# V12.0 — Acquisition Ready

A V12 transforma a base funcional em um ativo mais fácil de auditar e transferir.

## Buyer Data Room
`python3 main.py sale-pack` gera ZIP separado contendo somente dados agregados e documentação segura: performance, inventário, contrato API, readiness, branding, scan de segredos e demo sintético claramente rotulado.

O Data Room **não inclui** banco de produção, PII de assinantes, `config.env`, Telegram token, Asaas key ou provider keys.

## Acquisition Readiness
`python3 main.py acquisition-readiness` mede prontidão técnica: segurança do pacote, testes verificados, deployment, API/tenant, white-label, evidência de performance e documentação. O score é indicador técnico e não é avaliação financeira.

## Demo
O Data Room contém demo sintético apenas para demonstração visual. Dados sintéticos nunca são misturados ao relatório real de performance.
