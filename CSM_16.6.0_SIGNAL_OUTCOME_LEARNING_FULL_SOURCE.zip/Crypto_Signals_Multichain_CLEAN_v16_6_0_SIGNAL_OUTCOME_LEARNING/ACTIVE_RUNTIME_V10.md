# Runtime ativo — v16.0.0

O pacote interno continua `phantom_v10` para preservar imports e contratos LTS, mas a release de produto ativa é **`16.0.0-customer-portal-enterprise`**.

- Bot mobile: single-Python cooperativo.
- HTTPS: stdlib sequencial.
- Telegram: canal principal.
- Distribution V15: outbound-only, um job por fatia ociosa.
- Proof + On-Chain + Reputation + Observability preservados.
- Schema ativo: 680; piso compatível: 600.

## V16 SaaS surface
- Customer Portal is served by the separate SaaS API service at `/portal`.
- Tenant entitlements are synchronized fail-open from linked commercial users.
- The bot runtime remains single-Python/cooperative and does not depend on the portal.
