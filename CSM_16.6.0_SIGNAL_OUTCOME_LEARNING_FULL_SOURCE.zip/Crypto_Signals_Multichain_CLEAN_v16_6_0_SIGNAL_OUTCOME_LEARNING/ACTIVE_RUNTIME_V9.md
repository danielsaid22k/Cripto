# Runtime ativo — v9.0.2

Entrada operacional do bot:

```text
main.py
  -> phantom_v9.runtime_v902.RuntimeGuardV902
  -> phantom_v9.app_v902.PhantomAppV902
  -> phantom_v9.telegram_v902.TelegramClientV902
  -> phantom_v9.scanner_v902.ScannerEngineV902
  -> phantom_v9.network_v902.global_curl_queue()
```

Contrato mobile:

- single Python: **sim**;
- multiprocessing: **não**;
- ThreadPoolExecutor: **não**;
- curl concorrente: **máximo 1**;
- liveness: **session + heartbeat**;
- PID: diagnóstico apenas;
- UI não dispara o scanner diretamente.
