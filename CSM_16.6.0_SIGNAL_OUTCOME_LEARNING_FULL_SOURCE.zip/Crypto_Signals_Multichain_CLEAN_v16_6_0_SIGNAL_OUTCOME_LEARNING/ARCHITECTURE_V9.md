# Arquitetura Phantom v9.0.2

```text
Telegram UI
    |
    v
Application Service / Router
    |
    +-------------------+
    |                   |
    v                   v
Market / Asaas        Scheduler
    |                   |
    +---------+---------+
              |
              v
     ONE_GLOBAL_CURL_QUEUE
              |
              v
            curl
```

A fila global é o único ponto autorizado a conceder execução de `curl` no processo do bot. O scanner usa uma lease cooperativa. Enquanto essa lease está ocupada, o polling do Telegram retorna sem iniciar outro processo e o scheduler continua progredindo o scanner.
