# Asaas Sandbox Consistency Hotfix

Escopo desta revisão: integração Asaas Sandbox, persistência de configuração,
cliente Asaas armazenado no SQLite e diagnóstico. Scanner, score, filtros,
watchdog e regras dos planos não foram alterados nesta etapa.

Correções:
- pré-validação do status cadastral via `/myAccount/status/` antes de PIX Sandbox;
- recuperação Sandbox-only via `/sandbox/myAccount/approve` quando a API ainda
  não considera a conta aprovada;
- uma única repetição da criação PIX quando o próprio Asaas devolve erro de
  aprovação no Sandbox;
- validação do `asaas_customer_id` persistido para evitar reutilizar cliente de
  outra conta/chave Sandbox após troca de instalação;
- `doctor` passa a exibir o status cadastral visto pela API;
- `config-recover` ignora backups marcados como secretos que não contenham
  credenciais reais, evitando restaurar configuração vazia de pacote/teste.

Segurança:
- nenhuma API key, token Telegram, banco do usuário ou arquivo `.env` é incluído
  neste pacote.
- nenhuma tentativa de aprovação automática existe no ambiente production.
