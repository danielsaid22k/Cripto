# a-Shell Crash Recovery — v12.0.2

## Sintoma real

Após um stack trace em `ssl.py/socket.py` seguido de `segmentation fault`, `python3 -u launcher.py bot` podia responder:

`Já existe uma sessão saudável do bot (... heartbeat há 19.4s)`

mesmo sem um bot funcional atendendo o Telegram.

## Autoridade de liveness

A v12.0.2 deixa de confiar em três sinais isolados:

1. heartbeat recente;
2. PID positivo/reutilizado;
3. porta UDP simplesmente ocupada.

Uma sessão v12.0.2 precisa responder a um desafio loopback contendo `session + nonce`. O challenger só aceita o PONG exato da sessão registrada.

## Estados de recuperação

- `lease_sem_resposta`: porta/registro existe, mas nenhum runtime Python responde;
- `lease_legada_sem_resposta`: lease bind-only da v12.0.1 ficou presa além da janela curta confiável;
- `lease_liberada`: porta legada foi liberada normalmente;
- `processo_ausente`: PID é definitivamente inexistente;
- `heartbeat_expirado`: fallback para sessões antigas sem prova moderna.

## Segurança contra duas instâncias

Se o runtime anterior está realmente vivo, ele responde ao challenge e a segunda instância é bloqueada. Para evitar falso takeover durante uma chamada HTTPS sequencial curta, heartbeat muito recente recebe uma janela limitada para o runtime responder após concluir a chamada.
