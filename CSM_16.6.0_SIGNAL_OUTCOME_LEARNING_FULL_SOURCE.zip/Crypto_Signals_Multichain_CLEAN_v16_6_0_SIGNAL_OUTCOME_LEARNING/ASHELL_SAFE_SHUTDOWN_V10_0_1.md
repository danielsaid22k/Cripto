# Phantom Alert v10.0.1 — a-Shell Safe Shutdown

Esta hotfix foi criada a partir do diagnóstico reproduzido no a-Shell/iOS:

o bot operava normalmente, porém depois de ciclos HTTPS do scanner um `Ctrl+C`
podia devolver o prompt antes de toda a pilha `ssl/socket` estar totalmente
desmontada. A próxima invocação de Python podia então falhar com
`pyinit_core_reconfigure: failed to read thread state` / segmentation fault.

## Correções

- `HTTPResponse` e `HTTPSConnection` são fechados explicitamente em `finally`,
  inclusive quando ocorre `KeyboardInterrupt`.
- Todas as requisições enviam `Connection: close`.
- O bot possui parada cooperativa pelo Telegram com `/encerrar` (somente admin).
- O caminho de `Ctrl+C` não propaga novamente `KeyboardInterrupt` depois da
  limpeza do transporte.
- `PhantomApp.close()` encerra scheduler, scanner local, Telegram, SQLite e
  limpa a posse local do `NetworkBus`.
- Enquanto o scanner está ativo, o polling do Telegram usa `timeout=0`, evitando
  gastar aproximadamente 1 segundo antes de cada etapa do scanner.
- O scanner passou a trabalhar em fatias de tempo. Atingir o orçamento de 45 s
  é conclusão parcial normal, não falha de watchdog.
- O watchdog fica reservado ao timeout absoluto configurável.
- `doctor` e `signal-test` deixaram de importar o runtime v9 e agora usam v10.

## Parada recomendada no a-Shell

No Telegram, envie:

```text
/encerrar
```

Aguarde no a-Shell:

```text
✅ Bot encerrado com segurança (Telegram /encerrar).
```

Depois disso é seguro executar outro comando Python na mesma sessão do a-Shell.
`Ctrl+C` permanece como saída de emergência.

## Orçamento do scanner

Novas opções em `config.env` / `.env`:

```text
SCAN_CYCLE_BUDGET_SECONDS=45
SCAN_CYCLE_HARD_TIMEOUT_SECONDS=120
SCAN_REQUEST_TIMEOUT_SECONDS=2.5
```

O limite de candidatos (`SCAN_LIMIT`) continua preservado como objetivo de
busca, porém um ciclo automático não tenta obrigatoriamente consumir todos os
candidatos antes de devolver controle ao Telegram/scheduler.
