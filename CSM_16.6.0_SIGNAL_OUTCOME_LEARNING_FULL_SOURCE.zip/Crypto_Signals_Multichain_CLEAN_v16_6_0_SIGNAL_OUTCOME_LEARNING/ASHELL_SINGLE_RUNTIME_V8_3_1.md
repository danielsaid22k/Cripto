# Phantom Alert v8.3.1 — a-Shell Single Runtime

Esta release substitui, no caminho ativo do bot, os workers Python de scanner/mercado por uma arquitetura compatível com o limite de processos do a-Shell.

## Regras

- Um único interpretador Python para o bot.
- Scanner automático cooperativo: uma etapa de rede por iteração do loop.
- Mercado/providers no a-Shell usam `curl` externo com timeout curto; nenhum worker Python é aberto.
- GeckoTerminal é priorizado no mercado mobile; DexScreener permanece fallback.
- Polling Telegram de 1 segundo no a-Shell para manter callbacks responsivos entre etapas do scanner.
- Runtime guard v8.3.1 não cria thread de heartbeat.
- Módulos congelados da LTS 6.3.0 não são modificados.

## Diagnóstico

```sh
python main.py runtime-status
```

No a-Shell deve indicar `Workers Python do scanner: desativados` e localizar o executável `curl`.
