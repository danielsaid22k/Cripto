# Atualização remota pelo iPhone → Termux Android

O Android é o host que executa o CSM. O iPhone via SSH apenas envia comandos para o
shell do Android. Portanto, depois que o ZIP estiver em `~/storage/downloads` no
Android, toda a instalação pode ser feita pelo iPhone via SSH.

## Fluxo seguro

1. Coloque `Crypto_Signals_Multichain_v16.0.0_DANIEL_AI_v0.1.0.zip` em Downloads do Android.
2. No iPhone/a-Shell, conecte por SSH/Tailscale ao Android.
3. Já dentro do Termux remoto, pare o CSM atual.
4. Entre em `~/storage/downloads`.
5. Extraia o ZIP. A pasta nova é `Crypto_Signals_Multichain_CLEAN_v16_0_0_DANIEL_AI_v0_1_0` e não sobrescreve a V16 antiga.
6. Entre na pasta nova e rode instalação/validações.
7. Confirme `python main.py daniel-status` → `OpenAI: OFF`.
8. Inicie o bot da pasta nova.
9. Depois de validar Telegram/scanner, ajuste o boot/atalho para apontar para a pasta nova.

Não é necessário tocar na tela do Android para executar os passos 3–9; eles rodam no
Android através da sessão SSH aberta no iPhone.
