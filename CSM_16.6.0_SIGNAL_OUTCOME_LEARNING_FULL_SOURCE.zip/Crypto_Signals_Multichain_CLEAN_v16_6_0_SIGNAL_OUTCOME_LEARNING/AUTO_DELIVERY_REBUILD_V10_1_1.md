# AutoDelivery Rebuild v10.1.1

O envio automático foi refeito como componente isolado em `phantom_v10/auto_delivery.py`.

Principais contratos:

- O scanner continua sendo a autoridade de aprovação e não foi alterado.
- A cota é aplicada depois da deduplicação. Candidatos já enviados não ocupam vaga.
- Free, Plus e Premium usam cotas independentes (1/2/3 por ciclo por usuário, configuráveis).
- Destinatários são segmentados pelo plano-base normalizado.
- Preferências de rede, sinais automáticos e horário silencioso continuam respeitados.
- Telegram usa retry apenas para falhas transitórias/429/5xx.
- A deduplicação só é persistida após confirmação do `sendMessage`.
- A posição de acompanhamento só é criada após entrega confirmada.
- O terminal informa usuários, elegíveis, duplicados e o motivo quando `enviados=0`.
