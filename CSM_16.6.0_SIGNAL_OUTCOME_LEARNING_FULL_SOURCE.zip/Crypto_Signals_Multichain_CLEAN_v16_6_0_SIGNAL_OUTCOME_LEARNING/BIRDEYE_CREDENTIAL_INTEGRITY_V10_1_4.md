# Birdeye Credential Integrity — v10.1.4

## O que foi encontrado

O ZIP comercial não contém uma API key Birdeye real. No aparelho, entretanto, uma chave pode existir em vários locais legítimos:

- `Crypto_Signals_Multichain_State/config.env` — fonte persistente ativa;
- `.env` da release atual — cópia de compatibilidade;
- `.env` de releases antigas — histórico local;
- `crypto_signals.env.backup` — legado;
- `Crypto_Signals_Multichain_State/backups/*.zip` com `state/config.env` — backups históricos com segredos.

No runtime, `config.env` persistente é carregado com prioridade. Backups não são fontes operacionais normais.

## Risco corrigido

Uma chave antiga podia permanecer dentro de um backup com segredos. O mecanismo de recuperação já não sobrescrevia uma chave atual não vazia, porém uma chave antiga ainda poderia reaparecer se o campo Birdeye fosse apagado/perdido e a recuperação automática preenchesse o valor faltante.

A v10.1.4 cria um marcador persistente contendo apenas a fingerprint da geração atual. Se um backup apresentar outra fingerprint, a chave Birdeye histórica é ignorada na recuperação automática.

## Diagnóstico

`python3 main.py birdeye-key-audit`

Mostra origem, fingerprint e cópias históricas sem imprimir a chave.

`python3 main.py birdeye-check`

Testa o endpoint de networks e a rota real New Listing, além de mostrar a mensagem segura devolvida pelo Birdeye em caso de erro.
