# Birdeye CU Guard — v10.1.5

Esta revisão trata explicitamente a resposta BDS `Compute units usage limit exceeded` como estado de **cota de Compute Units esgotada**, e não como chave inválida ou erro de contrato.

- O diagnóstico encerra após o probe barato de `/defi/networks` quando a cota está esgotada, evitando uma chamada adicional ao New Listing.
- O scanner pausa apenas o Birdeye por 30 minutos e mantém DexScreener, GeckoTerminal e CoinGecko operacionais.
- O `doctor` diferencia credencial inválida de cota CU esgotada.
- Cópias históricas de chaves continuam auditáveis, mas não são confundidas com a fonte ativa.
- Nenhum segredo é incluído no pacote comercial.
