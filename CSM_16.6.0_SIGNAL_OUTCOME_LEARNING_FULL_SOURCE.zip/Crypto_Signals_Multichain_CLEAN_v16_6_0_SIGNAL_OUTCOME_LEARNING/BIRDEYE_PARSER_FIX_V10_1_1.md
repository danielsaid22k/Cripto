# Birdeye Parser Fix v10.1.1

Correção localizada no adaptador Birdeye do Multi-Provider.

## Causa
O endpoint `defi/v2/tokens/new_listing` retorna os tokens em `data.items`, mas normalmente não repete a rede em cada item porque ela já é informada no cabeçalho `x-chain`. O parser anterior descartava esses itens ao normalizar uma rede vazia.

## Correção
O parser agora herda a rede da própria fonte consultada quando o item não inclui `chain`, `network` ou `chainId`. Se o item trouxer uma rede explícita, ela continua tendo prioridade.

Nenhuma lógica de DexScreener, GeckoTerminal, CoinGecko, score, filtros, Telegram, Asaas, banco ou planos foi alterada.
