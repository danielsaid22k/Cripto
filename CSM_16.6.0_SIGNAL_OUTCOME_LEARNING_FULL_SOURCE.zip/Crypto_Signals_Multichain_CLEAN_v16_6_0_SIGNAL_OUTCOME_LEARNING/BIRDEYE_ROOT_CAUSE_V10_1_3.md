# Birdeye Root Cause — v10.1.3

## O que foi observado

O runtime v10.1.2 mostrava `Birdeye=0(+0)` com `HTTP 400` em diferentes redes. Um teste mínimo executado no aparelho também mostrou que a chave persistente atual é rejeitada com `HTTP 401 Unauthorized`.

## Falha de código confirmada

Em `phantom_v10/discovery.py`, cada rota Birdeye enviava:

- `limit=20`;
- `meme_platform_enabled=true` para Solana;
- `meme_platform_enabled=false` para todas as demais redes.

O parâmetro `meme_platform_enabled` é Solana-only no endpoint `defi/v2/tokens/new_listing`. A correção remove esse parâmetro por completo nas redes EVM.

## Falha de configuração confirmada no aparelho

A configuração persistente contém uma chave Birdeye de 32 caracteres, mas o servidor respondeu `401 Unauthorized` no teste mínimo. Isso indica chave ausente/inválida/expirada/revogada do ponto de vista do Birdeye. O pacote comercial não contém e não deve conter a chave privada do operador; portanto, após instalar a v10.1.3, uma chave BDS válida precisa ser salva no setup se a atual continuar retornando 401.

## Proteções novas

- `birdeye-check` nativo, sem curl/heredoc;
- validação de autenticação separada da validação de parâmetros;
- pausa de 5 min para 401/403;
- sem stale cache em falha de autenticação;
- demais providers continuam ativos;
- logs de erro não expõem a API key.
