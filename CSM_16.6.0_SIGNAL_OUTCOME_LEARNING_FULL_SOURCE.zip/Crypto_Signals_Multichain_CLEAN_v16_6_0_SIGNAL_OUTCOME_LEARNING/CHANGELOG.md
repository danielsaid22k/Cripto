# 16.6.0 — Signal Outcome Learning

- Adiciona aprendizado evidence-only sobre sinais efetivamente entregues.
- Segmenta resultados por rede, provider, rede/provider, score, liquidez, volume e plano.
- Usa suavização Bayesiana e amostra mínima para reduzir conclusões frágeis.
- Persiste snapshots locais e recomendações PROMISING/CAUTION/OBSERVE.
- Reaproveita o Performance Ledger; não cria novas chamadas HTTPS.
- Não altera filtros, scoring, Telegram ou lógica LIVE.
- Não existe auto-apply na V16.6.0; futura otimização exigirá nova versão e aprovação humana.

# 16.5.9 — Provider Intelligence & Coverage

- Adiciona Adaptive GeckoTerminal Backoff: Retry-After ou 5m → 10m → 20m → 30m máximo.
- Detecta rotação da API key Birdeye por fingerprint e executa probe seguro sem sinais/Telegram.
- Adiciona failover inteligente por rede/função e Provider Quality Router.
- Adiciona Recovery Probe diagnóstico durante cooldown, sem contaminar métricas LIVE.
- Separa saúde operacional atual do histórico auditável de incidentes provider.
- Adiciona cobertura por rede/provider, Coverage Guard e Opportunity Coverage Watchdog.
- Adiciona diagnóstico de rejeições por rede/provider.
- Mantém DexPaprika/Honeypot keyless e todos os providers/integradores existentes.
- Mantém `~/CSM_CURRENT`, schema 680, filtros, scoring, Telegram, Discord, Retool e estado persistente.

# 16.5.8 — Provider & Telegram Integrity

- Corrige classificação/telemetria de falhas Telegram e respeita `retry_after` em HTTP 429 real.
- Impede `TELEGRAM_CHAT_ID` operacional de ser cadastrado automaticamente como usuário Free.
- Restaura comandos administrativos de block/unblock no router ativo.
- Deduplica incidentes de quota/rate-limit por família de provider e resolve incidentes stale.
- Persiste cooldowns de providers e amplia backoff do GeckoTerminal em HTTP 429.
- Adiciona Honeypot.is keyless como fallback advisory de segurança EVM.
- Adiciona `~/CSM_CURRENT` via post-update sem renomear a instalação física.
- Nenhuma alteração de filtros LIVE, scoring ou schema do banco.

# V16.5.7 — Provider Coverage & Stability

- Adiciona DexPaprika como provider público/keyless de discovery multi-chain e fallback de mercado.
- Base URL configurável e API key opcional; nenhuma chave é necessária por padrão.
- Rotação limitada a 1 rede por ciclo por padrão para respeitar o orçamento keyless.
- Birdeye Compute Units: cooldown padrão ampliado para 6h, evitando flapping e gasto repetido quando a cota já acabou.
- DexPaprika HTTP 402/429 entra em cooldown isolado sem derrubar os providers existentes.
- Filtros, scoring, Telegram, Discord, pagamentos, banco, Runtime Resilience e Daniel AI permanecem preservados.

# 16.5.6 — Post-Update Hotfix

- Corrige o Finalizer para migrar somente o banco persistente atual, in-place.
- Remove restauração automática de backup anterior do fluxo `post-update`.
- Mantém backup de segurança pré-migração antes do upgrade de schema.
- Adiciona espera/retry de até 60s para Bot + SaaS API `/healthz` após restart.
- Evita falso `FAILED` enquanto a porta 8787 ainda está inicializando.
- Preserva fail-closed, Runtime Resilience, Signal Measurement Integrity e todas as integrações existentes.

# CSM 16.5.5 — Post-Update Finalizer

- Adiciona `python main.py post-update` para migração, validação e restart seguro em uma única ação.
- Fail-closed: Runtime/Admin Bridge só reiniciam se migrate, db-check, selftest, release-check, version e Config Integrity passarem.
- Adiciona relatório persistente e lock contra finalizações concorrentes.
- Adiciona `POST /api/update/finalize` e `GET /api/update/finalize/status` para o Update Center do Retool.
- Preserva integralmente Runtime Resilience 16.5.3 e Signal Measurement Integrity 16.5.4.
- Nenhuma alteração em scanner, scoring, filtros, Telegram, Discord, pagamentos, chains ou entrega LIVE.

# CSM 16.5.4 — Signal Measurement Integrity

- Corrige horizonte 5m para nunca usar baseline pré-horizonte.
- Remove viés ACTIVE-only da elegibilidade Shadow.
- Captura Shadow passa a ser evidence-only sem mutar lifecycle.
- Telemetria da fila passa a usar ledger recente.
- Nenhuma alteração na lógica LIVE de sinais.

# CSM 16.5.3 — Runtime Resilience

- Corrige falso `degraded` no Retool quando o bot permanece saudável pela lease/sessão/heartbeat v10 mas a sessão tmux não é vista.
- SaaS API passa a ser validada pelo endpoint local `/healthz`, não apenas pela sessão tmux.
- Snapshot do runtime expõe `health_score` operacional e release comercial atual para manter o card do Retool consistente.
- Novo Runtime Resilience Manager monitora bot, SaaS API, Supervisor, Admin Bridge, ngrok e Config Auditor.
- Recuperação automática controlada exige falha confirmada, cooldown e proteção contra restart storm.
- Watchdog respeita `desired_state` do Supervisor e não religa serviços parados intencionalmente.
- Watchdog suspende recuperação durante manutenção do ProjectLeader.
- Recuperação do runtime é bloqueada se a integridade de configuração indicar chaves críticas ausentes.
- Nenhum valor secreto é registrado; `config.env`, filtros, scoring, Telegram, Discord, chains, pagamentos e Daniel AI 1.3.1 permanecem preservados.

# Daniel AI V1.3.0 — Daniel Smart / Local Generative Brain

- Adiciona LLM local GGUF via llama.cpp para perguntas livres.
- Perfil inicial SMART: Qwen3-4B Q4_K_M.
- Mantém rotas determinísticas do CSM acima do LLM.
- Histórico curto local para continuidade conversacional.
- Remove o fallback repetitivo sobre “modelo generativo pago”.
- Novos comandos: daniel-smart-status/test/benchmark/on/off.
- OpenAI continua opcional e desligada por padrão.

# Daniel AI V1.2.4 — Adaptive Conversational Voice

- seleção automática entre perfis executivo, analista e explicativo;
- áudio prioriza conclusão, significado e próximo passo em vez de ler relatório;
- sequências de terminal são explicadas por objetivo, mantendo os comandos exatos somente no texto;
- variações naturais determinísticas para reduzir repetição sem perder reprodutibilidade;
- pronúncia técnica refinada e limite de métricas faladas;
- Whisper, TTS neural, fallbacks e estado persistente preservados;
- 394/394 testes, SELFTEST OK, release-check aprovado, schema 680.

# Daniel AI V1.2.3 — Conversational Voice Intelligence

- Texto do Telegram permanece técnico e completo; áudio recebe uma versão conversacional separada.
- Nova camada local `conversational_voice.py`, sem OpenAI e sem nova dependência pesada.
- Estrutura falada: contexto → importância → consequência → ponto de atenção.
- Narrativas especializadas para status operacional, análise de ativo, explicação de score, lifecycle e providers.
- Fallback genérico converte listas técnicas em briefing falado sem repetir bullets linha por linha.
- Limite próprio de tamanho falado para evitar respostas longas demais.
- Natural Neural Voice V1.2.2 preservada: Edge Neural PT-BR principal + Supertonic/Kokoro/eSpeak como fallbacks.
- Native Voice via whisper.cpp preservada; instalador V1.2.3 recupera caminhos persistentes do Whisper quando os arquivos já existem.
- Scanner, filtros, scoring, pagamentos, schema e estado persistente não são modificados.

# Daniel AI V1.2.2 — Natural Neural Voice

- Microsoft Edge Neural PT-BR online via `edge-tts` como motor principal, sem chave de API.
- Supertonic 3, Kokoro PT-BR e eSpeak preservados como fallbacks automáticos.
- Voz padrão `pt-BR-AntonioNeural`; presets Fabio, Humberto e Francisca.
- Novos comandos `daniel-speech-compare` e `daniel-speech-use`.
- Entrada de voz continua local com whisper.cpp; somente o texto final da resposta é enviado ao TTS online.
- Falha do TTS permanece não fatal: texto do Telegram é entregue primeiro.
- CSM V16.4, schema 680, scanner, pagamentos, filtros e limites críticos preservados.

# Changelog

## 16.2.0 + Daniel AI 0.8.0
- Scanner Intelligence persiste decisões APPROVED/REJECTED/UNAVAILABLE e motivo exato de rejeição.
- Funil por rede, taxa de aprovação e comparação agregada aprovados × rejeitados.
- Daniel responde gargalos do scanner com evidência local, sem inventar motivos.
- Outcome Learning lê o Performance Ledger e aprende padrões observacionais de resultados com amostra/confiança.
- Painel Daniel AI ganha Scanner Intelligence 24h.
- Nenhum filtro, score, GoPlus, pagamentos ou wallet é alterado automaticamente; OpenAI permanece OFF.

## 16.1.0 + Daniel AI 0.7.0
- Continuous Learning ON por padrão, com fila automática de pesquisa.
- Perguntas e sinais aprovados podem alimentar temas de aprendizado.
- Conhecimento persistido com fontes, confiança, TTL e notas Markdown auditáveis.
- Atualização automática de conhecimento vencido, limite de armazenamento e scheduler de baixa prioridade.
- Comandos learning on/off/status/run e painel com estado/fila/conhecimento.
- OpenAI permanece OFF; CSM continua read-only para o Daniel.

## 16.1.0 + Daniel AI 0.6.0
- Provider Resilience: COOLDOWN HTTP 429, quota separada, fallback e recovery grace.
- Runtime ativo persiste provider health real para Daniel AI/painel.
- Alertas operacionais deduplicados e aviso único de recuperação.
- Daniel AI V0.6 explica failover/cooldown e mostra Provider Resilience no painel.
- OpenAI permanece OFF; schema 680 preservado.

# Daniel AI V0.5.0 — Web Reliability + Admin Panel

- Corrige a descoberta web da V0.4 com múltiplos fallbacks públicos e sem chave.
- Prioriza Google News para consultas de notícias.
- Mantém leitura direta de URLs públicas independente da busca.
- Adiciona identificação da fonte de descoberta e diagnóstico dos providers tentados.
- Adiciona painel dedicado `/daniel-ai` no Admin Web.
- Adiciona `daniel-panel` e `daniel-panel-token`.
- Preserva memória, documentos, histórico e inteligência administrativa.
- Preserva `OPENAI_ENABLED=false` e web opt-in.
- Preserva CSM V16.0.0 e schema 680.

## 16.4.0 — Smart Reentry + Daniel AI 1.0 Operational Copilot

- Plan-aware signal reentry cooldowns: Free 24h, Plus 12h, Premium 6h.
- Reentry only for candidates rediscovered and approved by the current scanner.
- Prior STOPPED/DETERIORATING/TP3 outcomes require material improvement evidence.
- Append-only confirmed delivery history in `signal_reentry_history`.
- Telegram reentry banner with factual reason/evidence.
- Daniel AI V1.0 Operational Copilot and reentry explanations.
- Existing Provider Resilience, Scanner Intelligence, Continuous Learning and Signal Lifecycle preserved.
- OpenAI remains OFF by default; no heavy/paid voice dependency auto-installed.


## 16.4.0 + Daniel AI 1.1.0 — Native Voice

- Telegram voice/audio is downloaded with a hard local size cap.
- Local ffmpeg + whisper.cpp transcription; no OpenAI/API fee required.
- Portuguese default, 90-second/12-MB bounded audio.
- Audio is deleted after transcription; transcript enters the normal Daniel conversation memory.
- Spoken content routes only to DanielAI.ask and cannot bypass critical-action/read-only boundaries.
- `daniel-voice-status`, `daniel-voice-on/off`, `daniel-voice-transcribe` and `install_voice_termux.sh`.
- Existing Smart Reentry, Lifecycle, Scanner Intelligence, Provider Resilience and Continuous Learning preserved.


## Daniel AI V1.2.0 — Dual Response Voice
- Resposta dupla no Telegram para comandos recebidos por voz: texto + áudio.
- TTS 100% local com eSpeak NG e ffmpeg/Opus.
- Texto é enviado primeiro e nunca depende do TTS.
- Áudio temporário é apagado após o envio.
- OpenAI permanece OFF por padrão.
