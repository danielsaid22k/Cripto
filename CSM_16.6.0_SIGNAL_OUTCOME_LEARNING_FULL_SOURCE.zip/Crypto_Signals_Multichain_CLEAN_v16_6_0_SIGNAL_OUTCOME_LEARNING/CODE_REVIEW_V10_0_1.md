# Revisão técnica — Phantom Alert v10.0.1

## Escopo

Foi revisado o caminho operacional completo iniciado por `python main.py bot`,
incluindo composição, runtime guard, Telegram, transporte HTTPS, scheduler,
scanner, market/providers, pagamentos, roteamento/UI e persistência usada pelo
runtime. Os módulos históricos `phantom_v9/` permanecem apenas para regressão e
compatibilidade de testes; não fazem parte do caminho ativo do bot.

Também foram executadas verificações automáticas de sintaxe/importação em todos
os módulos Python de `phantom_v10/` e `csm/`, além da suíte completa de testes.

## Falhas encontradas

### 1. Encerramento HTTPS incompleto no cenário de Ctrl+C

O transporte fechava `HTTPSConnection`, mas não fechava explicitamente o
`HTTPResponse` que mantém o wrapper de leitura do socket/TLS. O stack observado
no a-Shell (`ssl.py -> recv_into -> socket.py -> readinto`) é compatível com uma
interrupção durante leitura TLS seguida de reconfiguração do Python embutido.

Correção:

- `HTTPResponse.close()` em `finally`;
- `HTTPSConnection.close()` em `finally`;
- limpeza protegida até contra uma segunda interrupção;
- `Connection: close` em todas as requisições;
- liberação garantida do `NetworkBus`.

### 2. Ctrl+C era o mecanismo normal de parada

No a-Shell isso pode interromper a pilha nativa no pior ponto possível. Agora o
bot possui parada cooperativa pelo Telegram:

```text
/encerrar
```

O comando é restrito ao administrador e é processado entre operações de rede.
O caminho de `Ctrl+C` continua disponível como emergência, mas não repropaga o
`KeyboardInterrupt` depois da limpeza local.

### 3. Watchdog do scanner estava medindo um trabalho impossível para a cadência

O scanner tinha alvo padrão de até 200 candidatos, rede totalmente sequencial e
um watchdog global de 120 s. Além disso, antes de cada `scanner.step()` o loop
fazia um `getUpdates` do Telegram com long-poll de 1 s. Assim, atingir o watchdog
era esperado mesmo quando cada provider individual estava funcionando.

Correção:

- scanner automático em fatias com orçamento padrão de 45 s;
- atingir o orçamento é conclusão parcial normal, não erro/degradação;
- timeout absoluto de 120 s permanece como proteção real;
- Telegram usa `timeout=0` enquanto o scanner está ativo;
- parâmetros configuráveis:
  - `SCAN_CYCLE_BUDGET_SECONDS`;
  - `SCAN_CYCLE_HARD_TIMEOUT_SECONDS`;
  - `SCAN_REQUEST_TIMEOUT_SECONDS`.

### 4. Comandos auxiliares ainda atravessavam o runtime v9

`doctor` e `signal-test` importavam classes de `phantom_v9`, apesar de o bot ser
v10. Isso quebrava a promessa de um grafo operacional coerente.

Correção: ambos agora usam exclusivamente `phantom_v10` no caminho operacional.
Uma verificação AST impede regressão de imports operacionais `phantom_v9` em
`main.py`.

### 5. Recursos locais não tinham uma sequência explícita de fechamento

`PhantomApp` não possuía `close()` centralizado. Agora o encerramento fecha, em
ordem, scheduler/scanner local, Telegram, SQLite e o estado local do
`NetworkBus`. Comandos `health` e `reset-plan` também passaram a fechar SQLite
explicitamente.

### 6. Documentação/comandos estavam parcialmente desatualizados

`lts-status`, `COMANDOS_A_SHELL.md` e o instalador ainda citavam runtime v9 ou
um `config.py` inexistente. Foram alinhados à v10.0.1 e ao comando
`python main.py setup`.

## UI e callbacks

A auditoria da UI continua aprovada:

- rotas de callback cadastradas: 19;
- botões de teclado: 14;
- callbacks sem rota: 0;
- botões sem handler: 0.

A parada segura `/encerrar` também funciona mesmo se o administrador estiver no
meio do fluxo de pagamento/CPF-CNPJ.

## Validação executada

- `python -m compileall`: aprovado;
- análise AST de `phantom_v10/` + `csm/`: sem erro de sintaxe;
- `pytest -q`: **132 passed**;
- `python main.py selftest`: aprovado;
- `python main.py ui-audit`: aprovado;
- `python main.py runtime-status`: estado local coerente;
- `python main.py release-tests`: aprovado;
- `python main.py foundation-release`: aprovado;
- `python main.py release-summary`: aprovado.

## Limite da homologação

O segmentation fault original ocorre dentro do runtime Python/SSL embutido do
a-Shell/iOS e não pode ser reproduzido neste ambiente Linux. A correção remove
os problemas de ciclo de vida e interrupção presentes no código e adiciona uma
parada cooperativa que evita interromper TLS em andamento. A homologação final
do comportamento nativo deve ser feita no próprio iPhone/a-Shell.
