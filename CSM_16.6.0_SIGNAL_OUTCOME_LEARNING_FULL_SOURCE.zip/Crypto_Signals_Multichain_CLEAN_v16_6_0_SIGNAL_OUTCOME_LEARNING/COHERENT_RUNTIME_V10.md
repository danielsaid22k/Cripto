# Phantom Alert v10.0.1 — Coherent Runtime

A v10 reconstrói o caminho operacional do bot sem reutilizar o runtime v9.

## Grafo de dependências ativo

```text
main.py
  -> phantom_v10.runtime.RuntimeGuard
  -> phantom_v10.app.PhantomApp            (composition root)
       -> phantom_v10.router.InteractionRouter
       -> phantom_v10.scheduler.Scheduler
       -> phantom_v10.telegram.TelegramClient
       -> phantom_v10.scanner.ScannerEngine
       -> phantom_v10.market.MarketService
       -> phantom_v10.payments.PaymentService
       -> phantom_v10.transport.StdlibHttpTransport
            -> http.client + ssl (biblioteca padrão)
       -> csm.storage.Storage               (contrato LTS persistente)
```

## Regras do runtime

- um único interpretador Python;
- zero `multiprocessing`;
- zero `ThreadPoolExecutor`;
- zero `subprocess`/`curl` no runtime ativo;
- zero `requests`/`urllib3` no runtime ativo;
- uma única operação HTTPS por vez via `NetworkBus`;
- scanner cooperativo: no máximo uma requisição por `step`;
- UI local não consulta providers;
- botão Sinais automáticos não inicia scanner;
- falhas transitórias de Telegram no bootstrap geram retry, não encerramento do bot;
- liveness por session + heartbeat; PID apenas diagnóstico;
- LTS 6.3.0 e schema 600 preservados.


## Hotfix a-Shell v10.0.1

O transporte fecha explicitamente resposta e conexão HTTPS; o scanner usa orçamento cooperativo de ciclo; e `/encerrar` fornece parada segura entre operações de rede. Veja `ASHELL_SAFE_SHUTDOWN_V10_0_1.md`.
