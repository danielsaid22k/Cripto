# Comandos a-Shell — v16.0.0 Customer Portal & Enterprise Dashboard

```sh
cd ~/Documents
unzip -o Crypto_Signals_Multichain_v16.0.0_CUSTOMER_PORTAL_ENTERPRISE_FOR_SALE.zip
cd Crypto_Signals_Multichain_CLEAN_v16_0_0_DANIEL_AI_v0_1_0
chmod +x install_a_shell.sh
./install_a_shell.sh
python3 main.py setup
python3 main.py migrate
python3 main.py db-check
python3 main.py doctor
python3 main.py selftest
python3 main.py entitlement-status --tenant crypto-signals
```

Bot:

```sh
python3 -u launcher.py bot
```

A V16 continua compatível com o bot no a-Shell. Para operação contínua da SaaS API / Customer Portal, prefira Termux/Android ou Linux/VPS por causa das limitações de background do iOS.
