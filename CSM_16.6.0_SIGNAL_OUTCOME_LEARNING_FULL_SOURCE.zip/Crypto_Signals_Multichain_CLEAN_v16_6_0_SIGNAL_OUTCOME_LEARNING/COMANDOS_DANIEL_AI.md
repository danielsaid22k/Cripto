# Comandos Daniel AI V0.8.0

## Scanner Intelligence

- `/daniel motivos de rejeição nas últimas 24h`
- `/daniel por que há poucos sinais na BSC nas últimas 24h?`
- `/daniel compare os rejeitados com os aprovados`
- `/daniel quais redes estão melhores hoje?`
- `/daniel quais padrões você encontrou nos sinais?`

CLI:

```sh
python main.py scanner-intelligence --hours 24
python main.py scanner-intelligence --hours 24 --chain bsc
python main.py scanner-decisions --hours 24 --decision rejected --limit 30
```

## Continuous Learning

- `/daniel aprendizado status`
- `/daniel o que você aprendeu`
- `/daniel aprenda sobre Bitcoin ETF`
- `/daniel o que você sabe sobre Bitcoin ETF?`

```sh
python main.py daniel-learning-status
python main.py daniel-learning-run
python main.py daniel-learning-on
python main.py daniel-learning-off
```

O aprendizado fica ON por padrão. Outcome Learning local funciona sem OpenAI; pesquisa pública nova exige a Web controlada do Daniel.

## Status / providers

- `/daniel status do sistema`
- `/daniel status dos providers e failover`
- `/daniel geckoterminal cooldown`
- `/daniel diagnóstico do scanner`

## Sinais

- `/daniel analise CATE`
- `/daniel por que CATE recebeu esse score?`
- `/daniel compare CATE e GORE`
- `/daniel melhores sinais das últimas 24 horas`

## Memória / histórico

- `/daniel histórico da conversa`
- `/daniel lembre que meu teste favorito é CATE`
- `/daniel qual é meu teste favorito?`
- `/daniel esqueça teste favorito`

## Documentos

- `/daniel documentos`
- `/daniel leia "manual.pdf"`
- `/daniel procure nos documentos liquidez`
- `/daniel reindexe documentos`

## Web

```sh
python main.py daniel-web-on
python main.py daniel-web-off
```

- `/daniel web status`
- `/daniel pesquise na internet bitcoin ETF`
- `/daniel busque na web notícias sobre Solana`
- `/daniel abra https://example.org/`

## Painel

```sh
python main.py daniel-panel-token
python main.py daniel-panel --host 0.0.0.0
```

O painel `/daniel-ai` mostra Scanner Intelligence + Continuous Learning + Provider Resilience.

## OpenAI

Enquanto `OPENAI_ENABLED=false`, nenhuma chamada à API paga da OpenAI é feita.


## Signal Lifecycle & Outcome Intelligence — V0.9

- `/daniel como estão os sinais de hoje?`
- `/daniel quais sinais estão deteriorando?`
- `/daniel quais sinais atingiram TP hoje?`
- `/daniel quais padrões você encontrou nos sinais?`

CLI:

```sh
python main.py signal-lifecycle --hours 24
python main.py signal-lifecycle --hours 24 --chain solana
python main.py signal-lifecycle-events --hours 24 --limit 20
```

Outcome Intelligence é local e somente analítico. Daniel não altera scoring/filtros automaticamente.

## Daniel AI V1.0 — Operational Copilot + Smart Reentry

```text
/daniel status operacional
/daniel reentradas nas últimas 24h
/daniel por que CATE foi reenviado?
/daniel quais reentradas tiveram melhor resultado?
/daniel quais sinais recuperaram depois de deteriorar?
```

CLI:

```sh
python main.py smart-reentry --hours 24
```

Free=24h, Plus=12h, Premium=6h. Reentrada exige reencontro + aprovação atual; STOP/DETERIORATING/TP3 exigem melhora material. Daniel permanece somente leitura sobre scoring/filtros/configurações críticas.


## V1.1 Native Voice

```bash
python main.py daniel-voice-status
bash install_voice_termux.sh
python main.py daniel-voice-on
python main.py daniel-voice-off
```

No Telegram, depois que `daniel-voice-status` mostrar `Pronto: SIM`, basta enviar uma nota de voz ao bot.


## V1.2 — Dual Response Voice

```bash
python main.py daniel-speech-status
python main.py daniel-speech-on
python main.py daniel-speech-off
bash install_speech_termux.sh
```

Ao receber uma nota de voz, o Daniel envia primeiro o texto e depois a resposta falada. Se o TTS falhar, o texto continua funcionando.


## V1.2.2 — Natural Neural Voice

```bash
python main.py daniel-speech-status
python main.py daniel-speech-test
python main.py daniel-speech-compare
python main.py daniel-speech-use antonio
python main.py daniel-speech-use fabio
python main.py daniel-speech-use humberto
python main.py daniel-speech-use francisca
```

Instalação do motor online natural no Termux:

```bash
bash install_natural_voice_termux.sh
```

## V1.2.3 — Conversational Voice Intelligence

```bash
python main.py daniel-conversational-voice-status
```

```bash
python main.py daniel-conversational-voice-test
```

```bash
python main.py daniel-conversational-voice-on
```

```bash
python main.py daniel-conversational-voice-off
```

Com a camada ON, o texto técnico permanece intacto no Telegram. Somente o roteiro enviado ao TTS é reorganizado como briefing conversacional.


## V1.2.4 — Adaptive Conversational Voice

```bash
python main.py daniel-conversational-voice-status
```

```bash
python main.py daniel-conversational-voice-test
```

O modo padrão é `adaptive`: executivo para status/resumo, analista para sinais/tokens e explicativo para “por quê?”, erros e comandos.
