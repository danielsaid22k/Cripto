# Comandos Termux — CSM V16.2 + Daniel AI V0.8.0

```sh
csm-stop
cd ~/storage/downloads
unzip -o Crypto_Signals_Multichain_v16.2.0_DANIEL_AI_v0.8.0_SCANNER_LEARNING_INTELLIGENCE.zip
cd Crypto_Signals_Multichain_CLEAN_v16_2_0_DANIEL_AI_v0_8_0
bash install_termux.sh
python main.py migrate
python main.py db-check
python main.py selftest
python main.py daniel-status
```

Não rode `python main.py setup` se a configuração atual já funciona.

## Atualizar Termux:Boot

```sh
sed -i 's#Crypto_Signals_Multichain_CLEAN_v16_1_0_DANIEL_AI_v0_7_0#Crypto_Signals_Multichain_CLEAN_v16_2_0_DANIEL_AI_v0_8_0#' ~/.termux/boot/10-start-csm
grep '^PROJECT=' ~/.termux/boot/10-start-csm
csm-start
csm-status
```

## Scanner Intelligence

```sh
python main.py scanner-intelligence --hours 24
python main.py scanner-decisions --hours 24 --decision rejected --limit 30
```

## Aprendizado automático

```sh
python main.py daniel-learning-status
python main.py daniel-learning-run
```

Desligar depois:

```sh
python main.py daniel-learning-off
csm-stop
csm-start
```

Religar:

```sh
python main.py daniel-learning-on
csm-stop
csm-start
```

OpenAI permanece OFF.

## V16.4 Smart Reentry

```sh
python main.py smart-reentry --hours 24
python main.py smart-reentry --hours 168 --plan premium
```
