# Phantom Alert v8.0 — Core Rebuild

Base LTS preservada: 6.3.0.

Módulos reconstruídos: HTTP Engine sem requests/urllib3, Process Manager com flock, scanner sequencial e supervisor de ciclo no processo principal.
