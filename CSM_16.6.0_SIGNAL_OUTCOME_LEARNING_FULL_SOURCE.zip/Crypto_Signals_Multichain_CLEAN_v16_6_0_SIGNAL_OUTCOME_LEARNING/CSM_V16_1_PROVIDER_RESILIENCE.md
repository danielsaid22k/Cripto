# CSM V16.1 — Provider Resilience

Camada aditiva de resiliência sobre o runtime V16, preservando LTS 6.3.0 e schema 680.

## O que muda

- HTTP 429 abre estado `COOLDOWN` com backoff de minutos e jitter determinístico.
- `force=True` não ignora circuito aberto: o scanner usa fallback em vez de insistir no provider limitado.
- `QUOTA_EXHAUSTED` continua separado de rate limit transitório e recebe pausa longa.
- GeckoTerminal discovery pode ser pausado sem interromper DexScreener/Birdeye/CoinGecko.
- GeckoTerminal market cai naturalmente para DexScreener durante cooldown.
- Snapshot do provider health passa a ser persistido pelo runtime `phantom_v10` ativo.
- Health agregado não pode mostrar 100/100 enquanto houver provider em `COOLDOWN`, `DEGRADED`, `OFFLINE` ou `QUOTA_EXHAUSTED`.
- Depois de recuperar, o provider fica em janela curta de `recently_recovered` antes de voltar a contribuir com health máximo.
- Alertas HIGH/CRITICAL continuam deduplicados por cooldown; incidentes de rate limit resolvidos podem gerar um aviso único de recuperação.

## Estados operacionais

- `ONLINE`: provider saudável.
- `AVAILABLE`: rota disponível, ainda sem sucesso confirmado.
- `DEGRADED`: falhas transitórias em sequência.
- `COOLDOWN`: HTTP 429/rate limit; fallback ativo e nova tentativa agendada.
- `QUOTA_EXHAUSTED`: quota de pacote/conta esgotada; pausa longa.
- `OFFLINE`: falha persistente/autenticação.

## Segurança

A camada não altera chaves, scoring, GoPlus, pagamentos, usuários ou carteiras. O fallback só escolhe outra fonte de dados já configurada.
