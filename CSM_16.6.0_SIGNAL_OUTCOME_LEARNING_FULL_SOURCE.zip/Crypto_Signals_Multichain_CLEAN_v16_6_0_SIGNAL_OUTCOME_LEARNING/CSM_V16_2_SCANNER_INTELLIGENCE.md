# CSM V16.2.0 — Scanner Intelligence

V16.2 preserva toda a V16.1 Provider Resilience e adiciona uma camada **somente de evidência** ao scanner. Nenhum filtro, gate GoPlus ou fórmula de score é alterado por esta camada.

## O que passa a ser persistido

- ciclo do scanner (`scanner_intelligence_cycles`);
- decisão por candidato (`scanner_decisions`);
- rede, provider e tier de discovery;
- `APPROVED`, `REJECTED` ou `UNAVAILABLE`;
- motivo exato da rejeição;
- liquidez, volume, market cap, buy pressure e score analítico disponíveis naquele momento.

A retenção é limitada por dias e quantidade de linhas. O padrão cobre todos os candidatos de um ciclo normal (até 1.000 decisões por ciclo) e limita o histórico a 10.000 decisões/14 dias.

## Funil

O relatório agrega analisados, aprovados, rejeitados e indisponíveis, motivos de rejeição e taxa de aprovação por rede.

```sh
python main.py scanner-intelligence --hours 24
python main.py scanner-intelligence --hours 24 --chain bsc
python main.py scanner-decisions --hours 24 --decision rejected --limit 30
```

## Segurança

Scanner Intelligence é observacional. Ele não muda automaticamente:

- filtros;
- score final;
- GoPlus;
- frequência por plano;
- pagamentos;
- wallets;
- providers/chaves.

Daniel AI pode explicar gargalos e sugerir estudos, mas continua sem autoridade para editar o CSM.
