# CSM V16.3 — Signal Lifecycle

A V16.3 fecha o ciclo operacional do sinal sem criar um segundo scanner pesado. Ela reaproveita o **Performance Ledger** e adiciona uma máquina de estados pós-sinal.

## Estados

- `ACTIVE` — sinal em acompanhamento.
- `TP1`, `TP2`, `TP3` — marcos de take profit atingidos.
- `DETERIORATING` — risco crescente por deterioração de liquidez, pressão compradora, momentum, volume ou score observado.
- `STOPPED` — stop atingido e ciclo encerrado.
- `EXPIRED` — janela máxima de acompanhamento encerrada.

Um salto direto de preço acima do TP3 registra também TP1 e TP2 para não perder marcos intermediários. TP3 e STOP encerram novas consultas do ciclo.

## Frequência adaptativa

A consulta pós-sinal não acontece em frequência fixa para todos os ativos. O intervalo depende da idade/estado do sinal e diminui quando há deterioração. Isso reduz consumo dos providers e trabalha junto com o Provider Resilience da V16.1.

Padrões configuráveis: 5 min para sinal recente/deteriorando, 10 min ativo, 15 min estável e 30 min antigo.

## Deterioração

A evidência pode considerar, quando disponível:

- queda de liquidez;
- queda ou nível baixo de buyer pressure;
- queda de score observado;
- colapso de volume;
- momentum de 1h negativo.

A deterioração não muda o score original nem encerra automaticamente o sinal. Ela cria evidência operacional e aumenta a frequência de observação.

## Alertas

Somente transições materiais são elegíveis para alerta: TP1/TP2/TP3, STOP, DETERIORATION, RECOVERED e EXPIRED. Os eventos são deduplicados e respeitam cooldown.

## Segurança

A V16.3 não altera filtros de entrada, GoPlus, preço de entrada, score original, planos, pagamentos, wallets ou chaves. O schema principal permanece 680 e as extensões são aditivas.
