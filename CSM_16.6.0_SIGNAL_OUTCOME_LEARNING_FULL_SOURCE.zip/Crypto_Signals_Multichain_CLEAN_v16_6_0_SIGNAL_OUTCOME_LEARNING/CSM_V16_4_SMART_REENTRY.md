# CSM V16.4 — Smart Reentry

A V16.4 substitui o cooldown único de sinais por uma política de reentrada por plano, sem criar um atalho em torno do scanner.

## Regras comerciais

- Free: 24 horas.
- Plus: 12 horas.
- Premium: 6 horas.
- O ativo só pode voltar a ser entregue se foi reencontrado pelo scanner e passou novamente pelos filtros atuais.
- Reentrada não consome um slot quando está bloqueada por cooldown ou por ausência de melhora material.

## Revalidação após outcome crítico

Quando o último lifecycle do ativo está em `STOPPED`, `DETERIORATING` ou `TP3`, o fim do cooldown não é suficiente. A V16.4 exige pelo menos uma evidência material nova, entre:

- aumento de score observado;
- aumento de liquidez;
- melhora de buyer pressure;
- aceleração de volume;
- melhora de momentum 1h.

Os thresholds são configuráveis, mas nunca aprovam um token que o scanner atual rejeitou.

## Auditoria

A tabela aditiva `signal_reentry_history` registra somente entregas confirmadas no Telegram e guarda plano, cooldown, sinal pai, lifecycle anterior e evidências da decisão. O Performance Ledger continua sendo a fonte dos outcomes.

## Comando

```sh
python main.py smart-reentry --hours 24
```

A camada não altera score, GoPlus, filtros, pagamentos, wallets, chaves ou o schema principal 680.
