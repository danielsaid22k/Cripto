# CSM 16.5.3 — Runtime Resilience

## Objetivo

A 16.5.3 reforça a disponibilidade operacional do CSM sem alterar scoring,
filtros de sinais, regras comerciais, Telegram, Discord, Setup, chains ou o
estado persistente.

## Correção da degradação exibida no Retool

Na 16.5.2, o snapshot do runtime usado pelo Retool considerava a presença das
sessões `tmux` `csm-bot` e `csm-api` como principal evidência de atividade.
Isso podia exibir `degraded` / `Processo ativo: Não` mesmo quando o runtime do
bot ainda estava saudável por lease + sessão + heartbeat.

A 16.5.3 passa a usar como autoridade primária do bot o contrato já existente
do runtime v10:

- lease UDP responsiva;
- sessão consistente;
- heartbeat recente;
- PID apenas como diagnóstico/fallback negativo.

`tmux` continua sendo observado como camada de orquestração e fallback, mas não
é mais a única fonte de liveness.

A SaaS API é validada pelo endpoint local `/healthz`, em vez de apenas pela
existência da sessão `tmux`.

O snapshot do runtime também fornece `health_score` operacional de 0 a 100 e a
release comercial atual para o painel.

## Runtime Resilience Manager

Novo módulo: `csm/runtime_resilience.py`.

Componentes monitorados:

- bot;
- SaaS API;
- Supervisor 8790;
- Admin Bridge 8765;
- ngrok através da API local 4040;
- Config Auditor.

Estados:

- `HEALTHY`;
- `DEGRADED`;
- `DOWN`;
- `NOT_CONFIGURED`;
- visão consolidada `HEALTHY`, `DEGRADED` ou `FAILED`.

## Recuperação controlada

O watchdog exige duas falhas consecutivas antes de tentar recuperar um
componente. Cada componente possui cooldown e proteção contra restart storm:

- mínimo de 2 confirmações de falha;
- cooldown de 60 segundos;
- no máximo 3 tentativas em 15 minutos.

A recuperação usa mecanismos já existentes quando disponíveis:

- Supervisor: sessão `csm-supervisor` com `~/csm-supervisor/api.py`;
- bot/API: `POST /runtime/start` do Supervisor;
- Admin Bridge: `python main.py retool-admin-start`;
- ngrok: script persistente `~/.termux/boot/95-csm-ngrok-admin.sh`;
- Config Auditor: `~/csm-config-audit/config_audit.py` em `csm-config-audit`.

Nenhum segredo é registrado, nenhum `config.env` é reescrito e nenhuma
configuração é restaurada automaticamente.

## Novos comandos

```bash
python main.py runtime-resilience-status
python main.py runtime-resilience-once --no-recover
python main.py runtime-resilience-once
python main.py runtime-resilience-watch --interval 60
```

## Persistência Termux

O script `install_runtime_resilience_termux.sh` instala apenas o watcher da
16.5.3 em `~/.termux/boot/96-csm-runtime-resilience.sh` e inicia a sessão tmux
`csm-runtime-resilience`.

A instalação do watcher é explícita e separada da atualização comercial.

## Compatibilidade

- Compat runtime: `8.3.1-ashell-single-runtime` preservado.
- Daniel AI: `1.3.1` preservado.
- Estado/banco/configuração persistente não fazem parte do payload de update.
