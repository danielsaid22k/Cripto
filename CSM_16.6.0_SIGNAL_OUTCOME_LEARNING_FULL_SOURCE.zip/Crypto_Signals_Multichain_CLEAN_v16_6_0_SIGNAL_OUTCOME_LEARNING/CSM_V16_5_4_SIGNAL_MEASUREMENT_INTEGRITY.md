# CSM 16.5.4 — Signal Measurement Integrity

Atualização aditiva sobre a 16.5.3 Runtime Resilience.

## Escopo
- NÃO altera aprovação, scoring, filtros, cotas ou entrega LIVE.
- NÃO altera Telegram, pagamentos, Retool controls, ProjectLeader, providers ou Runtime Resilience.
- Corrige a integridade das métricas usadas para estudar assertividade.

## Correções
1. Horizonte 5m agora aceita somente observação em/apos 300s; baseline de entrada nunca conta como 5m.
2. Shadow continua elegível mesmo se o lifecycle encerrar STOP/TP3 antes de 5m.
3. Captura dedicada Shadow grava evidence-only e não muda lifecycle/status/TP/STOP.
4. Telemetria Shadow usa snapshot direto do ledger recente, mostrando waiting/due/late de forma auditável.
5. Observações passam a ter `observation_kind` (`live`/`shadow`) de forma aditiva.

## Critério para futura promoção
Nenhum filtro LIVE é promovido nesta release. Primeiro acumular 20-50 confirmações válidas e comparar a coorte com o baseline.
