# CSM 16.5.5 — Post-Update Finalizer

## Objetivo

Reduzir o pós-instalação a uma única ação segura, preservando aprovação humana do ProjectLeader e todos os controles existentes.

## Novo comando

`python main.py post-update`

Executa, nesta ordem:

1. migrate
2. db-check
3. selftest
4. release-check
5. version
6. Config Integrity preflight
7. restart do Runtime via Supervisor
8. validação Bot + SaaS API
9. restart do Admin Bridge

O fluxo é fail-closed: se qualquer validação anterior aos restarts falhar, Runtime e Admin Bridge permanecem sem restart para preservar a superfície de diagnóstico.

## Retool

Novos endpoints protegidos pelo mesmo Bearer token administrativo:

- `POST /api/update/finalize`
- `GET /api/update/finalize/status`

O POST inicia o finalizador em processo separado e retorna HTTP 202. Isso permite que o próprio Admin Bridge seja reiniciado ao final sem quebrar o fluxo iniciado pelo Retool.

Na primeira instalação da 16.5.5, execute `python main.py post-update` uma vez pelo Termux, pois o Admin Bridge 16.5.4 ainda não conhece o novo endpoint até ser reiniciado. A partir daí, futuras atualizações podem usar o botão **Finalizar atualização** do Retool.

## Segurança e compatibilidade

- nenhuma alteração de scanner, filtros, scoring ou entrega LIVE;
- nenhuma alteração em Telegram/Discord;
- nenhuma alteração em pagamentos/Asaas;
- nenhuma alteração em chains/providers;
- Runtime Resilience 16.5.3 preservado;
- Signal Measurement Integrity 16.5.4 preservada;
- Config Integrity Guard continua obrigatório antes do restart;
- comandos individuais migrate/db-check/selftest/release-check continuam disponíveis;
- lock impede finalizações concorrentes;
- relatório persistente em `State/post_update/last_report.json`;
- logs limitados e sem registro de segredos.
