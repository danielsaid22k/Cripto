# CSM 16.5.6 — Post-Update Hotfix

Hotfix operacional da 16.5.5. Não altera scanner, filtros, scoring, sinais, Telegram, Discord, chains, pagamentos, Daniel AI, Signal Measurement Integrity ou Runtime Resilience.

## Correções

- `post-update` deixa de chamar a migração legada que pode restaurar automaticamente backup anterior.
- O Finalizer cria backup de segurança e faz somente upgrade idempotente **in-place** do banco persistente atual.
- Nenhum backup anterior é restaurado automaticamente pelo Finalizer.
- Após restart, o Finalizer aguarda Bot + SaaS API `/healthz` ficarem saudáveis, com retry por até 60 segundos.
- Evita falso `FAILED` enquanto a porta 8787 ainda está inicializando.
- Mantém fail-closed: falha real continua bloqueando a finalização.

## Segurança

- Aprovação humana do ProjectLeader preservada.
- Configuração persistente não é reescrita/restaurada automaticamente.
- Sem alteração de schema planejada nesta release.
