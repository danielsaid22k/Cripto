# CSM V16.5.7 — Provider Coverage & Stability

Base: **16.5.6-post-update-hotfix**  
Runtime: **16.5.7-retool-admin-speechify**  
Compat runtime: **8.3.1-ashell-single-runtime**  
Daniel AI: **1.3.1**

## Objetivo

Aumentar cobertura de descoberta/market fallback sem reduzir filtros de qualidade e reduzir o flapping do Birdeye quando a cota de Compute Units já está esgotada.

## DexPaprika adicional

- Fonte pública adicional habilitada por padrão.
- URL padrão: `https://api.dexpaprika.com`.
- API key opcional; modo keyless funciona sem configuração adicional.
- Discovery aditivo em Plus/Premium, com uma rede rotativa por ciclo por padrão.
- Endpoint de discovery: `/networks/{network}/tokens/search`.
- Market fallback: `/networks/{network}/tokens/{token_address}` apenas depois das fontes de mercado existentes falharem.
- Normaliza preço, liquidez, FDV, volume, buys, sells e transações para o formato já usado pelo CSM.
- Se créditos/quota DexPaprika esgotarem (`HTTP 402`), somente DexPaprika entra em cooldown; os demais providers continuam.

## Birdeye Compute Units Guard

- `Compute Units usage limit exceeded` deixa de provocar tentativas repetidas em janelas curtas.
- Cooldown padrão configurável: `21600` segundos (6h).
- DexScreener, GeckoTerminal, CoinGecko e DexPaprika permanecem disponíveis durante esse cooldown.

## Novas configurações

```text
BIRDEYE_QUOTA_COOLDOWN_SECONDS=21600
DEXPAPRIKA_ENABLED=true
DEXPAPRIKA_BASE_URL=https://api.dexpaprika.com
DEXPAPRIKA_API_KEY=
DEXPAPRIKA_CHAIN_SOURCES=1
DEXPAPRIKA_DISCOVERY_LIMIT=30
DEXPAPRIKA_MARKET_FALLBACK=true
DEXPAPRIKA_QUOTA_COOLDOWN_SECONDS=21600
```

Esses campos possuem defaults seguros no código. A atualização não reescreve o `config.env` persistente.

## Segurança e compatibilidade

Não foram alterados:

- filtros LIVE;
- score/threshold de aprovação;
- cooldowns/reentrada de sinais;
- Telegram/Discord;
- pagamentos;
- banco/schema;
- Runtime Resilience;
- Post-Update Finalizer;
- ProjectLeader;
- Daniel AI;
- Signal Measurement Integrity/Shadow.

## Validação

- `pytest --collect-only`: **493 testes coletados**.
- regressão focada provider/scanner/runtime/update: **95/95 PASS**.
- `compileall`: **PASS**.
- `selftest`: **PASS**.
- `release-check`: **PASS**.

A suíte monolítica completa excede a janela de execução do sandbox; por isso o gate desta entrega registra os 95 testes focados mais `selftest`/`release-check`, sem afirmar 493/493 executados.
