# CSM V16.5.8 — Provider & Telegram Integrity

Release incremental sobre a V16.5.7, sem alteração dos filtros LIVE, scoring ou schema do banco.

## Correções de Telegram
- Separa HTTP 429 real de destinatário inválido/inalcançável.
- Preserva `retry_after` retornado pela API do Telegram e aplica guard cooperativo por chat.
- Destinatários `chat not found` / bot bloqueado podem ser suprimidos automaticamente da entrega, evitando falso alerta de quota.
- O startup não converte mais `TELEGRAM_CHAT_ID` configurado em assinante Free.
- Restaura `/admin_block` e `/admin_unblock` no router Phantom V10.

## Integridade de providers e Observability
- Consolida incidentes de quota/rate-limit por família de provider, evitando penalidade duplicada (`limit` + `health`).
- Resolve incidentes provider stale após a janela configurada.
- Introduz janela estável antes de notificação de recuperação, reduzindo flapping de alerta.
- GeckoTerminal HTTP 429 usa cooldown base prolongado e adaptativo.
- Cooldowns de providers passam a ser persistidos em `STATE_DIR/runtime/v10/provider_cooldowns.json`.
- Mantém Birdeye disponível quando saudável e preserva fallback público quando a quota estiver exaurida.

## Cobertura adicional
- Mantém DexPaprika keyless da V16.5.7.
- Adiciona Honeypot.is keyless como fallback/advisory de segurança EVM para Ethereum, BSC e Base.
- `HONEYPOT_ENFORCE_BLOCKS=false` por padrão: não altera decisão LIVE ou score.

## Caminho fixo da instalação
O `post-update` cria/atualiza com segurança:

```bash
~/CSM_CURRENT
```

Assim, após a atualização, o comando operacional passa a ser:

```bash
cd ~/CSM_CURRENT
```

A pasta física atual não é renomeada, preservando Termux Boot, Supervisor, tmux, Retool, Admin Bridge/ngrok e demais referências existentes.

## Compatibilidade preservada
- Telegram e Discord existentes.
- Retool/Setup Center/Update Center.
- ProjectLeader e aprovação humana.
- Runtime Resilience, Supervisor, Admin Bridge/ngrok.
- Estado persistente, banco schema 680, assinaturas e pagamentos.
- Daniel AI V1.3.1.
- DexScreener, GeckoTerminal, Birdeye, CoinGecko Onchain, GoPlus e DexPaprika.
