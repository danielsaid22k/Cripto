# CSM V16.5.9.1 — Provider Quality Router Hotfix

Hotfix regressão-zero da V16.5.9. Corrige um `return` inadvertidamente comentado em `ProviderQualityRouter._utility()`, que fazia a função retornar `None` quando já existia histórico de cobertura e causava `TypeError: unsupported operand type(s) for *: 'NoneType' and 'float'`.

- Nenhum filtro LIVE alterado.
- Nenhum score alterado.
- Nenhum schema alterado.
- Telegram, Retool, Daniel AI e providers preservados.
- Mantém as 10 melhorias da V16.5.9.
- Inclui teste de regressão reproduzindo exatamente o erro de produção.
