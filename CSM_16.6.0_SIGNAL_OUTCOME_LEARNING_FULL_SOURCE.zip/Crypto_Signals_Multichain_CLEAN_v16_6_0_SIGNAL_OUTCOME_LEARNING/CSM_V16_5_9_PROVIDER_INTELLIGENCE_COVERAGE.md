# CSM V16.5.9 — Provider Intelligence & Coverage

Release incremental sobre a V16.5.8. Mantém filtros LIVE, scoring, schema 680, Telegram/Discord, Retool, ProjectLeader, Runtime Resilience, pagamentos, Daniel AI e estado persistente intactos.

## Pacote de 10 melhorias

1. **Adaptive GeckoTerminal Backoff**
   - HTTP 429 usa `Retry-After` quando fornecido pelo servidor.
   - Sem `Retry-After`, progride 5m → 10m → 20m → máximo 30m.
   - Cooldown continua persistente entre restarts.

2. **Birdeye Credential Change Probe**
   - Detecta troca da API key por fingerprint SHA-256; a chave nunca é gravada em log/estado de probe.
   - Após salvar uma chave diferente no Setup, executa uma única chamada leve do New Listing (`limit=1`).
   - Probe não cria candidato, não gera sinal e não envia Telegram.
   - Chave válida libera imediatamente o cooldown antigo; quota/invalidez mantém Birdeye isolado e fallbacks ativos.

3. **Failover inteligente por rede e função**
   - Discovery e market lookup deixam de depender de prioridade estática única.
   - A ordem considera saúde atual e utilidade recente do provider.

4. **Recovery Probe leve durante cooldown**
   - Providers elegíveis podem receber probe diagnóstico de baixa frequência enquanto a rota normal permanece em cooldown.
   - Recuperação comprovada pode liberar o provider antes do teto do cooldown.
   - Probe é `diagnostic_only` e não contamina scanner, sinais ou saúde operacional.

5. **Saúde atual separada do histórico de incidentes**
   - Incidentes antigos permanecem auditáveis.
   - O health score atual só penaliza incidentes provider vistos na janela operacional recente.
   - Relatório distingue `current_open_incidents`, `historical_open_incidents`, `effective_open_incidents` e `raw_open_incidents`.

6. **Cobertura em tempo real por rede/provider**
   - Novo relatório persistente de ciclos, candidatos, analisados, aprovados e utilidade por provider/rede.
   - Comando: `python main.py provider-coverage --minutes 60`.

7. **Coverage Guard**
   - Identifica redes com cobertura insuficiente após histórico mínimo.
   - Pode direcionar uma fonte pública adicional (DexPaprika) para a rede deficitária sem alterar filtros/scoring.

8. **Diagnóstico de rejeições por rede/provider**
   - Agrupa rejeições por chain, provider, motivo, liquidez/volume/score médios.
   - Comando: `python main.py scanner-provider-diagnostics --hours 24 --chain bsc`.

9. **Provider Quality Router**
   - Prioriza providers por saúde recente + utilidade real de cobertura, com preferência específica por função.
   - Probes diagnósticos continuam isolados e executados antes da rota normal apenas quando necessários.

10. **Opportunity Coverage Watchdog**
    - Detecta queda de fluxo/cobertura por rede após histórico mínimo.
    - Aciona cobertura alternativa sem fabricar sinais, sem afrouxar filtros e sem spam de Telegram por padrão.

## Compatibilidade e segurança

- Birdeye permanece opcional e não é removido.
- DexPaprika keyless e Honeypot.is keyless da V16.5.8 permanecem ativos.
- DexScreener, GeckoTerminal, CoinGecko Onchain, GoPlus e demais providers existentes permanecem disponíveis.
- `~/CSM_CURRENT` continua sendo o caminho operacional fixo.
- Nenhuma alteração de `SCAN_MIN_*`, `SCAN_MAX_*`, score mínimo, lógica de TP/SL ou Smart Reentry.
- Nenhuma migração de schema de banco.
- Nenhuma restauração automática de configuração antiga.
- Aprovação humana do ProjectLeader continua obrigatória.

## Novos comandos de diagnóstico

```bash
python main.py provider-intelligence-status
python main.py provider-coverage --minutes 60
python main.py scanner-provider-diagnostics --hours 24 --chain bsc
python main.py birdeye-check
```
