# CSM V16.6.0 — Signal Outcome Learning

Camada incremental sobre a V16.5.9.1 para aprender com o resultado real dos sinais entregues, sem alterar decisões LIVE.

## O que aprende
- rede;
- provider e combinação rede/provider;
- faixa de score;
- faixa de liquidez;
- faixa de volume;
- plano de entrega;
- win/TP1/TP2/stop, retorno atual, máximo retorno e drawdown;
- horizontes já existentes no Performance Ledger.

## Proteção contra amostra pequena
Usa suavização Bayesiana e exige amostra mínima antes de classificar segmentos como `PROMISING`, `CAUTION` ou `OBSERVE`.

## Segurança da fase 1
- modo fixo: `EVIDENCE_ONLY`;
- não altera `SCAN_MIN_*`/`SCAN_MAX_*`;
- não altera score;
- não altera Telegram/entrega;
- não existe caminho de auto-apply nesta versão;
- futura otimização automática exigirá nova versão e aprovação humana.

## Automação local
A cada ~30 minutos, após um ciclo do scanner, gera um snapshot local usando somente o SQLite/Performance Ledger. Não cria novas chamadas HTTPS.

## Comandos
```bash
python main.py signal-learning-status
python main.py signal-learning-run --days 30
python main.py signal-learning-report --days 30
python main.py signal-learning-recommendations --days 30 --limit 20
```
