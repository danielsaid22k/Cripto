# V16 — Customer Portal & Enterprise Dashboard

## Purpose

V16 turns the existing read-only SaaS API into a customer-facing product surface without changing scanner/security authority. The scanner, GoPlus gate, Telegram delivery and V15 Distribution remain independent of the portal.

## Customer Portal

`GET /portal` serves a dependency-free responsive dashboard from the same SaaS API process.

The browser asks for a tenant API key and sends it only in the HTTP `Authorization: Bearer ...` header. The key is stored in browser `sessionStorage`, not in URL query parameters, cookies, HTML or server logs.

The portal shows, according to entitlement:

- tenant / subscription status;
- API usage and quotas;
- latest delivered signals;
- observed performance;
- Proof of Performance status;
- Enterprise operations summary when permitted.

## Entitlements

Plans:

- `free`: portal, status, branding, signals;
- `plus`: Free + providers, performance and proofs;
- `premium`: Plus + security, On-Chain, Reputation, Observability and Distribution;
- `enterprise`: Premium + Enterprise consolidated dashboard.

The entitlement state is separate from market score and cannot increase `final_score`, bypass GoPlus or alter signal filtering.

Existing tenants created before V16 receive the migration default `enterprise` to preserve their already-working API capabilities. New tenants created in V16 default to `free` unless a plan is explicitly selected.

## Linked user / billing bridge

A SaaS tenant can be linked to an existing Telegram user ID:

```sh
python main.py tenant-link-user --tenant crypto-signals --user-id 123456789
```

When the local plan changes through the existing commercial/payment flow, V16 performs a fail-open entitlement synchronization. A portal-side error can never block payment activation or Telegram delivery.

Manual controls:

```sh
python main.py entitlement-status --tenant crypto-signals
python main.py entitlement-set --tenant crypto-signals --plan premium --status ACTIVE
python main.py entitlement-sync --tenant crypto-signals
```

## API additions

- `GET /portal`
- `GET /api/v1/portal/overview`
- `GET /api/v1/portal/me`
- `GET /api/v1/portal/usage`
- `GET /api/v1/portal/subscription`
- `GET /api/v1/enterprise/overview` (Enterprise entitlement)

Existing V11.5–V15 endpoints remain available but are now feature-gated according to the tenant entitlement.

## Database

Schema 680, additive migration.

New/extended state:

- `saas_tenants.entitlement_plan`
- `saas_tenants.entitlement_status`
- `saas_tenants.entitlement_expires_at`
- `saas_tenants.entitlement_grace_until`
- `saas_tenants.linked_user_id`
- append-only `entitlement_events`

No production secrets are added to SQLite.

## Mobile

The portal/SaaS API is intended for Termux/Android or Linux/VPS continuous operation. The a-Shell-compatible bot remains unchanged and can still use all core scanner features without running the portal service.
