# Daniel AI V0.1 integrado ao Crypto Signals Multichain V16

## Objetivo

Adicionar uma camada inteligente isolada, preservando o scanner, providers, planos,
pagamentos, Telegram, banco principal e estado LTS do CSM.

## Modo inicial sem custo externo

- `DANIEL_AI_ENABLED=true`
- `OPENAI_ENABLED=false`
- nenhuma chamada à OpenAI é realizada;
- `OPENAI_API_KEY` pode permanecer vazia;
- o CSM continua funcionando mesmo se o Daniel AI for desativado.

## O que funciona nesta V0.1

- núcleo local do Daniel AI;
- personalidade/regras próprias;
- memória e histórico persistentes em banco separado;
- ferramentas read-only sobre o banco do CSM;
- status do sistema, providers, scanner, sinais, performance e usuários/planos;
- `/daniel` e `/ai` no Telegram, inicialmente restritos ao administrador;
- integração ao painel administrativo e API local já autenticada do CSM;
- leitura segura de `.txt`, `.md`, `.json`, `.csv` e `.log` em pasta dedicada;
- scaffold OpenAI presente, porém incapaz de chamar a rede nesta release.

## Segurança

O Daniel AI abre `signals.db` em modo SQLite read-only para consultas. Ele não recebe
ferramentas para alterar cobranças, chaves, carteiras, filtros, limites ou transações.
O histórico próprio fica em `Crypto_Signals_Multichain_State/daniel_ai/daniel_ai.db`.

## API local

Com o Admin Web ativo, ficam disponíveis:

- `GET /api/daniel-ai`
- `POST /api/daniel-ai/ask`

A autenticação é a mesma do Admin Web (`ADMIN_WEB_TOKEN` quando configurado).

Exemplo JSON do POST:

```json
{"question":"melhores sinais de 1 dia","user_id":0}
```

## Futuro

A integração real com OpenAI será adicionada em uma versão posterior, com limites de
uso e orçamento. Voz/imagem também permanecem fora da V0.1.
