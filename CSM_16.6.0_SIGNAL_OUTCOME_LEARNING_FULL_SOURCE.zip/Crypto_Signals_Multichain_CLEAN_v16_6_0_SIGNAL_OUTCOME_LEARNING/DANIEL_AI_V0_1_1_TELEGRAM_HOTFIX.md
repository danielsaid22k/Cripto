# Daniel AI V0.1.1 — Telegram runtime hotfix

- Corrige o roteamento de `/daniel` e `/ai` no runtime realmente iniciado por `python main.py bot` (`phantom_v10.app.PhantomApp`).
- Mantém OpenAI desligada por padrão.
- Mantém o CSM V16, banco, scanner, planos e boot inalterados.
- Mantém Daniel AI admin-only por padrão.
- Comandos Daniel são tratados antes do estado de cobrança pendente, evitando serem confundidos com CPF/CNPJ.
