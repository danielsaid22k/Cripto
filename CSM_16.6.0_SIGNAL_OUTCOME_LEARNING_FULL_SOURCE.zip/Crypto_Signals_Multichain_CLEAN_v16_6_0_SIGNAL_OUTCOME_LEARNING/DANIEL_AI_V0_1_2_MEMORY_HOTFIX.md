# Daniel AI V0.1.2 — Memory Hotfix

Hotfix incremental sobre V0.1.1.

- Corrige comandos naturais de memória explícita no runtime local.
- `/daniel lembre que meu teste favorito é CATE` grava em `daniel_ai.db`.
- `/daniel qual é meu teste favorito?` recupera a memória do mesmo usuário.
- Lista memórias e permite apagar uma memória específica.
- Isolamento por `user_id` preservado.
- Histórico de conversas continua separado das memórias explícitas.
- `OPENAI_ENABLED=false` permanece obrigatório por padrão e nenhuma chamada paga é feita.
- Núcleo CSM V16 e schema 680 não foram alterados.
