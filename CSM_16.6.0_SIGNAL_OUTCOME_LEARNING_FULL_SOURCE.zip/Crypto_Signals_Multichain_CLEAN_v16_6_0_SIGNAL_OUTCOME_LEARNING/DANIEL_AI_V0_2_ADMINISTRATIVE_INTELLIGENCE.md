# Daniel AI V0.2.0 — Administrative Intelligence

Evolução incremental sobre a V0.1.2 estável do Daniel AI, preservando o núcleo
Crypto Signals Multichain V16.0.0 e o schema 680.

## Objetivo

Transformar o Daniel AI local em um assistente administrativo mais útil sem
introduzir modelo pago, dependência externa ou autoridade de escrita sobre o CSM.

## Novas capacidades

- `/daniel analise CATE`
  - localiza o sinal no ledger;
  - mostra score, liquidez, volume, market cap e variação;
  - calcula pressão compradora a partir de compras/vendas persistidas;
  - inclui GoPlus e on-chain quando registrados;
  - inclui performance pós-sinal e razões de aprovação gravadas.

- `/daniel por que CATE recebeu esse score?`
  - explica apenas os componentes e razões que existem no banco;
  - não inventa decomposição ponto a ponto quando ela não foi persistida.

- `/daniel compare CATE e GORE`
  - comparação factual de score, liquidez, volume, variação e pressão compradora;
  - não escolhe automaticamente um ativo para compra.

- `/daniel diagnóstico do scanner`
  - agrega ciclos recentes, erros, observabilidade, saúde de providers e incidentes;
  - funciona em modo somente leitura.

- `/daniel por que há poucos sinais na BSC?`
  - mostra os sinais efetivamente persistidos para a rede e os indicadores gerais;
  - deixa explícito que o schema atual não persiste motivos de rejeição por rede,
    evitando afirmar uma causa sem evidência.

- `/daniel últimos erros`
  - consulta incidentes operacionais persistidos.

- `/daniel histórico da conversa`
  - consulta o histórico persistente do próprio Daniel AI por usuário.

## Segurança

- `OPENAI_ENABLED=false` continua sendo o padrão.
- Nenhuma nova chamada paga foi adicionada.
- Ferramentas do CSM continuam abrindo `signals.db` em SQLite `mode=ro`.
- Nenhuma ferramenta nova altera pagamentos, usuários, sinais, carteiras, chaves,
  filtros, limites ou configurações críticas.
- O banco do Daniel AI continua separado em
  `Crypto_Signals_Multichain_State/daniel_ai/daniel_ai.db`.

## Compatibilidade

- CSM: `16.0.0-customer-portal-enterprise` preservado.
- Schema principal: `680` preservado.
- Telegram ativo: `phantom_v10/router.py` preserva `/daniel` e `/ai` admin-only.
- Memórias V0.1.2 permanecem no mesmo banco persistente e sobrevivem à atualização.
