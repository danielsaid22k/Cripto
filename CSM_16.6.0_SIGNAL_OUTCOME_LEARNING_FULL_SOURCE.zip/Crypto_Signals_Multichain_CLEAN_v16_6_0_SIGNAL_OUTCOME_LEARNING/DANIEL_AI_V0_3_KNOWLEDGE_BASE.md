# Daniel AI V0.3.0 — Local Knowledge Base

Evolução incremental sobre a V0.2.0 estável, preservando o núcleo Crypto Signals
Multichain V16.0.0, o schema 680 e o estado persistente existente.

## Objetivo

Corrigir os dois pontos encontrados nos testes reais da V0.2.0 e acrescentar
leitura/indexação local de documentos, sem API paga e sem dar autoridade de escrita
sobre o CSM ao Daniel AI.

## Correções incorporadas

- `/daniel histórico da conversa`
  - remove tags HTML antigas antes de montar o histórico;
  - não exibe `&lt;b&gt;` ou outras tags literais;
  - compacta respostas longas para manter o Telegram legível.

- `/daniel últimos erros`
  - possui resposta dedicada;
  - lista incidentes em ordem cronológica por `last_seen`;
  - mostra horário, severidade, componente, status e ocorrências;
  - não cai mais no diagnóstico administrativo geral.

## Base de conhecimento local

A pasta padrão é:

`Crypto_Signals_Multichain_State/daniel_ai/documents`

Formatos suportados:

- `.txt`
- `.md`
- `.json`
- `.csv`
- `.log`
- `.docx`
- `.pdf`

O índice é gravado somente no banco próprio do Daniel AI:

`Crypto_Signals_Multichain_State/daniel_ai/daniel_ai.db`

Novas tabelas são criadas automaticamente no banco do Daniel AI e não alteram o
`signals.db` do CSM.

## Comandos

- `/daniel documentos`
  - lista arquivos autorizados e sincroniza o índice incrementalmente.

- `/daniel leia "manual.pdf"`
  - lê um documento específico da pasta autorizada.

- `/daniel procure nos documentos liquidez`
  - busca trechos relevantes no índice local.

- `/daniel o que os documentos dizem sobre GeckoTerminal`
  - busca por conteúdo em linguagem natural simples.

- `/daniel reindexe documentos`
  - força sincronização do índice e remove referências a arquivos apagados.

## Segurança

- `OPENAI_ENABLED=false` continua sendo o padrão.
- `DANIEL_AI_WEB_ENABLED=false` continua sendo o padrão.
- A busca documental é 100% local.
- O caminho de documentos é confinado à pasta autorizada; `../` é bloqueado.
- Arquivos possuem limite configurável de tamanho.
- O banco principal do CSM continua aberto em `mode=ro` pelas ferramentas Daniel.
- Pagamentos, usuários, sinais, chaves, carteiras, filtros e limites não são alterados.

## Configuração opcional

```text
DANIEL_AI_DOCUMENTS_ENABLED=true
DANIEL_AI_DOCUMENTS_DIR=
DANIEL_AI_DOCUMENTS_MAX_FILE_MB=8
DANIEL_AI_KNOWLEDGE_MAX_RESULTS=5
OPENAI_ENABLED=false
```

Quando `DANIEL_AI_DOCUMENTS_DIR` fica vazio, é usada a pasta persistente padrão.

## Compatibilidade

- CSM: `16.0.0-customer-portal-enterprise` preservado.
- Schema principal: `680` preservado.
- Telegram: `/daniel` e `/ai` continuam admin-only.
- Memórias e histórico das versões anteriores permanecem no mesmo banco.
- A V0.2.0 pode ser mantida em pasta separada para rollback.
