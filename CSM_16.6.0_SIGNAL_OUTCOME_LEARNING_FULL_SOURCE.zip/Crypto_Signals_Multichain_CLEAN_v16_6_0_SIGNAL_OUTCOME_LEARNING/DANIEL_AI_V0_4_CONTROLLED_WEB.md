# Daniel AI V0.4.0 — Controlled Web Research

## Objetivo

Adicionar acesso externo controlado sem transformar a internet em dependência do CSM e sem ativar OpenAI.

## Princípios

- `OPENAI_ENABLED=false` continua padrão.
- `DANIEL_AI_WEB_ENABLED=false` continua padrão (opt-in).
- Scanner, Telegram operacional, pagamentos, banco principal e providers não dependem da web do Daniel.
- Ferramentas do CSM continuam read-only.
- A web do Daniel só é usada quando o administrador pede explicitamente.

## Capacidades

- pesquisa pública: `pesquise na internet ...`;
- leitura textual de URL pública: `abra https://...`;
- fontes e URLs exibidas na resposta;
- auditoria local das chamadas web no banco isolado do Daniel AI.

## Segurança

O módulo `daniel_ai/web.py`:

1. aceita somente `http://` e `https://`;
2. rejeita localhost, `.local`, loopback, link-local, multicast, redes privadas/reservadas;
3. valida redirecionamentos;
4. limita timeout e bytes lidos;
5. bloqueia conteúdo não textual;
6. não executa JavaScript;
7. não escreve no `signals.db`.

## Busca

A V0.4 usa uma busca web HTML pública em modo best-effort. Se o provedor de busca estiver indisponível ou mudar o HTML, o Daniel retorna uma falha clara sem afetar o CSM. Leitura direta de URLs públicas continua separada.

## Configuração

- `DANIEL_AI_WEB_ENABLED=false`
- `DANIEL_AI_WEB_TIMEOUT_SECONDS=8`
- `DANIEL_AI_WEB_MAX_BYTES=700000`
- `DANIEL_AI_WEB_MAX_RESULTS=5`

Ativação simples: `python main.py daniel-web-on` e reinício do CSM.

## Custos

O recurso não usa a API OpenAI. Acesso à internet pode consumir apenas dados da conexão do dispositivo/servidor; não há cobrança por chamada OpenAI enquanto `OPENAI_ENABLED=false`.
