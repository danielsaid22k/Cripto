# Daniel AI V0.5.0 — Web Reliability + Admin Panel

## Objetivo

Consolidar a pesquisa web da V0.4 e avançar para a próxima etapa: um painel web dedicado ao Daniel AI, mantendo OpenAI desligada e o CSM independente.

## Correção da busca web

A descoberta deixa de depender de um único HTML. A V0.5 usa fallbacks públicos, sem chave obrigatória:

1. Bing RSS;
2. DuckDuckGo HTML;
3. Wikipedia OpenSearch;
4. Google News RSS.

Consultas de notícias priorizam Google News. Resultados são deduplicados, URLs passam novamente pela validação de rede pública e a resposta identifica a fonte de descoberta.

A leitura direta de URL pública continua separada e funciona mesmo se todos os mecanismos de descoberta estiverem indisponíveis.

## Painel Daniel AI

O Admin Web passa a ter uma página dedicada em `/daniel-ai` com:

- estado, OpenAI e web;
- contadores de conversas, memórias e documentos;
- caixa de pergunta usando o mesmo motor do Telegram;
- histórico recente;
- memórias locais;
- documentos indexados.

O HTML exibe respostas como texto escapado, sem executar conteúdo retornado pelo Daniel.

## Segurança

- `OPENAI_ENABLED=false` permanece padrão;
- `DANIEL_AI_WEB_ENABLED=false` permanece opt-in;
- painel fora de localhost exige `ADMIN_WEB_TOKEN`;
- ferramentas CSM permanecem read-only;
- nenhum script externo é carregado;
- nenhuma escrita no `signals.db` é feita pelo Daniel AI.

## CLI

- `python main.py daniel-panel-token` cria e persiste um token administrativo;
- `python main.py daniel-panel` inicia o painel usando as configurações do Admin Web;
- `python main.py daniel-panel --host 0.0.0.0` permite acesso remoto somente quando há token.
