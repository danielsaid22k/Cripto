# Daniel AI V0.6.0 — Provider Failover Intelligence

Daniel AI V0.6.0 acompanha a evolução CSM V16.1 e continua local-first, admin-only e com `OPENAI_ENABLED=false`.

## Novidades

- Explica `ONLINE / DEGRADED / COOLDOWN / QUOTA_EXHAUSTED / OFFLINE`.
- Exibe tempo restante de retry/cooldown quando persistido no snapshot ativo.
- Identifica providers saudáveis disponíveis como alternativas de fallback.
- O painel `/daniel-ai` ganhou seção **Provider Resilience** com estado, health, retry e motivo do circuito.
- Diagnóstico administrativo passa a refletir o snapshot gerado pelo runtime ativo, reduzindo risco de health 100/100 obsoleto.

## Exemplos

- `/daniel status dos providers e failover`
- `/daniel geckoterminal cooldown`
- `/daniel qual provider está em cota?`
- `/daniel diagnostico do scanner`

Daniel AI permanece somente leitura sobre o CSM.
