# Daniel AI V0.7.0 — Continuous Learning

V0.7 transforma a memória do Daniel AI em uma base de conhecimento que se atualiza ao longo do tempo, sem treinar pesos de modelo e sem dar autoridade para alterar o CSM.

## Como aprende

- `DANIEL_AI_LEARNING_ENABLED=true` por padrão.
- Perguntas úteis entram na fila de aprendizado.
- Sinais aprovados do CSM podem adicionar até 2 temas por ciclo à fila.
- Há temas-semente sobre Bitcoin ETF, Solana, Ethereum, BNB, memecoins e providers.
- O scheduler executa um tema por intervalo, somente quando as tarefas operacionais prioritárias estão ociosas.
- A pesquisa usa a camada web pública já controlada da V0.5/V0.6. Se a web estiver OFF, o aprendizado aguarda.

## Conhecimento verificável

Cada item guarda:
- tema;
- resumo de evidências públicas;
- quantidade de domínios/fontes distintos;
- confiança calculada de forma conservadora;
- data de aprendizado;
- validade/expiração;
- URLs/fontes de origem;
- origem do tema (seed, conversa, sinal CSM ou comando manual).

O banco principal continua sendo `Crypto_Signals_Multichain_State/daniel_ai/daniel_ai.db`.
Notas legíveis são criadas em `Crypto_Signals_Multichain_State/daniel_ai/learned/`.

## Atualização e esquecimento operacional

Itens vencidos voltam a ficar elegíveis para pesquisa. O padrão é 168h, com TTL menor para temas voláteis como notícias/ETF e providers.

O limite padrão é 500 itens para evitar crescimento sem controle.

## Comandos

Telegram:
- `/daniel aprendizado status`
- `/daniel o que você aprendeu`
- `/daniel aprenda sobre Bitcoin ETF`
- `/daniel o que você sabe sobre Bitcoin ETF?`

CLI:
- `python main.py daniel-learning-status`
- `python main.py daniel-learning-run`
- `python main.py daniel-learning-on`
- `python main.py daniel-learning-off`

## Segurança

O aprendizado NÃO pode:
- mudar score/filtros;
- mudar wallets/chaves;
- alterar pagamentos/Asaas;
- executar trades/transações;
- remover limites de segurança;
- gravar no `signals.db`.

`OPENAI_ENABLED=false` continua válido. Continuous Learning usa a web pública controlada, não a API paga da OpenAI.

## Privacidade do aprendizado automático

Perguntas pessoais genéricas não são enviadas automaticamente para pesquisa pública. A fila automática aceita temas públicos de cripto/mercado/providers, pesquisas web explícitas e temas derivados de sinais do CSM. Memórias pessoais permanecem locais.
