# Daniel AI V0.8.0 — Scanner & Learning Intelligence

A V0.8 preserva Continuous Learning V0.7 e Provider Failover Intelligence V0.6 e passa a usar duas novas evidências locais do CSM.

## 1. Scanner Intelligence

Daniel consegue responder, com dados persistidos:

- por que houve poucos sinais;
- quais motivos mais rejeitaram candidatos;
- qual rede teve melhor conversão;
- comparação agregada de aprovados × rejeitados.

Exemplos:

- `/daniel motivos de rejeição nas últimas 24h`
- `/daniel por que há poucos sinais na BSC nas últimas 24h?`
- `/daniel compare os rejeitados com os aprovados`

## 2. Outcome Learning

O Daniel lê o **Performance Ledger local** (`signal_ledger`) e aprende padrões observacionais de resultados já medidos, por exemplo:

- score inicial alto;
- liquidez acima da mediana;
- volume acima da mediana;
- buy pressure elevado;
- diferenças por rede quando existe amostra suficiente.

Ele registra tamanho da amostra, taxa positiva, retorno médio, TP1/stop e uplift contra a base. O resultado é salvo como conhecimento local com origem `csm_outcomes` e validade curta para ser reavaliado.

`/daniel quais padrões você encontrou nos sinais?`

## Limite metodológico

Os padrões são **correlações históricas**, não causalidade e não promessa de retorno. O Daniel não modifica scoring, filtros ou execução com base neles.

## OpenAI

`OPENAI_ENABLED=false` continua sendo o padrão. O aprendizado local e as métricas do CSM não dependem da API OpenAI.
