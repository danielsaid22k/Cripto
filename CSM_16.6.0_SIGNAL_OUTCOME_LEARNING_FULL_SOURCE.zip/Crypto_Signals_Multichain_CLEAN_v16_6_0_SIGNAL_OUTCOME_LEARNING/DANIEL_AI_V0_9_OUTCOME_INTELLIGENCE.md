# Daniel AI V0.9 — Outcome Intelligence

Daniel AI V0.9 entende o ciclo de vida dos sinais e aprende com resultados observados do próprio CSM.

## Perguntas novas

- `/daniel como estão os sinais de hoje?`
- `/daniel quais sinais estão deteriorando?`
- `/daniel quais sinais atingiram TP hoje?`
- `/daniel quais padrões você encontrou nos sinais?`
- `/daniel analise TOKEN` — inclui estado de lifecycle quando disponível.

## Aprendizado de resultados

O Continuous Learning da V0.7 é preservado. A V0.9 acrescenta padrões observacionais do Performance Ledger/Lifecycle, incluindo amostra, taxa positiva, retorno médio e incidência de TP1/TP2/TP3, stop e deterioração quando houver dados suficientes.

Esses padrões são conhecimento descritivo, não autoridade de trading. O Daniel não pode alterar score, filtros, Risk/GoPlus, pagamentos, wallets ou configurações críticas.

## Privacidade e custo

Outcome Intelligence usa dados locais do CSM e funciona com `OPENAI_ENABLED=false`. Pesquisa web continua separada e controlada pelas opções já existentes.
