# Daniel AI V1.0 — Operational Copilot

Daniel AI V1.0 consolida as camadas já existentes do CSM em uma visão operacional única, local-first e read-only.

## O que ele cruza

- Provider Resilience e failover.
- Scanner Intelligence e motivos de rejeição.
- Continuous Learning.
- Signal Lifecycle e Outcome Intelligence.
- Smart Reentry por plano.

## Exemplos no Telegram

```text
/daniel status operacional
/daniel reentradas nas últimas 24h
/daniel por que CATE foi reenviado?
/daniel quais reentradas tiveram melhor resultado?
/daniel quais sinais recuperaram depois de deteriorar?
```

Daniel explica fatos persistidos e pode aprender padrões observacionais, mas não altera scoring, filtros, pagamentos, wallets, API keys ou limites críticos.

## Voz

A arquitetura V1.0 permanece preparada para uma camada de voz posterior, mas não instala um motor STT pesado nem uma API paga automaticamente. Isso preserva a simplicidade do Termux e mantém OpenAI OFF.
