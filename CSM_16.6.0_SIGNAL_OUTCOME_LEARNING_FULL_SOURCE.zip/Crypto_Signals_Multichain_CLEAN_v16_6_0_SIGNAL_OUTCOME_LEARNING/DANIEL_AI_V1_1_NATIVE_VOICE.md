# Daniel AI V1.1 — Native Voice

## Objetivo
Receber uma nota de voz no Telegram, baixar o áudio com limite rígido, transcrever localmente no Android/Termux usando whisper.cpp e enviar o texto ao mesmo motor read-only do Daniel AI.

## Fluxo
Telegram voice/audio -> Telegram getFile -> download HTTPS limitado -> ffmpeg 16 kHz mono -> whisper.cpp local -> DanielAI.ask(source=telegram_voice) -> resposta no Telegram.

## Segurança e isolamento
- OpenAI permanece OFF e nenhuma API paga é necessária.
- Voice é admin-only quando DANIEL_AI_ADMIN_ONLY=true.
- O áudio temporário é apagado após a transcrição.
- O áudio falado NÃO vira comando geral do Telegram; passa somente por DanielAI.ask.
- Portanto voz não pode contornar pagamentos, shutdown, scoring, filtros, wallets ou configurações críticas.
- Limite padrão: 90 segundos e 12 MB.
- Falha de ffmpeg/whisper.cpp fica isolada e não derruba o bot.

## Backend local
O instalador `install_voice_termux.sh` instala ffmpeg e compila whisper.cpp no Termux HOME (`~/.local/share/csm_daniel_voice`) porque o armazenamento compartilhado Android é `noexec`. O modelo padrão é `tiny` multilíngue para reduzir CPU/armazenamento.

## Comandos
```bash
python main.py daniel-voice-status
python main.py daniel-voice-on
python main.py daniel-voice-off
python main.py daniel-voice-transcribe arquivo.ogg
bash install_voice_termux.sh
```

Depois da instalação do backend, reinicie com `csm-stop` e `csm-start` e envie uma nota de voz ao bot.
