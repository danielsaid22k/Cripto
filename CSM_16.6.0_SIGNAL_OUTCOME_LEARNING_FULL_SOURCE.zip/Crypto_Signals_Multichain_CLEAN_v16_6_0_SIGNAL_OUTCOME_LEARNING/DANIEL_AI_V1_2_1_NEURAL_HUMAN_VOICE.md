# Daniel AI V1.2.1 — Neural Human Voice

## Objetivo
Substituir a voz robótica do eSpeak por uma voz neural mais natural sem exigir OpenAI.

## Ordem automática de motores
1. **Supertonic 3** — motor neural local principal, português (`pt`), voz padrão `M1`.
2. **Kokoro 82M PT-BR** — fallback neural local, voz padrão masculina `pm_alex`.
3. **eSpeak** — fallback de emergência apenas para manter a resposta falada disponível.

## Segurança e isolamento
- O texto continua sendo enviado primeiro no Telegram.
- Falhas de TTS não cancelam nem atrasam permanentemente a resposta de texto.
- O TTS não pode alterar score, filtros, pagamentos, carteira, providers ou configurações críticas.
- OpenAI permanece desativada por padrão.
- Áudios temporários são removidos após o envio.

## Operação
- `python main.py daniel-speech-status` mostra motor selecionado e fallbacks disponíveis.
- `python main.py daniel-speech-test` gera um áudio de teste local.
- `bash install_neural_voice_termux.sh` instala e faz um warm-up real do Supertonic no Android.
- `bash test_neural_voice_termux.sh` executa a sequência de validação.

## Armazenamento
Os modelos ficam no HOME privado do Termux (`~/.cache/supertonic3` e `~/.local/share/csm_daniel_tts`), evitando o `noexec` do armazenamento compartilhado do Android.
