# Daniel AI V1.2.2 — Natural Neural Voice

A V1.2.2 mantém a entrada de voz do Telegram com `whisper.cpp` local e melhora a saída falada com uma camada online mais natural.

## Cadeia de voz

1. **Microsoft Edge Neural PT-BR via `edge-tts`** — motor principal online, sem chave de API.
2. **Supertonic 3** — fallback neural local.
3. **Kokoro 82M PT-BR** — segundo fallback neural local.
4. **eSpeak** — fallback de emergência.

A resposta de texto continua sendo enviada primeiro. Falhas no TTS não cancelam a resposta textual nem alteram scanner, pagamentos, filtros, score ou estado crítico do CSM.

## Privacidade e rede

A transcrição da nota de voz continua local no Android com `whisper.cpp`. Quando o motor `edge` está ativo, apenas o texto final da resposta a ser falada é enviado ao serviço online de TTS usado pelo Microsoft Edge. O áudio original do usuário não é enviado por essa camada.

O `edge-tts` não exige chave de API, mas depende de internet e do serviço online do Microsoft Edge; por isso os motores locais permanecem como fallback automático.

## Vozes PT-BR prontas

- `pt-BR-AntonioNeural` — padrão masculino.
- `pt-BR-FabioNeural` — alternativa masculina.
- `pt-BR-HumbertoNeural` — alternativa masculina.
- `pt-BR-FranciscaNeural` — alternativa feminina.

Comandos:

```bash
python main.py daniel-speech-status
python main.py daniel-speech-test
python main.py daniel-speech-compare
python main.py daniel-speech-use antonio
python main.py daniel-speech-use fabio
python main.py daniel-speech-use humberto
python main.py daniel-speech-use francisca
```
