# Daniel AI V1.2.3 — Conversational Voice Intelligence

## Objetivo

Parar de ler a resposta técnica linha por linha. A V1.2.3 mantém o relatório completo no Telegram e cria uma segunda representação, exclusiva para fala, com tom de analista.

## Fluxo

1. Nota de voz chega pelo Telegram.
2. `whisper.cpp` transcreve localmente.
3. Daniel AI gera a resposta técnica normal.
4. O texto técnico é enviado ao Telegram sem alteração.
5. `ConversationalVoice` lê apenas os fatos já presentes na resposta e monta um briefing falado.
6. O TTS ativo gera o áudio: Edge Neural PT-BR principal, com fallbacks locais já existentes.

## Estrutura da fala

- contexto;
- importância;
- consequência;
- ponto de atenção.

O áudio evita cabeçalhos, emojis, bullets, disclaimers repetitivos e leitura mecânica de todas as métricas. Números relevantes continuam sendo usados quando ajudam a explicar o significado.

## Modos especializados

- status operacional: saúde de providers, funil do scanner, lifecycle e reentradas;
- análise de ativo: força do score, estrutura de mercado, pressão compradora, risco e lifecycle;
- score: fatos persistidos e motivos registrados, sem inventar pesos;
- lifecycle: mudanças e sinais deteriorando;
- providers: disponibilidade versus impacto real e fallback;
- genérico: resumo conectado dos principais pontos.

## Segurança

A camada é determinística e local. Não chama OpenAI, não altera score, filtros, scanner, pagamentos ou configurações críticas. Se a transformação falhar, o TTS recebe a resposta original e o texto do Telegram já terá sido entregue.

## Configuração

```text
DANIEL_AI_CONVERSATIONAL_VOICE_ENABLED=true
DANIEL_AI_CONVERSATIONAL_VOICE_STYLE=executive
DANIEL_AI_CONVERSATIONAL_VOICE_DETAIL=balanced
DANIEL_AI_CONVERSATIONAL_VOICE_MAX_CHARS=1150
```
