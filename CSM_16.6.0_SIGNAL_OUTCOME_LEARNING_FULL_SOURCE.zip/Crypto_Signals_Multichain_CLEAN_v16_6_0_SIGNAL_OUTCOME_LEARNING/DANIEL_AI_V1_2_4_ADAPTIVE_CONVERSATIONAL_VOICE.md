# Daniel AI V1.2.4 — Adaptive Conversational Voice

## Objetivo

Tornar a resposta falada mais próxima de uma conversa natural: menos leitura de relatório, mais interpretação. O texto do Telegram continua técnico e completo; o áudio recebe uma representação separada, criada apenas com fatos já presentes na resposta.

## Perfis automáticos

- **Executivo**: status, panorama, resumo, saúde operacional e prioridades.
- **Analista**: token, sinal, score, liquidez, momentum, risco, lifecycle e reentrada.
- **Explicativo**: perguntas com “por quê?”, “me explica”, erros, instalação e sequências de comandos.

O perfil padrão é `adaptive`, então Daniel escolhe o estilo automaticamente a cada pergunta.

## Fala mais natural

A V1.2.4 prioriza:

1. o ponto principal;
2. contexto suficiente para entender;
3. significado e consequência;
4. próximo ponto a observar.

A fala evita repetir todas as métricas do texto. Números entram apenas quando ajudam a explicar o quadro. Também converte termos técnicos para formas mais pronunciáveis, como `24h` para “24 horas”, `TP3` para “terceiro alvo” e `HTTP 429` para “erro 429 de limite de requisições”.

## Explicação de comandos

Quando a resposta contém vários comandos de terminal, o texto mantém os comandos exatos para copiar. O áudio não soletra caminhos e comandos; ele explica a lógica da sequência, por exemplo: parar o serviço, entrar na pasta correta, extrair o pacote, instalar, migrar, validar e reiniciar.

Se uma etapa falhar, Daniel orienta a interromper ali e usar a mensagem exata do terminal como referência.

## Variação controlada

As aberturas e transições variam de forma determinística para não soar repetitivo. A mesma pergunta gera a mesma fala, o que mantém testes e diagnósticos reproduzíveis.

## Privacidade e segurança

- Nenhum novo LLM/API é usado para essa reescrita.
- OpenAI permanece desligada por padrão.
- Scanner, score, filtros, pagamentos, banco e limites críticos não são alterados.
- O texto técnico continua sendo a referência autoritativa.
- A entrada de voz continua local via whisper.cpp.
- A saída de voz mantém o motor já configurado e seus fallbacks.

## Configuração

```text
DANIEL_AI_CONVERSATIONAL_VOICE_ENABLED=true
DANIEL_AI_CONVERSATIONAL_VOICE_STYLE=adaptive
DANIEL_AI_CONVERSATIONAL_VOICE_DETAIL=balanced
DANIEL_AI_CONVERSATIONAL_VOICE_MAX_CHARS=1250
DANIEL_AI_CONVERSATIONAL_COMMAND_EXPLAINER=true
DANIEL_AI_CONVERSATIONAL_NATURAL_VARIATION=true
```
