# Daniel AI V1.2 — Dual Response Voice

- Entrada: nota de voz Telegram continua sendo transcrita localmente via whisper.cpp.
- Saída: Daniel envia primeiro o texto completo e, em seguida, uma nota de voz local.
- TTS local: eSpeak NG + ffmpeg/Opus.
- Sem OpenAI/API para STT ou TTS.
- Falha no TTS nunca bloqueia a resposta em texto.
- Áudio gerado é temporário e apagado após o envio.
- Respostas longas são resumidas/truncadas apenas no áudio; o texto preserva a resposta completa dentro dos limites do Telegram.
