# Daniel AI V1.3.0 — Daniel Smart / Local Generative Brain

A V1.3 adiciona um cérebro generativo local opcional ao Daniel AI.

## Objetivo

Eliminar o antigo fallback rígido para perguntas livres e permitir conversas naturais em PT-BR sem depender de OpenAI ou de uma API paga.

## Arquitetura

- `llama.cpp` compilado no Termux.
- Modelo padrão SMART: `Qwen3-4B Q4_K_M` em GGUF (~2,5 GB).
- Contexto inicial: 4096 tokens.
- O modelo é acionado somente quando a pergunta não cai em uma rota determinística existente do CSM.
- Scanner, providers, signal lifecycle, smart reentry, pagamentos, score, filtros e demais rotas críticas continuam prioritários e não são delegados ao LLM.
- O modelo não recebe autoridade para alterar wallet, pagamentos, chaves, filtros de segurança ou executar operações financeiras.

## Memória e conversa

O fallback generativo recebe uma janela curta do histórico local do Daniel (6 mensagens por padrão), permitindo continuidade sem enviar essa conversa a uma API de LLM.

## Voz

A entrada continua usando whisper.cpp local. A saída continua usando a cadeia TTS já configurada. O texto gerado pelo Daniel Smart passa normalmente pela Adaptive Conversational Voice antes do TTS.

## Privacidade

O LLM roda localmente. A primeira instalação requer internet apenas para clonar/compilar o llama.cpp e baixar o GGUF. A política do TTS permanece independente: se Edge Neural estiver ativo, apenas o texto final destinado à fala segue para esse serviço; os fallbacks locais continuam preservados.

## Comandos

```bash
python main.py daniel-smart-status
python main.py daniel-smart-test
python main.py daniel-smart-benchmark
python main.py daniel-smart-on
python main.py daniel-smart-off
```

## Observação de desempenho

O modo V1.3 inicial usa execução sob demanda, sem manter o modelo permanentemente residente em RAM. Isso protege o CSM quando o Daniel não está sendo usado, mas pode acrescentar tempo de carregamento a cada pergunta livre. O benchmark no próprio aparelho decide se uma evolução posterior para servidor persistente vale a pena.
