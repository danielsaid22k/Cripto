# Crypto Signals Multichain V15 — Distribution Platform

V15 extends the stable Telegram-first delivery engine with **outbound-only** enterprise distribution. No inbound/public webhook is opened by the bot.

## Channels

- Telegram remains the authoritative primary delivery channel.
- Signed HTTPS webhook / API push (`webhook`).
- Discord webhook (`discord`).
- SMTP email (`email`).

Only after Telegram confirms a signal delivery does V15 enqueue matching outbound jobs. External channel failures never roll back the Telegram delivery or block scanning.

## Security model

Webhook targets, Discord webhook URLs and HMAC secrets are **not stored in SQLite**. They live under the persistent state directory:

`Crypto_Signals_Multichain_State/secrets/distribution/`

Files are written with restrictive permissions when the platform allows it. Secret-bearing backups include them only when `include_secrets=true` / setup creates a secret backup. Buyer Data Room and sale packages do not include them.

Signed webhook headers:

- `X-CSM-Event`
- `X-CSM-Delivery`
- `X-CSM-Timestamp`
- `X-CSM-Signature: v1=<hmac-sha256>`
- `Idempotency-Key`

Signature input is `timestamp + "." + canonical_json_body`.

## Reliability

- Persistent SQLite queue.
- One idempotent job per destination/event.
- Cooperative scheduler: at most one outbound delivery per idle step on mobile.
- Retry schedule with bounded attempts.
- Dead-letter state after maximum attempts.
- Explicit retry command for DEAD/RETRY jobs.
- Append-only delivery-attempt audit.
- Observability metrics for delivery channel/state.

## Commands

```sh
python main.py distribution-status --days 7
python main.py distribution-list
python main.py distribution-add --channel webhook --name "Partner API" --plans premium
python main.py distribution-add --channel discord --name "Premium Discord" --plans premium
python main.py distribution-add --channel email --name "Operations Email" --plans premium
python main.py distribution-test --id 1
python main.py distribution-run-once --limit 5
python main.py distribution-jobs --limit 50
python main.py distribution-jobs --status DEAD --limit 50
python main.py distribution-retry --job-id 123
python main.py distribution-disable --id 1
python main.py distribution-enable --id 1
```

On a-Shell use `python3`.

If `--target` is omitted, the CLI asks for the destination without echoing it. This is recommended for Discord webhook URLs and private enterprise endpoints.

## SMTP

Configure SMTP in setup option **10** or in persistent config:

```text
SMTP_HOST=
SMTP_PORT=587
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=
SMTP_STARTTLS=true
SMTP_SSL=false
```

No SMTP configuration is required for Telegram, Discord or signed webhook distribution.

## SaaS read-only endpoints

- `GET /api/v1/distribution`
- `GET /api/v1/distribution/dead-letter`

They expose sanitized job state only; target URLs, recipient addresses and HMAC material are not returned.
