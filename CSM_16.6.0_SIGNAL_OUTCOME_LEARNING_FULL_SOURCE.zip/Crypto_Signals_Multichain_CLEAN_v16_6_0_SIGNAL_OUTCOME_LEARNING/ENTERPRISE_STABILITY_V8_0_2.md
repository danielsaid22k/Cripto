# Phantom Alert 8.0.2 — Enterprise Stability

Base LTS preservada: **6.3.0**.

Esta release concentra-se em estabilidade operacional dos providers:

- logs somente em mudanças de estado;
- circuit breaker com backoff progressivo;
- cache fresco e cache obsoleto controlado para contingência;
- recuperação automática e aviso único ao voltar a ONLINE;
- métricas de taxa de sucesso e latência por provider;
- nenhum banco, segredo ou dado pessoal incluído no pacote.
