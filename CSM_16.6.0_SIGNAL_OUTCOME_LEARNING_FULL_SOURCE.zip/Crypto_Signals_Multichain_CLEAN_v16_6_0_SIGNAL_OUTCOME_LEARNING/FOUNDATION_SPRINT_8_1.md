# Sprint 8.1 Foundation RC1

Implemented:

- Architecture dependency audit without automatic deletion.
- Compatibility facades for Core, Bot, Admin, Leader and Backup.
- Read-only Configuration Manager preserving the existing persistent `config.env`.
- Health Engine with uptime, process memory, existing health dashboard and latest backup.
- Plugin manifest registry and loader with no plugin enabled by default.
- Release Engine validating compilation, LTS contract, configuration, architecture, existing Quality Gate and tests.
- New CLI commands: `foundation-audit`, `foundation-health`, `plugins-status`, `foundation-release`.

Not changed:

- SQLite schema.
- Migration logic.
- Scanner business rules.
- Telegram callbacks.
- Payments and subscriptions.
- Backup and restore formats.
