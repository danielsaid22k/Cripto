# Full Review — Crypto Signals Multichain v10.1.2

## Escopo revisado

A revisão partiu do ZIP `v10.1.1 SECURITY_CLEAN_FOR_SALE` e cobriu estrutura do arquivo, compilação, testes, runtime ativo, compatibilidade, scanner, discovery, providers, Telegram, auto-delivery, banco/persistência, backup/restore, Asaas, painel administrativo, Project Leader, scripts mobile e limpeza para venda.

## Estado inicial observado

- 215 arquivos no projeto extraído;
- 159 arquivos Python;
- runtime ativo correto em `phantom_v10` e runtimes anteriores mantidos para compatibilidade;
- 179 testes existentes;
- uma execução limpa expôs dependência de estado no teste de replay/checkpoint do Telegram;
- feeds públicos do GeckoTerminal estavam fixos em Solana no núcleo de discovery;
- fatias cooperativas podiam reiniciar análise nos mesmos primeiros candidatos;
- 404 de mercado podia contribuir para circuit breaker compartilhado;
- backups/logs eram produzidos dentro da pasta da release;
- update bundle usava extração integral do ZIP antes de copiar arquivos validados;
- manifesto/documentação continham números e versões divergentes do runtime/banco atual.

## Correções implementadas

1. Dependência injetada do Telegram separada da configuração de produção, eliminando teste dependente de estado.
2. Discovery público GeckoTerminal global e parser de relação explícita de rede.
3. Rotação de candidatos entre fatias para ampliar profundidade de pesquisa ao longo dos ciclos.
4. 404 classificado como miss neutro no provider gateway.
5. Métricas de `market_unavailable`, erros de normalização e motivos de rejeição.
6. Sanitização de tokens/chaves em URLs de erro.
7. Headers adicionais de segurança no Admin Web e redaction de query token no audit log.
8. Update bundles sem `extractall()`, copiando somente payload listado e validado por SHA-256.
9. Logs e backups persistentes fora da pasta da versão.
10. Backups identificados com a versão real do produto.
11. Validação de faixas de configuração e redes desconhecidas.
12. Scripts Termux/a-Shell mais robustos e selftest na instalação.
13. `validate.py` reconstruído para estado isolado e compilação do projeto inteiro.
14. README, comandos, upgrade, security audit, release notes, freeze e manifesto atualizados.

## Segurança do ZIP de origem

O container ZIP original não apresentou entradas duplicadas, caminhos absolutos/`..`, symlinks, arquivos criptografados ou razão de compressão suspeita.

## Homologação final

- 160 arquivos Python;
- `compileall`: aprovado;
- `pytest`: **189/189**;
- selftest: aprovado;
- SQLite: `integrity_check=ok`, schema 611;
- release-check: aprovado;
- sintaxe dos scripts shell: aprovada;
- JSON do pacote: válido;
- padrões de `eval`, `exec`, `shell=True`, `pickle.load`, `yaml.load` inseguro e `os.system`: não encontrados;
- imports proibidos no runtime ativo `phantom_v10` (`subprocess`, threads, requests, urllib3): não encontrados;
- credenciais reais por padrões conhecidos: não encontradas;
- artefatos de usuário no pacote final (`.env`, DB, logs, backups, pyc, ZIP interno): não presentes.

## Observação de arquitetura

A versão interna `csm.__version__ = 8.3.1-ashell-single-runtime` é preservada como identidade da camada congelada de compatibilidade. A versão do produto é exposta separadamente como `10.1.2-security-reliability`, evitando quebrar contratos históricos e eliminando rótulos errados nos novos backups/telas.
