# Full Review — Crypto Signals Multichain v10.1.3

## Escopo

Revisão orientada à falha real observada no Birdeye, preservando o runtime v10.1.2 que já estava operando com DexScreener, GeckoTerminal, CoinGecko, Telegram, SQLite e os planos comerciais.

## Causa raiz no código

A fonte Birdeye de `phantom_v10/discovery.py` adicionava `meme_platform_enabled` a todas as redes. A API atual documenta esse filtro como exclusivo de Solana. A presença do parâmetro nas redes EVM podia gerar `HTTP 400`.

## Causa raiz de autenticação no estado do aparelho

O teste mínimo retornou `HTTP 401 Unauthorized` para a chave Birdeye persistente. A presença de 32 caracteres no arquivo de configuração prova apenas que existe um valor salvo; não prova que o BDS aceita esse valor. A v10.1.3 deixa de declarar Birdeye saudável apenas por haver uma string configurada.

## Correções

1. parâmetros Birdeye por rede;
2. `meme_platform_enabled` somente em Solana;
3. diagnóstico `birdeye-check` usando o transporte real do runtime;
4. autenticação validada primeiro em `/defi/networks`;
5. teste opcional de New Listing após autenticação;
6. 401/403 não usam cache stale;
7. 401/403 pausam somente Birdeye por 5 minutos;
8. rotas Birdeye restantes do mesmo ciclo são descartadas após erro de autenticação;
9. DexScreener, GeckoTerminal e CoinGecko permanecem funcionando como fallback;
10. mensagens operacionais distinguem 401 de 403 sem revelar a chave;
11. setup normaliza colagem de chave e orienta teste nativo.

## Preservado

- LTS 6.3.0;
- schema 611 e piso 600;
- diretório persistente `Crypto_Signals_Multichain_State`;
- Telegram;
- Asaas;
- Free/Plus/Premium e cadências 15/5/1 minuto;
- scanner sequencial/cooperativo no a-Shell;
- rotação de profundidade entre fatias;
- watchdog consciente de suspensão iOS;
- segurança de logs e updates da v10.1.2.
