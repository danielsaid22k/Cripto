# Full Review — Crypto Signals Multichain v10.1.4

## Escopo

Revisão incremental sobre a v10.1.3, focada na persistência e no diagnóstico Birdeye sem regressão do scanner, Telegram, Asaas, SQLite, planos ou runtime mobile.

## Resultado da investigação de credenciais

- Nenhuma chave Birdeye real existe no ZIP comercial.
- A fonte ativa normal é `Crypto_Signals_Multichain_State/config.env`.
- O `.env` da release atual é uma cópia de compatibilidade e agora precisa coincidir com a fonte persistente.
- Releases antigas e backups podem conter chaves históricas.
- Antes da v10.1.4, uma chave histórica não sobrescrevia uma chave atual, mas podia ser restaurada se o campo Birdeye ficasse ausente.
- A v10.1.4 elimina essa reintrodução silenciosa usando fingerprint de geração em `credential_meta.json`.

## Birdeye HTTP

O diagnóstico foi alterado para não assumir que um único endpoint representa toda a integração. `/defi/networks` é usado como coverage probe, e a rota efetivamente consumida pelo scanner, `/defi/v2/tokens/new_listing`, também é testada com request mínimo. Respostas de erro preservam o detalhe útil do servidor e removem qualquer segredo.

## Validação

202 testes aprovados, selftest OK, compileall OK, SQLite íntegro em schema 611 e release-check aprovado em estado isolado.
