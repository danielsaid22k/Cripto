# Full Review v10.1.5 — Birdeye CU Guard

A captura real do operador mostrou que a chave ativa vinha de `Crypto_Signals_Multichain_State/config.env` e que havia três cópias históricas diferentes, sem serem a fonte ativa. O BDS retornou `Compute units usage limit exceeded` tanto em `/defi/networks` quanto em New Listing.

A causa operacional, portanto, é cota de Compute Units da conta/pacote Birdeye, não whitelist e não chave antiga. A release corrige a classificação interna para evitar diagnóstico falso de autenticação inválida e reduz chamadas inúteis enquanto a cota estiver bloqueada.

A camada pública e os demais providers continuam funcionando como fallback.
