# GoPlus Security Layer — v10.2.0

## Objetivo

Adicionar uma segunda camada de decisão baseada na segurança do contrato, sem alterar a função dos providers que descobrem oportunidades.

## Pipeline

1. DexScreener / GeckoTerminal / Birdeye / CoinGecko descobrem candidatos.
2. O scanner aplica idade, liquidez, volume, mudança de preço e filtros existentes.
3. Se a rede for suportada, GoPlus consulta a segurança do contrato.
4. Riscos críticos bloqueiam o candidato.
5. Riscos moderados reduzem o score de segurança.
6. O `final_score` combina mercado e segurança, mas nunca supera o score de mercado.
7. O sinal aprovado segue para apresentação e auto-delivery.

## Endpoints integrados

- EVM: `/api/v1/token_security/{chain_id}` com `contract_addresses`.
- Solana: `/api/v1/solana/token_security` com `contract_addresses`.
- Diagnóstico geral: `/api/v1/supported_chains`.

O Bearer token, quando configurado, é enviado exclusivamente no header `Authorization`.

## Segurança EVM

Bloqueios críticos incluem honeypot, compra bloqueada, owner capaz de alterar saldo, selfdestruct, gas abuse, airdrop scam, fake token e taxas acima dos limites definidos pelo operador.

Riscos ponderados incluem contrato não verificado, proxy, mint, recuperação de ownership, hidden owner, pause, blacklist/whitelist, slippage/taxas modificáveis, anti-whale modificável, cooldown, impossibilidade de vender 100% e concentração relevante.

## Segurança Solana

A integração interpreta estado default congelado, non-transferable, balance mutable authority, creator/hook malicioso, mint/freezing/close authorities, transfer fee e capacidades de upgrade retornadas pela API.

## Operação e disponibilidade

- cache primário: `GOPLUS_CACHE_TTL`, padrão 1800 s;
- stale fallback: `GOPLUS_STALE_TTL`, padrão 86400 s;
- score mínimo: `GOPLUS_MIN_SECURITY_SCORE`, padrão 55;
- fail-open padrão para preservar disponibilidade do scanner;
- `GOPLUS_FAIL_CLOSED=true` transforma indisponibilidade/ausência de dados em rejeição;
- redes não suportadas permanecem analisáveis pelo pipeline de mercado e são marcadas como `unsupported`.

## Telegram

Os cards passam a incluir a seção `🛡️ SEGURANÇA DO CONTRATO`. Premium recebe mais detalhes de taxas, concentração, LP e riscos; Plus recebe uma visão intermediária; o score final passa a priorizar `final_score`.

## Diagnóstico

```sh
python3 main.py goplus-check
python3 main.py goplus-check --chain ethereum --address 0x...
```

Nenhum comando imprime `GOPLUS_ACCESS_TOKEN`.
