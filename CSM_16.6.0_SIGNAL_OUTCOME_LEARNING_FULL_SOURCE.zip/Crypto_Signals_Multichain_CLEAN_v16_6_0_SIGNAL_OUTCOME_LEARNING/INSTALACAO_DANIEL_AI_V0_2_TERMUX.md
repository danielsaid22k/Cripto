# Atualização remota — Daniel AI V0.2.0

O Android/Termux é o host. O iPhone pode executar todos os comandos abaixo por
SSH/Tailscale depois que o ZIP estiver nos Downloads do Android.

Execute um comando por vez:

```sh
csm-stop
```

```sh
cd ~/storage/downloads
```

```sh
unzip -o Crypto_Signals_Multichain_v16.0.0_DANIEL_AI_v0.2.0_ADMIN_INTELLIGENCE.zip
```

```sh
cd Crypto_Signals_Multichain_CLEAN_v16_0_0_DANIEL_AI_v0_2_0
```

```sh
bash install_termux.sh
```

```sh
python main.py migrate
```

```sh
python main.py db-check
```

```sh
python main.py daniel-status
```

Antes de trocar o boot, confirme o caminho atual:

```sh
grep '^PROJECT=' ~/.termux/boot/10-start-csm
```

Se estiver em `DANIEL_AI_v0_1_2`, atualize somente o sufixo:

```sh
sed -i 's/DANIEL_AI_v0_1_2/DANIEL_AI_v0_2_0/' ~/.termux/boot/10-start-csm
```

Confirme:

```sh
grep '^PROJECT=' ~/.termux/boot/10-start-csm
```

Inicie:

```sh
csm-start
```

Verifique:

```sh
csm-status
```

Teste no Telegram:

`/daniel analise CATE`
