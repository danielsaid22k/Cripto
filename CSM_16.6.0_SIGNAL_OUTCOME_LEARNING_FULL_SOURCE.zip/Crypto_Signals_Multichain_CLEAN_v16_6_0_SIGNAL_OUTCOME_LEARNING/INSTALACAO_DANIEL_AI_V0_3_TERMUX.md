# Atualização remota — Daniel AI V0.3.0

O Android/Termux continua sendo o host. O iPhone pode executar a atualização por
SSH/Tailscale depois que o ZIP estiver nos Downloads do Android.

Execute um comando por vez:

```sh
csm-stop
```

```sh
cd ~/storage/downloads
```

```sh
unzip -o Crypto_Signals_Multichain_v16.0.0_DANIEL_AI_v0.3.0_LOCAL_KNOWLEDGE.zip
```

```sh
cd Crypto_Signals_Multichain_CLEAN_v16_0_0_DANIEL_AI_v0_3_0
```

```sh
bash install_termux.sh
```

```sh
python main.py migrate
```

```sh
python main.py db-check
```

```sh
python main.py daniel-status
```

Confirme o boot atual:

```sh
grep '^PROJECT=' ~/.termux/boot/10-start-csm
```

Atualize somente da V0.2.0 para V0.3.0:

```sh
sed -i 's/DANIEL_AI_v0_2_0/DANIEL_AI_v0_3_0/' ~/.termux/boot/10-start-csm
```

Confirme:

```sh
grep '^PROJECT=' ~/.termux/boot/10-start-csm
```

Inicie:

```sh
csm-start
```

Verifique:

```sh
csm-status
```

## Testes Telegram

```text
/daniel últimos erros
```

```text
/daniel histórico da conversa
```

```text
/daniel documentos
```

Para adicionar documentos manualmente pelo Termux, use a pasta:

```sh
mkdir -p ~/storage/downloads/Crypto_Signals_Multichain_State/daniel_ai/documents
```

Depois copie um `.txt`, `.md`, `.json`, `.csv`, `.log`, `.docx` ou `.pdf` para ela
e envie no Telegram:

```text
/daniel documentos
```

A busca pode ser testada com:

```text
/daniel procure nos documentos liquidez
```
