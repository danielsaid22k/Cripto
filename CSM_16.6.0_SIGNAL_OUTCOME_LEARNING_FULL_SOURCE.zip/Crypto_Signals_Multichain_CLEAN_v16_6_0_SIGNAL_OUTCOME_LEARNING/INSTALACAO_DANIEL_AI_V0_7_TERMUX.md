# Instalação — CSM V16.1 + Daniel AI V0.7 Continuous Learning

1. `csm-stop`
2. `cd ~/storage/downloads`
3. `unzip -o Crypto_Signals_Multichain_v16.1.0_DANIEL_AI_v0.7.0_CONTINUOUS_LEARNING.zip`
4. `cd Crypto_Signals_Multichain_CLEAN_v16_1_0_DANIEL_AI_v0_7_0`
5. `bash install_termux.sh`
6. `python main.py migrate`
7. `python main.py db-check`
8. `python main.py selftest`
9. `python main.py daniel-status`
10. `sed -i 's#Crypto_Signals_Multichain_CLEAN_v16_1_0_DANIEL_AI_v0_6_0#Crypto_Signals_Multichain_CLEAN_v16_1_0_DANIEL_AI_v0_7_0#' ~/.termux/boot/10-start-csm`
11. `grep '^PROJECT=' ~/.termux/boot/10-start-csm`
12. `csm-start`
13. `csm-status`
14. `python main.py daniel-learning-status`

Se a Web estiver OFF: `python main.py daniel-web-on`, depois reinicie o CSM.

Teste manual: `python main.py daniel-learning-run`.

Desligar depois: `python main.py daniel-learning-off`, depois `csm-stop` e `csm-start`.

OpenAI permanece OFF enquanto `OPENAI_ENABLED=false`.
