# Instalação — CSM V16.2 + Daniel AI V0.8

```sh
csm-stop
cd ~/storage/downloads
unzip -o Crypto_Signals_Multichain_v16.2.0_DANIEL_AI_v0.8.0_SCANNER_LEARNING_INTELLIGENCE.zip
cd Crypto_Signals_Multichain_CLEAN_v16_2_0_DANIEL_AI_v0_8_0
bash install_termux.sh
python main.py migrate
python main.py db-check
python main.py selftest
python main.py daniel-status
sed -i 's#Crypto_Signals_Multichain_CLEAN_v16_1_0_DANIEL_AI_v0_7_0#Crypto_Signals_Multichain_CLEAN_v16_2_0_DANIEL_AI_v0_8_0#' ~/.termux/boot/10-start-csm
grep '^PROJECT=' ~/.termux/boot/10-start-csm
csm-start
csm-status
```

Não rode `python main.py setup` quando Telegram/Asaas/providers já estão configurados. O estado persistente é reutilizado e o schema permanece 680.

Após iniciar:

```sh
python main.py scanner-intelligence --hours 24
python main.py daniel-learning-status
```
