# Instalação — CSM V16.3 + Daniel AI V0.9

```sh
csm-stop
cd ~/storage/downloads
unzip -o Crypto_Signals_Multichain_v16.3.0_DANIEL_AI_v0.9.0_SIGNAL_LIFECYCLE_OUTCOME_INTELLIGENCE.zip
cd Crypto_Signals_Multichain_CLEAN_v16_3_0_DANIEL_AI_v0_9_0
bash install_termux.sh
python main.py migrate
python main.py db-check
python main.py selftest
python main.py daniel-status
sed -i 's#Crypto_Signals_Multichain_CLEAN_v16_2_0_DANIEL_AI_v0_8_0#Crypto_Signals_Multichain_CLEAN_v16_3_0_DANIEL_AI_v0_9_0#' ~/.termux/boot/10-start-csm
grep '^PROJECT=' ~/.termux/boot/10-start-csm
csm-start
csm-status
```

Não rode `python main.py setup` quando Telegram/Asaas/providers já estão configurados. O estado persistente é reutilizado e o schema permanece 680.

Após iniciar:

```sh
python main.py signal-lifecycle --hours 24
python main.py signal-lifecycle-events --hours 24 --limit 20
python main.py daniel-learning-status
```
