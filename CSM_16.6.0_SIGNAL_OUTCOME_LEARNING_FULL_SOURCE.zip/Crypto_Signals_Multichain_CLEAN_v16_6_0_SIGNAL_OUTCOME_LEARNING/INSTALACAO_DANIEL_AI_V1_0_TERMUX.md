# Instalação — CSM V16.4 + Daniel AI V1.0

```sh
csm-stop
cd ~/storage/downloads
unzip -o Crypto_Signals_Multichain_v16.4.0_DANIEL_AI_v1.0.0_SMART_REENTRY_OPERATIONAL_COPILOT.zip
cd Crypto_Signals_Multichain_CLEAN_v16_4_0_DANIEL_AI_v1_0_0
bash install_termux.sh
python main.py migrate
python main.py db-check
python main.py selftest
python main.py daniel-status
sed -i 's#Crypto_Signals_Multichain_CLEAN_v16_3_0_DANIEL_AI_v0_9_0#Crypto_Signals_Multichain_CLEAN_v16_4_0_DANIEL_AI_v1_0_0#' ~/.termux/boot/10-start-csm
grep '^PROJECT=' ~/.termux/boot/10-start-csm
csm-start
csm-status
python main.py smart-reentry --hours 24
```

Não execute `python main.py setup` se Telegram, Asaas e providers já estiverem configurados.
