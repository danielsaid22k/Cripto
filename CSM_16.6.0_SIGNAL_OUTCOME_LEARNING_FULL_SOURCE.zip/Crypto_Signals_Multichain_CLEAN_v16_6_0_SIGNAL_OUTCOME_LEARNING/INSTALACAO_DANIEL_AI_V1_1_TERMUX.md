# Instalação Daniel AI V1.1 no Termux

1. Instale/atualize o pacote CSM normalmente.
2. Entre na pasta da V1.1.
3. Execute `bash install_voice_termux.sh`.
4. Aguarde ffmpeg + compilação whisper.cpp + modelo tiny.
5. Rode `python main.py daniel-voice-status`. O esperado é `Pronto: SIM`.
6. `csm-stop` e `csm-start`.
7. Envie uma nota de voz ao bot Telegram.

OpenAI continua OFF. O motor de voz fica persistente em `~/.local/share/csm_daniel_voice`, fora do armazenamento `noexec` do Android.
