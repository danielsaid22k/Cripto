# Instalação Daniel AI V1.2.1 — Neural Human Voice

1. Atualize o pacote principal normalmente.
2. Rode `python main.py migrate`.
3. Rode `python main.py db-check`.
4. Rode `python main.py selftest`.
5. Rode `bash install_neural_voice_termux.sh`.
6. Confirme com `python main.py daniel-speech-status`.
7. Gere um áudio local com `python main.py daniel-speech-test`.
8. Reinicie o CSM com `csm-stop` e `csm-start`.
9. Envie uma nota de voz ao bot no Telegram.

Esperado: transcrição local -> resposta em texto -> resposta em áudio neural. Se o Supertonic não ficar disponível, o Daniel tenta Kokoro; eSpeak fica apenas como fallback de emergência.
