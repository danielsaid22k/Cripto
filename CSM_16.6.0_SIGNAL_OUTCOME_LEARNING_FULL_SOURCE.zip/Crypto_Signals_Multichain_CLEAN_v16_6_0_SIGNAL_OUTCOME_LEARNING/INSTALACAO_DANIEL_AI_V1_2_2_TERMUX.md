# Instalação Daniel AI V1.2.2 — Natural Neural Voice

Base preservada: CSM V16.4.0 + Daniel AI V1.2.1.

## Instalação

```bash
csm-stop
```

```bash
cd ~/storage/downloads
```

```bash
unzip -o Crypto_Signals_Multichain_v16.4.0_DANIEL_AI_v1.2.2_NATURAL_NEURAL_VOICE.zip
```

```bash
cd Crypto_Signals_Multichain_CLEAN_v16_4_0_DANIEL_AI_v1_2_2
```

```bash
bash install_termux.sh
```

```bash
python main.py migrate
```

```bash
python main.py db-check
```

```bash
python main.py selftest
```

```bash
bash install_natural_voice_termux.sh
```

## Testes do novo motor

```bash
python main.py daniel-speech-status
```

```bash
python main.py daniel-speech-test
```

Para gerar três amostras PT-BR:

```bash
python main.py daniel-speech-compare
```

Arquivos de teste ficam em `Crypto_Signals_Multichain_State/daniel_ai/voice/tests/`.

Escolha uma voz:

```bash
python main.py daniel-speech-use antonio
```

ou `fabio`, `humberto`, `francisca`.

## Boot

Atualize o `PROJECT` da V1.2.1 para V1.2.2 e confirme com `grep '^PROJECT=' ~/.termux/boot/10-start-csm`.

Depois:

```bash
csm-start
```

```bash
csm-status
```

## Observação

O motor principal usa o serviço online de TTS do Microsoft Edge via `edge-tts`, sem chave de API. Se a internet ou o serviço falhar, Daniel tenta automaticamente Supertonic, Kokoro e eSpeak, nessa ordem.
