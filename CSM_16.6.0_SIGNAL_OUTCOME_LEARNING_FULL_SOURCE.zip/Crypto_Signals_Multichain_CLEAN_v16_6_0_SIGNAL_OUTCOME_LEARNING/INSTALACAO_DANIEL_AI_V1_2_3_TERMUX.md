# Instalação Daniel AI V1.2.3 — Conversational Voice Intelligence

Base preservada: CSM V16.4.0 + Daniel AI V1.2.2 Natural Neural Voice.

A V1.2.3 não exige novo modelo pesado. Ela adiciona uma camada local de preparação da fala e preserva Edge Neural PT-BR, whisper.cpp e todos os fallbacks já instalados.

## Instalação

```bash
csm-stop
```

```bash
cd ~/storage/downloads
```

```bash
unzip -o Crypto_Signals_Multichain_v16.4.0_DANIEL_AI_v1.2.3_CONVERSATIONAL_VOICE_INTELLIGENCE.zip
```

```bash
cd Crypto_Signals_Multichain_CLEAN_v16_4_0_DANIEL_AI_v1_2_3
```

```bash
bash install_termux.sh
```

```bash
python main.py migrate
```

```bash
python main.py db-check
```

```bash
python main.py selftest
```

```bash
bash install_conversational_voice_termux.sh
```

## Testes

```bash
python main.py daniel-voice-status
```

```bash
python main.py daniel-speech-status
```

```bash
python main.py daniel-conversational-voice-status
```

```bash
python main.py daniel-conversational-voice-test
```

O teste cria `daniel_conversational_voice_test.ogg` dentro de `Crypto_Signals_Multichain_State/daniel_ai/voice/tests/` quando o TTS estiver disponível.

## Boot

Troque apenas o diretório da V1.2.2 pela V1.2.3 no `PROJECT` do Termux:Boot. Depois confirme com `grep '^PROJECT=' ~/.termux/boot/10-start-csm`.

Finalize com:

```bash
csm-start
```

```bash
csm-status
```
