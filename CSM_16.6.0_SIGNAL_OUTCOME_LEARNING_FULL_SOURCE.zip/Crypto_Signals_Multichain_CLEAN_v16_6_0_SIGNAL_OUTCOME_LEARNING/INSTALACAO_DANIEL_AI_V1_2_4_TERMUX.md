# Instalação Daniel AI V1.2.4 — Adaptive Conversational Voice

Esta atualização não instala novo modelo pesado. Ela preserva Whisper, Edge Neural PT-BR e fallbacks já configurados.

## Termux

Execute um comando por vez:

```bash
csm-stop
```

```bash
cd ~/storage/downloads
```

```bash
unzip -o Crypto_Signals_Multichain_v16.4.0_DANIEL_AI_v1.2.4_ADAPTIVE_CONVERSATIONAL_VOICE.zip
```

```bash
cd Crypto_Signals_Multichain_CLEAN_v16_4_0_DANIEL_AI_v1_2_4
```

```bash
bash install_termux.sh
```

```bash
python main.py migrate
```

```bash
python main.py db-check
```

```bash
python main.py selftest
```

```bash
bash install_adaptive_voice_termux.sh
```

```bash
python main.py daniel-voice-status
```

```bash
python main.py daniel-speech-status
```

```bash
python main.py daniel-conversational-voice-status
```

```bash
python main.py daniel-conversational-voice-test
```

Depois atualize o `PROJECT` do Termux:Boot de `v1_2_3` para `v1_2_4`, confirme o caminho e reinicie com `csm-start`.

## Teste no Telegram

Teste os três comportamentos:

- “Daniel, me dê um resumo do status operacional.”
- “Daniel, analise esse token e me diga o que realmente importa.”
- “Daniel, me explica por que aconteceu esse erro e o que eu faço agora.”

Para comandos, peça algo como: “Daniel, me explica essa sequência de instalação.” O texto mantém os comandos; o áudio explica as etapas sem ler o terminal linha por linha.
