# Instalação V1.2 no Termux

1. Instale/atualize o pacote principal normalmente.
2. Rode `python main.py migrate`, `python main.py db-check` e `python main.py selftest`.
3. Rode `bash install_speech_termux.sh`.
4. Confirme com `python main.py daniel-speech-status`.
5. Reinicie com `csm-stop` e `csm-start`.
6. Envie uma nota de voz ao bot; ele responderá com texto e, se o TTS estiver pronto, também com áudio.
