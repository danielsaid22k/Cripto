# Instalação — Daniel AI V1.3.0 Daniel Smart

O pacote do projeto é pequeno; o modelo Smart é baixado durante a instalação e ocupa aproximadamente 2,5 GB.

Execute na pasta da release:

```bash
bash install_termux.sh
python main.py migrate
python main.py db-check
python main.py selftest
bash install_daniel_smart_termux.sh
python main.py daniel-smart-status
python main.py daniel-smart-benchmark
```

Depois reinicie o CSM:

```bash
csm-stop
csm-start
csm-status
```

Teste no Telegram com uma pergunta livre que antes caía no fallback, por exemplo:

> Daniel, me explica de forma simples a diferença entre liquidez e volume e por que isso importa para uma memecoin.

Para testar continuidade:

> E nesse caso, qual dos dois você observaria primeiro?

O segundo pedido usa o histórico local recente para manter o contexto.
