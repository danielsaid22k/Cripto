# Estabilidade móvel — v7.1.3

No a-Shell/iOS, o scanner trabalha em modo sequencial para evitar falhas nativas de SSL/threading.

Configurações:

```env
SCAN_PARALLEL_ENABLED=false
SCAN_MOBILE_DELAY_MS=50
```

Em servidores Linux, o paralelismo pode ser habilitado explicitamente com `SCAN_PARALLEL_ENABLED=true`.
No iOS, ele permanece desabilitado por segurança.
