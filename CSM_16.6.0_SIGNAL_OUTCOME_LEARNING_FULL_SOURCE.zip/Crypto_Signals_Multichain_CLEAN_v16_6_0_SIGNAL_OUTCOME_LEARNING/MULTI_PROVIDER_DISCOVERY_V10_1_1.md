# Multi-Provider Discovery v10.1.1

Camada independente de descoberta adicionada ao runtime cooperativo.

## Perfis

- Free: GeckoTerminal + DexScreener.
- Plus: núcleo + Birdeye quando BIRDEYE_API_KEY estiver configurada.
- Premium: núcleo + Birdeye + CoinGecko Onchain quando as respectivas chaves estiverem configuradas.
- Fontes extras por rede são rotacionadas em quantidade limitada por ciclo para preservar o orçamento móvel.

## Segurança operacional

- Nenhuma chave é obrigatória para manter o comportamento anterior.
- As chaves ficam no config.env persistente.
- Logs mascaram BIRDEYE_API_KEY e COINGECKO_API_KEY.
- Uma falha de fonte é isolada pelo ProviderGateway/circuit breaker e não derruba o scanner.
- Toda rede continua passando pelo NetworkBus sequencial: sem threads, subprocessos ou curl.

## Configuração

Execute `python main.py setup` e escolha:

`6 - Configurar fontes Multi-Provider`

Campos:

- MULTI_PROVIDER_ENABLED
- BIRDEYE_API_KEY
- COINGECKO_API_KEY
- MULTI_PROVIDER_DISCOVERY_TTL
- MULTI_PROVIDER_PLUS_CHAIN_SOURCES
- MULTI_PROVIDER_PREMIUM_CHAIN_SOURCES

Depois execute `python main.py doctor`.
