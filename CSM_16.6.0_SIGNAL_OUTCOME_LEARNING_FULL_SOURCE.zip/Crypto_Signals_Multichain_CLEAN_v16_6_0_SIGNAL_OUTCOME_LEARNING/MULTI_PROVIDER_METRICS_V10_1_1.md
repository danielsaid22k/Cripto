# Multi-Provider Metrics v10.1.1

Melhoria de observabilidade do scanner Multi-Provider.

O terminal agora informa, por ciclo:
- candidatos retornados por DexScreener, GeckoTerminal, Birdeye e CoinGecko;
- quantos candidatos realmente foram adicionados depois da deduplicação, no formato `total(+novos)`;
- total de contratos únicos descobertos;
- quantidade analisada e aprovada;
- falhas por fonte com marcador `⚠️`, sem revelar API keys.

Exemplo:
`🌐 Multi-Provider: DexScreener=12(+8) | GeckoTerminal=9(+5) | Birdeye=6(+4) | CoinGecko=4(+1) | únicos=18 analisados=7 aprovados=3`

Nenhuma regra de descoberta, score, plano, pagamento, banco ou entrega automática foi alterada.
