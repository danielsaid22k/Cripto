# V14.5 — Observability & Operations

A V14.5 adiciona telemetria operacional local e cooperativa sem introduzir webhook público, coletor obrigatório, thread de background ou dependência externa de observabilidade.

## Objetivos

- medir saúde do scanner, providers, Telegram e barramento HTTPS;
- registrar latência, taxa de sucesso, erros e sinais enviados;
- detectar rate limit/cota de providers sem confundir com falha de autenticação;
- manter histórico de incidentes com abertura e resolução;
- expor métricas sanitizadas no Admin Dashboard e na SaaS API read-only;
- gerar export JSON ou formato Prometheus/OpenMetrics para uso posterior em VPS;
- preservar operação sequencial no a-Shell e execução contínua no Termux.

## Persistência

Schema 660, aditivo:

- `ops_metrics`: amostras operacionais de baixa cardinalidade;
- `ops_incidents`: incidentes deduplicados, com estado OPEN/RESOLVED;
- `ops_state`: reserva de estado operacional local.

Métricas detalhadas têm retenção configurável. Incidentes resolvidos são retidos por período maior para due diligence.

## Segurança

A camada sanitiza detalhes antes de persistir:

- URLs completas não são registradas nos detalhes de incidentes;
- padrões `api_key`, `token`, `secret` e `access_token` são redigidos;
- nenhuma chave é enviada a serviço externo;
- não existe listener ou webhook público novo.

## Scheduler mobile

O scanner continua com prioridade. A captura de métricas é executada somente em pontos cooperativos seguros, principalmente após uma fatia do scanner e em heartbeat local de baixa frequência.

## Incidentes principais

- scanner abortado;
- provider OFFLINE/DEGRADED/QUOTA_EXHAUSTED;
- latência de provider acima do limite;
- HTTP 429/rate limit/cota detectada;
- falhas de entrega Telegram acima do limite;
- barramento HTTPS ocupado por tempo anormal;
- erros isolados recorrentes do loop.

Incidentes HIGH/CRITICAL podem ser enviados ao administrador pelo Telegram existente, com cooldown. Isso não usa webhook público.

## Comandos

```bash
python main.py observability-status --days 7
python main.py observability-report --days 7 --limit 50
python main.py observability-incidents --open-only --limit 50
python main.py observability-export --days 7 --format json --output csm_observability.json
python main.py observability-export --days 1 --format prometheus --output csm_metrics.prom
```

No a-Shell, use `python3`.

## APIs read-only

Admin:

- `/api/observability`

SaaS:

- `/api/v1/observability`
- `/api/v1/observability/incidents`

## Regra de produto

Observability não altera score de mercado, GoPlus, CSM Confidence, On-Chain Score ou Reputation Score. A função é medir a operação e registrar degradações, não mudar decisões de segurança/trading.
