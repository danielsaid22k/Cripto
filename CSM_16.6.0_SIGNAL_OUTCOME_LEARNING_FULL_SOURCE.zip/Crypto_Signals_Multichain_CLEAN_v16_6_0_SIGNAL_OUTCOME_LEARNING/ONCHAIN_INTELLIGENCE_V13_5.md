# V13.5 — On-Chain Intelligence (Mobile Polling)

A V13.5 adiciona inteligência pós-sinal **sem webhook público**. O mesmo runtime funciona no a-Shell/iOS e no Termux/Android usando somente conexões HTTPS de saída e o NetworkBus sequencial do projeto.

## Contrato mobile

- zero webhook público;
- zero porta de entrada para o monitor on-chain;
- zero subprocesso/worker/thread no caminho ativo do bot;
- no máximo uma requisição HTTPS por sinal em cada fatia cooperativa;
- scanner, Telegram, pagamentos, Performance e Proof têm prioridade sobre o monitor on-chain;
- falha de Helius/RPC não derruba o scanner.

## Solana

Fonte: Helius JSON-RPC por polling.

O monitor usa lotes JSON-RPC limitados para:

- `getTokenSupply`;
- `getTokenLargestAccounts`;
- `getMultipleAccounts` para aproximar concentração por proprietário a partir das maiores token accounts;
- `getSignaturesForAddress` nas maiores token accounts selecionadas e, quando conhecido, no deployer;
- `getTransaction` em lote nos ciclos seguintes para medir variações reais de saldo do mint.

A primeira observação estabelece baseline. Atividade anterior ao baseline não é relabelada como evento pós-sinal. Novas assinaturas são enfileiradas e detalhadas em ciclos posteriores, mantendo uma única ida HTTPS por fatia.

Detecções:

- concentração Top 10;
- grandes transferências de token por delta de saldo;
- movimentação do deployer quando ele participa da transação do token;
- expansão/redução observável de supply;
- atividade nas maiores token accounts.

A cobertura é deliberadamente conservadora: o monitor não afirma enxergar toda transferência do mint em tempo real e não chama uma transferência de “compra” ou “venda” sem contexto DEX suficiente.

## EVM

Redes previstas: Ethereum, BSC, Base, Arbitrum, Polygon, Avalanche, Optimism, Fantom e Cronos.

Cada rede usa uma URL HTTPS JSON-RPC configurada pelo operador. O monitor estabelece um cursor de bloco e depois consulta eventos ERC-20 `Transfer` com `eth_getLogs`, além de `eth_blockNumber` e `decimals()` quando necessário.

Detecções:

- grandes transferências;
- mint/burn representados por endereço zero;
- saída/entrada do deployer quando conhecido;
- wallets envolvidas;
- deterioração de liquidez proveniente do Performance Ledger.

Depois de uma pausa móvel longa, o EVM reestabelece baseline em vez de solicitar um backfill potencialmente enorme a um RPC público.

## On-Chain Score

O `On-Chain Score` é consultivo e pós-sinal. Pode cair por:

- concentração elevada;
- perda relevante de liquidez;
- volume excepcional de grandes transferências;
- expansão observável de supply;
- eventos de deployer de alto risco.

Ele **não altera o `final_score` original**, não libera token reprovado e nunca substitui o GoPlus Security Gate.

## Persistência

Schema ativo 640, com tabelas aditivas:

- `onchain_snapshots`;
- `onchain_events` (append-only);
- `onchain_cursors`;
- `wallet_profiles`.

Eventos são deduplicados por chave determinística. `onchain_events` possui triggers que bloqueiam UPDATE/DELETE.

## Alertas

Plus/Premium podem receber alertas de deterioração HIGH/CRITICAL ou queda de liquidez acima do limiar configurado. Há cooldown; agravamento material pode furar o cooldown. O alerta deixa explícito que é inteligência pós-sinal, não ordem de compra/venda.

## Comandos

```sh
python3 main.py onchain-status --days 30
python3 main.py onchain-report --days 30 --limit 20
python3 main.py onchain-check --chain solana
python3 main.py onchain-check --chain base
python3 main.py onchain-run-once --limit 3
```

No Termux, `python` pode ser usado no lugar de `python3`.
