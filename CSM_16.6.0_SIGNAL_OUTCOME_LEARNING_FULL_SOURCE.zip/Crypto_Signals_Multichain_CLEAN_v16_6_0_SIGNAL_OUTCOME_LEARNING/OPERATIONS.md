# Operação — Phantom Alert v9.0.3

O bot deve ser executado com uma única instância. O Runtime Guard usa sessão + heartbeat. A rede do bot usa uma única fila global de `curl`.

Se o scanner estiver usando a fila, o Telegram pode atrasar alguns segundos até a requisição curta terminar, mas não deve abrir um segundo curl nem mostrar o alerta "Only one curl command at a time".

Diagnóstico:

```sh
python main.py runtime-status
python main.py runtime-recover
python main.py provider-health
```
