# V11.0 — Performance Intelligence

A V11.0 adiciona evidência operacional sem alterar a decisão de segurança do scanner.

## Signal Performance Ledger
Somente sinais confirmados pelo Telegram entram em `signal_ledger`. O registro original mantém preço de entrada, score, GoPlus, liquidez, volume, market cap, source/providers e motivos de aprovação. Distribuições do mesmo evento para vários usuários/planos são consolidadas e `delivered_count` preserva a quantidade de entregas.

## Observações pós-sinal
`signal_observations` é append-only. O monitor usa DexScreener em passos cooperativos, somente quando o scanner está ocioso, e tenta registrar no máximo uma consulta HTTPS por passo. Resultados do próprio scanner são reaproveitados sem nova chamada quando possível.

Métricas: retorno atual, máxima, drawdown, TP1, TP2, stop touch e aproximações auditáveis para 5m, 15m, 1h, 6h, 24h e 7d. Um horizonte só é publicado quando existe observação suficientemente próxima; o sistema não inventa preço histórico perdido.

## Replay / Backtest
`python3 main.py performance-backtest` executa replay **somente sobre sinais que o produto realmente registrou**. Não simula um universo histórico que o scanner nunca viu.

## Adaptive Confidence
O CSM Confidence requer amostra mínima e usa histórico apenas como camada explicativa. `final_score`, filtros de mercado e GoPlus permanecem soberanos e não podem ser removidos pelo histórico. O peso histórico começa em 15% e cresce gradualmente com a evidência, limitado a 30%.

## Strategy A/B
`python3 main.py performance-compare` compara duas políticas de filtro sobre exatamente o mesmo ledger observado. A saída explicita que é replay observacional e não afirma cobrir candidatos que o scanner nunca viu.


## Segmentação analítica
O relatório consolida desempenho por blockchain, provider de descoberta, faixa de score, mês e horizontes 5m/15m/1h/6h/24h/7d. Um mesmo sinal descoberto por vários providers pode contar em mais de um bucket de provider; o total global continua deduplicado pelo evento entregue.
