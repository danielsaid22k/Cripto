# Plan Communication + Smart Realerts v10.1.1

## Objetivo
Deixar explícito que 1/5/15 minutos são intervalos de busca, não promessa de quantidade de sinais, e tornar Plus/Premium mais úteis mesmo sem token novo por meio de realertas inteligentes sem spam.

## Política de novos sinais
- Free: busca a cada 15 min, até 1 nova oportunidade por ciclo.
- Plus: busca a cada 5 min, até 2 novas oportunidades por ciclo.
- Premium: busca a cada 1 min, até 3 novas oportunidades por ciclo.
- Um sinal novo só é enviado se a oportunidade foi aprovada e ainda não foi entregue ao destinatário.
- Sem oportunidade nova aprovada = nenhum sinal novo.

## Acompanhamento
- Todos: TP1, TP2 e stop continuam monitorados. O Free recebe apresentação resumida.
- Plus: realerta quando o score sobe 12+ pontos, volume chega a 2x da referência, nova máxima avança 20%+ ou o risco piora.
- Premium: realerta quando o score sobe 7+ pontos, volume chega a 1,5x, nova máxima avança 10%+ ou o risco piora.
- Após um realerta, a nova condição vira a referência. Pequenas oscilações não geram spam.
- TP/stop sempre têm prioridade sobre um realerta informativo.

## Banco
A migração é aditiva. Novas colunas de referência são criadas automaticamente em `signal_positions`; posições antigas são inicializadas silenciosamente no primeiro ciclo.

## Transparência comercial
As telas de planos, boas-vindas, assinatura, central, sinais automáticos e cartões agora deixam claro que a frequência é de busca e que não existe quantidade mínima garantida.
