# Plan Tier Visual Hotfix — v10.1.1

Ajuste restrito à apresentação dos sinais por plano.

- Free: cartão essencial e alertas de TP/STOP resumidos.
- Plus: níveis técnicos completos, motivos e risco/retorno.
- Premium: raio-X completo e contexto adicional nos alertas de acompanhamento.
- Scanner, filtros, scheduler, banco, Telegram delivery e Asaas não foram alterados por este hotfix.

Validação: suíte completa com 152 testes aprovados usando credenciais Telegram fictícias no ambiente de teste.
