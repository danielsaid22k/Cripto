# Phantom Alert 7.1 — Enterprise Platform

A release 7.1 adiciona uma camada empresarial sobre a base LTS 6.3.0, sem reescrever os módulos críticos.

## Linhas permanentes

- **Core (LTS):** banco, migração, backup, Telegram, Asaas, pagamentos e scanner.
- **Experience:** onboarding, dashboards e identidade visual.
- **Intelligence:** Project Leader, auditoria e simulação de mudanças.
- **Enterprise:** painel administrativo web, assinantes, renovações e observabilidade.

## Painel web

O painel é somente leitura e usa `127.0.0.1:8765` por padrão. Para exposição fora do dispositivo, um token administrativo é obrigatório. Nenhuma chave do Telegram ou Asaas é retornada pela API.

Comando:

```sh
python main.py admin-web
```

Endpoints:

- `/` — dashboard visual;
- `/api/status` — resumo operacional;
- `/api/users` — usuários sem segredos;
- `/api/subscriptions` — assinaturas;
- `/api/events` — eventos de auditoria;
- `/healthz` — verificação simples.

## Auditoria

Eventos administrativos são gravados em `Crypto_Signals_Multichain_State/audit/events.jsonl`.
