# Provider Capability Revalidation — 5 minutos

- HTTP 404 em rota específica pausa apenas provider+rede.
- Revalidação automática após 5 minutos.
- A rede continua ativa nos demais providers.
- Reiniciar o processo também limpa a quarentena temporária.
