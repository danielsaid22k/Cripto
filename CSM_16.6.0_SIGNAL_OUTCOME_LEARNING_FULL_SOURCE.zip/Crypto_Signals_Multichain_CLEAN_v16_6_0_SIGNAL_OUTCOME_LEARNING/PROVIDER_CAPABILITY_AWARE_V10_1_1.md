# Provider Capability-Aware v10.1.1

- HTTP 404 em endpoint específico de provider+rede é tratado como incompatibilidade temporária de capacidade, não como falha global do scanner.
- Apenas a combinação provider+rede é pausada por até 24 horas.
- A rede continua disponível nos demais providers.
- A combinação é revalidada após o TTL ou imediatamente após reiniciar o processo.
- Logs mostram `⏭️[rede: não suportada (revalidação ≤24h)]` em vez de alerta operacional enganoso.
