# Provider Failure Diagnostics v10.1.1

Melhoria de observabilidade sem alterar a lógica de descoberta.

O scanner agora registra por provider e rede uma causa curta para falhas de fonte,
como HTTP 429, HTTP 403, timeout, TLS, JSON inválido, DNS ou erro de rede.
As chaves, URLs completas e payloads não são exibidos na linha operacional.

Exemplo:

`Birdeye=20(+20) ⚠️1[solana: HTTP 429]`

`CoinGecko=0(+0) ⚠️2[base: timeout; ethereum: HTTP 403]`
