# Phantom Alert 8.2 — Provider Intelligence

A v8.2 evolui a camada de providers sem alterar a LTS 6.3.0, schema 600, banco persistente, Telegram, Asaas, pagamentos ou assinaturas.

## Prioridade de fontes

A descoberta usa prioridade explícita e sequencial, adequada ao a-Shell/iOS:
1. GeckoTerminal trending
2. GeckoTerminal novos
3. DexScreener perfis
4. DexScreener boosts

A prioridade organiza a coleta; nenhuma fonte isolada é obrigatória para o funcionamento do scanner.

## Saúde e telemetria

Cada fonte registra estado ONLINE/DEGRADED/OFFLINE, taxa de sucesso, latência, cache, falhas e tempo até nova tentativa. O relatório persistente fica em `Crypto_Signals_Multichain_State/reports/provider_health.json`.

Comando operacional:

```sh
python main.py provider-health
```

## Resiliência

Circuit breaker, backoff, cache e recuperação automática da linha 8.0/8.1 foram preservados. A v8.2 adiciona pontuação de saúde sem modificar a lógica comercial do scanner.
