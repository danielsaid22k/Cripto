# Crypto Signals Multichain v16.4.0 — Smart Reentry + Daniel AI V1.0

Commercial multichain signal platform for **Termux/Android, a-Shell/iOS and Linux/VPS**.

V16.4 preserves Provider Resilience, Scanner Intelligence, Continuous Learning and Signal Lifecycle, then adds plan-aware Smart Reentry. Daniel AI V1.0 consolidates those layers into an Operational Copilot without gaining authority to change scoring or critical configuration.

## V16.4 Smart Reentry

```sh
python main.py smart-reentry --hours 24
```

Cooldowns are Free=24h, Plus=12h and Premium=6h. A token is eligible only when rediscovered and approved again by the current scanner. Previous `STOPPED`, `DETERIORATING` or `TP3` outcomes additionally require material improvement evidence.

## Daniel AI V1.0 Operational Copilot

Telegram examples:

```text
/daniel status operacional
/daniel reentradas nas últimas 24h
/daniel por que CATE foi reenviado?
/daniel quais sinais recuperaram depois de deteriorar?
```

Daniel remains local-first/read-only for critical CSM decisions. OpenAI remains OFF by default.

## Preserved stack

- Multichain discovery: DexScreener, GeckoTerminal, Birdeye, CoinGecko.
- GoPlus contract-security gate.
- Provider Resilience with cooldown/failover.
- Scanner Intelligence with exact rejection reasons.
- Verified Performance / cryptographic Proof.
- Signal Lifecycle: ACTIVE, TP1, TP2, TP3, DETERIORATING, STOPPED, EXPIRED.
- Continuous Learning with provenance/confidence/TTL.
- On-Chain Intelligence and Wallet/Deployer Reputation.
- Observability & Operations.
- SaaS read-only API, V16 Customer Portal and Enterprise Dashboard.
- V15 Distribution Platform with Telegram primary.

## Security model

- Smart Reentry never bypasses current scanner approval or GoPlus.
- Daniel does not change filters, scores, billing, wallets, API keys or safety limits.
- Generic personal questions are not automatically sent to public search.
- Voice transcription is not silently enabled with a paid or heavy dependency.
- Schema 680 and persistent state are preserved.

See `CSM_V16_4_SMART_REENTRY.md`, `DANIEL_AI_V1_0_OPERATIONAL_COPILOT.md`, `CSM_V16_3_SIGNAL_LIFECYCLE.md`, `CSM_V16_2_SCANNER_INTELLIGENCE.md` and `CSM_V16_1_PROVIDER_RESILIENCE.md`.
