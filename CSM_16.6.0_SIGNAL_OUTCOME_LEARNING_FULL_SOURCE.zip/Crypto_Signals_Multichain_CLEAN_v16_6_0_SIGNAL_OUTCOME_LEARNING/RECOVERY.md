# RECOVERY — Recuperação segura

## Bot bloqueado por trava antiga

Primeiro confirme que não existe outra instância. Depois localize a trava:

```sh
find . -name "*.lock" -o -name "*.pid"
```

A proteção da aplicação remove travas órfãs automaticamente. Não apague o banco.

## Banco com problema

```sh
python main.py db-check
python main.py backup-list
python main.py restore-dry-run
```

Restaure somente um backup validado:

```sh
python main.py restore --choose --restore-secrets
python main.py db-check
```

## Telegram ou Asaas não autenticam

```sh
python main.py setup
python main.py doctor
```

As credenciais ficam no estado persistente e não devem ser enviadas a terceiros.

## Falha após atualização

1. Pare o bot.
2. Volte à pasta da versão LTS que estava funcionando.
3. Execute `python main.py db-check`.
4. Use `restore-dry-run` antes de qualquer restauração.
5. Só restaure se o backup contiver o banco e, quando necessário, os segredos.

## Relatórios úteis

```sh
python main.py health-dashboard
python main.py admin-dashboard
python main.py leader-report
python main.py quality-gate
```
