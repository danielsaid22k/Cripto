# Release Notes — v10.1.2 Security & Reliability

## Objetivo

Corrigir problemas observados na profundidade do scanner e reforçar segurança, diagnóstico, persistência e reprodutibilidade sem reescrever o runtime estável.

## Correções principais

1. **Profundidade entre ciclos:** nova rotação de candidatos impede que fatias curtas recomecem sempre na cabeça da mesma fila.
2. **Descoberta multichain pública:** fontes GeckoTerminal do núcleo passam a utilizar feeds globais de pools novos e tendências.
3. **Circuit breaker:** 404 de token/pool não acumula falhas operacionais nem suspende o provider inteiro.
4. **Diagnóstico de filtros:** rejeições agora registram motivo; dados indisponíveis deixam de ser confundidos com erro operacional.
5. **Teste determinístico:** dependências Telegram injetadas em teste não dependem mais de configuração global; `validate.py` usa estado isolado.
6. **Segurança de URL:** tokens e parâmetros sensíveis são removidos de erros/logs.
7. **Atualização segura:** Project Leader copia somente membros declarados e validados no manifesto do ZIP.
8. **Admin web:** headers de segurança reforçados e query token mascarado no audit log.
9. **Persistência:** logs/backups movidos para o estado persistente externo à release.
10. **Identidade de release:** backup e telas operacionais distinguem versão do produto da camada LTS/compatibilidade.

## Compatibilidade

- LTS: 6.3.0;
- schema de compatibilidade: 600;
- schema ativo: 611;
- banco e configuração permanecem em `Crypto_Signals_Multichain_State`;
- runtime ativo continua `phantom_v10`;
- Termux e a-Shell continuam sem concorrência de rede no caminho operacional.

## Homologação

- 189/189 testes;
- três execuções adicionais em estado limpo durante a revisão;
- `python3 validate.py`: aprovado;
- selftest: aprovado;
- SQLite integrity: `ok`;
- release-check: aprovado;
- varredura de credenciais reais: nenhuma encontrada no pacote final.
