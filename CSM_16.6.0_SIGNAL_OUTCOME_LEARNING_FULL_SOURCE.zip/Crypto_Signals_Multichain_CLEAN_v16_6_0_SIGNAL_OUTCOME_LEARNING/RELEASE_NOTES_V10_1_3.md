# Release Notes — v10.1.3 Birdeye & Reliability

Esta revisão corrige a integração Birdeye sem substituir o runtime v10 nem alterar o fluxo já validado de Telegram, Asaas, banco, planos ou scanner cooperativo.

## Causa raiz corrigida

O adaptador v10.1.2 enviava `meme_platform_enabled=false` também para redes EVM. O contrato atual do endpoint Birdeye New Listing define esse filtro como exclusivo de Solana. Em redes como Ethereum, BSC, Base, Polygon, Avalanche, Arbitrum e Optimism, a presença do parâmetro podia resultar em `HTTP 400`.

A v10.1.3 monta os parâmetros por rede: `limit=20` em todas as redes suportadas e `meme_platform_enabled=true` somente para Solana.

## Autenticação e resiliência

Uma chave presente no arquivo de configuração não é mais tratada automaticamente como uma integração saudável. O comando `python3 main.py birdeye-check` primeiro valida a chave em `/defi/networks` e, somente depois, testa `/defi/v2/tokens/new_listing` em Solana. Nenhuma chave é impressa.

Respostas `401` e `403` não usam cache antigo. O Birdeye é pausado temporariamente, enquanto DexScreener, GeckoTerminal e CoinGecko continuam funcionando. As demais rotas Birdeye do mesmo ciclo são descartadas para evitar chamadas repetidas com uma chave rejeitada.

## Compatibilidade preservada

- a-Shell/iOS: runtime sequencial, sem subprocessos/threads no caminho ativo;
- Termux/Android: mesma base de código;
- Free/Plus/Premium: cadências 15/5/1 min preservadas;
- SQLite/schema, usuários, assinaturas e histórico preservados;
- Asaas e Telegram preservados;
- estado persistente permanece em `Crypto_Signals_Multichain_State`.
