# Release Notes — v10.1.4 Birdeye Credential Integrity

## Objetivo

Fechar a ambiguidade entre chave Birdeye ativa e cópias históricas sem alterar o restante do runtime v10 que já estava funcionando.

## Correções

1. **Proveniência da chave** — `python3 main.py birdeye-key-audit` identifica a fonte ativa e apresenta somente fingerprint SHA-256 curta.
2. **Configuração persistente validada** — `config.env` e `.env` local são gravados atomicamente e comparados após o save.
3. **Rotação protegida** — `credential_meta.json` registra apenas a fingerprint da geração atual. Uma chave Birdeye antiga em backup não pode ser restaurada automaticamente após rotação ou limpeza.
4. **Limpeza explícita** — no setup, `-` apaga a chave opcional; Enter mantém a atual.
5. **Diagnóstico real** — `birdeye-check` continua até a rota New Listing mesmo se o probe `/defi/networks` responder 400, exceto 401/403 definitivos.
6. **Resposta do servidor** — mensagens seguras de 400/401/403 são exibidas sem revelar segredo.
7. **Contrato mínimo** — New Listing usa somente `limit` e o header `x-chain`; filtros opcionais foram removidos.
8. **Isolamento preservado** — falha Birdeye não interrompe DexScreener, GeckoTerminal ou CoinGecko.

## Persistência

A fonte operacional continua sendo:

`Crypto_Signals_Multichain_State/config.env`

Backups com segredos podem manter versões históricas por design, mas não têm prioridade sobre a configuração persistente atual.

## Homologação

- 202/202 testes;
- compileall completo;
- selftest OK;
- SQLite `integrity_check=ok`;
- schema 611;
- release-check em estado isolado;
- pacote comercial sem `.env`, `config.env`, banco, logs ou chaves reais.
