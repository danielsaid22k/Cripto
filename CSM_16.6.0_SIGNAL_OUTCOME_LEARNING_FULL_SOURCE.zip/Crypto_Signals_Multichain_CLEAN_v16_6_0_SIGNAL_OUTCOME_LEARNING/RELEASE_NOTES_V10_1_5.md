# Release Notes — v10.1.5 Birdeye CU Guard

Correção orientada ao retorno real do BDS: `Compute units usage limit exceeded`.

## Alterações

- cota de Compute Units esgotada não é mais classificada como chave inválida;
- `birdeye-check` encerra após o probe barato quando detecta CU esgotada, evitando uma segunda chamada New Listing;
- `doctor` informa modo fallback por cota, preservando Telegram, Asaas, DexScreener, GeckoTerminal e CoinGecko;
- scanner reconhece o erro de CU e pausa somente Birdeye por 30 minutos, removendo as demais rotas Birdeye do ciclo atual;
- ProviderGateway não devolve cache antigo quando a conta Birdeye está bloqueada por cota;
- auditoria de credenciais da v10.1.4 permanece intacta: backups históricos podem guardar chaves antigas, mas não são a fonte ativa.

Banco/schema e runtime single-Python permanecem compatíveis.
