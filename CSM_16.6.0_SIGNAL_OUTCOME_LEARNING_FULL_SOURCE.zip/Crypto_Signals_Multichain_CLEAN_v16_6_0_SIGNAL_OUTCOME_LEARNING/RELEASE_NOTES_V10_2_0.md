# Release Notes — v10.2.0 GoPlus Security Layer

- adiciona `phantom_v10/goplus_security.py`;
- integra Token Security EVM e Solana como etapa cooperativa do scanner;
- adiciona bloqueios de risco crítico e score de segurança configurável;
- adiciona `final_score` sem inflar o score de mercado;
- adiciona cache/stale fallback e modos fail-open/fail-closed;
- adiciona `python3 main.py goplus-check`;
- adiciona configuração GoPlus ao setup Multi-Provider;
- adiciona GoPlus aos diagnósticos, scheduler, scanner UI e cards Telegram;
- adiciona redação de `GOPLUS_ACCESS_TOKEN` em logs;
- preserva Birdeye CU Guard, Telegram, Asaas, banco, planos, watchdog iOS e runtime sequencial;
- homologação: **217/217 testes**.
