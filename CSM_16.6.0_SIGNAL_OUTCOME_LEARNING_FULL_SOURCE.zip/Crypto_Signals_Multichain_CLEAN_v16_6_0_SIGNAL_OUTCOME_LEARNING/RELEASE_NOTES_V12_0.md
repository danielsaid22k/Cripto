# Release Notes — v12.0.0 Acquisition Ready

Ordem de evolução aplicada sobre a v10.2.0 estável:

1. **Runtime foundation** — recuperação imediata de sessão cujo PID morreu, inclusive após crash nativo do SSL no a-Shell.
2. **V11.0 Performance Intelligence** — Signal Performance Ledger, observações pós-sinal, horizontes, TP/SL evidence, replay, comparação Strategy A/B e CSM Confidence com peso histórico adaptativo limitado.
3. **V11.5 SaaS Platform** — API read-only autenticada, tenants, API keys hash-only, RPM/daily quotas, white-label, dashboard Overview/Signals/Security/Analytics/System, Docker/systemd.
4. **V12.0 Acquisition Ready** — Buyer Data Room, security scan, inventário, demo sintético isolado e readiness report.

GoPlus, Birdeye CU Guard, DexScreener, GeckoTerminal, CoinGecko, Telegram, Asaas, planos e scanner cooperativo foram preservados.

## Homologação
- 228/228 testes aprovados em estado isolado.
- SELFTEST OK.
- SQLite schema 620 íntegro.
- release-check aprovado.
- security scan do pacote sem padrões de credencial encontrados.
