# Release Notes — v12.0.1 Runtime Lease Recovery

Hotfix de confiabilidade para a-Shell/iOS sobre a v12.0.0 Acquisition Ready.

## Corrigido

- falso bloqueio “Já existe uma sessão saudável do bot” depois de encerramento/queda do Python;
- dependência de PID positivo como sinal indireto de vida no a-Shell;
- recuperação demorada de lock/session com heartbeat ainda recente.

## Novo contrato de liveness

`UDP loopback lease + session id + heartbeat`, com PID apenas como fallback negativo para sessões legadas.

## Preservado

Performance Ledger, Adaptive/CSM Confidence, SaaS/API, white-label, Buyer Data Room, GoPlus, Birdeye, Multi-Provider, Telegram, Asaas, planos Free/Plus/Premium, SQLite schema 620 e compatibilidade LTS.

Além disso, quando o ambiente expõe `SIGINT`, `Ctrl+C` é convertido em pedido de parada cooperativa em vez de levantar `KeyboardInterrupt` arbitrariamente dentro de `ssl.read()`. O caminho antigo de `KeyboardInterrupt` permanece como fallback.
