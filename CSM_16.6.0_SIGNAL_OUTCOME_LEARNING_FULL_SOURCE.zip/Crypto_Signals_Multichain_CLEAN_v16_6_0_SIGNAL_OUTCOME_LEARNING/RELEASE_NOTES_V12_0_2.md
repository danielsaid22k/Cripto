# Release Notes — v12.0.2 a-Shell Crash Recovery

Esta release corrige a falha reproduzida no a-Shell em que um `segmentation fault` durante `ssl.read()` devolvia o prompt, mas a execução seguinte ainda enxergava a sessão anterior como saudável.

## Causa raiz

A v12.0.1 usava uma lease UDP baseada apenas na posse da porta. No a-Shell/iOS, um crash do Python embutido pode retornar ao shell sem destruir imediatamente o processo hospedeiro; um descritor UDP vazado pode continuar ocupando a porta. Portanto `porta ocupada` não prova que o loop Python do bot continua executando.

## Correção v12.0.2

- nova lease `udp-challenge-v2` com nonce `CSM_PING/CSM_PONG`;
- sessão só é considerada viva quando o runtime antigo responde ativamente ao desafio local;
- socket vazado sem Python executando não consegue responder e é recuperado como `lease_sem_resposta`;
- migração segura de sessões v12.0.1 `udp-loopback`: heartbeat antigo (>8s) não fica preso por até 60s só porque a porta continua ocupada;
- `service_lease()` é cooperativo, sem thread, subprocess ou worker;
- desafios são atendidos entre polling Telegram e passos do scheduler;
- heartbeat muito recente recebe janela curta para terminar uma operação HTTPS e responder, evitando falso takeover de uma sessão realmente ativa.

## Ctrl+C e TLS

Quando `signal.pthread_sigmask` está disponível, SIGINT é bloqueado durante a seção crítica HTTPS/TLS. O sinal pendente só é restaurado depois de fechar `HTTPResponse`, `HTTPSConnection` e liberar o `NetworkBus`. Assim Ctrl+C deixa de atingir `ssl.read()` diretamente em builds do a-Shell vulneráveis. O handler cooperativo existente continua como segunda camada/fallback.

## Compatibilidade

- Performance Intelligence preservado;
- SaaS/API e white-label preservados;
- Acquisition Readiness preservado;
- GoPlus, Birdeye, CoinGecko, DexScreener e GeckoTerminal preservados;
- Telegram, Asaas, planos e estado persistente preservados;
- schema SQLite permanece 620, com piso LTS 600.

## Homologação

- 234/234 testes;
- `validate.py` em estado isolado;
- SELFTEST OK;
- SQLite schema 620 íntegro;
- release-check aprovado;
- regressões específicas para socket vazado, lease v12.0.1 presa e proteção SIGINT/TLS.
