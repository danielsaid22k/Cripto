# Release Notes — v13.0.0 Verified Performance

## Base preservada

A V13 parte da v12.0.2 validada no a-Shell e mantém sua recuperação de sessão por UDP challenge/response, além de Performance Intelligence, SaaS/API, Acquisition Ready, GoPlus, Birdeye, Telegram, Asaas e multi-provider.

## Novo

- Proof ID/hash preparado antes do envio Telegram.
- commit inicial contém somente fatos disponíveis no momento do sinal.
- persistência do commit ocorre somente após confirmação da entrega.
- observações posteriores entram como eventos encadeados append-only.
- proteção SQLite contra UPDATE/DELETE das tabelas de evidência.
- detecção de adulteração dos registros-fonte.
- separação explícita `live_commit` × `legacy_backfill`.
- raízes Merkle diárias e selagem de dias encerrados.
- registro opcional de âncoras externas sem custodiar chaves.
- export público sanitizado com verificador offline sem dependências.
- endpoints SaaS read-only para provas e raízes.
- dashboard e Buyer Data Room com evidência verificável.
- componente Proof of Performance no Acquisition Readiness.
- schema ativo 630, mantendo piso LTS 600.

## Segurança de interpretação

A V13 não transforma backfill em prova histórica pre-outcome e não afirma que hash, performance ou readiness garantem retorno financeiro. A ancoragem blockchain é opcional e externa ao runtime.
