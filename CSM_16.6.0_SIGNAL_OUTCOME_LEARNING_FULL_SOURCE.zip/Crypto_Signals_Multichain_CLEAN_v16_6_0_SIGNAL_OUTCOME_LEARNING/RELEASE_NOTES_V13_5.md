# Release Notes — v13.5.0 On-Chain Intelligence

Base: v13.0.0 Verified Performance + runtime crash recovery v12.0.2.

## Novo

- On-Chain Intelligence pós-sinal por polling outbound;
- compatibilidade a-Shell/iOS e Termux/Android sem webhook público;
- Solana/Helius: supply, concentração, maiores token accounts, detalhes de novas transações e atividade do deployer;
- EVM: ERC-20 Transfer logs, whale transfer, mint/burn e deployer movement;
- deterioração de liquidez combinada com Performance Ledger;
- `On-Chain Score` consultivo separado do `final_score`;
- eventos append-only e deduplicados;
- wallet profiles iniciais para o dataset proprietário futuro;
- dashboard, SaaS API, Buyer Data Room e Acquisition Readiness com evidência on-chain;
- CLI `onchain-status`, `onchain-report`, `onchain-check`, `onchain-run-once`;
- redaction de Helius `api-key` e credenciais comuns de RPC hospedado;
- schema ativo 640, piso LTS 600 preservado.

## Segurança e limites de interpretação

- não há private keys de carteira;
- não há auto-trading;
- não há webhook público;
- “whale transfer” é movimentação grande de token, não inferência automática de compra/venda;
- On-Chain Intelligence não vence GoPlus e não muda a decisão original do sinal.
