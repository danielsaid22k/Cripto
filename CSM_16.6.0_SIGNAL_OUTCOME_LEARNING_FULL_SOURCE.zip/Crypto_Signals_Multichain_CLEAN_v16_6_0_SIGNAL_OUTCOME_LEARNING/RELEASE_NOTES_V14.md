# Release Notes — v14.0.0 Wallet/Deployer Reputation

- Dataset próprio de reputação por wallet/deployer.
- Evidências append-only e deduplicadas por hash determinístico.
- Score 0–100 separado de confidence 0–100.
- Outcomes reais do Performance Ledger alimentam reputação do deployer.
- Eventos V13.5 (deployer outflow, mint, supply, liquidity deterioration, whale activity) alimentam evidência local.
- Scanner exibe reputação em Plus/Premium; somente histórico de risco bem evidenciado pode reduzir CSM Confidence.
- `final_score` e GoPlus permanecem intocados.
- Dashboard, SaaS API, Acquisition Readiness e Buyer Data Room ampliados.
- Sem novas APIs, chaves, webhooks, threads ou subprocessos.
- Schema 650; piso de compatibilidade LTS 600 preservado.
