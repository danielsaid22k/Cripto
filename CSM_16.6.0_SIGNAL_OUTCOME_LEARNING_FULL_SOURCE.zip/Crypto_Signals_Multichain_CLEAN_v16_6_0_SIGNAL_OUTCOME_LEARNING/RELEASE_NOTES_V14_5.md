# Release Notes — V14.5.0 Observability & Operations

Base: V14.0.0 Wallet/Deployer Reputation.

## Adicionado

- ObservabilityEngine local/cooperativo;
- schema 660 com métricas e incidentes;
- health score operacional 0–100;
- telemetria do scanner e tempo ativo excluindo suspensão iOS;
- métricas de provider (latência, sucesso e falhas);
- detecção de rate limits/cotas;
- métricas de entrega Telegram;
- detecção de barramento HTTPS preso;
- alertas administrativos HIGH/CRITICAL com cooldown;
- Admin Dashboard `/api/observability`;
- SaaS API `/api/v1/observability` e `/api/v1/observability/incidents`;
- export JSON e Prometheus/OpenMetrics local;
- Buyer Data Room com relatórios operacionais;
- setup opção 9;
- retenção/pruning de métricas detalhadas;
- sanitização de URLs e segredos em incidentes.

## Compatibilidade

- Android / Termux;
- iPhone / a-Shell;
- sem webhook público;
- sem thread/subprocess na nova camada;
- scanner permanece prioritário e sequencial no mobile.

## Qualidade

Também foi corrigido um teste probabilístico legado: o teste de falha Telegram usava a substring `BAD` em toda a mensagem, podendo colidir aleatoriamente com o hash do Proof V13. A lógica de produção não foi alterada por essa correção de teste.
