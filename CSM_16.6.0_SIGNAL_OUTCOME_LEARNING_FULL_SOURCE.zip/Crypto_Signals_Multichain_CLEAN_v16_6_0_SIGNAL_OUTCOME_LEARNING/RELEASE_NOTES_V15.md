# Release Notes — V15.0.0 Distribution Platform

Built additively on V14.5 Observability & Operations.

## Added
- Telegram-first outbound distribution orchestration.
- Signed HMAC-SHA256 webhooks/API push.
- Discord webhook channel.
- SMTP email channel.
- Persistent idempotent queue and dead-letter handling.
- Append-only distribution attempt ledger.
- Cooperative mobile scheduler (one outbound job per idle step).
- Sanitized SaaS/Admin/Buyer Data Room distribution visibility.
- Secret targets stored outside SQLite.
- Secret-bearing backup/restore support for outbound destination credentials.
- Setup option 10 for Distribution Platform / SMTP.
- Schema 670.

## Preserved
- V14 Wallet/Deployer Reputation.
- V13.5 On-Chain Intelligence without public webhooks.
- V13 Verified Performance.
- V14.5 local observability.
- GoPlus, Birdeye, CoinGecko, DexScreener, GeckoTerminal.
- Telegram plans/payments and a-Shell crash recovery.
