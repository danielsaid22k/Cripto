# Release Notes — V16.0.0 Customer Portal & Enterprise Dashboard

Built additively on V15.0 Distribution Platform.

## Added

- Customer Portal served by the existing SaaS API at `/portal`.
- Tenant entitlement plans: Free / Plus / Premium / Enterprise.
- Entitlement feature gates for SaaS API endpoints.
- Backward-compatible migration: pre-V16 tenants retain Enterprise-equivalent API capabilities.
- Tenant ↔ local Telegram user linking.
- Fail-open automatic entitlement sync after local plan/payment changes.
- Append-only entitlement event history.
- Portal usage/quota, subscription, signal and performance views.
- Enterprise-only consolidated API dashboard.
- Existing admin Enterprise Center now includes SaaS tenant/entitlement/usage summary.
- Setup option 11 for Customer Portal & Enterprise Dashboard.
- Buyer Data Room / acquisition API contract updated for V16.
- Schema 680.

## Preserved

- V15 outbound Distribution Platform / Discord / HMAC / e-mail.
- Telegram as primary signal delivery.
- V14.5 Observability.
- V14 Wallet/Deployer Reputation.
- V13.5 On-Chain Intelligence without public inbound webhooks.
- V13 Proof of Performance.
- GoPlus security authority and market scoring semantics.
- a-Shell single-Python bot runtime and Termux operation.
