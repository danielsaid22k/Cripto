# Processo de Release

1. `python main.py migrate`
2. `python main.py db-check`
3. `python main.py selftest`
4. `pytest -q`
5. `python main.py backup --include-secrets`
6. `python main.py restore-dry-run`
7. `python main.py foundation-release`
8. `python main.py release-summary`
9. Somente com **APROVADO**, iniciar `python main.py bot`.

O `foundation-release` remove automaticamente artefatos descartáveis antes e depois dos testes.
