# Phantom Alert 8.2.2 — Release & Recovery

Esta versão preserva a LTS 6.3.0 e o schema 600.

## Correções

- Novo Release Engine para a-Shell, sem abrir um segundo processo Python para executar pytest.
- O `foundation-release` usa `pytest.main()` no próprio processo, reproduzindo o caminho que passou 74/74 no iPhone.
- Saída completa dos testes é salva no relatório de release.
- Novo `config-recover`: recupera `config.env` do backup mais recente com segredos.
- Recuperação é conservadora: valores atuais não vazios nunca são sobrescritos; apenas chaves ausentes/vazias são preenchidas.
- `migrate` e `bot` executam a recuperação segura antes de iniciar, quando houver backup compatível.

## Segurança

O pacote não inclui tokens, carteiras, banco pessoal nem `config.env`. O estado persistente continua em `Crypto_Signals_Multichain_State`.
