> **Superado pela v12.0.2:** o teste real no a-Shell mostrou que uma porta UDP pode permanecer ocupada após crash do Python embutido. A autoridade ativa agora é challenge/response, documentada em `ASHELL_CRASH_RECOVERY_V12_0_2.md`.

# v12.0.1 — a-Shell Runtime Lease Recovery

## Causa raiz reproduzida

No a-Shell/iOS, `os.kill(pid, 0)` não é uma prova suficiente de que **aquela execução Python** do bot continua viva. A identidade de processo pode permanecer válida ou ser reutilizada enquanto o heartbeat JSON deixado pela execução anterior ainda está fresco. Isso reproduziu o falso aviso “Já existe uma sessão saudável do bot” depois de o usuário já ter parado o bot.

## Correção

Cada `RuntimeGuard` v12.0.1 abre um socket UDP em `127.0.0.1` numa porta efêmera e salva a porta no lock/session. O socket fica aberto durante toda a execução do bot.

- runtime vivo: a porta continua ocupada e uma segunda execução é bloqueada;
- runtime encerrado/crashado: o sistema operacional fecha o descritor e a porta volta a ser bindável imediatamente;
- heartbeat recente + porta livre: o estado anterior é arquivado como `lease_liberada` e a nova sessão inicia sem esperar o timeout;
- sessões antigas, sem campo `lease`, continuam usando heartbeat + PID negativo como fallback de compatibilidade.

A lease não abre serviço externo, não aceita tráfego de rede público e fica restrita a loopback local.

## Testes adicionados

1. duas instâncias: a segunda é bloqueada enquanto a primeira mantém a lease;
2. heartbeat fresco + PID artificialmente “vivo” + lease liberada: recuperação imediata;
3. `runtime-status`: expõe `lease_alive` e `lease_port`;
4. simulação por processos reais: após `SIGKILL` do holder, nova instância recupera em ~1 s com heartbeat ainda fresco.

Além disso, quando o ambiente expõe `SIGINT`, `Ctrl+C` é convertido em pedido de parada cooperativa em vez de levantar `KeyboardInterrupt` arbitrariamente dentro de `ssl.read()`. O caminho antigo de `KeyboardInterrupt` permanece como fallback.
