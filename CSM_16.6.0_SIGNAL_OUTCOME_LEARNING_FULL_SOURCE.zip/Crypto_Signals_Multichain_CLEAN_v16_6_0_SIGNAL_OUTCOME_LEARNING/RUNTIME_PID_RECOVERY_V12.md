> **Superado pela v12.0.1:** o teste real no a-Shell mostrou que PID positivo pode permanecer/reutilizar identidade. A autoridade ativa passou a ser a UDP runtime lease descrita em `RUNTIME_LEASE_RECOVERY_V12_0_1.md`. Este arquivo fica apenas como histórico da tentativa anterior.

# V12 — a-Shell Dead-PID Recovery

Problema observado: um `segmentation fault` nativo dentro do SSL do a-Shell podia matar o processo e deixar lock/session com heartbeat recente. Durante a janela de 60 s, uma nova inicialização interpretava esse arquivo recente como sessão saudável.

Correção: o RuntimeGuard continua exigindo session id + heartbeat, mas usa o PID como **autoridade negativa**. Se `kill(pid, 0)` prova que o processo não existe (`ESRCH`), a sessão é arquivada imediatamente como `processo_ausente`, mesmo com heartbeat recente. Se o iOS não permite determinar PID, o sistema volta ao heartbeat, preservando compatibilidade.

Em `Ctrl+C` capturado pelo Python, o heartbeat passa a `stopping` antes da liberação. Em crash nativo, a próxima execução recupera automaticamente pelo dead PID.
