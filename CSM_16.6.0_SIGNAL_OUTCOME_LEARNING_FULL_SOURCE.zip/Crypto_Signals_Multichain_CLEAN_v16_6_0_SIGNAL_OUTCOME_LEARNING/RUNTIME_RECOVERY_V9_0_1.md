# Phantom Alert v9.0.1 — Runtime Recovery

Correção de estabilidade da reconstrução v9 para a-Shell/iOS.

## Problemas reproduzidos na v9.0.0

- sessão anterior podia permanecer marcada como `running` após o a-Shell interromper o bot;
- `os.kill(pid, 0)` podia continuar indicando PID existente e não era uma prova confiável de que o PID ainda pertencia ao bot;
- o último heartbeat ficava congelado em `scanner_phase=discover`;
- o scanner usava `subprocess.run`, portanto uma anomalia do processo `curl` podia prender a etapa até o runtime do a-Shell se recuperar.

## Reconstrução v9.0.1

- `runtime_v901.py`: autoridade de liveness = **session + heartbeat**. PID é somente diagnóstico;
- locks/sessões expirados ou inconsistentes são arquivados automaticamente com sufixo `.stale...`;
- stale-after curto e explícito para recuperação rápida após fechamento/crash;
- `last_progress_at` separado do heartbeat;
- `network_v901.py`: scanner usa `Popen + poll`, sem `subprocess.run`, `wait()` ou `communicate()`;
- stdout/stderr do curl são arquivos temporários pequenos, evitando pipes bloqueantes;
- deadline rígido de rede; se curl não encerra, o ciclo é abortado e o Telegram continua no loop;
- `scanner_v901.py`: watchdog de ciclo/fase e máquina de estados não bloqueante;
- `app_v901.py`: rede automática de fundo restrita à lane segura do scanner; monitor de posições usa apenas cache no a-Shell;
- `runtime-recover`: diagnóstico/recuperação manual opcional. O `bot` já recupera stale state automaticamente.

## Estado persistente

Nenhum token, carteira, API, banco, usuário ou assinatura é movido para a pasta da release. A versão continua usando `Crypto_Signals_Multichain_State` e o contrato LTS 6.3.0 / schema 600.
