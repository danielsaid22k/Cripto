# V11.5 — SaaS Platform

## API comercial read-only
Comando: `python3 main.py saas-api --host 127.0.0.1 --port 8787`.

Autenticação por `Authorization: Bearer csm_live_...` ou `X-API-Key`. Chaves completas são mostradas uma única vez; o SQLite guarda apenas SHA-256, prefixo público e limites.

Endpoints principais:
- `GET /healthz`
- `GET /api/v1/status`
- `GET /api/v1/signals`
- `GET /api/v1/signals/{id}`
- `GET /api/v1/performance`
- `GET /api/v1/providers`
- `GET /api/v1/security/{chain}/{address}`
- `GET /api/v1/branding`

Tenants têm keys próprias, RPM e cota diária. Provisionamento/revogação fica deliberadamente fora da API pública e exige CLI administrativa local.

## White-label
`brand-set` grava `branding.json` no estado persistente. Nome, título Telegram, emoji, suporte e textos comerciais podem mudar sem alterar fonte. O branding é usado em sinais, pagamentos, painel e API.

## Deploy
A release inclui Dockerfile, Docker Compose e modelos systemd. Em ambiente público a API deve ficar atrás de HTTPS/reverse proxy.

## Dashboard profissional
O `admin-web` existente foi ampliado para exibir Overview, sinais do Performance Ledger, snapshots GoPlus, analytics por rede e saúde operacional. Endpoints adicionais: `/api/signals`, `/api/security` e `/api/system`. O painel continua somente leitura.


## V13.5 On-Chain read-only endpoints

- `GET /api/v1/onchain?days=30&limit=100` — snapshots + resumo + perfis de wallets.
- `GET /api/v1/onchain/{signal_id}` — snapshots e eventos append-only de um sinal.
- `GET /api/v1/onchain-wallets?limit=100` — perfis on-chain derivados.

A API continua read-only. O monitor mobile não depende desta API e não usa webhooks públicos.
