# Security Audit — v10.1.2

## Escopo

Revisão estática e regressiva dos 160 arquivos Python do pacote, incluindo runtime ativo, compatibilidade, configuração, scanner, providers, Telegram, painel web, persistência, backup/restore e mecanismo de atualização.

## Correções aplicadas

### Segredos em URLs

`NetworkHTTPError` sanitiza a URL antes de armazená-la ou renderizá-la. Tokens embutidos no caminho do Telegram e parâmetros como `token`, `access_token`, `api_key`, `key` e `secret` são mascarados.

### Painel administrativo

Adicionados `Referrer-Policy: no-referrer`, `Cross-Origin-Resource-Policy: same-origin`, `Permissions-Policy` e CSP para HTML. O token em query string continua aceito por compatibilidade, mas é redigido antes de entrar no audit log.

### Pacotes de atualização

`ProjectLeader.apply_update_bundle()` não usa mais `ZipFile.extractall()`. Somente arquivos presentes em `update-manifest.json`, com caminho seguro e SHA-256 previamente validado, são copiados ao projeto. Um teste de regressão inclui membro ZIP malicioso não listado e confirma que ele não é extraído.

### Provider breaker

HTTP 404 é tratado como miss/capacidade: não derruba circuit breaker de outros tokens e não impede tentativas posteriores válidas.

### Pacote comercial

A release final exclui `.env`, SQLite, logs, backups de teste, `__pycache__`, `.pytest_cache` e ZIPs internos. `.env.example` mantém campos sensíveis vazios.

## Limites de segurança

- Este projeto não deve registrar nem publicar tokens reais.
- `ADMIN_WEB_TOKEN` é obrigatório quando o painel web deixa de usar loopback.
- Backups com `--include-secrets` devem ser tratados como arquivos confidenciais.
- O scanner produz sinais informativos; não elimina risco de mercado ou de smart contract.
