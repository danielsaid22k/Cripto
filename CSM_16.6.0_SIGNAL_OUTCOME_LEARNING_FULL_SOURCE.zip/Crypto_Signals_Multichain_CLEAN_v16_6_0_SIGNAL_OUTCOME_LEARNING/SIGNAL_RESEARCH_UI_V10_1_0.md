# Signal Research UI — v10.1.0

## Objetivo

Apresentar sinais legíveis no Telegram, corrigir metadados incompletos e
entregar profundidade coerente com cada plano sem aumentar a concorrência de
rede do a-Shell.

## Planos

- Grátis: ciclo de 15 minutos, resumo de mercado, entrada, stop e TP1/TP2.
- Plus: ciclo de 5 minutos, contexto, estágio, motivos e risco/retorno.
- Premium: ciclo de 1 minuto, todos os campos públicos normalizados disponíveis,
  múltiplos períodos, atividade, pressão, FDV, DEX, idade, proporções,
  composição do score, riscos e qualidade dos dados.

## Metadados e preços

O GeckoTerminal é consultado com `include=base_token,quote_token,dex`. O token
solicitado é identificado pelo endereço, e o preço utiliza `token_price_usd`.
Quando a fonte não fornece metadados, o nome do pool é usado como fallback
seguro, impedindo que o Telegram exiba apenas `?`.

O cache de mercado usa uma chave separada por provider, rede e contrato. Assim,
uma consulta ou ciclo do scanner não pode entregar temporariamente os dados da
moeda consultada anteriormente.

## Alertas de acompanhamento

TP1, TP2 e stop mostram símbolo, rede, contrato, entrada, preço atual, máxima
observada, stop inicial, dois alvos e frequência do plano. Os textos deixam
explícito que se trata de cenário educacional e que pode haver slippage.

## Contratos preservados

- um único processo Python;
- zero curl/subprocess/threads no runtime ativo;
- HTTPS sequencial da biblioteca padrão;
- scanner cooperativo;
- checkpoint persistente de updates do Telegram;
- LTS 6.3.0 e schema 600.
