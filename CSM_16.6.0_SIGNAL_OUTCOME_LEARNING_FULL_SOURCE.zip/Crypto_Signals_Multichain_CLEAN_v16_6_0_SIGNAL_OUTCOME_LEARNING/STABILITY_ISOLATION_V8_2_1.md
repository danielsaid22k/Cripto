# Phantom Alert 8.2.1 — Stability Isolation

Hotfix estrutural criado após falha nativa observada no a-Shell/iOS em `http_client -> market -> scanner`.

## Princípio

Os arquivos congelados da LTS, incluindo `csm/scanner.py`, não foram reescritos. A correção foi implementada em arquivos novos e conectada por uma camada fina de integração.

## Arquivos novos

- `csm/scanner_worker_v821.py` — executa a lógica de scan em processo descartável.
- `csm/scanner_isolation_v821.py` — cliente/proxy do scanner isolado.
- `csm/scanner_supervisor_v821.py` — backoff e recuperação do worker.
- `csm/market_worker_v821.py` — consulta de mercado em processo descartável.
- `csm/market_isolation_v821.py` — proxy compatível com `MarketClient.fetch`.
- `csm/runtime_guard_v821.py` — nova trava/heartbeat em namespace próprio.
- `csm/stability_status_v821.py` — diagnóstico de heartbeat e isolamento.

## Comportamento diante de SIGSEGV

Se um worker de scanner ou mercado sofrer falha nativa, o processo principal do Telegram não executa aquela chamada nativa. O ciclo é descartado, entra em backoff e o bot permanece online.

Não existe fallback inline para o scanner quando o worker falha. Isso é intencional: perder um ciclo é preferível a derrubar o serviço.

## Estado persistente

Telegram, APIs, carteiras, banco, assinaturas e backups continuam sendo lidos do diretório persistente já existente. Nenhum segredo é incluído no pacote.
