# Stable Maintenance 8.1.1

Esta release transforma a Foundation RC2 aprovada em uma linha Stable operacional.

Principais mudanças:
- limpeza automática de artefatos;
- diagnóstico do Quality Gate;
- resumo de release;
- persistência do relatório real da execução;
- nenhuma alteração nos módulos congelados da LTS.
