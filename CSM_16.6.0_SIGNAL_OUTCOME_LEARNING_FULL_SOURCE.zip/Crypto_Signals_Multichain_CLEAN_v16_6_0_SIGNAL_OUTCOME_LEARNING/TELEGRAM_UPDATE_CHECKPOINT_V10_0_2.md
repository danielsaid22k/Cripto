# Telegram Update Checkpoint — v10.0.2

## Erro reproduzido

Na v10.0.1, `PhantomApp.run()` começava com `offset = None`. Quando `/encerrar` era recebido, o loop calculava `update_id + 1`, mas encerrava antes de uma nova chamada `getUpdates(offset=...)`. Pela semântica do Telegram Bot API, o update anterior só é confirmado quando uma chamada posterior usa um offset maior que o `update_id`. Assim, o mesmo `/encerrar` podia reaparecer no próximo processo e desligar o bot imediatamente.

## Correção

- O próximo offset processado é persistido atomicamente fora da pasta da release, no diretório de estado.
- O checkpoint inclui `bot_id`; um bot diferente não herda offsets de outro token.
- O checkpoint é carregado no bootstrap e usado na primeira chamada `getUpdates`.
- O offset só é salvo depois de o update ser roteado com sucesso.
- Ao receber uma parada segura atual, o runtime salva o checkpoint e tenta confirmar o offset no Telegram antes de sair.
- Comandos de lifecycle antigos que precedem o processo atual são ignorados, permitindo a primeira inicialização da v10.0.2 limpar o `/encerrar` pendente deixado pela v10.0.1 sem desligar novamente.

## Contratos preservados

- um único processo Python;
- zero curl/subprocess/threads do projeto;
- HTTPS stdlib sequencial;
- scanner cooperativo;
- session+heartbeat como autoridade de liveness;
- schema 600 e estado persistente preservados.
