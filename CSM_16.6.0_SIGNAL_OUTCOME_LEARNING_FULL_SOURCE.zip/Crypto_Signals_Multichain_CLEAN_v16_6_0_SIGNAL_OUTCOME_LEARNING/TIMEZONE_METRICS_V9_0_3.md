# v9.0.3 — Timezone Metrics Hotfix

Correção crítica compatível com LTS 6.3.0/schema 600.

## Problema reproduzido no a-Shell
SQLite grava `CURRENT_TIMESTAMP` em UTC. A consulta de métricas comparava `date(created_at)` (UTC) com `date('now','localtime')` (dia local). Em fusos negativos, no período entre 21:00 e 00:00 local, o UTC já está no dia seguinte e o ciclo recém-gravado desaparecia do relatório diário.

## Correção
A consulta agora compara:

```sql
date(created_at,'localtime') = date('now','localtime')
```

O schema não muda e dados existentes continuam compatíveis.

Também foi corrigido o comando `runtime-recover` para instanciar `RuntimeGuardV902`.
