# Phantom Alert v8.3.0 — UI Complete Integration

Objetivo: nenhum botão sem rota e nenhuma divergência entre teclado de resposta e callbacks inline.

- Registro central de callbacks (`csm/ui_registry_v830.py`).
- Auditoria automatizada (`python main.py ui-audit`).
- Router v8.3 valida callbacks antes do dispatch.
- `Minha Central` do teclado de resposta usa a mesma Central v2 local/fail-safe do callback inline.
- Scanner assíncrono v8.3 sempre executa `wait()` para recolher workers finalizados e reduzir acúmulo de interpretadores no a-Shell.
- LTS 6.3.0 e schema 600 preservados.
