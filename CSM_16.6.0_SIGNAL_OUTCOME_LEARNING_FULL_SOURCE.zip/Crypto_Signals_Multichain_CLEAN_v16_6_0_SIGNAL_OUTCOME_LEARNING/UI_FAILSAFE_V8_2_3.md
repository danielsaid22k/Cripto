# v8.2.3 — UI Fail-Safe & Responsive Scanner

Esta release preserva a LTS 6.3.0 e o schema 600.

## Mudanças

- `csm/central_v823.py`: nova Minha Central baseada exclusivamente em dados locais/persistentes. Não consulta providers nem scanner.
- `csm/ui_guard_v823.py`: confirmação de callback com timeout curto e uma única tentativa, evitando indicador "Carregando..." prolongado.
- `csm/scanner_worker_v823.py`: worker novo de scanner com protocolo por arquivos e heartbeat.
- `csm/scanner_async_v823.py`: coordenador não bloqueante. O loop do Telegram não espera o scanner terminar.
- `phantom/release/engine_v823.py`: recibo de testes vinculado ao fingerprint do código. Evita divergência entre teste aprovado e segunda execução em estado diferente.
- Novo comando `release-tests`.

## Compatibilidade

Telegram, APIs, carteiras, banco, assinaturas e segredos continuam no diretório persistente e não são incluídos no pacote.
