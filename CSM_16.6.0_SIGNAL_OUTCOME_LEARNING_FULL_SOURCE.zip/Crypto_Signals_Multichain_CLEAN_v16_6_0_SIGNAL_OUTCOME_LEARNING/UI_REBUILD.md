# UI Rebuild 7.1.3

The Telegram callback transport, callback router and preferences screen were rebuilt as separate modules.

- `csm/telegram.py`: callback acknowledgement retry and edit-or-send fallback.
- `csm/ui_callbacks.py`: isolated callback routing.
- `csm/preferences_ui.py`: deterministic preferences screen.
- Preferences open as a new message to avoid stale edit/loading states on Telegram for iOS.
- LTS core remains 6.3.0.
