# Upgrade para v16.0.0 Customer Portal & Enterprise Dashboard

A migração atual é aditiva: schema **670 → 680**. Não apague `Crypto_Signals_Multichain_State`.

1. Extraia a nova release em uma pasta nova.
2. Execute o instalador do ambiente.
3. `python main.py setup` (ou `python3` no a-Shell).
4. Opção 10 configura Distribution/SMTP; destinos individuais são criados por CLI.
5. `python main.py migrate`
6. `python main.py db-check`
7. `python main.py doctor`
8. `python main.py selftest`
9. `python main.py distribution-status --days 7`
10. Inicie o bot normalmente.

Telegram continua funcionando mesmo se nenhum destino V15 for configurado.

## V15 → V16

1. Stop `csm-bot` and `csm-api` before replacing the release folder.
2. Preserve `Crypto_Signals_Multichain_State`.
3. Install V16 and run `python main.py migrate`; schema advances additively to 680.
4. Existing SaaS tenants receive Enterprise-compatible entitlement to avoid capability loss.
5. Run `python main.py entitlement-status --tenant crypto-signals`.
6. Restart bot and SaaS API. The Customer Portal is available at `/portal`.
7. If Termux:Boot points to a versioned folder, update the `PROJECT=` path to the V16 folder.

## V16.0.0 → V16.0.0 + Daniel AI V0.1.0

Esta atualização não altera o schema principal (permanece 680) e não exige apagar ou
mover `Crypto_Signals_Multichain_State`.

1. Pare o bot atual.
2. Extraia esta release em `Crypto_Signals_Multichain_CLEAN_v16_0_0_DANIEL_AI_v0_1_0`; ela fica ao lado da V16 anterior.
3. Execute `./install_termux.sh` (ou instalador a-Shell).
4. Execute `python main.py migrate`, `db-check`, `doctor` e `selftest`.
5. Execute `python main.py daniel-status`; confirme `OpenAI: OFF`.
6. Inicie o bot desta nova pasta.
7. Somente depois de validar, atualize o Termux:Boot/atalho `csm-start` para esta pasta.
8. Em caso de problema, pare a nova release e volte o caminho do boot para a pasta V16 anterior.

O banco do Daniel AI fica separado em `Crypto_Signals_Multichain_State/daniel_ai/daniel_ai.db`.
