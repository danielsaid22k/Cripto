# Verified Performance — V13.0

## Objetivo

Criar evidência tecnicamente verificável de que um sinal foi comprometido antes de seus resultados futuros, preservando a distinção entre prova criptográfica, performance observada e resultado financeiro.

## Estados de commit

- `live_commit`: snapshot preparado antes do envio e persistido após confirmação da entrega.
- `legacy_backfill`: sinal anterior/incorporado posteriormente; útil para continuidade, mas não prova preexistência antes do resultado.

Nunca há promoção automática de `legacy_backfill` para `live_commit`.

## Conteúdo do commit inicial

O snapshot usa apenas fatos disponíveis no instante do sinal: identificador lógico, horário, chain, contrato, símbolo/nome e métricas/score presentes no item. Observações futuras não entram nesse hash.

O JSON é serializado de forma canônica (`sort_keys`, separadores compactos, sem NaN) e recebe SHA-256.

## Eventos posteriores

Cada observação recebe seu próprio payload e hash. O `previous_hash` encadeia os eventos do mesmo sinal. UPDATE e DELETE nas tabelas de prova são bloqueados por triggers SQLite.

A verificação também compara o snapshot comprometido com os registros-fonte. Alterar posteriormente o preço original ou uma observação faz a auditoria falhar.

## Merkle diário

Os hashes dos eventos de um dia UTC formam uma raiz Merkle. Dias encerrados podem ser selados. A raiz cria uma impressão digital compacta do lote; ela não substitui os eventos individuais.

## Ancoragem externa

O CSM permite registrar `chain`, `txid` e URL de uma raiz já publicada. Ele não guarda seed/private key e não assina transação de ancoragem automaticamente.

## Export público

```sh
python3 main.py proof-export --days 30 --output proof_bundle.zip
```

O bundle não contém banco de produção, Telegram token, chaves de providers, Asaas, PII ou `config.env`. O verificador `verify_proofs.py` roda offline com Python padrão.

## Verificação operacional

```sh
python3 main.py proof-status
python3 main.py proof-verify --days 30
python3 main.py proof-verify --signal-id 123
```

Um resultado `ok=true` significa que a cadeia e os snapshots cobertos pela verificação permanecem consistentes. Não significa garantia de lucro nem auditoria financeira independente.
