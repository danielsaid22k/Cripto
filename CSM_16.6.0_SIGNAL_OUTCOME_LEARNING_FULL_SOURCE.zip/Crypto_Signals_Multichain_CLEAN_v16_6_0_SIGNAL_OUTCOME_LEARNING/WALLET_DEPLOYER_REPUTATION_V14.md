# V14 — Wallet/Deployer Reputation Engine

## Objetivo
Transformar o histórico real da V13/V13.5 em um dataset proprietário de reputação de wallets e deployers, sem chamadas de rede adicionais e sem webhooks públicos.

## Fontes de evidência
- eventos append-only da On-Chain Intelligence;
- TP1/TP2/stop e drawdown observados no Performance Ledger;
- mint/supply, liquidity deterioration e movimentação de deployer quando vinculáveis.

## Modelo
Cada evidência recebe tipo, origem, referência determinística, peso, severidade e horário. O registro é imutável por triggers SQLite. A reputação atual é derivada da soma das evidências e materializada em cache.

**Score e confiança são diferentes.** Uma wallet com uma única evidência pode ter score alto/baixo, mas continua `UNPROVEN` até acumular amostra.

Ratings: `UNPROVEN`, `STRONG`, `POSITIVE`, `NEUTRAL`, `CAUTION`, `HIGH_RISK`.

## Regra de segurança
- nunca altera `final_score`;
- nunca vence GoPlus;
- reputação positiva nunca infla CSM Confidence;
- reputação negativa só reduz CSM Confidence quando a confiança da amostra atinge o mínimo configurado.

## Mobile
O motor é SQLite-only: zero chamadas HTTPS, zero threads, zero subprocessos e zero webhooks. A consolidação ocorre atrás das tarefas de scanner/performance/on-chain.

## Comandos
```sh
python3 main.py reputation-status
python3 main.py reputation-refresh --days 3650 --limit 1000
python3 main.py reputation-report --days 3650 --limit 20
python3 main.py reputation-lookup --chain base --address 0x...
```

## SaaS / Data Room
Endpoints read-only:
- `GET /api/v1/reputation`
- `GET /api/v1/reputation/{chain}/{address}`

O Buyer Data Room inclui status e relatório sanitizados de reputação, sem PII ou credenciais.
