# Watchdog iOS Hotfix — v10.1.1

## Problema corrigido

O relógio monotônico do iPhone continua avançando quando o iOS suspende o
a-Shell em segundo plano. Ao abrir o Telegram durante um ciclo, a v10.1.0 podia
somar o tempo suspenso aos 120 segundos do watchdog e exibir uma degradação
falsa, mesmo sem erro do scanner ou dos providers.

## Correção

- o scanner mantém um relógio cooperativo próprio;
- intervalos normais entre passos continuam contando para o orçamento;
- pausas longas, incompatíveis com os timeouts curtos da rede, são classificadas
  como suspensão do iOS e excluídas do tempo ativo;
- o diagnóstico registra quantidade e duração das suspensões;
- o watchdog rígido permanece reservado para excesso de tempo realmente ativo;
- não foram adicionados threads, subprocessos, `curl`, `requests` ou outro
  runtime paralelo.

## Preservação

A mudança não altera schema, banco, usuários, assinaturas, histórico,
favoritos, chaves, planos, dez redes nem níveis de entrada/stop/take profit.
O estado continua compartilhado em `Crypto_Signals_Multichain_State`.
