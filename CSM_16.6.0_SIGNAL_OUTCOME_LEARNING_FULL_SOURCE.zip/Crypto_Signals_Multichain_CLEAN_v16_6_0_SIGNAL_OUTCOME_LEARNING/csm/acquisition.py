from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import __product_version__
from .branding import load_branding
from .config import settings
from .performance import PerformanceLedger
from .onchain import OnChainLedger
from .reputation import ReputationEngine
from .observability import ObservabilityEngine
from .distribution import DistributionManager
from .proof import ProofLedger
from .saas import SaaSManager
from .entitlements import EntitlementManager


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def source_inventory(root: Path | None = None) -> dict[str, Any]:
    root = root or settings.base_dir
    files = [p for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts and ".pytest_cache" not in p.parts]
    py = [p for p in files if p.suffix == ".py"]
    tests = [p for p in files if "tests" in p.parts and p.suffix == ".py"]
    lines = 0
    for path in py:
        try:
            lines += len(path.read_text(encoding="utf-8", errors="ignore").splitlines())
        except Exception:
            pass
    return {
        "files_total": len(files),
        "python_files": len(py),
        "test_files": len(tests),
        "python_lines": lines,
        "root": root.name,
    }


def secret_scan(root: Path | None = None) -> dict[str, Any]:
    root = root or settings.base_dir
    patterns = [
        re.compile(r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b"),
        re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b"),
        re.compile(r"\$aact_(?:prod|hmlg|sandbox)_[A-Za-z0-9_$:-]{20,}", re.I),
    ]
    findings: list[str] = []
    excluded = {".git", "__pycache__", ".pytest_cache"}
    for path in root.rglob("*"):
        if not path.is_file() or any(part in excluded for part in path.parts):
            continue
        if path.suffix.lower() not in {".py", ".md", ".txt", ".json", ".sh", ".yml", ".yaml", ".example"} and path.name != ".env.example":
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if any(pattern.search(text) for pattern in patterns):
            findings.append(str(path.relative_to(root)))
    return {"clean": not findings, "findings": sorted(set(findings))}


def acquisition_readiness(storage) -> dict[str, Any]:
    inventory = source_inventory()
    security = secret_scan()
    ledger = PerformanceLedger(storage)
    performance = ledger.report(days=3650)
    proof_ledger = ProofLedger(storage)
    proof_ledger.seal_due_roots()
    proof = proof_ledger.status()
    onchain = OnChainLedger(storage).status(days=3650)
    reputation_engine = ReputationEngine(storage)
    reputation_engine.refresh(days=3650, limit=1000)
    reputation = reputation_engine.status(days=3650)
    observability_engine = ObservabilityEngine(storage)
    observability = observability_engine.status(days=30)
    distribution = DistributionManager(storage).status(days=30)
    manager = SaaSManager(storage)
    tenants = manager.list_tenants()
    deployment = {
        "dockerfile": (settings.base_dir / "Dockerfile").exists(),
        "compose": (settings.base_dir / "docker-compose.yml").exists(),
        "systemd": (settings.base_dir / "deployment" / "csm.service").exists(),
    }
    docs = {
        "readme": (settings.base_dir / "README.md").exists(),
        "architecture": (settings.base_dir / "ARCHITECTURE.md").exists(),
        "api": (settings.base_dir / "SAAS_API_V11_5.md").exists(),
        "performance": (settings.base_dir / "PERFORMANCE_INTELLIGENCE_V11.md").exists(),
        "onchain": (settings.base_dir / "ONCHAIN_INTELLIGENCE_V13_5.md").exists(),
        "reputation": (settings.base_dir / "WALLET_DEPLOYER_REPUTATION_V14.md").exists(),
        "observability": (settings.base_dir / "OBSERVABILITY_OPERATIONS_V14_5.md").exists(),
        "distribution": (settings.base_dir / "DISTRIBUTION_PLATFORM_V15.md").exists(),
        "customer_portal": (settings.base_dir / "CUSTOMER_PORTAL_ENTERPRISE_V16.md").exists(),
    }
    try:
        from phantom_v10.release import read_test_receipt, source_fingerprint
        fingerprint = source_fingerprint()
        receipt = read_test_receipt()
        tests_verified = bool(receipt.get("passed") and receipt.get("fingerprint") == fingerprint)
        test_summary = receipt.get("summary") or ""
        verification_source = "runtime-test-receipt" if tests_verified else ""

        # Sale packages are intentionally state-clean, so a runtime receipt may not
        # exist yet. A release-time quality report can provide durable evidence, but
        # only when it was generated for the exact current Python fingerprint.
        if not tests_verified:
            quality_path = settings.base_dir / "QUALITY_REPORT_V16_0.json"
            try:
                quality = json.loads(quality_path.read_text(encoding="utf-8"))
            except Exception:
                quality = {}
            tests_verified = bool(
                quality.get("tests_passed")
                and quality.get("source_fingerprint") == fingerprint
                and quality.get("version") == __product_version__
            )
            if tests_verified:
                test_summary = quality.get("test_summary") or quality.get("tests") or "release quality report verified"
                verification_source = "release-quality-report"
    except Exception:
        tests_verified = False
        test_summary = ""
        verification_source = ""

    live_proofs = int(proof.get("live_commits") or 0)
    sealed_roots = int(proof.get("sealed_daily_roots") or 0)
    proof_points = 15 if live_proofs >= 20 and sealed_roots >= 1 else 10 if live_proofs > 0 else 5 if int(proof.get("legacy_backfills") or 0) > 0 else 0
    onchain_signals = int(onchain.get("signals_monitored") or 0)
    # Keep the total readiness scale at 100: On-Chain evidence shares the
    # evidence budget with raw performance instead of inflating the score.
    components = {
        "security_clean": 15 if security["clean"] else 0,
        "verified_tests": 15 if tests_verified else 0,
        "deployment_ready": 10 if all(deployment.values()) else 5 if any(deployment.values()) else 0,
        "saas_api_ready": 5,
        "white_label_ready": 5 if settings.branding_file is not None else 0,
        "customer_portal_entitlements": 4 if settings.customer_portal_enabled else 0,
        "performance_evidence": 10 if performance["signals_observed"] >= 100 else 7 if performance["signals_observed"] >= 20 else 3 if performance["signals_observed"] > 0 else 0,
        "onchain_evidence": 3 if onchain_signals >= 20 else 2 if onchain_signals > 0 else 0,
        "reputation_evidence": 2 if int(reputation.get("profiles") or 0) >= 10 else 1 if int(reputation.get("profiles") or 0) > 0 else 0,
        "proof_of_performance": proof_points,
        "operational_observability": 5 if int(observability.get("metrics") or 0) >= 20 and int(observability.get("health_score") or 0) >= 70 else 3 if settings.observability_enabled else 0,
        "distribution_platform": 4 if int(distribution.get("active_destinations") or 0) > 0 else 2 if settings.distribution_enabled else 0,
        "documentation": 3 if all(docs.values()) else 2,
        "buyer_data_room": 4,
    }
    score = min(100, sum(components.values()))
    observed = int(performance.get("signals_observed") or 0)
    if score >= 85 and observed >= 20:
        rating = "ACQUISITION READY"
    elif score >= 80:
        rating = "TECHNICALLY READY • EVIDENCE BUILDING"
    elif score >= 70:
        rating = "STRONG FOUNDATION"
    else:
        rating = "BUILDING EVIDENCE"
    return {
        "generated_at": _now(),
        "version": __product_version__,
        "score": score,
        "rating": rating,
        "components": components,
        "tests_verified": tests_verified,
        "test_verification_source": verification_source,
        "test_summary": test_summary,
        "security": security,
        "inventory": inventory,
        "deployment": deployment,
        "documentation": docs,
        "performance": {
            "signals_total": performance["signals_total"],
            "signals_observed": performance["signals_observed"],
            "observation_coverage_pct": performance["observation_coverage_pct"],
        },
        "proof_of_performance": proof,
        "onchain_intelligence": onchain,
        "wallet_deployer_reputation": reputation,
        "observability_operations": observability,
        "distribution_platform": distribution,
        "customer_portal": {
            "enabled": bool(settings.customer_portal_enabled),
            "enterprise_dashboard_enabled": bool(settings.enterprise_dashboard_enabled),
            "tenant_entitlements": [
                {
                    "tenant": row.get("slug"),
                    "plan": row.get("entitlement_plan", "enterprise"),
                    "status": row.get("entitlement_status", "ACTIVE"),
                } for row in tenants
            ],
        },
        "saas_tenants_configured": len(tenants),
        "note": "O score mede prontidão técnica/comercial do ativo e não constitui avaliação financeira do negócio. O selo ACQUISITION READY exige também evidência observada mínima; sem histórico suficiente a release permanece tecnicamente pronta, mas em construção de evidência.",
    }


def _api_spec() -> dict[str, Any]:
    return {
        "openapi_like": "CSM compact API contract",
        "version": __product_version__,
        "authentication": "Authorization: Bearer csm_live_... or X-API-Key",
        "endpoints": {
            "GET /healthz": "public health",
            "GET /portal": "V16 browser customer portal; API key kept in sessionStorage",
            "GET /api/v1/status": "product, tenant and entitlement status",
            "GET /api/v1/portal/overview": "tenant-scoped customer dashboard payload",
            "GET /api/v1/portal/me": "tenant identity + entitlement",
            "GET /api/v1/portal/usage": "API quota and current usage",
            "GET /api/v1/portal/subscription": "tenant/link subscription status",
            "GET /api/v1/enterprise/overview": "enterprise-only consolidated tenant dashboard",
            "GET /api/v1/signals?days=30&limit=100": "delivered signal ledger",
            "GET /api/v1/signals/{id}": "signal + observations",
            "GET /api/v1/performance?days=30": "aggregate audited performance",
            "GET /api/v1/proofs?days=30": "tamper-evident proof dataset",
            "GET /api/v1/proofs/{proof_id}": "proof chain + verification",
            "GET /api/v1/proof-roots": "sealed Merkle roots + registered anchors",
            "GET /api/v1/onchain?days=30&limit=100": "post-signal on-chain intelligence",
            "GET /api/v1/reputation?days=3650&limit=100": "wallet/deployer reputation leaderboard",
            "GET /api/v1/reputation/{chain}/{address}": "evidence-based reputation profile",
            "GET /api/v1/observability?days=7&limit=100": "sanitized operational metrics + incidents",
            "GET /api/v1/observability/incidents": "operational incident history",
            "GET /api/v1/distribution": "sanitized outbound delivery status/jobs",
            "GET /api/v1/distribution/dead-letter": "sanitized dead-letter jobs",
            "GET /api/v1/onchain/{signal_id}": "on-chain snapshots + append-only events",
            "GET /api/v1/providers": "provider health",
            "GET /api/v1/security/{chain}/{address}": "last stored GoPlus snapshot",
            "GET /api/v1/branding": "white-label public branding",
        },
        "writes": "Tenant/key/entitlement and outbound-destination provisioning are local-admin CLI only; public API remains read-only.",
        "authorization": "V16 feature access is entitlement-gated per tenant; legacy tenants migrate enterprise-compatible.",
    }


def _synthetic_demo() -> dict[str, Any]:
    return {
        "synthetic": True,
        "warning": "Dados demonstrativos gerados; não representam resultados reais.",
        "signals": [
            {"id": "DEMO-1", "chain": "solana", "symbol": "DEMO", "entry_price": 0.001, "score": 91, "goplus_score": 96, "max_return_pct": 42.5},
            {"id": "DEMO-2", "chain": "base", "symbol": "SAMPLE", "entry_price": 0.025, "score": 87, "goplus_score": 92, "max_return_pct": 18.4},
        ],
    }


def generate_sale_pack(storage, output: str | Path | None = None) -> Path:
    output_path = Path(output) if output else settings.data_dir / "exports" / f"CSM_Data_Room_{__product_version__}.zip"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    ledger = PerformanceLedger(storage)
    readiness = acquisition_readiness(storage)
    with tempfile.TemporaryDirectory(prefix="csm_data_room_") as tmp:
        root = Path(tmp) / "CSM_DATA_ROOM"
        root.mkdir(parents=True)
        _write_json(root / "ACQUISITION_READINESS.json", readiness)
        _write_json(root / "PERFORMANCE_REPORT.json", ledger.report(days=3650))
        proofs = ProofLedger(storage)
        proofs.seal_due_roots()
        _write_json(root / "PROOF_STATUS.json", proofs.status())
        _write_json(root / "PROOF_PUBLIC.json", proofs.public_dataset(days=3650))
        onchain = OnChainLedger(storage)
        _write_json(root / "ONCHAIN_STATUS.json", onchain.status(days=3650))
        _write_json(root / "ONCHAIN_REPORT.json", onchain.report(days=3650, limit=500))
        reputation = ReputationEngine(storage)
        reputation.refresh(days=3650, limit=5000)
        _write_json(root / "WALLET_REPUTATION_STATUS.json", reputation.status(days=3650))
        _write_json(root / "WALLET_REPUTATION_REPORT.json", reputation.report(days=3650, limit=500))
        observability = ObservabilityEngine(storage)
        _write_json(root / "OBSERVABILITY_STATUS.json", observability.status(days=30))
        _write_json(root / "OBSERVABILITY_REPORT.json", observability.report(days=30, limit=500))
        distribution = DistributionManager(storage)
        _write_json(root / "DISTRIBUTION_STATUS.json", distribution.status(days=30))
        _write_json(root / "DISTRIBUTION_JOBS.json", distribution.jobs(limit=500))
        entitlements = EntitlementManager(storage)
        safe_entitlements = []
        for tenant in SaaSManager(storage).list_tenants():
            effective = entitlements.effective(str(tenant.get("slug") or "")) or {}
            safe_entitlements.append({
                "tenant": tenant.get("slug"), "plan": effective.get("plan"),
                "status": effective.get("status"), "features": effective.get("features", []),
            })
        _write_json(root / "ENTITLEMENTS_SUMMARY.json", {"items": safe_entitlements})
        _write_json(root / "API_CONTRACT.json", _api_spec())
        _write_json(root / "SOURCE_INVENTORY.json", source_inventory())
        _write_json(root / "SECURITY_SCAN.json", secret_scan())
        _write_json(root / "BRANDING.json", load_branding())
        _write_json(root / "DEMO_SYNTHETIC.json", _synthetic_demo())
        env_example = settings.base_dir / ".env.example"
        if env_example.exists():
            shutil.copy2(env_example, root / ".env.example")
        overview = f"""# Crypto Signals Multichain — Buyer Data Room\n\nGenerated: {_now()}\nRelease: {__product_version__}\n\nThis package contains **no production database, subscriber PII, Telegram token, provider API key or payment credential**.\n\n## Included evidence\n- Acquisition readiness report\n- Audited signal-performance aggregate\n- API contract\n- Source inventory\n- Security-clean scan\n- White-label branding snapshot\n- Synthetic demo data clearly labelled as synthetic\n- Sanitized environment template\n\nPerformance data is derived only from signals actually persisted by the product; no synthetic performance is mixed into the real report.\n"""
        (root / "README.md").write_text(overview, encoding="utf-8")
        due = """# Technical Due Diligence\n\n## Runtime\n- Single Python bot runtime for a-Shell/Termux.\n- Sequential stdlib HTTPS bus on mobile.\n- Session guard with heartbeat plus dead-PID negative recovery.\n\n## Data\n- SQLite persistent state outside release folders.\n- Signal ledger separates original signal facts from later observations.\n- SaaS API keys stored as SHA-256 hashes; full keys are returned only once at creation.\n\n## Security\n- GoPlus contract-security gate.\n- Provider credentials are not embedded in sale packages.\n- Public SaaS API is read-only.\n- Tenant/key provisioning remains a local administrative action.\n\n## Deployment\n- a-Shell, Termux, Linux/VPS, Docker Compose and systemd artifacts are included in the source release.\n"""
        (root / "TECHNICAL_DUE_DILIGENCE.md").write_text(due, encoding="utf-8")
        manifest: dict[str, str] = {}
        for path in sorted(root.rglob("*")):
            if path.is_file():
                manifest[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
        _write_json(root / "MANIFEST_SHA256.json", manifest)
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(root.rglob("*")):
                if path.is_file():
                    zf.write(path, path.relative_to(root.parent))
    return output_path
