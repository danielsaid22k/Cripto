from __future__ import annotations

import hmac
import html
import json
import re
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlencode, urlparse

from .audit_log import recent_events, record_event
from .branding import load_branding
from .performance import PerformanceLedger
from .config_integrity import ConfigIntegrityGuard
from .signal_quality_runtime import build_signal_quality_overview
from .onchain import OnChainLedger
from .reputation import ReputationEngine
from .observability import ObservabilityEngine
from .distribution import DistributionManager
from .proof import ProofLedger
from .storage import Storage
from .config import settings
from .enterprise_ops import enterprise_snapshot, safe_subscriptions, safe_users


def _is_loopback(host: str) -> bool:
    return host in {"127.0.0.1", "localhost", "::1"}



def _redact_request_target(target: str) -> str:
    parsed = urlparse(str(target or ""))
    if not parsed.query:
        return str(target or "")
    query = parse_qs(parsed.query, keep_blank_values=True)
    for key in list(query):
        if key.lower() in {"token", "access_token", "api_key", "apikey", "key", "secret"}:
            query[key] = ["***REDACTED***"]
    return parsed._replace(query=urlencode(query, doseq=True)).geturl()

def _json_bytes(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, indent=2, default=str).encode("utf-8")


def _safe_num(value: object, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _dashboard_tables(snapshot: dict) -> tuple[str, str, str, str, str, str]:
    signals = snapshot.get("ledger_signals") or []
    signal_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row.get('symbol') or '?'))}</td>"
        f"<td>{html.escape(str(row.get('chain') or '?'))}</td>"
        f"<td>{int(_safe_num(row.get('final_score')))}</td>"
        f"<td>{int(_safe_num(row.get('goplus_score')))}</td>"
        f"<td>{int(_safe_num(row.get('csm_confidence_score') or row.get('final_score')))}</td>"
        f"<td>{_safe_num(row.get('last_return_pct')):.2f}%</td>"
        f"<td>{html.escape(str(row.get('created_at') or ''))}</td>"
        "</tr>"
        for row in signals[:20]
    ) or "<tr><td colspan='7'>Nenhum sinal no Performance Ledger ainda</td></tr>"

    security_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row.get('symbol') or '?'))}</td>"
        f"<td>{html.escape(str(row.get('chain') or '?'))}</td>"
        f"<td>{html.escape(str(row.get('goplus_risk_level') or 'N/D'))}</td>"
        f"<td>{int(_safe_num(row.get('goplus_score')))}</td>"
        f"<td>{_safe_num(row.get('goplus_buy_tax_pct')):.2f}%</td>"
        f"<td>{_safe_num(row.get('goplus_sell_tax_pct')):.2f}%</td>"
        "</tr>"
        for row in signals[:20]
    ) or "<tr><td colspan='6'>Nenhum snapshot GoPlus persistido no ledger</td></tr>"

    by_chain = (snapshot.get("performance") or {}).get("by_chain") or {}
    analytics_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(chain))}</td>"
        f"<td>{int(data.get('signals') or 0)}</td>"
        f"<td>{_safe_num(data.get('win_rate_pct')):.2f}%</td>"
        f"<td>{_safe_num(data.get('tp1_hit_rate_pct')):.2f}%</td>"
        f"<td>{_safe_num(data.get('average_last_return_pct')):.2f}%</td>"
        "</tr>"
        for chain, data in sorted(by_chain.items())
    ) or "<tr><td colspan='5'>Aguardando performance observada</td></tr>"

    onchain_latest = (snapshot.get("onchain") or {}).get("latest") or []
    onchain_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row.get('symbol') or '?'))}</td>"
        f"<td>{html.escape(str(row.get('chain') or '?'))}</td>"
        f"<td>{int(_safe_num(row.get('onchain_score'), 0))}</td>"
        f"<td>{html.escape(str(row.get('risk_level') or 'N/D'))}</td>"
        f"<td>{(_safe_num(row.get('top10_holders_pct'))):.2f}%</td>"
        f"<td>{int(_safe_num(row.get('whale_transfer_count')))}</td>"
        f"<td>{_safe_num(row.get('liquidity_change_pct')):+.2f}%</td>"
        f"<td>{html.escape(str(row.get('captured_at') or ''))}</td>"
        "</tr>"
        for row in onchain_latest[:20]
    ) or "<tr><td colspan='8'>Aguardando observações on-chain</td></tr>"

    rep_rows_data = (snapshot.get("reputation") or {}).get("highest_risk") or []
    reputation_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row.get('chain') or '?'))}</td>"
        f"<td><code>{html.escape(str(row.get('address') or '')[:18])}…</code></td>"
        f"<td>{html.escape(str(row.get('role') or 'observed'))}</td>"
        f"<td>{int(_safe_num(row.get('reputation_score'), 50))}</td>"
        f"<td>{int(_safe_num(row.get('confidence_score'), 0))}</td>"
        f"<td>{html.escape(str(row.get('rating') or 'UNPROVEN'))}</td>"
        f"<td>{int(_safe_num(row.get('evidence_count'), 0))}</td>"
        "</tr>" for row in rep_rows_data[:20]
    ) or "<tr><td colspan='7'>Aguardando evidências de reputação</td></tr>"

    alerts = snapshot.get("operational_alerts") or []
    alert_rows = "".join(
        f"<li>{html.escape(str(item if not isinstance(item, dict) else item.get('message') or item.get('title') or item))}</li>"
        for item in alerts[:15]
    ) or "<li class='ok'>Nenhum alerta operacional relevante</li>"
    return signal_rows, security_rows, analytics_rows, onchain_rows, reputation_rows, alert_rows



def _daniel_text(value: object, limit: int = 6000) -> str:
    text = str(value or "")
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text).strip()
    return text[:limit]


def _daniel_panel_snapshot(user_id: int = 0) -> dict:
    from daniel_ai.api import status_payload
    from daniel_ai.config import DanielSettings, ensure_directories
    from daniel_ai.memory import DanielMemory
    from csm.provider_health import load_provider_health

    cfg = ensure_directories(DanielSettings.from_env())
    status = status_payload()
    history: list[dict] = []
    memories: list[dict] = []
    docs: list[dict] = []
    learned: list[dict] = []
    learning: dict = {}
    try:
        with DanielMemory(cfg.db_file) as mem:
            history = mem.history(int(user_id or 0), limit=10)
            memories = mem.memories(int(user_id or 0), limit=10)
            docs = mem.indexed_documents(limit=20)
            learned = mem.learned_items(limit=8)
            learning = mem.learning_stats()
    except Exception:
        pass
    try:
        provider_health = load_provider_health()
    except Exception:
        provider_health = {"overall_health": 0, "counts": {}, "providers": []}
    scanner_funnel = {}
    signal_lifecycle = {}
    smart_reentry = {}
    try:
        from daniel_ai.tools import DanielTools
        tools = DanielTools(cfg)
        result = tools.scanner_funnel(hours=24)
        scanner_funnel = result.data if result.ok else {}
        life = tools.signal_lifecycle(hours=24)
        signal_lifecycle = life.data if life.ok else {}
        reentry = tools.smart_reentry(hours=24, limit=8)
        smart_reentry = reentry.data if reentry.ok else {}
    except Exception:
        scanner_funnel = {}
        signal_lifecycle = {}
        smart_reentry = {}
    return {"status": status, "history": history, "memories": memories, "documents": docs, "learned": learned, "learning": learning, "providers": provider_health, "scanner_funnel": scanner_funnel, "signal_lifecycle": signal_lifecycle, "smart_reentry": smart_reentry, "user_id": int(user_id or 0)}


def _daniel_panel_page(*, token: str = "", user_id: int = 0, question: str = "", answer: str = "") -> bytes:
    data = _daniel_panel_snapshot(user_id)
    status = data.get("status") or {}
    counts = status.get("counts") or {}
    token_q = ("?" + urlencode({"token": token})) if token else ""
    action = "/daniel-ai" + token_q
    history_rows = "".join(
        "<div class='history'><b>" + html.escape("Você" if str(row.get("role")) == "user" else "Daniel") + ":</b> "
        + html.escape(_daniel_text(row.get("content"), 500)) + "</div>"
        for row in (data.get("history") or [])[-8:]
    ) or "<div class='muted'>Sem conversas neste usuário do painel.</div>"
    memory_rows = "".join(
        "<li><b>" + html.escape(str(row.get("key") or "")) + "</b>: " + html.escape(str(row.get("value") or "")[:300]) + "</li>"
        for row in (data.get("memories") or [])
    ) or "<li class='muted'>Sem memórias salvas para este usuário.</li>"
    doc_rows = "".join(
        "<li>" + html.escape(str(row.get("name") or "")) + " • " + html.escape(str(row.get("format") or "").upper()) + " • " + str(int(row.get("chunks") or 0)) + " trecho(s)</li>"
        for row in (data.get("documents") or [])
    ) or "<li class='muted'>Nenhum documento indexado.</li>"
    learned_rows = "".join(
        "<li><b>" + html.escape(str(row.get("topic") or "")) + "</b> • confiança " + str(int(row.get("confidence") or 0)) + "% • fontes " + str(int(row.get("source_count") or 0)) + "<br><span class='muted'>" + html.escape(_daniel_text(row.get("summary"), 260)) + "</span></li>"
        for row in (data.get("learned") or [])
    ) or "<li class='muted'>Ainda sem conhecimento automático persistido.</li>"
    learning_data = data.get("learning") or {}
    provider_data = data.get("providers") or {}
    provider_rows = "".join(
        "<tr><td>" + html.escape(str(row.get("name") or row.get("provider") or "")) + "</td><td>" +
        html.escape(str(row.get("status") or "?")) + "</td><td>" + str(int(row.get("health_score") or 0)) +
        "/100</td><td>" + (str(int(row.get("retry_in") or 0)) + "s" if int(row.get("retry_in") or 0) > 0 else "—") +
        "</td><td>" + html.escape(str(row.get("circuit_reason") or ("recuperando" if row.get("recently_recovered") else ""))) + "</td></tr>"
        for row in (provider_data.get("providers") or [])[:20]
    ) or "<tr><td colspan='5' class='muted'>Sem snapshot de providers.</td></tr>"
    scanner_data = data.get("scanner_funnel") or {}
    scanner_reason_rows = "".join(
        "<li>" + html.escape(str(row.get("label") or row.get("reason") or "")) + ": <b>" + str(int(row.get("count") or 0)) + "</b> (" + str(float(row.get("pct") or 0)) + "%)</li>"
        for row in (scanner_data.get("rejection_reasons") or [])[:6]
    ) or "<li class='muted'>Aguardando decisões V16.2 dos próximos ciclos.</li>"
    scanner_network_rows = "".join(
        "<tr><td>" + html.escape(str(row.get("chain") or "?").upper()) + "</td><td>" + str(int(row.get("analyzed") or 0)) + "</td><td>" + str(int(row.get("approved") or 0)) + "</td><td>" + str(float(row.get("approval_rate_pct") or 0)) + "%</td><td>" + html.escape(str(row.get("top_rejection_label") or "—")) + "</td></tr>"
        for row in (scanner_data.get("networks") or [])[:10]
    ) or "<tr><td colspan='5' class='muted'>Sem funil por rede ainda.</td></tr>"
    lifecycle_data = data.get("signal_lifecycle") or {}
    lifecycle_states = lifecycle_data.get("states") or {}
    lifecycle_events = lifecycle_data.get("events") or {}
    lifecycle_det_rows = "".join(
        "<li><b>" + html.escape(str(row.get("symbol") or row.get("name") or "TOKEN")) + "</b> • " +
        html.escape(str(row.get("chain") or "").upper()) + " • retorno " + str(round(float(row.get("last_return_pct") or 0), 2)) +
        "% • deterioração " + str(int(row.get("deterioration_score") or 0)) + "/100</li>"
        for row in (lifecycle_data.get("deteriorating") or [])[:8]
    ) or "<li class='muted'>Nenhum sinal em deterioração no recorte.</li>"
    reentry_data = data.get("smart_reentry") or {}
    reentry_rows = "".join(
        "<li><b>" + html.escape(str(row.get("symbol") or row.get("name") or "TOKEN")) + "</b> • " +
        html.escape(str(row.get("chain") or "").upper()) + " • " + html.escape(str(row.get("plan_group") or "").upper()) +
        " • anterior " + html.escape(str(row.get("prior_lifecycle_state") or "N/D")) +
        " • retorno " + str(round(float(row.get("last_return_pct") or 0), 2)) + "%</li>"
        for row in (reentry_data.get("recent") or [])[:8]
    ) or "<li class='muted'>Nenhuma reentrada confirmada no recorte.</li>"

    answer_box = ""
    if answer:
        answer_box = "<section class='card answer'><h2>🧠 Resposta</h2><pre>" + html.escape(_daniel_text(answer, 12000)) + "</pre></section>"
    page = f"""<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Daniel AI V{html.escape(str(status.get('version') or '?'))} • CSM</title><style>
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:0;background:#090f20;color:#eef4ff}}header{{padding:20px;background:#111a35;border-bottom:1px solid #2b3a6d}}main{{max-width:980px;margin:auto;padding:18px}}a{{color:#9bd2ff}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}}.card{{background:#151e3d;border:1px solid #2d3d70;border-radius:16px;padding:15px;margin-bottom:14px}}.value{{font-size:22px;font-weight:800}}.muted{{color:#a9b6d5}}textarea,input{{box-sizing:border-box;width:100%;background:#0d1530;color:#fff;border:1px solid #3a4c84;border-radius:12px;padding:12px;font-size:16px}}button{{background:#4667ff;color:white;border:0;border-radius:12px;padding:12px 18px;font-weight:700;margin-top:10px}}pre{{white-space:pre-wrap;word-break:break-word;font-family:inherit;line-height:1.4}}.history{{border-top:1px solid #27365f;padding:8px 0}}.ok{{color:#78e4a8}}.off{{color:#ffd277}}</style></head><body>
<header><h1>🧠 Daniel AI V{html.escape(str(status.get('version') or '?'))} • Painel</h1><div class='muted'>CSM V16.4 • local-first • OpenAI {'ON' if status.get('openai_enabled') else 'OFF'} • Web {'ON' if status.get('web_enabled') else 'OFF'}</div></header>
<main><p><a href='/{token_q}'>← Admin Center</a></p>
<div class='grid'>
<div class='card'><div>Estado</div><div class='value {'ok' if status.get('enabled') else 'off'}'>{'ATIVO' if status.get('enabled') else 'OFF'}</div></div>
<div class='card'><div>OpenAI</div><div class='value'>{'ON' if status.get('openai_enabled') else 'OFF'}</div></div>
<div class='card'><div>Internet</div><div class='value'>{'ON' if status.get('web_enabled') else 'OFF'}</div></div>
<div class='card'><div>Aprendizado</div><div class='value {'ok' if status.get('learning_enabled') else 'off'}'>{'ON' if status.get('learning_enabled') else 'OFF'}</div></div>
<div class='card'><div>Conversas</div><div class='value'>{int(counts.get('conversations') or 0)}</div></div>
<div class='card'><div>Memórias</div><div class='value'>{int(counts.get('memories') or 0)}</div></div>
<div class='card'><div>Documentos</div><div class='value'>{int(counts.get('knowledge_documents') or 0)}</div></div>
<div class='card'><div>Conhecimento</div><div class='value'>{int(learning_data.get('learned_items') or 0)}</div></div>
<div class='card'><div>Fila learning</div><div class='value'>{int(learning_data.get('pending_topics') or 0)}</div></div>
<div class='card'><div>Scanner 24h</div><div class='value'>{int(scanner_data.get('analyzed') or 0)}</div></div>
<div class='card'><div>Lifecycle 24h</div><div class='value'>{int(lifecycle_data.get('signals') or 0)}</div></div>
<div class='card'><div>Reentradas 24h</div><div class='value'>{int(reentry_data.get('reentries') or 0)}</div></div>
<div class='card'><div>Deteriorando</div><div class='value'>{int(lifecycle_states.get('DETERIORATING') or 0)}</div></div>
<div class='card'><div>Provider health</div><div class='value'>{int(provider_data.get('overall_health') or 0)}/100</div></div>
<div class='card'><div>Cooldowns</div><div class='value'>{int((provider_data.get('counts') or {}).get('COOLDOWN') or 0)}</div></div>
</div>
<section class='card'><h2>💬 Perguntar ao Daniel</h2><form method='post' action='{html.escape(action, quote=True)}'><label>Usuário local</label><input name='user_id' inputmode='numeric' value='{int(user_id or 0)}'><label>Pergunta</label><textarea name='question' rows='4' maxlength='4000' placeholder='Ex.: diagnostico do scanner'>{html.escape(question)}</textarea><button type='submit'>Perguntar</button></form><p class='muted'>O painel usa o mesmo motor local do Telegram. Ferramentas CSM permanecem somente leitura.</p></section>
{answer_box}
<section class='card'><h2>🗂 Histórico recente</h2>{history_rows}</section>
<section class='card'><h2>🧠 Memórias</h2><ul>{memory_rows}</ul></section>
<section class='card'><h2>📚 Base local</h2><ul>{doc_rows}</ul></section>
<section class='card'><h2>🔎 Scanner Intelligence • 24h</h2><p>Analisados: <b>{int(scanner_data.get('analyzed') or 0)}</b> • aprovados: <b>{int(scanner_data.get('approved') or 0)}</b> • rejeitados: <b>{int(scanner_data.get('rejected') or 0)}</b> • aprovação: <b>{float(scanner_data.get('approval_rate_pct') or 0):.1f}%</b></p><h3>Principais rejeições</h3><ul>{scanner_reason_rows}</ul><h3>Por rede</h3><table style='width:100%;border-collapse:collapse'><thead><tr><th style='text-align:left'>Rede</th><th style='text-align:left'>Analisados</th><th style='text-align:left'>Aprovados</th><th style='text-align:left'>Taxa</th><th style='text-align:left'>Principal bloqueio</th></tr></thead><tbody>{scanner_network_rows}</tbody></table><p class='muted'>Evidence-only: o Daniel pode explicar e aprender padrões, mas não altera filtros/scoring automaticamente.</p></section>
<section class='card'><h2>📈 Signal Lifecycle • 24h</h2><p>Ativos: <b>{int(lifecycle_states.get('ACTIVE') or 0)}</b> • TP1: <b>{int(lifecycle_states.get('TP1') or 0)}</b> • TP2: <b>{int(lifecycle_states.get('TP2') or 0)}</b> • TP3: <b>{int(lifecycle_states.get('TP3') or 0)}</b> • stops: <b>{int(lifecycle_states.get('STOPPED') or 0)}</b></p><p>Eventos: {html.escape(', '.join(str(k) + '=' + str(v) for k,v in sorted(lifecycle_events.items())) or '—')}</p><h3>Deteriorando</h3><ul>{lifecycle_det_rows}</ul><p class='muted'>Frequência adaptativa reduz consultas em sinais estáveis e aumenta a atenção em deterioração. O scoring original é imutável.</p></section>
<section class='card'><h2>🔄 Smart Reentry • 24h</h2><p>Reentradas confirmadas: <b>{int(reentry_data.get('reentries') or 0)}</b> • positivo observado: <b>{float(reentry_data.get('positive_rate_pct') or 0):.1f}%</b> • TP1: <b>{float(reentry_data.get('tp1_rate_pct') or 0):.1f}%</b></p><p>Cooldown padrão: Free 24h • Plus 12h • Premium 6h.</p><ul>{reentry_rows}</ul><p class='muted'>Toda reentrada exige reencontro + aprovação atual; STOP/DETERIORATING/TP3 exigem melhora material. Daniel permanece somente leitura.</p></section>
<section class='card'><h2>🧠 Continuous Learning</h2><p>Automático: <b>{'ON' if status.get('learning_enabled') else 'OFF'}</b> • expirados: {int(learning_data.get('expired_items') or 0)} • último: {html.escape(str(learning_data.get('last_topic') or '—'))}</p><ul>{learned_rows}</ul><p class='muted'>Cada item guarda fontes, confiança e validade. O aprendizado não altera scanner, score, pagamentos ou chaves.</p></section>
<section class='card'><h2>🌐 Provider Resilience</h2><table style='width:100%;border-collapse:collapse'><thead><tr><th style='text-align:left'>Provider</th><th style='text-align:left'>Estado</th><th style='text-align:left'>Health</th><th style='text-align:left'>Retry</th><th style='text-align:left'>Circuito</th></tr></thead><tbody>{provider_rows}</tbody></table><p class='muted'>COOLDOWN/QUOTA acionam fallback automático; o painel é somente leitura.</p></section>
<section class='card'><h2>🔐 Segurança</h2><p>OpenAI continua independente. A pesquisa web é opt-in e aplica bloqueio de localhost/redes privadas, redirects validados, timeout e limite de bytes.</p></section>
</main></body></html>"""
    return page.encode("utf-8")


def _page(snapshot: dict, token: str = "") -> bytes:
    daniel = snapshot.get("daniel_ai") or {}
    plans = snapshot.get("plans", {})
    scanner = snapshot.get("scanner", {})
    performance = snapshot.get("performance", {})
    proof = snapshot.get("proof", {})
    onchain = snapshot.get("onchain", {})
    onchain_summary = onchain.get("summary") or {}
    reputation = snapshot.get("reputation", {})
    reputation_summary = reputation.get("summary") or {}
    observability = snapshot.get("observability", {})
    observability_status = observability.get("status") or {}
    distribution = snapshot.get("distribution") or {}
    saas = snapshot.get("saas") or {}
    brand = snapshot.get("branding") or load_branding()
    renewals = snapshot.get("renewals_next_30_days", [])
    rows = "".join(
        f"<tr><td>{html.escape(str(r.get('user_id','')))}</td><td>{html.escape(str(r.get('plan','')))}</td><td>{html.escape(str(r.get('expires_at','')))}</td></tr>"
        for r in renewals[:20]
    ) or "<tr><td colspan='3'>Nenhuma renovação próxima</td></tr>"
    signal_rows, security_rows, analytics_rows, onchain_rows, reputation_rows, alert_rows = _dashboard_tables(snapshot)
    document = f"""<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>{html.escape(str(brand.get('product_name') or 'CSM'))} Admin</title><style>
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:0;background:#0b1020;color:#edf2ff}}header{{padding:24px;background:#111936;border-bottom:1px solid #28345f}}main{{padding:20px;max-width:1100px;margin:auto}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}}.card{{background:#151d3d;border:1px solid #2c396d;border-radius:16px;padding:16px}}.value{{font-size:28px;font-weight:700}}table{{width:100%;border-collapse:collapse;background:#151d3d;border-radius:12px;overflow:hidden}}th,td{{padding:10px;border-bottom:1px solid #2c396d;text-align:left}}code{{color:#9ed0ff}}.ok{{color:#73e2a7}}.muted{{color:#aab5d6}}</style></head>
<body><header><h1>{html.escape(str(brand.get('logo_emoji') or '🌐'))} {html.escape(str(brand.get('product_name') or 'Crypto Signals Multichain'))} • Admin Center</h1><div class='muted'>Release {html.escape(str(snapshot.get('product_release') or snapshot.get('release')))} • LTS {html.escape(str(snapshot.get('lts_base')))} • {html.escape(str(snapshot.get('environment')))}</div></header><main><div class='card'><b>🧠 Daniel AI</b> • {html.escape(str('ATIVO' if daniel.get('enabled') else 'DESATIVADO'))} • modo {html.escape(str(daniel.get('mode','local')).upper())} • OpenAI {html.escape(str('ON' if daniel.get('openai_enabled') else 'OFF'))} • <a href='/daniel-ai{('?' + urlencode({'token': token})) if token else ''}'>abrir painel</a></div>
<div class='grid'>
<div class='card'><div>Usuários</div><div class='value'>{snapshot.get('users_total',0)}</div></div>
<div class='card'><div>Plus</div><div class='value'>{plans.get('plus',0)+plans.get('plus_annual',0)}</div></div>
<div class='card'><div>Premium</div><div class='value'>{plans.get('premium',0)+plans.get('premium_annual',0)}</div></div>
<div class='card'><div>Sinais abertos</div><div class='value'>{snapshot.get('signals_open',0)}</div></div>
<div class='card'><div>Ciclos hoje</div><div class='value'>{scanner.get('cycles_today',0)}</div></div>
<div class='card'><div>Sinais hoje</div><div class='value'>{scanner.get('signals_today',0)}</div></div>
<div class='card'><div>Ledger observado</div><div class='value'>{performance.get('signals_observed',0)}</div></div>
<div class='card'><div>Win rate</div><div class='value'>{performance.get('win_rate_pct',0)}%</div></div>
<div class='card'><div>TP1 hit rate</div><div class='value'>{performance.get('tp1_hit_rate_pct',0)}%</div></div>
<div class='card'><div>Proof live</div><div class='value'>{proof.get('live_commits',0)}</div></div>
<div class='card'><div>Raízes seladas</div><div class='value'>{proof.get('sealed_daily_roots',0)}</div></div>
<div class='card'><div>Sinais on-chain</div><div class='value'>{onchain_summary.get('signals_monitored',0)}</div></div>
<div class='card'><div>On-Chain médio</div><div class='value'>{onchain_summary.get('average_onchain_score') if onchain_summary.get('average_onchain_score') is not None else '—'}</div></div>
<div class='card'><div>Wallet profiles</div><div class='value'>{reputation_summary.get('profiles',0)}</div></div>
<div class='card'><div>Deployers</div><div class='value'>{reputation_summary.get('deployers',0)}</div></div>
<div class='card'><div>Operations health</div><div class='value'>{observability_status.get('health_score',100)}/100</div></div>
<div class='card'><div>Incidentes abertos</div><div class='value'>{observability_status.get('open_incidents',0)}</div></div>
<div class='card'><div>Distribution destinos</div><div class='value'>{distribution.get('active_destinations',0)}</div></div>
<div class='card'><div>Distribution enviados</div><div class='value'>{(distribution.get('jobs') or {}).get('SENT',0)}</div></div>
<div class='card'><div>SaaS tenants</div><div class='value'>{saas.get('tenant_count',0)}</div></div>
<div class='card'><div>Entitlements ativos</div><div class='value'>{saas.get('active_entitlements',0)}</div></div>
<div class='card'><div>API requests hoje</div><div class='value'>{saas.get('requests_today',0)}</div></div>
</div>
<h2>Proof • Verified Performance</h2><div class='card'><div><b>Live commits:</b> {proof.get('live_commits',0)} • <b>Legacy/backfill:</b> {proof.get('legacy_backfills',0)} • <b>Observações provadas:</b> {proof.get('observation_proofs',0)}</div><div class='muted'>Raiz provisória UTC: <code>{html.escape(str((proof.get('today_provisional_root') or {}).get('root_hash') or 'sem eventos'))}</code></div></div>
<h2>Signals • Performance Ledger</h2><table><thead><tr><th>Token</th><th>Rede</th><th>Score</th><th>GoPlus</th><th>Confidence</th><th>Retorno</th><th>Emitido</th></tr></thead><tbody>{signal_rows}</tbody></table>
<h2>Security • GoPlus snapshots</h2><table><thead><tr><th>Token</th><th>Rede</th><th>Risco</th><th>Score</th><th>Buy tax</th><th>Sell tax</th></tr></thead><tbody>{security_rows}</tbody></table>
<h2>On-Chain Intelligence • Pós-sinal</h2><table><thead><tr><th>Token</th><th>Rede</th><th>Score</th><th>Risco</th><th>Top 10</th><th>Whales</th><th>Δ Liquidez</th><th>Capturado</th></tr></thead><tbody>{onchain_rows}</tbody></table>
<h2>Wallet/Deployer Reputation • Evidência própria</h2><table><thead><tr><th>Rede</th><th>Wallet</th><th>Papel</th><th>Score</th><th>Confiança</th><th>Rating</th><th>Evidências</th></tr></thead><tbody>{reputation_rows}</tbody></table>
<h2>Analytics • Resultado por rede</h2><table><thead><tr><th>Rede</th><th>Amostra</th><th>Win rate</th><th>TP1</th><th>Retorno médio</th></tr></thead><tbody>{analytics_rows}</tbody></table>
<h2>Distribution Platform • Outbound</h2><div class='card'><pre>{html.escape(json.dumps(distribution, ensure_ascii=False, indent=2, default=str))}</pre><div class='muted'>Somente saída; Telegram permanece principal. URLs/segredos não são exibidos.</div></div>
<h2>System • Saúde operacional</h2><div class='card'><div><b>Observability:</b> {html.escape(str(observability_status.get('state','HEALTHY')))} • health {observability_status.get('health_score',100)}/100 • incidentes {observability_status.get('open_incidents',0)}</div><div class='muted'>Telemetria local/cooperativa, sem webhook público.</div><pre>{html.escape(json.dumps(scanner, ensure_ascii=False, indent=2, default=str))}</pre><ul>{alert_rows}</ul></div>
<h2>Renovações nos próximos 30 dias</h2><table><thead><tr><th>Usuário</th><th>Plano</th><th>Vencimento</th></tr></thead><tbody>{rows}</tbody></table>
<p class='muted'>Painel somente leitura. API: <code>/api/status</code>, <code>/api/daniel-ai</code>, <code>/api/performance</code>, <code>/api/proof</code>, <code>/api/signals</code>, <code>/api/security</code>, <code>/api/onchain</code>, <code>/api/reputation</code>, <code>/api/observability</code>, <code>/api/distribution</code>, <code>/api/system</code>, <code>/api/users</code>, <code>/api/subscriptions</code>, <code>/api/events</code>.</p>
</main></body></html>"""
    return document.encode("utf-8")


def _admin_snapshot() -> dict:
    snapshot = enterprise_snapshot()
    try:
        snapshot["signal_quality"] = (
            build_signal_quality_overview(snapshot)
        )
    except Exception as exc:
        snapshot["signal_quality"] = {
            "version": "16.4.9",
            "mode": "SHADOW",
            "promotion_enabled": False,
            "samples": 0,
            "error": str(exc),
        }
    snapshot["branding"] = load_branding()
    try:
        snapshot["config_integrity"] = ConfigIntegrityGuard().report(
            persist=False
        )
    except Exception as exc:
        snapshot["config_integrity"] = {
            "status": "ATENCAO",
            "healthy": False,
            "baseline_available": False,
            "changed_count": 0,
            "critical_missing_count": 0,
            "changes": [],
            "error": str(exc),
        }
    try:
        with Storage() as storage:
            ledger = PerformanceLedger(storage)
            performance = ledger.report(days=30)

            try:
                performance["signal_quality_shadow"] = (
                    ledger.signal_quality_shadow_report(
                        days=30,
                        target_seconds=int(
                            getattr(
                                settings,
                                "signal_quality_shadow_target_seconds",
                                300,
                            )
                        ),
                        grace_seconds=int(
                            getattr(
                                settings,
                                "signal_quality_shadow_grace_seconds",
                                180,
                            )
                        ),
                        persist=False,
                    )
                )
            except Exception as shadow_exc:
                performance["signal_quality_shadow"] = {
                    "error": str(shadow_exc),
                    "shadow_confirmed": 0,
                    "shadow_missing": 0,
                    "shadow_coverage_pct": 0.0,
                }

            shadow_queue_snapshot = getattr(ledger, "shadow_queue_snapshot", None)
            if callable(shadow_queue_snapshot):
                performance["shadow_queue"] = shadow_queue_snapshot(
                    hours=24,
                    target_seconds=int(getattr(settings, "signal_quality_shadow_target_seconds", 300)),
                    grace_seconds=int(getattr(settings, "signal_quality_shadow_grace_seconds", 180)),
                )
            snapshot["performance"] = performance
            snapshot["signal_quality"] = build_signal_quality_overview(snapshot)
            snapshot["ledger_signals"] = ledger.signals(days=30, limit=50)
            proofs = ProofLedger(storage)
            proofs.seal_due_roots()
            snapshot["proof"] = proofs.status()
            snapshot["onchain"] = OnChainLedger(storage).report(days=30, limit=50)
            rep = ReputationEngine(storage)
            rep.refresh(days=3650, limit=500)
            snapshot["reputation"] = rep.report(days=3650, limit=50)
            snapshot["observability"] = ObservabilityEngine(storage).report(days=7, limit=50)
            snapshot["distribution"] = DistributionManager(storage).status(days=7)
    except Exception as exc:
        snapshot["performance"] = {"error": str(exc), "signals_observed": 0, "win_rate_pct": 0, "tp1_hit_rate_pct": 0}
        snapshot["ledger_signals"] = []
        snapshot["proof"] = {"error": str(exc), "live_commits": 0, "legacy_backfills": 0, "sealed_daily_roots": 0}
        snapshot["onchain"] = {"summary": {"error": str(exc)}, "latest": []}
        snapshot["reputation"] = {"summary": {"error": str(exc)}, "highest_risk": [], "strongest": []}
        snapshot["observability"] = {"status": {"error": str(exc), "health_score": 0, "open_incidents": 0}, "incidents": []}
        snapshot["distribution"] = {"error": str(exc), "active_destinations": 0, "jobs": {}}
    try:
        from daniel_ai.api import status_payload
        snapshot["daniel_ai"] = status_payload()
    except Exception as exc:
        snapshot["daniel_ai"] = {"enabled": False, "error": str(exc), "openai_enabled": False}
    # SIGNAL_QUALITY_FINAL_REBUILD_V1649
    # Recalcula somente depois de performance estar completo.
    try:
        snapshot['signal_quality'] = (
            build_signal_quality_overview(snapshot)
        )
    except Exception as exc:
        snapshot['signal_quality'] = {
            'version': '16.4.9',
            'mode': 'SHADOW',
            'promotion_enabled': False,
            'samples': 0,
            'error': str(exc),
        }

    # CONFIG_CHANGE_HISTORY_OVERVIEW_V1652
    try:
        from csm.config_change_history import overview_status
        snapshot['config_change_history'] = overview_status(
            limit=20,
        )
    except Exception as exc:
        snapshot['config_change_history'] = {
            'version': '16.5.2',
            'status': 'UNAVAILABLE',
            'reason': type(exc).__name__,
            'secret_values_stored': False,
            'automatic_restore': False,
            'automatic_block': False,
        }

    return snapshot


# CONFIG_CHANGE_HISTORY_WRAPPER_V1652
_admin_snapshot_v1652_original = _admin_snapshot


def _admin_snapshot():
    snapshot = _admin_snapshot_v1652_original()

    if not isinstance(snapshot, dict):
        return snapshot

    # Evita modificar o objeto original.
    snapshot = dict(snapshot)

    try:
        from csm.config_change_history import overview_status

        snapshot["config_change_history"] = overview_status(
            limit=20,
        )

    except Exception as exc:
        snapshot["config_change_history"] = {
            "version": "16.5.2",
            "status": "UNAVAILABLE",
            "reason": type(exc).__name__,
            "events": 0,
            "secret_values_stored": False,
            "automatic_restore": False,
            "automatic_block": False,
        }

    return snapshot





# CONFIG_CHANGE_HISTORY_FINAL_WRAPPER_V1652
_admin_snapshot_v1652_final_original = _admin_snapshot


def _admin_snapshot():
    snapshot = _admin_snapshot_v1652_final_original()

    if not isinstance(snapshot, dict):
        return snapshot

    snapshot = dict(snapshot)

    try:
        from csm.config_change_history import overview_status

        snapshot["config_change_history"] = overview_status(
            limit=20,
        )

    except Exception as exc:
        snapshot["config_change_history"] = {
            "version": "16.5.2",
            "status": "UNAVAILABLE",
            "reason": type(exc).__name__,
            "events": 0,
            "secret_values_stored": False,
            "automatic_restore": False,
            "automatic_block": False,
        }

    return snapshot


class AdminHandler(BaseHTTPRequestHandler):
    server_version = "CSMAdmin/16.4.3"

    def _authorized(self) -> bool:
        expected = getattr(self.server, "admin_token", "")
        if not expected:
            return True
        supplied = self.headers.get("X-Admin-Token", "")
        if not supplied:
            auth = str(self.headers.get("Authorization", "") or "").strip()
            if auth.lower().startswith("bearer "):
                supplied = auth[7:].strip()
        if not supplied:
            query = parse_qs(urlparse(self.path).query)
            supplied = (query.get("token") or [""])[0]
        return hmac.compare_digest(str(supplied), str(expected))

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if content_type.startswith("text/html"):
            self.send_header(
                "Content-Security-Policy",
                "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
            )
        self.end_headers()
        self.wfile.write(body)

    def _request_token(self) -> str:
        query = parse_qs(urlparse(self.path).query)
        return str((query.get("token") or [""])[0])

    def do_GET(self) -> None:  # noqa: N802
        if not self._authorized():
            self._send(HTTPStatus.UNAUTHORIZED, b'{"error":"unauthorized"}', "application/json; charset=utf-8")
            return
        path = urlparse(self.path).path
        try:
            if path == "/":
                self._send(HTTPStatus.OK, _page(_admin_snapshot(), token=self._request_token()), "text/html; charset=utf-8")
            elif path == "/daniel-ai":
                query = parse_qs(urlparse(self.path).query)
                try:
                    user_id = int((query.get("user_id") or ["0"])[0] or 0)
                except Exception:
                    user_id = 0
                self._send(HTTPStatus.OK, _daniel_panel_page(token=self._request_token(), user_id=user_id), "text/html; charset=utf-8")
            elif path == "/api/status":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot()), "application/json; charset=utf-8")
            elif path == "/api/retool/overview":
                from .retool_control import runtime_snapshot
                from .runtime_resilience import overview as runtime_resilience_overview
                from daniel_ai.config import DanielSettings, ensure_directories
                from daniel_ai.tts import DanielSpeech
                snap = _admin_snapshot()
                try:
                    from .provider_health import load_provider_health
                    provider_health = load_provider_health()
                except Exception:
                    provider_health = {"overall_health": 0, "counts": {}, "providers": []}
                cfg = ensure_directories(DanielSettings.from_env())
                speech = DanielSpeech(cfg).status()
                runtime_data = runtime_snapshot()
                resilience_data = runtime_resilience_overview(
                    current_admin_bridge=True,
                    runtime_override=runtime_data,
                )
                leader_data = dict(snap.get("leader", {}) or {})
                # Retool v16.5.3: the Runtime card historically consumed
                # leader.release/health_score, which could show 8.2.1 + 100
                # while the runtime itself was degraded. Preserve the audit
                # values explicitly and expose runtime-consistent display data.
                leader_data["audit_release"] = leader_data.get("release")
                leader_data["audit_health_score"] = leader_data.get("health_score")
                leader_data["release"] = runtime_data.get("release")
                leader_data["health_score"] = runtime_data.get("health_score")
                leader_data["operational_health_score"] = resilience_data.get("health_score")
                payload = {
                    "ok": True,
                    "runtime": runtime_data,
                    "scanner": snap.get("scanner", {}),
                    "leader": leader_data,
                    "performance": snap.get("performance", {}),
                    "config_integrity": snap.get("config_integrity", {}),
                    "config_change_history": snap.get("config_change_history", {}),
                    "runtime_resilience": resilience_data,
                    "signal_quality": snap.get("signal_quality", {}),
                    "providers": provider_health,
                    "daniel_ai": snap.get("daniel_ai", {}),
                    "speech": {
                        "enabled": speech.enabled,
                        "ready": speech.ready,
                        "selected_engine": speech.selected_engine,
                        "voice": speech.voice,
                        "available_engines": speech.available_engines,
                        "speechify_enabled": speech.speechify_enabled,
                        "speechify_configured": speech.speechify_configured,
                        "speechify_voice_id": speech.speechify_voice_id,
                        "speechify_model": speech.speechify_model,
                    },
                    "alerts": snap.get("operational_alerts", []),
                }
                self._send(HTTPStatus.OK, _json_bytes(payload), "application/json; charset=utf-8")
            elif path == "/api/update/status":
                from pathlib import Path
                from . import __product_version__
                from .project_leader import ProjectLeader

                leader = ProjectLeader()
                packages = []

                for bundle in sorted(leader.inbox_dir.glob("*.zip")):
                    try:
                        manifest = leader.validate_update_bundle(bundle)
                        packages.append({
                            "filename": bundle.name,
                            "valid": True,
                            "update_id": manifest.get("update_id"),
                            "version": manifest.get("version"),
                            "title": manifest.get("title") or manifest.get("update_id"),
                        })
                    except Exception as exc:
                        packages.append({
                            "filename": bundle.name,
                            "valid": False,
                            "error": str(exc),
                        })

                proposals = []

                for proposal in leader.list_proposals():
                    if proposal.action != "apply_update_bundle":
                        continue

                    bundle_value = str(
                        proposal.parameters.get("bundle") or ""
                    )

                    proposals.append({
                        "proposal_id": proposal.proposal_id,
                        "status": proposal.status,
                        "title": proposal.title,
                        "severity": proposal.severity,
                        "created_at": proposal.created_at,
                        "approved_at": proposal.approved_at,
                        "applied_at": proposal.applied_at,
                        "result": proposal.result,
                        "bundle": Path(bundle_value).name if bundle_value else None,
                    })

                payload = {
                    "ok": True,
                    "current_version": __product_version__,
                    "available_count": sum(
                        1 for item in packages if item.get("valid")
                    ),
                    "invalid_count": sum(
                        1 for item in packages if not item.get("valid")
                    ),
                    "packages": packages,
                    "applied_count": len(
                        list(leader.applied_dir.glob("*.zip"))
                    ),
                    "maintenance": leader.maintenance(),
                    "proposals": proposals[:20],
                }

                self._send(
                    HTTPStatus.OK,
                    _json_bytes(payload),
                    "application/json; charset=utf-8",
                )

            elif path == "/api/update/finalize/status":
                from .post_update import status as post_update_status
                self._send(
                    HTTPStatus.OK,
                    _json_bytes(post_update_status()),
                    "application/json; charset=utf-8",
                )

            elif path in {"/api/setup/summary", "/api/setup/config", "/api/setup/chains"}:
                from urllib import request as urllib_request

                supervisor_path = {
                    "/api/setup/summary": "/setup/summary",
                    "/api/setup/config": "/setup/config",
                    "/api/setup/chains": "/setup/chains",
                }[path]

                try:
                    with urllib_request.urlopen(
                        "http://127.0.0.1:8790" + supervisor_path,
                        timeout=5,
                    ) as response:
                        body = response.read()

                    self._send(
                        HTTPStatus.OK,
                        body,
                        "application/json; charset=utf-8",
                    )

                except Exception as exc:
                    self._send(
                        HTTPStatus.BAD_GATEWAY,
                        _json_bytes({
                            "ok": False,
                            "error": "supervisor_unavailable",
                            "message": str(exc),
                        }),
                        "application/json; charset=utf-8",
                    )

            elif path == "/api/config-integrity":
                self._send(
                    HTTPStatus.OK,
                    _json_bytes(
                        ConfigIntegrityGuard().report(
                            persist=False
                        )
                    ),
                    "application/json; charset=utf-8",
                )
            elif path == "/api/performance":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("performance", {})), "application/json; charset=utf-8")
            elif path == "/api/proof":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("proof", {})), "application/json; charset=utf-8")
            elif path == "/api/signals":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("ledger_signals", [])), "application/json; charset=utf-8")
            elif path == "/api/security":
                rows = _admin_snapshot().get("ledger_signals", [])
                safe = [{k: row.get(k) for k in ("id", "chain", "address", "symbol", "goplus_score", "goplus_risk_level", "goplus_buy_tax_pct", "goplus_sell_tax_pct", "goplus_top10_pct", "created_at")} for row in rows]
                self._send(HTTPStatus.OK, _json_bytes(safe), "application/json; charset=utf-8")
            elif path == "/api/onchain":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("onchain", {})), "application/json; charset=utf-8")
            elif path == "/api/reputation":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("reputation", {})), "application/json; charset=utf-8")
            elif path == "/api/observability":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("observability", {})), "application/json; charset=utf-8")
            elif path == "/api/distribution":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("distribution", {})), "application/json; charset=utf-8")
            elif path == "/api/daniel-ai":
                self._send(HTTPStatus.OK, _json_bytes(_admin_snapshot().get("daniel_ai", {})), "application/json; charset=utf-8")
            elif path == "/api/system":
                snap = _admin_snapshot()
                self._send(HTTPStatus.OK, _json_bytes({"scanner": snap.get("scanner", {}), "leader": snap.get("leader", {}), "alerts": snap.get("operational_alerts", []), "observability": snap.get("observability", {})}), "application/json; charset=utf-8")
            elif path == "/api/users":
                self._send(HTTPStatus.OK, _json_bytes(safe_users()), "application/json; charset=utf-8")
            elif path == "/api/subscriptions":
                self._send(HTTPStatus.OK, _json_bytes(safe_subscriptions()), "application/json; charset=utf-8")
            elif path == "/api/events":
                self._send(HTTPStatus.OK, _json_bytes(recent_events(100)), "application/json; charset=utf-8")
            elif path == "/healthz":
                self._send(HTTPStatus.OK, b'{"status":"ok"}', "application/json; charset=utf-8")
            else:
                self._send(HTTPStatus.NOT_FOUND, b'{"error":"not_found"}', "application/json; charset=utf-8")
        except Exception as exc:
            record_event("admin_web_error", category="enterprise", severity="error", details={"error": str(exc), "path": path})
            self._send(HTTPStatus.INTERNAL_SERVER_ERROR, _json_bytes({"error": "internal_error"}), "application/json; charset=utf-8")

    def do_POST(self) -> None:  # noqa: N802
        if not self._authorized():
            self._send(HTTPStatus.UNAUTHORIZED, b'{"error":"unauthorized"}', "application/json; charset=utf-8")
            return
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length < 0 or length > 65536:
                self._send(HTTPStatus.BAD_REQUEST, b'{"error":"invalid_body"}', "application/json; charset=utf-8")
                return
            raw = self.rfile.read(length) if length else b""
            if path == "/daniel-ai":
                if not raw:
                    self._send(HTTPStatus.BAD_REQUEST, b'{"error":"invalid_body"}', "application/json; charset=utf-8")
                    return
                form = parse_qs(raw.decode("utf-8", errors="replace"), keep_blank_values=True)
                question = str((form.get("question") or [""])[0]).strip()
                try:
                    user_id = int((form.get("user_id") or ["0"])[0] or 0)
                except Exception:
                    user_id = 0
                answer = ""
                if question:
                    from daniel_ai.api import ask_payload
                    answer = str(ask_payload(question, user_id=user_id, source="admin-panel").get("answer") or "")
                self._send(HTTPStatus.OK, _daniel_panel_page(token=self._request_token(), user_id=user_id, question=question, answer=answer), "text/html; charset=utf-8")
                return

            if path == "/api/update/finalize":
                from .post_update import PostUpdateError, launch_background

                try:
                    result = launch_background(delay_seconds=1.2)
                except PostUpdateError as exc:
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "post_update_busy",
                            "message": str(exc),
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                record_event(
                    "retool_update_finalize",
                    category="enterprise",
                    severity="info",
                    details={"accepted": True, "pid": result.get("pid")},
                )
                self._send(
                    HTTPStatus.ACCEPTED,
                    _json_bytes(result),
                    "application/json; charset=utf-8",
                )
                return

            if path == "/api/update/prepare":
                from pathlib import Path
                from .project_leader import ProjectLeader

                payload = (
                    json.loads(raw.decode("utf-8"))
                    if raw
                    else {}
                )

                update_id = str(
                    (payload or {}).get("update_id") or ""
                ).strip()

                filename = str(
                    (payload or {}).get("filename") or ""
                ).strip()

                leader = ProjectLeader()
                candidates = []

                for bundle in sorted(
                    leader.inbox_dir.glob("*.zip")
                ):
                    try:
                        manifest = leader.validate_update_bundle(
                            bundle
                        )
                    except Exception:
                        continue

                    if (
                        update_id
                        and str(manifest.get("update_id") or "")
                        != update_id
                    ):
                        continue

                    if filename and bundle.name != filename:
                        continue

                    candidates.append((bundle, manifest))

                if not candidates:
                    self._send(
                        HTTPStatus.NOT_FOUND,
                        _json_bytes({
                            "ok": False,
                            "error": "update_not_found",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                if (
                    len(candidates) > 1
                    and not update_id
                    and not filename
                ):
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "multiple_updates_available",
                            "message": (
                                "Informe update_id ou filename."
                            ),
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                bundle, manifest = candidates[0]

                # Uma proposta já aprovada não deve ser
                # substituída silenciosamente.
                for existing in leader.list_proposals():
                    if existing.action != "apply_update_bundle":
                        continue

                    existing_bundle = Path(
                        str(
                            existing.parameters.get("bundle")
                            or ""
                        )
                    ).expanduser().resolve()

                    if (
                        existing_bundle == bundle.resolve()
                        and existing.status == "APPROVED"
                    ):
                        self._send(
                            HTTPStatus.CONFLICT,
                            _json_bytes({
                                "ok": False,
                                "error": "update_already_approved",
                                "proposal_id": existing.proposal_id,
                            }),
                            "application/json; charset=utf-8",
                        )
                        return

                # PENDING antigo do mesmo pacote pode ter
                # perdido seu código após reload da UI.
                # Mantemos histórico e criamos um novo desafio.
                for existing in leader.list_proposals():
                    if (
                        existing.action
                        != "apply_update_bundle"
                        or existing.status != "PENDING"
                    ):
                        continue

                    existing_bundle = Path(
                        str(
                            existing.parameters.get("bundle")
                            or ""
                        )
                    ).expanduser().resolve()

                    if existing_bundle == bundle.resolve():
                        existing.status = "OBSOLETE"
                        existing.result = (
                            "Substituída por nova preparação "
                            "via painel."
                        )
                        leader._write_proposal(existing)

                proposal, approval_code = (
                    leader.create_proposal(
                        title=(
                            manifest.get("title")
                            or manifest["update_id"]
                        ),
                        reason=str(bundle),
                        severity="medium",
                        action="apply_update_bundle",
                        parameters={
                            "bundle": str(bundle.resolve()),
                        },
                    )
                )

                record_event(
                    "retool_update_prepare",
                    category="enterprise",
                    severity="info",
                    details={
                        "proposal_id": proposal.proposal_id,
                        "update_id": manifest.get("update_id"),
                        "version": manifest.get("version"),
                    },
                )

                self._send(
                    HTTPStatus.OK,
                    _json_bytes({
                        "ok": True,
                        "proposal_id": proposal.proposal_id,
                        "approval_code": approval_code,
                        "approval_code_one_time": True,
                        "status": proposal.status,
                        "update": {
                            "update_id": manifest.get("update_id"),
                            "version": manifest.get("version"),
                            "title": (
                                manifest.get("title")
                                or manifest.get("update_id")
                            ),
                            "filename": bundle.name,
                        },
                    }),
                    "application/json; charset=utf-8",
                )
                return

            if path == "/api/update/approve":
                from pathlib import Path
                from .project_leader import (
                    ProjectLeader,
                    ProjectLeaderError,
                )

                if not raw:
                    self._send(
                        HTTPStatus.BAD_REQUEST,
                        _json_bytes({
                            "ok": False,
                            "error": "invalid_body",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                payload = json.loads(
                    raw.decode("utf-8")
                )

                proposal_id = str(
                    (payload or {}).get("proposal_id") or ""
                ).strip()

                approval_code = str(
                    (payload or {}).get("approval_code") or ""
                ).strip()

                if not proposal_id or not approval_code:
                    self._send(
                        HTTPStatus.BAD_REQUEST,
                        _json_bytes({
                            "ok": False,
                            "error": (
                                "proposal_id_and_approval_code_required"
                            ),
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                leader = ProjectLeader()
                proposal = leader.get_proposal(proposal_id)

                if proposal.action != "apply_update_bundle":
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "not_update_proposal",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                bundle = Path(
                    str(
                        proposal.parameters.get("bundle")
                        or ""
                    )
                ).expanduser().resolve()

                # Aprovação só é aceita enquanto o pacote
                # continua presente e válido no inbox.
                if not bundle.exists():
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "update_bundle_missing",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                leader.validate_update_bundle(bundle)

                try:
                    proposal = leader.approve(
                        proposal_id,
                        approval_code,
                    )
                except ProjectLeaderError as exc:
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "approval_failed",
                            "message": str(exc),
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                record_event(
                    "retool_update_approve",
                    category="enterprise",
                    severity="info",
                    details={
                        "proposal_id": proposal.proposal_id,
                    },
                )

                self._send(
                    HTTPStatus.OK,
                    _json_bytes({
                        "ok": True,
                        "proposal_id": proposal.proposal_id,
                        "status": proposal.status,
                        "approved_at": proposal.approved_at,
                    }),
                    "application/json; charset=utf-8",
                )
                return

            if path == "/api/update/apply":
                from .project_leader import (
                    ProjectLeader,
                    ProjectLeaderError,
                )

                if not raw:
                    self._send(
                        HTTPStatus.BAD_REQUEST,
                        _json_bytes({
                            "ok": False,
                            "error": "invalid_body",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                payload = json.loads(
                    raw.decode("utf-8")
                )

                proposal_id = str(
                    (payload or {}).get("proposal_id") or ""
                ).strip()

                if not proposal_id:
                    self._send(
                        HTTPStatus.BAD_REQUEST,
                        _json_bytes({
                            "ok": False,
                            "error": "proposal_id_required",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                leader = ProjectLeader()
                proposal = leader.get_proposal(proposal_id)

                if proposal.action != "apply_update_bundle":
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "not_update_proposal",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                if proposal.status != "APPROVED":
                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "proposal_not_approved",
                            "status": proposal.status,
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                try:
                    proposal = leader.apply(proposal_id)
                except Exception as exc:
                    record_event(
                        "retool_update_apply",
                        category="enterprise",
                        severity="error",
                        details={
                            "proposal_id": proposal_id,
                            "ok": False,
                            "error": str(exc),
                        },
                    )

                    self._send(
                        HTTPStatus.CONFLICT,
                        _json_bytes({
                            "ok": False,
                            "error": "update_failed",
                            "message": str(exc),
                            "proposal_id": proposal_id,
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                record_event(
                    "retool_update_apply",
                    category="enterprise",
                    severity="info",
                    details={
                        "proposal_id": proposal.proposal_id,
                        "ok": True,
                    },
                )

                self._send(
                    HTTPStatus.OK,
                    _json_bytes({
                        "ok": True,
                        "proposal_id": proposal.proposal_id,
                        "status": proposal.status,
                        "applied_at": proposal.applied_at,
                        "result": proposal.result,
                        "next_steps": [
                            "finalize_update",
                            "poll_finalize_status",
                        ],
                    }),
                    "application/json; charset=utf-8",
                )
                return

            if path == "/api/setup/update":
                from urllib import request as urllib_request
                from urllib.error import HTTPError

                if not raw:
                    self._send(
                        HTTPStatus.BAD_REQUEST,
                        b'{"ok":false,"error":"invalid_body"}',
                        "application/json; charset=utf-8",
                    )
                    return

                req = urllib_request.Request(
                    "http://127.0.0.1:8790/setup/update",
                    data=raw,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )

                try:
                    with urllib_request.urlopen(req, timeout=10) as response:
                        body = response.read()
                        status = response.status

                except HTTPError as exc:
                    body = exc.read()
                    status = exc.code

                except Exception:
                    self._send(
                        HTTPStatus.BAD_GATEWAY,
                        _json_bytes({
                            "ok": False,
                            "error": "supervisor_unavailable",
                        }),
                        "application/json; charset=utf-8",
                    )
                    return

                self._send(
                    status,
                    body,
                    "application/json; charset=utf-8",
                )
                return

            action_map = {
                "/api/actions/runtime/start": "start",
                "/api/actions/runtime/stop": "stop",
                "/api/actions/runtime/restart": "restart",
                "/api/actions/backup": "db-backup",
                "/api/actions/doctor": "doctor",
                "/api/actions/selftest": "selftest",
            }
            if path in action_map:
                from .retool_control import start_bot, stop_bot, restart_bot, run_local_command
                action = action_map[path]
                if action == "start":
                    result = start_bot()
                elif action == "stop":
                    result = stop_bot()
                elif action == "restart":
                    result = restart_bot()
                else:
                    result = run_local_command(action)
                record_event("retool_admin_action", category="enterprise", severity="info" if result.get("ok") else "warning", details={"action": action, "ok": bool(result.get("ok"))})
                self._send(HTTPStatus.OK if result.get("ok") else HTTPStatus.CONFLICT, _json_bytes(result), "application/json; charset=utf-8")
                return

            if path != "/api/daniel-ai/ask":
                self._send(HTTPStatus.NOT_FOUND, b'{"error":"not_found"}', "application/json; charset=utf-8")
                return
            if not raw:
                self._send(HTTPStatus.BAD_REQUEST, b'{"error":"invalid_body"}', "application/json; charset=utf-8")
                return
            payload = json.loads(raw.decode("utf-8"))
            question = str((payload or {}).get("question") or "").strip()
            user_id = int((payload or {}).get("user_id") or 0)
            if not question:
                self._send(HTTPStatus.BAD_REQUEST, b'{"error":"question_required"}', "application/json; charset=utf-8")
                return
            from daniel_ai.api import ask_payload
            self._send(HTTPStatus.OK, _json_bytes(ask_payload(question, user_id=user_id, source="retool-admin-api")), "application/json; charset=utf-8")
        except (ValueError, TypeError, json.JSONDecodeError):
            self._send(HTTPStatus.BAD_REQUEST, b'{"error":"invalid_request"}', "application/json; charset=utf-8")
        except Exception as exc:
            record_event("admin_api_error", category="enterprise", severity="error", details={"error": str(exc), "path": path})
            self._send(HTTPStatus.INTERNAL_SERVER_ERROR, b'{"error":"internal_error"}', "application/json; charset=utf-8")

    def log_message(self, fmt: str, *args: object) -> None:
        message = fmt % args
        # Query-string tokens are supported for compatibility with the browser
        # UI, but they must never be persisted in the audit log.
        safe_target = _redact_request_target(self.path)
        if safe_target != self.path:
            message = message.replace(self.path, safe_target)
        record_event("admin_web_access", category="enterprise", details={"message": message})


def serve_admin_web(host: str, port: int, token: str = "") -> None:
    if not _is_loopback(host) and not token:
        raise RuntimeError("ADMIN_WEB_TOKEN é obrigatório quando o painel não usa localhost")
    server = ThreadingHTTPServer((host, port), AdminHandler)
    server.admin_token = token  # type: ignore[attr-defined]
    record_event("admin_web_started", category="enterprise", details={"host": host, "port": port, "protected": bool(token)})
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
        record_event("admin_web_stopped", category="enterprise", details={"host": host, "port": port})
