from __future__ import annotations

import time
import json
from datetime import datetime, timezone
from pathlib import Path

from html import escape

from .config import settings
from .http_client import HTTPTransientError
from .chains import CHAINS, normalize_chain, detect_chain
from .plans import PLANS
from .storage import Storage
from .formatting import report, compact_address
from .experience import (
    dashboard_intro, keyboard_for_plan, opportunity_profile, premium_score_details,
    project_stage, signal_reasons, start_keyboard, welcome_text, plan_group, interval_label,
    home_text, activated_text, signal_header, BRAND_DIVIDER, subscription_timing,
)
from .intelligence_center import build_center_text, center_keyboard
from .telegram import Telegram
from .ashell_runtime_v831 import is_ashell_runtime
from .telegram_mobile_v831 import TelegramMobileV831
from .market_single_v831 import SingleRuntimeMarketV831
from .scanner_single_v831 import SingleRuntimeScannerV831
from .logging_setup import logger
from .payment_service import PaymentService, only_digits, valid_document
from .project_leader import ProjectLeader, ProjectLeaderError
from .user_profiles import UserProfileStore
from .professional_ops import admin_dashboard
from .ui_callbacks_v830 import CallbackRouterV830
from .preferences_ui import build_preferences_screen


MAIN_KEYBOARD = keyboard_for_plan("free")


class App:
    def __init__(self, storage=None, market=None, telegram=None):
        self.storage = storage or Storage()
        self.mobile_runtime = is_ashell_runtime()
        self.market = market or SingleRuntimeMarketV831(mobile=self.mobile_runtime)
        if telegram is not None:
            self.telegram = telegram
        elif settings.telegram_token:
            self.telegram = TelegramMobileV831() if self.mobile_runtime else Telegram()
        else:
            self.telegram = None
        self.pending: dict[int, str | None] = {}
        self.last_results: dict[int, tuple[str, str, dict]] = {}
        self.payments = PaymentService(self.storage) if settings.payments_ready else None
        self.pending_payment: dict[int, dict] = {}
        self.scanner = SingleRuntimeScannerV831(market=self.market, mobile=self.mobile_runtime)
        # O mesmo scanner cooperativo atende o ciclo automático. Nenhum worker Python é criado.
        self.scanner_async = self.scanner
        self._pending_auto_scan_groups: list[tuple[str, int]] = []
        self._pending_manual_scan_users: set[int] = set()
        self.scanner_sessions: dict[int, list[dict]] = {}
        self.project_leader = ProjectLeader() if settings.project_leader_enabled else None
        self.started_at = datetime.now(timezone.utc)
        self.runtime_next_cycles: dict[str, float] = {}
        self.user_profiles = UserProfileStore()
        self.callback_router = CallbackRouterV830(self)

    def main_menu(self, user: dict, first_name: str = "") -> str:
        return home_text(user, first_name)

    @staticmethod
    def networks_text() -> str:
        rows = [f"{data['emoji']} <b>{data['label']}</b> — <code>{key}</code>" for key, data in CHAINS.items()]
        return "🌐 <b>REDES DISPONÍVEIS</b>\n\n" + "\n".join(rows)

    @staticmethod
    def plan_name(user: dict) -> str:
        plan = PLANS[user["plan"]]
        return f"{plan['emoji']} {plan['label']}"

    @staticmethod
    def user_keyboard(user: dict) -> dict:
        return keyboard_for_plan(user.get("plan"))

    def plans_text(self) -> str:
        return (
            "💎 <b>PLANOS E EXPERIÊNCIAS</b>\n"
            f"{BRAND_DIVIDER}\n\n"
            "🆓 <b>ESSENCIAL — GRÁTIS</b>\n"
            "⏱ Sinais a cada 15 minutos\n"
            "• visão rápida e profissional\n"
            "• score, liquidez, volume e contrato\n\n"
            f"💠 <b>PLUS MENSAL</b> — R$ {settings.asaas_plus_value:.2f}\n"
            f"💠 <b>PLUS ANUAL</b> — R$ {settings.asaas_plus_annual_value:.2f}\n"
            "⏱ Sinais a cada 5 minutos\n"
            "• estágio, confiança e motivos do sinal\n"
            "• entrada, alvos, stop, favoritos e histórico\n\n"
            f"👑 <b>PREMIUM MENSAL</b> — R$ {settings.asaas_premium_value:.2f}\n"
            f"👑 <b>PREMIUM ANUAL</b> — R$ {settings.asaas_premium_annual_value:.2f}\n"
            "⏱ Radar a cada 1 minuto\n"
            "• composição do score e tese completa\n"
            "• pressão compradora, DEX, market cap e FDV\n\n"
            "✅ PIX e cartão pelo Asaas\n"
            "✅ Ativação automática após confirmação\n\n"
            "⚠️ <i>Mais frequência e profundidade não significam garantia de lucro.</i>"
        )

    def sales_keyboard(self):
        rows=[]
        if settings.payments_ready:
            rows += [
                [{"text":"💠 Plus mensal","callback_data":"subscribe|plus"},{"text":"👑 Premium mensal","callback_data":"subscribe|premium"}],
                [{"text":"💠 Plus anual","callback_data":"subscribe|plus_annual"},{"text":"👑 Premium anual","callback_data":"subscribe|premium_annual"}],
                [{"text":"🔄 Verificar pagamento","callback_data":"payment_check"}],
            ]
        else:
            rows.append([{"text":"📩 Falar com atendimento","url":f"https://t.me/{settings.sales_contact.lstrip('@')}"}])
        rows.append([{"text":"🏠 Menu principal","callback_data":"menu"}])
        return {"inline_keyboard":rows}

    def payment_text(self, plan: str) -> tuple[str, dict]:
        if not self.payments:
            return "⚠️ Pagamentos automáticos não configurados.", self.sales_keyboard()
        meta=PLANS[plan]
        period="ano" if meta["cycle"]=="YEARLY" else "mês"
        return (
            f"💳 <b>{meta['label'].upper()}</b>\n\n"
            f"Valor: <b>R$ {meta['value']:.2f}/{period}</b>\n"
            f"Acesso: <b>{meta['days']} dias</b>\n"
            "Pagamento único para este período.\n\n"
            "A cobrança é processada em página segura do Asaas.", {}
        )

    def payment_method_keyboard(self, plan: str):
        rows=[]
        methods=set(settings.asaas_payment_methods)
        if "PIX" in methods:
            rows.append([{"text":"⚡ Pagar com PIX","callback_data":f"paymethod|{plan}|PIX"}])
        if "CREDIT_CARD" in methods:
            rows.append([{"text":"💳 Pagar com cartão","callback_data":f"paymethod|{plan}|CREDIT_CARD"}])
        rows.append([{"text":"⬅️ Planos","callback_data":"plans"}])
        return {"inline_keyboard":rows}

    def request_payment_document(self, chat_id: int, user_id: int, plan: str, sender: dict, billing_type: str):
        if not self.payments:
            return self.telegram.send(chat_id, "⚠️ Pagamentos ainda não estão configurados.", self.sales_keyboard())
        billing_type=str(billing_type or "").upper()
        if billing_type not in settings.asaas_payment_methods:
            return self.telegram.send(chat_id, "⚠️ Forma de pagamento não habilitada.", self.sales_keyboard())
        full_name = " ".join(
            part for part in [sender.get("first_name", ""), sender.get("last_name", "")] if part
        ).strip()
        self.pending_payment[user_id] = {
            "plan": plan,
            "name": full_name or f"Cliente Telegram {user_id}",
            "billing_type": billing_type,
        }
        method_label="PIX" if billing_type=="PIX" else "cartão de crédito"
        return self.telegram.send(
            chat_id,
            f"🪪 <b>DADOS PARA A COBRANÇA — {method_label.upper()}</b>\n\n"
            "Envie somente seu <b>CPF ou CNPJ</b>.\n"
            "O documento será enviado diretamente ao Asaas para criar o cliente "
            "e não será salvo no banco do bot.\n\n"
            "Para cancelar, envie <code>/cancelar</code>.",
            MAIN_KEYBOARD,
        )

    def create_payment_order(self, chat_id: int, user_id: int, plan: str, name: str, document: str, billing_type: str):
        try:
            row = self.payments.create_payment(user_id=user_id, plan=plan, name=name, cpf_cnpj=document, billing_type=billing_type)
            text, _ = self.payment_text(plan)
            rows=[]
            if row.get("invoice_url"):
                label="⚡ Abrir pagamento PIX" if billing_type=="PIX" else "💳 Abrir pagamento com cartão"
                rows.append([{"text":label,"url":row["invoice_url"]}])
            if billing_type=="PIX" and row.get("pix_payload"):
                payload=escape(str(row["pix_payload"]))
                text += f"\n\n⚡ <b>PIX COPIA E COLA</b>\n<code>{payload}</code>"
            rows += [[{"text":"✅ Já paguei — verificar","callback_data":"payment_check"}],[{"text":"⬅️ Planos","callback_data":"plans"}]]
            keyboard={"inline_keyboard":rows}
            return self.telegram.send(chat_id, text, keyboard)
        except Exception as exc:
            logger.exception("Falha ao criar cobrança Asaas")
            return self.telegram.send(chat_id, f"❌ Não foi possível criar a cobrança: {escape(str(exc))}", self.sales_keyboard())

    def verify_payment(self, chat_id: int, user_id: int):
        if not self.payments:
            return self.telegram.send(chat_id, "⚠️ Pagamentos automáticos não configurados.", MAIN_KEYBOARD)
        try:
            results = self.payments.verify_user(user_id)
            user = self.storage.get_user(user_id)
            if user["plan"] != "free":
                return self.telegram.send(
                    chat_id,
                    activated_text(user),
                    MAIN_KEYBOARD,
                )
            if any(item.get("state") == "pending" for item in results):
                return self.telegram.send(chat_id, "⏳ Pagamento ainda não confirmado. Aguarde um pouco e verifique novamente.", self.sales_keyboard())
            return self.telegram.send(chat_id, "ℹ️ Nenhum pagamento confirmado foi localizado para esta conta. Crie uma cobrança em Planos e tente novamente.", self.sales_keyboard())
        except Exception as exc:
            logger.exception("Falha ao verificar pagamento")
            return self.telegram.send(chat_id, f"❌ Falha temporária na verificação: {escape(str(exc))}", MAIN_KEYBOARD)

    def plan_status_text(self, user: dict) -> str:
        plan = PLANS[user["plan"]]
        used = self.storage.count_today(user["user_id"])
        limit = plan["limit"]
        usage = f"{used}/∞" if limit is None else f"{used}/{limit}"
        group = plan_group(user.get("plan"))
        level = "ESSENCIAL" if group == "free" else "PLUS" if group == "plus" else "PREMIUM"
        due_date, days_text, _ = subscription_timing(user)
        renewal = "Automática" if group != "free" and settings.asaas_auto_renew else "Manual"
        plan_badge = "🟢 PLANO GRÁTIS" if group == "free" else "🔵 PLANO PLUS" if group == "plus" else "👑 PLANO PREMIUM"
        return (
            f"{BRAND_DIVIDER}\n"
            f"{plan['emoji']} <b>PHANTOM ALERT • MINHA ASSINATURA</b>\n"
            f"{BRAND_DIVIDER}\n\n"
            f"<b>{plan_badge}</b>\n\n"
            "👤 <b>PLANO E ACESSO</b>\n"
            f"• Plano atual: <b>{plan['emoji']} {plan['label']}</b>\n"
            f"• Status: <b>🟢 Ativo</b>\n"
            f"• Scanner: <b>automático a cada {interval_label(user.get('plan'))}</b>\n"
            f"• Próximo ciclo: <b>em até {interval_label(user.get('plan'))}</b>\n\n"
            "📊 <b>UTILIZAÇÃO</b>\n"
            f"• Análises hoje: <b>{usage}</b>\n"
            f"• Favoritos: <b>{self.storage.favorite_count(user['user_id'])}/{plan['favorites']}</b>\n\n"
            "📅 <b>VENCIMENTO</b>\n"
            f"• Data: <b>{due_date}</b>\n"
            f"• Dias restantes: <b>{days_text}</b>\n"
            f"• Renovação: <b>{renewal}</b>\n\n"
            "⚠️ <i>Os sinais são educacionais e não garantem retorno.</i>"
        )

    @staticmethod
    def _compact_usd(value: float) -> str:
        value = float(value or 0)
        if abs(value) >= 1_000_000_000:
            return f"US$ {value / 1_000_000_000:.2f} bi"
        if abs(value) >= 1_000_000:
            return f"US$ {value / 1_000_000:.2f} mi"
        if abs(value) >= 1_000:
            return f"US$ {value / 1_000:.1f} mil"
        return f"US$ {value:,.0f}"

    @staticmethod
    def _score_classification(score: int) -> tuple[str, str]:
        score = max(0, min(100, int(score or 0)))
        stars = "⭐" * max(1, min(5, (score + 19) // 20))
        if score >= 90:
            label = "Excelente"
        elif score >= 80:
            label = "Muito forte"
        elif score >= 70:
            label = "Forte"
        elif score >= 55:
            label = "Moderada"
        else:
            label = "Em observação"
        return stars, label

    def scanner_text(self, user_id: int, *, page: int = 0, force: bool = False) -> tuple[str, dict]:
        # No a-Shell o scanner nunca roda de forma síncrona dentro do callback.
        # O clique agenda um ciclo cooperativo e devolve a UI imediatamente.
        if force:
            self.scanner_sessions.pop(user_id, None)
        if user_id not in self.scanner_sessions:
            pending_users = getattr(self, "_pending_manual_scan_users", None)
            # Compatibilidade com testes/integrações antigas que injetam um scanner
            # simples sem a API cooperativa start/poll.
            if pending_users is None or not hasattr(self.scanner, "start"):
                self.scanner_sessions[user_id] = self.scanner.scan(force=force)
            else:
                pending_users.add(int(user_id))
                if not self.scanner.active:
                    self.scanner.start(force=True)
                return (
                    "🚀 <b>SCANNER MULTICHAIN</b>\n\n"
                    "⏳ Ciclo iniciado em modo seguro para a-Shell. O bot continua respondendo enquanto os ativos são analisados.\n\n"
                    "Quando terminar, o resultado será enviado automaticamente.",
                    {"inline_keyboard": [[{"text": "🔄 Atualizar", "callback_data": "scanner"}], [{"text": "🏠 Menu", "callback_data": "menu"}]]},
                )
        results = self.scanner_sessions.get(user_id, [])
        stats = self.scanner.last_stats
        page_size = 3
        total_pages = max(1, (len(results) + page_size - 1) // page_size)
        page = max(0, min(page, total_pages - 1))

        summary = (
            "📊 <b>RESUMO DO CICLO</b>\n"
            f"🔎 Descobertos: <b>{stats.get('discovered', 0)}</b>   "
            f"⚙️ Analisados: <b>{stats.get('analyzed', 0)}</b>   "
            f"✅ Aprovados: <b>{stats.get('approved', 0)}</b>"
        )
        if not results:
            return (
                "🚀 <b>SCANNER MULTICHAIN</b>\n\n" + summary
                + "\n\nNenhum ativo passou pelos filtros neste ciclo.\n"
                "Use <b>Novo ciclo</b> mais tarde ou ajuste os filtros no <code>.env</code>.\n\n"
                "⚠️ Score é filtro técnico, não garantia de lucro.",
                {"inline_keyboard": [
                    [{"text": "🔄 Novo ciclo", "callback_data": "scanner_force"}],
                    [{"text": "🏠 Menu", "callback_data": "menu"}],
                ]},
            )

        first = page * page_size
        current = results[first:first + page_size]
        lines = [
            "🚀 <b>SCANNER MULTICHAIN</b>",
            "", summary,
            f"\n🏆 <b>TOP OPORTUNIDADES</b> · página {page + 1}/{total_pages}",
        ]
        buttons: list[list[dict]] = []
        for local_index, item in enumerate(current):
            absolute = first + local_index
            rank = absolute + 1
            symbol = escape(str(item.get("symbol") or item.get("name") or "Token"))[:24]
            chain = escape(str(item.get("chain") or "?"))
            score = int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or 0)
            badge = "🟢" if score >= 85 else "🟡" if score >= 70 else "🟠"
            liquidity = self._compact_usd(float(item.get("liquidity") or 0))
            volume = self._compact_usd(float(item.get("volume24h") or 0))
            age = item.get("age_days")
            age_text = "desconhecida" if age is None else f"{float(age):.1f} dias"
            lines.extend([
                "",
                f"{badge} <b>{rank}. {symbol}</b> · {chain}",
                f"⭐ Score: <b>{score}/100</b>",
                f"💧 Liquidez: <b>{liquidity}</b>",
                f"📈 Volume 24h: <b>{volume}</b>",
                f"🕒 Idade: <b>{age_text}</b>",
            ])
            buttons.append([{"text": f"🔎 {rank}. Detalhes de {symbol[:15]}", "callback_data": f"scanner_detail|{absolute}"}])

        nav: list[dict] = []
        if page > 0:
            nav.append({"text": "⬅️ Anterior", "callback_data": f"scanner_page|{page - 1}"})
        nav.append({"text": f"📄 {page + 1}/{total_pages}", "callback_data": "scanner_noop"})
        if page + 1 < total_pages:
            nav.append({"text": "Próxima ➡️", "callback_data": f"scanner_page|{page + 1}"})
        buttons.append(nav)
        buttons += [
            [{"text": "⚡ Ver cache", "callback_data": "scanner"}, {"text": "🔄 Novo ciclo", "callback_data": "scanner_force"}],
            [{"text": "🏠 Menu", "callback_data": "menu"}],
        ]
        lines.extend(["", "⚠️ <i>Dados educacionais; não constituem recomendação financeira.</i>"])
        return "\n".join(lines), {"inline_keyboard": buttons}

    def allowed(self, user: dict, chain: str) -> tuple[bool, str]:
        plan = PLANS[user["plan"]]
        if user.get("blocked"):
            return False, "Sua conta está bloqueada. Entre em contato com o suporte."
        if plan["chains"] != "all" and chain not in plan["chains"]:
            return False, "Esta rede está disponível nos planos VIP/Plus e Premium."
        used = self.storage.count_today(user["user_id"])
        limit = plan["limit"]
        if limit is not None and used >= limit:
            return False, f"Seu limite diário foi atingido ({used}/{limit})."
        return True, ""

    def result_keyboard(self, user_id: int, chain: str, address: str, market: dict):
        rows = []
        if market.get("url"):
            rows.append([{"text": "📈 Abrir no DexScreener", "url": market["url"]}])
        rows.append(
            [
                {"text": "🔄 Atualizar", "callback_data": f"refresh|{chain}|{address}"},
                {"text": "⭐ Favoritar", "callback_data": f"favorite|{chain}|{address}"},
            ]
        )
        rows.append([{"text": "💎 Ver planos", "callback_data": "plans"}])
        return {"inline_keyboard": rows}

    def analyze(self, user_id: int, chain: str, address: str, force: bool = False):
        user = self.storage.get_user(user_id)
        allowed, reason = self.allowed(user, chain)
        if not allowed:
            return "⛔ <b>Acesso limitado</b>\n" + escape(reason), self.sales_keyboard()

        market = self.market.fetch(chain, address, force=force)
        text, score = report(market, user["plan"])
        self.storage.save_analysis(user_id, chain, address, score, market)
        self.last_results[user_id] = (chain, address, market)
        return text, self.result_keyboard(user_id, chain, address, market)

    def send_analysis(self, chat_id, user_id: int, chain: str, address: str, force: bool = False):
        address = address.strip()
        if not address:
            return self.telegram.send(chat_id, "❌ Envie um contrato válido.", MAIN_KEYBOARD)

        try:
            self.telegram.send(chat_id, "⏳ <b>Analisando mercado...</b>\nConsultando fontes seguras.")
            text, keyboard = self.analyze(user_id, chain, address, force=force)
            return self.telegram.send(chat_id, text, keyboard)
        except Exception:
            logger.exception("Falha na análise")
            return self.telegram.send(
                chat_id,
                "❌ <b>Análise temporariamente indisponível.</b>\n"
                "As fontes de mercado não responderam com conexão segura. "
                "O bot continua online; tente novamente em alguns instantes.",
                MAIN_KEYBOARD,
            )

    def history_text(self, user_id: int, page: int = 0) -> tuple[str, dict]:
        user = self.storage.get_user(user_id)
        allowed_total = PLANS[user["plan"]]["history"]
        page_size = settings.history_page_size
        total = min(self.storage.history_count(user_id), allowed_total)
        max_page = max(0, (total - 1) // page_size)
        page = max(0, min(page, max_page))
        rows = self.storage.history(user_id, page_size, page * page_size)

        if not rows:
            text = "🧾 <b>HISTÓRICO</b>\n\nNenhuma análise registrada."
        else:
            lines = ["🧾 <b>HISTÓRICO DE ANÁLISES</b>", ""]
            for row in rows:
                chain = CHAINS.get(row["chain"], {"emoji": "🌐", "label": row["chain"]})
                name = row["token_symbol"] or row["token_name"] or "Token"
                lines.append(
                    f"{chain['emoji']} <b>{escape(name)}</b> • {row['score']}/100\n"
                    f"<code>{escape(compact_address(row['address']))}</code>"
                )
            lines.append(f"\nPágina <b>{page + 1}/{max_page + 1}</b>")
            text = "\n\n".join(lines)

        nav = []
        if page > 0:
            nav.append({"text": "⬅️ Anterior", "callback_data": f"history|{page - 1}"})
        if page < max_page:
            nav.append({"text": "Próxima ➡️", "callback_data": f"history|{page + 1}"})
        keyboard = {"inline_keyboard": [nav] if nav else [[{"text": "⬅️ Menu", "callback_data": "menu"}]]}
        return text, keyboard

    def favorites_text(self, user_id: int) -> tuple[str, dict]:
        user = self.storage.get_user(user_id)
        plan = PLANS[user["plan"]]
        if plan["favorites"] <= 0:
            return (
                "⭐ <b>FAVORITOS</b>\n\nEste recurso está disponível nos planos VIP/Plus e Premium.",
                self.sales_keyboard(),
            )

        rows = self.storage.favorites(user_id, plan["favorites"])
        if not rows:
            return "⭐ <b>FAVORITOS</b>\n\nVocê ainda não adicionou tokens.", {
                "inline_keyboard": [[{"text": "⬅️ Menu", "callback_data": "menu"}]]
            }

        lines = ["⭐ <b>SEUS FAVORITOS</b>", ""]
        buttons = []
        for row in rows[:10]:
            chain = CHAINS.get(row["chain"], {"emoji": "🌐"})
            name = row["token_symbol"] or row["token_name"] or "Token"
            lines.append(f"{chain['emoji']} <b>{escape(name)}</b> — <code>{escape(compact_address(row['address']))}</code>")
            buttons.append(
                [
                    {
                        "text": f"🔄 {name}",
                        "callback_data": f"refresh|{row['chain']}|{row['address']}",
                    },
                    {
                        "text": "🗑️",
                        "callback_data": f"unfavorite|{row['chain']}|{row['address']}",
                    },
                ]
            )
        buttons.append([{"text": "⬅️ Menu", "callback_data": "menu"}])
        return "\n".join(lines), {"inline_keyboard": buttons}

    def preferences_text(self, user_id: int) -> tuple[str, dict]:
        prefs = self.storage.user_preferences(user_id)
        def mark(value: bool) -> str:
            return "🟢 Ativado" if value else "⚪ Desativado"
        profile = self.user_profiles.get(user_id)
        chain_names = ", ".join(profile["preferred_chains"]) if profile["preferred_chains"] else "Todas as redes"
        detail_labels = {"compact": "Compacto", "standard": "Equilibrado", "detailed": "Detalhado"}
        quiet_labels = {"off": "Desativado", "22-07": "22h às 07h", "00-07": "00h às 07h"}
        risk_labels = {"conservative": "Conservador", "moderate": "Moderado", "aggressive": "Agressivo"}
        frequency_labels = {"plan": "Padrão do plano", "reduced": "Reduzida", "priority": "Prioritária"}
        text = (
            f"{BRAND_DIVIDER}\n🎛️ <b>PHANTOM ALERT • PREFERÊNCIAS</b>\n{BRAND_DIVIDER}\n\n"
            f"📡 Sinais automáticos: <b>{mark(prefs['auto_signals'])}</b>\n"
            f"⭐ Alertas de favoritos: <b>{mark(prefs['favorite_alerts'])}</b>\n"
            f"🔔 Avisos de vencimento: <b>{mark(prefs['expiry_alerts'])}</b>\n"
            f"🧾 Mensagens compactas: <b>{mark(prefs['compact_messages'])}</b>\n\n"
            "🧭 <b>PERSONALIZAÇÃO PROFISSIONAL</b>\n"
            f"🌐 Redes preferidas: <b>{escape(chain_names)}</b>\n"
            f"📝 Nível de detalhe: <b>{detail_labels[profile['detail_mode']]}</b>\n"
            f"🌙 Horário silencioso: <b>{quiet_labels[profile['quiet_hours']]}</b>\n\n"
            "As preferências avançadas ficam no diretório persistente e sobrevivem às atualizações."
        )
        keyboard = {"inline_keyboard": [
            [{"text": "📡 Alternar sinais", "callback_data": "pref|auto_signals"}],
            [{"text": "⭐ Alternar favoritos", "callback_data": "pref|favorite_alerts"}],
            [{"text": "🔔 Alternar vencimento", "callback_data": "pref|expiry_alerts"}],
            [{"text": "🧾 Alternar compacto", "callback_data": "pref|compact_messages"}],
            [{"text": "🌐 Trocar redes", "callback_data": "profile|chains"}],
            [{"text": "📝 Nível de detalhe", "callback_data": "profile|detail"}],
            [{"text": "🌙 Horário silencioso", "callback_data": "profile|quiet"}],
            [{"text": "🛡️ Perfil de risco", "callback_data": "profile|risk"}],
            [{"text": "🔔 Frequência", "callback_data": "profile|frequency"}],
            [{"text": "🌍 Idioma", "callback_data": "profile|language"}],
            [{"text": "⬅️ Minha Central", "callback_data": "intelligence_center"}],
        ]}
        return text, keyboard

    @staticmethod
    def _format_runtime_time(raw: str | None) -> str:
        if not raw:
            return "ainda não executado"
        try:
            dt = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone().strftime("%H:%M:%S")
        except ValueError:
            return escape(str(raw))

    def intelligence_center_text(self, user_id: int) -> str:
        user = self.storage.get_user(user_id)
        return build_center_text(
            user=user,
            stats=self.storage.user_signal_stats(user_id),
            recent=self.storage.recent_signal_results(user_id, 6),
            renewals=self.storage.renewal_history(user_id, 5),
            profile=self.user_profiles.get(user_id),
            favorites=self.storage.favorite_count(user_id),
            analyses_today=self.storage.count_today(user_id),
        )

    def dashboard_text(self, user_id: int) -> str:
        user = self.storage.get_user(user_id)
        plan = PLANS[user["plan"]]
        group = plan_group(user.get("plan"))
        sig = self.storage.user_signal_stats(user_id)
        scan = self.storage.scanner_stats_today()
        recent = self.storage.recent_signal_results(user_id, settings.dashboard_recent_limit)
        uptime_seconds = max(0, int((datetime.now(timezone.utc) - self.started_at).total_seconds()))
        uptime = f"{uptime_seconds // 3600:02d}h {(uptime_seconds % 3600) // 60:02d}m"
        due_date, days_text, days = subscription_timing(user)
        recent_lines = []
        for row in recent:
            status = row.get("outcome") or ("ABERTO" if row.get("status") == "OPEN" else "FECHADO")
            pct = float(row.get("result_pct") or 0)
            icon = "🟢" if pct > 0 else "🔴" if pct < 0 else "⚪"
            recent_lines.append(f"{icon} {escape(str(row.get('symbol') or 'Token'))}: <b>{escape(str(status))}</b> {pct:+.1f}%")
        recent_text = "\n".join(recent_lines) or "• Nenhum sinal registrado"
        title = "CENTRAL ESSENCIAL" if group == "free" else "CENTRAL PLUS" if group == "plus" else "CENTRAL PREMIUM"
        badge = "🆓" if group == "free" else "💠" if group == "plus" else "👑"
        renewal = "Não aplicável" if group == "free" else ("Automática" if settings.asaas_auto_renew else "Manual")
        account_status = "🟢 Ativa" if group == "free" or days is None or days > 0 else "🔴 Expirada"
        upgrade = (
            "💠 <b>EVOLUA PARA PLUS</b>\nReceba contexto, estratégia, favoritos e acompanhamento." if group == "free" else
            "👑 <b>EVOLUA PARA PREMIUM</b>\nDesbloqueie radar de 1 minuto e inteligência analítica completa." if group == "plus" else
            "✨ <b>ACESSO COMPLETO</b>\nTodos os recursos Premium estão liberados."
        )
        return (
            f"{BRAND_DIVIDER}\n{badge} <b>PHANTOM ALERT • {title}</b>\n{BRAND_DIVIDER}\n\n"
            "👤 <b>ASSINATURA</b>\n"
            f"• Plano: <b>{plan['emoji']} {plan['label']}</b>\n"
            f"• Status: <b>{account_status}</b>\n"
            f"• Vencimento: <b>{due_date}</b>\n"
            f"• Dias restantes: <b>{days_text}</b>\n"
            f"• Renovação: <b>{renewal}</b>\n\n"
            "📡 <b>RADAR AUTOMÁTICO</b>\n"
            f"• Estado: <b>🟢 Online</b>\n"
            f"• Frequência: <b>{interval_label(user.get('plan'))}</b>\n"
            f"• Próximo ciclo: <b>em até {interval_label(user.get('plan'))}</b>\n"
            f"• Último ciclo: <b>{self._format_runtime_time(scan.get('last_cycle'))}</b>\n"
            f"• Bot online há: <b>{uptime}</b>\n"
            f"• Análises pessoais hoje: <b>{self.storage.count_today(user_id)}</b>\n"
            f"• Favoritos: <b>{self.storage.favorite_count(user_id)}/{plan['favorites']}</b>\n\n"
            "🔭 <b>ATIVIDADE GLOBAL DO RADAR HOJE</b>\n"
            f"• Ciclos executados: <b>{scan.get('cycles', 0)}</b>\n"
            f"• Ativos descobertos: <b>{scan.get('discovered', 0):,}</b>\n"
            f"• Ativos aprovados: <b>{scan.get('approved', 0):,}</b>\n"
            f"• Sinais entregues: <b>{scan.get('sent', 0):,}</b>\n"
            f"• Melhor score: <b>{scan.get('top_score', 0)}/100</b>\n\n"
            "📈 <b>DESEMPENHO OBSERVADO</b>\n"
            f"• Sinais totais: <b>{sig['total']}</b>\n"
            f"• Em acompanhamento: <b>{sig['open_count']}</b>\n"
            f"• Alvos registrados: <b>{sig['wins']}</b>\n"
            f"• Stops registrados: <b>{sig['losses']}</b>\n"
            f"• Taxa observada: <b>{sig['hit_rate']:.1f}%</b>\n"
            f"• Resultado médio fechado: <b>{sig['avg_result']:+.1f}%</b>\n\n"
            "🕘 <b>ATIVIDADE RECENTE</b>\n" + recent_text + "\n\n" + upgrade +
            "\n\n⚠️ <i>Métricas educacionais baseadas em preços observados; não representam retorno real.</i>"
        )

    def broadcast_maintenance(self, active: bool, reason: str, eta_minutes: int) -> dict[str, int]:
        if not self.project_leader:
            return {"sent": 0, "errors": 0}
        state = self.project_leader.set_maintenance(active, reason=reason, eta_minutes=eta_minutes)
        if active:
            text = self.project_leader.maintenance_message()
        else:
            text = (
                "✅ <b>SISTEMA DISPONÍVEL</b>\n\n"
                "A manutenção foi concluída. Seus dados e sua assinatura foram preservados."
            )
        sent = errors = 0
        for target in self.storage.all_user_ids():
            try:
                self.telegram.send(target, text)
                sent += 1
            except Exception:
                errors += 1
        return {"sent": sent, "errors": errors}

    def notify_admins(self, text: str) -> None:
        for admin_id in settings.admin_ids or set():
            try:
                self.telegram.send(admin_id, text)
            except Exception:
                logger.exception("Falha ao notificar administrador")

    def admin_text(self) -> str:
        stats = self.storage.stats()
        payment_stats = self.storage.payment_stats()
        ranking = self.storage.network_ranking(5)
        ranking_text = "\n".join(
            f"• {CHAINS.get(item['chain'], {'label': item['chain']})['label']}: {item['total']}"
            for item in ranking
        ) or "• Nenhuma análise"

        return (
            "🛠️ <b>PAINEL ADMINISTRATIVO</b>\n\n"
            f"👥 Usuários: <b>{stats['users']}</b>\n"
            f"🆓 Grátis: <b>{stats['free']}</b>\n"
            f"💠 VIP/Plus: <b>{stats['plus']}</b>\n"
            f"👑 Premium: <b>{stats['premium']}</b>\n"
            f"📊 Análises hoje: <b>{stats['today']}</b>\n"
            f"📚 Análises totais: <b>{stats['analyses']}</b>\n"
            f"⭐ Favoritos: <b>{stats['favorites']}</b>\n"
            f"💳 Cobranças pendentes: <b>{payment_stats['pending']}</b>\n"
            f"✅ Cobranças confirmadas: <b>{payment_stats['confirmed']}</b>\n\n"
            "🌐 <b>REDES MAIS USADAS</b>\n"
            f"{ranking_text}\n\n"
            "⚙️ <b>Comandos</b>\n"
            "<code>/admin_add USER_ID plus 30</code>\n"
            "<code>/admin_add USER_ID premium 30</code>\n"
            "<code>/admin_remove USER_ID</code>\n"
            "<code>/admin_block USER_ID</code>\n"
            "<code>/admin_unblock USER_ID</code>\n"
            "<code>/admin_sync</code>"
        )

    def handle_admin_command(self, user_id: int, text: str) -> str | None:
        if user_id not in settings.admin_ids:
            return None
        parts = text.split()
        command = parts[0].lower()

        try:
            if command == "/admin_add" and len(parts) >= 3:
                target = int(parts[1])
                plan = parts[2]
                days = int(parts[3]) if len(parts) >= 4 else 30
                self.storage.set_plan(target, plan, days)
                return f"✅ Plano <b>{escape(plan)}</b> ativado para <code>{target}</code> por {days} dias."

            if command == "/admin_remove" and len(parts) >= 2:
                target = int(parts[1])
                self.storage.set_plan(target, "free", 0)
                return f"✅ Usuário <code>{target}</code> voltou ao plano Grátis."

            if command == "/admin_sync":
                if not self.payments:
                    return "⚠️ Asaas não configurado."
                result = self.payments.sync_all(100)
                return f"✅ Conciliação: {result['checked']} verificados, {result['activated']} ativados, {result['errors']} erros."

            if command in {"/admin_block", "/admin_unblock"} and len(parts) >= 2:
                target = int(parts[1])
                blocked = command == "/admin_block"
                self.storage.set_blocked(target, blocked)
                return f"✅ Usuário <code>{target}</code> {'bloqueado' if blocked else 'desbloqueado'}."

            if command == "/leader":
                if not self.project_leader:
                    return "⚠️ Líder de Projeto desativado."
                state = self.project_leader.maintenance()
                pending = len(self.project_leader.list_proposals("PENDING"))
                approved = len(self.project_leader.list_proposals("APPROVED"))
                return (
                    "🤖 <b>LÍDER DE PROJETO</b>\n\n"
                    f"Manutenção: <b>{'ATIVA' if state.get('active') else 'inativa'}</b>\n"
                    f"Propostas pendentes: <b>{pending}</b>\n"
                    f"Propostas aprovadas: <b>{approved}</b>\n\n"
                    "Use <code>/leader_audit</code> para nova auditoria."
                )

            if command == "/admin_dashboard":
                data = admin_dashboard()
                scanner = data.get("scanner_cycles_today", 0)
                text = (
                    f"{BRAND_DIVIDER}\n🛡️ <b>PHANTOM ALERT • ADMIN CENTER</b>\n{BRAND_DIVIDER}\n\n"
                    f"🏷 Release: <b>{escape(str(data.get('release')))}</b> • LTS {escape(str(data.get('lts_base')))}\n"
                    f"🌍 Ambiente: <b>{escape(str(data.get('environment')))}</b>\n"
                    f"🗄 Banco: <b>{escape(str(data.get('database_integrity')))}</b>\n"
                    f"👥 Usuários: <b>{data.get('users', 0)}</b>\n"
                    f"💎 Assinantes ativos: <b>{data.get('active_subscribers', 0)}</b>\n"
                    f"💳 Pagamentos: <b>{data.get('payments', 0)}</b>\n"
                    f"🔄 Ciclos hoje: <b>{scanner}</b>\n"
                    f"📡 Sinais hoje: <b>{data.get('signals_sent_today', 0)}</b>\n"
                    f"🤖 Project Leader: <b>{'ATIVO' if data.get('project_leader_enabled') else 'INATIVO'}</b>\n\n"
                    "Use /leader_audit para gerar propostas técnicas controladas."
                )
                return self.telegram.send(chat_id, text)

            if command == "/leader_audit":
                if not self.project_leader:
                    return "⚠️ Líder de Projeto desativado."
                report = self.project_leader.audit()
                created = self.project_leader.proposals_from_audit(report)
                summary = report["summary"]
                lines = [
                    "🤖 <b>AUDITORIA CONCLUÍDA</b>",
                    f"Achados: <b>{summary['total']}</b>",
                    f"Críticos: <b>{summary['critical']}</b>",
                    f"Acionáveis: <b>{summary['actionable']}</b>",
                ]
                for proposal, code in created:
                    lines.extend([
                        "", f"🟡 <code>{proposal.proposal_id}</code>",
                        escape(proposal.title),
                        f"Código: <code>{code}</code>",
                        f"Aprovar: <code>/leader_approve {proposal.proposal_id} {code}</code>",
                    ])
                if not created:
                    lines.append("\n✅ Nenhuma nova correção segura pendente.")
                return "\n".join(lines)

            if command == "/leader_approve" and len(parts) >= 3:
                if not self.project_leader:
                    return "⚠️ Líder de Projeto desativado."
                proposal = self.project_leader.approve(parts[1], parts[2])
                return (f"✅ Proposta <code>{proposal.proposal_id}</code> aprovada.\n"
                        f"Aplicar: <code>/leader_apply {proposal.proposal_id}</code>")

            if command == "/leader_apply" and len(parts) >= 2:
                if not self.project_leader:
                    return "⚠️ Líder de Projeto desativado."
                proposal = self.project_leader.get_proposal(parts[1])
                self.broadcast_maintenance(True, proposal.title, settings.project_leader_maintenance_eta)
                applied = self.project_leader.apply(
                    proposal.proposal_id, eta_minutes=settings.project_leader_maintenance_eta
                )
                self.broadcast_maintenance(False, "Atualização concluída", 0)
                return (f"✅ Proposta <code>{applied.proposal_id}</code> aplicada.\n"
                        f"Resultado: {escape(applied.result)}")

            if command == "/maintenance_off":
                if not self.project_leader:
                    return "⚠️ Líder de Projeto desativado."
                self.project_leader.set_maintenance(False, reason="Encerrada pelo administrador")
                self.broadcast_maintenance(False, "Manutenção encerrada", 0)
                return "✅ Modo de manutenção desativado."
        except (ValueError, IndexError):
            return "❌ Parâmetros inválidos."
        except ProjectLeaderError as exc:
            return f"❌ Líder de Projeto: {escape(str(exc))}"
        except Exception as exc:
            logger.exception("Falha no comando administrativo")
            return f"❌ Falha administrativa: {escape(str(exc))}"

        return None

    def handle_message(self, message: dict):
        chat = message.get("chat") or {}
        sender = message.get("from") or {}
        user_id = int(sender.get("id") or chat.get("id"))
        chat_id = chat.get("id")
        text = (message.get("text") or "").strip()
        lower = text.lower()
        user = self.storage.upsert_user(user_id, sender.get("username", ""), sender.get("first_name", ""))

        if self.project_leader and user_id not in (settings.admin_ids or set()):
            maintenance_text = self.project_leader.maintenance_message()
            if maintenance_text:
                return self.telegram.send(chat_id, maintenance_text)

        if user_id in self.pending_payment:
            if lower == "/cancelar":
                self.pending_payment.pop(user_id, None)
                return self.telegram.send(chat_id, "✅ Cobrança cancelada antes da criação.", MAIN_KEYBOARD)
            pending = self.pending_payment[user_id]
            if not valid_document(text):
                return self.telegram.send(chat_id, "❌ CPF ou CNPJ inválido. Envie somente os números ou use /cancelar.", MAIN_KEYBOARD)
            self.pending_payment.pop(user_id, None)
            return self.create_payment_order(chat_id, user_id, pending["plan"], pending["name"], only_digits(text), pending["billing_type"])

        admin_response = self.handle_admin_command(user_id, text)
        if admin_response:
            return self.telegram.send(chat_id, admin_response, MAIN_KEYBOARD)

        if lower == "/daniel" or lower == "/ai" or lower.startswith("/daniel ") or lower.startswith("/ai "):
            try:
                from daniel_ai.config import DanielSettings
                cfg = DanielSettings.from_env()
                if cfg.admin_only and user_id not in (settings.admin_ids or set()):
                    return self.telegram.send(chat_id, "⛔ Daniel AI V0.1 está disponível somente para o administrador.", MAIN_KEYBOARD)
                from daniel_ai.engine import DanielAI
                if lower in {"/daniel", "/ai"}:
                    answer = DanielAI(cfg).help_text()
                else:
                    question = text.split(maxsplit=1)[1]
                    answer = DanielAI(cfg).ask(question, user_id=user_id, source="telegram")
                return self.telegram.send(chat_id, answer, MAIN_KEYBOARD)
            except Exception as exc:
                logger.exception("Falha Daniel AI")
                return self.telegram.send(chat_id, f"⚠️ Daniel AI indisponível: {escape(str(exc))}", MAIN_KEYBOARD)

        if lower == "/start":
            return self.telegram.send(chat_id, welcome_text(user, sender.get("first_name", "")), start_keyboard())

        if lower in {"💎 planos", "👑 conhecer premium", "/planos"}:
            return self.telegram.send(chat_id, self.plans_text(), self.sales_keyboard())

        if lower in {"👤 meu plano", "👤 minha assinatura", "/meuplano"}:
            return self.telegram.send(chat_id, self.plan_status_text(user), MAIN_KEYBOARD)

        if lower in {"/assinar", "assinar"}:
            return self.telegram.send(chat_id, self.plans_text(), self.sales_keyboard())

        if lower in {"/verificar_pagamento", "verificar pagamento"}:
            return self.verify_payment(chat_id, user_id)

        if lower in {"🚀 scanner", "/scanner", "📡 sinais automáticos"}:
            if plan_group(user.get("plan")) != "free":
                return self.telegram.send(
                    chat_id,
                    "📡 <b>SCANNER AUTOMÁTICO ATIVO</b>\n\n"
                    "Seu plano recebe oportunidades automaticamente em segundo plano. "
                    "Use o Painel para acompanhar frequência, histórico e sinais recentes.",
                    self.user_keyboard(user),
                )
            self.telegram.send(chat_id,"⏳ Analisando diversos ativos em várias redes...",self.user_keyboard(user))
            text_out,keyboard=self.scanner_text(user_id)
            return self.telegram.send(chat_id,text_out,keyboard)

        if lower in {"🎛️ preferências", "⚙️ preferências", "/preferencias"}:
            text_out, keyboard = build_preferences_screen(self, user_id)
            return self.telegram.send(chat_id, text_out, keyboard)

        if lower in {"🧠 minha central", "/central", "/minhaconta"}:
            from .central_v823 import build_central_v2
            text_out, keyboard = build_central_v2(self, user_id)
            return self.telegram.send(chat_id, text_out, keyboard)

        if lower in {"⚙️ painel", "/painel", "👑 central premium"}:
            rows=[[{"text":"👤 Minha assinatura","callback_data":"my_plan"}],
                  [{"text":"⭐ Favoritos","callback_data":"favorites"},{"text":"🧾 Histórico","callback_data":"history|0"}],
                  [{"text":"🎛️ Preferências","callback_data":"preferences"}],
                  [{"text":"📤 Exportar meus dados","callback_data":"export_user"}],
                  [{"text":"💎 Planos","callback_data":"plans"}],
                  [{"text":"🏠 Menu","callback_data":"menu"}]]
            return self.telegram.send(chat_id,self.dashboard_text(user_id),{"inline_keyboard":rows})

        if lower in {"🟢 status", "/status"}:
            return self.telegram.send(
                chat_id,
                f"🟢 <b>SERVIÇO ONLINE</b>\n"
                f"Plano: <b>{self.plan_name(user)}</b>\n"
                "Telegram: <b>conectado</b>\n"
                "Fontes: <b>DexScreener + GeckoTerminal</b>\n"
                f"Próximo ciclo do plano: <b>{interval_label(user.get('plan'))}</b>",
                self.user_keyboard(user),
            )

        if lower in {"🌐 redes", "/redes"}:
            return self.telegram.send(chat_id, self.networks_text(), MAIN_KEYBOARD)

        if lower in {"🧾 histórico", "/historico"}:
            text_out, keyboard = self.history_text(user_id, 0)
            return self.telegram.send(chat_id, text_out, keyboard)

        if lower in {"⭐ favoritos", "/favoritos"}:
            text_out, keyboard = self.favorites_text(user_id)
            return self.telegram.send(chat_id, text_out, keyboard)

        if lower == "/admin":
            if user_id not in settings.admin_ids:
                return self.telegram.send(chat_id, "⛔ Acesso restrito ao administrador.", MAIN_KEYBOARD)
            return self.telegram.send(chat_id, self.admin_text(), MAIN_KEYBOARD)

        if lower in {"🔍 analisar", "/analisar"}:
            self.pending[user_id] = None
            return self.telegram.send(
                chat_id,
                "🔍 <b>ANALISAR TOKEN</b>\n\n"
                "Toque em SOL, ETH ou BNB; ou cole diretamente o contrato para detecção automática.",
                MAIN_KEYBOARD,
            )

        quick = {
            "🟣 sol": "solana",
            "/sol": "solana",
            "🔷 eth": "ethereum",
            "/eth": "ethereum",
            "🟡 bnb": "bsc",
            "/bnb": "bsc",
        }
        for prefix, chain in quick.items():
            if lower == prefix:
                self.pending[user_id] = chain
                return self.telegram.send(
                    chat_id,
                    f"📥 Envie somente o contrato da rede <b>{CHAINS[chain]['label']}</b>.",
                    MAIN_KEYBOARD,
                )
            if lower.startswith(prefix + " "):
                return self.send_analysis(chat_id, user_id, chain, text.split(maxsplit=1)[1])

        if lower.startswith("/analisar "):
            parts = text.split()
            if len(parts) == 2:
                address = parts[1]
                chain = detect_chain(address)
            else:
                chain = normalize_chain(parts[1])
                address = parts[2] if len(parts) > 2 else ""
            if not chain:
                return self.telegram.send(chat_id, "❌ Rede não reconhecida.", MAIN_KEYBOARD)
            return self.send_analysis(chat_id, user_id, chain, address)

        if user_id in self.pending and self.pending[user_id]:
            chain = self.pending.pop(user_id)
            return self.send_analysis(chat_id, user_id, chain, text)

        detected = detect_chain(text)
        if detected:
            return self.send_analysis(chat_id, user_id, detected, text)

        return self.telegram.send(chat_id, "Comando desconhecido. Use /start para abrir o menu.", MAIN_KEYBOARD)

    def handle_callback(self, callback: dict):
        """Delegate inline UI events to the rebuilt callback router."""
        return self.callback_router.handle(callback)


    def automatic_payment_check(self) -> dict:
        """Consulta somente cobranças pendentes e ativa planos sem webhook."""
        if not self.payments or not settings.payment_auto_check:
            return {"checked": 0, "activated": 0, "errors": 0, "activations": []}
        result = self.payments.sync_all(settings.payment_check_batch)
        for activation in result.get("activations", []):
            user_id = int(activation["user_id"])
            user = self.storage.get_user(user_id)
            try:
                self.telegram.send(
                    user_id,
                    activated_text(user),
                    self.user_keyboard(user),
                )
            except Exception as exc:
                logger.warning("Plano ativado, mas não foi possível notificar %s: %s", user_id, exc)
        return result

    def _automatic_signal_text(self, item: dict, plan: str) -> str:
        group = plan_group(plan)
        base_score = int(item.get("score") or 0)
        profile = opportunity_profile(item)
        score = int(profile["opportunity_score"])
        stars, classification = self._score_classification(score)
        symbol = escape(str(item.get("symbol") or item.get("name") or "Token"))
        chain = escape(str(item.get("chain") or "?"))
        address = escape(str(item.get("address") or ""))
        price = float(item.get("price") or 0)
        t1 = price * (1 + settings.signal_target1_pct / 100) if price else 0
        t2 = price * (1 + settings.signal_target2_pct / 100) if price else 0
        stop = price * (1 - settings.signal_stop_pct / 100) if price else 0
        stage_emoji, stage = project_stage(item)
        reason_limit = 2 if group == "free" else 3 if group == "plus" else 5
        reasons = signal_reasons(item, reason_limit)
        reasons_text = "\n".join(f"✓ {escape(reason)}" for reason in reasons)
        liquidity = self._compact_usd(float(item.get("liquidity") or 0))
        volume = self._compact_usd(float(item.get("volume24h") or 0))
        change24h = float(item.get("change24h") or 0)

        if group == "free":
            return (
                f"{BRAND_DIVIDER}\n🟢 <b>PHANTOM ALERT • SINAL ESSENCIAL</b>\n{BRAND_DIVIDER}\n\n"
                f"🪙 <b>ATIVO</b>\n• {symbol} • {chain}\n\n"
                f"📊 <b>MERCADO</b>\n• {stars} Score: <b>{score}/100</b>\n"
                f"• Classificação: <b>{classification}</b>\n• Liquidez: <b>{liquidity}</b>\n• Volume 24h: <b>{volume}</b>\n\n"
                f"🧠 <b>POR QUE APARECEU?</b>\n{reasons_text}\n\n"
                f"📄 <b>CONTRATO</b>\n<code>{address}</code>\n\n"
                "⚠️ <i>Métrica educacional. Verifique o contrato e gerencie seu risco.</i>"
            )

        market_block = (
            f"{stage_emoji} Estágio: <b>{escape(stage)}</b>\n"
            f"🧭 Origem provável: <b>{escape(str(profile['origin']))}</b>\n"
            f"{stars} Score: <b>{score}/100</b> <i>(base {base_score})</i>\n"
            f"🏅 Classificação: <b>{classification}</b>\n"
            f"🎯 Confiança técnica: <b>{escape(str(profile['confidence']).upper())}</b>\n"
            f"💧 Liquidez: <b>{liquidity}</b>\n"
            f"📈 Volume 24h: <b>{volume}</b>\n"
            f"📊 Variação 24h: <b>{change24h:+.2f}%</b>"
        )
        strategy_block = (
            (f"• Entrada observada: <code>{price:.12g}</code>\n" if price else "")
            + (f"• Alvo 1: <code>{t1:.12g}</code> (+{settings.signal_target1_pct:.0f}%)\n" if t1 else "")
            + (f"• Alvo 2: <code>{t2:.12g}</code> (+{settings.signal_target2_pct:.0f}%)\n" if t2 else "")
            + (f"• Stop sugerido: <code>{stop:.12g}</code> (-{settings.signal_stop_pct:.0f}%)" if stop else "")
        )
        risk_block = (
            "• Ativos recentes podem perder liquidez rapidamente.\n"
            "• Confirme contrato, distribuição e condições da DEX.\n"
            "• Use tamanho de posição compatível com seu risco."
        )

        if group == "plus":
            return (
                f"{BRAND_DIVIDER}\n🔵 <b>PHANTOM ALERT • SINAL PLUS</b>\n{BRAND_DIVIDER}\n\n"
                f"🪙 <b>ATIVO</b>\n• {symbol} • {chain}\n\n"
                f"📊 <b>MERCADO</b>\n{market_block}\n\n"
                f"🎯 <b>ESTRATÉGIA OBSERVADA</b>\n{strategy_block}\n\n"
                f"🧠 <b>POR QUE O SCANNER SELECIONOU</b>\n{reasons_text}\n\n"
                f"⚠️ <b>RISCOS</b>\n{risk_block}\n\n"
                f"📄 <b>CONTRATO</b>\n<code>{address}</code>\n\n"
                "⚠️ <i>Sinal educacional; não constitui recomendação nem promessa de lucro.</i>"
            )

        buys1h = int(item.get("buys1h") or 0)
        sells1h = int(item.get("sells1h") or 0)
        total1h = buys1h + sells1h
        pressure = buys1h / total1h * 100 if total1h else 0
        advanced = (
            f"• Variação 1h: <b>{float(item.get('change1h') or 0):+.2f}%</b>\n"
            f"• Variação 6h: <b>{float(item.get('change6h') or 0):+.2f}%</b>\n"
            f"• Compras/Vendas 1h: <b>{buys1h}/{sells1h}</b>\n"
            f"• Pressão compradora: <b>{pressure:.1f}%</b>\n"
            f"• Giro Volume/Liquidez: <b>{float(profile['turnover']):.2f}x</b>\n"
            f"• DEX: <b>{escape(str(item.get('dex') or 'indisponível'))}</b>\n"
            f"• Market cap: <b>{self._compact_usd(float(item.get('marketcap') or 0))}</b>\n"
            f"• FDV: <b>{self._compact_usd(float(item.get('fdv') or 0))}</b>"
        )
        return (
            f"{BRAND_DIVIDER}\n👑 <b>PHANTOM ALERT • PREMIUM SIGNAL</b>\n{BRAND_DIVIDER}\n\n"
            f"🪙 <b>ATIVO</b>\n• {symbol} • {chain}\n\n"
            f"📊 <b>MERCADO</b>\n{market_block}\n\n"
            f"🎯 <b>ESTRATÉGIA OBSERVADA</b>\n{strategy_block}\n\n"
            f"👑 <b>INTELIGÊNCIA PREMIUM</b>\n{advanced}\n\n"
            f"🧠 <b>TESE DO SINAL</b>\n{reasons_text}\n\n"
            f"⚠️ <b>RISCOS</b>\n{risk_block}\n\n"
            f"📄 <b>CONTRATO</b>\n<code>{address}</code>\n\n"
            "⚠️ <i>Análise algorítmica educacional. Ativos novos têm risco elevado.</i>"
        )

    def automatic_signal_cycle(
        self,
        *,
        plan_group: str | None = None,
        test_user_id: int | None = None,
        results: list[dict] | None = None,
    ) -> dict[str, int]:
        """Entrega oportunidades automaticamente.

        Grátis, Plus e Premium usam a mesma seleção e diferem somente na frequência:
        15, 5 e 1 minuto, respectivamente. O cooldown continua evitando repetição.
        """
        summary = {
            "users": 0,
            "paid_users": 0,
            "sent": 0,
            "candidates": 0,
            "approved": 0,
            "eligible": 0,
            "duplicates": 0,
            "missing_address": 0,
            "errors": 0,
            "top_score": 0,
        }
        if not settings.auto_signals_enabled and test_user_id is None:
            return summary

        self.storage.prune_alert_deliveries(settings.signal_alert_cooldown_hours)
        if results is None:
            results = self.scanner.scan(force=True)
        summary["candidates"] = int(self.scanner.last_stats.get("discovered") or len(results))
        summary["approved"] = len(results)
        summary["top_score"] = max((int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or 0) for item in results), default=0)

        if test_user_id is not None:
            recipients = [self.storage.get_user(int(test_user_id))]
        else:
            recipients = self.storage.signal_users(plan_group or "free")
        summary["paid_users"] = sum(1 for user in recipients if str(user.get("plan") or "free") != "free")

        for user in recipients:
            if test_user_id is None and not self.storage.user_preferences(int(user["user_id"]))["auto_signals"]:
                continue
            profile = self.user_profiles.get(int(user["user_id"]))
            if test_user_id is None and self.user_profiles.is_quiet(profile):
                continue
            plan = str(user.get("plan") or "free")
            if test_user_id is not None and plan == "free":
                plan = "plus"

            preferred = set(profile.get("preferred_chains") or [])
            available = [item for item in results if not preferred or str(item.get("chain") or "") in preferred]
            if test_user_id is not None:
                selected = available[:1]
            else:
                selected = [
                    item for item in available
                    if int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or 0) >= settings.auto_signal_min_score
                ][:settings.auto_signal_limit]
            summary["eligible"] += len(selected)
            summary["users"] += 1

            for item in selected:
                chain = str(item.get("chain") or "")
                address = str(item.get("address") or "")
                if not chain or not address:
                    summary["missing_address"] += 1
                    continue
                if test_user_id is None and not self.storage.mark_alert_delivery(
                    int(user["user_id"]),
                    chain,
                    address,
                    "entry",
                    int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or 0),
                ):
                    summary["duplicates"] += 1
                    continue
                try:
                    keyboard = {
                        "inline_keyboard": [
                            [
                                {"text": "🔎 Analisar agora", "callback_data": f"refresh|{chain}|{address}"},
                                {"text": "⭐ Favoritar", "callback_data": f"favorite|{chain}|{address}"},
                            ],
                            [{"text": "📋 Copiar contrato", "callback_data": f"copy|{chain}|{address}"}],
                        ]
                    }
                    text = self._automatic_signal_text(item, plan)
                    if test_user_id is not None:
                        text = "🧪 <b>TESTE DO CANAL AUTOMÁTICO</b>\n\n" + text
                    self.telegram.send(int(user["user_id"]), text, keyboard)
                    price = float(item.get("price") or 0)
                    if test_user_id is None and settings.signal_monitor_enabled and price > 0:
                        self.storage.create_signal_position(
                            user_id=int(user["user_id"]),
                            chain=chain,
                            address=address,
                            symbol=str(item.get("symbol") or item.get("name") or "Token"),
                            entry_price=price,
                            target1_price=price * (1 + settings.signal_target1_pct / 100),
                            target2_price=price * (1 + settings.signal_target2_pct / 100),
                            stop_price=price * (1 - settings.signal_stop_pct / 100),
                        )
                    summary["sent"] += 1
                except Exception as exc:
                    summary["errors"] += 1
                    logger.warning(
                        "Falha ao enviar sinal automático para %s: %s",
                        user["user_id"],
                        exc,
                    )
        return summary

    def monitor_signal_positions(self) -> dict[str, int]:
        summary = {"checked": 0, "alerts": 0, "errors": 0}
        if not settings.signal_monitor_enabled:
            return summary
        for position in self.storage.open_signal_positions(limit=200):
            try:
                market = self.market.fetch(position["chain"], position["address"], force=True)
                price = float(market.get("price") or 0)
                if price <= 0:
                    continue
                summary["checked"] += 1
                entry = float(position["entry_price"] or 0)
                change = ((price / entry) - 1) * 100 if entry else 0
                text = None; updates = {}
                peak = max(float(position.get("peak_price") or 0), price)
                if not position["stop_sent"] and price <= float(position["stop_price"]):
                    text = (f"{BRAND_DIVIDER}\n🛑 <b>PHANTOM ALERT • ALERTA DE SAÍDA</b>\n{BRAND_DIVIDER}\n\n"
                            f"🪙 Ativo: <b>{escape(position['symbol'])}</b>\n"
                            f"🔻 Evento: <b>stop sugerido atingido</b>\n"
                            f"📉 Variação desde o sinal: <b>{change:+.1f}%</b>\n\n"
                            "⚠️ <i>Registro educacional do acompanhamento automático.</i>")
                    updates = {"stop_sent": True, "status": "CLOSED", "last_price": price, "peak_price": peak, "result_pct": change, "outcome": "STOP"}
                elif not position["target2_sent"] and price >= float(position["target2_price"]):
                    text = (f"{BRAND_DIVIDER}\n🏆 <b>PHANTOM ALERT • ALVO 2</b>\n{BRAND_DIVIDER}\n\n"
                            f"🪙 Ativo: <b>{escape(position['symbol'])}</b>\n"
                            f"📈 Variação desde o sinal: <b>{change:+.1f}%</b>\n\n"
                            "🛡️ <i>Considere proteger o resultado conforme sua estratégia.</i>")
                    updates = {"target1_sent": True, "target2_sent": True, "status": "CLOSED", "last_price": price, "peak_price": peak, "result_pct": change, "outcome": "TARGET2"}
                elif not position["target1_sent"] and price >= float(position["target1_price"]):
                    text = (f"{BRAND_DIVIDER}\n🎯 <b>PHANTOM ALERT • ALVO 1</b>\n{BRAND_DIVIDER}\n\n"
                            f"🪙 Ativo: <b>{escape(position['symbol'])}</b>\n"
                            f"📈 Variação desde o sinal: <b>{change:+.1f}%</b>\n\n"
                            "🛡️ <i>Considere revisar o risco e proteger a entrada.</i>")
                    updates = {"target1_sent": True, "last_price": price, "peak_price": peak, "result_pct": change, "outcome": "TARGET1"}
                if not text:
                    self.storage.update_signal_position(int(position["id"]), last_price=price, peak_price=peak, result_pct=change)
                if text:
                    self.telegram.send(int(position["user_id"]), text, MAIN_KEYBOARD)
                    self.storage.update_signal_position(int(position["id"]), **updates)
                    summary["alerts"] += 1
            except Exception as exc:
                summary["errors"] += 1
                logger.debug("Falha no monitoramento da posição %s: %s", position.get("id"), exc)
        return summary


    def monitor_favorites(self) -> dict[str, int]:
        summary = {"checked": 0, "alerts": 0, "errors": 0}
        if not settings.favorite_monitor_enabled:
            return summary
        for favorite in self.storage.paid_favorites(limit=300):
            if not self.storage.user_preferences(int(favorite["user_id"]))["favorite_alerts"]:
                continue
            try:
                market = self.market.fetch(favorite["chain"], favorite["address"], force=True)
                price = float(market.get("price") or 0)
                base = float(favorite.get("initial_price") or favorite.get("last_price") or 0)
                if price <= 0:
                    continue
                if base <= 0:
                    base = price
                change = ((price / base) - 1) * 100 if base else 0
                self.storage.update_favorite_market(int(favorite["id"]), price, change)
                summary["checked"] += 1
                alert_type = None
                if change >= settings.favorite_alert_up_pct:
                    alert_type = "favorite_up"
                elif change <= -settings.favorite_alert_down_pct:
                    alert_type = "favorite_down"
                if alert_type and self.storage.mark_alert_delivery(
                    int(favorite["user_id"]), favorite["chain"], favorite["address"], alert_type, int(abs(change))
                ):
                    icon = "📈" if change > 0 else "📉"
                    self.telegram.send(
                        int(favorite["user_id"]),
                        f"{icon} <b>ALERTA DE FAVORITO</b>\n\n"
                        f"{escape(str(favorite.get('token_symbol') or favorite.get('token_name') or 'Token'))}: <b>{change:+.1f}%</b> desde que foi favoritado.\n"
                        f"Preço atual: <code>{price:.12g}</code>",
                        MAIN_KEYBOARD,
                    )
                    summary["alerts"] += 1
            except Exception as exc:
                summary["errors"] += 1
                logger.debug("Falha no favorito %s: %s", favorite.get("id"), exc)
        return summary

    def subscription_reminder_cycle(self) -> dict[str, int]:
        summary = {"due": 0, "sent": 0, "errors": 0}
        for user in self.storage.expiring_users():
            if not self.storage.user_preferences(int(user["user_id"]))["expiry_alerts"]:
                continue
            summary["due"] += 1
            try:
                days = int(user.get("days_left", 0))
                plan = PLANS[user["plan"]]
                due_date, days_text, _ = subscription_timing(user)
                if days == 0:
                    headline = "⌛ <b>SUA ASSINATURA VENCE HOJE</b>"
                else:
                    headline = "🔔 <b>LEMBRETE DE RENOVAÇÃO</b>"
                text = (
                    f"{headline}\n{BRAND_DIVIDER}\n\n"
                    f"{plan['emoji']} Plano: <b>{plan['label']}</b>\n"
                    f"📅 Vencimento: <b>{due_date}</b>\n"
                    f"⏳ Restante: <b>{days_text}</b>\n\n"
                    "Renove para manter o scanner automático, o histórico e os recursos do seu plano.\n\n"
                    "⚠️ <i>Esta mensagem informa acesso e validade; não representa promessa de resultado.</i>"
                )
                keyboard = {"inline_keyboard": [
                    [{"text": "💎 Renovar plano", "callback_data": "plans"}],
                    [{"text": "👤 Minha assinatura", "callback_data": "my_plan"}],
                ]}
                self.telegram.send(int(user["user_id"]), text, keyboard)
                self.storage.mark_subscription_reminder(int(user["user_id"]), str(user["expires_at"]), days)
                summary["sent"] += 1
            except Exception as exc:
                summary["errors"] += 1
                logger.warning("Falha ao enviar lembrete de assinatura para %s: %s", user.get("user_id"), exc)
        return summary

    def run(self):
        if not settings.telegram_token or not settings.telegram_chat_id:
            raise RuntimeError("Configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no arquivo .env")

        try:
            me = self.telegram.get_me()
        except Exception as exc:
            message = str(exc)
            if "HTTP 401" in message:
                raise RuntimeError(
                    "Token do Telegram recusado (HTTP 401). Execute 'python main.py setup' "
                    "e informe o token real fornecido pelo BotFather."
                ) from None
            raise RuntimeError(f"Falha ao autenticar no Telegram: {message}") from None
        print(f"✅ Telegram conectado como @{me.get('username', 'bot')}", flush=True)
        self.telegram.prepare()
        print("✅ BOT ONLINE — Ctrl+C para parar", flush=True)
        free_count = len(self.storage.signal_users("free"))
        plus_count = len(self.storage.signal_users("plus"))
        premium_count = len(self.storage.signal_users("premium"))
        print(
            "✅ Scanner automático por plano | "
            f"Grátis={free_count} (15 min) | Plus={plus_count} (5 min) | "
            f"Premium={premium_count} (1 min) | score ≥ {settings.auto_signal_min_score}",
            flush=True,
        )

        offset = None
        now = time.monotonic()
        next_payment_check = now + 3
        # Primeiro ciclo ocorre após 5 segundos para validar os três grupos;
        # depois cada grupo segue sua própria frequência.
        next_auto_scan_free = now + 5
        next_auto_scan_plus = now + 5
        next_auto_scan_premium = now + 5
        next_signal_monitor = now + 20
        next_favorite_monitor = now + 30
        next_expiry_check = now + 10
        next_subscription_reminder = now + 15
        next_leader_audit = now + 60
        while True:
            try:
                for update in self.telegram.updates(offset):
                    offset = update["update_id"] + 1
                    if update.get("message"):
                        self.handle_message(update["message"])
                    elif update.get("callback_query"):
                        self.handle_callback(update["callback_query"])

                now = time.monotonic()
                if now >= next_expiry_check:
                    expired = self.storage.expire_plans()
                    if expired:
                        print(f"⌛ {expired} assinatura(s) expirada(s) voltaram ao plano grátis", flush=True)
                    next_expiry_check = now + 300
                if now >= next_subscription_reminder:
                    reminder = self.subscription_reminder_cycle()
                    if reminder.get("sent"):
                        print(f"🔔 {reminder['sent']} lembrete(s) de assinatura enviado(s)", flush=True)
                    next_subscription_reminder = now + 21600
                if settings.payment_auto_check and now >= next_payment_check:
                    result = self.automatic_payment_check()
                    if result.get("activated"):
                        print(f"✅ {result['activated']} pagamento(s) ativado(s) automaticamente", flush=True)
                    next_payment_check = now + settings.payment_check_interval
                if settings.auto_signals_enabled:
                    due_groups = []
                    if now >= next_auto_scan_premium:
                        due_groups.append(("premium", settings.auto_scan_interval_premium))
                    if now >= next_auto_scan_plus:
                        due_groups.append(("plus", settings.auto_scan_interval_plus))
                    if now >= next_auto_scan_free:
                        due_groups.append(("free", settings.auto_scan_interval_free))

                    # v8.3.1: scanner cooperativo single-runtime. Cada poll executa
                    # apenas uma etapa e não cria outro interpretador Python.
                    completion = self.scanner_async.poll()
                    if completion is not None:
                        scan_results = completion.results
                        # Entrega de ciclos solicitados manualmente sem bloquear o callback.
                        manual_users = list(self._pending_manual_scan_users)
                        self._pending_manual_scan_users.clear()
                        for manual_user_id in manual_users:
                            self.scanner_sessions[int(manual_user_id)] = [dict(x) for x in scan_results]
                            try:
                                manual_text, manual_keyboard = self.scanner_text(int(manual_user_id))
                                self.telegram.send(int(manual_user_id), manual_text, manual_keyboard)
                            except Exception as exc:
                                logger.warning("Falha ao entregar scanner manual para %s: %s", manual_user_id, exc)

                        if self._pending_auto_scan_groups:
                            pending_groups = list(self._pending_auto_scan_groups)
                            self._pending_auto_scan_groups.clear()
                            completed_at = time.monotonic()
                            for group, interval in pending_groups:
                                result = self.automatic_signal_cycle(plan_group=group, results=scan_results)
                                self.storage.record_scanner_cycle(group, result)
                                print(
                                    f"🚀 Scanner {group}: "
                                    f"descobertos={result['candidates']} aprovados={result['approved']} "
                                    f"top_score={result['top_score']} usuários={result['users']} "
                                    f"elegíveis={result['eligible']} enviados={result['sent']} "
                                    f"repetidos={result['duplicates']} erros={result['errors']} "
                                    f"próximo={interval // 60}min",
                                    flush=True,
                                )
                                if group == "premium":
                                    next_auto_scan_premium = completed_at + interval
                                elif group == "plus":
                                    next_auto_scan_plus = completed_at + interval
                                else:
                                    next_auto_scan_free = completed_at + interval

                    if due_groups and not self._pending_auto_scan_groups and not self.scanner_async.active:
                        if self.scanner_async.start(force=True):
                            self._pending_auto_scan_groups = list(due_groups)
                        else:
                            # Falha ao iniciar worker: agenda novo ciclo sem travar a UI.
                            retry_at = time.monotonic() + 15
                            for group, _interval in due_groups:
                                if group == "premium":
                                    next_auto_scan_premium = retry_at
                                elif group == "plus":
                                    next_auto_scan_plus = retry_at
                                else:
                                    next_auto_scan_free = retry_at
                if settings.signal_monitor_enabled and now >= next_signal_monitor:
                    result = self.monitor_signal_positions()
                    if result.get("alerts"):
                        print(f"📈 Monitor de sinais: {result['alerts']} alerta(s)", flush=True)
                    next_signal_monitor = now + settings.signal_monitor_interval
                if settings.favorite_monitor_enabled and now >= next_favorite_monitor:
                    result = self.monitor_favorites()
                    if result.get("alerts"):
                        print(f"⭐ Monitor de favoritos: {result['alerts']} alerta(s)", flush=True)
                    next_favorite_monitor = now + settings.favorite_monitor_interval
                if (self.project_leader and settings.project_leader_auto_audit
                        and now >= next_leader_audit):
                    report = self.project_leader.audit()
                    created = self.project_leader.proposals_from_audit(report)
                    if created:
                        lines = ["🤖 <b>NOVAS PROPOSTAS TÉCNICAS</b>"]
                        for proposal, code in created:
                            lines.extend([
                                "", f"🟡 <code>{proposal.proposal_id}</code>",
                                escape(proposal.title),
                                f"Código: <code>{code}</code>",
                                f"<code>/leader_approve {proposal.proposal_id} {code}</code>",
                            ])
                        self.notify_admins("\n".join(lines))
                    next_leader_audit = now + settings.project_leader_audit_interval
            except KeyboardInterrupt:
                print("Bot finalizado.", flush=True)
                return
            except (HTTPTransientError,) as exc:
                # Falha transitória: reconecta silenciosamente, sem despejar traceback.
                logger.warning("Conexão temporariamente indisponível no polling: %s", exc)
                print("⚠️ Internet/Telegram oscilou. Reconectando...", flush=True)
                time.sleep(max(2.0, settings.http_backoff))
            except Exception as exc:
                logger.exception("Erro inesperado no polling")
                print(f"⚠️ Reconectando após {type(exc).__name__}...", flush=True)
                time.sleep(5)
