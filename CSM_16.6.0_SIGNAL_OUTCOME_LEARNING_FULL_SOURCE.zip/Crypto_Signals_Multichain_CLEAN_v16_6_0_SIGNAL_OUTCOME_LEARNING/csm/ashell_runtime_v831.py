from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


def is_ashell_runtime() -> bool:
    """Detecta a-Shell/iOS sem depender de uma única variável de ambiente."""
    parts = [
        sys.platform,
        sys.executable or "",
        str(Path(sys.executable).resolve()) if sys.executable else "",
        os.getcwd(),
        os.getenv("HOME", ""),
        os.getenv("APPDIR", ""),
    ]
    text = " ".join(parts).lower()
    markers = (
        "a-shell",
        "ashell",
        "/private/var/mobile/containers/",
        "/var/mobile/containers/",
        "/bundle/application/",
    )
    return sys.platform in {"ios"} or any(marker in text for marker in markers)


def curl_binary() -> str | None:
    return shutil.which("curl")


def runtime_capabilities() -> dict[str, object]:
    return {
        "ashell": is_ashell_runtime(),
        "python_pid": os.getpid(),
        "python_executable": sys.executable,
        "curl": curl_binary(),
        "single_python_runtime": True,
    }
