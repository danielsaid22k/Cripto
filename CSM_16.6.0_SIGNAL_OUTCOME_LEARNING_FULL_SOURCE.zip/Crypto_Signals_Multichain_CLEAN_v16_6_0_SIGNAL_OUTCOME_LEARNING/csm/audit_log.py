from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


@dataclass(frozen=True)
class AuditEvent:
    event: str
    category: str
    severity: str
    details: dict[str, Any]
    created_at: str


def _path() -> Path:
    target = settings.data_dir / "audit" / "events.jsonl"
    target.parent.mkdir(parents=True, exist_ok=True)
    return target


def record_event(event: str, *, category: str = "system", severity: str = "info", details: dict[str, Any] | None = None) -> AuditEvent:
    item = AuditEvent(
        event=event.strip() or "unknown",
        category=category.strip() or "system",
        severity=severity.strip().lower() or "info",
        details=details or {},
        created_at=datetime.now(timezone.utc).isoformat(),
    )
    with _path().open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(asdict(item), ensure_ascii=False, default=str) + "\n")
    return item


def recent_events(limit: int = 100) -> list[dict[str, Any]]:
    target = _path()
    if not target.exists():
        return []
    lines = target.read_text(encoding="utf-8", errors="replace").splitlines()[-max(1, limit):]
    result: list[dict[str, Any]] = []
    for line in reversed(lines):
        try:
            value = json.loads(line)
            if isinstance(value, dict):
                result.append(value)
        except json.JSONDecodeError:
            continue
    return result
