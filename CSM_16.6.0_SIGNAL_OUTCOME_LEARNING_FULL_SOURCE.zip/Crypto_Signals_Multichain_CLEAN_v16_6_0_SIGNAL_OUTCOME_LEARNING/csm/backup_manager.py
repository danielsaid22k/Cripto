from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Iterable

from .config import settings
from .persistence import inspect_database
from .security import sign_file, verify_file

EXCLUDED_DIRS = {"__pycache__", ".pytest_cache", ".git", "logs", "backups"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp"}
LATEST_NAME = "ultimo_backup.zip"
DEFAULT_RETENTION = 10


def _product_version() -> str:
    from csm import __product_version__
    return __product_version__.split("-")[0]


def _safe_name() -> str:
    return datetime.now().strftime(f"CryptoSignals_v{_product_version()}_backup_%Y%m%d_%H%M%S.zip")


def _default_backup_dir() -> Path:
    # Backups are persistent state, not release artifacts. Keeping them outside
    # the version folder prevents upgrades/reinstalls from orphaning them.
    directory = settings.data_dir / "backups"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _iter_project_files(include_secrets: bool):
    root = settings.base_dir
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        if relative.name == ".env" and not include_secrets:
            continue
        if relative.name.endswith(".zip"):
            continue
        yield path, Path("project") / relative


def _write_latest_alias(output: Path) -> Path:
    latest = output.parent / LATEST_NAME
    temp = latest.with_suffix(".tmp")
    shutil.copy2(output, temp)
    os.replace(temp, latest)
    try:
        os.chmod(latest, 0o600)
    except OSError:
        pass
    return latest



def backup_retention() -> int:
    """Quantidade de backups históricos mantidos. Mínimo 1, padrão 10."""
    raw = os.getenv("BACKUP_RETENTION", str(DEFAULT_RETENTION)).strip()
    try:
        return max(1, min(100, int(raw)))
    except ValueError:
        return DEFAULT_RETENTION


def prune_backups(directory: str | Path | None = None, *, keep: int | None = None) -> list[Path]:
    """Remove históricos excedentes sem apagar ``ultimo_backup.zip``."""
    root = Path(directory).expanduser() if directory else _default_backup_dir()
    limit = backup_retention() if keep is None else max(1, int(keep))
    items = []
    for item in root.glob("CryptoSignals_*_backup_*.zip"):
        try:
            if item.is_file():
                validate_backup(item)
                items.append(item)
        except (OSError, zipfile.BadZipFile, RuntimeError, ValueError):
            continue
    items.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    removed = []
    for old in items[limit:]:
        old.unlink(missing_ok=True)
        removed.append(old)
    return removed


def backup_inventory() -> list[dict]:
    """Lista backups válidos com metadados úteis para escolha e auditoria."""
    inventory = []
    for path in discover_backups():
        try:
            manifest = validate_backup(path)
            stat = path.stat()
            inventory.append({
                "path": path,
                "created_at": manifest.get("created_at", "desconhecido"),
                "version": manifest.get("version", "desconhecida"),
                "includes_secrets": bool(manifest.get("includes_secrets")),
                "database_included": bool(manifest.get("database_included")),
                "size": stat.st_size,
            })
        except Exception:
            continue
    return inventory


def choose_backup_interactive() -> Path | None:
    """Permite escolher um backup válido pelo número no terminal."""
    items = backup_inventory()
    if not items:
        return None
    if len(items) == 1 or not os.isatty(0):
        return items[0]["path"]
    print("Backups disponíveis:", flush=True)
    for index, item in enumerate(items, 1):
        secret = "com segredos" if item["includes_secrets"] else "sem segredos"
        database = "com banco" if item["database_included"] else "sem banco"
        print(f"{index} - {item['path'].name} | v{item['version']} | {secret} | {database}", flush=True)
    while True:
        value = input("Escolha o número do backup [1]: ").strip() or "1"
        try:
            selected = int(value)
            if 1 <= selected <= len(items):
                return items[selected - 1]["path"]
        except ValueError:
            pass
        print("Opção inválida.", flush=True)


def create_pre_migration_backup() -> Path | None:
    """Protege o estado existente sem exigir credenciais antes da migração.

    Se houver configuração persistente, inclui segredos. Se houver apenas banco,
    cria um snapshot sem segredos. Assim a primeira migração nunca fica bloqueada.
    """
    local_env = settings.base_dir / ".env"
    persistent_env = settings.data_dir / "config.env"
    if not persistent_env.is_file() and local_env.is_file():
        persistent_env.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(local_env, persistent_env)
        try:
            os.chmod(persistent_env, 0o600)
        except OSError:
            pass
    env_exists = persistent_env.is_file()
    db_exists = settings.db_file.is_file()
    if not env_exists and not db_exists:
        return None
    label = datetime.now().strftime("pre_migracao_v6.0_%Y%m%d_%H%M%S.zip")
    return create_backup(
        include_secrets=env_exists,
        destination=_default_backup_dir() / label,
        update_latest=False,
    )



def _env_has_required_secrets(path: Path) -> bool:
    """Confirma que o arquivo possui as credenciais mínimas do Telegram."""
    try:
        values: dict[str, str] = {}
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
        return bool(values.get("TELEGRAM_BOT_TOKEN") and values.get("TELEGRAM_CHAT_ID"))
    except OSError:
        return False


def _recover_persistent_env() -> Path | None:
    """Localiza e consolida configuração existente sem bloquear o backup.

    A fonte persistente é priorizada. Na ausência dela, procura a cópia local,
    o backup env histórico e arquivos .env de versões irmãs. Nunca utiliza
    ``.env.example``.
    """
    persistent = settings.data_dir / "config.env"
    if persistent.is_file() and _env_has_required_secrets(persistent):
        return persistent

    candidates: list[Path] = [
        settings.base_dir / ".env",
        settings.base_dir.parent / "crypto_signals.env.backup",
    ]
    try:
        siblings = list(settings.base_dir.parent.glob("Crypto_Signals_Multichain_CLEAN_v*/.env"))
        siblings.sort(key=lambda item: item.stat().st_mtime, reverse=True)
        candidates.extend(siblings)
    except OSError:
        pass

    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.expanduser().resolve()
        except OSError:
            continue
        if resolved in seen or not resolved.is_file() or not _env_has_required_secrets(resolved):
            continue
        seen.add(resolved)
        persistent.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(resolved, persistent)
        local = settings.base_dir / ".env"
        if resolved != local.resolve():
            shutil.copy2(persistent, local)
        for target in (persistent, local):
            try:
                os.chmod(target, 0o600)
            except OSError:
                pass
        return persistent
    return None

def create_backup(
    *,
    include_secrets: bool = False,
    destination: str | Path | None = None,
    update_latest: bool = True,
) -> Path:
    """Cria e valida um backup portátil em ZIP.

    Quando ``update_latest`` está ativo, também atualiza o alias persistente
    ``Crypto_Signals_Multichain_State/backups/ultimo_backup.zip``.
    O banco SQLite é copiado por snapshot consistente, inclusive com o bot em uso.
    """
    output = Path(destination).expanduser() if destination else _default_backup_dir() / _safe_name()
    if output.suffix.lower() != ".zip":
        output = output.with_suffix(".zip")
    output.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.NamedTemporaryFile(prefix="csm_backup_", suffix=".zip", delete=False, dir=str(output.parent)) as tmp:
        temp_path = Path(tmp.name)

    try:
        secret_source = _recover_persistent_env() if include_secrets else None
        actual_include_secrets = bool(secret_source)
        manifest = {
            "format": 2,
            "created_at": datetime.now().astimezone().isoformat(),
            "version": _product_version(),
            "includes_secrets": actual_include_secrets,
            "secrets_requested": bool(include_secrets),
            "secrets_missing": bool(include_secrets and not actual_include_secrets),
            "database_included": False,
        }
        with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for source, target in _iter_project_files(include_secrets):
                archive.write(source, target.as_posix())

            if actual_include_secrets and secret_source is not None:
                archive.write(secret_source, "state/config.env")
                manifest["persistent_secrets_included"] = True
            else:
                manifest["persistent_secrets_included"] = False

            # V15 outbound destination URLs/HMAC keys live outside SQLite.
            # They are included only in explicit secret-bearing backups.
            distribution_secret_dir = settings.data_dir / "secrets" / "distribution"
            distribution_secret_count = 0
            if include_secrets and distribution_secret_dir.is_dir():
                for item in sorted(distribution_secret_dir.glob("destination_*.json")):
                    if item.is_file():
                        archive.write(item, f"state/secrets/distribution/{item.name}")
                        distribution_secret_count += 1
            manifest["distribution_secrets_included"] = distribution_secret_count
            if distribution_secret_count:
                manifest["includes_secrets"] = True

            if settings.db_file.exists():
                fd, snap_name = tempfile.mkstemp(prefix="signals_", suffix=".db")
                os.close(fd)
                snapshot = Path(snap_name)
                try:
                    source_conn = sqlite3.connect(settings.db_file)
                    target_conn = sqlite3.connect(snapshot)
                    source_conn.backup(target_conn)
                    target_conn.close()
                    source_conn.close()
                    archive.write(snapshot, "state/signals.db")
                    manifest["database_included"] = True
                finally:
                    snapshot.unlink(missing_ok=True)

            archive.writestr("backup_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))

        validate_backup(temp_path)
        os.replace(temp_path, output)
        try:
            os.chmod(output, 0o600)
        except OSError:
            pass
        sign_file(output)
        if update_latest and output.name != LATEST_NAME:
            latest = _write_latest_alias(output)
            sign_file(latest)
        prune_backups(output.parent)
        return output
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def validate_backup(path: str | Path) -> dict:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Backup não encontrado: {source}")
    verify_file(source, require_signature=False)
    with zipfile.ZipFile(source, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"Arquivo corrompido no backup: {bad}")
        if "backup_manifest.json" not in archive.namelist():
            raise RuntimeError("Manifesto do backup ausente")
        return json.loads(archive.read("backup_manifest.json").decode("utf-8"))


def _candidate_roots() -> list[Path]:
    roots = [settings.data_dir, settings.base_dir, settings.base_dir.parent]
    home = Path.home()
    roots.extend([home, home / "Documents"])
    unique: list[Path] = []
    for root in roots:
        try:
            resolved = root.expanduser().resolve()
        except OSError:
            continue
        if resolved not in unique and resolved.exists():
            unique.append(resolved)
    return unique


def inspect_backup_database(path: Path) -> dict:
    """Extrai temporariamente o banco do backup e avalia conteúdo e estrutura."""
    try:
        with zipfile.ZipFile(path, "r") as archive:
            if "state/signals.db" not in archive.namelist():
                return {"valid": False, "score": (0, 0, 0, 0), "reason": "sem banco"}
            fd, temp_name = tempfile.mkstemp(prefix="inspect_backup_", suffix=".db")
            os.close(fd)
            temp = Path(temp_name)
            try:
                with archive.open("state/signals.db") as src, temp.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
                return inspect_database(temp)
            finally:
                temp.unlink(missing_ok=True)
    except (OSError, zipfile.BadZipFile, RuntimeError):
        return {"valid": False, "score": (0, 0, 0, 0), "reason": "backup inválido"}


def backup_quality(path: Path) -> tuple:
    manifest = validate_backup(path)
    report = inspect_backup_database(path)
    try:
        mtime = path.stat().st_mtime
    except OSError:
        mtime = 0.0
    # Conteúdo real do banco vale mais que recência. Segredos e recência desempata.
    return (*tuple(report.get("score", (0, 0, 0, 0))), int(bool(manifest.get("includes_secrets"))), mtime)


def discover_backups() -> list[Path]:
    """Localiza backups reconhecidos da versão atual e de versões irmãs."""
    found: dict[Path, float] = {}
    for root in _candidate_roots():
        patterns = (
            "backups/ultimo_backup.zip",
            "backups/CryptoSignals_*_backup_*.zip",
            "Crypto_Signals_Multichain_CLEAN_v*/backups/ultimo_backup.zip",
            "Crypto_Signals_Multichain_CLEAN_v*/backups/CryptoSignals_*_backup_*.zip",
        )
        for pattern in patterns:
            try:
                items: Iterable[Path] = root.glob(pattern)
            except OSError:
                continue
            for item in items:
                try:
                    if item.is_file():
                        validate_backup(item)
                        found[item.resolve()] = item.stat().st_mtime
                except (OSError, zipfile.BadZipFile, RuntimeError, ValueError):
                    continue
    items = list(found)
    items.sort(key=backup_quality, reverse=True)
    return items


def newest_backup() -> Path | None:
    backups = discover_backups()
    return backups[0] if backups else None


def import_legacy_env(source: str | Path | None = None) -> Path | None:
    """Importa um ``crypto_signals.env.backup`` legado para o projeto atual."""
    candidates = []
    if source:
        candidates.append(Path(source).expanduser())
    candidates.extend([
        settings.base_dir.parent / "crypto_signals.env.backup",
        Path.home() / "Documents" / "crypto_signals.env.backup",
        Path.home() / "crypto_signals.env.backup",
    ])
    local_target = settings.base_dir / ".env"
    persistent_target = settings.data_dir / "config.env"
    for candidate in candidates:
        try:
            if candidate.is_file():
                persistent_target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(candidate, persistent_target)
                shutil.copy2(candidate, local_target)
                for target in (persistent_target, local_target):
                    try:
                        os.chmod(target, 0o600)
                    except OSError:
                        pass
                return candidate.resolve()
        except OSError:
            continue
    return None


def restore_backup(backup_file: str | Path, *, restore_secrets: bool = False) -> dict[str, int]:
    source = Path(backup_file).expanduser().resolve()
    validate_backup(source)

    root = settings.base_dir.resolve()
    restored = {"project_files": 0, "database": 0, "secrets": 0}
    with zipfile.ZipFile(source, "r") as archive:
        names = set(archive.namelist())
        for name in sorted(names):
            if not name.startswith("project/") or name.endswith("/"):
                continue
            relative = Path(name).relative_to("project")
            if relative.name == ".env" and not restore_secrets:
                continue
            # Não substitui o código da nova versão por código antigo. Só restaura
            # arquivos persistentes e o .env.
            allowed = relative.name == ".env" or relative.parts[:1] in {("data",), ("exports",)}
            if not allowed:
                continue
            destination = (root / relative).resolve()
            if root not in destination.parents and destination != root:
                raise RuntimeError("Caminho inseguro detectado no backup")
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(name) as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            restored["project_files"] += 1
            if relative.name == ".env":
                restored["secrets"] += 1
                try:
                    os.chmod(destination, 0o600)
                except OSError:
                    pass

        if restore_secrets:
            secret_prefix = "state/secrets/distribution/"
            secret_names = [n for n in names if n.startswith(secret_prefix) and not n.endswith("/")]
            if secret_names:
                target_dir = settings.data_dir / "secrets" / "distribution"
                target_dir.mkdir(parents=True, exist_ok=True)
                try:
                    os.chmod(target_dir, 0o700)
                except OSError:
                    pass
                for name in sorted(secret_names):
                    basename = Path(name).name
                    if not basename.startswith("destination_") or not basename.endswith(".json"):
                        continue
                    destination = target_dir / basename
                    temp = destination.with_suffix(".restore.tmp")
                    with archive.open(name) as src, temp.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
                    os.replace(temp, destination)
                    try:
                        os.chmod(destination, 0o600)
                    except OSError:
                        pass
                    restored["secrets"] += 1

        if restore_secrets and "state/config.env" in names:
            persistent_env = settings.data_dir / "config.env"
            persistent_env.parent.mkdir(parents=True, exist_ok=True)
            temp_env = persistent_env.with_suffix(".restore.tmp")
            with archive.open("state/config.env") as src, temp_env.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            os.replace(temp_env, persistent_env)
            # Mantém cópia local para compatibilidade com versões antigas.
            shutil.copy2(persistent_env, settings.base_dir / ".env")
            for target in (persistent_env, settings.base_dir / ".env"):
                try:
                    os.chmod(target, 0o600)
                except OSError:
                    pass
            restored["secrets"] += 1

        if "state/signals.db" in names:
            settings.db_file.parent.mkdir(parents=True, exist_ok=True)
            temp_db = settings.db_file.with_suffix(".restore.tmp")
            with archive.open("state/signals.db") as src, temp_db.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            candidate = inspect_database(temp_db)
            current = inspect_database(settings.db_file)
            if not candidate["valid"]:
                temp_db.unlink(missing_ok=True)
                raise RuntimeError("Banco do backup é vazio ou estruturalmente incompatível")
            # Nunca substitui um banco atual mais completo por um backup pior.
            if current["valid"] and tuple(current["score"]) > tuple(candidate["score"]):
                temp_db.unlink(missing_ok=True)
                restored["database_skipped"] = 1
            else:
                if settings.db_file.exists():
                    safety = settings.db_file.parent / "backups" / f"signals_before_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                    safety.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(settings.db_file, safety)
                os.replace(temp_db, settings.db_file)
                restored["database"] = 1
    return restored


def auto_restore_previous(*, restore_secrets: bool = True) -> tuple[Path | None, dict[str, int] | None]:
    """Restaura o backup mais recente encontrado, sem sobrescrever o código atual."""
    source = newest_backup()
    if source is None:
        legacy = import_legacy_env()
        if legacy:
            return legacy, {"project_files": 1, "database": 0, "secrets": 1}
        return None, None
    return source, restore_backup(source, restore_secrets=restore_secrets)
