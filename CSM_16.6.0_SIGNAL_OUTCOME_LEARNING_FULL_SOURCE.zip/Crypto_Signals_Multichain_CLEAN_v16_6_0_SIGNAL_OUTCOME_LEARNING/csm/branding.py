from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import settings

DEFAULT_BRANDING: dict[str, Any] = {
    "product_name": "Crypto Signals Multichain",
    "short_name": "CSM",
    "platform_name": "Phantom Alert Platform",
    "telegram_title": "Crypto Signals Multichain",
    "logo_emoji": "🌐",
    "support_contact": "",
    "legal_disclaimer": "Cenário educacional, não é recomendação financeira.",
}


def load_branding(path: Path | None = None) -> dict[str, Any]:
    target = path or settings.branding_file
    data = dict(DEFAULT_BRANDING)
    try:
        raw = json.loads(target.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            for key in DEFAULT_BRANDING:
                value = raw.get(key)
                if isinstance(value, str) and value.strip():
                    data[key] = value.strip()[:240]
    except Exception:
        pass
    if not data.get("support_contact"):
        data["support_contact"] = settings.sales_contact
    return data


def save_branding(updates: dict[str, Any], path: Path | None = None) -> dict[str, Any]:
    target = path or settings.branding_file
    current = load_branding(target)
    for key, value in updates.items():
        if key not in DEFAULT_BRANDING:
            continue
        text = str(value or "").strip()
        if text:
            current[key] = text[:240]
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".tmp")
    tmp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(target)
    return current
