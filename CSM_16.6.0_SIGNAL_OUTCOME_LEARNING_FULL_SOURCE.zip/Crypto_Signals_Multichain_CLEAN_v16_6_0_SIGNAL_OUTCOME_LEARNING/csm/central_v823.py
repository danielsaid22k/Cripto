from __future__ import annotations

import time
from html import escape
from typing import Any, Callable

from .experience import BRAND_DIVIDER, interval_label, plan_group, subscription_timing
from .plans import PLANS


def _safe_call(call: Callable[[], Any], default: Any) -> Any:
    try:
        value = call()
        return default if value is None else value
    except Exception:
        return default


def _label(mapping: dict[str, str], value: Any, default: str) -> str:
    return mapping.get(str(value or ""), default)


def build_central_v2(app: Any, user_id: int, *, budget_seconds: float = 1.5) -> tuple[str, dict[str, Any]]:
    """Monta a Central Premium somente com estado local/persistente.

    Nenhuma chamada de provider, HTTP ou scanner é feita aqui. O objetivo é que a
    navegação da UI permaneça independente de DexScreener, GeckoTerminal e workers.
    Leituras locais são isoladas individualmente: uma tabela/consulta com problema
    degrada apenas aquele bloco, nunca a tela inteira.
    """
    started = time.monotonic()
    user = _safe_call(lambda: app.storage.get_user(user_id), {}) or {}
    plan_key = str(user.get("plan") or "free")
    plan = PLANS.get(plan_key) or PLANS["free"]
    group = plan_group(plan_key)
    badge = "🆓" if group == "free" else "💠" if group == "plus" else "👑"

    def within_budget() -> bool:
        return (time.monotonic() - started) < max(0.25, float(budget_seconds))

    profile = _safe_call(lambda: app.user_profiles.get(user_id), {}) if within_budget() else {}
    stats = _safe_call(lambda: app.storage.user_signal_stats(user_id), {}) if within_budget() else {}
    favorites = _safe_call(lambda: app.storage.favorite_count(user_id), 0) if within_budget() else 0
    analyses_today = _safe_call(lambda: app.storage.count_today(user_id), 0) if within_budget() else 0
    recent = _safe_call(lambda: app.storage.recent_signal_results(user_id, 4), []) if within_budget() else []

    try:
        due_date, days_text, _ = subscription_timing(user)
    except Exception:
        due_date, days_text = "—", "—"

    risk = _label({"conservative": "Conservador", "moderate": "Moderado", "aggressive": "Agressivo"}, profile.get("risk_profile"), "Moderado")
    detail = _label({"compact": "Compacto", "standard": "Equilibrado", "detailed": "Detalhado"}, profile.get("detail_mode"), "Equilibrado")
    frequency = _label({"plan": "Padrão do plano", "reduced": "Reduzida", "priority": "Prioritária"}, profile.get("notification_frequency"), "Padrão do plano")
    chains = ", ".join(profile.get("preferred_chains") or []) or "Todas"

    recent_lines: list[str] = []
    for row in list(recent or [])[:4]:
        symbol = escape(str(row.get("symbol") or "Token"))
        try:
            pct = float(row.get("result_pct") or 0)
        except (TypeError, ValueError):
            pct = 0.0
        state = row.get("outcome") or ("ABERTO" if row.get("status") == "OPEN" else "FECHADO")
        recent_lines.append(f"• {symbol}: <b>{escape(str(state))}</b> {pct:+.1f}%")
    if not recent_lines:
        recent_lines.append("• Nenhum sinal acompanhado ainda")

    elapsed_ms = int((time.monotonic() - started) * 1000)
    text = (
        f"{BRAND_DIVIDER}\n"
        f"{badge} <b>PHANTOM ALERT • MINHA CENTRAL</b>\n"
        f"{BRAND_DIVIDER}\n\n"
        "👤 <b>CONTA</b>\n"
        f"• Plano: <b>{plan['emoji']} {escape(plan['label'])}</b>\n"
        f"• Vencimento: <b>{escape(str(due_date))}</b>\n"
        f"• Dias restantes: <b>{escape(str(days_text))}</b>\n"
        f"• Scanner do plano: <b>🟢 {interval_label(plan_key)}</b>\n"
        f"• Sinais acompanhados: <b>{int(stats.get('total', 0) or 0)}</b>\n"
        f"• Favoritos: <b>{int(favorites or 0)}/{plan['favorites']}</b>\n"
        f"• Análises hoje: <b>{int(analyses_today or 0)}</b>\n\n"
        "🧭 <b>PERFIL</b>\n"
        f"• Risco: <b>{risk}</b>\n"
        f"• Redes: <b>{escape(chains)}</b>\n"
        f"• Mensagens: <b>{detail}</b>\n"
        f"• Frequência: <b>{frequency}</b>\n"
        f"• Idioma: <b>{escape(str(profile.get('language') or 'pt-BR'))}</b>\n\n"
        "📈 <b>HISTÓRICO RECENTE</b>\n"
        + "\n".join(recent_lines)
        + f"\n\n🛡️ Tela local/fail-safe • {elapsed_ms} ms"
        + "\n⚠️ Métricas observacionais e educacionais; não representam garantia de retorno."
    )
    keyboard = {
        "inline_keyboard": [
            [
                {"text": "🧾 Histórico", "callback_data": "history|0"},
                {"text": "⭐ Favoritos", "callback_data": "favorites"},
            ],
            [{"text": "🎛️ Preferências", "callback_data": "preferences"}],
            [{"text": "👤 Assinatura", "callback_data": "my_plan"}],
            [{"text": "📤 Exportar meus dados", "callback_data": "export_user"}],
            [{"text": "🏠 Menu", "callback_data": "menu"}],
        ]
    }
    return text, keyboard
