
CHAINS={'solana':{'label':'Solana','emoji':'🟣','aliases':{'sol','solana'},'gecko':'solana'},'ethereum':{'label':'Ethereum','emoji':'🔷','aliases':{'eth','ethereum'},'gecko':'eth'},'bsc':{'label':'BNB Chain','emoji':'🟡','aliases':{'bnb','bsc','binance'},'gecko':'bsc'},'base':{'label':'Base','emoji':'🔵','aliases':{'base'},'gecko':'base'},'arbitrum':{'label':'Arbitrum','emoji':'🔹','aliases':{'arb','arbitrum'},'gecko':'arbitrum'},'polygon':{'label':'Polygon','emoji':'🟪','aliases':{'matic','polygon'},'gecko':'polygon_pos'},'avalanche':{'label':'Avalanche','emoji':'🔺','aliases':{'avax','avalanche'},'gecko':'avax'},'optimism':{'label':'Optimism','emoji':'🔴','aliases':{'op','optimism'},'gecko':'optimism'},'fantom':{'label':'Fantom','emoji':'🔵','aliases':{'ftm','fantom'},'gecko':'fantom'},'cronos':{'label':'Cronos','emoji':'⚪','aliases':{'cro','cronos'},'gecko':'cronos'}}
def normalize_chain(v):
    v=(v or '').strip().lower()
    for k,d in CHAINS.items():
        if v==k or v in d['aliases']:return k
def detect_chain(a):
    a=a.strip()
    if a.startswith('0x') and len(a)==42:return 'ethereum'
    if 32<=len(a)<=44 and not a.startswith('0x'):return 'solana'
