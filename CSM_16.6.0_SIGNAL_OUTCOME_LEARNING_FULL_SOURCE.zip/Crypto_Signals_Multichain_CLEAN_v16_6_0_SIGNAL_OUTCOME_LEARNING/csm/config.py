from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
# Compatibilidade: lê primeiro a configuração local, quando existir.
load_dotenv(BASE_DIR / ".env", override=False)

def _resolve_state_dir() -> Path:
    """Resolve o diretório persistente sem aceitar valor vazio ou relativo acidental.

    Um ``CSM_STATE_DIR=`` vazio nas configurações antigas fazia ``Path("")``
    apontar para a pasta do projeto, criando bancos conflitantes. Agora o valor
    vazio usa sempre a pasta persistente irmã do projeto. Caminhos relativos são
    ancorados em ``BASE_DIR.parent`` para permanecerem estáveis entre versões.
    """
    default = BASE_DIR.parent / "Crypto_Signals_Multichain_State"
    raw = os.getenv("CSM_STATE_DIR", "").strip()
    if not raw:
        return default
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        candidate = BASE_DIR.parent / candidate
    return candidate.resolve()


STATE_DIR = _resolve_state_dir()
STATE_DIR.mkdir(parents=True, exist_ok=True)
PERSISTENT_ENV_FILE = STATE_DIR / "config.env"
# A configuração persistente é a fonte principal e sobrevive à troca de versão.
load_dotenv(PERSISTENT_ENV_FILE, override=True)


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {
        "1", "true", "yes", "on", "sim",
    }


def _int(name: str, default: int, *, minimum: int | None = None) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError:
        value = default
    return max(minimum, value) if minimum is not None else value


def _float(name: str, default: float, *, minimum: float | None = None) -> float:
    try:
        value = float(os.getenv(name, str(default)).replace(",", "."))
    except ValueError:
        value = default
    return max(minimum, value) if minimum is not None else value


def _ids(value: str) -> set[int]:
    return {int(item.strip()) for item in value.split(",") if item.strip().isdigit()}


def mask_secret(value: str, visible: int = 4) -> str:
    """Retorna uma representação segura de tokens e chaves para diagnóstico."""
    value = (value or "").strip()
    if not value:
        return "não definida"
    if len(value) <= visible * 2:
        return "*" * len(value)
    return f"{value[:visible]}…{value[-visible:]}"


@dataclass(frozen=True)
class Settings:
    base_dir: Path = BASE_DIR
    data_dir: Path = STATE_DIR
    logs_dir: Path = STATE_DIR / "logs"
    db_file: Path = STATE_DIR / "signals.db"
    log_file: Path = STATE_DIR / "logs" / "crypto_signals.log"

    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    admin_ids: set[int] | None = None
    enable_telegram: bool = _bool("ENABLE_TELEGRAM", True)

    sales_contact: str = os.getenv("SALES_CONTACT", "@seu_usuario").strip()
    price_plus: str = os.getenv("PRICE_PLUS", "R$ 49,90/mês").strip()
    price_premium: str = os.getenv("PRICE_PREMIUM", "R$ 99,90/mês").strip()

    asaas_enabled: bool = _bool("ASAAS_ENABLED", False)
    asaas_environment: str = os.getenv("ASAAS_ENVIRONMENT", "sandbox").strip().lower()
    asaas_api_key: str = os.getenv("ASAAS_API_KEY", "").strip()
    asaas_plus_value: float = _float("ASAAS_PLUS_VALUE", 49.90, minimum=0.01)
    asaas_premium_value: float = _float("ASAAS_PREMIUM_VALUE", 99.90, minimum=0.01)
    asaas_plus_annual_value: float = _float("ASAAS_PLUS_ANNUAL_VALUE", 598.80, minimum=0.01)
    asaas_premium_annual_value: float = _float("ASAAS_PREMIUM_ANNUAL_VALUE", 1198.90, minimum=0.01)
    asaas_payment_methods: tuple[str, ...] = tuple(
        method.strip().upper()
        for method in os.getenv("ASAAS_PAYMENT_METHODS", "PIX,CREDIT_CARD").split(",")
        if method.strip().upper() in {"PIX", "CREDIT_CARD", "BOLETO"}
    )
    asaas_due_days: int = _int("ASAAS_DUE_DAYS", 1, minimum=1)
    plan_monthly_duration_days: int = _int("PLAN_MONTHLY_DURATION_DAYS", 30, minimum=1)
    plan_annual_duration_days: int = _int("PLAN_ANNUAL_DURATION_DAYS", 365, minimum=1)

    request_timeout: int = _int("REQUEST_TIMEOUT", 25, minimum=5)
    http_retries: int = _int("HTTP_RETRIES", 3, minimum=0)
    http_backoff: float = _float("HTTP_BACKOFF", 0.8, minimum=0.0)
    poll_timeout: int = _int("POLL_TIMEOUT", 15, minimum=5)
    cache_ttl: int = _int("CACHE_TTL", 45, minimum=0)
    free_daily_limit: int = _int("FREE_DAILY_LIMIT", 3, minimum=0)
    plus_daily_limit: int = _int("PLUS_DAILY_LIMIT", 30, minimum=0)
    history_page_size: int = _int("HISTORY_PAGE_SIZE", 5, minimum=1)
    scan_limit: int = _int("SCAN_LIMIT", 200, minimum=10)
    scan_max_candidates: int = _int("SCAN_MAX_CANDIDATES", 1000, minimum=10)
    # v10.0.2: a-Shell uses one sequential HTTPS bus. The automatic scanner
    # therefore works in bounded slices instead of treating a large 200-token
    # scan as one monolithic cycle.
    scan_cycle_budget_seconds: float = _float("SCAN_CYCLE_BUDGET_SECONDS", 45.0, minimum=10.0)
    scan_cycle_hard_timeout_seconds: float = _float("SCAN_CYCLE_HARD_TIMEOUT_SECONDS", 120.0, minimum=30.0)
    scan_request_timeout_seconds: float = _float("SCAN_REQUEST_TIMEOUT_SECONDS", 2.5, minimum=1.0)
    scan_discovery_ttl: int = _int("SCAN_DISCOVERY_TTL", 300, minimum=0)
    scan_cache_ttl: int = _int("SCAN_CACHE_TTL", 120, minimum=0)
    scan_workers: int = _int("SCAN_WORKERS", 2, minimum=1)
    # Hotfix mobile: concorrência do scanner é opt-in. No a-Shell/iOS, o padrão seguro é sequencial.
    scan_parallel_enabled: bool = _bool("SCAN_PARALLEL_ENABLED", False)
    scan_mobile_delay_ms: int = _int("SCAN_MOBILE_DELAY_MS", 50, minimum=0)
    scan_min_liquidity: float = _float("SCAN_MIN_LIQUIDITY", 10000.0, minimum=0.0)
    scan_max_liquidity: float = _float("SCAN_MAX_LIQUIDITY", 0.0, minimum=0.0)  # 0 = ilimitada
    scan_min_volume24h: float = _float("SCAN_MIN_VOLUME24H", 25000.0, minimum=0.0)
    scan_max_volume24h: float = _float("SCAN_MAX_VOLUME24H", 0.0, minimum=0.0)  # 0 = ilimitado
    scan_min_marketcap: float = _float("SCAN_MIN_MARKETCAP", 0.0, minimum=0.0)
    scan_max_marketcap: float = _float("SCAN_MAX_MARKETCAP", 50000000.0, minimum=0.0)
    scan_min_age_days: float = _float("SCAN_MIN_AGE_DAYS", 0.0, minimum=0.0)
    scan_max_age_days: float = _float("SCAN_MAX_AGE_DAYS", 3650.0, minimum=0.0)
    scan_min_change24h: float = _float("SCAN_MIN_CHANGE24H", -35.0)
    scan_max_change24h: float = _float("SCAN_MAX_CHANGE24H", 250.0)
    scan_min_txns24h: int = _int("SCAN_MIN_TXNS24H", 20, minimum=0)
    scan_min_buy_sell_ratio: float = _float("SCAN_MIN_BUY_SELL_RATIO", 0.70, minimum=0.0)
    scan_result_limit: int = _int("SCAN_RESULT_LIMIT", 15, minimum=3)
    # v16.2 Scanner Intelligence: evidence-only persistence of the scanner funnel.
    # This layer records why candidates were accepted/rejected and never changes gates.
    scanner_intelligence_enabled: bool = _bool("SCANNER_INTELLIGENCE_ENABLED", True)
    scanner_intelligence_retention_days: int = _int("SCANNER_INTELLIGENCE_RETENTION_DAYS", 14, minimum=1)
    scanner_intelligence_max_decisions: int = _int("SCANNER_INTELLIGENCE_MAX_DECISIONS", 10000, minimum=1000)
    scanner_intelligence_max_decisions_per_cycle: int = _int("SCANNER_INTELLIGENCE_MAX_DECISIONS_PER_CYCLE", 1000, minimum=10)
    # Multi-provider discovery. Extra authenticated providers are opt-in by key
    # and remain sequential/budgeted for Termux and a-Shell stability.
    multi_provider_enabled: bool = _bool("MULTI_PROVIDER_ENABLED", True)
    birdeye_api_key: str = os.getenv("BIRDEYE_API_KEY", "").strip()
    coingecko_api_key: str = os.getenv("COINGECKO_API_KEY", "").strip()
    # V16.5.7: DexPaprika is an additional public DEX/on-chain source.
    # Keyless works by default; a free API key can optionally raise its quota.
    dexpaprika_enabled: bool = _bool("DEXPAPRIKA_ENABLED", True)
    dexpaprika_base_url: str = os.getenv("DEXPAPRIKA_BASE_URL", "https://api.dexpaprika.com").strip().rstrip("/")
    dexpaprika_api_key: str = os.getenv("DEXPAPRIKA_API_KEY", "").strip()
    dexpaprika_chain_sources: int = _int("DEXPAPRIKA_CHAIN_SOURCES", 1, minimum=1)
    dexpaprika_discovery_limit: int = _int("DEXPAPRIKA_DISCOVERY_LIMIT", 30, minimum=5)
    dexpaprika_market_fallback: bool = _bool("DEXPAPRIKA_MARKET_FALLBACK", True)
    dexpaprika_quota_cooldown_seconds: int = _int("DEXPAPRIKA_QUOTA_COOLDOWN_SECONDS", 21600, minimum=900)
    birdeye_quota_cooldown_seconds: int = _int("BIRDEYE_QUOTA_COOLDOWN_SECONDS", 21600, minimum=1800)
    # V16.5.9 adaptive GeckoTerminal backoff: 5m -> 10m -> 20m -> 30m.
    # The legacy variable remains accepted as a compatibility cap/fallback.
    geckoterminal_rate_limit_cooldown_seconds: int = _int("GECKOTERMINAL_RATE_LIMIT_COOLDOWN_SECONDS", 1800, minimum=300)
    geckoterminal_rate_limit_initial_seconds: int = _int("GECKOTERMINAL_RATE_LIMIT_INITIAL_SECONDS", 300, minimum=60)
    geckoterminal_rate_limit_second_seconds: int = _int("GECKOTERMINAL_RATE_LIMIT_SECOND_SECONDS", 600, minimum=60)
    geckoterminal_rate_limit_third_seconds: int = _int("GECKOTERMINAL_RATE_LIMIT_THIRD_SECONDS", 1200, minimum=60)
    geckoterminal_rate_limit_max_seconds: int = _int("GECKOTERMINAL_RATE_LIMIT_MAX_SECONDS", 1800, minimum=300)
    provider_recovery_probe_enabled: bool = _bool("PROVIDER_RECOVERY_PROBE_ENABLED", True)
    provider_recovery_probe_interval_seconds: int = _int("PROVIDER_RECOVERY_PROBE_INTERVAL_SECONDS", 300, minimum=60)
    birdeye_credential_change_probe_enabled: bool = _bool("BIRDEYE_CREDENTIAL_CHANGE_PROBE_ENABLED", True)
    provider_quality_router_enabled: bool = _bool("PROVIDER_QUALITY_ROUTER_ENABLED", True)
    provider_coverage_enabled: bool = _bool("PROVIDER_COVERAGE_ENABLED", True)
    provider_coverage_window_minutes: int = _int("PROVIDER_COVERAGE_WINDOW_MINUTES", 60, minimum=15)
    coverage_guard_enabled: bool = _bool("COVERAGE_GUARD_ENABLED", True)
    coverage_guard_min_analyzed_per_hour: int = _int("COVERAGE_GUARD_MIN_ANALYZED_PER_HOUR", 2, minimum=0)
    coverage_guard_extra_chain_sources: int = _int("COVERAGE_GUARD_EXTRA_CHAIN_SOURCES", 1, minimum=0)
    opportunity_coverage_watchdog_enabled: bool = _bool("OPPORTUNITY_COVERAGE_WATCHDOG_ENABLED", True)
    opportunity_coverage_min_cycles: int = _int("OPPORTUNITY_COVERAGE_MIN_CYCLES", 3, minimum=1)
    opportunity_coverage_notify_admin: bool = _bool("OPPORTUNITY_COVERAGE_NOTIFY_ADMIN", False)
    # V16.5.8: Honeypot.is is a keyless EVM security/pair fallback for GoPlus.
    # It does not discover tokens and does not change live blocking by default.
    honeypot_enabled: bool = _bool("HONEYPOT_ENABLED", True)
    honeypot_base_url: str = os.getenv("HONEYPOT_BASE_URL", "https://api.honeypot.is").strip().rstrip("/")
    honeypot_api_key: str = os.getenv("HONEYPOT_API_KEY", "").strip()
    honeypot_cache_ttl: int = _int("HONEYPOT_CACHE_TTL", 1800, minimum=60)
    honeypot_stale_ttl: int = _int("HONEYPOT_STALE_TTL", 86400, minimum=300)
    honeypot_enforce_blocks: bool = _bool("HONEYPOT_ENFORCE_BLOCKS", False)
    honeypot_max_buy_tax_pct: float = _float("HONEYPOT_MAX_BUY_TAX_PCT", 25.0, minimum=0.0)
    honeypot_max_sell_tax_pct: float = _float("HONEYPOT_MAX_SELL_TAX_PCT", 25.0, minimum=0.0)
    # GoPlus is a post-discovery security gate, not a discovery source.
    # Anonymous access remains possible; an optional Bearer token can be supplied
    # for accounts that use authenticated GoPlus API access.
    goplus_enabled: bool = _bool("GOPLUS_ENABLED", True)
    goplus_access_token: str = os.getenv("GOPLUS_ACCESS_TOKEN", "").strip()
    goplus_cache_ttl: int = _int("GOPLUS_CACHE_TTL", 1800, minimum=60)
    goplus_stale_ttl: int = _int("GOPLUS_STALE_TTL", 86400, minimum=300)
    goplus_min_security_score: int = _int("GOPLUS_MIN_SECURITY_SCORE", 55, minimum=0)
    goplus_max_buy_tax_pct: float = _float("GOPLUS_MAX_BUY_TAX_PCT", 25.0, minimum=0.0)
    goplus_max_sell_tax_pct: float = _float("GOPLUS_MAX_SELL_TAX_PCT", 25.0, minimum=0.0)
    goplus_fail_closed: bool = _bool("GOPLUS_FAIL_CLOSED", False)
    goplus_score_weight_pct: int = _int("GOPLUS_SCORE_WEIGHT_PCT", 25, minimum=0)
    multi_provider_discovery_ttl: int = _int("MULTI_PROVIDER_DISCOVERY_TTL", 120, minimum=30)
    multi_provider_plus_chain_sources: int = _int("MULTI_PROVIDER_PLUS_CHAIN_SOURCES", 1, minimum=1)
    multi_provider_premium_chain_sources: int = _int("MULTI_PROVIDER_PREMIUM_CHAIN_SOURCES", 2, minimum=1)
    scan_chains: tuple[str, ...] = tuple(
        item.strip().lower() for item in os.getenv(
            "SCAN_CHAINS", "solana,ethereum,bsc,base,arbitrum,polygon,avalanche,optimism,fantom,cronos"
        ).split(",") if item.strip()
    )
    # Automação comercial e sinais
    payment_auto_check: bool = _bool("PAYMENT_AUTO_CHECK", True)
    payment_check_interval: int = _int("PAYMENT_CHECK_INTERVAL", 60, minimum=30)
    payment_check_batch: int = _int("PAYMENT_CHECK_BATCH", 100, minimum=1)
    asaas_auto_renew: bool = _bool("ASAAS_AUTO_RENEW", True)

    # V16.5.8 Telegram Delivery Guard. The active runtime is cooperative and
    # sequential, so small pacing gaps prevent same-chat bursts without threads.
    telegram_min_global_interval_seconds: float = _float("TELEGRAM_MIN_GLOBAL_INTERVAL_SECONDS", 0.05, minimum=0.0)
    telegram_min_chat_interval_seconds: float = _float("TELEGRAM_MIN_CHAT_INTERVAL_SECONDS", 1.05, minimum=0.0)
    telegram_retry_after_max_seconds: int = _int("TELEGRAM_RETRY_AFTER_MAX_SECONDS", 15, minimum=1)
    telegram_auto_suppress_unreachable: bool = _bool("TELEGRAM_AUTO_SUPPRESS_UNREACHABLE", True)

    auto_signals_enabled: bool = _bool("AUTO_SIGNALS_ENABLED", True)
    auto_scan_interval_free: int = _int("AUTO_SCAN_INTERVAL_FREE", 900, minimum=60)
    auto_scan_interval_plus: int = _int("AUTO_SCAN_INTERVAL_PLUS", 300, minimum=60)
    auto_scan_interval_premium: int = _int("AUTO_SCAN_INTERVAL_PREMIUM", 60, minimum=60)
    # O scanner decide a aprovação. A entrega prioriza score e usa cotas próprias
    # por plano; o limite legado permanece apenas para compatibilidade de .env.
    auto_signal_min_score: int = _int("AUTO_SIGNAL_MIN_SCORE", 78, minimum=0)
    auto_signal_limit: int = _int("AUTO_SIGNAL_LIMIT", 2, minimum=1)
    auto_signal_limit_free: int = _int("AUTO_SIGNAL_LIMIT_FREE", 1, minimum=1)
    auto_signal_limit_plus: int = _int("AUTO_SIGNAL_LIMIT_PLUS", 2, minimum=1)
    auto_signal_limit_premium: int = _int("AUTO_SIGNAL_LIMIT_PREMIUM", 3, minimum=1)
    auto_signal_notify_empty_admin: bool = _bool("AUTO_SIGNAL_NOTIFY_EMPTY_ADMIN", False)
    signal_monitor_enabled: bool = _bool("SIGNAL_MONITOR_ENABLED", True)
    signal_monitor_interval: int = _int("SIGNAL_MONITOR_INTERVAL", 120, minimum=60)

    # v11 Performance Intelligence: evidence ledger and post-signal observations.
    performance_ledger_enabled: bool = _bool("PERFORMANCE_LEDGER_ENABLED", True)
    performance_monitor_enabled: bool = _bool("PERFORMANCE_MONITOR_ENABLED", True)
    performance_monitor_interval: int = _int("PERFORMANCE_MONITOR_INTERVAL", 300, minimum=60)
    performance_monitor_batch: int = _int("PERFORMANCE_MONITOR_BATCH", 12, minimum=1)
    performance_request_timeout_seconds: float = _float("PERFORMANCE_REQUEST_TIMEOUT_SECONDS", 2.5, minimum=1.0)
    performance_market_cache_ttl: int = _int("PERFORMANCE_MARKET_CACHE_TTL", 90, minimum=30)
    performance_market_stale_ttl: int = _int("PERFORMANCE_MARKET_STALE_TTL", 900, minimum=300)
    adaptive_confidence_enabled: bool = _bool("ADAPTIVE_CONFIDENCE_ENABLED", True)
    adaptive_min_samples: int = _int("ADAPTIVE_MIN_SAMPLES", 30, minimum=5)

    # v16.4.5 Signal Quality Shadow Gate.
    # Evidence-only: coleta confirmação temporal sem bloquear ou alterar sinais.
    signal_quality_shadow_enabled: bool = _bool("SIGNAL_QUALITY_SHADOW_ENABLED", True)
    signal_quality_shadow_poll_interval: int = _int("SIGNAL_QUALITY_SHADOW_POLL_INTERVAL", 60, minimum=60)
    signal_quality_shadow_target_seconds: int = _int("SIGNAL_QUALITY_SHADOW_TARGET_SECONDS", 300, minimum=60)
    signal_quality_shadow_grace_seconds: int = _int("SIGNAL_QUALITY_SHADOW_GRACE_SECONDS", 180, minimum=0)

    # V16.6.0 Signal Outcome Learning: evidence-only learning over delivered
    # signal outcomes. There is intentionally no AUTO_APPLY setting/path in
    # this release; recommendations never change filters, scoring or delivery.
    signal_outcome_learning_enabled: bool = _bool("SIGNAL_OUTCOME_LEARNING_ENABLED", True)
    signal_outcome_learning_interval_seconds: int = _int("SIGNAL_OUTCOME_LEARNING_INTERVAL_SECONDS", 1800, minimum=300)
    signal_outcome_learning_lookback_days: int = _int("SIGNAL_OUTCOME_LEARNING_LOOKBACK_DAYS", 30, minimum=1)
    signal_outcome_learning_min_samples: int = _int("SIGNAL_OUTCOME_LEARNING_MIN_SAMPLES", 12, minimum=2)
    signal_outcome_learning_prior_strength: float = _float("SIGNAL_OUTCOME_LEARNING_PRIOR_STRENGTH", 8.0, minimum=1.0)

    # v16.3 Signal Lifecycle: post-signal state machine and quota-conscious cadence.
    signal_lifecycle_enabled: bool = _bool("SIGNAL_LIFECYCLE_ENABLED", True)
    signal_lifecycle_target3_pct: float = _float("SIGNAL_LIFECYCLE_TARGET3_PCT", 100.0, minimum=1.0)
    signal_lifecycle_expire_hours: int = _int("SIGNAL_LIFECYCLE_EXPIRE_HOURS", 168, minimum=1)
    signal_lifecycle_liquidity_drop_pct: float = _float("SIGNAL_LIFECYCLE_LIQUIDITY_DROP_PCT", 30.0, minimum=1.0)
    signal_lifecycle_buy_pressure_drop_points: float = _float("SIGNAL_LIFECYCLE_BUY_PRESSURE_DROP_POINTS", 15.0, minimum=1.0)
    signal_lifecycle_score_drop: int = _int("SIGNAL_LIFECYCLE_SCORE_DROP", 15, minimum=1)
    signal_lifecycle_recent_gap: int = _int("SIGNAL_LIFECYCLE_RECENT_GAP", 300, minimum=60)
    signal_lifecycle_active_gap: int = _int("SIGNAL_LIFECYCLE_ACTIVE_GAP", 600, minimum=60)
    signal_lifecycle_stable_gap: int = _int("SIGNAL_LIFECYCLE_STABLE_GAP", 900, minimum=60)
    signal_lifecycle_old_gap: int = _int("SIGNAL_LIFECYCLE_OLD_GAP", 1800, minimum=60)
    signal_lifecycle_deteriorating_gap: int = _int("SIGNAL_LIFECYCLE_DETERIORATING_GAP", 300, minimum=60)
    signal_lifecycle_alert_cooldown: int = _int("SIGNAL_LIFECYCLE_ALERT_COOLDOWN", 1800, minimum=300)

    # v13.5 On-Chain Intelligence. Mobile runtimes use HTTPS polling only;
    # no public webhook, inbound port or background thread is required.
    onchain_enabled: bool = _bool("ONCHAIN_ENABLED", True)
    onchain_monitor_interval: int = _int("ONCHAIN_MONITOR_INTERVAL", 300, minimum=60)
    onchain_monitor_batch: int = _int("ONCHAIN_MONITOR_BATCH", 8, minimum=1)
    onchain_monitor_days: int = _int("ONCHAIN_MONITOR_DAYS", 7, minimum=1)
    onchain_request_timeout_seconds: float = _float("ONCHAIN_REQUEST_TIMEOUT_SECONDS", 3.5, minimum=1.0)
    onchain_snapshot_bucket_seconds: int = _int("ONCHAIN_SNAPSHOT_BUCKET_SECONDS", 300, minimum=60)
    onchain_whale_min_usd: float = _float("ONCHAIN_WHALE_MIN_USD", 10000.0, minimum=100.0)
    onchain_liquidity_warn_drop_pct: float = _float("ONCHAIN_LIQUIDITY_WARN_DROP_PCT", 25.0, minimum=1.0)
    onchain_alert_cooldown: int = _int("ONCHAIN_ALERT_COOLDOWN", 1800, minimum=300)
    onchain_solana_top_accounts: int = min(5, _int("ONCHAIN_SOLANA_TOP_ACCOUNTS", 3, minimum=1))
    onchain_solana_tx_per_poll: int = min(6, _int("ONCHAIN_SOLANA_TX_PER_POLL", 4, minimum=1))
    onchain_evm_rebase_after_seconds: int = _int("ONCHAIN_EVM_REBASE_AFTER_SECONDS", 3600, minimum=300)
    helius_api_key: str = os.getenv("HELIUS_API_KEY", "").strip()
    helius_secure_rpc_url: str = os.getenv("HELIUS_SECURE_RPC_URL", "").strip()
    evm_rpc_ethereum: str = os.getenv("EVM_RPC_ETHEREUM", "").strip()
    evm_rpc_bsc: str = os.getenv("EVM_RPC_BSC", "").strip()
    evm_rpc_base: str = os.getenv("EVM_RPC_BASE", "").strip()
    evm_rpc_arbitrum: str = os.getenv("EVM_RPC_ARBITRUM", "").strip()
    evm_rpc_polygon: str = os.getenv("EVM_RPC_POLYGON", "").strip()
    evm_rpc_avalanche: str = os.getenv("EVM_RPC_AVALANCHE", "").strip()
    evm_rpc_optimism: str = os.getenv("EVM_RPC_OPTIMISM", "").strip()
    evm_rpc_fantom: str = os.getenv("EVM_RPC_FANTOM", "").strip()
    evm_rpc_cronos: str = os.getenv("EVM_RPC_CRONOS", "").strip()

    # v14 Wallet/Deployer Reputation Engine. Local evidence only; no network calls.
    reputation_enabled: bool = _bool("REPUTATION_ENABLED", True)
    reputation_refresh_interval: int = _int("REPUTATION_REFRESH_INTERVAL", 300, minimum=60)
    reputation_refresh_limit: int = _int("REPUTATION_REFRESH_LIMIT", 1000, minimum=50)
    reputation_min_confidence: int = _int("REPUTATION_MIN_CONFIDENCE", 30, minimum=0)
    reputation_csm_max_penalty: int = _int("REPUTATION_CSM_MAX_PENALTY", 20, minimum=0)

    # v14.5 Observability & Operations. Local/cooperative only: no webhook, no
    # background collector and no mandatory third-party telemetry service.
    observability_enabled: bool = _bool("OBSERVABILITY_ENABLED", True)
    observability_runtime_interval: int = _int("OBSERVABILITY_RUNTIME_INTERVAL", 60, minimum=30)
    observability_retention_days: int = _int("OBSERVABILITY_RETENTION_DAYS", 30, minimum=1)
    observability_provider_latency_warn_ms: float = _float("OBSERVABILITY_PROVIDER_LATENCY_WARN_MS", 2500.0, minimum=100.0)
    observability_provider_success_warn_pct: float = _float("OBSERVABILITY_PROVIDER_SUCCESS_WARN_PCT", 70.0, minimum=0.0)
    observability_delivery_error_count: int = _int("OBSERVABILITY_DELIVERY_ERROR_COUNT", 2, minimum=1)
    observability_delivery_error_pct: float = _float("OBSERVABILITY_DELIVERY_ERROR_PCT", 25.0, minimum=0.0)
    observability_network_busy_warn_seconds: float = _float("OBSERVABILITY_NETWORK_BUSY_WARN_SECONDS", 15.0, minimum=1.0)
    observability_admin_alerts: bool = _bool("OBSERVABILITY_ADMIN_ALERTS", True)
    observability_admin_alert_cooldown: int = _int("OBSERVABILITY_ADMIN_ALERT_COOLDOWN", 1800, minimum=300)
    observability_provider_stale_seconds: int = _int("OBSERVABILITY_PROVIDER_STALE_SECONDS", 1800, minimum=300)
    # Current health is intentionally shorter-lived than incident history.
    # An old provider incident may remain auditable OPEN until stale cleanup,
    # while no longer making the live system look CRITICAL.
    observability_current_provider_window_seconds: int = _int("OBSERVABILITY_CURRENT_PROVIDER_WINDOW_SECONDS", 300, minimum=60)
    observability_provider_limit_alert_cooldown: int = _int("OBSERVABILITY_PROVIDER_LIMIT_ALERT_COOLDOWN", 21600, minimum=900)
    observability_provider_recovery_stable_seconds: int = _int("OBSERVABILITY_PROVIDER_RECOVERY_STABLE_SECONDS", 600, minimum=60)

    # v15 Distribution Platform. Outbound-only channels; Telegram remains primary.
    distribution_enabled: bool = _bool("DISTRIBUTION_ENABLED", True)
    distribution_max_attempts: int = _int("DISTRIBUTION_MAX_ATTEMPTS", 5, minimum=1)
    distribution_timeout_seconds: float = _float("DISTRIBUTION_TIMEOUT_SECONDS", 6.0, minimum=1.0)
    distribution_scheduler_interval: int = _int("DISTRIBUTION_SCHEDULER_INTERVAL", 2, minimum=1)
    smtp_host: str = os.getenv("SMTP_HOST", "").strip()
    smtp_port: int = _int("SMTP_PORT", 587, minimum=1)
    smtp_username: str = os.getenv("SMTP_USERNAME", "").strip()
    smtp_password: str = os.getenv("SMTP_PASSWORD", "").strip()
    smtp_from: str = os.getenv("SMTP_FROM", "").strip()
    smtp_starttls: bool = _bool("SMTP_STARTTLS", True)
    smtp_ssl: bool = _bool("SMTP_SSL", False)
    signal_target1_pct: float = _float("SIGNAL_TARGET1_PCT", 25.0, minimum=1.0)
    signal_target2_pct: float = _float("SIGNAL_TARGET2_PCT", 50.0, minimum=2.0)
    signal_stop_pct: float = _float("SIGNAL_STOP_PCT", 12.0, minimum=1.0)
    signal_alert_cooldown_hours: int = _int("SIGNAL_ALERT_COOLDOWN_HOURS", 24, minimum=1)
    signal_smart_realert_enabled: bool = _bool("SIGNAL_SMART_REALERT_ENABLED", True)
    signal_smart_plus_score_step: int = _int("SIGNAL_SMART_PLUS_SCORE_STEP", 12, minimum=1)
    signal_smart_plus_volume_ratio: float = _float("SIGNAL_SMART_PLUS_VOLUME_RATIO", 2.0, minimum=1.1)
    signal_smart_plus_peak_step_pct: float = _float("SIGNAL_SMART_PLUS_PEAK_STEP_PCT", 20.0, minimum=1.0)
    signal_smart_premium_score_step: int = _int("SIGNAL_SMART_PREMIUM_SCORE_STEP", 7, minimum=1)
    signal_smart_premium_volume_ratio: float = _float("SIGNAL_SMART_PREMIUM_VOLUME_RATIO", 1.5, minimum=1.1)
    signal_smart_premium_peak_step_pct: float = _float("SIGNAL_SMART_PREMIUM_PEAK_STEP_PCT", 10.0, minimum=1.0)

    # v16.4 Smart Reentry. Cooldown is commercial-plan specific, but every
    # reentry must come from a candidate that the current scanner approved
    # again. Terminal/deteriorated prior outcomes additionally require fresh
    # market improvement evidence; no setting here can bypass scanner safety.
    signal_reentry_enabled: bool = _bool("SIGNAL_REENTRY_ENABLED", True)
    signal_reentry_cooldown_free_hours: int = _int("SIGNAL_REENTRY_COOLDOWN_FREE_HOURS", 24, minimum=1)
    signal_reentry_cooldown_plus_hours: int = _int("SIGNAL_REENTRY_COOLDOWN_PLUS_HOURS", 12, minimum=1)
    signal_reentry_cooldown_premium_hours: int = _int("SIGNAL_REENTRY_COOLDOWN_PREMIUM_HOURS", 6, minimum=1)
    signal_reentry_score_improvement: int = _int("SIGNAL_REENTRY_SCORE_IMPROVEMENT", 3, minimum=1)
    signal_reentry_liquidity_improvement_pct: float = _float("SIGNAL_REENTRY_LIQUIDITY_IMPROVEMENT_PCT", 10.0, minimum=1.0)
    signal_reentry_buy_pressure_improvement_points: float = _float("SIGNAL_REENTRY_BUY_PRESSURE_IMPROVEMENT_POINTS", 5.0, minimum=1.0)
    signal_reentry_volume_ratio: float = _float("SIGNAL_REENTRY_VOLUME_RATIO", 1.20, minimum=1.01)
    signal_reentry_momentum_improvement_points: float = _float("SIGNAL_REENTRY_MOMENTUM_IMPROVEMENT_POINTS", 5.0, minimum=1.0)
    signal_reentry_history_days: int = _int("SIGNAL_REENTRY_HISTORY_DAYS", 365, minimum=30)
    favorite_monitor_enabled: bool = _bool("FAVORITE_MONITOR_ENABLED", True)
    favorite_monitor_interval: int = _int("FAVORITE_MONITOR_INTERVAL", 300, minimum=60)
    favorite_alert_up_pct: float = _float("FAVORITE_ALERT_UP_PCT", 10.0, minimum=1.0)
    favorite_alert_down_pct: float = _float("FAVORITE_ALERT_DOWN_PCT", 10.0, minimum=1.0)
    favorite_alert_cooldown_hours: int = _int("FAVORITE_ALERT_COOLDOWN_HOURS", 12, minimum=1)
    dashboard_recent_limit: int = _int("DASHBOARD_RECENT_LIMIT", 5, minimum=1)


    # Líder de Projeto com aprovação humana obrigatória
    project_leader_enabled: bool = _bool("PROJECT_LEADER_ENABLED", True)
    project_leader_auto_audit: bool = _bool("PROJECT_LEADER_AUTO_AUDIT", True)
    project_leader_audit_interval: int = _int("PROJECT_LEADER_AUDIT_INTERVAL", 21600, minimum=300)
    project_leader_log_max_bytes: int = _int("PROJECT_LEADER_LOG_MAX_BYTES", 5242880, minimum=102400)
    project_leader_validation_timeout: int = _int("PROJECT_LEADER_VALIDATION_TIMEOUT", 180, minimum=30)
    project_leader_maintenance_eta: int = _int("PROJECT_LEADER_MAINTENANCE_ETA", 5, minimum=1)

    app_environment: str = os.getenv("APP_ENVIRONMENT", "production").strip().lower() or "production"
    product_report_interval: int = _int("PRODUCT_REPORT_INTERVAL", 21600, minimum=300)

    # v11.5 SaaS Platform. API remains read-only for market/signal data;
    # tenant and API-key writes happen only through explicit local CLI commands.
    saas_api_enabled: bool = _bool("SAAS_API_ENABLED", False)
    saas_api_host: str = os.getenv("SAAS_API_HOST", "127.0.0.1").strip() or "127.0.0.1"
    saas_api_port: int = _int("SAAS_API_PORT", 8787, minimum=1)
    saas_default_rpm: int = _int("SAAS_DEFAULT_RPM", 60, minimum=1)
    saas_default_daily_limit: int = _int("SAAS_DEFAULT_DAILY_LIMIT", 10000, minimum=1)

    # v16 Customer Portal & Enterprise Dashboard. The portal is served by the
    # existing authenticated SaaS API; no extra public listener is created.
    customer_portal_enabled: bool = _bool("CUSTOMER_PORTAL_ENABLED", True)
    customer_portal_max_signals: int = _int("CUSTOMER_PORTAL_MAX_SIGNALS", 100, minimum=5)
    enterprise_dashboard_enabled: bool = _bool("ENTERPRISE_DASHBOARD_ENABLED", True)

    # White-label branding is persisted separately from secrets so a buyer can
    # rebrand the product without editing source code.
    branding_file: Path = STATE_DIR / "branding.json"

    # Painel administrativo web somente leitura
    admin_web_enabled: bool = _bool("ADMIN_WEB_ENABLED", False)
    admin_web_host: str = os.getenv("ADMIN_WEB_HOST", "127.0.0.1").strip() or "127.0.0.1"
    admin_web_port: int = _int("ADMIN_WEB_PORT", 8765, minimum=1)
    admin_web_token: str = os.getenv("ADMIN_WEB_TOKEN", "").strip()

    log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()

    def __post_init__(self) -> None:
        object.__setattr__(self, "admin_ids", _ids(os.getenv("ADMIN_USER_IDS", "")))
        if not self.asaas_payment_methods:
            object.__setattr__(self, "asaas_payment_methods", ("PIX", "CREDIT_CARD"))
        if self.app_environment not in {"production", "staging"}:
            object.__setattr__(self, "app_environment", "production")
        if self.asaas_environment not in {"sandbox", "production"}:
            object.__setattr__(self, "asaas_environment", "sandbox")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)

    @property
    def asaas_base_url(self) -> str:
        if self.asaas_environment == "production":
            return "https://api.asaas.com/v3"
        return "https://api-sandbox.asaas.com/v3"

    @property
    def payments_ready(self) -> bool:
        return self.asaas_enabled and not self.asaas_validation_errors()

    def asaas_validation_errors(self) -> list[str]:
        errors: list[str] = []
        if not self.asaas_enabled:
            return errors
        if not self.asaas_api_key:
            errors.append("ASAAS_API_KEY não definida")
            return errors
        key = self.asaas_api_key.lower()
        if self.asaas_environment == "production" and any(marker in key for marker in ("sandbox", "hmlg")):
            errors.append("a chave aparenta ser de sandbox, mas o ambiente é production")
        if self.asaas_environment == "sandbox" and "prod" in key:
            errors.append("a chave aparenta ser de produção, mas o ambiente é sandbox")
        return errors

    def evm_rpc_url(self, chain: str) -> str:
        return {
            "ethereum": self.evm_rpc_ethereum, "bsc": self.evm_rpc_bsc, "base": self.evm_rpc_base,
            "arbitrum": self.evm_rpc_arbitrum, "polygon": self.evm_rpc_polygon, "avalanche": self.evm_rpc_avalanche,
            "optimism": self.evm_rpc_optimism, "fantom": self.evm_rpc_fantom, "cronos": self.evm_rpc_cronos,
        }.get(str(chain or "").strip().lower(), "")

    @property
    def helius_ready(self) -> bool:
        return bool(self.helius_secure_rpc_url or self.helius_api_key)

    def configuration_errors(self) -> list[str]:
        errors: list[str] = []
        if self.enable_telegram:
            if not self.telegram_token:
                errors.append("TELEGRAM_BOT_TOKEN não definido")
            if not self.telegram_chat_id:
                errors.append("TELEGRAM_CHAT_ID não definido")
        errors.extend(self.asaas_validation_errors())

        if not 1 <= int(self.admin_web_port) <= 65535:
            errors.append("ADMIN_WEB_PORT deve estar entre 1 e 65535")
        if not 1 <= int(self.saas_api_port) <= 65535:
            errors.append("SAAS_API_PORT deve estar entre 1 e 65535")
        if not 1 <= int(self.smtp_port) <= 65535:
            errors.append("SMTP_PORT deve estar entre 1 e 65535")
        if self.scan_max_liquidity and self.scan_max_liquidity < self.scan_min_liquidity:
            errors.append("SCAN_MAX_LIQUIDITY não pode ser menor que SCAN_MIN_LIQUIDITY")
        if self.scan_max_volume24h and self.scan_max_volume24h < self.scan_min_volume24h:
            errors.append("SCAN_MAX_VOLUME24H não pode ser menor que SCAN_MIN_VOLUME24H")
        if self.scan_max_marketcap and self.scan_max_marketcap < self.scan_min_marketcap:
            errors.append("SCAN_MAX_MARKETCAP não pode ser menor que SCAN_MIN_MARKETCAP")
        if self.scan_max_age_days and self.scan_max_age_days < self.scan_min_age_days:
            errors.append("SCAN_MAX_AGE_DAYS não pode ser menor que SCAN_MIN_AGE_DAYS")
        if self.scan_max_change24h < self.scan_min_change24h:
            errors.append("SCAN_MAX_CHANGE24H não pode ser menor que SCAN_MIN_CHANGE24H")
        if self.signal_target2_pct <= self.signal_target1_pct:
            errors.append("SIGNAL_TARGET2_PCT deve ser maior que SIGNAL_TARGET1_PCT")
        if self.goplus_min_security_score > 100:
            errors.append("GOPLUS_MIN_SECURITY_SCORE deve estar entre 0 e 100")
        if self.goplus_score_weight_pct > 100:
            errors.append("GOPLUS_SCORE_WEIGHT_PCT deve estar entre 0 e 100")
        if self.reputation_min_confidence > 100:
            errors.append("REPUTATION_MIN_CONFIDENCE deve estar entre 0 e 100")
        if self.reputation_csm_max_penalty > 100:
            errors.append("REPUTATION_CSM_MAX_PENALTY deve estar entre 0 e 100")
        if self.observability_provider_success_warn_pct > 100:
            errors.append("OBSERVABILITY_PROVIDER_SUCCESS_WARN_PCT deve estar entre 0 e 100")
        if self.observability_delivery_error_pct > 100:
            errors.append("OBSERVABILITY_DELIVERY_ERROR_PCT deve estar entre 0 e 100")
        if self.goplus_max_buy_tax_pct > 100 or self.goplus_max_sell_tax_pct > 100:
            errors.append("Limites de taxa GoPlus devem estar entre 0 e 100%")
        if self.honeypot_max_buy_tax_pct > 100 or self.honeypot_max_sell_tax_pct > 100:
            errors.append("Limites de taxa Honeypot.is devem estar entre 0 e 100%")
        try:
            from .chains import CHAINS
            unknown = sorted(set(self.scan_chains) - set(CHAINS))
            if unknown:
                errors.append("SCAN_CHAINS contém rede(s) desconhecida(s): " + ", ".join(unknown))
        except Exception:
            pass
        return errors


settings = Settings()
