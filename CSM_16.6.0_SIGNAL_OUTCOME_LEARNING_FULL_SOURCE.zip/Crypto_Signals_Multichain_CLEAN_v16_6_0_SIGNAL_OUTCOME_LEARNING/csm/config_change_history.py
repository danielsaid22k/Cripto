from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import hashlib
import json

from .config import STATE_DIR


VERSION = "16.5.2"

HISTORY_FILE = (
    Path(STATE_DIR)
    / "logs"
    / "config_change_history.jsonl"
)


def classify_origin(
    process_context: list[str] | None,
) -> str:
    text = "\n".join(
        process_context or []
    ).lower()

    if (
        "setup_config" in text
        or "csm-supervisor" in text
        or "/setup/update" in text
    ):
        return "SETUP_CENTER"

    if (
        "admin_web" in text
        or "retool" in text
    ):
        return "ADMIN_RETOOL"

    if (
        "project_leader" in text
        or "leader-bundle" in text
    ):
        return "UPDATE_ENGINE"

    if (
        "launcher.py" in text
        or "saas-api" in text
    ):
        return "RUNTIME"

    return "UNKNOWN"


def _event_id(event: dict[str, Any]) -> str:
    raw = json.dumps(
        {
            "time": event.get("time"),
            "changed": event.get("changed"),
        },
        ensure_ascii=False,
        sort_keys=True,
    )

    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()[:20]


def normalize_audit_event(
    event: dict[str, Any],
) -> dict[str, Any]:
    changed = (
        event.get("changed")
        if isinstance(
            event.get("changed"),
            dict,
        )
        else {}
    )

    context = (
        event.get("process_context")
        if isinstance(
            event.get("process_context"),
            list,
        )
        else []
    )

    return {
        "event_id": _event_id(event),
        "time": (
            event.get("time")
            or datetime.now(
                timezone.utc
            ).isoformat()
        ),
        "version": VERSION,
        "event": "CONFIG_CHANGED",
        "origin": classify_origin(context),
        "keys": sorted(changed.keys()),
        "changed": changed,
        "origin_confidence": (
            "HEURISTIC"
            if context
            else "UNKNOWN"
        ),
        "safety": (
            "Fingerprints only; "
            "secret values are never stored."
        ),
    }


def append_history(
    event: dict[str, Any],
) -> dict[str, Any]:
    normalized = normalize_audit_event(
        event
    )

    HISTORY_FILE.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    event_id = normalized["event_id"]

    if HISTORY_FILE.is_file():
        try:
            lines = HISTORY_FILE.read_text(
                encoding="utf-8"
            ).splitlines()[-500:]

            for line in lines:
                try:
                    old = json.loads(line)
                except Exception:
                    continue

                if old.get("event_id") == event_id:
                    return normalized

        except Exception:
            pass

    with HISTORY_FILE.open(
        "a",
        encoding="utf-8",
    ) as handle:
        handle.write(
            json.dumps(
                normalized,
                ensure_ascii=False,
            )
            + "\n"
        )

    return normalized


def history_report(
    limit: int = 50,
) -> dict[str, Any]:
    events = []

    if HISTORY_FILE.is_file():
        for line in HISTORY_FILE.read_text(
            encoding="utf-8"
        ).splitlines():
            try:
                event = json.loads(line)
            except Exception:
                continue

            if isinstance(event, dict):
                events.append(event)

    events = events[-max(1, limit):]

    origins = Counter()
    keys = Counter()

    for event in events:
        origins[
            str(
                event.get("origin")
                or "UNKNOWN"
            )
        ] += 1

        for key in event.get("keys") or []:
            keys[str(key)] += 1

    return {
        "version": VERSION,
        "events": len(events),
        "by_origin": dict(origins),
        "by_key": dict(keys),
        "latest": (
            events[-1]
            if events
            else None
        ),
        "history": list(
            reversed(events)
        ),
        "secret_values_stored": False,
    }

def overview_status(
    limit: int = 20,
) -> dict[str, Any]:
    report = history_report(limit=limit)

    latest = report.get("latest")

    if not latest:
        status = "STABLE"
        reason = "Nenhuma alteração monitorada registrada."
    else:
        origin = str(
            latest.get("origin")
            or "UNKNOWN"
        )

        if origin == "UNKNOWN":
            status = "REVIEW"
            reason = (
                "Última alteração possui origem "
                "não identificada."
            )
        else:
            status = "KNOWN_CHANGE"
            reason = (
                "Última alteração possui origem "
                "identificada."
            )

    return {
        "version": VERSION,
        "status": status,
        "reason": reason,
        "events": report.get("events", 0),
        "latest": latest,
        "by_origin": report.get(
            "by_origin",
            {},
        ),
        "by_key": report.get(
            "by_key",
            {},
        ),
        "secret_values_stored": False,
        "automatic_restore": False,
        "automatic_block": False,
    }

