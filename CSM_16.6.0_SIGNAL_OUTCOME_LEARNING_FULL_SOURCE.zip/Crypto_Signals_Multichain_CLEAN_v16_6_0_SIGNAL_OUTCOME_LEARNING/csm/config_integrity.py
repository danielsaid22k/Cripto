from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from dotenv import dotenv_values
from .config import PERSISTENT_ENV_FILE, STATE_DIR


SECRET_WORDS = (
    "TOKEN",
    "SECRET",
    "PASSWORD",
    "PRIVATE_KEY",
    "API_KEY",
)

CRITICAL = {
    "TELEGRAM_BOT_TOKEN",
    "ADMIN_WEB_TOKEN",
    "ASAAS_API_KEY",
    "ASAAS_ENABLED",
    "BIRDEYE_API_KEY",
    "BIRDEYE_ENABLED",
    "COINGECKO_API_KEY",
    "GOPLUS_API_KEY",
    "GOPLUS_ENABLED",
    "HELIUS_API_KEY",
    "SCAN_CHAINS",
    "SCANNER_CHAINS",
    "ENABLED_CHAINS",
    "AUTO_SIGNALS_ENABLED",
    "SCANNER_ENABLED",
}


def now():
    return datetime.now(timezone.utc).isoformat()


def is_secret(key):
    key = str(key).upper()
    return any(word in key for word in SECRET_WORDS)


def fingerprint(value):
    return "sha256:" + hashlib.sha256(
        str(value).encode()
    ).hexdigest()[:12]


class ConfigIntegrityGuard:
    def __init__(self, env_file=None, state_dir=None):
        self.env_file = Path(
            env_file or PERSISTENT_ENV_FILE
        )

        root = Path(state_dir or STATE_DIR)

        self.root = root / "config_integrity"
        self.root.mkdir(parents=True, exist_ok=True)

        self.baseline_file = (
            self.root / "healthy_baseline.json"
        )

        self.report_file = (
            self.root / "last_report.json"
        )

    def snapshot(self):
        values = {}

        if self.env_file.is_file():
            values = {
                str(k): str(v or "").strip()
                for k, v in dotenv_values(
                    self.env_file
                ).items()
                if k
            }

        keys = set(CRITICAL)

        keys.update(
            key
            for key in values
            if key.startswith("EVM_RPC_")
        )

        safe = {}

        for key in sorted(keys):
            value = values.get(key, "")

            if is_secret(key):
                safe[key] = {
                    "secret": True,
                    "present": bool(value),
                    "length": len(value),
                    "fingerprint": (
                        fingerprint(value)
                        if value
                        else None
                    ),
                }
            else:
                safe[key] = {
                    "secret": False,
                    "present": bool(value),
                    "value": value,
                }

        return {
            "generated_at": now(),
            "keys": safe,
        }

    def mark_healthy(self, reason="manual"):
        snap = self.snapshot()

        if self.baseline_file.exists():
            stamp = datetime.now().strftime(
                "%Y%m%d_%H%M%S"
            )

            shutil.copy2(
                self.baseline_file,
                self.baseline_file.with_name(
                    "healthy_baseline.json.bak_"
                    + stamp
                ),
            )

        snap["accepted_at"] = now()
        snap["accepted_reason"] = reason

        self.baseline_file.write_text(
            json.dumps(
                snap,
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )

        return snap

    def report(self, persist=True):
        current = self.snapshot()

        if not self.baseline_file.is_file():
            result = {
                "status": "NO_BASELINE",
                "healthy": False,
                "baseline_available": False,
                "changed_count": 0,
                "critical_missing_count": 0,
                "changes": [],
            }

            return result

        baseline = json.loads(
            self.baseline_file.read_text(
                encoding="utf-8"
            )
        )

        before = baseline.get("keys") or {}
        after = current.get("keys") or {}

        changes = []
        missing = 0

        for key in sorted(set(before) | set(after)):
            old = before.get(key) or {}
            new = after.get(key) or {}

            if old == new:
                continue

            old_present = bool(old.get("present"))
            new_present = bool(new.get("present"))

            if old_present and not new_present:
                kind = "REMOVED"
                missing += 1
            elif not old_present and new_present:
                kind = "ADDED"
            else:
                kind = "CHANGED"

            changes.append({
                "key": key,
                "kind": kind,
                "secret": bool(
                    old.get("secret")
                    or new.get("secret")
                ),
            })

        if missing:
            status = "ATENCAO"
        elif changes:
            status = "ALTERADA"
        else:
            status = "OK"

        result = {
            "generated_at": now(),
            "status": status,
            "healthy": status == "OK",
            "baseline_available": True,
            "changed_count": len(changes),
            "critical_missing_count": missing,
            "changes": changes,
            "methodology": (
                "Segredos nunca são expostos; "
                "somente presença e fingerprint."
            ),
        }

        if persist:
            self.report_file.write_text(
                json.dumps(
                    result,
                    ensure_ascii=False,
                    indent=2,
                ) + "\n",
                encoding="utf-8",
            )

        return result

    def preflight(self, action):
        report = self.report()

        return {
            "allowed": (
                report.get(
                    "critical_missing_count", 0
                ) == 0
            ),
            "action": action,
            "status": report.get("status"),
            "changed_count": report.get(
                "changed_count", 0
            ),
            "critical_missing_count": report.get(
                "critical_missing_count", 0
            ),
        }
