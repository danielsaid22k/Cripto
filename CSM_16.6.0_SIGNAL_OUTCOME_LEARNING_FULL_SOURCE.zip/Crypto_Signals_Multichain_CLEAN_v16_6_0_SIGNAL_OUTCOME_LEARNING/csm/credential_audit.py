from __future__ import annotations

"""Credential provenance and stale-copy protection.

The commercial ZIP never ships operator secrets. Runtime credentials live in
persistent state and, for legacy compatibility, may also exist in local .env
files or historical backups. This module makes that provenance auditable
without ever printing secret values.
"""

import hashlib
import json
import zipfile
from dataclasses import dataclass, asdict
from io import StringIO
from pathlib import Path
from typing import Any

from dotenv import dotenv_values

MARKER_FILE = "credential_meta.json"
BIRDEYE_VARIABLE = "BIRDEYE_API_KEY"


def secret_fingerprint(value: str) -> str:
    value = str(value or "").strip()
    if not value:
        return ""
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]


def _read_env_value(path: Path, variable: str) -> str:
    try:
        values = dotenv_values(path)
    except Exception:
        return ""
    return str(values.get(variable) or "").strip()


def _read_env_text_value(text: str, variable: str) -> str:
    try:
        values = dotenv_values(stream=StringIO(text))
    except Exception:
        return ""
    return str(values.get(variable) or "").strip()


def marker_path(state_dir: Path) -> Path:
    return Path(state_dir) / MARKER_FILE


def read_credential_marker(state_dir: Path) -> dict[str, Any]:
    path = marker_path(state_dir)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def update_credential_marker(variable: str, value: str, state_dir: Path) -> Path:
    """Record the intended credential generation without storing the secret."""
    path = marker_path(state_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = read_credential_marker(state_dir)
    payload.setdefault("version", 1)
    credentials = payload.setdefault("credentials", {})
    normalized = str(value or "").strip()
    credentials[str(variable)] = {
        "state": "set" if normalized else "cleared",
        "fingerprint": secret_fingerprint(normalized),
    }
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temp.replace(path)
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return path


def recovery_secret_allowed(variable: str, value: str, state_dir: Path) -> tuple[bool, str]:
    """Prevent a rotated/cleared provider key from being resurrected by backup recovery."""
    if str(variable) != BIRDEYE_VARIABLE:
        return True, "not-governed"
    marker = read_credential_marker(state_dir)
    entry = (marker.get("credentials") or {}).get(BIRDEYE_VARIABLE) or {}
    state = str(entry.get("state") or "").strip().lower()
    expected = str(entry.get("fingerprint") or "").strip()
    if not state:
        return True, "no-marker"
    if state == "cleared":
        return False, "credential-explicitly-cleared"
    actual = secret_fingerprint(value)
    if expected and actual != expected:
        return False, "backup-fingerprint-does-not-match-current-generation"
    return True, "marker-match"


@dataclass(frozen=True)
class CredentialCopy:
    location: str
    kind: str
    fingerprint: str
    length: int
    active_match: bool
    historical: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _backup_rows(paths: list[Path], active_fp: str) -> list[CredentialCopy]:
    rows: list[CredentialCopy] = []
    seen: set[Path] = set()
    for path in paths:
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if resolved in seen or not resolved.is_file():
            continue
        seen.add(resolved)
        try:
            with zipfile.ZipFile(resolved, "r") as archive:
                if "state/config.env" not in archive.namelist():
                    continue
                text = archive.read("state/config.env").decode("utf-8", errors="replace")
        except Exception:
            continue
        value = _read_env_text_value(text, BIRDEYE_VARIABLE)
        if not value:
            continue
        fp = secret_fingerprint(value)
        rows.append(CredentialCopy(
            location=str(resolved),
            kind="backup-with-secrets",
            fingerprint=fp,
            length=len(value),
            active_match=bool(active_fp and fp == active_fp),
            historical=True,
        ))
    return rows


def audit_birdeye_credentials(*, base_dir: Path | None = None, state_dir: Path | None = None,
                               runtime_value: str | None = None) -> dict[str, Any]:
    """Inventory Birdeye credential copies without returning any credential value."""
    if base_dir is None or state_dir is None or runtime_value is None:
        from csm.config import settings
        base_dir = Path(base_dir or settings.base_dir)
        state_dir = Path(state_dir or settings.data_dir)
        if runtime_value is None:
            runtime_value = str(settings.birdeye_api_key or "")
    base_dir = Path(base_dir)
    state_dir = Path(state_dir)
    runtime_value = str(runtime_value or "").strip()
    active_fp = secret_fingerprint(runtime_value)

    persistent = state_dir / "config.env"
    local = base_dir / ".env"
    env_candidates: list[tuple[Path, str, bool]] = [
        (persistent, "persistent-config", False),
        (local, "current-release-env", False),
    ]
    try:
        siblings = sorted(base_dir.parent.glob("Crypto_Signals_Multichain_CLEAN_v*/.env"))
        for item in siblings:
            if item.resolve() != local.resolve():
                env_candidates.append((item, "legacy-release-env", True))
    except OSError:
        pass
    env_candidates.extend([
        (base_dir.parent / "crypto_signals.env.backup", "legacy-env-backup", True),
        (Path.home() / "Documents" / "crypto_signals.env.backup", "legacy-env-backup", True),
    ])

    rows: list[CredentialCopy] = []
    seen_files: set[Path] = set()
    for path, kind, historical in env_candidates:
        try:
            resolved = path.expanduser().resolve()
        except OSError:
            continue
        if resolved in seen_files or not resolved.is_file():
            continue
        seen_files.add(resolved)
        value = _read_env_value(resolved, BIRDEYE_VARIABLE)
        if not value:
            continue
        fp = secret_fingerprint(value)
        rows.append(CredentialCopy(
            location=str(resolved),
            kind=kind,
            fingerprint=fp,
            length=len(value),
            active_match=bool(active_fp and fp == active_fp),
            historical=historical,
        ))

    backup_candidates: list[Path] = []
    for directory in (state_dir / "backups", base_dir / "backups"):
        try:
            backup_candidates.extend(sorted(directory.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)[:30])
        except OSError:
            pass
    rows.extend(_backup_rows(backup_candidates, active_fp))

    source = "runtime/environment"
    persistent_fp = secret_fingerprint(_read_env_value(persistent, BIRDEYE_VARIABLE))
    local_fp = secret_fingerprint(_read_env_value(local, BIRDEYE_VARIABLE))
    if active_fp and persistent_fp == active_fp:
        source = str(persistent)
    elif active_fp and local_fp == active_fp:
        source = str(local)
    elif not active_fp:
        source = "nenhuma"

    marker = read_credential_marker(state_dir)
    marker_entry = (marker.get("credentials") or {}).get(BIRDEYE_VARIABLE) or {}
    stale = [row for row in rows if active_fp and row.fingerprint != active_fp]
    matching = [row for row in rows if active_fp and row.fingerprint == active_fp]

    return {
        "variable": BIRDEYE_VARIABLE,
        "key_present": bool(runtime_value),
        "key_length": len(runtime_value),
        "active_fingerprint": active_fp,
        "active_source": source,
        "copies": [row.to_dict() for row in rows],
        "matching_copies": len(matching),
        "stale_copies": len(stale),
        "marker_state": str(marker_entry.get("state") or "untracked"),
        "marker_fingerprint": str(marker_entry.get("fingerprint") or ""),
        "persistent_path": str(persistent),
        "local_path": str(local),
    }
