from __future__ import annotations

import json
import subprocess
import time
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import urlencode

from .ashell_runtime_v831 import curl_binary
from .config import settings
from .http_client import HTTPJSONError, HTTPTransientError, SafeHTTP


class CurlUnavailableError(HTTPTransientError):
    pass


@dataclass(frozen=True)
class CurlResponse:
    status: int
    payload: Any
    elapsed_ms: float


class CurlJSONV831:
    """HTTP JSON para a-Shell sem abrir outro interpretador Python.

    A camada de mercado/providers usa o executável ``curl`` do a-Shell. Cada
    processo é curto, aguardado e recolhido por ``subprocess.run``. Isso evita
    criar workers Python adicionais, que estavam provocando o alerta
    "Too many Python scripts" no iOS.
    """

    def __init__(
        self,
        timeout: int | float | None = None,
        *,
        connect_timeout: int | float = 2.0,
        runner: Callable[..., subprocess.CompletedProcess] | None = None,
        binary: str | None = None,
    ) -> None:
        # Em UI/mobile preferimos falhar rápido e deixar fallback/cache assumir.
        configured = float(timeout or getattr(settings, "request_timeout", 15) or 15)
        self.timeout = max(1.0, min(configured, float(getattr(settings, "mobile_market_timeout", 4) or 4)))
        self.connect_timeout = max(1.0, min(float(connect_timeout), self.timeout))
        self.runner = runner or subprocess.run
        self.binary = binary or curl_binary()
        self.headers = {
            "Accept": "application/json",
            "User-Agent": "PhantomAlert/8.3.1-aShell",
        }

    @staticmethod
    def _decode(text: str) -> Any:
        raw = (text or "").strip()
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise HTTPTransientError("Provider retornou resposta não JSON.") from exc

    def _command(self, method: str, url: str, *, params=None, data=None, json_data=None, timeout=None) -> list[str]:
        if not self.binary:
            raise CurlUnavailableError("curl não está disponível no a-Shell.")
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params, doseq=True)
        effective_timeout = max(1.0, min(float(timeout or self.timeout), 10.0))
        cmd = [
            self.binary,
            "--silent",
            "--show-error",
            "--location",
            "--connect-timeout", str(self.connect_timeout),
            "--max-time", str(effective_timeout),
            "--request", method.upper(),
        ]
        for key, value in self.headers.items():
            cmd += ["--header", f"{key}: {value}"]
        body: str | None = None
        if json_data is not None:
            body = json.dumps(json_data, ensure_ascii=False)
            cmd += ["--header", "Content-Type: application/json"]
        elif data is not None:
            body = urlencode(data, doseq=True)
            cmd += ["--header", "Content-Type: application/x-www-form-urlencoded"]
        if body is not None:
            cmd += ["--data", body]
        # Status é anexado em linha própria para distinguir 4xx/5xx de payload.
        cmd += ["--write-out", "\\n__PHANTOM_HTTP_STATUS__:%{http_code}", url]
        return cmd

    def request_json(self, method: str, url: str, *, params=None, data=None, json_data=None, timeout=None) -> Any:
        cmd = self._command(method, url, params=params, data=data, json_data=json_data, timeout=timeout)
        started = time.monotonic()
        try:
            completed = self.runner(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=max(2.0, min(float(timeout or self.timeout) + 1.0, 12.0)),
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise HTTPTransientError("Timeout externo de mercado no a-Shell.") from exc
        except OSError as exc:
            raise CurlUnavailableError(f"Não foi possível executar curl: {exc}") from exc

        output = completed.stdout or ""
        marker = "\n__PHANTOM_HTTP_STATUS__:"
        if marker in output:
            body, status_text = output.rsplit(marker, 1)
            try:
                status = int(status_text.strip().splitlines()[0])
            except Exception:
                status = 0
        else:
            body, status = output, 0

        if completed.returncode != 0:
            message = (completed.stderr or "").strip()[:300]
            raise HTTPTransientError(f"curl falhou ({completed.returncode}): {message or 'rede indisponível'}")

        payload = self._decode(body)
        if status in (429, 500, 502, 503, 504) or status == 0:
            raise HTTPTransientError(f"Provider temporariamente indisponível (HTTP {status or 'desconhecido'}).")
        if status >= 400:
            raise HTTPJSONError(status, payload, url)
        return payload

    def get_json(self, url: str, params=None):
        return self.request_json("GET", url, params=params)


class MarketHTTPV831:
    """Seleciona curl no a-Shell e SafeHTTP fora do iOS."""

    def __init__(self, *, mobile: bool, timeout: int | None = None):
        self.mobile = bool(mobile)
        self.impl = CurlJSONV831(timeout=timeout) if self.mobile else SafeHTTP(timeout)

    def get_json(self, url: str, params=None):
        return self.impl.get_json(url, params=params)
