from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from .config import settings


ALIAS_NAME = "CSM_CURRENT"


def alias_path() -> Path:
    return Path.home() / ALIAS_NAME


def ensure_current_alias(target: Path | None = None) -> dict[str, Any]:
    """Create/update ~/CSM_CURRENT without renaming the installed project.

    Termux keeps the symlink in its private HOME and the target can remain on
    shared storage. Existing real directories are never overwritten.
    """
    target = Path(target or settings.base_dir).expanduser().resolve()
    alias = alias_path()
    if os.name != "posix":
        return {"ok": True, "skipped": True, "reason": "non_posix", "alias": str(alias), "target": str(target)}
    if not target.is_dir():
        return {"ok": False, "error": "target_not_directory", "alias": str(alias), "target": str(target)}
    try:
        if alias.is_symlink():
            current = alias.resolve(strict=False)
            if current == target:
                return {"ok": True, "changed": False, "alias": str(alias), "target": str(target)}
            alias.unlink()
        elif alias.exists():
            return {"ok": False, "error": "alias_path_exists_and_is_not_symlink", "alias": str(alias), "target": str(target)}
        alias.symlink_to(target, target_is_directory=True)
        return {"ok": True, "changed": True, "alias": str(alias), "target": str(target)}
    except OSError as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "alias": str(alias), "target": str(target)}
