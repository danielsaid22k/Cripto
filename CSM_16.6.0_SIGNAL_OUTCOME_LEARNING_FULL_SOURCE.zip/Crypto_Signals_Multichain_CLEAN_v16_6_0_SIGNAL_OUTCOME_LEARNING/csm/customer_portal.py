from __future__ import annotations

import html


def portal_page(product_name: str, version: str, logo_emoji: str = "🌐") -> bytes:
    """Return a dependency-free customer portal shell.

    The API key is kept only in browser sessionStorage and is sent as an
    Authorization header to the same-origin SaaS API. It is never placed in the
    URL, HTML, cookies or server logs.
    """
    product = html.escape(str(product_name or "Crypto Signals Multichain"))
    logo = html.escape(str(logo_emoji or "🌐"))
    ver = html.escape(str(version or ""))
    doc = f"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{product} • Portal</title>
<style>
:root{{--bg:#09111f;--panel:#111d31;--line:#243a5d;--text:#edf5ff;--muted:#a9bbd0;--ok:#69e6a6;--warn:#ffd166;--bad:#ff7a90;--accent:#79b8ff}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}
header{{padding:22px 18px;border-bottom:1px solid var(--line);background:#0d1728;position:sticky;top:0;z-index:3}}
.wrap{{max-width:1120px;margin:auto}}h1{{font-size:21px;margin:0}}.sub{{color:var(--muted);font-size:13px;margin-top:5px}}
main{{padding:18px}}.login{{max-width:560px;margin:44px auto;background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:20px}}
input{{width:100%;padding:13px;border-radius:11px;border:1px solid var(--line);background:#081321;color:var(--text);font-size:15px}}
button{{padding:11px 15px;border-radius:11px;border:1px solid var(--line);background:#17345a;color:white;font-weight:700;cursor:pointer;margin-top:10px}}
button.secondary{{background:transparent;color:var(--muted);margin-left:8px}}.error{{color:var(--bad);margin-top:10px;white-space:pre-wrap}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:14px 0}}.card{{background:var(--panel);border:1px solid var(--line);border-radius:15px;padding:15px}}
.label{{font-size:12px;color:var(--muted)}}.value{{font-size:24px;font-weight:800;margin-top:5px}}.small{{font-size:13px;color:var(--muted)}}
section{{margin:22px 0}}table{{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--line);border-radius:14px;overflow:hidden}}
th,td{{padding:10px;border-bottom:1px solid var(--line);text-align:left;font-size:13px}}th{{color:var(--muted)}}code{{color:#a9d5ff}}.pill{{display:inline-block;padding:4px 8px;border-radius:999px;background:#17345a;font-size:12px}}
.ok{{color:var(--ok)}}.warn{{color:var(--warn)}}.hidden{{display:none}}.toolbar{{display:flex;gap:8px;flex-wrap:wrap;align-items:center}}
@media(max-width:600px){{th:nth-child(3),td:nth-child(3){{display:none}}}}
</style></head><body>
<header><div class="wrap"><h1>{logo} {product} • Customer Portal</h1><div class="sub">V16 • {ver} • API key nunca é colocada na URL</div></div></header>
<main class="wrap">
<div id="login" class="login"><h2>Acessar portal</h2><p class="small">Use a API key do seu tenant. Ela fica somente nesta sessão do navegador.</p>
<input id="key" type="password" autocomplete="off" placeholder="csm_live_..."><div><button id="enter">Entrar</button></div><div id="loginError" class="error"></div></div>
<div id="app" class="hidden">
<div class="toolbar"><span id="tenant" class="pill"></span><span id="plan" class="pill"></span><span id="status" class="pill"></span><button class="secondary" id="refresh">Atualizar</button><button class="secondary" id="logout">Sair</button></div>
<div class="grid">
<div class="card"><div class="label">Sinais disponíveis</div><div class="value" id="signalsCount">—</div></div>
<div class="card"><div class="label">Requests hoje</div><div class="value" id="usageToday">—</div></div>
<div class="card"><div class="label">Limite diário</div><div class="value" id="dailyLimit">—</div></div>
<div class="card"><div class="label">Performance observada</div><div class="value" id="observed">—</div></div>
<div class="card"><div class="label">Win rate</div><div class="value" id="winRate">—</div></div>
<div class="card"><div class="label">Proof live</div><div class="value" id="proofLive">—</div></div>
</div>
<section><h2>Assinatura & acesso</h2><div id="subscription" class="card small"></div></section>
<section><h2>Últimos sinais</h2><div style="overflow:auto"><table><thead><tr><th>Ativo</th><th>Rede</th><th>Score</th><th>Retorno</th><th>Data</th></tr></thead><tbody id="signals"></tbody></table></div></section>
<section><h2>Recursos liberados</h2><div id="features" class="card small"></div></section>
<section id="enterpriseSection" class="hidden"><h2>Enterprise</h2><div id="enterprise" class="card small"></div></section>
<div id="appError" class="error"></div>
</div></main>
<script>
const $=id=>document.getElementById(id); const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c]));
function key(){{return sessionStorage.getItem('csm_api_key')||''}}
async function api(path){{const r=await fetch(path,{{headers:{{'Authorization':'Bearer '+key(),'Accept':'application/json'}},cache:'no-store'}});let j={{}};try{{j=await r.json()}}catch(e){{}}if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j}}
function render(o){{const me=o.me||{{}}, ent=me.entitlement||{{}}, usage=o.usage||{{}}, perf=o.performance||{{}}, proof=o.proof||{{}}, sig=o.signals||{{}};
$('tenant').textContent=me.tenant||'tenant'; $('plan').textContent=(ent.plan||'free').toUpperCase(); $('status').textContent=ent.status||'—';
$('signalsCount').textContent=sig.count??0; $('usageToday').textContent=usage.requests_today??0; $('dailyLimit').textContent=usage.daily_limit??'—';
$('observed').textContent=perf.signals_observed??'—'; $('winRate').textContent=perf.win_rate_pct==null?'—':perf.win_rate_pct+'%'; $('proofLive').textContent=proof.live_commits??'—';
const sub=o.subscription||{{}};$('subscription').innerHTML='<b>Plano:</b> '+esc(ent.plan||'free')+' &nbsp; <b>Status:</b> '+esc(ent.status||'—')+'<br><b>Expira:</b> '+esc(ent.expires_at||sub.expires_at||'sem data')+'<br><b>Fonte:</b> '+esc(sub.source||'tenant-entitlement');
$('features').textContent=(ent.features||[]).join(' • ')||'portal';
const rows=(sig.items||[]).map(x=>'<tr><td>'+esc(x.symbol||x.name||'?')+'</td><td>'+esc(x.chain||'?')+'</td><td>'+esc(x.final_score??'—')+'</td><td>'+esc(x.last_return_pct==null?'—':Number(x.last_return_pct).toFixed(2)+'%')+'</td><td>'+esc(x.created_at||'')+'</td></tr>').join(''); $('signals').innerHTML=rows||'<tr><td colspan="5">Nenhum sinal disponível ainda</td></tr>';
if(o.enterprise){{$('enterpriseSection').classList.remove('hidden'); $('enterprise').textContent='Health '+(o.enterprise.health_score??'—')+'/100 • destinos '+(o.enterprise.distribution_destinations??0)+' • incidentes '+(o.enterprise.open_incidents??0)}} else $('enterpriseSection').classList.add('hidden');
}}
async function load(){{$('appError').textContent='';try{{const o=await api('/api/v1/portal/overview');render(o);$('login').classList.add('hidden');$('app').classList.remove('hidden')}}catch(e){{$('appError').textContent=e.message;throw e}}}}
$('enter').onclick=async()=>{{$('loginError').textContent='';const v=$('key').value.trim();if(!v)return;$('key').value='';sessionStorage.setItem('csm_api_key',v);try{{await load()}}catch(e){{sessionStorage.removeItem('csm_api_key');$('login').classList.remove('hidden');$('app').classList.add('hidden');$('loginError').textContent=e.message}}}};
$('refresh').onclick=()=>load().catch(()=>{{}}); $('logout').onclick=()=>{{sessionStorage.removeItem('csm_api_key');location.reload()}};
if(key()) load().catch(()=>{{sessionStorage.removeItem('csm_api_key');$('login').classList.remove('hidden');$('app').classList.add('hidden')}});
</script></body></html>"""
    return doc.encode("utf-8")
