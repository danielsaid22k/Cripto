from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import smtplib
import ssl
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .config import settings

DISTRIBUTION_SCHEMA_VERSION = 1
CHANNELS = {"webhook", "discord", "email"}
EVENT_SIGNAL = "signal.created"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _csv(value: str | list[str] | tuple[str, ...] | None) -> list[str]:
    if isinstance(value, (list, tuple)):
        raw = value
    else:
        raw = str(value or "").split(",")
    return [str(x).strip().lower() for x in raw if str(x).strip()]


def _safe_name(value: Any, limit: int = 80) -> str:
    text = re.sub(r"[^a-zA-Z0-9 _.-]+", "", str(value or "").strip())
    return text[:limit] or "destination"


def _target_hint(channel: str, target: str) -> str:
    if channel in {"webhook", "discord"}:
        try:
            parsed = urlsplit(target)
            return parsed.hostname or "https-endpoint"
        except Exception:
            return "https-endpoint"
    if "@" in target:
        left, _, domain = target.partition("@")
        return (left[:2] + "***@" + domain)[:120]
    return "email"


def _canonical_json(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _safe_error(value: Any) -> str:
    text = str(value or "")
    text = re.sub(r"https?://[^\s]+", "[url]", text, flags=re.I)
    text = re.sub(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", "[email]", text, flags=re.I)
    text = re.sub(r"(?i)(token|secret|password|api[_-]?key)[=: ]+[^\s,;]+", r"\1=[redacted]", text)
    return text[:240]


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS distribution_destinations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_slug TEXT NOT NULL DEFAULT 'crypto-signals',
            channel TEXT NOT NULL,
            name TEXT NOT NULL,
            target_hint TEXT NOT NULL DEFAULT '',
            config_ref TEXT NOT NULL,
            plans_csv TEXT NOT NULL DEFAULT 'free,plus,premium',
            events_csv TEXT NOT NULL DEFAULT 'signal.created',
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_distribution_destinations_enabled
        ON distribution_destinations(enabled, channel);

        CREATE TABLE IF NOT EXISTS distribution_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destination_id INTEGER NOT NULL,
            event_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            idempotency_key TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING',
            attempt_count INTEGER NOT NULL DEFAULT 0,
            next_attempt_at TEXT NOT NULL,
            last_error TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at TEXT,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(destination_id, idempotency_key)
        );
        CREATE INDEX IF NOT EXISTS idx_distribution_jobs_due
        ON distribution_jobs(status, next_attempt_at, id);

        CREATE TABLE IF NOT EXISTS distribution_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            destination_id INTEGER NOT NULL,
            channel TEXT NOT NULL,
            status TEXT NOT NULL,
            http_status INTEGER,
            elapsed_ms REAL NOT NULL DEFAULT 0,
            error_class TEXT NOT NULL DEFAULT '',
            error_message TEXT NOT NULL DEFAULT '',
            attempted_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_distribution_attempts_job
        ON distribution_attempts(job_id, attempted_at DESC);

        CREATE TRIGGER IF NOT EXISTS distribution_attempts_no_update
        BEFORE UPDATE ON distribution_attempts
        BEGIN SELECT RAISE(ABORT, 'distribution_attempts are append-only'); END;
        CREATE TRIGGER IF NOT EXISTS distribution_attempts_no_delete
        BEFORE DELETE ON distribution_attempts
        BEGIN SELECT RAISE(ABORT, 'distribution_attempts are append-only'); END;
        """
    )
    conn.commit()


@dataclass(frozen=True)
class DeliveryResult:
    ok: bool
    status: int | None
    elapsed_ms: float
    error: str = ""


class DistributionManager:
    """V15 outbound-only multi-channel distribution.

    No inbound webhook/listener is created. Telegram remains authoritative for
    signal approval/delivery. This layer receives a sanitized event only after
    Telegram confirms delivery, persists one idempotent job per destination,
    and sends at most one network delivery per cooperative scheduler step.
    """

    def __init__(self, storage, transport=None, observability=None):
        self.storage = storage
        self.conn = storage.conn
        self.transport = transport
        self.observability = observability
        ensure_schema(self.conn)
        self.secret_dir = storage.path.parent / "secrets" / "distribution"
        self.secret_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.secret_dir, 0o700)
        except OSError:
            pass

    def _config_path(self, destination_id: int) -> Path:
        return self.secret_dir / f"destination_{int(destination_id)}.json"

    def _write_config(self, destination_id: int, payload: dict[str, Any]) -> str:
        path = self._config_path(destination_id)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(_canonical_json(payload), encoding="utf-8")
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return str(path.relative_to(self.storage.path.parent))

    def _read_config(self, ref: str) -> dict[str, Any]:
        base = self.storage.path.parent.resolve()
        path = (base / str(ref)).resolve()
        if base not in path.parents or not path.is_file():
            raise RuntimeError("configuração privada do destino não encontrada")
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise RuntimeError("configuração privada inválida")
        return data

    def add_destination(
        self,
        *,
        channel: str,
        name: str,
        target: str,
        tenant_slug: str = "crypto-signals",
        plans: str = "free,plus,premium",
        events: str = EVENT_SIGNAL,
        signing_secret: str = "",
    ) -> dict[str, Any]:
        channel = str(channel or "").strip().lower()
        if channel not in CHANNELS:
            raise ValueError("channel deve ser webhook, discord ou email")
        target = str(target or "").strip()
        if channel in {"webhook", "discord"}:
            parsed = urlsplit(target)
            if parsed.scheme != "https" or not parsed.hostname:
                raise ValueError("webhook/Discord exige URL HTTPS válida")
        elif "@" not in target or target.startswith("@") or target.endswith("@"):
            raise ValueError("e-mail de destino inválido")

        clean_plans = _csv(plans) or ["free", "plus", "premium"]
        invalid_plans = sorted(set(clean_plans) - {"free", "plus", "premium", "*"})
        if invalid_plans:
            raise ValueError("planos inválidos: " + ", ".join(invalid_plans))
        clean_events = _csv(events) or [EVENT_SIGNAL]
        secret = ""
        if channel == "webhook":
            secret = str(signing_secret or "").strip() or secrets.token_urlsafe(32)

        cur = self.conn.execute(
            """INSERT INTO distribution_destinations
               (tenant_slug,channel,name,target_hint,config_ref,plans_csv,events_csv,enabled)
               VALUES(?,?,?,?,?,?,?,1)""",
            (
                str(tenant_slug or "crypto-signals").strip().lower()[:80],
                channel,
                _safe_name(name),
                _target_hint(channel, target),
                "pending",
                ",".join(clean_plans),
                ",".join(clean_events),
            ),
        )
        destination_id = int(cur.lastrowid)
        ref = self._write_config(destination_id, {"target": target, "signing_secret": secret})
        self.conn.execute(
            "UPDATE distribution_destinations SET config_ref=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (ref, destination_id),
        )
        self.conn.commit()
        row = dict(self.conn.execute("SELECT * FROM distribution_destinations WHERE id=?", (destination_id,)).fetchone())
        row["signing_secret"] = secret if channel == "webhook" else ""
        return row

    def list_destinations(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM distribution_destinations ORDER BY enabled DESC,id ASC"
        ).fetchall()
        return [dict(row) for row in rows]

    def set_enabled(self, destination_id: int, enabled: bool) -> bool:
        cur = self.conn.execute(
            "UPDATE distribution_destinations SET enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (1 if enabled else 0, int(destination_id)),
        )
        self.conn.commit()
        return cur.rowcount > 0

    @staticmethod
    def signal_payload(item: dict[str, Any], plan: str, proof_fields: dict[str, Any] | None = None) -> dict[str, Any]:
        allow = (
            "chain", "address", "symbol", "name", "price", "liquidity", "volume24h", "marketcap", "fdv",
            "change24h", "final_score", "opportunity_score", "goplus_security_score", "goplus_risk",
            "onchain_score", "reputation_score", "reputation_confidence", "url",
        )
        signal = {key: item.get(key) for key in allow if item.get(key) is not None}
        proof = {k: v for k, v in (proof_fields or {}).items() if k in {"proof_id", "proof_hash", "proof_commit_mode"} and v}
        return {
            "schema": "csm.distribution.signal.v1",
            "event": EVENT_SIGNAL,
            "occurred_at": _iso(),
            "plan": str(plan or "").strip().lower(),
            "signal": signal,
            "proof": proof,
        }

    def enqueue_signal(self, item: dict[str, Any], plan: str, proof_fields: dict[str, Any] | None = None) -> int:
        if not settings.distribution_enabled:
            return 0
        payload = self.signal_payload(item, plan, proof_fields)
        proof_key = str((proof_fields or {}).get("proof_hash") or "")
        chain = str(item.get("chain") or "").strip().lower()
        address = str(item.get("address") or "").strip().lower()
        plan = str(plan or "").strip().lower()
        raw_key = f"{EVENT_SIGNAL}|{chain}|{address}|{plan}|{proof_key}"
        idem = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()
        event_id = "evt_" + idem[:24]
        payload["event_id"] = event_id
        payload_json = _canonical_json(payload)
        queued = 0
        for row in self.conn.execute("SELECT * FROM distribution_destinations WHERE enabled=1 ORDER BY id").fetchall():
            dest = dict(row)
            plans = set(_csv(dest.get("plans_csv")))
            events = set(_csv(dest.get("events_csv")))
            if "*" not in plans and plan not in plans:
                continue
            if "*" not in events and EVENT_SIGNAL not in events:
                continue
            cur = self.conn.execute(
                """INSERT OR IGNORE INTO distribution_jobs
                   (destination_id,event_id,event_type,idempotency_key,payload_json,status,next_attempt_at)
                   VALUES(?,?,?,?,?,'PENDING',?)""",
                (dest["id"], event_id, EVENT_SIGNAL, idem, payload_json, _iso()),
            )
            queued += int(cur.rowcount > 0)
        self.conn.commit()
        return queued

    def _due_job(self) -> dict[str, Any] | None:
        row = self.conn.execute(
            """SELECT j.*,d.channel,d.name,d.target_hint,d.config_ref
               FROM distribution_jobs j JOIN distribution_destinations d ON d.id=j.destination_id
               WHERE d.enabled=1 AND j.status IN ('PENDING','RETRY') AND j.next_attempt_at<=?
               ORDER BY j.next_attempt_at,j.id LIMIT 1""",
            (_iso(),),
        ).fetchone()
        return dict(row) if row else None

    @staticmethod
    def _retry_delay(attempt: int) -> int:
        schedule = (30, 120, 600, 1800, 3600)
        return schedule[min(max(0, int(attempt) - 1), len(schedule) - 1)]

    def _send_webhook(self, job: dict[str, Any], cfg: dict[str, Any]) -> DeliveryResult:
        if self.transport is None:
            raise RuntimeError("transport HTTPS não configurado")
        target = str(cfg.get("target") or "")
        body = json.loads(job["payload_json"])
        timestamp = str(int(time.time()))
        secret = str(cfg.get("signing_secret") or "")
        signature = hmac.new(secret.encode("utf-8"), (timestamp + "." + job["payload_json"]).encode("utf-8"), hashlib.sha256).hexdigest()
        transport = self.transport.clone(
            label=f"distribution-webhook-{job['destination_id']}", timeout=settings.distribution_timeout_seconds,
            headers={
                "X-CSM-Event": str(job["event_type"]),
                "X-CSM-Delivery": str(job["event_id"]),
                "X-CSM-Timestamp": timestamp,
                "X-CSM-Signature": "v1=" + signature,
                "Idempotency-Key": str(job["idempotency_key"]),
            },
        )
        started = time.monotonic()
        result = transport.request_json("POST", target, json_data=body, timeout=settings.distribution_timeout_seconds)
        ok = 200 <= int(result.status) < 300
        return DeliveryResult(ok, int(result.status), (time.monotonic() - started) * 1000.0, "" if ok else f"HTTP {result.status}")

    @staticmethod
    def _discord_content(payload: dict[str, Any]) -> str:
        sig = payload.get("signal") or {}
        proof = payload.get("proof") or {}
        symbol = str(sig.get("symbol") or "TOKEN")[:24]
        chain = str(sig.get("chain") or "?").upper()
        score = sig.get("final_score") or sig.get("opportunity_score") or "?"
        price = sig.get("price")
        lines = [f"🚀 **CSM SIGNAL • {payload.get('plan','').upper()}**", f"**{symbol}** • {chain} • score {score}/100"]
        if price:
            lines.append(f"Preço: `{price}`")
        lines.append(f"Contrato: `{str(sig.get('address') or '')[:120]}`")
        if proof.get("proof_hash"):
            lines.append(f"🔐 Proof: `{str(proof['proof_hash'])[:20]}…`")
        url = str(sig.get("url") or "")
        if url.startswith("https://"):
            lines.append(url)
        return "\n".join(lines)[:1900]

    def _send_discord(self, job: dict[str, Any], cfg: dict[str, Any]) -> DeliveryResult:
        if self.transport is None:
            raise RuntimeError("transport HTTPS não configurado")
        payload = json.loads(job["payload_json"])
        transport = self.transport.clone(label=f"distribution-discord-{job['destination_id']}", timeout=settings.distribution_timeout_seconds)
        started = time.monotonic()
        result = transport.request_json(
            "POST", str(cfg.get("target") or ""),
            json_data={"content": self._discord_content(payload), "allowed_mentions": {"parse": []}},
            timeout=settings.distribution_timeout_seconds,
        )
        ok = 200 <= int(result.status) < 300
        return DeliveryResult(ok, int(result.status), (time.monotonic() - started) * 1000.0, "" if ok else f"HTTP {result.status}")

    def _send_email(self, job: dict[str, Any], cfg: dict[str, Any]) -> DeliveryResult:
        if not settings.smtp_host or not settings.smtp_from:
            raise RuntimeError("SMTP_HOST/SMTP_FROM não configurados")
        payload = json.loads(job["payload_json"])
        sig = payload.get("signal") or {}
        recipient = str(cfg.get("target") or "")
        message = EmailMessage()
        symbol = str(sig.get("symbol") or "TOKEN")[:40]
        message["Subject"] = f"CSM {payload.get('plan','').upper()} • {symbol} • {str(sig.get('chain') or '').upper()}"
        message["From"] = settings.smtp_from
        message["To"] = recipient
        message.set_content(
            "\n".join([
                "Crypto Signals Multichain — sinal automático",
                f"Plano: {payload.get('plan','')}",
                f"Token: {symbol}",
                f"Rede: {sig.get('chain','')}",
                f"Contrato: {sig.get('address','')}",
                f"Preço: {sig.get('price','')}",
                f"Score: {sig.get('final_score') or sig.get('opportunity_score') or ''}",
                f"Proof: {(payload.get('proof') or {}).get('proof_hash','')}",
                f"Gráfico: {sig.get('url','')}",
                "",
                "Mensagem automatizada. Não é recomendação financeira.",
            ])
        )
        started = time.monotonic()
        context = ssl.create_default_context()
        timeout = float(settings.distribution_timeout_seconds)
        previous_mask = None
        try:
            # Reuse the same a-Shell TLS Ctrl+C shield used by the HTTPS bus.
            from phantom_v10.transport import _block_sigint_during_tls
            previous_mask = _block_sigint_during_tls()
        except Exception:
            previous_mask = None
        server = None
        try:
            if settings.smtp_ssl:
                server = smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=timeout, context=context)
            else:
                server = smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=timeout)
            server.ehlo()
            if settings.smtp_starttls and not settings.smtp_ssl:
                server.starttls(context=context)
                server.ehlo()
            if settings.smtp_username:
                server.login(settings.smtp_username, settings.smtp_password)
            server.send_message(message)
        finally:
            if server is not None:
                try:
                    server.quit()
                except Exception:
                    try: server.close()
                    except Exception: pass
            try:
                from phantom_v10.transport import _restore_sigint_mask
                _restore_sigint_mask(previous_mask)
            except Exception:
                pass
        return DeliveryResult(True, None, (time.monotonic() - started) * 1000.0)

    def _attempt(self, job: dict[str, Any]) -> DeliveryResult:
        cfg = self._read_config(job["config_ref"])
        channel = str(job["channel"])
        if channel == "webhook":
            return self._send_webhook(job, cfg)
        if channel == "discord":
            return self._send_discord(job, cfg)
        if channel == "email":
            return self._send_email(job, cfg)
        raise RuntimeError("canal não suportado")

    def run_one(self) -> dict[str, Any] | None:
        if not settings.distribution_enabled:
            return None
        job = self._due_job()
        if not job:
            return None
        attempt = int(job.get("attempt_count") or 0) + 1
        started = time.monotonic()
        status_code = None
        error_class = ""
        error_message = ""
        try:
            result = self._attempt(job)
            ok = bool(result.ok)
            status_code = result.status
            elapsed = result.elapsed_ms
            error_message = result.error
        except Exception as exc:
            ok = False
            elapsed = (time.monotonic() - started) * 1000.0
            error_class = type(exc).__name__
            error_message = _safe_error(exc)

        self.conn.execute(
            """INSERT INTO distribution_attempts
               (job_id,destination_id,channel,status,http_status,elapsed_ms,error_class,error_message,attempted_at)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                job["id"], job["destination_id"], job["channel"], "SENT" if ok else "FAILED",
                status_code, round(float(elapsed), 2), error_class, error_message, _iso(),
            ),
        )
        max_attempts = max(1, int(settings.distribution_max_attempts))
        if ok:
            self.conn.execute(
                """UPDATE distribution_jobs SET status='SENT',attempt_count=?,last_error='',sent_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                (attempt, _iso(), job["id"]),
            )
            state = "SENT"
        elif attempt >= max_attempts:
            self.conn.execute(
                """UPDATE distribution_jobs SET status='DEAD',attempt_count=?,last_error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                (attempt, error_message or error_class, job["id"]),
            )
            state = "DEAD"
        else:
            retry_at = _utc_now() + timedelta(seconds=self._retry_delay(attempt))
            self.conn.execute(
                """UPDATE distribution_jobs SET status='RETRY',attempt_count=?,next_attempt_at=?,last_error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                (attempt, _iso(retry_at), error_message or error_class, job["id"]),
            )
            state = "RETRY"
        self.conn.commit()

        if self.observability is not None:
            try:
                self.observability.record_metric(
                    "distribution", "delivery", 1, unit="count", status="OK" if ok else "ERROR",
                    labels={"channel": job["channel"], "state": state, "destination": job["target_hint"]},
                )
                if state == "DEAD":
                    self.observability.record_loop_error(
                        "distribution_dead_letter", f"canal={job['channel']} destino={job['target_hint']} {error_message}", component="distribution"
                    )
            except Exception:
                pass
        return {
            "job_id": int(job["id"]), "destination_id": int(job["destination_id"]), "channel": job["channel"],
            "state": state, "attempt": attempt, "http_status": status_code, "elapsed_ms": round(float(elapsed), 2),
            "error": error_message,
        }

    def test_destination(self, destination_id: int) -> dict[str, Any]:
        row = self.conn.execute("SELECT * FROM distribution_destinations WHERE id=?", (int(destination_id),)).fetchone()
        if not row:
            raise ValueError("destino não encontrado")
        dest = dict(row)
        payload = {
            "schema": "csm.distribution.test.v1", "event": "distribution.test", "event_id": "evt_test_" + uuid.uuid4().hex[:16],
            "occurred_at": _iso(), "plan": "premium",
            "signal": {"symbol": "CSMTEST", "chain": "test", "address": "test-only", "final_score": 100},
            "proof": {},
        }
        job = {
            "id": 0, "destination_id": dest["id"], "channel": dest["channel"], "event_type": "distribution.test",
            "event_id": payload["event_id"], "idempotency_key": hashlib.sha256(payload["event_id"].encode()).hexdigest(),
            "payload_json": _canonical_json(payload), "config_ref": dest["config_ref"], "target_hint": dest["target_hint"],
        }
        result = self._attempt(job)
        return {"ok": result.ok, "status": result.status, "elapsed_ms": round(result.elapsed_ms, 2), "target_hint": dest["target_hint"], "channel": dest["channel"]}

    def retry_job(self, job_id: int) -> bool:
        cur = self.conn.execute(
            "UPDATE distribution_jobs SET status='PENDING',next_attempt_at=?,last_error='',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status IN ('DEAD','RETRY')",
            (_iso(), int(job_id)),
        )
        self.conn.commit()
        return cur.rowcount > 0

    def status(self, days: int = 7) -> dict[str, Any]:
        since = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        destinations = int(self.conn.execute("SELECT COUNT(*) FROM distribution_destinations WHERE enabled=1").fetchone()[0])
        rows = self.conn.execute(
            """SELECT status,COUNT(*) n FROM distribution_jobs WHERE created_at>=? GROUP BY status""", (since,)
        ).fetchall()
        counts = {str(r["status"]): int(r["n"]) for r in rows}
        channel_rows = self.conn.execute(
            """SELECT d.channel,COUNT(*) n FROM distribution_jobs j JOIN distribution_destinations d ON d.id=j.destination_id
               WHERE j.created_at>=? GROUP BY d.channel""", (since,)
        ).fetchall()
        return {
            "version": "16.4.0-smart-reentry", "days": max(1, int(days)), "enabled": bool(settings.distribution_enabled),
            "active_destinations": destinations, "jobs": counts, "by_channel": {r["channel"]: int(r["n"]) for r in channel_rows},
            "public_inbound_webhooks": False, "telegram_primary": True,
        }

    def jobs(self, limit: int = 50, status: str = "") -> list[dict[str, Any]]:
        params: list[Any] = []
        where = ""
        if status:
            where = "WHERE j.status=?"
            params.append(str(status).upper())
        params.append(max(1, min(int(limit), 500)))
        rows = self.conn.execute(
            f"""SELECT j.id,j.event_id,j.event_type,j.status,j.attempt_count,j.next_attempt_at,j.last_error,j.created_at,j.sent_at,
                       d.channel,d.name,d.target_hint
                FROM distribution_jobs j JOIN distribution_destinations d ON d.id=j.destination_id
                {where} ORDER BY j.id DESC LIMIT ?""", params
        ).fetchall()
        return [dict(r) for r in rows]
