from __future__ import annotations

from . import __product_version__

import json
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .audit_log import recent_events, record_event
from .config import settings
from .platform_ops import health_dashboard, leader_simulation, operational_alerts
from .storage import Storage
from .saas import SaaSManager
from .entitlements import EntitlementManager

RELEASE = "8.2.1"
LTS_BASE = "6.3.0"


def _rows(storage: Storage, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
    return [dict(row) for row in storage.conn.execute(sql, params).fetchall()]


def enterprise_snapshot() -> dict[str, Any]:
    # Retool/admin fast path:
    # enterprise_snapshot precisa apenas de health, leader, alerts e status.
    # Evita executar admin_dashboard() dentro de platform_dashboard(), que
    # adicionava vários segundos de latência a cada /api/retool/overview.
    health = health_dashboard()
    leader = leader_simulation()
    alerts = [
        item.to_dict()
        for item in operational_alerts(health)
    ]

    critical = sum(
        item.get("severity") == "critical"
        for item in alerts
    )
    high = sum(
        item.get("severity") == "high"
        for item in alerts
    )

    status = (
        "critical"
        if critical
        else "attention"
        if high or alerts
        else "healthy"
    )

    platform = {
        "status": status,
        "health": health,
        "leader": leader,
        "alerts": alerts,
    }

    now = datetime.now(timezone.utc)
    horizon = (now + timedelta(days=30)).isoformat()
    with Storage() as storage:
        users = _rows(storage, "SELECT user_id, username, first_name, plan, expires_at, blocked, created_at FROM users ORDER BY created_at DESC")
        payments = _rows(storage, "SELECT payment_id, user_id, plan, status, billing_type, created_at, updated_at FROM payment_orders ORDER BY created_at DESC LIMIT 200")
        renewals = _rows(
            storage,
            "SELECT user_id, plan, expires_at FROM users WHERE plan != 'free' AND blocked=0 AND expires_at IS NOT NULL AND expires_at <= ? ORDER BY expires_at ASC",
            (horizon,),
        )
        plan_counts = Counter(str(item.get("plan") or "free") for item in users if not int(item.get("blocked") or 0))
        payment_counts = Counter(str(item.get("status") or "UNKNOWN") for item in payments)
        favorites = int(storage.conn.execute("SELECT COUNT(*) FROM favorites").fetchone()[0])
        signals = int(storage.conn.execute("SELECT COUNT(*) FROM signal_positions").fetchone()[0])
        open_signals = int(storage.conn.execute("SELECT COUNT(*) FROM signal_positions WHERE status='OPEN'").fetchone()[0])
        saas = SaaSManager(storage)
        entitlement_manager = EntitlementManager(storage)
        tenant_rows = saas.list_tenants()
        tenant_summary = []
        for tenant in tenant_rows:
            effective = entitlement_manager.effective(str(tenant.get("slug") or "")) or {}
            usage = saas.usage_summary(str(tenant.get("slug") or ""))
            tenant_summary.append({
                "tenant": tenant.get("slug"), "name": tenant.get("name"),
                "plan": effective.get("plan"), "status": effective.get("status"),
                "active": effective.get("active"), "api_keys": tenant.get("api_keys", 0),
                "requests_today": usage.get("requests_today", 0),
            })
    # health_dashboard() já calculou latest_backup.
    # Reutiliza o valor para evitar uma segunda varredura cara
    # do diretório de backups em cada chamada do Retool.
    backup = health.get("latest_backup")
    result = {
        "release": RELEASE,
        "product_release": __product_version__,
        "lts_base": LTS_BASE,
        "generated_at": now.isoformat(),
        "environment": settings.app_environment,
        "platform_status": platform.get("status", "unknown"),
        "users_total": len(users),
        "plans": dict(plan_counts),
        "payments": dict(payment_counts),
        "renewals_next_30_days": renewals,
        "favorites": favorites,
        "signals_total": signals,
        "signals_open": open_signals,
        "saas": {
            "portal_enabled": bool(settings.customer_portal_enabled),
            "enterprise_dashboard_enabled": bool(settings.enterprise_dashboard_enabled),
            "tenants": tenant_summary,
            "tenant_count": len(tenant_summary),
            "active_entitlements": sum(1 for item in tenant_summary if item.get("active")),
            "requests_today": sum(int(item.get("requests_today") or 0) for item in tenant_summary),
        },
        "latest_backup": str(backup) if backup else None,
        "scanner": platform.get("health", {}).get("scanner", {}),
        "leader": platform.get("leader", {}),
        "operational_alerts": platform.get("alerts", []),
        "recent_events": recent_events(30),
    }
    return result


def save_enterprise_snapshot() -> Path:
    target = settings.data_dir / "reports" / "enterprise_dashboard.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = enterprise_snapshot()
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    record_event("enterprise_snapshot_created", category="enterprise", details={"path": str(target)})
    return target


def safe_users(limit: int = 100) -> list[dict[str, Any]]:
    with Storage() as storage:
        rows = _rows(storage, "SELECT user_id, username, first_name, plan, expires_at, blocked, created_at FROM users ORDER BY created_at DESC LIMIT ?", (max(1, min(limit, 500)),))
    return rows


def safe_subscriptions(limit: int = 100) -> list[dict[str, Any]]:
    with Storage() as storage:
        return _rows(storage, "SELECT subscription_id, user_id, plan, status, cycle, value, next_due_date, auto_renew, created_at, updated_at FROM subscriptions ORDER BY created_at DESC LIMIT ?", (max(1, min(limit, 500)),))
