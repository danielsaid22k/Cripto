from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .plans import base_plan, normalize_plan

ENTITLEMENT_SCHEMA_VERSION = 1
VALID_PLANS = {"free", "plus", "premium", "enterprise"}
VALID_STATUSES = {"ACTIVE", "GRACE", "SUSPENDED", "EXPIRED", "CANCELLED"}

# Feature names are deliberately stable API contracts. More features can be
# added without changing scanner/security behavior.
PLAN_LIMITS: dict[str, dict[str, int]] = {
    "free": {"signal_days": 5, "signal_limit": 25, "performance_days": 0, "api_rpm": 15, "api_daily": 1000},
    "plus": {"signal_days": 30, "signal_limit": 200, "performance_days": 30, "api_rpm": 30, "api_daily": 5000},
    "premium": {"signal_days": 365, "signal_limit": 500, "performance_days": 365, "api_rpm": 60, "api_daily": 20000},
    "enterprise": {"signal_days": 3650, "signal_limit": 1000, "performance_days": 3650, "api_rpm": 120, "api_daily": 50000},
}

FEATURES_BY_PLAN: dict[str, set[str]] = {
    "free": {"portal", "status", "branding", "signals"},
    "plus": {
        "portal", "status", "branding", "signals", "providers",
        "performance", "proofs",
    },
    "premium": {
        "portal", "status", "branding", "signals", "providers",
        "performance", "proofs", "security", "onchain", "reputation",
        "observability", "distribution",
    },
    "enterprise": {
        "portal", "status", "branding", "signals", "providers",
        "performance", "proofs", "security", "onchain", "reputation",
        "observability", "distribution", "enterprise",
    },
}


def _columns(conn, table: str) -> set[str]:
    return {str(row[1]) for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def ensure_schema(conn) -> None:
    """Additive V16 entitlement schema.

    Existing V11.5/V15 tenants are intentionally migrated with enterprise
    entitlement so an upgrade never removes API capabilities that worked before
    V16. Newly-created tenants explicitly receive the plan selected at creation.
    """
    columns = _columns(conn, "saas_tenants")
    additions = {
        "entitlement_plan": "TEXT NOT NULL DEFAULT 'enterprise'",
        "entitlement_status": "TEXT NOT NULL DEFAULT 'ACTIVE'",
        "entitlement_expires_at": "TEXT",
        "entitlement_grace_until": "TEXT",
        "linked_user_id": "INTEGER",
    }
    for name, ddl in additions.items():
        if name not in columns:
            conn.execute(f"ALTER TABLE saas_tenants ADD COLUMN {name} {ddl}")
            columns.add(name)

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS entitlement_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            old_plan TEXT DEFAULT '',
            new_plan TEXT DEFAULT '',
            old_status TEXT DEFAULT '',
            new_status TEXT DEFAULT '',
            source TEXT DEFAULT 'manual',
            details TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(tenant_id) REFERENCES saas_tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_entitlement_events_tenant
        ON entitlement_events(tenant_id, created_at DESC);

        CREATE TRIGGER IF NOT EXISTS trg_entitlement_events_no_update
        BEFORE UPDATE ON entitlement_events
        BEGIN
            SELECT RAISE(ABORT, 'entitlement_events_append_only');
        END;
        CREATE TRIGGER IF NOT EXISTS trg_entitlement_events_no_delete
        BEFORE DELETE ON entitlement_events
        BEGIN
            SELECT RAISE(ABORT, 'entitlement_events_append_only');
        END;
        """
    )
    conn.commit()


def _parse_time(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _clean_plan(value: str | None) -> str:
    raw = str(value or "free").strip().lower()
    if raw == "enterprise":
        return raw
    canonical = normalize_plan(raw)
    return base_plan(canonical)


class EntitlementManager:
    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)

    def _tenant(self, tenant_slug: str):
        return self.conn.execute(
            "SELECT * FROM saas_tenants WHERE slug=?",
            (str(tenant_slug or "").strip().lower(),),
        ).fetchone()

    def effective(self, tenant_or_slug: dict[str, Any] | str) -> dict[str, Any] | None:
        if isinstance(tenant_or_slug, str):
            row = self._tenant(tenant_or_slug)
            if not row:
                return None
            tenant = dict(row)
        else:
            tenant = dict(tenant_or_slug)

        plan = _clean_plan(tenant.get("entitlement_plan"))
        status = str(tenant.get("entitlement_status") or "ACTIVE").upper()
        now = datetime.now(timezone.utc)
        expires = _parse_time(tenant.get("entitlement_expires_at"))
        grace = _parse_time(tenant.get("entitlement_grace_until"))

        active = status in {"ACTIVE", "GRACE"}
        effective_status = status
        if expires is not None and expires <= now:
            if grace is not None and grace > now and status not in {"SUSPENDED", "CANCELLED"}:
                active = True
                effective_status = "GRACE"
            else:
                active = False
                effective_status = "EXPIRED"
        if status in {"SUSPENDED", "EXPIRED", "CANCELLED"}:
            active = False

        features = set(FEATURES_BY_PLAN.get(plan, FEATURES_BY_PLAN["free"]))
        # A customer with an expired/suspended entitlement must still be able to
        # open the portal, identify the account and see branding/status so they
        # can understand what happened. Data/product features stay blocked.
        if not active:
            features = {"portal", "status", "branding"}

        return {
            "tenant": tenant.get("slug"),
            "tenant_name": tenant.get("name"),
            "plan": plan,
            "status": effective_status,
            "configured_status": status,
            "active": active,
            "expires_at": tenant.get("entitlement_expires_at"),
            "grace_until": tenant.get("entitlement_grace_until"),
            "linked_user_id": tenant.get("linked_user_id"),
            "features": sorted(features),
            "limits": dict(PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])) if active else {
                "signal_days": 0, "signal_limit": 0, "performance_days": 0,
                "api_rpm": PLAN_LIMITS[plan]["api_rpm"], "api_daily": PLAN_LIMITS[plan]["api_daily"],
            },
        }

    def allowed(self, tenant_or_slug: dict[str, Any] | str, feature: str) -> bool:
        row = self.effective(tenant_or_slug)
        return bool(row and str(feature) in set(row.get("features") or []))

    def set_entitlement(
        self,
        tenant_slug: str,
        *,
        plan: str,
        status: str = "ACTIVE",
        expires_at: str | None = None,
        grace_until: str | None = None,
        source: str = "manual",
        details: str = "",
    ) -> dict[str, Any]:
        tenant = self._tenant(tenant_slug)
        if not tenant:
            raise ValueError("tenant não encontrado")
        clean_plan = _clean_plan(plan)
        if clean_plan not in VALID_PLANS:
            raise ValueError("plano de entitlement inválido")
        clean_status = str(status or "ACTIVE").strip().upper()
        if clean_status not in VALID_STATUSES:
            raise ValueError("status de entitlement inválido")
        if expires_at and _parse_time(expires_at) is None:
            raise ValueError("expires_at inválido; use ISO-8601")
        if grace_until and _parse_time(grace_until) is None:
            raise ValueError("grace_until inválido; use ISO-8601")

        old = dict(tenant)
        with self.conn:
            self.conn.execute(
                """UPDATE saas_tenants
                   SET entitlement_plan=?, entitlement_status=?, entitlement_expires_at=?,
                       entitlement_grace_until=?, updated_at=CURRENT_TIMESTAMP
                   WHERE id=?""",
                (clean_plan, clean_status, expires_at or None, grace_until or None, int(old["id"])),
            )
            self.conn.execute(
                """INSERT INTO entitlement_events(
                       tenant_id,event_type,old_plan,new_plan,old_status,new_status,source,details
                   ) VALUES(?,?,?,?,?,?,?,?)""",
                (
                    int(old["id"]), "entitlement.changed",
                    str(old.get("entitlement_plan") or ""), clean_plan,
                    str(old.get("entitlement_status") or ""), clean_status,
                    str(source or "manual")[:40], str(details or "")[:500],
                ),
            )
        result = self.effective(tenant_slug)
        if result is None:
            raise RuntimeError("entitlement não pôde ser recarregado")
        return result

    def link_user(self, tenant_slug: str, user_id: int | None) -> dict[str, Any]:
        tenant = self._tenant(tenant_slug)
        if not tenant:
            raise ValueError("tenant não encontrado")
        old_user = tenant["linked_user_id"]
        with self.conn:
            self.conn.execute(
                "UPDATE saas_tenants SET linked_user_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (int(user_id) if user_id is not None else None, int(tenant["id"])),
            )
            self.conn.execute(
                """INSERT INTO entitlement_events(tenant_id,event_type,source,details)
                   VALUES(?,?,?,?)""",
                (int(tenant["id"]), "tenant.user_linked", "manual", f"old={old_user};new={user_id}"),
            )
        result = self.effective(tenant_slug)
        if result is None:
            raise RuntimeError("tenant não pôde ser recarregado")
        return result

    def sync_from_users(self, tenant_slug: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM saas_tenants WHERE linked_user_id IS NOT NULL"
        params: tuple[Any, ...] = ()
        if tenant_slug:
            sql += " AND slug=?"
            params = (str(tenant_slug).strip().lower(),)
        tenants = self.conn.execute(sql, params).fetchall()
        changed: list[dict[str, Any]] = []
        for row in tenants:
            tenant = dict(row)
            user = self.conn.execute(
                "SELECT user_id,plan,expires_at,blocked FROM users WHERE user_id=?",
                (int(tenant["linked_user_id"]),),
            ).fetchone()
            if not user:
                continue
            user = dict(user)
            plan = _clean_plan(user.get("plan"))
            status = "SUSPENDED" if int(user.get("blocked") or 0) else "ACTIVE"
            expiry = user.get("expires_at")
            parsed = _parse_time(expiry)
            if parsed is not None and parsed <= datetime.now(timezone.utc):
                plan = "free"
                status = "EXPIRED"
            current_plan = _clean_plan(tenant.get("entitlement_plan"))
            current_status = str(tenant.get("entitlement_status") or "ACTIVE").upper()
            current_expiry = tenant.get("entitlement_expires_at")
            if (current_plan, current_status, current_expiry) == (plan, status, expiry):
                continue
            changed.append(self.set_entitlement(
                tenant["slug"], plan=plan, status=status, expires_at=expiry,
                grace_until=None, source="user-plan-sync",
                details=f"linked_user_id={user['user_id']}",
            ))
        return changed

    def history(self, tenant_slug: str, limit: int = 50) -> list[dict[str, Any]]:
        tenant = self._tenant(tenant_slug)
        if not tenant:
            return []
        rows = self.conn.execute(
            """SELECT id,event_type,old_plan,new_plan,old_status,new_status,source,details,created_at
               FROM entitlement_events WHERE tenant_id=? ORDER BY id DESC LIMIT ?""",
            (int(tenant["id"]), max(1, min(500, int(limit)))),
        ).fetchall()
        return [dict(row) for row in rows]
