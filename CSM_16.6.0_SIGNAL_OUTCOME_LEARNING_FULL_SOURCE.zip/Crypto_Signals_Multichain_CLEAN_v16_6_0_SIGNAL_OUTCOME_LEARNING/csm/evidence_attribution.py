from __future__ import annotations

from collections import defaultdict
from statistics import mean
from typing import Any


VERSION = "16.5.1"


def _num(value: Any) -> float | None:
    if value is None:
        return None

    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _text(
    value: Any,
    default: str = "unknown",
) -> str:
    text = str(value or "").strip()
    return text or default


def score_band(value: Any) -> str:
    score = _num(value)

    if score is None:
        return "unknown"

    if score >= 90:
        return "90-100"

    if score >= 80:
        return "80-89"

    if score >= 70:
        return "70-79"

    if score >= 60:
        return "60-69"

    return "<60"


def _confirmed(row: dict[str, Any]) -> bool:
    value = row.get("shadow_confirmed")

    if value is True:
        return True

    if value is False:
        return False

    status = _text(
        row.get("shadow_status")
        or row.get("status"),
        "",
    ).lower()

    if status in {
        "confirmed",
        "observed",
        "complete",
        "completed",
    }:
        return True

    return (
        _num(
            row.get("shadow_return_pct")
            or row.get("return_pct")
        )
        is not None
    )


def _return_pct(
    row: dict[str, Any],
) -> float | None:
    return _num(
        row.get("shadow_return_pct")
        or row.get("return_pct")
        or row.get("pnl_pct")
        or row.get("last_return_pct")
    )


def _group(
    rows: list[dict[str, Any]],
    field: str,
) -> list[dict[str, Any]]:
    groups = defaultdict(list)

    for row in rows:
        key = _text(row.get(field))
        groups[key].append(row)

    result = []

    for name, items in groups.items():
        returns = [
            value
            for item in items
            if (
                value := _return_pct(item)
            ) is not None
        ]

        wins = sum(
            1
            for value in returns
            if value > 0
        )

        losses = sum(
            1
            for value in returns
            if value < 0
        )

        samples = len(returns)

        result.append({
            "name": name,
            "samples": samples,
            "wins": wins,
            "losses": losses,
            "win_rate_pct": round(
                (
                    wins / samples * 100
                    if samples
                    else 0.0
                ),
                2,
            ),
            "average_return_pct": round(
                mean(returns)
                if returns
                else 0.0,
                2,
            ),
        })

    return sorted(
        result,
        key=lambda item: (
            -item["samples"],
            -item["win_rate_pct"],
            -item["average_return_pct"],
        ),
    )


def analyze_evidence_attribution(
    rows: list[dict[str, Any]],
    *,
    minimum_samples: int = 3,
) -> dict[str, Any]:
    confirmed = []

    for source in rows:
        if not isinstance(source, dict):
            continue

        if not _confirmed(source):
            continue

        row = dict(source)

        row["chain"] = _text(
            row.get("chain")
            or row.get("network")
        )

        row["provider"] = _text(
            row.get("provider")
            or row.get("source")
        )

        row["score_band"] = score_band(
            row.get("score")
        )

        if _return_pct(row) is None:
            continue

        confirmed.append(row)

    by_chain = _group(
        confirmed,
        "chain",
    )

    by_provider = _group(
        confirmed,
        "provider",
    )

    by_score_band = _group(
        confirmed,
        "score_band",
    )

    eligible_chains = [
        row
        for row in by_chain
        if row["samples"] >= minimum_samples
    ]

    eligible_providers = [
        row
        for row in by_provider
        if row["samples"] >= minimum_samples
    ]

    best_chain = (
        max(
            eligible_chains,
            key=lambda row: (
                row["win_rate_pct"],
                row["average_return_pct"],
            ),
        )
        if eligible_chains
        else None
    )

    worst_chain = (
        min(
            eligible_chains,
            key=lambda row: (
                row["win_rate_pct"],
                row["average_return_pct"],
            ),
        )
        if eligible_chains
        else None
    )

    best_provider = (
        max(
            eligible_providers,
            key=lambda row: (
                row["win_rate_pct"],
                row["average_return_pct"],
            ),
        )
        if eligible_providers
        else None
    )

    worst_provider = (
        min(
            eligible_providers,
            key=lambda row: (
                row["win_rate_pct"],
                row["average_return_pct"],
            ),
        )
        if eligible_providers
        else None
    )

    return {
        "version": VERSION,
        "mode": "SHADOW",
        "confirmed_samples": len(confirmed),
        "minimum_samples_per_group": minimum_samples,
        "by_chain": by_chain,
        "by_provider": by_provider,
        "by_score_band": by_score_band,
        "best_chain": best_chain,
        "worst_chain": worst_chain,
        "best_provider": best_provider,
        "worst_provider": worst_provider,
        "live_impact": False,
        "methodology": (
            "Usa somente evidências Shadow confirmadas. "
            "Grupos com amostra insuficiente não são "
            "promovidos a melhor/pior resultado."
        ),
    }
