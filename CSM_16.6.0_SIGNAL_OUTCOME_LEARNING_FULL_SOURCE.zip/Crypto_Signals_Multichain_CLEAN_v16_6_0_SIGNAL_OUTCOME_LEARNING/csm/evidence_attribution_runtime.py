from __future__ import annotations

from typing import Any

from .evidence_attribution import (
    analyze_evidence_attribution,
)


VERSION = "16.5.1"


RETURN_KEYS = (
    "shadow_return_pct",
    "return_pct",
    "pnl_pct",
    "last_return_pct",
)

IDENTITY_KEYS = (
    "chain",
    "network",
    "provider",
    "source",
)


def _candidate(row: dict[str, Any]) -> bool:
    has_return = any(
        key in row
        and row.get(key) is not None
        for key in RETURN_KEYS
    )

    has_identity = any(
        str(row.get(key) or "").strip()
        for key in IDENTITY_KEYS
    )

    return has_return and has_identity


def _identity(row: dict[str, Any]) -> str:
    value = (
        row.get("signal_id")
        or row.get("id")
        or row.get("address")
        or row.get("token_address")
        or row.get("contract_address")
    )

    if value:
        return str(value)

    return "|".join([
        str(
            row.get("chain")
            or row.get("network")
            or ""
        ),
        str(
            row.get("provider")
            or row.get("source")
            or ""
        ),
        str(
            row.get("created_at")
            or row.get("timestamp")
            or ""
        ),
        str(
            row.get("symbol")
            or ""
        ),
    ])


def collect_evidence_rows(
    value: Any,
) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []

    def walk(node: Any) -> None:
        if isinstance(node, list):
            for item in node:
                if isinstance(item, dict):
                    if _candidate(item):
                        found.append(dict(item))
                    else:
                        walk(item)

            return

        if isinstance(node, dict):
            for child in node.values():
                if isinstance(
                    child,
                    (dict, list),
                ):
                    walk(child)

    walk(value)

    unique = []
    seen = set()

    for row in found:
        key = _identity(row)

        if key in seen:
            continue

        seen.add(key)
        unique.append(row)

    return unique


def attach_evidence_attribution(
    quality: dict[str, Any],
    performance: dict[str, Any],
) -> dict[str, Any]:
    result = dict(quality)

    rows = collect_evidence_rows(
        performance
    )

    attribution = (
        analyze_evidence_attribution(
            rows,
            minimum_samples=3,
        )
    )

    result["evidence_attribution"] = (
        attribution
    )

    # Alimenta o card existente somente com
    # estatística baseada em evidência real.
    if attribution["confirmed_samples"] > 0:
        result["by_chain"] = (
            attribution["by_chain"]
        )

        result["by_provider"] = (
            attribution["by_provider"]
        )

        result["by_score_band"] = (
            attribution["by_score_band"]
        )

    result["attribution_live_impact"] = False

    return result
