from __future__ import annotations

from html import escape
from typing import Any
from datetime import datetime, timezone

from .config import settings
from .formatting import score_breakdown
from .plans import PLANS, base_plan, normalize_plan


def plan_group(plan: str | None) -> str:
    return base_plan(normalize_plan(plan))


def interval_seconds(plan: str | None) -> int:
    group = plan_group(plan)
    if group == "premium":
        return settings.auto_scan_interval_premium
    if group == "plus":
        return settings.auto_scan_interval_plus
    return settings.auto_scan_interval_free


def interval_label(plan: str | None) -> str:
    seconds = interval_seconds(plan)
    if seconds % 60 == 0:
        minutes = seconds // 60
        return f"{minutes} minuto" if minutes == 1 else f"{minutes} minutos"
    return f"{seconds} segundos"


def new_opportunity_limit(plan: str | None) -> int:
    group = plan_group(plan)
    if group == "premium":
        return max(1, int(getattr(settings, "auto_signal_limit_premium", 3)))
    if group == "plus":
        return max(1, int(getattr(settings, "auto_signal_limit_plus", 2)))
    return max(1, int(getattr(settings, "auto_signal_limit_free", 1)))


def scan_explainer(plan: str | None, *, compact: bool = False) -> str:
    """Explain the scanner cadence without promising a signal every cycle."""
    group = plan_group(plan)
    interval = interval_label(plan)
    limit = new_opportunity_limit(plan)
    if compact:
        return (
            f"verificação a cada {interval}; novo sinal somente com oportunidade "
            "aprovada e ainda não recebida"
        )
    quota = "1 nova oportunidade" if limit == 1 else f"até {limit} novas oportunidades"
    if group == "premium":
        follow = "Realertas inteligentes: score, volume, nova máxima e piora de risco, além de TP/stop."
    elif group == "plus":
        follow = "Realertas inteligentes em mudanças relevantes, além de TP/stop."
    else:
        follow = "Moedas já sinalizadas continuam com avisos resumidos de TP/stop."
    return (
        f"🔄 Verificação de novas oportunidades: <b>a cada {interval}</b>\n"
        f"🚀 Por ciclo: <b>{quota}</b>, somente quando forem aprovadas e ainda não tiverem sido recebidas por você.\n"
        "🔕 Se não houver novidade aprovada, <b>nenhum sinal novo é enviado</b>.\n"
        f"🎯 {follow}\n"
        "ℹ️ O intervalo é a frequência de busca, não uma quantidade mínima garantida de sinais."
    )


def project_stage(item: dict[str, Any]) -> tuple[str, str]:
    age = item.get("age_days")
    try:
        age_value = float(age) if age is not None else None
    except (TypeError, ValueError):
        age_value = None
    if age_value is None:
        return "🔎", "fase não confirmada"
    if age_value <= 0.25:
        return "🆕", "recém-listado"
    if age_value <= 1:
        return "🌱", "fase inicial"
    if age_value <= 7:
        return "🚀", "em crescimento inicial"
    if age_value <= 30:
        return "📈", "em expansão"
    return "🏛️", "mais estabelecido"


def launch_origin(item: dict[str, Any]) -> str:
    source = str(item.get("source") or "").lower()
    dex = str(item.get("dex") or "").lower()
    chain = str(item.get("chain") or "").lower()
    combined = f"{source} {dex}"
    if "pump" in combined:
        return "Pump.fun / ecossistema Solana"
    if "four" in combined or "meme" in combined and chain == "bsc":
        return "ecossistema de lançamentos BNB Chain"
    labels = {
        "solana": "ecossistema Solana",
        "ethereum": "ecossistema Ethereum",
        "bsc": "ecossistema BNB Chain",
        "base": "ecossistema Base",
        "arbitrum": "ecossistema Arbitrum",
        "polygon": "ecossistema Polygon",
        "avalanche": "ecossistema Avalanche",
        "optimism": "ecossistema Optimism",
    }
    return labels.get(chain, "DEX multichain")


def opportunity_profile(item: dict[str, Any]) -> dict[str, Any]:
    base_score = int(item.get("score") or 0)
    age = item.get("age_days")
    try:
        age_value = float(age) if age is not None else None
    except (TypeError, ValueError):
        age_value = None
    buys = int(item.get("buys24h") or 0)
    sells = int(item.get("sells24h") or 0)
    ratio = buys / max(sells, 1)
    volume = float(item.get("volume24h") or 0)
    liquidity = float(item.get("liquidity") or 0)
    turnover = volume / liquidity if liquidity > 0 else 0
    change = float(item.get("change24h") or 0)

    early_bonus = 0
    if age_value is not None:
        if age_value <= 1:
            early_bonus = 8
        elif age_value <= 7:
            early_bonus = 6
        elif age_value <= 30:
            early_bonus = 3
    activity_bonus = 4 if ratio >= 1.5 else 2 if ratio >= 1.1 else 0
    turnover_bonus = 4 if turnover >= 3 else 2 if turnover >= 1 else 0
    momentum_bonus = 3 if 3 <= change <= 80 else 1 if change > 0 else 0
    penalty = 6 if change > 250 else 4 if ratio < 0.7 else 0
    opportunity_score = max(0, min(100, base_score + early_bonus + activity_bonus + turnover_bonus + momentum_bonus - penalty))

    confidence = "alta" if opportunity_score >= 88 else "moderada" if opportunity_score >= 78 else "em observação"
    return {
        "opportunity_score": opportunity_score,
        "confidence": confidence,
        "buy_sell_ratio": ratio,
        "turnover": turnover,
        "stage": project_stage(item)[1],
        "origin": launch_origin(item),
    }


def signal_reasons(item: dict[str, Any], limit: int = 3) -> list[str]:
    candidates: list[tuple[int, str]] = []
    liquidity = float(item.get("liquidity") or 0)
    volume = float(item.get("volume24h") or 0)
    buys = int(item.get("buys24h") or 0)
    sells = int(item.get("sells24h") or 0)
    age = item.get("age_days")
    change = float(item.get("change24h") or 0)

    if liquidity >= 100_000:
        candidates.append((10, "liquidez acima de US$ 100 mil"))
    elif liquidity >= 25_000:
        candidates.append((7, "liquidez relevante para o estágio"))
    if volume >= 500_000:
        candidates.append((10, "volume de 24h acima de US$ 500 mil"))
    elif volume >= 50_000:
        candidates.append((7, "volume de negociação consistente"))
    if buys > sells and buys + sells > 0:
        candidates.append((9, "pressão compradora superior à vendedora"))
    if age is not None:
        try:
            age_value = float(age)
            if age_value <= 1:
                candidates.append((10, "pool recém-listado detectado cedo"))
            elif age_value <= 7:
                candidates.append((8, "projeto ainda em fase inicial"))
        except (TypeError, ValueError):
            pass
    if 3 <= change <= 80:
        candidates.append((8, "momentum positivo sem pico extremo"))
    if not candidates:
        candidates.append((1, "combinação de filtros técnicos atingiu o mínimo"))
    candidates.sort(key=lambda row: row[0], reverse=True)
    return [text for _, text in candidates[: max(1, limit)]]


def keyboard_for_plan(plan: str | None) -> dict:
    group = plan_group(plan)
    if group == "free":
        rows = [
            [{"text": "🔍 Analisar"}, {"text": "🚀 Scanner"}],
            [{"text": "🌐 Redes"}, {"text": "🧾 Histórico"}],
            [{"text": "👤 Meu plano"}, {"text": "💎 Planos"}],
            [{"text": "🧠 Minha Central"}, {"text": "🎛️ Preferências"}],
            [{"text": "🟢 Status"}],
        ]
        placeholder = "Grátis • busca de oportunidades a cada 15 min"
    elif group == "plus":
        rows = [
            [{"text": "📡 Sinais automáticos"}, {"text": "🔍 Analisar"}],
            [{"text": "⭐ Favoritos"}, {"text": "🧾 Histórico"}],
            [{"text": "🧠 Minha Central"}, {"text": "👤 Meu plano"}],
            [{"text": "👑 Conhecer Premium"}, {"text": "🟢 Status"}],
        ]
        placeholder = "Plus • busca de oportunidades a cada 5 min"
    else:
        rows = [
            [{"text": "👑 Central Premium"}, {"text": "📡 Sinais automáticos"}],
            [{"text": "🔍 Analisar"}, {"text": "⭐ Favoritos"}],
            [{"text": "🧾 Histórico"}, {"text": "🧠 Minha Central"}],
            [{"text": "👤 Minha assinatura"}, {"text": "🟢 Status"}],
        ]
        placeholder = "Premium • busca prioritária a cada 1 min"
    return {
        "keyboard": rows,
        "resize_keyboard": True,
        "is_persistent": True,
        "input_field_placeholder": placeholder,
    }



def subscription_timing(user: dict) -> tuple[str, str, int | None]:
    """Formata vencimento e dias restantes para mensal e anual."""
    raw = user.get("expires_at")
    if not raw:
        return "Sem vencimento", "Não aplicável", None
    try:
        dt = datetime.fromisoformat(str(raw))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        seconds = (dt - now).total_seconds()
        days = max(0, int((seconds + 86399) // 86400)) if seconds > 0 else 0
        return dt.astimezone().strftime("%d/%m/%Y"), f"{days} dia" if days == 1 else f"{days} dias", days
    except (TypeError, ValueError):
        return escape(str(raw)), "Data não reconhecida", None

def welcome_text(user: dict, first_name: str = "") -> str:
    plan_key = normalize_plan(user.get("plan"))
    meta = PLANS[plan_key]
    group = meta["base"]
    name = f", {escape(first_name)}" if first_name else ""
    if group == "free":
        title = "🆓 <b>CENTRAL ESSENCIAL</b>"
        body = (
            "• Busca de oportunidades a cada <b>15 minutos</b>\n"
            "• Visão rápida de liquidez, volume e score\n"
            "• Alertas resumidos de TP/stop\n"
            "• Histórico e painel essenciais"
        )
    elif group == "plus":
        title = "💠 <b>CENTRAL PLUS</b>"
        body = (
            "• Busca de oportunidades a cada <b>5 minutos</b>\n"
            "• Estratégia, motivos, risco/retorno e níveis completos\n"
            "• Realertas inteligentes quando o cenário muda de forma relevante"
        )
    else:
        title = "👑 <b>CENTRAL PREMIUM</b>"
        body = (
            "• Busca prioritária a cada <b>1 minuto</b>\n"
            "• Inteligência avançada e tese completa do sinal\n"
            "• Realertas mais sensíveis para score, volume, nova máxima e risco"
        )
    return (
        f"{BRAND_DIVIDER}\n"
        f"🚀 <b>{BRAND_NAME} • BEM-VINDO{name}</b>\n"
        f"{BRAND_DIVIDER}\n\n"
        f"{title}\n"
        f"Plano reconhecido: <b>{meta['emoji']} {escape(meta['label'])}</b>\n"
        f"Próxima verificação: <b>em até {interval_label(plan_key)}</b>\n\n"
        "📡 <b>O QUE ESTÁ ATIVO</b>\n"
        f"{body}\n\n"
        "🧭 <b>COMO OS SINAIS FUNCIONAM</b>\n"
        f"{scan_explainer(plan_key)}\n\n"
        "⚠️ <b>TRANSPARÊNCIA</b>\n"
        "Análises educacionais, sem promessa de lucro ou quantidade mínima de sinais. Confirme contrato e gerencie seu risco.\n\n"
        "👇 Toque em <b>INICIAR</b> para abrir seu painel."
    )


def start_keyboard() -> dict:
    return {"inline_keyboard": [[{"text": "➡️  INICIAR  ⬅️", "callback_data": "enter_app"}]]}


def dashboard_intro(user: dict) -> str:
    plan_key = normalize_plan(user.get("plan"))
    meta = PLANS[plan_key]
    group = meta["base"]
    style = "ESSENCIAL" if group == "free" else "PLUS" if group == "plus" else "PREMIUM"
    return (
        f"{'🆓' if group == 'free' else '💠' if group == 'plus' else '👑'} "
        f"<b>PAINEL {style}</b>\n"
        f"Verificação de oportunidades: <b>ativa • a cada {interval_label(plan_key)}</b>\n"
    )


def premium_score_details(item: dict[str, Any]) -> str:
    breakdown = score_breakdown(item)
    return (
        "🧮 <b>COMPOSIÇÃO DO SCORE</b>\n"
        f"• Liquidez: {breakdown['liquidez']}/25\n"
        f"• Volume: {breakdown['volume']}/25\n"
        f"• Market cap: {breakdown['marketcap']}/15\n"
        f"• Atividade: {breakdown['atividade']}/15\n"
        f"• Momentum: {breakdown['momentum']}/10\n"
        f"• Idade: {breakdown['idade']}/10"
    )


BRAND_DIVIDER = "━━━━━━━━━━━━━━━━━━━━"
BRAND_NAME = "PHANTOM ALERT • MULTICHAIN INTELLIGENCE"


def plan_badge(plan: str | None) -> str:
    group = plan_group(plan)
    return "🆓 ESSENCIAL" if group == "free" else "💠 PLUS" if group == "plus" else "👑 PREMIUM"


def plan_theme(plan: str | None) -> dict[str, str]:
    group = plan_group(plan)
    if group == "free":
        return {"icon": "🆓", "title": "CENTRAL ESSENCIAL", "tone": "Visão objetiva do mercado"}
    if group == "plus":
        return {"icon": "💠", "title": "CENTRAL PLUS", "tone": "Contexto, estratégia e acompanhamento"}
    return {"icon": "👑", "title": "CENTRAL PREMIUM", "tone": "Radar antecipado e inteligência avançada"}


def next_cycle_text(plan: str | None) -> str:
    return f"em até {interval_label(plan)}"


def home_text(user: dict, first_name: str = "") -> str:
    plan_key = normalize_plan(user.get("plan"))
    meta = PLANS[plan_key]
    theme = plan_theme(plan_key)
    name = f", {escape(first_name)}" if first_name else ""
    group = meta["base"]
    if group == "free":
        unlocked = "• sinais essenciais\n• dados resumidos de mercado\n• avisos resumidos de TP/stop\n• análise manual e histórico básico"
        upgrade = "💎 Plus acrescenta níveis técnicos completos, risco/retorno, favoritos e realertas inteligentes."
    elif group == "plus":
        unlocked = "• sinais contextualizados\n• entrada, stop, TP1 e TP2\n• favoritos e histórico ampliado\n• realertas inteligentes em mudanças relevantes"
        upgrade = "👑 Premium libera radar mais rápido, contexto completo e realertas mais sensíveis."
    else:
        unlocked = "• radar prioritário\n• tese completa do sinal\n• análise avançada e monitoramento\n• realertas inteligentes de alta sensibilidade"
        upgrade = "✨ Todos os recursos Premium estão liberados."
    return (
        f"{theme['icon']} <b>{theme['title']}</b>{name}\n"
        f"{BRAND_DIVIDER}\n"
        f"<i>{theme['tone']}</i>\n\n"
        f"🏷 Plano: <b>{meta['emoji']} {escape(meta['label'])}</b>\n"
        f"📡 Scanner: <b>ATIVO</b>\n"
        f"⏱ Próxima verificação: <b>{next_cycle_text(plan_key)}</b>\n\n"
        f"🔓 <b>RECURSOS ATIVOS</b>\n{unlocked}\n\n"
        f"{upgrade}\n\n"
        "ℹ️ <i>O intervalo é de busca. Um novo sinal só é enviado quando existe uma oportunidade aprovada ainda não recebida.</i>\n"
        "⚠️ <i>Ferramenta educacional. Sinais não garantem lucro; valide os dados e gerencie o risco.</i>"
    )


def activated_text(user: dict) -> str:
    plan_key = normalize_plan(user.get("plan"))
    meta = PLANS[plan_key]
    due_date, days_text, _ = subscription_timing(user)
    cycle = "ANUAL" if plan_key.endswith("_annual") else "MENSAL" if plan_key != "free" else "GRÁTIS"
    return (
        "✅ <b>ASSINATURA ATIVADA</b>\n"
        f"{BRAND_DIVIDER}\n\n"
        f"{meta['emoji']} Plano: <b>{escape(meta['label'])}</b>\n"
        f"🔁 Ciclo: <b>{cycle}</b>\n"
        f"📅 Vencimento: <b>{due_date}</b>\n"
        f"⏳ Dias restantes: <b>{days_text}</b>\n\n"
        f"{scan_explainer(plan_key)}\n\n"
        "✅ Seu painel e os recursos do plano já estão liberados.\n"
        "⚠️ <i>Os alertas são educacionais; não há promessa de retorno nem quantidade mínima garantida.</i>"
    )


def signal_header(plan: str | None, subtitle: str) -> str:
    return f"{plan_badge(plan)} <b>{escape(subtitle)}</b>\n{BRAND_DIVIDER}"
