from __future__ import annotations

from html import escape
from .chains import CHAINS


def money(value) -> str:
    value = float(value or 0)
    if abs(value) >= 1_000_000_000:
        return f"${value / 1_000_000_000:.2f}B"
    if abs(value) >= 1_000_000:
        return f"${value / 1_000_000:.2f}M"
    if abs(value) >= 1_000:
        return f"${value / 1_000:.2f}K"
    if 0 < abs(value) < 0.01:
        return f"${value:.10f}".rstrip("0")
    return f"${value:,.2f}"


def compact_address(address: str, size: int = 7) -> str:
    address = address or ""
    if len(address) <= size * 2 + 3:
        return address
    return f"{address[:size]}…{address[-size:]}"


def score_breakdown(market: dict) -> dict[str, int]:
    liquidity = 25 if market["liquidity"] >= 100_000 else 15 if market["liquidity"] >= 25_000 else 5
    volume = 25 if market["volume24h"] >= 500_000 else 15 if market["volume24h"] >= 50_000 else 5
    marketcap = 15 if market["marketcap"] > 0 else 5
    activity = 15 if market["buys24h"] >= market["sells24h"] else 8
    momentum = 10 if market["change24h"] >= 0 else 3
    age = 10 if market.get("age_days") is None or market["age_days"] >= 7 else 4
    return {
        "liquidez": liquidity,
        "volume": volume,
        "marketcap": marketcap,
        "atividade": activity,
        "momentum": momentum,
        "idade": age,
    }


def score_market(market: dict) -> int:
    return min(100, sum(score_breakdown(market).values()))


def score_badge(score: int) -> tuple[str, str]:
    if score >= 80:
        return "🟢", "MUITO FORTE"
    if score >= 70:
        return "✅", "FORTE"
    if score >= 55:
        return "🟡", "MODERADO"
    return "🔴", "FRACO"


def risk_label(score: int) -> str:
    if score >= 75:
        return "BAIXO"
    if score >= 50:
        return "MÉDIO"
    return "ALTO"


def report(market: dict, plan: str) -> tuple[str, int]:
    score = score_market(market)
    badge, signal = score_badge(score)
    chain = CHAINS.get(market["chain"], {"emoji": "🌐", "label": market["chain"]})
    short_contract = compact_address(market["address"])

    lines = [
        "📊 <b>CRYPTO SIGNALS MULTICHAIN</b>",
        f"<i>{escape(market['source'])}{' • cache' if market.get('cached') else ''}</i>",
        "",
        f"{badge} <b>SINAL {signal}</b>",
        f"{chain['emoji']} <b>Rede</b>          {escape(chain['label'])}",
        f"🪙 <b>Token</b>         {escape(market['name'])} ({escape(market['symbol'])})",
        f"📄 <b>Contrato</b>      <code>{escape(short_contract)}</code>",
        "",
        "💹 <b>MERCADO</b>",
        f"💲 Preço         <b>{money(market['price'])}</b>",
        f"💧 Liquidez      <b>{money(market['liquidity'])}</b>",
        f"📈 Volume 24h    <b>{money(market['volume24h'])}</b>",
        f"🏦 Market cap    <b>{money(market['marketcap'])}</b>",
        f"📊 Variação 24h  <b>{market['change24h']:+.2f}%</b>",
        f"🔄 C/V 24h       <b>{market['buys24h']}/{market['sells24h']}</b>",
        "",
        "🧭 <b>AVALIAÇÃO</b>",
        f"⭐ Score         <b>{score}/100</b>",
        f"🛡️ Risco         <b>{risk_label(score)}</b>",
    ]

    if plan in {"plus", "premium"}:
        holders = market.get("holders")
        lines += [
            "",
            "💎 <b>INDICADORES VIP</b>",
            f"• FDV: <b>{money(market['fdv'])}</b>",
            (
                f"• Idade do pool: <b>{market['age_days']:.1f} dias</b>"
                if market.get("age_days") is not None
                else "• Idade do pool: <b>indisponível</b>"
            ),
            f"• DEX: <b>{escape(market.get('dex') or 'indisponível')}</b>",
            f"• Holders: <b>{holders if holders is not None else 'indisponível na fonte pública'}</b>",
            (
                f"• Volume/Liquidez: <b>{market['volume24h'] / market['liquidity']:.2f}x</b>"
                if market["liquidity"]
                else "• Volume/Liquidez: <b>indisponível</b>"
            ),
        ]

    if plan == "premium":
        breakdown = score_breakdown(market)
        total_1h = market["buys1h"] + market["sells1h"]
        pressure = market["buys1h"] / total_1h * 100 if total_1h else 0
        lines += [
            "",
            "👑 <b>PAINEL PREMIUM</b>",
            f"• Variação 1h: <b>{market['change1h']:+.2f}%</b>",
            f"• Variação 6h: <b>{market['change6h']:+.2f}%</b>",
            f"• Compras/Vendas 1h: <b>{market['buys1h']}/{market['sells1h']}</b>",
            f"• Pressão compradora 1h: <b>{pressure:.1f}%</b>",
            "",
            "🧮 <b>COMPOSIÇÃO DO SCORE</b>",
            f"• Liquidez: {breakdown['liquidez']}/25",
            f"• Volume: {breakdown['volume']}/25",
            f"• Market cap: {breakdown['marketcap']}/15",
            f"• Atividade: {breakdown['atividade']}/15",
            f"• Momentum: {breakdown['momentum']}/10",
            f"• Idade: {breakdown['idade']}/10",
        ]

    lines += ["", "⚠️ <i>Informação educacional; não é recomendação financeira.</i>"]
    return "\n".join(lines), score
