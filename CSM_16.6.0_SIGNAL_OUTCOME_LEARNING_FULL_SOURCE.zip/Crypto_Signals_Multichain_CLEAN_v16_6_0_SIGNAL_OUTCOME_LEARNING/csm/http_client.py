from __future__ import annotations

import json
import os
import socket
import ssl
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPSHandler

import certifi

from .config import settings

CA_BUNDLE = certifi.where()
os.environ["SSL_CERT_FILE"] = CA_BUNDLE
os.environ["REQUESTS_CA_BUNDLE"] = CA_BUNDLE


class HTTPTransientError(RuntimeError):
    """Falha temporária de rede, tratada pela aplicação sem derrubar o bot."""


class HTTPJSONError(RuntimeError):
    def __init__(self, status_code: int, payload: Any, url: str):
        self.status_code = int(status_code)
        self.payload = payload
        self.url = url
        super().__init__(self._message())

    def _message(self) -> str:
        if isinstance(self.payload, dict):
            message = self.payload.get("description") or self.payload.get("message")
            if message:
                return f"HTTP {self.status_code}: {message}"
        return f"HTTP {self.status_code} ao acessar {self.url}"


class SafeHTTP:
    """Cliente HTTP reconstruído para a-Shell/iOS.

    Não usa bibliotecas HTTP com pool, threads ou retries internos. Cada tentativa
    abre uma conexão curta e o backoff é controlado pela própria aplicação.
    """

    def __init__(self, timeout: int | None = None, headers: dict | None = None,
                 retries: int | None = None, backoff: float | None = None):
        self.timeout = int(timeout or settings.request_timeout)
        self.retries = max(0, int(settings.http_retries if retries is None else retries))
        self.backoff = max(0.0, float(settings.http_backoff if backoff is None else backoff))
        self.headers = {
            "User-Agent": "PhantomAlert/8.0.2",
            "Accept": "application/json",
            "Connection": "close",
        }
        if headers:
            self.headers.update(headers)
        context = ssl.create_default_context(cafile=CA_BUNDLE)
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED
        self._opener = build_opener(HTTPSHandler(context=context))

    @staticmethod
    def _payload(raw: bytes) -> Any:
        if not raw:
            return {}
        text = raw.decode("utf-8", errors="replace")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"message": text[:1000]}

    def request_json(self, method: str, url: str, *, params=None, json_data=None,
                     data=None, timeout=None):
        method = method.upper()
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params, doseq=True)
        body = None
        headers = dict(self.headers)
        if json_data is not None:
            body = json.dumps(json_data, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        elif data is not None:
            body = urlencode(data, doseq=True).encode("utf-8")
            headers["Content-Type"] = "application/x-www-form-urlencoded"

        attempts = 1 if method == "POST" else self.retries + 1
        effective_timeout = int(timeout or self.timeout)
        last_exc: BaseException | None = None
        for attempt in range(attempts):
            try:
                request = Request(url, data=body, headers=headers, method=method)
                with self._opener.open(request, timeout=effective_timeout) as response:
                    return self._payload(response.read())
            except HTTPError as exc:
                payload = self._payload(exc.read())
                if exc.code in (429, 500, 502, 503, 504) and attempt + 1 < attempts:
                    time.sleep(self.backoff * (2 ** attempt))
                    continue
                raise HTTPJSONError(exc.code, payload, url) from exc
            except (URLError, TimeoutError, socket.timeout, ConnectionError, OSError) as exc:
                last_exc = exc
                if attempt + 1 < attempts:
                    time.sleep(self.backoff * (2 ** attempt))
                    continue
                raise HTTPTransientError("Falha temporária de conexão HTTPS.") from exc
        raise HTTPTransientError("Falha temporária de conexão HTTPS.") from last_exc

    def get_json(self, url: str, params=None):
        return self.request_json("GET", url, params=params)

    def post_json(self, url: str, data=None, json_data=None, timeout=None):
        return self.request_json("POST", url, data=data, json_data=json_data, timeout=timeout)

    def put_json(self, url: str, json_data=None):
        return self.request_json("PUT", url, json_data=json_data)

    def delete_json(self, url: str):
        return self.request_json("DELETE", url)
