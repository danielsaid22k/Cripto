from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from typing import Any

from .experience import BRAND_DIVIDER, interval_label, plan_group, subscription_timing
from .plans import PLANS


def _fmt_date(raw: str | None) -> str:
    if not raw:
        return "—"
    try:
        dt = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone().strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return escape(str(raw))


def build_center_text(
    *,
    user: dict[str, Any],
    stats: dict[str, Any],
    recent: list[dict[str, Any]],
    renewals: list[dict[str, Any]],
    profile: dict[str, Any],
    favorites: int,
    analyses_today: int,
) -> str:
    plan = PLANS[user["plan"]]
    group = plan_group(user.get("plan"))
    due_date, days_text, _ = subscription_timing(user)
    badge = "🆓" if group == "free" else "💠" if group == "plus" else "👑"
    risk = {
        "conservative": "Conservador",
        "moderate": "Moderado",
        "aggressive": "Agressivo",
    }[profile["risk_profile"]]
    detail = {
        "compact": "Compacto",
        "standard": "Equilibrado",
        "detailed": "Detalhado",
    }[profile["detail_mode"]]
    frequency = {
        "plan": "Padrão do plano",
        "reduced": "Reduzida",
        "priority": "Prioritária",
    }[profile["notification_frequency"]]
    chains = ", ".join(profile["preferred_chains"]) if profile["preferred_chains"] else "Todas"

    recent_lines: list[str] = []
    for row in recent[:4]:
        symbol = escape(str(row.get("symbol") or "Token"))
        pct = float(row.get("result_pct") or 0)
        state = row.get("outcome") or ("ABERTO" if row.get("status") == "OPEN" else "FECHADO")
        recent_lines.append(f"• {symbol}: <b>{escape(str(state))}</b> {pct:+.1f}%")
    if not recent_lines:
        recent_lines.append("• Nenhum sinal acompanhado ainda")

    renewal_lines: list[str] = []
    for row in renewals[:3]:
        plan_name = escape(str(row.get("plan") or "plano"))
        when = _fmt_date(row.get("activated_at") or row.get("created_at"))
        renewal_lines.append(f"• {plan_name} • {when}")
    if not renewal_lines:
        renewal_lines.append("• Nenhuma renovação confirmada registrada")

    return (
        f"{BRAND_DIVIDER}\n"
        f"{badge} <b>PHANTOM ALERT • CENTRO DE INTELIGÊNCIA</b>\n"
        f"{BRAND_DIVIDER}\n\n"
        "👤 <b>MINHA CONTA</b>\n"
        f"• Plano: <b>{plan['emoji']} {escape(plan['label'])}</b>\n"
        f"• Vencimento: <b>{due_date}</b>\n"
        f"• Dias restantes: <b>{days_text}</b>\n"
        f"• Scanner: <b>🟢 ativo • {interval_label(user.get('plan'))}</b>\n"
        f"• Sinais acompanhados: <b>{stats.get('total', 0)}</b>\n"
        f"• Favoritos: <b>{favorites}/{plan['favorites']}</b>\n"
        f"• Análises hoje: <b>{analyses_today}</b>\n\n"
        "🧭 <b>MEU PERFIL</b>\n"
        f"• Risco: <b>{risk}</b>\n"
        f"• Redes: <b>{escape(chains)}</b>\n"
        f"• Mensagens: <b>{detail}</b>\n"
        f"• Frequência: <b>{frequency}</b>\n"
        f"• Idioma: <b>{profile['language']}</b>\n\n"
        "📈 <b>HISTÓRICO INTELIGENTE</b>\n"
        + "\n".join(recent_lines)
        + "\n\n🔄 <b>RENOVAÇÕES RECENTES</b>\n"
        + "\n".join(renewal_lines)
        + "\n\n⚠️ Métricas observacionais e educacionais. Não representam garantia de retorno."
    )


def center_keyboard() -> dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {"text": "🧾 Histórico", "callback_data": "history|0"},
                {"text": "⭐ Favoritos", "callback_data": "favorites"},
            ],
            [{"text": "🎛️ Preferências", "callback_data": "preferences"}],
            [{"text": "👤 Assinatura", "callback_data": "my_plan"}],
            [{"text": "📤 Exportar meus dados", "callback_data": "export_user"}],
            [{"text": "🏠 Menu", "callback_data": "menu"}],
        ]
    }
