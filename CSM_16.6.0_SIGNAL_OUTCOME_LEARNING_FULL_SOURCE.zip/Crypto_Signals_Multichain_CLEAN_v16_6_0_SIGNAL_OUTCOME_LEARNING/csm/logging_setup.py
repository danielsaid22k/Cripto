from __future__ import annotations

import logging
import re
from logging.handlers import RotatingFileHandler
from typing import Any

from .config import settings

_SECRET_PATTERNS = (
    re.compile(r"(?i)(access_token[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"(?i)(ASAAS_API_KEY[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"(?i)(BIRDEYE_API_KEY[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"(?i)(COINGECKO_API_KEY[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"(?i)(DEXPAPRIKA_API_KEY[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"(?i)(GOPLUS_ACCESS_TOKEN[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"(?i)(TELEGRAM_BOT_TOKEN[\"'=:\s]+)([^\s,;}]+)"),
    re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\$aact_[A-Za-z0-9_$:-]{20,}"),
)


def redact(value: Any) -> str:
    text = str(value)
    for pattern in _SECRET_PATTERNS:
        if pattern.groups >= 2:
            text = pattern.sub(r"\1***REDACTED***", text)
        else:
            text = pattern.sub("***REDACTED***", text)
    for secret in (settings.asaas_api_key, settings.birdeye_api_key, settings.coingecko_api_key, settings.dexpaprika_api_key, settings.honeypot_api_key, settings.goplus_access_token, settings.telegram_token):
        if secret:
            text = text.replace(secret, "***REDACTED***")
    return text


class SecretFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            pass
        return True


def setup() -> logging.Logger:
    logger = logging.getLogger("csm_clean")
    if logger.handlers:
        return logger

    logger.setLevel(getattr(logging, settings.log_level, logging.INFO))
    formatter = logging.Formatter("[%(asctime)s] [%(levelname)s] %(message)s")
    secret_filter = SecretFilter()

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.addFilter(secret_filter)

    file_handler = RotatingFileHandler(
        settings.log_file,
        maxBytes=2_000_000,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(secret_filter)

    logger.addHandler(console)
    logger.addHandler(file_handler)
    logger.propagate = False
    return logger


logger = setup()
