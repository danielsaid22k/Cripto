from __future__ import annotations

import time
from datetime import datetime, timezone

from .http_client import SafeHTTP
from .chains import CHAINS
from .config import settings


class MarketClient:
    def __init__(self, http=None):
        self.http = http or SafeHTTP(settings.request_timeout)
        self._cache: dict[tuple[str, str], tuple[float, dict]] = {}

    def fetch(self, chain: str, address: str, force: bool = False) -> dict:
        key = (chain, address)
        cached = self._cache.get(key)
        if not force and cached and time.time() - cached[0] <= settings.cache_ttl:
            result = dict(cached[1])
            result["cached"] = True
            return result

        errors: list[str] = []

        try:
            data = self.http.get_json(f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}")
            pairs = data if isinstance(data, list) else []
            if pairs:
                result = self._normalize_dex(
                    max(pairs, key=lambda pair: float((pair.get("liquidity") or {}).get("usd") or 0))
                )
                self._cache[key] = (time.time(), result)
                return dict(result)
        except Exception as exc:
            errors.append(f"DexScreener: {exc}")

        try:
            network = CHAINS[chain]["gecko"]
            data = self.http.get_json(
                f"https://api.geckoterminal.com/api/v2/networks/{network}/tokens/{address}/pools",
                {"page": "1"},
            )
            pools = data.get("data") or []
            if pools:
                result = self._normalize_gecko(pools[0], chain, address)
                self._cache[key] = (time.time(), result)
                return dict(result)
        except Exception as exc:
            errors.append(f"GeckoTerminal: {exc}")

        raise RuntimeError("Nenhuma fonte respondeu com conexão segura. " + " | ".join(errors))

    @staticmethod
    def _normalize_dex(pair: dict) -> dict:
        created = pair.get("pairCreatedAt")
        age_days = None
        if created:
            age_days = max(0.0, (datetime.now(timezone.utc).timestamp() - created / 1000) / 86400)

        txns = pair.get("txns") or {}
        volume = pair.get("volume") or {}
        changes = pair.get("priceChange") or {}
        token = pair.get("baseToken") or {}

        return {
            "source": "DexScreener",
            "chain": pair.get("chainId"),
            "name": token.get("name", "Token"),
            "symbol": token.get("symbol", "?"),
            "address": token.get("address", ""),
            "price": float(pair.get("priceUsd") or 0),
            "liquidity": float((pair.get("liquidity") or {}).get("usd") or 0),
            "volume24h": float(volume.get("h24") or 0),
            "volume6h": float(volume.get("h6") or 0),
            "volume1h": float(volume.get("h1") or 0),
            "marketcap": float(pair.get("marketCap") or 0),
            "fdv": float(pair.get("fdv") or 0),
            "change24h": float(changes.get("h24") or 0),
            "change6h": float(changes.get("h6") or 0),
            "change1h": float(changes.get("h1") or 0),
            "buys24h": int((txns.get("h24") or {}).get("buys") or 0),
            "sells24h": int((txns.get("h24") or {}).get("sells") or 0),
            "buys6h": int((txns.get("h6") or {}).get("buys") or 0),
            "sells6h": int((txns.get("h6") or {}).get("sells") or 0),
            "buys1h": int((txns.get("h1") or {}).get("buys") or 0),
            "sells1h": int((txns.get("h1") or {}).get("sells") or 0),
            "age_days": age_days,
            "dex": pair.get("dexId", ""),
            "pair": pair.get("pairAddress", ""),
            "url": pair.get("url", ""),
            "holders": None,
            "cached": False,
        }

    @staticmethod
    def _normalize_gecko(item: dict, chain: str, address: str) -> dict:
        attrs = item.get("attributes") or {}
        txns = attrs.get("transactions") or {}
        volume = attrs.get("volume_usd") or {}
        changes = attrs.get("price_change_percentage") or {}

        return {
            "source": "GeckoTerminal",
            "chain": chain,
            "name": attrs.get("name", "Token"),
            "symbol": "?",
            "address": address,
            "price": float(attrs.get("base_token_price_usd") or 0),
            "liquidity": float(attrs.get("reserve_in_usd") or 0),
            "volume24h": float(volume.get("h24") or 0),
            "volume6h": float(volume.get("h6") or 0),
            "volume1h": float(volume.get("h1") or 0),
            "marketcap": float(attrs.get("market_cap_usd") or 0),
            "fdv": float(attrs.get("fdv_usd") or 0),
            "change24h": float(changes.get("h24") or 0),
            "change6h": float(changes.get("h6") or 0),
            "change1h": float(changes.get("h1") or 0),
            "buys24h": int((txns.get("h24") or {}).get("buys") or 0),
            "sells24h": int((txns.get("h24") or {}).get("sells") or 0),
            "buys6h": int((txns.get("h6") or {}).get("buys") or 0),
            "sells6h": int((txns.get("h6") or {}).get("sells") or 0),
            "buys1h": int((txns.get("h1") or {}).get("buys") or 0),
            "sells1h": int((txns.get("h1") or {}).get("sells") or 0),
            "age_days": None,
            "dex": "",
            "pair": item.get("id", ""),
            "url": "",
            "holders": None,
            "cached": False,
        }
