from __future__ import annotations

import json
import math
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from .config import settings

OBSERVABILITY_SCHEMA_VERSION = 1
SEVERITY_PENALTY = {"INFO": 0, "LOW": 3, "MEDIUM": 8, "HIGH": 20, "CRITICAL": 35}


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()




def _parse_iso(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (TypeError, ValueError):
        return None

def _f(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(result):
        return default
    return result


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _safe_text(value: Any, limit: int = 240) -> str:
    """Operator-safe text: remove URLs/query strings and obvious secrets."""
    text = str(value or "").strip()
    text = re.sub(r"https?://[^\s]+", "[url]", text, flags=re.I)
    text = re.sub(r"(?i)(api[_-]?key|token|secret|access[_-]?token)\s*[=:]\s*[^\s,;]+", r"\1=[redacted]", text)
    return text[: max(16, int(limit))]


def _safe_labels(labels: dict[str, Any] | None) -> dict[str, str]:
    clean: dict[str, str] = {}
    for key, value in (labels or {}).items():
        k = re.sub(r"[^a-zA-Z0-9_.-]", "_", str(key))[:40]
        if not k:
            continue
        v = _safe_text(value, 80)
        clean[k] = v
    return clean


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS ops_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            component TEXT NOT NULL,
            metric_name TEXT NOT NULL,
            value REAL NOT NULL,
            unit TEXT DEFAULT '',
            status TEXT DEFAULT 'OK',
            labels_json TEXT DEFAULT '{}',
            occurred_at TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_ops_metrics_component_time
        ON ops_metrics(component,metric_name,occurred_at DESC);
        CREATE INDEX IF NOT EXISTS idx_ops_metrics_time
        ON ops_metrics(occurred_at DESC);

        CREATE TABLE IF NOT EXISTS ops_incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_key TEXT NOT NULL UNIQUE,
            component TEXT NOT NULL,
            severity TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN',
            summary TEXT NOT NULL,
            details_json TEXT DEFAULT '{}',
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            occurrences INTEGER NOT NULL DEFAULT 1,
            last_notified_at TEXT,
            resolved_at TEXT,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_ops_incidents_status_severity
        ON ops_incidents(status,severity,last_seen DESC);

        CREATE TABLE IF NOT EXISTS ops_state (
            state_key TEXT PRIMARY KEY,
            value_json TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """
    )
    conn.commit()


class ObservabilityEngine:
    """Low-overhead local observability for mobile and VPS runtimes.

    No background thread, subprocess, webhook or mandatory external collector is
    used. The scheduler calls bounded capture methods only at safe cooperative
    points. Data stays in the persistent SQLite database and can be exposed by
    the existing authenticated/read-only dashboards/APIs.
    """

    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)

    def record_metric(
        self,
        component: str,
        metric_name: str,
        value: Any,
        *,
        unit: str = "",
        status: str = "OK",
        labels: dict[str, Any] | None = None,
        occurred_at: str | datetime | None = None,
        commit: bool = True,
    ) -> int:
        when = occurred_at.isoformat() if isinstance(occurred_at, datetime) else str(occurred_at or _iso())
        cur = self.conn.execute(
            """INSERT INTO ops_metrics(component,metric_name,value,unit,status,labels_json,occurred_at)
               VALUES(?,?,?,?,?,?,?)""",
            (
                _safe_text(component, 60).lower(),
                _safe_text(metric_name, 80).lower(),
                _f(value),
                _safe_text(unit, 24),
                _safe_text(status, 24).upper(),
                json.dumps(_safe_labels(labels), ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                when,
            ),
        )
        if commit:
            self.conn.commit()
        return int(cur.lastrowid)

    def _incident(
        self,
        key: str,
        *,
        active: bool,
        component: str,
        severity: str,
        summary: str,
        details: dict[str, Any] | None = None,
        now: datetime | None = None,
    ) -> None:
        now = now or _utc_now()
        when = _iso(now)
        key = _safe_text(key, 120).lower()
        existing = self.conn.execute("SELECT * FROM ops_incidents WHERE incident_key=?", (key,)).fetchone()
        safe_details = {str(k)[:40]: _safe_text(v, 160) for k, v in (details or {}).items()}
        if active:
            if existing:
                self.conn.execute(
                    """UPDATE ops_incidents SET component=?,severity=?,status='OPEN',summary=?,details_json=?,
                       last_seen=?,occurrences=occurrences+1,resolved_at=NULL,updated_at=CURRENT_TIMESTAMP
                       WHERE incident_key=?""",
                    (
                        _safe_text(component, 60).lower(),
                        _safe_text(severity, 16).upper(),
                        _safe_text(summary, 220),
                        json.dumps(safe_details, ensure_ascii=False, sort_keys=True),
                        when,
                        key,
                    ),
                )
            else:
                self.conn.execute(
                    """INSERT INTO ops_incidents(incident_key,component,severity,status,summary,details_json,first_seen,last_seen)
                       VALUES(?,?,?,'OPEN',?,?,?,?)""",
                    (
                        key,
                        _safe_text(component, 60).lower(),
                        _safe_text(severity, 16).upper(),
                        _safe_text(summary, 220),
                        json.dumps(safe_details, ensure_ascii=False, sort_keys=True),
                        when,
                        when,
                    ),
                )
        elif existing and str(existing["status"]).upper() == "OPEN":
            self.conn.execute(
                """UPDATE ops_incidents SET status='RESOLVED',resolved_at=?,last_seen=?,updated_at=CURRENT_TIMESTAMP
                   WHERE incident_key=?""",
                (when, when, key),
            )

    @staticmethod
    def _provider_name(row: dict[str, Any]) -> str:
        return str(row.get("name") or "provider").strip()[:80]

    @staticmethod
    def _provider_family(value: str) -> str:
        text = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
        for family in ("birdeye", "geckoterminal", "coingecko", "dexscreener", "dexpaprika", "goplus", "honeypot"):
            if text.startswith(family):
                return family
        return text.split("-", 1)[0] or "provider"

    @staticmethod
    def _is_rate_or_quota(last_error: str) -> bool:
        text = str(last_error or "").casefold()
        return any(marker in text for marker in ("http 429", "too many requests", "rate limit", "quota", "compute unit", "credits exhausted"))

    def _resolve_stale_provider_incidents(self, now: datetime) -> None:
        stale = max(300, int(getattr(settings, "observability_provider_stale_seconds", 1800)))
        cutoff = _iso(now - timedelta(seconds=stale))
        self.conn.execute(
            """UPDATE ops_incidents SET status='RESOLVED',resolved_at=?,updated_at=CURRENT_TIMESTAMP
               WHERE status='OPEN' AND component='provider' AND last_seen<?""",
            (_iso(now), cutoff),
        )

    def capture_scanner_cycle(
        self,
        stats: dict[str, Any],
        *,
        delivery_summaries: Iterable[tuple[str, dict[str, Any]]] = (),
        provider_rows: Iterable[dict[str, Any]] = (),
        network_snapshot: dict[str, Any] | None = None,
    ) -> None:
        """Persist one bounded operational snapshot after a scanner slice."""
        now = _utc_now()
        metrics = [
            ("scanner", "discovered", _i(stats.get("discovered")), "count"),
            ("scanner", "analyzed", _i(stats.get("analyzed")), "count"),
            ("scanner", "approved", _i(stats.get("approved")), "count"),
            ("scanner", "rejected", _i(stats.get("rejected")), "count"),
            ("scanner", "errors", _i(stats.get("errors")), "count"),
            ("scanner", "active_seconds", _f(stats.get("active_seconds")), "seconds"),
            ("scanner", "suspensions", _i(stats.get("suspensions")), "count"),
        ]
        for component, name, value, unit in metrics:
            self.record_metric(component, name, value, unit=unit, occurred_at=now, commit=False)

        self._incident(
            "scanner:aborted",
            active=_i(stats.get("aborted")) > 0,
            component="scanner",
            severity="HIGH",
            summary="Scanner encerrou uma fatia de forma degradada",
            details={"errors": _i(stats.get("errors")), "partial": _i(stats.get("partial"))},
            now=now,
        )

        delivery_errors = 0
        delivery_sent = 0
        rate_limit_errors = 0
        transient_errors = 0
        other_errors = 0
        unreachable = 0
        for plan, summary in delivery_summaries:
            labels = {"plan": str(plan)}
            sent = _i(summary.get("sent"))
            errors = _i(summary.get("errors"))
            rate_errors = _i(summary.get("rate_limit_errors"))
            transient = _i(summary.get("transient_errors"))
            other = _i(summary.get("other_errors"))
            unreachable_count = _i(summary.get("recipient_unreachable"))
            delivery_sent += sent
            delivery_errors += errors
            rate_limit_errors += rate_errors
            transient_errors += transient
            other_errors += other
            unreachable += unreachable_count
            self.record_metric("telegram", "signals_sent", sent, unit="count", labels=labels, occurred_at=now, commit=False)
            self.record_metric("telegram", "delivery_errors", errors, unit="count", status="WARN" if errors else "OK", labels=labels, occurred_at=now, commit=False)
            self.record_metric("telegram", "rate_limit_errors", rate_errors, unit="count", status="WARN" if rate_errors else "OK", labels=labels, occurred_at=now, commit=False)
            self.record_metric("telegram", "recipient_unreachable", unreachable_count, unit="count", status="INFO", labels=labels, occurred_at=now, commit=False)
        total_delivery = delivery_sent + delivery_errors
        error_pct = (delivery_errors / total_delivery * 100.0) if total_delivery else 0.0
        self._incident(
            "telegram:rate-limit",
            active=rate_limit_errors > 0,
            component="telegram",
            severity="HIGH",
            summary="Telegram API aplicou rate limit real (HTTP 429)",
            details={"rate_limit_errors": rate_limit_errors, "sent": delivery_sent},
            now=now,
        )
        self._incident(
            "telegram:delivery-errors",
            active=delivery_errors >= max(1, int(getattr(settings, "observability_delivery_error_count", 2)))
            or (delivery_errors > 0 and error_pct >= float(getattr(settings, "observability_delivery_error_pct", 25.0))),
            component="telegram",
            severity="HIGH" if error_pct >= 50 else "MEDIUM",
            summary="Falhas reais de entrega Telegram acima do limite operacional",
            details={
                "errors": delivery_errors, "sent": delivery_sent, "error_pct": round(error_pct, 1),
                "rate_limit": rate_limit_errors, "transient": transient_errors, "other": other_errors,
                "unreachable_suppressed": unreachable,
            },
            now=now,
        )

        seen_provider_keys: set[str] = set()
        family_limits: dict[str, dict[str, Any]] = {}
        seen_families: set[str] = set()
        latency_warn = float(getattr(settings, "observability_provider_latency_warn_ms", 2500.0))
        provider_success_warn = float(getattr(settings, "observability_provider_success_warn_pct", 70.0))
        for raw in provider_rows:
            row = dict(raw)
            if bool(row.get("diagnostic_only")):
                continue
            name = self._provider_name(row)
            key_name = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "provider"
            family = self._provider_family(name)
            seen_provider_keys.add(key_name)
            seen_families.add(family)
            status = str(row.get("status") or "ONLINE").upper()
            latency = _f(row.get("latency_ms", row.get("average_latency_ms", 0.0)))
            success_rate = _f(row.get("success_rate"), 100.0)
            failures = _i(row.get("failures"))
            self.record_metric("provider", "latency_ms", latency, unit="ms", status="WARN" if latency > latency_warn else "OK", labels={"provider": name}, occurred_at=now, commit=False)
            self.record_metric("provider", "success_rate_pct", success_rate, unit="percent", status="WARN" if success_rate < provider_success_warn else "OK", labels={"provider": name}, occurred_at=now, commit=False)
            self.record_metric("provider", "failures", failures, unit="count", labels={"provider": name}, occurred_at=now, commit=False)
            last_error = str(row.get("last_error") or "")
            rate_limited = self._is_rate_or_quota(last_error) or status in {"COOLDOWN", "QUOTA_EXHAUSTED"} and self._is_rate_or_quota(last_error)
            if rate_limited:
                current = family_limits.get(family)
                if current is None or status == "QUOTA_EXHAUSTED":
                    family_limits[family] = {"name": name, "last_error": last_error, "status": status}

            # A quota/rate event has one family-level HIGH incident below. Do not
            # double-penalize the same event with a second health/latency incident.
            degraded = (status in {"OFFLINE", "DEGRADED"} or success_rate < provider_success_warn) and not rate_limited
            severity = "CRITICAL" if status == "OFFLINE" else "MEDIUM"
            self._incident(
                f"provider:{key_name}:health",
                active=degraded,
                component="provider",
                severity=severity,
                summary=f"Provider {name} em estado {status}",
                details={"success_rate": round(success_rate, 1), "latency_ms": round(latency, 1), "last_error": last_error},
                now=now,
            )
            self._incident(
                f"provider:{key_name}:latency",
                active=(latency > latency_warn and latency > 0 and not rate_limited and status not in {"COOLDOWN", "QUOTA_EXHAUSTED"}),
                component="provider",
                severity="MEDIUM" if latency <= latency_warn * 2 else "HIGH",
                summary=f"Latência elevada em {name}",
                details={"latency_ms": round(latency, 1), "threshold_ms": latency_warn},
                now=now,
            )

        # One rate/quota incident per provider family, even when several chain
        # routes share the same account-wide quota (e.g. Birdeye Compute Units).
        for family in seen_families:
            info = family_limits.get(family)
            label = (info or {}).get("name") or family
            self._incident(
                f"provider:{family}:limit",
                active=info is not None,
                component="provider",
                severity="HIGH",
                summary=f"Limite/cota do provider {family} detectado",
                details={"provider": label, "status": (info or {}).get("status", ""), "last_error": (info or {}).get("last_error", "")},
                now=now,
            )

        self._resolve_stale_provider_incidents(now)

        network = dict(network_snapshot or {})
        if network:
            age = _f(network.get("age_seconds"))
            busy_rejections = _i(network.get("busy_rejections"))
            self.record_metric("network", "busy_age_seconds", age, unit="seconds", occurred_at=now, commit=False)
            self.record_metric("network", "busy_rejections", busy_rejections, unit="count", occurred_at=now, commit=False)
            stuck_threshold = float(getattr(settings, "observability_network_busy_warn_seconds", 15.0))
            self._incident(
                "network:bus-stuck",
                active=bool(network.get("busy")) and age >= stuck_threshold,
                component="network",
                severity="HIGH",
                summary="Barramento HTTPS permaneceu ocupado além do esperado",
                details={"owner": network.get("owner"), "kind": network.get("kind"), "age_seconds": round(age, 1)},
                now=now,
            )
        self.conn.commit()
        self.prune(commit=True)

    def record_loop_error(self, kind: str, message: str, *, component: str = "runtime") -> None:
        now = _utc_now()
        self.record_metric(component, "loop_errors", 1, unit="count", status="WARN", labels={"kind": kind}, occurred_at=now, commit=False)
        severity = "HIGH" if kind.lower() in {"telegramapierror", "sslerror", "runtimeerror"} else "MEDIUM"
        self._incident(
            f"{component}:loop:{kind.lower()}",
            active=True,
            component=component,
            severity=severity,
            summary=f"Erro isolado no loop: {kind}",
            details={"message": message},
            now=now,
        )
        self.conn.commit()

    def heartbeat(self, *, network_snapshot: dict[str, Any] | None = None, scanner_active: bool = False) -> None:
        now = _utc_now()
        self.record_metric("runtime", "heartbeat", 1, unit="count", labels={"scanner_active": int(bool(scanner_active))}, occurred_at=now, commit=False)
        if network_snapshot:
            self.record_metric("network", "busy", 1 if network_snapshot.get("busy") else 0, unit="bool", occurred_at=now, commit=False)
        # Loop exceptions are transient incidents. A healthy heartbeat after a
        # quiet window closes them automatically instead of leaving stale red
        # alarms in the operations dashboard forever.
        cutoff = _iso(now - timedelta(seconds=max(120, int(getattr(settings, "observability_runtime_interval", 60)) * 3)))
        self.conn.execute(
            """UPDATE ops_incidents SET status='RESOLVED',resolved_at=?,updated_at=CURRENT_TIMESTAMP
               WHERE status='OPEN' AND incident_key LIKE '%:loop:%' AND last_seen<?""",
            (_iso(now), cutoff),
        )
        self.conn.commit()

    def notification_candidates(self, *, cooldown_seconds: int | None = None, limit: int = 5) -> list[dict[str, Any]]:
        """Return current alert candidates with provider-family dedupe/cooldown.

        Rate/quota faults used to generate both ``:limit`` and route ``:health``
        alerts.  V16.5.8 treats the provider family limit as the single alert
        authority and gives it a longer cooldown so 429/quota flapping does not
        spam the admin Telegram channel.
        """
        now = _utc_now()
        self._resolve_stale_provider_incidents(now)
        self.conn.commit()
        normal_cooldown = max(300, int(cooldown_seconds or getattr(settings, "observability_admin_alert_cooldown", 1800)))
        provider_limit_cooldown = max(normal_cooldown, int(getattr(settings, "observability_provider_limit_alert_cooldown", 21600)))
        rows = [row for row in self._current_effective_open_incidents(now) if str(row.get("severity") or "").upper() in {"HIGH", "CRITICAL"}]
        selected: list[dict[str, Any]] = []
        seen_provider_families: set[str] = set()
        for row in rows:
            key = str(row.get("incident_key") or "")
            last = _parse_iso(row.get("last_notified_at"))
            required = provider_limit_cooldown if row.get("component") == "provider" and key.endswith(":limit") else normal_cooldown
            if last is not None and (now - last).total_seconds() < required:
                continue
            if row.get("component") == "provider":
                family = self._incident_provider_family(row)
                if family in seen_provider_families:
                    continue
                seen_provider_families.add(family)
            selected.append(row)
            if len(selected) >= max(1, min(int(limit), 20)):
                break
        return selected

    def mark_notified(self, incident_ids: Iterable[int]) -> None:
        ids = [int(x) for x in incident_ids if int(x) > 0]
        if not ids:
            return
        now = _iso()
        self.conn.executemany(
            "UPDATE ops_incidents SET last_notified_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
            [(now, i) for i in ids],
        )
        self.conn.commit()

    def recovery_candidates(self, *, limit: int = 5) -> list[dict[str, Any]]:
        """Provider recoveries after a stability window, deduped by family.

        A short healthy observation must remain resolved for the configured
        window before a recovery Telegram is emitted. This removes the old
        down/up/down notification loop around rate-limit boundaries.
        """
        stable = max(60, int(getattr(settings, "observability_provider_recovery_stable_seconds", 600)))
        cutoff = _iso(_utc_now() - timedelta(seconds=stable))
        rows = self.conn.execute(
            """SELECT * FROM ops_incidents
               WHERE status='RESOLVED' AND component='provider'
                 AND severity IN ('HIGH','CRITICAL')
                 AND last_notified_at IS NOT NULL AND resolved_at IS NOT NULL
                 AND resolved_at>last_notified_at AND resolved_at<=?
               ORDER BY resolved_at DESC""",
            (cutoff,),
        ).fetchall()
        selected: list[dict[str, Any]] = []
        seen: set[str] = set()
        for raw in rows:
            row = dict(raw)
            family = self._incident_provider_family(row)
            if family in seen:
                continue
            seen.add(family)
            selected.append(row)
            if len(selected) >= max(1, min(int(limit), 20)):
                break
        return selected

    def mark_recovery_notified(self, incident_ids: Iterable[int]) -> None:
        ids = [int(x) for x in incident_ids if int(x) > 0]
        if not ids:
            return
        now = _iso()
        # Use resolved_at as the acknowledgement cursor when available. This
        # makes the operation idempotent even if clocks/test fixtures place the
        # resolution a few seconds ahead of the caller's current timestamp.
        self.conn.executemany(
            """UPDATE ops_incidents
               SET last_notified_at=COALESCE(resolved_at,?),updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            [(now, i) for i in ids],
        )
        self.conn.commit()

    def prune(self, *, commit: bool = True) -> int:
        retention = max(1, int(getattr(settings, "observability_retention_days", 30)))
        cutoff = _iso(_utc_now() - timedelta(days=retention))
        cur = self.conn.execute("DELETE FROM ops_metrics WHERE occurred_at<?", (cutoff,))
        # Resolved incidents are retained longer for operational due diligence.
        incident_cutoff = _iso(_utc_now() - timedelta(days=max(retention * 3, 90)))
        self.conn.execute("DELETE FROM ops_incidents WHERE status='RESOLVED' AND resolved_at IS NOT NULL AND resolved_at<?", (incident_cutoff,))
        if commit:
            self.conn.commit()
        return int(cur.rowcount or 0)

    def _incident_provider_family(self, row: dict[str, Any]) -> str:
        key = str(row.get("incident_key") or "")
        if key.startswith("provider:"):
            middle = key[len("provider:"):].rsplit(":", 1)[0]
            return self._provider_family(middle)
        return self._provider_family(str(row.get("summary") or "provider"))

    def _effective_open_incidents(self) -> list[dict[str, Any]]:
        """Open incidents that should affect current health and alerts."""
        rows = self._open_incidents()
        limit_families = {
            self._incident_provider_family(row)
            for row in rows
            if row.get("component") == "provider" and str(row.get("incident_key") or "").endswith(":limit")
        }
        effective: list[dict[str, Any]] = []
        for row in rows:
            if row.get("component") != "provider":
                effective.append(row)
                continue
            family = self._incident_provider_family(row)
            key = str(row.get("incident_key") or "")
            try:
                details = json.loads(str(row.get("details_json") or "{}"))
            except Exception:
                details = {}
            summary = str(row.get("summary") or "")
            last_error = str(details.get("last_error") or "")
            duplicate_limit_health = (
                family in limit_families
                and key.endswith(":health")
                and (self._is_rate_or_quota(last_error) or "COOLDOWN" in summary.upper() or "QUOTA_EXHAUSTED" in summary.upper())
            )
            if not duplicate_limit_health:
                effective.append(row)
        return effective

    def _current_effective_open_incidents(self, now: datetime | None = None) -> list[dict[str, Any]]:
        """Incidents that should affect *current* health.

        Provider incident history is intentionally longer-lived than the live
        health window. A provider fault can remain auditable OPEN until stale
        cleanup while no longer making a currently healthy runtime CRITICAL.
        """
        now = now or _utc_now()
        provider_window = max(60, int(getattr(settings, "observability_current_provider_window_seconds", 300)))
        current: list[dict[str, Any]] = []
        for row in self._effective_open_incidents():
            if row.get("component") != "provider":
                current.append(row)
                continue
            last_seen = _parse_iso(row.get("last_seen"))
            if last_seen is not None and (now - last_seen).total_seconds() <= provider_window:
                current.append(row)
        return current

    def _open_incidents(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT * FROM ops_incidents WHERE status='OPEN'
               ORDER BY CASE severity WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 WHEN 'LOW' THEN 3 ELSE 4 END,
                        last_seen DESC"""
        ).fetchall()
        return [dict(r) for r in rows]

    def status(self, *, days: int = 7) -> dict[str, Any]:
        now = _utc_now()
        cutoff = _iso(now - timedelta(days=max(1, int(days))))
        self._resolve_stale_provider_incidents(now)
        self.conn.commit()
        raw_incidents = self._open_incidents()
        effective_incidents = self._effective_open_incidents()
        incidents = self._current_effective_open_incidents(now)
        historical_incidents = [row for row in effective_incidents if int(row.get("id") or 0) not in {int(x.get("id") or 0) for x in incidents}]
        penalty = sum(SEVERITY_PENALTY.get(str(row.get("severity") or "INFO").upper(), 0) for row in incidents)
        health = max(0, 100 - penalty)
        metrics_count = _i(self.conn.execute("SELECT COUNT(*) FROM ops_metrics WHERE occurred_at>=?", (cutoff,)).fetchone()[0])
        components = [r[0] for r in self.conn.execute("SELECT DISTINCT component FROM ops_metrics WHERE occurred_at>=? ORDER BY component", (cutoff,)).fetchall()]
        last_metric = self.conn.execute("SELECT occurred_at FROM ops_metrics ORDER BY id DESC LIMIT 1").fetchone()
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for row in incidents:
            sev = str(row.get("severity") or "INFO").upper()
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        state = "HEALTHY" if health >= 90 else "DEGRADED" if health >= 70 else "AT_RISK" if health >= 50 else "CRITICAL"
        return {
            "version": "16.6.0-signal-outcome-learning",
            "mode": "local-cooperative-no-public-webhook",
            "health_score": health,
            "state": state,
            "metrics": metrics_count,
            "components": components,
            "open_incidents": len(incidents),
            "current_open_incidents": len(incidents),
            "historical_open_incidents": len(historical_incidents),
            "effective_open_incidents": len(effective_incidents),
            "raw_open_incidents": len(raw_incidents),
            "deduplicated_incidents": max(0, len(raw_incidents) - len(effective_incidents)),
            "severity_counts": severity_counts,
            "last_metric_at": last_metric[0] if last_metric else None,
            "retention_days": max(1, int(getattr(settings, "observability_retention_days", 30))),
            "admin_alerts": bool(getattr(settings, "observability_admin_alerts", True)),
        }

    def report(self, *, days: int = 7, limit: int = 50) -> dict[str, Any]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        limit = max(1, min(int(limit), 500))
        summary_rows = self.conn.execute(
            """SELECT component,metric_name,COUNT(*) samples,AVG(value) avg_value,MIN(value) min_value,MAX(value) max_value,
                      MAX(occurred_at) last_at
               FROM ops_metrics WHERE occurred_at>=?
               GROUP BY component,metric_name ORDER BY component,metric_name""",
            (cutoff,),
        ).fetchall()
        incidents = self.conn.execute(
            """SELECT * FROM ops_incidents WHERE last_seen>=? OR status='OPEN'
               ORDER BY id DESC LIMIT ?""",
            (cutoff, limit),
        ).fetchall()
        latest = self.conn.execute(
            """SELECT component,metric_name,value,unit,status,labels_json,occurred_at
               FROM ops_metrics WHERE occurred_at>=? ORDER BY id DESC LIMIT ?""",
            (cutoff, limit),
        ).fetchall()
        def decode(row):
            d = dict(row)
            if "labels_json" in d:
                try:
                    d["labels"] = json.loads(d.pop("labels_json") or "{}")
                except Exception:
                    d["labels"] = {}
            if "details_json" in d:
                try:
                    d["details"] = json.loads(d.pop("details_json") or "{}")
                except Exception:
                    d["details"] = {}
            return d
        return {
            "status": self.status(days=days),
            "metric_summary": [decode(r) for r in summary_rows],
            "incidents": [decode(r) for r in incidents],
            "latest_metrics": [decode(r) for r in latest],
        }

    def incidents(self, *, open_only: bool = False, limit: int = 100) -> list[dict[str, Any]]:
        sql = "SELECT * FROM ops_incidents"
        params: list[Any] = []
        if open_only:
            sql += " WHERE status='OPEN'"
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(max(1, min(int(limit), 1000)))
        rows = self.conn.execute(sql, params).fetchall()
        output = []
        for row in rows:
            d = dict(row)
            try:
                d["details"] = json.loads(d.pop("details_json") or "{}")
            except Exception:
                d["details"] = {}
            output.append(d)
        return output

    def prometheus_text(self, *, days: int = 1) -> str:
        """Return a local Prometheus/OpenMetrics-style snapshot without server dependency."""
        report = self.report(days=days, limit=1)
        lines = [
            "# CSM V14.5 local observability export",
            f"csm_health_score {int(report['status']['health_score'])}",
            f"csm_open_incidents {int(report['status']['open_incidents'])}",
        ]
        for row in report["metric_summary"]:
            component = re.sub(r"[^a-z0-9_]", "_", str(row["component"]).lower())
            metric = re.sub(r"[^a-z0-9_]", "_", str(row["metric_name"]).lower())
            name = f"csm_{component}_{metric}"
            lines.append(f"{name}_avg {float(row['avg_value'] or 0):.6f}")
            lines.append(f"{name}_max {float(row['max_value'] or 0):.6f}")
            lines.append(f"{name}_samples {int(row['samples'] or 0)}")
        return "\n".join(lines) + "\n"

    def export(self, path: str | Path, *, days: int = 7, fmt: str = "json") -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        if str(fmt).lower() in {"prom", "prometheus", "openmetrics"}:
            target.write_text(self.prometheus_text(days=days), encoding="utf-8")
        else:
            target.write_text(json.dumps(self.report(days=days, limit=500), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        return target
