from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import Any

from .config import settings

ONCHAIN_SCHEMA_VERSION = 1


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        text = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def event_key(chain: str, address: str, event_type: str, txid: str = "", ordinal: str = "") -> str:
    raw = "|".join((str(chain).lower(), str(address).lower(), str(event_type), str(txid), str(ordinal)))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS onchain_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            captured_bucket INTEGER NOT NULL,
            captured_at TEXT NOT NULL,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            source TEXT DEFAULT '',
            onchain_score INTEGER DEFAULT 100,
            risk_level TEXT DEFAULT 'LOW',
            top10_holders_pct REAL,
            transfer_count INTEGER DEFAULT 0,
            unique_wallets INTEGER DEFAULT 0,
            whale_transfer_count INTEGER DEFAULT 0,
            whale_volume_usd REAL DEFAULT 0,
            mint_events INTEGER DEFAULT 0,
            burn_events INTEGER DEFAULT 0,
            liquidity REAL DEFAULT 0,
            liquidity_change_pct REAL DEFAULT 0,
            deployer_address TEXT DEFAULT '',
            deployer_score INTEGER,
            activity_count INTEGER DEFAULT 0,
            notes_json TEXT DEFAULT '[]',
            UNIQUE(signal_id, captured_bucket),
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_onchain_snapshots_signal
        ON onchain_snapshots(signal_id, captured_at DESC);
        CREATE INDEX IF NOT EXISTS idx_onchain_snapshots_chain
        ON onchain_snapshots(chain, captured_at DESC);

        CREATE TABLE IF NOT EXISTS onchain_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            event_key TEXT NOT NULL UNIQUE,
            event_type TEXT NOT NULL,
            severity TEXT DEFAULT 'INFO',
            wallet_address TEXT DEFAULT '',
            counterparty TEXT DEFAULT '',
            txid TEXT DEFAULT '',
            block_ref TEXT DEFAULT '',
            amount_token REAL DEFAULT 0,
            amount_usd REAL DEFAULT 0,
            details_json TEXT DEFAULT '{}',
            occurred_at TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_onchain_events_signal
        ON onchain_events(signal_id, occurred_at DESC);
        CREATE INDEX IF NOT EXISTS idx_onchain_events_wallet
        ON onchain_events(chain, wallet_address, occurred_at DESC);

        CREATE TRIGGER IF NOT EXISTS trg_onchain_events_no_update
        BEFORE UPDATE ON onchain_events
        BEGIN SELECT RAISE(ABORT, 'onchain events are append-only'); END;
        CREATE TRIGGER IF NOT EXISTS trg_onchain_events_no_delete
        BEFORE DELETE ON onchain_events
        BEGIN SELECT RAISE(ABORT, 'onchain events are append-only'); END;

        CREATE TABLE IF NOT EXISTS onchain_cursors (
            signal_id INTEGER NOT NULL,
            source TEXT NOT NULL,
            cursor_value TEXT DEFAULT '',
            state_json TEXT DEFAULT '{}',
            last_checked_at TEXT,
            error_count INTEGER DEFAULT 0,
            last_error TEXT DEFAULT '',
            PRIMARY KEY(signal_id, source),
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS wallet_profiles (
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            role TEXT DEFAULT 'observed',
            total_events INTEGER DEFAULT 0,
            whale_events INTEGER DEFAULT 0,
            risky_events INTEGER DEFAULT 0,
            positive_events INTEGER DEFAULT 0,
            reputation_score INTEGER DEFAULT 50,
            first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
            last_seen TEXT DEFAULT CURRENT_TIMESTAMP,
            notes_json TEXT DEFAULT '[]',
            PRIMARY KEY(chain, address)
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_profiles_score
        ON wallet_profiles(chain, reputation_score, total_events DESC);
        """
    )
    conn.commit()


class OnChainLedger:
    """Persistent post-signal on-chain intelligence store.

    This layer is advisory. It never changes the original signal decision and
    never overrides GoPlus blockers. Snapshots are observations; raw events are
    append-only and deduplicated by a deterministic event key.
    """

    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)

    def due_signals(self, *, limit: int = 10, minimum_gap_seconds: int | None = None) -> list[dict[str, Any]]:
        gap = max(60, int(minimum_gap_seconds or settings.onchain_monitor_interval))
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(settings.onchain_monitor_days))))
        rows = self.conn.execute(
            """SELECT s.*, MAX(o.captured_at) AS last_onchain_at
               FROM signal_ledger s
               LEFT JOIN onchain_snapshots o ON o.signal_id=s.id
               WHERE s.created_at>=?
               GROUP BY s.id
               ORDER BY COALESCE(last_onchain_at, s.created_at) ASC
               LIMIT ?""",
            (cutoff, max(1, int(limit))),
        ).fetchall()
        now = _utc_now()
        due: list[dict[str, Any]] = []
        for row in rows:
            data = dict(row)
            last = _parse(data.get("last_onchain_at"))
            if last is None or (now - last).total_seconds() >= gap:
                due.append(data)
        return due

    def cursor(self, signal_id: int, source: str) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM onchain_cursors WHERE signal_id=? AND source=?",
            (int(signal_id), str(source)),
        ).fetchone()
        if not row:
            return {"signal_id": int(signal_id), "source": str(source), "cursor_value": "", "state": {}}
        data = dict(row)
        try:
            data["state"] = json.loads(str(data.get("state_json") or "{}"))
        except Exception:
            data["state"] = {}
        return data

    def set_cursor(self, signal_id: int, source: str, cursor_value: str = "", *, state: dict[str, Any] | None = None, error: str = "") -> None:
        current = self.cursor(signal_id, source)
        failures = _i(current.get("error_count")) + (1 if error else 0)
        if not error:
            failures = 0
        self.conn.execute(
            """INSERT INTO onchain_cursors(signal_id,source,cursor_value,state_json,last_checked_at,error_count,last_error)
               VALUES(?,?,?,?,?,?,?)
               ON CONFLICT(signal_id,source) DO UPDATE SET
                 cursor_value=excluded.cursor_value,state_json=excluded.state_json,
                 last_checked_at=excluded.last_checked_at,error_count=excluded.error_count,
                 last_error=excluded.last_error""",
            (int(signal_id), str(source), str(cursor_value or ""), _json(state or {}), _iso(), failures, str(error or "")[:240]),
        )
        self.conn.commit()

    def latest_market_snapshot(self, signal_id: int, *, fallback_price: float = 0.0, fallback_liquidity: float = 0.0) -> dict[str, float]:
        row = self.conn.execute(
            "SELECT price,liquidity FROM signal_observations WHERE signal_id=? ORDER BY captured_at DESC LIMIT 1",
            (int(signal_id),),
        ).fetchone()
        return {
            "price": _f(row[0]) if row and _f(row[0]) > 0 else _f(fallback_price),
            "liquidity": _f(row[1]) if row and _f(row[1]) > 0 else _f(fallback_liquidity),
        }

    def _latest_liquidity(self, signal_id: int, fallback: float) -> float:
        return self.latest_market_snapshot(signal_id, fallback_liquidity=fallback).get("liquidity", _f(fallback))

    def score_snapshot(self, signal: dict[str, Any], metrics: dict[str, Any]) -> dict[str, Any]:
        score = 100
        notes: list[str] = []
        top10 = metrics.get("top10_holders_pct")
        if top10 is not None:
            top10f = _f(top10)
            if top10f >= 80:
                score -= 35; notes.append(f"top10 concentration critical ({top10f:.1f}%)")
            elif top10f >= 60:
                score -= 22; notes.append(f"top10 concentration high ({top10f:.1f}%)")
            elif top10f >= 45:
                score -= 10; notes.append(f"top10 concentration elevated ({top10f:.1f}%)")

        base_liq = _f(signal.get("liquidity"))
        current_liq = self._latest_liquidity(_i(signal.get("id")), base_liq)
        liq_change = ((current_liq / base_liq) - 1.0) * 100.0 if base_liq > 0 and current_liq > 0 else 0.0
        if liq_change <= -50:
            score -= 45; notes.append(f"liquidity collapsed {liq_change:.1f}%")
        elif liq_change <= -30:
            score -= 30; notes.append(f"liquidity fell {liq_change:.1f}%")
        elif liq_change <= -15:
            score -= 15; notes.append(f"liquidity weakened {liq_change:.1f}%")

        whale_count = _i(metrics.get("whale_transfer_count"))
        whale_volume = _f(metrics.get("whale_volume_usd"))
        if whale_count >= 5:
            score -= 10; notes.append(f"{whale_count} large transfers in monitored window")
        if whale_volume >= max(50000.0, float(settings.onchain_whale_min_usd) * 5):
            score -= 8; notes.append(f"large transfer volume ${whale_volume:,.0f}")

        mint_events = _i(metrics.get("mint_events"))
        if mint_events:
            score -= min(30, mint_events * 15); notes.append(f"supply/mint expansion events={mint_events}")

        risky = _i(metrics.get("deployer_risky_events"))
        if risky:
            score -= min(40, risky * 25); notes.append(f"deployer risky events={risky}")

        score = max(0, min(100, int(score)))
        risk = "LOW" if score >= 85 else "MODERATE" if score >= 70 else "HIGH" if score >= 50 else "CRITICAL"
        return {
            **metrics,
            "onchain_score": score,
            "risk_level": risk,
            "liquidity": current_liq,
            "liquidity_change_pct": round(liq_change, 2),
            "notes": notes,
        }

    def record_snapshot(self, signal: dict[str, Any], metrics: dict[str, Any], *, captured_at: datetime | None = None) -> int | None:
        captured_at = captured_at or _utc_now()
        enriched = self.score_snapshot(signal, metrics)
        bucket = int(captured_at.timestamp()) // max(60, int(settings.onchain_snapshot_bucket_seconds))
        try:
            cur = self.conn.execute(
                """INSERT INTO onchain_snapshots(
                    signal_id,captured_bucket,captured_at,chain,address,source,onchain_score,risk_level,
                    top10_holders_pct,transfer_count,unique_wallets,whale_transfer_count,whale_volume_usd,
                    mint_events,burn_events,liquidity,liquidity_change_pct,deployer_address,deployer_score,
                    activity_count,notes_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    _i(signal.get("id")), bucket, _iso(captured_at), str(signal.get("chain") or "").lower(),
                    str(signal.get("address") or ""), str(enriched.get("source") or "")[:80],
                    _i(enriched.get("onchain_score"), 100), str(enriched.get("risk_level") or "LOW"),
                    enriched.get("top10_holders_pct"), _i(enriched.get("transfer_count")),
                    _i(enriched.get("unique_wallets")), _i(enriched.get("whale_transfer_count")),
                    _f(enriched.get("whale_volume_usd")), _i(enriched.get("mint_events")),
                    _i(enriched.get("burn_events")), _f(enriched.get("liquidity")),
                    _f(enriched.get("liquidity_change_pct")), str(signal.get("goplus_creator_address") or signal.get("goplus_owner_address") or "")[:128],
                    enriched.get("deployer_score"), _i(enriched.get("activity_count")), _json(enriched.get("notes") or []),
                ),
            )
            self.conn.commit()
            return int(cur.lastrowid)
        except Exception as exc:
            if "UNIQUE constraint failed" in str(exc):
                return None
            raise

    def record_event(self, signal: dict[str, Any], *, event_type: str, txid: str = "", ordinal: str = "", severity: str = "INFO", wallet_address: str = "", counterparty: str = "", block_ref: str = "", amount_token: float = 0.0, amount_usd: float = 0.0, details: dict[str, Any] | None = None, occurred_at: datetime | None = None) -> bool:
        chain = str(signal.get("chain") or "").lower()
        address = str(signal.get("address") or "")
        key = event_key(chain, address, event_type, txid, ordinal)
        try:
            self.conn.execute(
                """INSERT INTO onchain_events(signal_id,chain,address,event_key,event_type,severity,wallet_address,
                   counterparty,txid,block_ref,amount_token,amount_usd,details_json,occurred_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (_i(signal.get("id")), chain, address, key, str(event_type), str(severity), str(wallet_address)[:128],
                 str(counterparty)[:128], str(txid)[:160], str(block_ref)[:80], _f(amount_token), _f(amount_usd),
                 _json(details or {}), _iso(occurred_at)),
            )
            self.conn.commit()
        except Exception as exc:
            if "UNIQUE constraint failed" in str(exc):
                return False
            raise
        if wallet_address:
            self.update_wallet_profile(chain, wallet_address, role="deployer" if wallet_address == (signal.get("goplus_creator_address") or signal.get("goplus_owner_address")) else "observed", event_type=event_type, severity=severity)
        return True

    def update_wallet_profile(self, chain: str, address: str, *, role: str = "observed", event_type: str = "", severity: str = "INFO") -> None:
        addr = str(address or "").strip()
        if not addr:
            return
        current = self.conn.execute("SELECT * FROM wallet_profiles WHERE chain=? AND address=?", (chain, addr)).fetchone()
        total = (_i(current["total_events"]) if current else 0) + 1
        whale = (_i(current["whale_events"]) if current else 0) + int("whale" in event_type)
        risky = (_i(current["risky_events"]) if current else 0) + int(str(severity).upper() in {"HIGH", "CRITICAL"})
        positive = _i(current["positive_events"]) if current else 0
        score = max(0, min(100, round(50 + min(20, positive * 2) - min(45, risky * 9) - min(15, whale))))
        self.conn.execute(
            """INSERT INTO wallet_profiles(chain,address,role,total_events,whale_events,risky_events,positive_events,reputation_score,first_seen,last_seen)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(chain,address) DO UPDATE SET role=excluded.role,total_events=excluded.total_events,
               whale_events=excluded.whale_events,risky_events=excluded.risky_events,positive_events=excluded.positive_events,
               reputation_score=excluded.reputation_score,last_seen=excluded.last_seen""",
            (chain, addr, role, total, whale, risky, positive, score, _iso(), _iso()),
        )
        self.conn.commit()

    def latest_snapshot(self, signal_id: int) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM onchain_snapshots WHERE signal_id=? ORDER BY captured_at DESC LIMIT 1", (int(signal_id),)).fetchone()
        return dict(row) if row else None

    def status(self, *, days: int = 30) -> dict[str, Any]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        signals = _i(self.conn.execute("SELECT COUNT(DISTINCT signal_id) FROM onchain_snapshots WHERE captured_at>=?", (cutoff,)).fetchone()[0])
        snaps = _i(self.conn.execute("SELECT COUNT(*) FROM onchain_snapshots WHERE captured_at>=?", (cutoff,)).fetchone()[0])
        events = _i(self.conn.execute("SELECT COUNT(*) FROM onchain_events WHERE occurred_at>=?", (cutoff,)).fetchone()[0])
        critical = _i(self.conn.execute("SELECT COUNT(*) FROM onchain_snapshots WHERE captured_at>=? AND risk_level='CRITICAL'", (cutoff,)).fetchone()[0])
        whales = _i(self.conn.execute("SELECT COUNT(*) FROM onchain_events WHERE occurred_at>=? AND event_type LIKE 'whale_%'", (cutoff,)).fetchone()[0])
        wallets = _i(self.conn.execute("SELECT COUNT(*) FROM wallet_profiles").fetchone()[0])
        avg = self.conn.execute("SELECT AVG(onchain_score) FROM onchain_snapshots WHERE captured_at>=?", (cutoff,)).fetchone()[0]
        configured_evm = [chain for chain in ("ethereum","bsc","base","arbitrum","polygon","avalanche","optimism","fantom","cronos") if settings.evm_rpc_url(chain)]
        return {
            "days": days, "signals_monitored": signals, "snapshots": snaps, "events": events,
            "critical_snapshots": critical, "whale_events": whales, "wallet_profiles": wallets,
            "average_onchain_score": round(_f(avg), 2) if avg is not None else None,
            "mode": "outbound-polling-only", "public_webhooks": False,
            "solana_ready": bool(settings.helius_ready), "evm_ready": configured_evm,
        }

    def report(self, *, days: int = 30, limit: int = 50) -> dict[str, Any]:
        summary = self.status(days=days)
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        rows = self.conn.execute(
            """SELECT s.symbol,s.chain,s.address,o.* FROM onchain_snapshots o
               JOIN signal_ledger s ON s.id=o.signal_id WHERE o.captured_at>=?
               ORDER BY o.captured_at DESC LIMIT ?""",
            (cutoff, max(1, int(limit))),
        ).fetchall()
        profiles = self.conn.execute(
            """SELECT chain,address,role,total_events,whale_events,risky_events,reputation_score,last_seen
               FROM wallet_profiles ORDER BY risky_events DESC,reputation_score ASC,total_events DESC LIMIT ?""",
            (max(1, min(100, int(limit))),),
        ).fetchall()
        return {"summary": summary, "latest": [dict(row) for row in rows], "wallet_profiles": [dict(row) for row in profiles]}
