from __future__ import annotations
import re
from typing import Any
from .config import settings
from .logging_setup import logger
from .payments import AsaasClient, PAID_STATUSES, TERMINAL_STATUSES
from .plans import PLANS, normalize_plan

def only_digits(value:str)->str: return re.sub(r"\D","",value or "")
def valid_cpf(value:str)->bool:
    cpf=only_digits(value)
    if len(cpf)!=11 or cpf==cpf[0]*11:return False
    for size in (9,10):
        total=sum(int(cpf[i])*(size+1-i) for i in range(size)); digit=(total*10)%11; digit=0 if digit==10 else digit
        if digit!=int(cpf[size]):return False
    return True
def valid_cnpj(value:str)->bool:
    cnpj=only_digits(value)
    if len(cnpj)!=14 or cnpj==cnpj[0]*14:return False
    def calc(base,weights):
        rem=sum(int(n)*w for n,w in zip(base,weights))%11; return 0 if rem<2 else 11-rem
    return calc(cnpj[:12],[5,4,3,2,9,8,7,6,5,4,3,2])==int(cnpj[12]) and calc(cnpj[:13],[6,5,4,3,2,9,8,7,6,5,4,3,2])==int(cnpj[13])
def valid_document(value:str)->bool:
    d=only_digits(value); return valid_cpf(d) if len(d)==11 else valid_cnpj(d) if len(d)==14 else False

class PaymentService:
    def __init__(self,storage,client:AsaasClient|None=None): self.storage=storage; self.client=client or AsaasClient()
    def _customer_id(self,*,user_id:int,name:str,cpf_cnpj:str)->str:
        user=self.storage.get_user(user_id); saved=str(user.get("asaas_customer_id") or "")
        if saved:
            try:
                remote=self.client.customer(saved)
                if str(remote.get("id") or "")==saved:return saved
            except Exception:
                pass
            try:self.storage.set_asaas_customer(user_id,"")
            except Exception:pass
        reference=f"csm-user:{user_id}"; customers=self.client.customers_by_reference(reference)
        customer=customers[0] if customers else self.client.create_customer(name=name or f"Cliente Telegram {user_id}",cpf_cnpj=only_digits(cpf_cnpj),reference=reference)
        customer_id=str(customer.get("id") or "")
        if not customer_id:raise RuntimeError("O Asaas não retornou o ID do cliente.")
        self.storage.set_asaas_customer(user_id,customer_id); return customer_id
    def create_payment(self,*,user_id:int,plan:str,name:str,cpf_cnpj:str,billing_type:str)->dict[str,Any]:
        plan=normalize_plan(plan)
        billing_type=str(billing_type or "").upper()
        if plan=="free": raise ValueError("Plano inválido.")
        if billing_type not in settings.asaas_payment_methods:
            raise ValueError("Forma de pagamento não habilitada.")
        if not valid_document(cpf_cnpj): raise ValueError("CPF ou CNPJ inválido.")

        existing=self.storage.latest_open_payment(user_id,plan,billing_type)
        if existing and existing.get("invoice_url"):
            return existing

        customer_id=self._customer_id(
            user_id=user_id,
            name=name,
            cpf_cnpj=cpf_cnpj,
        )
        remote=self.client.create_payment(
            customer_id=customer_id,
            user_id=user_id,
            plan=plan,
            billing_type=billing_type,
        )
        payment_id=str(remote.get("id") or "")
        invoice_url=str(remote.get("invoiceUrl") or remote.get("bankSlipUrl") or "")
        status=str(remote.get("status") or "PENDING").upper()
        if not payment_id or not invoice_url:
            raise RuntimeError("O Asaas não retornou o ID e o link da cobrança.")

        self.storage.save_payment(
            payment_id=payment_id,
            user_id=user_id,
            plan=plan,
            invoice_url=invoice_url,
            external_reference=f"csm:{user_id}:{plan}:{billing_type.lower()}",
            status=status,
            billing_type=billing_type,
        )
        row=self.storage.get_payment(payment_id) or {}
        if billing_type=="PIX":
            try:
                pix=self.client.pix_qr_code(payment_id)
                row["pix_payload"]=str(pix.get("payload") or "")
                row["pix_expiration"]=str(pix.get("expirationDate") or "")
            except Exception as exc:
                logger.warning("Não foi possível obter o PIX copia e cola: %s",exc)
        return row

    def verify_payment(self,payment_id:str)->dict[str,Any]:
        row=self.storage.get_payment(payment_id)
        if not row:raise RuntimeError("Cobrança não encontrada.")
        local_status=str(row.get("status") or "").upper()
        if row.get("activated_at") and local_status in PAID_STATUSES:
            return {"state":"active","status":local_status,"plan":row["plan"],"payment_id":payment_id}
        # Crash recovery: if Asaas had already been persisted as paid but the
        # process stopped before activate_payment(), complete activation locally.
        if local_status in PAID_STATUSES and not row.get("activated_at"):
            days=PLANS[normalize_plan(row["plan"])]["days"]
            self.storage.activate_payment(payment_id,days=days)
            return {"state":"activated","status":local_status,"plan":row["plan"],"payment_id":payment_id,"recovered":True}
        status=self.client.payment_status(payment_id); self.storage.update_payment_status(payment_id,status)
        if status in PAID_STATUSES:
            days=PLANS[normalize_plan(row["plan"])]["days"]; self.storage.activate_payment(payment_id,days=days)
            return {"state":"activated","status":status,"plan":row["plan"],"payment_id":payment_id}
        if status in TERMINAL_STATUSES:return {"state":"failed","status":status,"plan":row["plan"],"payment_id":payment_id}
        return {"state":"pending","status":status,"plan":row["plan"],"payment_id":payment_id}
    def verify_user(self,user_id:int)->list[dict[str,Any]]:
        results=[]
        for row in self.storage.open_payments(user_id=user_id,limit=20):
            try:
                results.append(self.verify_payment(row["payment_id"]))
            except Exception as exc:
                logger.warning("Falha ao verificar cobrança %s: %s",row["payment_id"],exc)
        return results
    def sync_all(self,limit:int=100)->dict[str,Any]:
        summary={"checked":0,"activated":0,"errors":0,"activations":[]}
        for payment in self.storage.open_payments(limit=max(1,limit)):
            try:
                result=self.verify_payment(str(payment["payment_id"]))
                summary["checked"]+=1
                if result["state"]=="activated":
                    summary["activated"]+=1
                    summary["activations"].append({
                        "user_id":int(payment["user_id"]),
                        "plan":str(payment["plan"]),
                        "payment_id":str(payment["payment_id"]),
                        "status":result["status"],
                    })
            except Exception:
                summary["errors"]+=1
                logger.exception("Falha ao sincronizar cobrança %s",payment.get("payment_id"))
        return summary
