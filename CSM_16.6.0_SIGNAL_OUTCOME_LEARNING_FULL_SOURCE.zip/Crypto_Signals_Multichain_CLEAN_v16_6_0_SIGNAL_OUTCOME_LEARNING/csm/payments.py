from __future__ import annotations
from datetime import date, timedelta
from typing import Any
from .config import settings
from .branding import load_branding
from .plans import PLANS, normalize_plan
from .http_client import HTTPJSONError, SafeHTTP

PAID_STATUSES={"RECEIVED","CONFIRMED","RECEIVED_IN_CASH"}
OPEN_STATUSES={"PENDING","OVERDUE"}
TERMINAL_STATUSES={"REFUNDED","REFUND_REQUESTED","CHARGEBACK_REQUESTED","CHARGEBACK_DISPUTE","AWAITING_CHARGEBACK_REVERSAL","DUNNING_REQUESTED","DUNNING_RECEIVED","DELETED"}
class AsaasError(RuntimeError): pass

class AsaasClient:
    def __init__(self,http:SafeHTTP|None=None):
        errors=settings.asaas_validation_errors()
        if errors: raise AsaasError("Configuração Asaas inválida: "+"; ".join(errors))
        self.base=settings.asaas_base_url
        self.http=http or SafeHTTP(settings.request_timeout,headers={"access_token":settings.asaas_api_key,"Content-Type":"application/json"})
    def _call(self,method,path,**kwargs)->Any:
        try:
            return self._raise_api_error(getattr(self.http,method)(f"{self.base}{path}",**kwargs))
        except HTTPJSONError as exc:
            payload=exc.payload
            if isinstance(payload,dict) and payload.get("errors"):
                msgs=[str(x.get("description") or x.get("code") or "Erro Asaas") for x in payload["errors"] if isinstance(x,dict)]
                raise AsaasError("; ".join(msgs) or str(exc)) from exc
            if exc.status_code in {401,403}: raise AsaasError(f"Asaas recusou a autenticação no ambiente {settings.asaas_environment}.") from exc
            if exc.status_code==429: raise AsaasError("Limite de requisições do Asaas atingido.") from exc
            raise AsaasError(str(exc)) from exc
        except (TimeoutError,ConnectionError) as exc: raise AsaasError("Não foi possível conectar ao Asaas.") from exc
    @staticmethod
    def _raise_api_error(payload):
        if isinstance(payload,dict) and payload.get("errors"):
            raise AsaasError("; ".join(str(x.get("description") or x.get("code") or "Erro Asaas") for x in payload["errors"] if isinstance(x,dict)))
        return payload
    def account(self): return self._call("get_json","/myAccount")
    def account_status(self):
        p=self._call("get_json","/myAccount/status/"); return p if isinstance(p,dict) else {}
    def approve_sandbox_account(self):
        if settings.asaas_environment!="sandbox": raise AsaasError("Aprovação automática só é permitida no Sandbox.")
        p=self._call("post_json","/sandbox/myAccount/approve",json_data={}); return p if isinstance(p,dict) else {}
    def ensure_sandbox_account_ready(self):
        if settings.asaas_environment!="sandbox": return {}
        status=self.account_status()
        if str(status.get("general") or "").upper()=="APPROVED": return status
        self.approve_sandbox_account(); status=self.account_status()
        if str(status.get("general") or "").upper()!="APPROVED":
            raise AsaasError(f"Conta Sandbox ainda não está aprovada pela API do Asaas (general={status.get('general') or 'UNKNOWN'}).")
        return status
    def customer(self,customer_id):
        p=self._call("get_json",f"/customers/{customer_id}"); return p if isinstance(p,dict) else {}
    def customers_by_reference(self,reference):
        p=self._call("get_json","/customers",params={"externalReference":reference,"limit":100}); return list(p.get("data",[])) if isinstance(p,dict) else []
    def create_customer(self,*,name,cpf_cnpj,reference):
        return self._call("post_json","/customers",json_data={"name":name.strip()[:100],"cpfCnpj":cpf_cnpj,"externalReference":reference,"notificationDisabled":True})
    def create_payment(self,*,customer_id,user_id,plan,billing_type):
        plan=normalize_plan(plan); meta=PLANS[plan]
        billing_type=str(billing_type or "").upper()
        if billing_type=="PIX" and settings.asaas_environment=="sandbox": self.ensure_sandbox_account_ready()
        if billing_type not in settings.asaas_payment_methods: raise AsaasError("Forma de pagamento não habilitada.")
        payload={"customer":customer_id,"billingType":billing_type,"value":round(meta["value"],2),"dueDate":(date.today()+timedelta(days=settings.asaas_due_days)).isoformat(),"description":f"{load_branding().get('product_name', 'Crypto Signals Multichain')} - {meta['label']} por {meta['days']} dias","externalReference":f"csm:{user_id}:{plan}"}
        try:
            return self._call("post_json","/payments",json_data=payload)
        except AsaasError as exc:
            msg=str(exc).lower(); approval_error="pix" in msg and ("aprov" in msg or "approve" in msg)
            if billing_type=="PIX" and settings.asaas_environment=="sandbox" and approval_error:
                self.approve_sandbox_account(); return self._call("post_json","/payments",json_data=payload)
            raise
    def payment_status(self,payment_id):
        p=self._call("get_json",f"/payments/{payment_id}/status"); return str(p.get("status") or "UNKNOWN").upper() if isinstance(p,dict) else "UNKNOWN"
    def payment(self,payment_id):
        p=self._call("get_json",f"/payments/{payment_id}"); return p if isinstance(p,dict) else {}
    def pix_qr_code(self,payment_id):
        p=self._call("get_json",f"/payments/{payment_id}/pixQrCode")
        return p if isinstance(p,dict) else {}
