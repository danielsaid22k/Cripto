from __future__ import annotations

import json
import math
import statistics
import time
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any, Iterable

from .config import settings
from .proof import PreparedSignalProof, ProofLedger, event_key as proof_event_key

HORIZONS: tuple[tuple[str, int], ...] = (
    ("5m", 5 * 60),
    ("15m", 15 * 60),
    ("1h", 60 * 60),
    ("6h", 6 * 60 * 60),
    ("24h", 24 * 60 * 60),
    ("7d", 7 * 24 * 60 * 60),
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        text = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _event_key(item: dict[str, Any], now: datetime | None = None) -> str:
    # Shared with V13 Proof of Performance so the pre-send proof and the
    # post-delivery Performance Ledger always identify the exact same event.
    return proof_event_key(item, now)


def _merge_csv(existing: str, value: str) -> str:
    values = [part.strip() for part in str(existing or "").split(",") if part.strip()]
    if value and value not in values:
        values.append(value)
    return ",".join(values)


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS signal_ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_key TEXT NOT NULL UNIQUE,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            symbol TEXT DEFAULT '',
            name TEXT DEFAULT '',
            plan_groups TEXT DEFAULT '',
            entry_price REAL NOT NULL,
            market_score INTEGER DEFAULT 0,
            final_score INTEGER DEFAULT 0,
            goplus_score INTEGER,
            goplus_risk TEXT DEFAULT '',
            goplus_buy_tax_pct REAL,
            goplus_sell_tax_pct REAL,
            goplus_top10_holders_pct REAL,
            goplus_owner_address TEXT DEFAULT '',
            goplus_creator_address TEXT DEFAULT '',
            deployer_reputation_score INTEGER,
            deployer_reputation_confidence INTEGER,
            deployer_reputation_rating TEXT DEFAULT '',
            deployer_reputation_evidence INTEGER DEFAULT 0,
            liquidity REAL DEFAULT 0,
            volume24h REAL DEFAULT 0,
            marketcap REAL DEFAULT 0,
            change24h REAL DEFAULT 0,
            buys24h INTEGER DEFAULT 0,
            sells24h INTEGER DEFAULT 0,
            source TEXT DEFAULT '',
            providers_json TEXT DEFAULT '[]',
            approval_reasons_json TEXT DEFAULT '[]',
            target1_pct REAL DEFAULT 25,
            target2_pct REAL DEFAULT 50,
            stop_pct REAL DEFAULT 12,
            delivered_count INTEGER DEFAULT 0,
            observations INTEGER DEFAULT 0,
            last_price REAL DEFAULT 0,
            last_return_pct REAL DEFAULT 0,
            max_return_pct REAL DEFAULT 0,
            max_drawdown_pct REAL DEFAULT 0,
            first_tp1_at TEXT,
            first_tp2_at TEXT,
            first_stop_at TEXT,
            status TEXT DEFAULT 'ACTIVE',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_signal_ledger_created
        ON signal_ledger(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_signal_ledger_active
        ON signal_ledger(status, updated_at);
        CREATE INDEX IF NOT EXISTS idx_signal_ledger_chain
        ON signal_ledger(chain, created_at DESC);

        CREATE TABLE IF NOT EXISTS signal_observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            captured_bucket INTEGER NOT NULL,
            captured_at TEXT NOT NULL,
            age_seconds REAL DEFAULT 0,
            price REAL NOT NULL,
            return_pct REAL DEFAULT 0,
            liquidity REAL DEFAULT 0,
            volume24h REAL DEFAULT 0,
            marketcap REAL DEFAULT 0,
            score INTEGER DEFAULT 0,
            source TEXT DEFAULT '',
            UNIQUE(signal_id, captured_bucket),
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_signal_observations_signal
        ON signal_observations(signal_id, captured_at);

        CREATE TABLE IF NOT EXISTS performance_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_type TEXT NOT NULL,
            parameters_json TEXT DEFAULT '{}',
            result_json TEXT DEFAULT '{}',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """
    )
    columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(signal_ledger)").fetchall()}
    for name, ddl in {
        "goplus_owner_address": "TEXT DEFAULT ''",
        "goplus_creator_address": "TEXT DEFAULT ''",
        "deployer_reputation_score": "INTEGER",
        "deployer_reputation_confidence": "INTEGER",
        "deployer_reputation_rating": "TEXT DEFAULT ''",
        "deployer_reputation_evidence": "INTEGER DEFAULT 0",
    }.items():
        if name not in columns:
            conn.execute(f"ALTER TABLE signal_ledger ADD COLUMN {name} {ddl}")
    conn.commit()
    # V16.3 additive lifecycle schema. Kept separate from the legacy Performance
    # Ledger DDL so upgrades remain backward-compatible and auditable.
    from .signal_lifecycle import ensure_schema as ensure_lifecycle_schema
    ensure_lifecycle_schema(conn)
    obs_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(signal_observations)").fetchall()}
    if "observation_kind" not in obs_columns:
        conn.execute("ALTER TABLE signal_observations ADD COLUMN observation_kind TEXT DEFAULT 'live'")
        conn.commit()


class PerformanceLedger:
    """Persistent, auditable post-signal performance ledger.

    The ledger records only signals that were actually delivered.  Observations
    are market facts captured later; they never change the original signal or
    its safety decision.  This separation makes reports suitable for due
    diligence and prevents hindsight rewriting.
    """

    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)
        self.proofs = ProofLedger(storage)

    def prepare_signal_proof(self, item: dict[str, Any], *, now: datetime | None = None) -> PreparedSignalProof | None:
        return self.proofs.prepare_signal(item, now=now)

    def record_signal(
        self, item: dict[str, Any], plan_group: str, *, now: datetime | None = None,
        proof_preview: PreparedSignalProof | None = None,
    ) -> int | None:
        now = now or _utc_now()
        chain = str(item.get("chain") or "").strip().lower()
        address = str(item.get("address") or "").strip()
        entry = _f(item.get("price"))
        if not chain or not address or entry <= 0:
            return None
        key = _event_key(item, now)
        proof_preview = proof_preview or self.proofs.prepare_signal(item, now=now)
        row = self.conn.execute("SELECT id,plan_groups,delivered_count FROM signal_ledger WHERE event_key=?", (key,)).fetchone()
        if row:
            merged = _merge_csv(row["plan_groups"], str(plan_group or ""))
            self.conn.execute(
                "UPDATE signal_ledger SET plan_groups=?, delivered_count=delivered_count+1, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (merged, int(row["id"])),
            )
            self.conn.commit()
            signal_id = int(row["id"])
            if proof_preview is not None:
                self.proofs.commit_prepared(signal_id, proof_preview)
            return signal_id

        reasons = item.get("approval_reasons") or []
        providers = item.get("discovery_providers") or item.get("providers") or []
        if isinstance(providers, str):
            providers = [providers]
        cursor = self.conn.execute(
            """INSERT INTO signal_ledger(
                event_key,chain,address,symbol,name,plan_groups,entry_price,
                market_score,final_score,goplus_score,goplus_risk,goplus_buy_tax_pct,
                goplus_sell_tax_pct,goplus_top10_holders_pct,goplus_owner_address,goplus_creator_address,
                deployer_reputation_score,deployer_reputation_confidence,deployer_reputation_rating,deployer_reputation_evidence,
                liquidity,volume24h,
                marketcap,change24h,buys24h,sells24h,source,providers_json,
                approval_reasons_json,target1_pct,target2_pct,stop_pct,delivered_count,
                last_price,created_at,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                key, chain, address, str(item.get("symbol") or "")[:64], str(item.get("name") or "")[:120],
                str(plan_group or ""), entry,
                _i(item.get("market_opportunity_score") or item.get("opportunity_score") or item.get("score")),
                _i(item.get("final_score") or item.get("opportunity_score") or item.get("score")),
                _i(item.get("goplus_score"), 0) if item.get("goplus_score") is not None else None,
                str(item.get("goplus_risk_level") or "")[:80],
                item.get("goplus_buy_tax_pct"), item.get("goplus_sell_tax_pct"), item.get("goplus_top10_holders_pct"),
                str(item.get("goplus_owner_address") or "")[:128], str(item.get("goplus_creator_address") or "")[:128],
                _i(item.get("deployer_reputation_score"), 0) if item.get("deployer_reputation_score") is not None else None,
                _i(item.get("deployer_reputation_confidence"), 0) if item.get("deployer_reputation_confidence") is not None else None,
                str(item.get("deployer_reputation_rating") or "")[:32], _i(item.get("deployer_reputation_evidence")),
                _f(item.get("liquidity")), _f(item.get("volume24h")), _f(item.get("marketcap")),
                _f(item.get("change24h")), _i(item.get("buys24h")), _i(item.get("sells24h")),
                str(item.get("source") or "")[:80], json.dumps(list(providers), ensure_ascii=False),
                json.dumps(list(reasons), ensure_ascii=False),
                float(settings.signal_target1_pct), float(settings.signal_target2_pct), float(settings.signal_stop_pct),
                1, entry, _iso(now), _iso(now),
            ),
        )
        signal_id = int(cursor.lastrowid)
        try:
            self.conn.execute(
                "UPDATE signal_ledger SET target3_pct=? WHERE id=?",
                (float(getattr(settings, "signal_lifecycle_target3_pct", 100.0)), signal_id),
            )
        except Exception:
            pass
        self.conn.commit()
        if proof_preview is not None:
            self.proofs.commit_prepared(signal_id, proof_preview)
        return signal_id

    def due_signals(self, *, limit: int = 25, minimum_gap_seconds: int | None = None) -> list[dict[str, Any]]:
        from .signal_lifecycle import adaptive_gap_seconds

        floor = max(60, int(minimum_gap_seconds or settings.performance_monitor_interval))
        cutoff = _iso(_utc_now() - timedelta(days=8))
        rows = self.conn.execute(
            """SELECT s.*, MAX(o.captured_at) AS last_observation_at
               FROM signal_ledger s
               LEFT JOIN signal_observations o ON o.signal_id=s.id
               WHERE s.status='ACTIVE' AND s.created_at>=?
               GROUP BY s.id
               ORDER BY COALESCE(s.next_check_at,last_observation_at,s.created_at) ASC
               LIMIT ?""",
            (cutoff, max(1, int(limit)) * 4),
        ).fetchall()
        now = _utc_now()
        due: list[dict[str, Any]] = []
        for row in rows:
            data = dict(row)
            explicit = _parse(data.get("next_check_at"))
            if explicit is not None and now >= explicit:
                due.append(data)
            elif explicit is None:
                last = _parse(data.get("last_observation_at"))
                gap = adaptive_gap_seconds(data, now=now, floor_seconds=floor)
                if last is None or (now - last).total_seconds() >= gap:
                    due.append(data)
            if len(due) >= max(1, int(limit)):
                break
        return due

    def shadow_due_signals(
        self,
        *,
        now: datetime | None = None,
        limit: int = 25,
        target_seconds: int = 300,
        grace_seconds: int = 180,
    ) -> list[dict[str, Any]]:
        """Return delivered signals needing the observational ~5 minute capture.

        V16.5.4 measurement-integrity rule: shadow eligibility is based on the
        delivery timestamp, not on the current lifecycle status.  A token that
        reached STOP/TP3 before five minutes must remain measurable; otherwise
        the confirmed cohort is biased toward survivors.  This selector never
        reopens or changes lifecycle state.
        """
        now = now or _utc_now()
        target = max(60, int(target_seconds or 300))
        grace = max(0, int(grace_seconds or 0))
        cutoff = _iso(now - timedelta(days=8))

        rows = self.conn.execute(
            """SELECT *
               FROM signal_ledger
               WHERE created_at>=?
               ORDER BY created_at ASC
               LIMIT ?""",
            (cutoff, max(1, int(limit)) * 8),
        ).fetchall()

        due: list[dict[str, Any]] = []

        for row in rows:
            data = dict(row)
            created = _parse(data.get("created_at"))
            if created is None:
                continue

            age = max(0.0, (now - created).total_seconds())
            if age < target or age > target + grace:
                continue

            captured = self.conn.execute(
                """SELECT 1
                   FROM signal_observations
                   WHERE signal_id=?
                     AND age_seconds>=?
                     AND age_seconds<=?
                   LIMIT 1""",
                (int(data["id"]), float(target), float(target + grace)),
            ).fetchone()

            if captured:
                continue

            due.append(data)
            if len(due) >= max(1, int(limit)):
                break

        return due

    def shadow_queue_snapshot(
        self,
        *,
        now: datetime | None = None,
        hours: int = 24,
        target_seconds: int = 300,
        grace_seconds: int = 180,
    ) -> dict[str, Any]:
        """Build queue telemetry directly from the ledger (no stale cache file)."""
        now = now or _utc_now()
        target = max(60, int(target_seconds or 300))
        grace = max(0, int(grace_seconds or 0))
        cutoff = _iso(now - timedelta(hours=max(1, int(hours))))
        rows = self.conn.execute(
            "SELECT * FROM signal_ledger WHERE created_at>=? ORDER BY created_at ASC",
            (cutoff,),
        ).fetchall()

        counts = {"waiting": 0, "due": 0, "late": 0, "confirmed": 0, "unknown": 0}
        by_chain: dict[str, int] = {}
        by_provider: dict[str, int] = {}

        for raw in rows:
            data = dict(raw)
            created = _parse(data.get("created_at"))
            if created is None:
                counts["unknown"] += 1
                continue
            captured = self.conn.execute(
                """SELECT 1 FROM signal_observations
                   WHERE signal_id=? AND age_seconds>=? AND age_seconds<=? LIMIT 1""",
                (int(data["id"]), float(target), float(target + grace)),
            ).fetchone()
            if captured:
                counts["confirmed"] += 1
                continue
            age = max(0.0, (now - created).total_seconds())
            if age < target:
                state = "waiting"
            elif age <= target + grace:
                state = "due"
            else:
                state = "late"
            counts[state] += 1
            chain = str(data.get("chain") or "").strip().lower()
            provider = str(data.get("source") or "").strip()
            if chain:
                by_chain[chain] = by_chain.get(chain, 0) + 1
            if provider:
                by_provider[provider] = by_provider.get(provider, 0) + 1

        return {
            "version": "16.5.4",
            "source": "ledger_recent",
            "lookback_hours": max(1, int(hours)),
            "queue_size": counts["waiting"] + counts["due"] + counts["late"] + counts["unknown"],
            **counts,
            "by_chain": by_chain,
            "by_provider": by_provider,
            "mode": "SHADOW",
            "live_impact": False,
        }

    def record_observation(self, signal_id: int, market: dict[str, Any], *, captured_at: datetime | None = None) -> bool:
        from .signal_lifecycle import evaluate as evaluate_lifecycle, record_event

        captured_at = captured_at or _utc_now()
        signal = self.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (int(signal_id),)).fetchone()
        if not signal:
            return False
        signal = dict(signal)
        entry = _f(signal.get("entry_price"))
        price = _f(market.get("price"))
        created = _parse(signal.get("created_at"))
        if entry <= 0 or price <= 0 or created is None:
            return False
        age = max(0.0, (captured_at - created).total_seconds())
        ret = ((price / entry) - 1.0) * 100.0
        lifecycle = evaluate_lifecycle(signal, market, captured_at=captured_at, return_pct=ret)
        bucket = int(captured_at.timestamp()) // 60
        buys = _i(market.get("buys24h"))
        sells = _i(market.get("sells24h"))
        try:
            observation_cursor = self.conn.execute(
                """INSERT INTO signal_observations(
                    signal_id,captured_bucket,captured_at,age_seconds,price,return_pct,
                    liquidity,volume24h,marketcap,score,source,buys24h,sells24h,buy_pressure_pct,
                    change1h,volume1h,liquidity_change_pct,volume_change_pct,score_delta,observation_kind
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    int(signal_id), bucket, _iso(captured_at), age, price, ret,
                    _f(market.get("liquidity")), _f(market.get("volume24h")), _f(market.get("marketcap")),
                    _i(market.get("final_score") or market.get("opportunity_score") or market.get("score")),
                    str(market.get("source") or "")[:80], buys, sells, lifecycle.get("buy_pressure_pct"),
                    _f(market.get("change1h")), _f(market.get("volume1h")),
                    _f(lifecycle.get("liquidity_change_pct")), _f(lifecycle.get("volume_change_pct")),
                    _i(lifecycle.get("score_delta")), "live",
                ),
            )
        except Exception as exc:
            if "UNIQUE constraint failed" not in str(exc):
                raise
            existing_observation = self.conn.execute(
                "SELECT id FROM signal_observations WHERE signal_id=? AND captured_bucket=?",
                (int(signal_id), bucket),
            ).fetchone()
            if existing_observation:
                self.proofs.commit_observation(int(signal_id), int(existing_observation["id"]), mode="live_commit")
            return False

        observation_id = int(observation_cursor.lastrowid)
        max_ret = max(_f(signal.get("max_return_pct")), ret)
        max_dd = min(_f(signal.get("max_drawdown_pct")), ret)
        tp1_at = signal.get("first_tp1_at")
        tp2_at = signal.get("first_tp2_at")
        tp3_at = signal.get("first_tp3_at")
        stop_at = signal.get("first_stop_at")
        if not tp1_at and ret >= _f(signal.get("target1_pct"), settings.signal_target1_pct):
            tp1_at = _iso(captured_at)
        if not tp2_at and ret >= _f(signal.get("target2_pct"), settings.signal_target2_pct):
            tp2_at = _iso(captured_at)
        if not tp3_at and ret >= _f(signal.get("target3_pct"), getattr(settings, "signal_lifecycle_target3_pct", 100.0)):
            tp3_at = _iso(captured_at)
        if not stop_at and ret <= -abs(_f(signal.get("stop_pct"), settings.signal_stop_pct)):
            stop_at = _iso(captured_at)

        events = list(lifecycle.get("events") or [])
        last_event = events[-1] if events else str(signal.get("last_lifecycle_event") or "")
        self.conn.execute(
            """UPDATE signal_ledger SET observations=observations+1,last_price=?,last_return_pct=?,
               max_return_pct=?,max_drawdown_pct=?,first_tp1_at=?,first_tp2_at=?,first_tp3_at=?,first_stop_at=?,
               lifecycle_state=?,deterioration_score=?,deterioration_reasons_json=?,last_buy_pressure_pct=?,
               last_liquidity_change_pct=?,last_volume_change_pct=?,last_score_delta=?,next_check_at=?,
               last_lifecycle_event=?,closed_at=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (
                price, ret, max_ret, max_dd, tp1_at, tp2_at, tp3_at, stop_at,
                str(lifecycle.get("state") or "ACTIVE"), _i(lifecycle.get("deterioration_score")),
                json.dumps(lifecycle.get("reasons") or [], ensure_ascii=False), lifecycle.get("buy_pressure_pct"),
                _f(lifecycle.get("liquidity_change_pct")), _f(lifecycle.get("volume_change_pct")),
                _i(lifecycle.get("score_delta")), lifecycle.get("next_check_at"), last_event,
                lifecycle.get("closed_at"), str(lifecycle.get("status") or "ACTIVE"), int(signal_id),
            ),
        )
        details = {
            "liquidity_change_pct": round(_f(lifecycle.get("liquidity_change_pct")), 4),
            "volume_change_pct": round(_f(lifecycle.get("volume_change_pct")), 4),
            "buy_pressure_pct": lifecycle.get("buy_pressure_pct"),
            "score_delta": _i(lifecycle.get("score_delta")),
            "next_check_at": lifecycle.get("next_check_at"),
        }
        for event in events:
            record_event(
                self.conn, int(signal_id), event, str(lifecycle.get("state") or "ACTIVE"),
                return_pct=ret, price=price, deterioration_score=_i(lifecycle.get("deterioration_score")),
                reasons=list(lifecycle.get("reasons") or []), details=details,
            )
        self.conn.commit()
        self.proofs.commit_observation(int(signal_id), observation_id, mode="live_commit")
        return True

    def record_shadow_observation(
        self, signal_id: int, market: dict[str, Any], *, captured_at: datetime | None = None
    ) -> bool:
        """Persist market evidence without mutating lifecycle or delivery state."""
        from .signal_lifecycle import evaluate as evaluate_lifecycle

        captured_at = captured_at or _utc_now()
        row = self.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (int(signal_id),)).fetchone()
        if not row:
            return False
        signal = dict(row)
        entry = _f(signal.get("entry_price"))
        price = _f(market.get("price"))
        created = _parse(signal.get("created_at"))
        if entry <= 0 or price <= 0 or created is None:
            return False
        age = max(0.0, (captured_at - created).total_seconds())
        ret = ((price / entry) - 1.0) * 100.0
        facts = evaluate_lifecycle(signal, market, captured_at=captured_at, return_pct=ret)
        bucket = int(captured_at.timestamp()) // 60
        buys = _i(market.get("buys24h"))
        sells = _i(market.get("sells24h"))
        try:
            self.conn.execute(
                """INSERT INTO signal_observations(
                    signal_id,captured_bucket,captured_at,age_seconds,price,return_pct,
                    liquidity,volume24h,marketcap,score,source,buys24h,sells24h,buy_pressure_pct,
                    change1h,volume1h,liquidity_change_pct,volume_change_pct,score_delta,observation_kind
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    int(signal_id), bucket, _iso(captured_at), age, price, ret,
                    _f(market.get("liquidity")), _f(market.get("volume24h")), _f(market.get("marketcap")),
                    _i(market.get("final_score") or market.get("opportunity_score") or market.get("score")),
                    str(market.get("source") or "")[:80], buys, sells, facts.get("buy_pressure_pct"),
                    _f(market.get("change1h")), _f(market.get("volume1h")),
                    _f(facts.get("liquidity_change_pct")), _f(facts.get("volume_change_pct")),
                    _i(facts.get("score_delta")), "shadow",
                ),
            )
        except Exception as exc:
            if "UNIQUE constraint failed" not in str(exc):
                raise
            # A normal observation in the same minute is already valid market
            # evidence and should satisfy the shadow window without duplication.
            return False
        self.conn.commit()
        return True

    def pending_lifecycle_event(self, signal_id: int) -> dict[str, Any] | None:
        row = self.conn.execute(
            """SELECT * FROM signal_lifecycle_events
               WHERE signal_id=? AND notified_at IS NULL ORDER BY id ASC LIMIT 1""",
            (int(signal_id),),
        ).fetchone()
        if not row:
            return None
        data = dict(row)
        for key, fallback in (("reasons_json", []), ("details_json", {})):
            try:
                data[key[:-5]] = json.loads(data.pop(key) or json.dumps(fallback))
            except Exception:
                data[key[:-5]] = fallback
        return data

    def mark_lifecycle_event_notified(self, event_id: int) -> None:
        self.conn.execute(
            "UPDATE signal_lifecycle_events SET notified_at=? WHERE id=?", (_iso(), int(event_id))
        )
        self.conn.commit()

    def _nearest_horizon_return(self, signal_id: int, seconds: int) -> float | None:
        """Return the first valid observation at/after a horizon, never before it.

        V16.5.3 could count the entry baseline (age≈0) as the 5m sample because
        its symmetric ±300s tolerance included zero.  V16.5.4 uses a one-sided
        window so a pre-horizon snapshot can never masquerade as future evidence.
        """
        target = max(60.0, float(seconds))
        tolerance = max(180.0, target * 0.25)
        row = self.conn.execute(
            """SELECT return_pct,age_seconds
               FROM signal_observations
               WHERE signal_id=? AND age_seconds>=? AND age_seconds<=?
               ORDER BY age_seconds ASC,id ASC LIMIT 1""",
            (int(signal_id), target, target + tolerance),
        ).fetchone()
        if not row:
            return None
        return _f(row["return_pct"])

    def signals(self, *, days: int = 30, limit: int = 5000) -> list[dict[str, Any]]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        rows = self.conn.execute(
            "SELECT * FROM signal_ledger WHERE created_at>=? ORDER BY id DESC LIMIT ?",
            (cutoff, max(1, int(limit))),
        ).fetchall()
        return [dict(row) for row in rows]

    def report(self, *, days: int = 30) -> dict[str, Any]:
        rows = self.signals(days=days)
        observed = [row for row in rows if _i(row.get("observations")) > 0]
        last_returns = [_f(row.get("last_return_pct")) for row in observed]
        max_returns = [_f(row.get("max_return_pct")) for row in observed]
        drawdowns = [_f(row.get("max_drawdown_pct")) for row in observed]

        def new_bucket() -> dict[str, Any]:
            return {"signals": 0, "wins": 0, "tp1": 0, "tp2": 0, "stop": 0, "returns": []}

        def add_bucket(bucket: dict[str, Any], row: dict[str, Any]) -> None:
            bucket["signals"] += 1
            bucket["wins"] += int(_f(row.get("last_return_pct")) > 0)
            bucket["tp1"] += int(bool(row.get("first_tp1_at")))
            bucket["tp2"] += int(bool(row.get("first_tp2_at")))
            bucket["stop"] += int(bool(row.get("first_stop_at")))
            bucket["returns"].append(_f(row.get("last_return_pct")))

        def finalize(buckets: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
            result: dict[str, dict[str, Any]] = {}
            for key, data in buckets.items():
                count = max(1, int(data["signals"]))
                result[key] = {
                    "signals": data["signals"],
                    "win_rate_pct": round(data["wins"] / count * 100, 2),
                    "tp1_hit_rate_pct": round(data["tp1"] / count * 100, 2),
                    "tp2_hit_rate_pct": round(data["tp2"] / count * 100, 2),
                    "stop_touch_rate_pct": round(data["stop"] / count * 100, 2),
                    "average_last_return_pct": round(statistics.fmean(data["returns"]), 2) if data["returns"] else 0.0,
                }
            return result

        by_chain_raw: dict[str, dict[str, Any]] = {}
        by_provider_raw: dict[str, dict[str, Any]] = {}
        by_score_raw: dict[str, dict[str, Any]] = {}
        by_month_raw: dict[str, dict[str, Any]] = {}
        for row in observed:
            chain = str(row.get("chain") or "unknown")
            add_bucket(by_chain_raw.setdefault(chain, new_bucket()), row)

            providers: list[str] = []
            try:
                decoded = json.loads(str(row.get("providers_json") or "[]"))
                if isinstance(decoded, list):
                    providers = [str(value) for value in decoded if str(value).strip()]
            except Exception:
                providers = []
            if not providers and row.get("source"):
                providers = [str(row.get("source"))]
            for provider in dict.fromkeys(providers or ["unknown"]):
                add_bucket(by_provider_raw.setdefault(provider, new_bucket()), row)

            score = _i(row.get("final_score"))
            if score >= 90:
                score_band = "90-100"
            elif score >= 80:
                score_band = "80-89"
            elif score >= 70:
                score_band = "70-79"
            else:
                score_band = "0-69"
            add_bucket(by_score_raw.setdefault(score_band, new_bucket()), row)

            month = str(row.get("created_at") or "unknown")[:7]
            add_bucket(by_month_raw.setdefault(month, new_bucket()), row)

        horizon_summary: dict[str, Any] = {}
        for label, seconds in HORIZONS:
            values: list[float] = []
            for row in observed:
                value = self._nearest_horizon_return(int(row["id"]), seconds)
                if value is not None:
                    values.append(value)
            horizon_summary[label] = {
                "samples": len(values),
                "average_return_pct": round(statistics.fmean(values), 2) if values else None,
                "median_return_pct": round(statistics.median(values), 2) if values else None,
                "win_rate_pct": round(sum(v > 0 for v in values) / len(values) * 100, 2) if values else None,
            }

        count = len(observed)
        return {
            "generated_at": _iso(),
            "days": int(days),
            "signals_total": len(rows),
            "signals_observed": count,
            "observation_coverage_pct": round((count / len(rows) * 100), 2) if rows else 0.0,
            "win_rate_pct": round(sum(v > 0 for v in last_returns) / count * 100, 2) if count else 0.0,
            "average_last_return_pct": round(statistics.fmean(last_returns), 2) if last_returns else 0.0,
            "median_last_return_pct": round(statistics.median(last_returns), 2) if last_returns else 0.0,
            "average_max_return_pct": round(statistics.fmean(max_returns), 2) if max_returns else 0.0,
            "worst_drawdown_pct": round(min(drawdowns), 2) if drawdowns else 0.0,
            "tp1_hit_rate_pct": round(sum(bool(r.get("first_tp1_at")) for r in observed) / count * 100, 2) if count else 0.0,
            "tp2_hit_rate_pct": round(sum(bool(r.get("first_tp2_at")) for r in observed) / count * 100, 2) if count else 0.0,
            "stop_touch_rate_pct": round(sum(bool(r.get("first_stop_at")) for r in observed) / count * 100, 2) if count else 0.0,
            "by_chain": finalize(by_chain_raw),
            "by_provider": finalize(by_provider_raw),
            "by_score_band": finalize(by_score_raw),
            "by_month": finalize(by_month_raw),
            "horizons": horizon_summary,
            "methodology": "Somente sinais efetivamente entregues; observações posteriores são append-only e o sinal original não é reescrito.",
        }

    def signal_quality_shadow_report(
        self,
        *,
        days: int = 30,
        target_seconds: int = 300,
        grace_seconds: int = 180,
        persist: bool = True,
    ) -> dict[str, Any]:
        """Measure observational coverage of the ~5 minute quality shadow gate.

        Evidence-only: this report never changes score, approval, delivery,
        lifecycle state or signal eligibility.
        """
        days = max(1, int(days))
        target = max(60, int(target_seconds or 300))
        grace = max(0, int(grace_seconds or 0))
        window_end = target + grace

        signals = self.signals(days=days)

        signals_with_baseline = 0
        shadow_confirmed = 0

        shadow_ages: list[float] = []
        shadow_returns: list[float] = []
        liquidity_changes: list[float] = []
        volume_changes: list[float] = []
        buy_pressures: list[float] = []
        score_deltas: list[float] = []
        confirmed_signal_ids: list[int] = []

        for signal in signals:
            signal_id = int(signal["id"])

            observations = [
                dict(row)
                for row in self.conn.execute(
                    """SELECT
                           age_seconds,
                           return_pct,
                           liquidity_change_pct,
                           volume_change_pct,
                           buy_pressure_pct,
                           score_delta
                       FROM signal_observations
                       WHERE signal_id=?
                       ORDER BY age_seconds ASC, id ASC""",
                    (signal_id,),
                ).fetchall()
            ]

            if any(
                0.0 <= _f(row.get("age_seconds")) < float(target)
                for row in observations
            ):
                signals_with_baseline += 1

            shadow = next(
                (
                    row
                    for row in observations
                    if float(target)
                    <= _f(row.get("age_seconds"))
                    <= float(window_end)
                ),
                None,
            )

            if shadow is None:
                continue

            shadow_confirmed += 1
            confirmed_signal_ids.append(signal_id)
            shadow_ages.append(_f(shadow.get("age_seconds")))
            shadow_returns.append(_f(shadow.get("return_pct")))

            if shadow.get("liquidity_change_pct") is not None:
                liquidity_changes.append(_f(shadow.get("liquidity_change_pct")))

            if shadow.get("volume_change_pct") is not None:
                volume_changes.append(_f(shadow.get("volume_change_pct")))

            if shadow.get("buy_pressure_pct") is not None:
                buy_pressures.append(_f(shadow.get("buy_pressure_pct")))

            if shadow.get("score_delta") is not None:
                score_deltas.append(_f(shadow.get("score_delta")))

        total = len(signals)
        missing = max(0, total - shadow_confirmed)

        def cohort_summary(
            cohort: list[dict[str, Any]],
        ) -> dict[str, Any]:
            n = len(cohort)
            returns = [
                _f(row.get("last_return_pct"))
                for row in cohort
            ]
            max_returns = [
                _f(row.get("max_return_pct"))
                for row in cohort
            ]
            drawdowns = [
                _f(row.get("max_drawdown_pct"))
                for row in cohort
            ]

            return {
                "signals": n,
                "win_rate_pct": round(
                    sum(value > 0 for value in returns) / n * 100,
                    2,
                ) if n else 0.0,
                "tp1_hit_rate_pct": round(
                    sum(bool(row.get("first_tp1_at")) for row in cohort)
                    / n * 100,
                    2,
                ) if n else 0.0,
                "tp2_hit_rate_pct": round(
                    sum(bool(row.get("first_tp2_at")) for row in cohort)
                    / n * 100,
                    2,
                ) if n else 0.0,
                "stop_touch_rate_pct": round(
                    sum(bool(row.get("first_stop_at")) for row in cohort)
                    / n * 100,
                    2,
                ) if n else 0.0,
                "average_last_return_pct": round(
                    statistics.fmean(returns),
                    2,
                ) if returns else 0.0,
                "average_max_return_pct": round(
                    statistics.fmean(max_returns),
                    2,
                ) if max_returns else 0.0,
                "worst_drawdown_pct": round(
                    min(drawdowns),
                    2,
                ) if drawdowns else 0.0,
            }

        confirmed_set = set(confirmed_signal_ids)

        confirmed_rows = [
            row for row in signals
            if int(row["id"]) in confirmed_set
        ]

        unconfirmed_rows = [
            row for row in signals
            if int(row["id"]) not in confirmed_set
        ]

        confirmed_outcomes = cohort_summary(confirmed_rows)
        unconfirmed_outcomes = cohort_summary(unconfirmed_rows)

        delta_confirmed_minus_unconfirmed = {
            "win_rate_pct": round(
                _f(confirmed_outcomes["win_rate_pct"])
                - _f(unconfirmed_outcomes["win_rate_pct"]),
                2,
            ),
            "average_last_return_pct": round(
                _f(confirmed_outcomes["average_last_return_pct"])
                - _f(unconfirmed_outcomes["average_last_return_pct"]),
                2,
            ),
            "tp1_hit_rate_pct": round(
                _f(confirmed_outcomes["tp1_hit_rate_pct"])
                - _f(unconfirmed_outcomes["tp1_hit_rate_pct"]),
                2,
            ),
            "stop_touch_rate_pct": round(
                _f(confirmed_outcomes["stop_touch_rate_pct"])
                - _f(unconfirmed_outcomes["stop_touch_rate_pct"]),
                2,
            ),
        }

        result = {
            "generated_at": _iso(),
            "days": days,
            "target_seconds": target,
            "grace_seconds": grace,
            "window_end_seconds": window_end,
            "signals_total": total,
            "signals_with_baseline": signals_with_baseline,
            "shadow_confirmed": shadow_confirmed,
            "shadow_missing": missing,
            "shadow_coverage_pct": round(
                shadow_confirmed / total * 100, 2
            ) if total else 0.0,
            "average_shadow_age_seconds": round(
                statistics.fmean(shadow_ages), 2
            ) if shadow_ages else None,
            "median_shadow_age_seconds": round(
                statistics.median(shadow_ages), 2
            ) if shadow_ages else None,
            "shadow_positive_rate_pct": round(
                sum(value > 0 for value in shadow_returns)
                / len(shadow_returns) * 100,
                2,
            ) if shadow_returns else None,
            "average_shadow_return_pct": round(
                statistics.fmean(shadow_returns), 2
            ) if shadow_returns else None,
            "average_liquidity_change_pct": round(
                statistics.fmean(liquidity_changes), 2
            ) if liquidity_changes else None,
            "average_volume_change_pct": round(
                statistics.fmean(volume_changes), 2
            ) if volume_changes else None,
            "average_buy_pressure_pct": round(
                statistics.fmean(buy_pressures), 2
            ) if buy_pressures else None,
            "average_score_delta": round(
                statistics.fmean(score_deltas), 2
            ) if score_deltas else None,
            "confirmed_outcomes": confirmed_outcomes,
            "unconfirmed_outcomes": unconfirmed_outcomes,
            "delta_confirmed_minus_unconfirmed": (
                delta_confirmed_minus_unconfirmed
            ),
            "methodology": (
                "Evidence-only: mede a primeira observação entre o alvo "
                "temporal e o fim da janela de tolerância; não altera "
                "score, aprovação, entrega ou lifecycle."
            ),
        }

        if persist:
            self.conn.execute(
                """INSERT INTO performance_runs(
                       run_type,
                       parameters_json,
                       result_json
                   ) VALUES('signal_quality_shadow', ?, ?)""",
                (
                    json.dumps(
                        {
                            "days": days,
                            "target_seconds": target,
                            "grace_seconds": grace,
                        }
                    ),
                    json.dumps(result, ensure_ascii=False),
                ),
            )
            self.conn.commit()

        return result

    def replay(self, *, days: int = 30, min_score: int = 0, min_goplus: int = 0, max_sell_tax: float = 100.0) -> dict[str, Any]:
        rows = self.signals(days=days)
        selected: list[dict[str, Any]] = []
        for row in rows:
            if _i(row.get("observations")) <= 0:
                continue
            if _i(row.get("final_score")) < int(min_score):
                continue
            gp = row.get("goplus_score")
            if gp is not None and _i(gp) < int(min_goplus):
                continue
            tax = row.get("goplus_sell_tax_pct")
            if tax is not None and _f(tax) > float(max_sell_tax):
                continue
            selected.append(row)
        returns = [_f(r.get("last_return_pct")) for r in selected]
        n = len(selected)
        result = {
            "generated_at": _iso(),
            "dataset": "signal_ledger_observed_only",
            "parameters": {
                "days": int(days),
                "min_score": int(min_score),
                "min_goplus": int(min_goplus),
                "max_sell_tax": float(max_sell_tax),
            },
            "signals": n,
            "win_rate_pct": round(sum(v > 0 for v in returns) / n * 100, 2) if n else 0.0,
            "average_return_pct": round(statistics.fmean(returns), 2) if returns else 0.0,
            "median_return_pct": round(statistics.median(returns), 2) if returns else 0.0,
            "tp1_hit_rate_pct": round(sum(bool(r.get("first_tp1_at")) for r in selected) / n * 100, 2) if n else 0.0,
            "tp2_hit_rate_pct": round(sum(bool(r.get("first_tp2_at")) for r in selected) / n * 100, 2) if n else 0.0,
            "stop_touch_rate_pct": round(sum(bool(r.get("first_stop_at")) for r in selected) / n * 100, 2) if n else 0.0,
            "note": "Replay usa apenas sinais historicamente registrados pelo produto; não inventa candidatos que o scanner nunca observou.",
        }
        self.conn.execute(
            "INSERT INTO performance_runs(run_type,parameters_json,result_json) VALUES('replay',?,?)",
            (json.dumps(result["parameters"]), json.dumps(result, ensure_ascii=False)),
        )
        self.conn.commit()
        return result


    def compare_strategies(
        self,
        *,
        days: int = 30,
        strategy_a: dict[str, Any] | None = None,
        strategy_b: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Compare two filter policies over the same observed ledger.

        This is an observational replay, not a claim that unobserved candidates
        would have behaved the same way. It is designed to make tuning
        decisions reproducible without changing live safety gates.
        """
        a = {"min_score": 0, "min_goplus": 0, "max_sell_tax": 100.0, **(strategy_a or {})}
        b = {"min_score": 80, "min_goplus": 80, "max_sell_tax": 10.0, **(strategy_b or {})}
        result_a = self.replay(days=days, **a)
        result_b = self.replay(days=days, **b)
        compare = {
            "generated_at": _iso(),
            "dataset": "signal_ledger_observed_only",
            "days": int(days),
            "strategy_a": result_a,
            "strategy_b": result_b,
            "delta_b_minus_a": {
                "signals": int(result_b["signals"]) - int(result_a["signals"]),
                "win_rate_pct": round(_f(result_b["win_rate_pct"]) - _f(result_a["win_rate_pct"]), 2),
                "average_return_pct": round(_f(result_b["average_return_pct"]) - _f(result_a["average_return_pct"]), 2),
                "tp1_hit_rate_pct": round(_f(result_b["tp1_hit_rate_pct"]) - _f(result_a["tp1_hit_rate_pct"]), 2),
                "stop_touch_rate_pct": round(_f(result_b["stop_touch_rate_pct"]) - _f(result_a["stop_touch_rate_pct"]), 2),
            },
            "note": "Comparação observacional sobre os mesmos sinais registrados; não mede candidatos que o scanner nunca observou e não altera a estratégia ao vivo.",
        }
        self.conn.execute(
            "INSERT INTO performance_runs(run_type,parameters_json,result_json) VALUES('compare',?,?)",
            (json.dumps({"days": days, "strategy_a": a, "strategy_b": b}), json.dumps(compare, ensure_ascii=False)),
        )
        self.conn.commit()
        return compare


@dataclass(frozen=True)
class HistoricalConfidence:
    available: bool
    score: int | None = None
    samples: int = 0
    tp1_rate_pct: float | None = None
    scope: str = "insufficient_history"


class HistoricalConfidenceModel:
    """Local historical probability model with a hard minimum sample gate.

    It never overrides the scanner or GoPlus safety gates.  Its output is a
    separate confidence feature intended for explanation, ranking experiments
    and buyer-facing analytics.
    """

    def __init__(self, storage, *, min_samples: int | None = None):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)
        self.min_samples = max(5, int(min_samples or settings.adaptive_min_samples))

    def estimate(self, item: dict[str, Any]) -> HistoricalConfidence:
        chain = str(item.get("chain") or "").strip().lower()
        score = _i(item.get("final_score") or item.get("opportunity_score") or item.get("score"))
        low, high = max(0, score - 10), min(100, score + 10)
        rows = self.conn.execute(
            """SELECT first_tp1_at FROM signal_ledger
               WHERE observations>0 AND final_score BETWEEN ? AND ? AND chain=?
               ORDER BY id DESC LIMIT 500""",
            (low, high, chain),
        ).fetchall()
        scope = f"chain:{chain}:score±10"
        if len(rows) < self.min_samples:
            rows = self.conn.execute(
                """SELECT first_tp1_at FROM signal_ledger
                   WHERE observations>0 AND final_score BETWEEN ? AND ?
                   ORDER BY id DESC LIMIT 1000""",
                (low, high),
            ).fetchall()
            scope = "global:score±10"
        n = len(rows)
        if n < self.min_samples:
            return HistoricalConfidence(False, samples=n)
        wins = sum(bool(row["first_tp1_at"]) for row in rows)
        # Beta(2,2) smoothing prevents tiny/imbalanced samples from producing
        # false 0% or 100% certainty.
        probability = (wins + 2) / (n + 4) * 100
        return HistoricalConfidence(True, int(round(probability)), n, round(wins / n * 100, 2), scope)
