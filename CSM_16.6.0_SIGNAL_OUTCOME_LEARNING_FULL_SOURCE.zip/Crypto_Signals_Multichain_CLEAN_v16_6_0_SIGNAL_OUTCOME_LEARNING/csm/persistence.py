from __future__ import annotations

import json
import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 680
STATE_MANIFEST = "state_manifest.json"

REQUIRED_CORE_TABLES = {"users", "payment_orders"}
OPTIONAL_DATA_TABLES = {"subscriptions", "analyses", "favorites", "signal_positions"}


def inspect_database(db_path: Path) -> dict[str, Any]:
    """Inspeciona um banco candidato sem modificá-lo.

    Retorna integridade, tabelas e contagens. Bancos vazios, sem tabelas de
    negócio ou oriundos de arquivos inválidos são marcados como não válidos.
    """
    result: dict[str, Any] = {
        "path": str(db_path), "valid": False, "integrity": "missing",
        "schema_version": 0, "tables": [], "users": 0,
        "payments": 0, "subscriptions": 0, "analyses": 0,
        "favorites": 0, "score": (0, 0, 0, 0),
    }
    if not db_path.is_file() or db_path.stat().st_size < 512:
        return result
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            result["integrity"] = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
            result["schema_version"] = int(conn.execute("PRAGMA user_version").fetchone()[0] or 0)
            tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            result["tables"] = sorted(tables)
            def count(name: str) -> int:
                if name not in tables:
                    return 0
                return int(conn.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0])
            for name in ("users", "payment_orders", "subscriptions", "analyses", "favorites"):
                result["payments" if name == "payment_orders" else name] = count(name)
            has_core = "users" in tables and bool(tables & (REQUIRED_CORE_TABLES | OPTIONAL_DATA_TABLES))
            result["valid"] = result["integrity"] == "ok" and has_core
            result["score"] = (
                1 if result["valid"] else 0,
                result["users"] + result["payments"] + result["subscriptions"],
                result["analyses"] + result["favorites"],
                result["schema_version"],
            )
        finally:
            conn.close()
    except (OSError, sqlite3.Error, ValueError):
        pass
    return result



def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def ensure_state_layout(state_dir: Path) -> None:
    state_dir.mkdir(parents=True, exist_ok=True)
    (state_dir / "backups").mkdir(parents=True, exist_ok=True)
    manifest = state_dir / STATE_MANIFEST
    if not manifest.exists():
        payload = {
            "format": 1,
            "purpose": "persistent-user-and-subscription-state",
            "created_at": datetime.now().astimezone().isoformat(),
            "schema_version": 0,
        }
        manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def current_schema_version(db_path: Path) -> int:
    if not db_path.exists() or db_path.stat().st_size == 0:
        return 0
    conn = sqlite3.connect(db_path)
    try:
        return int(conn.execute("PRAGMA user_version").fetchone()[0] or 0)
    finally:
        conn.close()


def create_database_snapshot(db_path: Path, *, label: str = "manual") -> Path | None:
    if not db_path.exists() or db_path.stat().st_size == 0:
        return None
    backup_dir = db_path.parent / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    destination = backup_dir / f"signals_{label}_{_timestamp()}.db"
    source_conn = sqlite3.connect(db_path)
    target_conn = sqlite3.connect(destination)
    try:
        source_conn.backup(target_conn)
    finally:
        target_conn.close()
        source_conn.close()
    try:
        os.chmod(destination, 0o600)
    except OSError:
        pass
    return destination


def prepare_schema_migration(db_path: Path) -> Path | None:
    ensure_state_layout(db_path.parent)
    old_version = current_schema_version(db_path)
    if db_path.exists() and db_path.stat().st_size > 0 and old_version < SCHEMA_VERSION:
        return create_database_snapshot(db_path, label=f"pre_migration_v{old_version}_to_v{SCHEMA_VERSION}")
    return None


def finalize_schema(conn: sqlite3.Connection, state_dir: Path) -> None:
    """Finaliza a migração dentro de uma transação idempotente."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TEXT DEFAULT CURRENT_TIMESTAMP,
                description TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS data_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                details TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, description) VALUES(?, ?)",
            (SCHEMA_VERSION, "v16 additive Customer Portal & Entitlements schema"),
        )
        conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
        conn.execute(
            "INSERT INTO data_audit(event, details) VALUES(?, ?)",
            ("schema_ready", json.dumps({"schema_version": SCHEMA_VERSION})),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    manifest = state_dir / STATE_MANIFEST
    payload: dict[str, Any] = {}
    if manifest.exists():
        try:
            payload = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            payload = {}
    payload.update({
        "format": 1,
        "purpose": "persistent-user-and-subscription-state",
        "schema_version": SCHEMA_VERSION,
        "updated_at": datetime.now().astimezone().isoformat(),
    })
    manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def database_report(db_path: Path) -> dict[str, Any]:
    report: dict[str, Any] = {
        "path": str(db_path),
        "exists": db_path.exists(),
        "schema_version": 0,
        "integrity": "missing",
        "users": 0,
        "active_subscribers": 0,
        "payments": 0,
        "subscriptions": 0,
        "duplicates": 0,
    }
    if not db_path.exists() or db_path.stat().st_size == 0:
        return report
    conn = sqlite3.connect(db_path)
    try:
        report["schema_version"] = int(conn.execute("PRAGMA user_version").fetchone()[0] or 0)
        report["integrity"] = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
        tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "users" in tables:
            report["users"] = int(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0])
            report["active_subscribers"] = int(conn.execute(
                "SELECT COUNT(*) FROM users WHERE plan IN ('plus','plus_annual','premium','premium_annual') AND blocked=0"
            ).fetchone()[0])
            report["duplicates"] = int(conn.execute(
                "SELECT COUNT(*) FROM (SELECT user_id, COUNT(*) c FROM users GROUP BY user_id HAVING c > 1)"
            ).fetchone()[0])
        if "payment_orders" in tables:
            report["payments"] = int(conn.execute("SELECT COUNT(*) FROM payment_orders").fetchone()[0])
        if "subscriptions" in tables:
            report["subscriptions"] = int(conn.execute("SELECT COUNT(*) FROM subscriptions").fetchone()[0])
    finally:
        conn.close()
    return report


def copy_legacy_database(source: Path, destination: Path) -> None:
    report = inspect_database(source)
    if not report["valid"]:
        raise RuntimeError(f"Banco legado incompatível ou vazio: {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(".importing")
    shutil.copy2(source, temp)
    copied = inspect_database(temp)
    if not copied["valid"]:
        temp.unlink(missing_ok=True)
        raise RuntimeError("Cópia do banco legado falhou na validação estrutural")
    os.replace(temp, destination)
