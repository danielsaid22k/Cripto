from __future__ import annotations

from .config import settings

PLANS = {
    "free": {"label":"Grátis","emoji":"🆓","limit":settings.free_daily_limit,"chains":{"solana","ethereum","bsc"},"history":5,"favorites":0,"level":0,"days":0,"cycle":None,"value":0.0,"base":"free","auto_signals":True,"premium_panel":False},
    "plus": {"label":"Plus Mensal","emoji":"💠","limit":settings.plus_daily_limit,"chains":"all","history":30,"favorites":20,"level":1,"days":settings.plan_monthly_duration_days,"cycle":"MONTHLY","value":settings.asaas_plus_value,"base":"plus","auto_signals":True,"premium_panel":False},
    "premium": {"label":"Premium Mensal","emoji":"👑","limit":None,"chains":"all","history":100,"favorites":100,"level":2,"days":settings.plan_monthly_duration_days,"cycle":"MONTHLY","value":settings.asaas_premium_value,"base":"premium","auto_signals":True,"premium_panel":True},
    "plus_annual": {"label":"Plus Anual","emoji":"💠","limit":settings.plus_daily_limit,"chains":"all","history":60,"favorites":40,"level":1,"days":settings.plan_annual_duration_days,"cycle":"YEARLY","value":settings.asaas_plus_annual_value,"base":"plus","auto_signals":True,"premium_panel":False},
    "premium_annual": {"label":"Premium Anual","emoji":"👑","limit":None,"chains":"all","history":250,"favorites":250,"level":2,"days":settings.plan_annual_duration_days,"cycle":"YEARLY","value":settings.asaas_premium_annual_value,"base":"premium","auto_signals":True,"premium_panel":True},
}

def normalize_plan(value: str | None) -> str:
    value=(value or "free").strip().lower()
    if value=="vip": value="plus"
    return value if value in PLANS else "free"

def base_plan(value: str | None) -> str:
    return PLANS[normalize_plan(value)]["base"]
