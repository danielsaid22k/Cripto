from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class PlatformLine:
    name: str
    status: str
    responsibility: str
    frozen: bool


def platform_lines() -> list[dict[str, object]]:
    values = [
        PlatformLine("Core", "LTS", "Banco, migração, backup, Telegram, Asaas, scanner e pagamentos", True),
        PlatformLine("Experience", "active", "Onboarding, dashboards, identidade visual e experiência por plano", False),
        PlatformLine("Intelligence", "active", "Project Leader, auditoria, métricas e simulações", False),
        PlatformLine("Enterprise", "active", "Admin web, assinantes, renovações, relatórios e observabilidade", False),
    ]
    return [asdict(item) for item in values]
