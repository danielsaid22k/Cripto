from __future__ import annotations

from . import __product_version__

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings
from .professional_ops import admin_dashboard
from .project_leader import ProjectLeader
from .release_ops import health_dashboard, run_quality_gate, restore_dry_run

RELEASE = "8.2.1"
LTS_BASE = "6.3.0"
PLATFORM_NAME = "Phantom Alert Platform"


@dataclass(frozen=True)
class OperationalAlert:
    code: str
    severity: str
    title: str
    details: str
    recommended_action: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def operational_alerts(precomputed_health: dict[str, Any] | None = None) -> list[OperationalAlert]:
    health = precomputed_health if precomputed_health is not None else health_dashboard()
    alerts: list[OperationalAlert] = []
    database = health.get("database", {})
    integrations = health.get("integrations", {})
    scanner = health.get("scanner", {})
    latest_backup = health.get("latest_backup")

    integrity = str(database.get("integrity") or "missing")
    if integrity not in {"ok", "missing"}:
        alerts.append(OperationalAlert(
            "DB_INTEGRITY", "critical", "Integridade do banco comprometida",
            f"integridade={integrity}",
            "Interromper atualização, criar snapshot e executar db-check.",
        ))

    if not integrations.get("telegram_configured"):
        alerts.append(OperationalAlert(
            "TELEGRAM_CONFIG", "high", "Telegram não configurado",
            "Token ou Chat ID ausente.",
            "Executar python main.py setup e validar com doctor.",
        ))

    if settings.asaas_enabled and not integrations.get("asaas_configured"):
        alerts.append(OperationalAlert(
            "ASAAS_CONFIG", "high", "Asaas habilitado sem credenciais válidas",
            "Cobranças automáticas podem falhar.",
            "Revisar a configuração do Asaas no setup.",
        ))

    if scanner.get("enabled") and scanner.get("last_cycle_age_seconds") is not None:
        age = float(scanner.get("last_cycle_age_seconds") or 0)
        threshold = max(1800, settings.auto_scan_interval_free * 3)
        if age > threshold:
            alerts.append(OperationalAlert(
                "SCANNER_STALE", "high", "Scanner sem ciclo recente",
                f"último ciclo há {int(age)} segundos",
                "Verificar conexão, logs e reiniciar uma única instância do bot.",
            ))

    if not latest_backup:
        alerts.append(OperationalAlert(
            "BACKUP_MISSING", "medium", "Backup recente não localizado",
            "Não há backup válido no estado persistente.",
            "Executar python main.py backup --include-secrets.",
        ))
    elif latest_backup.get("error"):
        alerts.append(OperationalAlert(
            "BACKUP_INVALID", "high", "Backup mais recente inválido",
            str(latest_backup.get("error")),
            "Criar um novo backup e executar restore-dry-run.",
        ))

    if health.get("maintenance", {}).get("active"):
        alerts.append(OperationalAlert(
            "MAINTENANCE_ACTIVE", "medium", "Modo de manutenção ativo",
            str(health.get("maintenance", {}).get("reason") or "sem motivo"),
            "Confirmar a atualização ou executar maintenance-off.",
        ))

    return alerts


def leader_simulation() -> dict[str, Any]:
    leader = ProjectLeader()
    report = leader.audit()
    severity_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    findings = sorted(
        report.get("findings", []),
        key=lambda item: (severity_rank.get(str(item.get("severity")), 9), str(item.get("code"))),
    )
    plan: list[dict[str, Any]] = []
    for index, item in enumerate(findings, 1):
        action = item.get("action")
        plan.append({
            "order": index,
            "severity": item.get("severity"),
            "title": item.get("title"),
            "details": item.get("details"),
            "proposed_action": action,
            "requires_admin_approval": bool(action),
            "would_modify_system": bool(action),
        })
    return {
        "generated_at": _now(),
        "release": RELEASE,
        "product_release": __product_version__,
        "lts_base": LTS_BASE,
        "health_score": report.get("health_score", 0),
        "findings": len(findings),
        "simulation_only": True,
        "steps": plan,
        "note": "Nenhuma alteração foi aplicada. Toda ação continua exigindo aprovação administrativa.",
    }


def platform_dashboard() -> dict[str, Any]:
    admin = admin_dashboard()
    health = health_dashboard()
    leader = leader_simulation()
    alerts = [item.to_dict() for item in operational_alerts(health)]
    critical = sum(item["severity"] == "critical" for item in alerts)
    high = sum(item["severity"] == "high" for item in alerts)
    status = "critical" if critical else "attention" if high or alerts else "healthy"
    return {
        "generated_at": _now(),
        "platform": PLATFORM_NAME,
        "release": RELEASE,
        "product_release": __product_version__,
        "lts_base": LTS_BASE,
        "status": status,
        "admin": admin,
        "health": health,
        "leader": leader,
        "alerts": alerts,
    }


def production_readiness() -> dict[str, Any]:
    gate = run_quality_gate()
    alerts = operational_alerts()
    critical_alerts = [item for item in alerts if item.severity in {"critical", "high"}]
    restore_result: dict[str, Any] | None = None
    restore_ok = False
    try:
        restore_result = restore_dry_run()
        restore_ok = bool(restore_result.get("valid"))
    except Exception as exc:
        restore_result = {"valid": False, "error": str(exc)}
    ready = bool(gate.passed and not critical_alerts and restore_ok)
    return {
        "generated_at": _now(),
        "release": RELEASE,
        "product_release": __product_version__,
        "lts_base": LTS_BASE,
        "ready": ready,
        "quality_gate": gate.to_dict(),
        "critical_alerts": [item.to_dict() for item in critical_alerts],
        "restore_dry_run": restore_result,
        "decision": "PROMOVER" if ready else "BLOQUEAR",
    }


def _save_report(name: str, payload: dict[str, Any]) -> Path:
    target = settings.data_dir / "reports" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return target


def save_platform_dashboard() -> Path:
    return _save_report("platform_dashboard.json", platform_dashboard())


def save_leader_simulation() -> Path:
    return _save_report("leader_simulation.json", leader_simulation())


def save_operational_alerts() -> Path:
    return _save_report("operational_alerts.json", {
        "generated_at": _now(),
        "release": RELEASE,
        "product_release": __product_version__,
        "alerts": [item.to_dict() for item in operational_alerts()],
    })


def save_production_readiness() -> Path:
    return _save_report("production_readiness.json", production_readiness())
