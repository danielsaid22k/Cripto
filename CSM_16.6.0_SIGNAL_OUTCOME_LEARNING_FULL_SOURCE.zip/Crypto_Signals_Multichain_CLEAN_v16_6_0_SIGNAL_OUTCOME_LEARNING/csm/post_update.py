from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import STATE_DIR, settings


VERSION = "16.6.0"


class PostUpdateError(RuntimeError):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _root() -> Path:
    path = STATE_DIR / "post_update"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _report_file() -> Path:
    return _root() / "last_report.json"


def _lock_file() -> Path:
    return _root() / "finalize.lock"


def _log_file() -> Path:
    path = STATE_DIR / "logs" / "post_update.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _pid_alive(pid: int) -> bool:
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _read_lock() -> dict[str, Any]:
    try:
        data = json.loads(_lock_file().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_lock() -> None:
    _lock_file().write_text(
        json.dumps({"pid": os.getpid(), "started_at": _now()}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _clear_lock() -> None:
    try:
        current = _read_lock()
        if int(current.get("pid") or 0) in {0, os.getpid()}:
            _lock_file().unlink(missing_ok=True)
    except Exception:
        pass


def _acquire_lock() -> None:
    current = _read_lock()
    pid = int(current.get("pid") or 0)
    if pid and _pid_alive(pid) and pid != os.getpid():
        raise PostUpdateError(f"post_update_already_running: pid={pid}")
    _write_lock()


def _safe_tail(value: str, limit: int = 12000) -> str:
    # Outputs from these commands are expected to be secret-free. Still cap the
    # persisted text so the post-update report never becomes a large log sink.
    return str(value or "")[-max(1000, int(limit)):]


def _save(report: dict[str, Any]) -> dict[str, Any]:
    report["updated_at"] = _now()
    _report_file().write_text(
        json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    return report


def status() -> dict[str, Any]:
    report: dict[str, Any] = {}
    try:
        data = json.loads(_report_file().read_text(encoding="utf-8"))
        if isinstance(data, dict):
            report = data
    except Exception:
        report = {}

    lock = _read_lock()
    pid = int(lock.get("pid") or 0)
    running = bool(pid and _pid_alive(pid))
    if not running and pid:
        try:
            _lock_file().unlink(missing_ok=True)
        except Exception:
            pass

    return {
        "ok": True,
        "version": VERSION,
        "running": running,
        "pid": pid or None,
        "report": report,
        "report_file": str(_report_file()),
        "log_file": str(_log_file()),
    }


def _run_cli(command: str, *, timeout_seconds: int = 300) -> dict[str, Any]:
    main = Path(settings.base_dir) / "main.py"
    proc = subprocess.run(
        [sys.executable, str(main), command],
        cwd=str(settings.base_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=max(20, int(timeout_seconds)),
        check=False,
        env=os.environ.copy(),
    )
    return {
        "ok": proc.returncode == 0,
        "returncode": int(proc.returncode),
        "output": _safe_tail(proc.stdout or ""),
    }


def _step(report: dict[str, Any], name: str, runner) -> bool:
    started = time.monotonic()
    try:
        result = runner()
        if not isinstance(result, dict):
            result = {"ok": bool(result)}
        ok = bool(result.get("ok"))
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout if isinstance(exc.stdout, str) else ""
        result = {"ok": False, "error": "timeout", "output": _safe_tail(out)}
        ok = False
    except Exception as exc:
        result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        ok = False

    result["duration_seconds"] = round(time.monotonic() - started, 3)
    report.setdefault("steps", {})[name] = result
    report["last_step"] = name
    _save(report)
    return ok


def _migrate_in_place_step() -> dict[str, Any]:
    """Upgrade only the currently installed persistent database.

    The v16.5.5 finalizer delegated to the legacy ``migrate`` command, whose
    historical migration workflow may auto-restore a previous backup. That is
    useful for recovery, but unsafe as an automatic post-update action. The
    finalizer now creates a safety backup and performs only the idempotent
    schema initialization against the current database.
    """
    from .backup_manager import create_pre_migration_backup
    from .persistence import database_report
    from .storage import Storage

    safety = create_pre_migration_backup()
    storage = Storage(settings.db_file)
    storage.close()
    report = database_report(settings.db_file)
    if report.get("integrity") != "ok" or int(report.get("schema_version") or 0) <= 0:
        return {
            "ok": False,
            "mode": "in_place_only",
            "safety_backup": str(safety) if safety else None,
            "error": "in_place_migration_invalid_database",
            "database": report,
        }
    return {
        "ok": True,
        "mode": "in_place_only",
        "auto_restore_previous": False,
        "safety_backup": str(safety) if safety else None,
        "database": {
            "path": report.get("path"),
            "integrity": report.get("integrity"),
            "schema_version": report.get("schema_version"),
            "users": report.get("users"),
            "payments": report.get("payments"),
        },
    }


def _wait_for_runtime_health(*, timeout_seconds: float = 60.0, interval_seconds: float = 2.0) -> dict[str, Any]:
    """Wait for bot lease/heartbeat and SaaS /healthz after a restart.

    Runtime processes are asynchronous. A tmux session can be created before
    port 8787 has bound, so an immediate snapshot can report a false failure.
    """
    from .retool_control import runtime_snapshot

    started = time.monotonic()
    attempts = 0
    last: dict[str, Any] = {}
    timeout_seconds = max(2.0, float(timeout_seconds))
    interval_seconds = max(0.2, float(interval_seconds))
    while True:
        attempts += 1
        last = runtime_snapshot()
        healthy = bool(last.get("bot_healthy") and last.get("saas_api_healthy"))
        if healthy:
            return {
                "ok": True,
                "attempts": attempts,
                "wait_seconds": round(time.monotonic() - started, 3),
                "runtime": last,
            }
        elapsed = time.monotonic() - started
        if elapsed >= timeout_seconds:
            return {
                "ok": False,
                "attempts": attempts,
                "wait_seconds": round(elapsed, 3),
                "reason": last.get("runtime_health_reason") or "runtime_health_timeout",
                "runtime": last,
            }
        time.sleep(min(interval_seconds, max(0.0, timeout_seconds - elapsed)))


def _current_alias_step() -> dict[str, Any]:
    from .current_install import ensure_current_alias

    return ensure_current_alias(Path(settings.base_dir))


def _config_integrity_step() -> dict[str, Any]:
    from .config_integrity import ConfigIntegrityGuard

    result = ConfigIntegrityGuard().preflight("post_update_finalize")
    return {
        "ok": bool(result.get("allowed", False)),
        "status": result.get("status"),
        "changed_count": int(result.get("changed_count") or 0),
        "critical_missing_count": int(result.get("critical_missing_count") or 0),
    }


def _version_step() -> dict[str, Any]:
    from . import __product_version__
    from phantom_v10 import __version__ as runtime_version

    result = _run_cli("version", timeout_seconds=30)
    result.update({
        "product_version": __product_version__,
        "runtime_version": runtime_version,
    })
    return result


def _runtime_restart_step() -> dict[str, Any]:
    from .retool_control import restart_bot

    result = dict(restart_bot() or {})
    supervisor = result.get("supervisor") if isinstance(result.get("supervisor"), dict) else {}
    restart_accepted = bool(result.get("ok") or supervisor.get("ok"))
    if not restart_accepted:
        result["runtime_healthy"] = False
        result["ok"] = False
        result["health_wait"] = {"ok": False, "reason": "restart_not_accepted"}
        return result

    wait = _wait_for_runtime_health(timeout_seconds=60.0, interval_seconds=2.0)
    snap = wait.get("runtime") if isinstance(wait.get("runtime"), dict) else {}
    result["runtime"] = snap
    result["health_wait"] = {k: v for k, v in wait.items() if k != "runtime"}
    result["runtime_healthy"] = bool(wait.get("ok"))
    result["health_score"] = snap.get("health_score")
    result["release"] = snap.get("release")
    result["ok"] = bool(restart_accepted and wait.get("ok"))
    return result


def _admin_bridge_restart_step() -> dict[str, Any]:
    from .retool_server import start, status as bridge_status, stop

    before = bridge_status()
    stop_result = stop(timeout_seconds=8.0)
    if not stop_result.get("ok"):
        return {"ok": False, "before": before, "stop": stop_result, "start": None}
    start_result = start()
    after = bridge_status()
    return {
        "ok": bool(start_result.get("ok") and after.get("running")),
        "before": before,
        "stop": stop_result,
        "start": start_result,
        "after": after,
    }


def run(*, restart_runtime: bool = True, restart_admin_bridge: bool = True) -> dict[str, Any]:
    """Finalize an already-applied update with fail-closed validation.

    Validation commands run first. Runtime/Admin Bridge restarts only happen if
    migrate, DB integrity, selftest, release-check, version and config integrity
    all succeed. A failed validation leaves the currently running services
    untouched so the administrator keeps a working control surface for diagnosis.
    """

    _acquire_lock()
    report: dict[str, Any] = {
        "version": VERSION,
        "status": "RUNNING",
        "started_at": _now(),
        "finished_at": None,
        "restart_runtime_requested": bool(restart_runtime),
        "restart_admin_bridge_requested": bool(restart_admin_bridge),
        "steps": {},
    }
    _save(report)

    validation_steps = [
        ("migrate", _migrate_in_place_step),
        ("db_check", lambda: _run_cli("db-check", timeout_seconds=120)),
        ("selftest", lambda: _run_cli("selftest", timeout_seconds=360)),
        ("release_check", lambda: _run_cli("release-check", timeout_seconds=240)),
        ("version", _version_step),
        ("config_integrity", _config_integrity_step),
        ("current_alias", _current_alias_step),
    ]

    try:
        for name, runner in validation_steps:
            if not _step(report, name, runner):
                report["status"] = "BLOCKED"
                report["blocked_by"] = name
                report["finished_at"] = _now()
                return _save(report)

        if restart_runtime:
            if not _step(report, "runtime_restart", _runtime_restart_step):
                report["status"] = "FAILED"
                report["blocked_by"] = "runtime_restart"
                report["finished_at"] = _now()
                return _save(report)
        else:
            report["steps"]["runtime_restart"] = {"ok": True, "skipped": True}
            _save(report)

        if restart_admin_bridge:
            if not _step(report, "admin_bridge_restart", _admin_bridge_restart_step):
                report["status"] = "FAILED"
                report["blocked_by"] = "admin_bridge_restart"
                report["finished_at"] = _now()
                return _save(report)
        else:
            report["steps"]["admin_bridge_restart"] = {"ok": True, "skipped": True}
            _save(report)

        report["status"] = "APPROVED"
        report["blocked_by"] = None
        report["finished_at"] = _now()
        return _save(report)
    finally:
        _clear_lock()


def launch_background(*, delay_seconds: float = 1.2) -> dict[str, Any]:
    current = status()
    if current.get("running"):
        raise PostUpdateError(f"post_update_already_running: pid={current.get('pid')}")

    main = Path(settings.base_dir) / "main.py"
    log_handle = _log_file().open("ab", buffering=0)
    try:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-u",
                str(main),
                "post-update",
                "--delay",
                str(max(0.0, float(delay_seconds))),
            ],
            cwd=str(settings.base_dir),
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
            env=os.environ.copy(),
        )
    finally:
        log_handle.close()

    # Reserve the lock immediately so repeated Retool clicks cannot start
    # multiple finalizers during the short HTTP-release delay.
    _lock_file().write_text(
        json.dumps({"pid": proc.pid, "started_at": _now(), "source": "retool"}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    return {
        "ok": True,
        "accepted": True,
        "pid": proc.pid,
        "status_endpoint": "/api/update/finalize/status",
        "message": "Finalização iniciada; acompanhe pelo status.",
    }
