from __future__ import annotations

from html import escape
from typing import Any

from .experience import BRAND_DIVIDER


RISK_LABELS = {
    "conservative": "Conservador",
    "moderate": "Moderado",
    "aggressive": "Agressivo",
}
DETAIL_LABELS = {
    "compact": "Compacto",
    "standard": "Equilibrado",
    "detailed": "Detalhado",
}
FREQUENCY_LABELS = {
    "plan": "Padrão do plano",
    "reduced": "Reduzida",
    "priority": "Prioritária",
}
QUIET_LABELS = {
    "off": "Desativado",
    "22-07": "22h às 07h",
    "00-07": "00h às 07h",
}


def build_preferences_screen(app: Any, user_id: int) -> tuple[str, dict[str, Any]]:
    profile = app.user_profiles.get(user_id)
    stored = app.storage.user_preferences(user_id)
    chains = ", ".join(profile.get("preferred_chains") or []) or "Todas"
    auto = "Ativos" if stored.get("auto_signals", True) else "Pausados"
    favorites = "Ativos" if stored.get("favorite_alerts", True) else "Pausados"
    expiry = "Ativos" if stored.get("expiry_alerts", True) else "Pausados"

    text = (
        f"{BRAND_DIVIDER}\n"
        "🎛️ <b>PHANTOM ALERT • PREFERÊNCIAS</b>\n"
        f"{BRAND_DIVIDER}\n\n"
        "🧭 <b>PERFIL DE ANÁLISE</b>\n"
        f"• Risco: <b>{RISK_LABELS.get(profile.get('risk_profile'), 'Moderado')}</b>\n"
        f"• Redes: <b>{escape(chains)}</b>\n"
        f"• Mensagens: <b>{DETAIL_LABELS.get(profile.get('detail_mode'), 'Equilibrado')}</b>\n"
        f"• Frequência: <b>{FREQUENCY_LABELS.get(profile.get('notification_frequency'), 'Padrão do plano')}</b>\n"
        f"• Horário silencioso: <b>{QUIET_LABELS.get(profile.get('quiet_hours'), 'Desativado')}</b>\n"
        f"• Idioma: <b>{escape(str(profile.get('language') or 'pt-BR'))}</b>\n\n"
        "🔔 <b>ALERTAS</b>\n"
        f"• Sinais automáticos: <b>{auto}</b>\n"
        f"• Favoritos: <b>{favorites}</b>\n"
        f"• Vencimento: <b>{expiry}</b>\n\n"
        "Toque em uma opção para alternar. A alteração é salva imediatamente."
    )
    keyboard = {
        "inline_keyboard": [
            [
                {"text": "🎯 Perfil de risco", "callback_data": "profile|risk"},
                {"text": "🌐 Redes", "callback_data": "profile|chains"},
            ],
            [
                {"text": "📝 Mensagens", "callback_data": "profile|detail"},
                {"text": "⏱ Frequência", "callback_data": "profile|frequency"},
            ],
            [
                {"text": "🌙 Horário silencioso", "callback_data": "profile|quiet"},
                {"text": "🌎 Idioma", "callback_data": "profile|language"},
            ],
            [{"text": "📡 Sinais automáticos", "callback_data": "pref|auto_signals"}],
            [{"text": "⭐ Alertas dos favoritos", "callback_data": "pref|favorite_alerts"}],
            [{"text": "📅 Avisos de vencimento", "callback_data": "pref|expiry_alerts"}],
            [{"text": "🧠 Minha Central", "callback_data": "intelligence_center"}],
            [{"text": "🏠 Menu", "callback_data": "menu"}],
        ]
    }
    return text, keyboard
