from __future__ import annotations

import json
import shutil
import sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


@dataclass(frozen=True)
class ProductReport:
    generated_at: str
    version: str
    environment: str
    database_path: str
    database_integrity: str
    users: int
    active_subscribers: int
    payments: int
    favorites: int
    analyses: int
    open_signals: int
    telegram_configured: bool
    asaas_configured: bool
    scanner_enabled: bool
    project_leader_enabled: bool
    maintenance_active: bool
    scanner_cycles_today: int
    tokens_discovered_today: int
    tokens_approved_today: int
    signals_sent_today: int
    last_scanner_cycle: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _table_count(conn: sqlite3.Connection, table: str, where: str = "", params: tuple = ()) -> int:
    exists = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone()
    if not exists:
        return 0
    query = f'SELECT COUNT(*) FROM "{table}"'
    if where:
        query += f" WHERE {where}"
    try:
        return int(conn.execute(query, params).fetchone()[0])
    except sqlite3.Error:
        return 0


def build_product_report() -> ProductReport:
    from csm import __version__
    from .project_leader import ProjectLeader

    integrity = "missing"
    users = subscribers = payments = favorites = analyses = open_signals = 0
    if settings.db_file.exists():
        conn = sqlite3.connect(settings.db_file)
        try:
            integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
            users = _table_count(conn, "users")
            subscribers = _table_count(
                conn,
                "users",
                "LOWER(COALESCE(plan, 'free')) NOT IN ('free', '') AND (expires_at IS NULL OR expires_at > ?)",
                (datetime.now(timezone.utc).isoformat(),),
            )
            payments = _table_count(conn, "payments")
            favorites = _table_count(conn, "favorites")
            analyses = _table_count(conn, "analyses")
            open_signals = _table_count(conn, "signal_positions", "status='OPEN'")
        finally:
            conn.close()

    scanner_cycles_today = tokens_discovered_today = tokens_approved_today = signals_sent_today = 0
    last_scanner_cycle = None
    if settings.db_file.exists():
        conn = sqlite3.connect(settings.db_file)
        try:
            if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='scanner_cycles'").fetchone():
                row = conn.execute(
                    """SELECT COUNT(*), COALESCE(SUM(discovered),0), COALESCE(SUM(approved),0),
                              COALESCE(SUM(sent),0), MAX(created_at)
                       FROM scanner_cycles WHERE date(created_at)=date('now','localtime')"""
                ).fetchone()
                scanner_cycles_today, tokens_discovered_today, tokens_approved_today, signals_sent_today, last_scanner_cycle = row
        finally:
            conn.close()

    maintenance = ProjectLeader().maintenance() if settings.project_leader_enabled else {"active": False}
    return ProductReport(
        generated_at=datetime.now(timezone.utc).isoformat(),
        version=__version__,
        environment=settings.app_environment,
        database_path=str(settings.db_file),
        database_integrity=integrity,
        users=users,
        active_subscribers=subscribers,
        payments=payments,
        favorites=favorites,
        analyses=analyses,
        open_signals=open_signals,
        telegram_configured=bool(settings.telegram_token and settings.telegram_chat_id),
        asaas_configured=bool(settings.payments_ready),
        scanner_enabled=bool(settings.auto_signals_enabled),
        project_leader_enabled=bool(settings.project_leader_enabled),
        maintenance_active=bool(maintenance.get("active")),
        scanner_cycles_today=int(scanner_cycles_today),
        tokens_discovered_today=int(tokens_discovered_today),
        tokens_approved_today=int(tokens_approved_today),
        signals_sent_today=int(signals_sent_today),
        last_scanner_cycle=last_scanner_cycle,
    )


def save_product_report(destination: str | Path | None = None) -> Path:
    report = build_product_report()
    folder = settings.data_dir / "reports"
    folder.mkdir(parents=True, exist_ok=True)
    target = Path(destination).expanduser() if destination else folder / "product_status.json"
    if not target.is_absolute():
        target = settings.base_dir / target
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def initialize_staging(*, copy_config: bool = False) -> dict[str, str]:
    """Cria um ambiente de homologação isolado, sem copiar o banco de produção."""
    root = settings.base_dir.parent / "Crypto_Signals_Multichain_Staging_State"
    root.mkdir(parents=True, exist_ok=True)
    (root / "backups").mkdir(exist_ok=True)
    (root / "project_leader").mkdir(exist_ok=True)
    env_target = root / "config.env"
    if not env_target.exists():
        source = settings.data_dir / "config.env"
        if copy_config and source.exists():
            shutil.copy2(source, env_target)
            content = env_target.read_text(encoding="utf-8")
            lines = []
            for line in content.splitlines():
                if line.startswith("ASAAS_ENVIRONMENT="):
                    line = "ASAAS_ENVIRONMENT=sandbox"
                elif line.startswith("APP_ENVIRONMENT="):
                    line = "APP_ENVIRONMENT=staging"
                lines.append(line)
            if not any(line.startswith("APP_ENVIRONMENT=") for line in lines):
                lines.append("APP_ENVIRONMENT=staging")
            env_target.write_text("\n".join(lines) + "\n", encoding="utf-8")
        else:
            env_target.write_text(
                "APP_ENVIRONMENT=staging\n"
                "ASAAS_ENVIRONMENT=sandbox\n"
                "ENABLE_TELEGRAM=false\n"
                "AUTO_SIGNALS_ENABLED=false\n",
                encoding="utf-8",
            )
    launcher = settings.base_dir / "run_staging.sh"
    launcher.write_text(
        "#!/bin/sh\n"
        f"export CSM_STATE_DIR='{root}'\n"
        "export APP_ENVIRONMENT=staging\n"
        "python main.py \"$@\"\n",
        encoding="utf-8",
    )
    try:
        launcher.chmod(0o700)
    except OSError:
        pass
    return {"state_dir": str(root), "config": str(env_target), "launcher": str(launcher)}
