from __future__ import annotations

from . import __product_version__

import compileall
import json
import platform
import resource
import shutil
import sqlite3
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings
from .product_ops import build_product_report
from .security import verify_file

LTS_BASE = "6.3.0"
RELEASE = "8.2.1"


@dataclass
class ReleaseCheck:
    created_at: str
    release: str
    lts_base: str
    passed: bool
    checks: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _check(name: str, ok: bool, details: str) -> dict[str, Any]:
    return {"name": name, "ok": bool(ok), "details": details}


def resource_snapshot() -> dict[str, Any]:
    usage = resource.getrusage(resource.RUSAGE_SELF)
    # ru_maxrss is KB on Linux and bytes on macOS/iOS. Keep raw and label it.
    return {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "max_rss_raw": int(usage.ru_maxrss),
        "user_cpu_seconds": round(float(usage.ru_utime), 3),
        "system_cpu_seconds": round(float(usage.ru_stime), 3),
    }


def admin_dashboard() -> dict[str, Any]:
    report = build_product_report().to_dict()
    report["resources"] = resource_snapshot()
    report["release"] = RELEASE
    report["product_release"] = __product_version__
    report["lts_base"] = LTS_BASE
    report["generated_at"] = datetime.now(timezone.utc).isoformat()
    return report


def run_release_check() -> ReleaseCheck:
    checks: list[dict[str, Any]] = []

    compiled = compileall.compile_dir(str(settings.base_dir), quiet=1, force=False)
    checks.append(_check("Compilação Python", compiled, "compileall"))
    for cache in settings.base_dir.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)

    db_ok = True
    db_details = "ausente; será criado no primeiro uso"
    if settings.db_file.exists():
        try:
            with sqlite3.connect(settings.db_file) as conn:
                integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
                schema = int(conn.execute("PRAGMA user_version").fetchone()[0])
            db_ok = integrity == "ok" and schema > 0
            db_details = f"integridade={integrity}; schema={schema}"
        except sqlite3.Error as exc:
            db_ok = False
            db_details = str(exc)
    checks.append(_check("Banco persistente", db_ok, db_details))

    forbidden = []
    for pattern in ("*.pyc", "*.pyo", "*.db", "*.sqlite", "*.sqlite3", "*.zip"):
        for path in settings.base_dir.rglob(pattern):
            if any(part in {"backups", "exports"} for part in path.parts):
                continue
            forbidden.append(str(path.relative_to(settings.base_dir)))
    for cache in settings.base_dir.rglob("__pycache__"):
        forbidden.append(str(cache.relative_to(settings.base_dir)))
    checks.append(_check("Pacote limpo", not forbidden, "ok" if not forbidden else ", ".join(forbidden[:10])))

    config_ok = settings.data_dir.exists()
    checks.append(_check("Diretório persistente", config_ok, str(settings.data_dir)))

    integrity_files = sorted((settings.data_dir / "backups").glob("*.integrity.json")) if (settings.data_dir / "backups").exists() else []
    signed_ok = True
    signed_details = "nenhum backup assinado disponível"
    if integrity_files:
        sidecar = integrity_files[-1]
        source = Path(str(sidecar)[:-len(".integrity.json")])
        try:
            result = verify_file(source)
            signed_ok = bool(result.get("ok"))
            signed_details = json.dumps(result, ensure_ascii=False)
        except Exception as exc:  # diagnóstico não deve abortar
            signed_ok = False
            signed_details = str(exc)
    checks.append(_check("Integridade de backup", signed_ok, signed_details))

    return ReleaseCheck(
        created_at=datetime.now(timezone.utc).isoformat(),
        release=RELEASE,
        lts_base=LTS_BASE,
        passed=all(item["ok"] for item in checks),
        checks=checks,
    )


def save_admin_dashboard() -> Path:
    target = settings.data_dir / "reports" / "admin_dashboard.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(admin_dashboard(), ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def save_release_check() -> Path:
    result = run_release_check()
    target = settings.data_dir / "reports" / "release_check.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return target
