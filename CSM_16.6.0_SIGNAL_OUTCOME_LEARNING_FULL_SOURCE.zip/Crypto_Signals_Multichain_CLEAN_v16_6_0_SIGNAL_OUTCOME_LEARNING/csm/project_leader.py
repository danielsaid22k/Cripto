from __future__ import annotations

import compileall
import hashlib
import json
import os
import secrets
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


@dataclass
class Finding:
    code: str
    severity: str
    title: str
    details: str
    action: str | None = None


@dataclass
class Proposal:
    proposal_id: str
    created_at: str
    title: str
    reason: str
    severity: str
    action: str
    parameters: dict[str, Any]
    status: str = "PENDING"
    approval_code_hash: str = ""
    approved_at: str | None = None
    applied_at: str | None = None
    result: str = ""


class ProjectLeaderError(RuntimeError):
    pass


class ProjectLeader:
    """Líder técnico com aprovação humana obrigatória.

    O componente pode auditar e corrigir apenas operações explicitamente
    permitidas. Mudanças de código exigem um pacote ZIP com manifesto e hashes.
    Nenhuma ação é aplicada sem aprovação do administrador.
    """

    SAFE_ACTIONS = {
        "ensure_runtime_dirs",
        "remove_stale_lock",
        "clear_python_cache",
        "rotate_log",
        "database_backup",
        "apply_update_bundle",
    }

    def __init__(self, base_dir: Path | None = None, state_dir: Path | None = None):
        self.base_dir = (base_dir or settings.base_dir).resolve()
        self.state_dir = (state_dir or settings.data_dir).resolve()
        self.root = self.state_dir / "project_leader"
        self.proposals_dir = self.root / "proposals"
        self.reports_dir = self.root / "reports"
        self.updates_dir = self.root / "updates"
        self.inbox_dir = self.updates_dir / "inbox"
        self.applied_dir = self.updates_dir / "applied"
        self.snapshots_dir = self.root / "snapshots"
        self.maintenance_file = self.root / "maintenance.json"
        for folder in (
            self.proposals_dir,
            self.reports_dir,
            self.inbox_dir,
            self.applied_dir,
            self.snapshots_dir,
        ):
            folder.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _hash(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    @staticmethod
    def _sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def maintenance(self) -> dict[str, Any]:
        if not self.maintenance_file.exists():
            return {"active": False}
        try:
            data = json.loads(self.maintenance_file.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {"active": False}
        except (OSError, json.JSONDecodeError):
            return {"active": False}

    def set_maintenance(self, active: bool, *, reason: str = "", eta_minutes: int = 0) -> dict[str, Any]:
        data = {
            "active": bool(active),
            "reason": reason.strip() or "Atualização técnica programada",
            "eta_minutes": max(0, int(eta_minutes)),
            "started_at": self._now() if active else None,
            "updated_at": self._now(),
        }
        self.maintenance_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return data

    def maintenance_message(self) -> str:
        state = self.maintenance()
        if not state.get("active"):
            return ""
        eta = int(state.get("eta_minutes") or 0)
        total_seconds = eta * 60
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        eta_text = (f"Previsão: {hours:02d}h {minutes:02d}m {seconds:02d}s."
                    if eta else "Previsão em atualização.")
        return (
            "🛠️ <b>SISTEMA EM MANUTENÇÃO</b>\n\n"
            f"Motivo: <b>{state.get('reason') or 'Atualização técnica'}</b>\n"
            f"{eta_text}\n\n"
            "Seus dados, assinatura e histórico permanecem preservados."
        )

    def audit(self) -> dict[str, Any]:
        findings: list[Finding] = []
        expected_paths = {
            "data": self.base_dir / "data",
            "logs": Path(settings.logs_dir),
            "backups": self.base_dir / "backups",
            "exports": self.base_dir / "exports",
            "tests": self.base_dir / "tests",
            "csm": self.base_dir / "csm",
        }
        missing = [name for name, path in expected_paths.items() if not path.exists()]
        if missing:
            findings.append(Finding(
                "MISSING_DIRS", "medium", "Diretórios ausentes",
                ", ".join(missing), "ensure_runtime_dirs",
            ))

        lock = self.base_dir / "data" / ".bot.lock"
        if lock.exists():
            stale = False
            try:
                pid_text = lock.read_text(encoding="utf-8").strip()
                pid = int(pid_text)
                try:
                    os.kill(pid, 0)
                except OSError:
                    stale = True
            except (OSError, ValueError):
                stale = True
            if stale:
                findings.append(Finding(
                    "STALE_LOCK", "high", "Trava órfã detectada",
                    str(lock), "remove_stale_lock",
                ))

        db_path = Path(settings.db_file)
        if db_path.exists():
            try:
                with sqlite3.connect(db_path) as conn:
                    integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
                if integrity != "ok":
                    findings.append(Finding(
                        "DB_INTEGRITY", "critical", "Banco com falha de integridade",
                        str(integrity), "database_backup",
                    ))
            except sqlite3.Error as exc:
                findings.append(Finding(
                    "DB_OPEN", "critical", "Banco não pôde ser verificado",
                    str(exc), "database_backup",
                ))

        log_file = Path(settings.log_file)
        if log_file.exists() and log_file.stat().st_size > settings.project_leader_log_max_bytes:
            findings.append(Finding(
                "LOG_SIZE", "low", "Log principal muito grande",
                f"{log_file.stat().st_size} bytes", "rotate_log",
            ))

        # __pycache__ é esperado após validate_runtime(), que executa compileall.
        # A ação clear_python_cache permanece disponível para manutenção manual,
        # mas caches normais não devem reduzir a saúde nem gerar propostas automáticas.

        bundles = sorted(self.inbox_dir.glob("*.zip"))
        for bundle in bundles:
            try:
                manifest = self.validate_update_bundle(bundle)
                findings.append(Finding(
                    f"UPDATE_{manifest['update_id']}", "medium",
                    f"Atualização disponível: {manifest.get('title') or manifest['update_id']}",
                    str(bundle), "apply_update_bundle",
                ))
            except Exception as exc:
                findings.append(Finding(
                    f"INVALID_UPDATE_{bundle.name}", "high", "Pacote de atualização inválido",
                    str(exc), None,
                ))

        severity_weight = {"low": 5, "medium": 12, "high": 25, "critical": 50}
        penalty = sum(severity_weight.get(item.severity, 10) for item in findings)
        health_score = max(0, 100 - penalty)
        suggestions = []
        if not findings:
            suggestions.append("Sistema saudável; manter a rotina de backup e homologação.")
        if any(item.code == "LOG_SIZE" for item in findings):
            suggestions.append("Rotacionar logs para reduzir armazenamento e facilitar auditoria.")
        if any(item.code == "PYCACHE" for item in findings):
            suggestions.append("Limpar caches Python antes do próximo pacote de produção.")
        if any(item.code.startswith("UPDATE_") for item in findings):
            suggestions.append("Validar o pacote no ambiente de homologação antes da aprovação.")

        report = {
            "version": "2.0",
            "health_score": health_score,
            "suggestions": suggestions,
            "created_at": self._now(),
            "base_dir": str(self.base_dir),
            "state_dir": str(self.state_dir),
            "findings": [asdict(item) for item in findings],
            "summary": {
                "total": len(findings),
                "critical": sum(item.severity == "critical" for item in findings),
                "high": sum(item.severity == "high" for item in findings),
                "actionable": sum(bool(item.action) for item in findings),
            },
        }
        path = self.reports_dir / f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return report

    def proposals_from_audit(self, report: dict[str, Any]) -> list[tuple[Proposal, str]]:
        created: list[tuple[Proposal, str]] = []
        existing_actions = {p.action for p in self.list_proposals() if p.status in {"PENDING", "APPROVED"}}
        for finding in report.get("findings", []):
            action = finding.get("action")
            if not action or action not in self.SAFE_ACTIONS or action in existing_actions:
                continue
            parameters: dict[str, Any] = {}
            if action == "apply_update_bundle":
                parameters["bundle"] = finding.get("details")
            proposal, code = self.create_proposal(
                title=finding.get("title") or action,
                reason=finding.get("details") or "Auditoria automática",
                severity=finding.get("severity") or "medium",
                action=action,
                parameters=parameters,
            )
            created.append((proposal, code))
        return created

    def create_proposal(
        self, *, title: str, reason: str, severity: str, action: str,
        parameters: dict[str, Any] | None = None,
    ) -> tuple[Proposal, str]:
        if action not in self.SAFE_ACTIONS:
            raise ProjectLeaderError(f"ação não permitida: {action}")
        proposal_id = datetime.now().strftime("PL%Y%m%d%H%M%S") + secrets.token_hex(2).upper()
        code = f"{secrets.randbelow(1_000_000):06d}"
        proposal = Proposal(
            proposal_id=proposal_id,
            created_at=self._now(),
            title=title,
            reason=reason,
            severity=severity,
            action=action,
            parameters=parameters or {},
            approval_code_hash=self._hash(code),
        )
        self._write_proposal(proposal)
        return proposal, code

    def _proposal_path(self, proposal_id: str) -> Path:
        safe = "".join(ch for ch in proposal_id if ch.isalnum() or ch in "-_")
        return self.proposals_dir / f"{safe}.json"

    def _write_proposal(self, proposal: Proposal) -> None:
        self._proposal_path(proposal.proposal_id).write_text(
            json.dumps(asdict(proposal), ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def get_proposal(self, proposal_id: str) -> Proposal:
        path = self._proposal_path(proposal_id)
        if not path.exists():
            raise ProjectLeaderError("proposta não encontrada")
        return Proposal(**json.loads(path.read_text(encoding="utf-8")))

    def list_proposals(self, status: str | None = None) -> list[Proposal]:
        result: list[Proposal] = []
        for path in sorted(self.proposals_dir.glob("*.json"), reverse=True):
            try:
                proposal = Proposal(**json.loads(path.read_text(encoding="utf-8")))
                if status is None or proposal.status == status:
                    result.append(proposal)
            except Exception:
                continue
        return result

    def approve(self, proposal_id: str, code: str) -> Proposal:
        proposal = self.get_proposal(proposal_id)
        if proposal.status != "PENDING":
            raise ProjectLeaderError(f"proposta está em estado {proposal.status}")
        if not secrets.compare_digest(proposal.approval_code_hash, self._hash(code.strip())):
            raise ProjectLeaderError("código de aprovação inválido")
        proposal.status = "APPROVED"
        proposal.approved_at = self._now()
        self._write_proposal(proposal)
        return proposal

    def apply(self, proposal_id: str, *, eta_minutes: int = 5) -> Proposal:
        # CONFIG_INTEGRITY_UPDATE_PREFLIGHT_V1646
        from .config_integrity import ConfigIntegrityGuard
        _integrity = ConfigIntegrityGuard().preflight(
            'apply_update_bundle'
        )
        if not _integrity.get('allowed', True):
            raise ProjectLeaderError(
                'config_integrity_blocked: '
                f"status={_integrity.get('status')} "
                f"critical_missing={_integrity.get('critical_missing_count')}"
            )

        proposal = self.get_proposal(proposal_id)
        if proposal.status != "APPROVED":
            raise ProjectLeaderError("a proposta precisa estar APPROVED")
        if proposal.action not in self.SAFE_ACTIONS:
            raise ProjectLeaderError("ação fora da lista permitida")

        rollback_created_files: list[Path] = []
        rollback_bundle: Path | None = None
        rollback_applied_bundle: Path | None = None

        # Para updates, registra ANTES da aplicação quais arquivos ainda
        # não existiam. Se a validação posterior falhar, eles serão removidos
        # antes da restauração do snapshot.
        if proposal.action == "apply_update_bundle":
            rollback_bundle = Path(
                str(proposal.parameters.get("bundle") or "")
            ).expanduser().resolve()

            manifest = self.validate_update_bundle(rollback_bundle)
            rollback_applied_bundle = self.applied_dir / rollback_bundle.name

            for item in manifest["files"]:
                rel = Path(str(item["path"]))
                target = (self.base_dir / rel).resolve()
                if not target.exists():
                    rollback_created_files.append(target)

        # Cria o snapshot ANTES de entrar em manutenção.
        # Se o snapshot falhar, nenhuma alteração será executada.
        snapshot = self.create_snapshot(proposal.proposal_id)
        self.set_maintenance(
            True,
            reason=proposal.title,
            eta_minutes=eta_minutes,
        )

        try:
            result = self._execute(proposal)

            # Compilação + selftest fazem parte da transação.
            self.validate_runtime()

            proposal.status = "APPLIED"
            proposal.applied_at = self._now()
            proposal.result = result
            self._write_proposal(proposal)

            self.set_maintenance(
                False,
                reason="Atualização concluída",
            )
            return proposal

        except Exception as exc:
            rollback_errors: list[str] = []

            # Remove arquivos que NÃO existiam antes do update.
            # Isso evita deixar código novo órfão após rollback.
            for target in sorted(
                rollback_created_files,
                key=lambda p: len(p.parts),
                reverse=True,
            ):
                try:
                    if target.is_dir():
                        shutil.rmtree(target)
                    else:
                        target.unlink(missing_ok=True)

                    # Remove apenas diretórios-pai que ficaram vazios.
                    parent = target.parent
                    while parent != self.base_dir:
                        try:
                            parent.rmdir()
                        except OSError:
                            break
                        parent = parent.parent

                except Exception as cleanup_exc:
                    rollback_errors.append(
                        f"cleanup {target}: {cleanup_exc}"
                    )

            # Restaura todos os arquivos que existiam no snapshot.
            try:
                self.restore_snapshot(snapshot)
            except Exception as restore_exc:
                rollback_errors.append(
                    f"restore_snapshot: {restore_exc}"
                )

            # apply_update_bundle move o ZIP para applied.
            # Se a validação falhou, devolve o pacote à localização original
            # para que ele não seja registrado como aplicado com sucesso.
            if (
                rollback_bundle is not None
                and rollback_applied_bundle is not None
                and rollback_applied_bundle.exists()
                and not rollback_bundle.exists()
            ):
                try:
                    rollback_bundle.parent.mkdir(
                        parents=True,
                        exist_ok=True,
                    )
                    shutil.move(
                        str(rollback_applied_bundle),
                        str(rollback_bundle),
                    )
                except Exception as bundle_exc:
                    rollback_errors.append(
                        f"restore_bundle: {bundle_exc}"
                    )

            proposal.status = "ROLLED_BACK"

            details = f"{type(exc).__name__}: {exc}"
            if rollback_errors:
                details += " | rollback warnings: " + "; ".join(
                    rollback_errors
                )

            proposal.result = details
            self._write_proposal(proposal)

            self.set_maintenance(
                False,
                reason=(
                    "Rollback concluído"
                    if not rollback_errors
                    else "Rollback concluído com alertas"
                ),
            )

            if rollback_errors:
                raise ProjectLeaderError(details) from exc

            raise

    def _execute(self, proposal: Proposal) -> str:
        action = proposal.action
        if action == "ensure_runtime_dirs":
            for path in (
                self.base_dir / "data",
                Path(settings.logs_dir),
                self.base_dir / "backups",
                self.base_dir / "exports",
                self.base_dir / "tests",
            ):
                path.mkdir(parents=True, exist_ok=True)
            return "diretórios verificados/criados"
        if action == "remove_stale_lock":
            lock = self.base_dir / "data" / ".bot.lock"
            lock.unlink(missing_ok=True)
            return "trava órfã removida"
        if action == "clear_python_cache":
            count = 0
            for path in self.base_dir.rglob("__pycache__"):
                shutil.rmtree(path, ignore_errors=True)
                count += 1
            for path in self.base_dir.rglob("*.pyc"):
                path.unlink(missing_ok=True)
            return f"{count} cache(s) removido(s)"
        if action == "rotate_log":
            log_file = Path(settings.log_file)
            if log_file.exists():
                target = log_file.with_name(f"{log_file.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{log_file.suffix}")
                log_file.replace(target)
                log_file.touch()
                return f"log movido para {target.name}"
            return "nenhum log para rotacionar"
        if action == "database_backup":
            from .persistence import create_database_snapshot
            target = create_database_snapshot(settings.db_file, label="leader")
            return f"snapshot criado: {target}"
        if action == "apply_update_bundle":
            bundle = Path(str(proposal.parameters.get("bundle") or ""))
            return self.apply_update_bundle(bundle)
        raise ProjectLeaderError(f"ação não implementada: {action}")

    def create_snapshot(self, label: str) -> Path:
        target = self.snapshots_dir / f"snapshot_{label}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        exclusions = {".env", "backups", "logs", "__pycache__", ".pytest_cache"}
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in self.base_dir.rglob("*"):
                if not path.is_file():
                    continue
                rel = path.relative_to(self.base_dir)
                if any(part in exclusions for part in rel.parts) or path.suffix == ".pyc":
                    continue
                archive.write(path, rel.as_posix())
        return target

    def restore_snapshot(self, snapshot: Path) -> None:
        if not snapshot.exists():
            raise ProjectLeaderError("snapshot de rollback não encontrado")
        with zipfile.ZipFile(snapshot) as archive:
            for info in archive.infolist():
                target = (self.base_dir / info.filename).resolve()
                if self.base_dir not in target.parents and target != self.base_dir:
                    raise ProjectLeaderError("caminho inseguro no snapshot")
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(info) as source, target.open("wb") as output:
                        shutil.copyfileobj(source, output)

    def validate_update_bundle(self, bundle: Path) -> dict[str, Any]:
        bundle = bundle.expanduser().resolve()

        if not bundle.is_file() or bundle.suffix.lower() != ".zip":
            raise ProjectLeaderError(
                "arquivo ZIP de atualização não encontrado"
            )

        # Estes caminhos não fazem parte do snapshot normal e, portanto,
        # não podem ser modificados por um update transacional.
        protected_parts = {
            ".env",
            "backups",
            "logs",
            "__pycache__",
            ".pytest_cache",
        }

        def validate_rel_path(value: object, *, label: str) -> str:
            rel_text = str(value or "").strip()

            if not rel_text:
                raise ProjectLeaderError(
                    f"caminho vazio em {label}"
                )

            rel = Path(rel_text)

            if rel.is_absolute() or ".." in rel.parts:
                raise ProjectLeaderError(
                    f"caminho inseguro: {rel_text}"
                )

            if (
                any(part in protected_parts for part in rel.parts)
                or rel.suffix.lower() == ".pyc"
            ):
                raise ProjectLeaderError(
                    f"caminho não atualizável: {rel_text}"
                )

            target = (self.base_dir / rel).resolve()
            if (
                self.base_dir not in target.parents
                and target != self.base_dir
            ):
                raise ProjectLeaderError(
                    f"destino fora do projeto: {rel_text}"
                )

            return rel.as_posix()

        with zipfile.ZipFile(bundle) as archive:
            try:
                manifest = json.loads(
                    archive.read("update-manifest.json")
                )
            except KeyError as exc:
                raise ProjectLeaderError(
                    "update-manifest.json ausente"
                ) from exc
            except json.JSONDecodeError as exc:
                raise ProjectLeaderError(
                    "update-manifest.json inválido"
                ) from exc

            if not isinstance(manifest, dict):
                raise ProjectLeaderError(
                    "manifesto inválido"
                )

            required = {"update_id", "version", "files"}
            if not required.issubset(manifest):
                raise ProjectLeaderError(
                    "manifesto incompleto"
                )

            if not str(manifest.get("update_id") or "").strip():
                raise ProjectLeaderError(
                    "update_id vazio"
                )

            if not str(manifest.get("version") or "").strip():
                raise ProjectLeaderError(
                    "version vazia"
                )

            files = manifest.get("files")

            if not isinstance(files, list) or not files:
                raise ProjectLeaderError(
                    "lista de arquivos vazia"
                )

            delete = manifest.get("delete", [])
            if delete is None:
                delete = []

            if not isinstance(delete, list):
                raise ProjectLeaderError(
                    "campo delete inválido"
                )

            archive_names = archive.namelist()
            archive_name_set = set(archive_names)

            seen_files: set[str] = set()

            for item in files:
                if not isinstance(item, dict):
                    raise ProjectLeaderError(
                        "entrada inválida em files"
                    )

                rel = validate_rel_path(
                    item.get("path"),
                    label="files",
                )

                if rel in seen_files:
                    raise ProjectLeaderError(
                        f"arquivo duplicado no manifesto: {rel}"
                    )

                seen_files.add(rel)

                archive_name = f"payload/{rel}"

                if archive_name not in archive_name_set:
                    raise ProjectLeaderError(
                        f"arquivo ausente: {archive_name}"
                    )

                # ZIP com duas entradas de mesmo nome é ambíguo.
                if archive_names.count(archive_name) != 1:
                    raise ProjectLeaderError(
                        f"entrada ZIP duplicada: {archive_name}"
                    )

                expected_hash = str(
                    item.get("sha256") or ""
                ).lower()

                digest = hashlib.sha256(
                    archive.read(archive_name)
                ).hexdigest()

                if digest != expected_hash:
                    raise ProjectLeaderError(
                        f"hash inválido: {rel}"
                    )

            seen_delete: set[str] = set()

            for rel_value in delete:
                rel = validate_rel_path(
                    rel_value,
                    label="delete",
                )

                if rel in seen_delete:
                    raise ProjectLeaderError(
                        f"remoção duplicada: {rel}"
                    )

                if rel in seen_files:
                    raise ProjectLeaderError(
                        f"arquivo aparece em files e delete: {rel}"
                    )

                seen_delete.add(rel)

        return manifest

    def apply_update_bundle(self, bundle: Path) -> str:
        manifest = self.validate_update_bundle(bundle)
        with zipfile.ZipFile(bundle) as archive:
            # Only files explicitly listed and hash-validated by the manifest
            # are ever copied. Unlisted ZIP members cannot escape a temporary
            # extraction directory because no extractall() is used.
            for item in manifest["files"]:
                rel = Path(item["path"])
                target = (self.base_dir / rel).resolve()
                if self.base_dir not in target.parents and target != self.base_dir:
                    raise ProjectLeaderError(f"destino inseguro: {rel}")
                target.parent.mkdir(parents=True, exist_ok=True)
                archive_name = f"payload/{rel.as_posix()}"
                with archive.open(archive_name) as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output)
            for rel_text in manifest.get("delete", []):
                rel = Path(str(rel_text))
                target = (self.base_dir / rel).resolve()
                if self.base_dir not in target.parents:
                    raise ProjectLeaderError(f"remoção insegura: {rel}")
                if target.is_dir():
                    shutil.rmtree(target)
                else:
                    target.unlink(missing_ok=True)
        destination = self.applied_dir / bundle.name
        shutil.move(str(bundle), str(destination))
        return f"pacote {manifest['update_id']} aplicado; reinício automático recomendado"

    def validate_runtime(self) -> None:
        if not compileall.compile_dir(self.base_dir, quiet=1, force=True):
            raise ProjectLeaderError("falha na compilação Python")
        process = subprocess.run(
            [sys.executable, str(self.base_dir / "main.py"), "selftest"],
            cwd=self.base_dir,
            capture_output=True,
            text=True,
            timeout=settings.project_leader_validation_timeout,
        )
        if process.returncode != 0:
            details = (process.stdout + "\n" + process.stderr).strip()[-4000:]
            raise ProjectLeaderError(f"selftest falhou: {details}")
