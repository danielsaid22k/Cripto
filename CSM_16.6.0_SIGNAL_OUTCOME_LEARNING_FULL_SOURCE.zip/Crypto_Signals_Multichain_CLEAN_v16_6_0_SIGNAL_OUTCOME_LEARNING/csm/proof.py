from __future__ import annotations

import hashlib
import json
import os
import textwrap
import zipfile
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from .config import settings

PROOF_VERSION = "csm-proof-v1"
PROOF_ALGORITHM = "sha256-canonical-json-v1"
ZERO_HASH = "0" * 64


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        text = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def canonical_json(value: Any) -> str:
    """Deterministic JSON used by every v13 proof hash.

    We intentionally use only stdlib primitives and document the exact
    serialization contract so an independent buyer/verifier can reproduce the
    hashes without importing the product.
    """
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False, default=str)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def event_key(item: dict[str, Any], now: datetime | None = None) -> str:
    now = now or _utc_now()
    chain = str(item.get("chain") or "").strip().lower()
    address = str(item.get("address") or "").strip().lower()
    bucket = int(now.timestamp()) // 300
    return hashlib.sha256(f"{chain}|{address}|{bucket}".encode("utf-8")).hexdigest()[:32]


def _proof_id(event_key_value: str, signal_hash: str) -> str:
    return f"CSM13-{event_key_value[:10].upper()}-{signal_hash[:10].upper()}"


def _providers(item: dict[str, Any]) -> list[str]:
    raw = item.get("discovery_providers") or item.get("providers") or []
    if isinstance(raw, str):
        raw = [raw]
    return [str(v) for v in raw if str(v).strip()]


def _reasons(item: dict[str, Any]) -> list[str]:
    raw = item.get("approval_reasons") or []
    if isinstance(raw, str):
        raw = [raw]
    return [str(v) for v in raw if str(v).strip()]


def signal_payload_from_item(item: dict[str, Any], *, occurred_at: datetime, key: str | None = None) -> dict[str, Any]:
    """Immutable market facts committed before a Telegram delivery.

    No subscriber identifier, API secret, future outcome, observation count or
    mutable performance result is included in this payload.
    """
    key = key or event_key(item, occurred_at)
    gp = item.get("goplus_score")
    return {
        "proof_version": PROOF_VERSION,
        "event_key": key,
        "occurred_at": _iso(occurred_at),
        "chain": str(item.get("chain") or "").strip().lower(),
        "address": str(item.get("address") or "").strip(),
        "symbol": str(item.get("symbol") or "")[:64],
        "name": str(item.get("name") or "")[:120],
        "entry_price": _f(item.get("price")),
        "market_score": _i(item.get("market_opportunity_score") or item.get("opportunity_score") or item.get("score")),
        "final_score": _i(item.get("final_score") or item.get("opportunity_score") or item.get("score")),
        "goplus_score": _i(gp) if gp is not None else None,
        "goplus_risk": str(item.get("goplus_risk_level") or "")[:80],
        "goplus_buy_tax_pct": item.get("goplus_buy_tax_pct"),
        "goplus_sell_tax_pct": item.get("goplus_sell_tax_pct"),
        "goplus_top10_holders_pct": item.get("goplus_top10_holders_pct"),
        "liquidity": _f(item.get("liquidity")),
        "volume24h": _f(item.get("volume24h")),
        "marketcap": _f(item.get("marketcap")),
        "change24h": _f(item.get("change24h")),
        "buys24h": _i(item.get("buys24h")),
        "sells24h": _i(item.get("sells24h")),
        "source": str(item.get("source") or "")[:80],
        "providers": _providers(item),
        "approval_reasons": _reasons(item),
        "target1_pct": float(settings.signal_target1_pct),
        "target2_pct": float(settings.signal_target2_pct),
        "stop_pct": float(settings.signal_stop_pct),
    }


def signal_payload_from_row(row: dict[str, Any]) -> dict[str, Any]:
    try:
        providers = json.loads(str(row.get("providers_json") or "[]"))
        if not isinstance(providers, list):
            providers = []
    except Exception:
        providers = []
    try:
        reasons = json.loads(str(row.get("approval_reasons_json") or "[]"))
        if not isinstance(reasons, list):
            reasons = []
    except Exception:
        reasons = []
    occurred = _parse(row.get("created_at")) or _utc_now()
    return {
        "proof_version": PROOF_VERSION,
        "event_key": str(row.get("event_key") or ""),
        "occurred_at": _iso(occurred),
        "chain": str(row.get("chain") or "").strip().lower(),
        "address": str(row.get("address") or "").strip(),
        "symbol": str(row.get("symbol") or "")[:64],
        "name": str(row.get("name") or "")[:120],
        "entry_price": _f(row.get("entry_price")),
        "market_score": _i(row.get("market_score")),
        "final_score": _i(row.get("final_score")),
        "goplus_score": _i(row.get("goplus_score")) if row.get("goplus_score") is not None else None,
        "goplus_risk": str(row.get("goplus_risk") or "")[:80],
        "goplus_buy_tax_pct": row.get("goplus_buy_tax_pct"),
        "goplus_sell_tax_pct": row.get("goplus_sell_tax_pct"),
        "goplus_top10_holders_pct": row.get("goplus_top10_holders_pct"),
        "liquidity": _f(row.get("liquidity")),
        "volume24h": _f(row.get("volume24h")),
        "marketcap": _f(row.get("marketcap")),
        "change24h": _f(row.get("change24h")),
        "buys24h": _i(row.get("buys24h")),
        "sells24h": _i(row.get("sells24h")),
        "source": str(row.get("source") or "")[:80],
        "providers": [str(v) for v in providers],
        "approval_reasons": [str(v) for v in reasons],
        "target1_pct": _f(row.get("target1_pct"), settings.signal_target1_pct),
        "target2_pct": _f(row.get("target2_pct"), settings.signal_target2_pct),
        "stop_pct": _f(row.get("stop_pct"), settings.signal_stop_pct),
    }


def observation_payload_from_row(row: dict[str, Any]) -> dict[str, Any]:
    occurred = _parse(row.get("captured_at")) or _utc_now()
    return {
        "proof_version": PROOF_VERSION,
        "observation_id": _i(row.get("id")),
        "captured_at": _iso(occurred),
        "age_seconds": _f(row.get("age_seconds")),
        "price": _f(row.get("price")),
        "return_pct": _f(row.get("return_pct")),
        "liquidity": _f(row.get("liquidity")),
        "volume24h": _f(row.get("volume24h")),
        "marketcap": _f(row.get("marketcap")),
        "score": _i(row.get("score")),
        "source": str(row.get("source") or "")[:80],
    }


def _event_hash(
    *, proof_id: str, signal_id: int, event_type: str, source_ref: str,
    committed_at: str, occurred_at: str, commit_mode: str, previous_hash: str,
    payload_json: str,
) -> str:
    envelope = {
        "algorithm": PROOF_ALGORITHM,
        "proof_id": proof_id,
        "signal_id": int(signal_id),
        "event_type": event_type,
        "source_ref": str(source_ref),
        "committed_at": committed_at,
        "occurred_at": occurred_at,
        "commit_mode": commit_mode,
        "previous_hash": previous_hash,
        "payload": json.loads(payload_json),
    }
    return sha256_text(canonical_json(envelope))


def merkle_root(hashes: Iterable[str]) -> str:
    level = [bytes.fromhex(str(value)) for value in hashes if len(str(value)) == 64]
    if not level:
        return ZERO_HASH
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        nxt: list[bytes] = []
        for idx in range(0, len(level), 2):
            nxt.append(hashlib.sha256(level[idx] + level[idx + 1]).digest())
        level = nxt
    return level[0].hex()


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS proof_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            proof_id TEXT NOT NULL,
            event_type TEXT NOT NULL CHECK(event_type IN ('signal','observation')),
            source_ref TEXT NOT NULL,
            committed_at TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            commit_mode TEXT NOT NULL CHECK(commit_mode IN ('live_commit','legacy_backfill')),
            algorithm TEXT NOT NULL DEFAULT 'sha256-canonical-json-v1',
            payload_json TEXT NOT NULL,
            previous_hash TEXT NOT NULL,
            event_hash TEXT NOT NULL UNIQUE,
            UNIQUE(event_type, source_ref),
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE RESTRICT
        );
        CREATE INDEX IF NOT EXISTS idx_proof_events_signal ON proof_events(signal_id,id);
        CREATE INDEX IF NOT EXISTS idx_proof_events_proof ON proof_events(proof_id,id);
        CREATE INDEX IF NOT EXISTS idx_proof_events_committed ON proof_events(committed_at,id);

        CREATE TRIGGER IF NOT EXISTS proof_events_immutable_update
        BEFORE UPDATE ON proof_events
        BEGIN SELECT RAISE(ABORT, 'proof_events are append-only'); END;
        CREATE TRIGGER IF NOT EXISTS proof_events_immutable_delete
        BEFORE DELETE ON proof_events
        BEGIN SELECT RAISE(ABORT, 'proof_events are append-only'); END;

        CREATE TABLE IF NOT EXISTS proof_daily_roots (
            proof_date TEXT PRIMARY KEY,
            root_hash TEXT NOT NULL,
            event_count INTEGER NOT NULL,
            first_event_id INTEGER NOT NULL,
            last_event_id INTEGER NOT NULL,
            algorithm TEXT NOT NULL DEFAULT 'sha256-merkle-v1',
            sealed_at TEXT NOT NULL
        );
        CREATE TRIGGER IF NOT EXISTS proof_roots_immutable_update
        BEFORE UPDATE ON proof_daily_roots
        BEGIN SELECT RAISE(ABORT, 'proof_daily_roots are immutable once sealed'); END;
        CREATE TRIGGER IF NOT EXISTS proof_roots_immutable_delete
        BEFORE DELETE ON proof_daily_roots
        BEGIN SELECT RAISE(ABORT, 'proof_daily_roots are immutable once sealed'); END;

        CREATE TABLE IF NOT EXISTS proof_anchors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            proof_date TEXT NOT NULL,
            root_hash TEXT NOT NULL,
            chain TEXT NOT NULL,
            txid TEXT NOT NULL,
            url TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            UNIQUE(chain,txid),
            FOREIGN KEY(proof_date) REFERENCES proof_daily_roots(proof_date) ON DELETE RESTRICT
        );
        CREATE TRIGGER IF NOT EXISTS proof_anchors_immutable_update
        BEFORE UPDATE ON proof_anchors
        BEGIN SELECT RAISE(ABORT, 'proof_anchors are append-only'); END;
        CREATE TRIGGER IF NOT EXISTS proof_anchors_immutable_delete
        BEFORE DELETE ON proof_anchors
        BEGIN SELECT RAISE(ABORT, 'proof_anchors are append-only'); END;
        """
    )
    conn.commit()


@dataclass(frozen=True)
class PreparedSignalProof:
    proof_id: str
    event_key: str
    signal_hash: str
    event_hash: str
    payload_json: str
    committed_at: str
    occurred_at: datetime
    commit_mode: str = "live_commit"
    existing: bool = False

    def public_fields(self) -> dict[str, str]:
        return {
            "proof_id": self.proof_id,
            "proof_hash": self.event_hash,
            "proof_commit_mode": self.commit_mode,
        }


class ProofLedger:
    """V13 tamper-evident evidence chain for delivered signal performance.

    A live signal hash is prepared *before* Telegram send, can be embedded in the
    Telegram message, and is persisted only after delivery succeeds. Historical
    v12 records can be imported, but are explicitly labelled legacy_backfill so
    they are never misrepresented as pre-outcome commitments.
    """

    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)

    def _existing_signal_proof(self, *, signal_id: int | None = None, event_key_value: str | None = None):
        if signal_id is not None:
            return self.conn.execute(
                "SELECT * FROM proof_events WHERE signal_id=? AND event_type='signal' ORDER BY id LIMIT 1",
                (int(signal_id),),
            ).fetchone()
        if event_key_value:
            return self.conn.execute(
                """SELECT p.* FROM proof_events p JOIN signal_ledger s ON s.id=p.signal_id
                   WHERE p.event_type='signal' AND s.event_key=? ORDER BY p.id LIMIT 1""",
                (event_key_value,),
            ).fetchone()
        return None

    def prepare_signal(self, item: dict[str, Any], *, now: datetime | None = None) -> PreparedSignalProof | None:
        now = now or _utc_now()
        key = event_key(item, now)
        existing = self._existing_signal_proof(event_key_value=key)
        if existing:
            payload_json = str(existing["payload_json"])
            return PreparedSignalProof(
                proof_id=str(existing["proof_id"]), event_key=key,
                signal_hash=sha256_text(payload_json), event_hash=str(existing["event_hash"]),
                payload_json=payload_json, committed_at=str(existing["committed_at"]),
                occurred_at=_parse(existing["occurred_at"]) or now,
                commit_mode=str(existing["commit_mode"]), existing=True,
            )
        payload = signal_payload_from_item(item, occurred_at=now, key=key)
        if not payload["chain"] or not payload["address"] or _f(payload["entry_price"]) <= 0:
            return None
        payload_json = canonical_json(payload)
        signal_hash = sha256_text(payload_json)
        proof_id = _proof_id(key, signal_hash)
        committed_at = _iso(now)
        event_hash_value = _event_hash(
            proof_id=proof_id, signal_id=0, event_type="signal", source_ref=key,
            committed_at=committed_at, occurred_at=_iso(now), commit_mode="live_commit",
            previous_hash=ZERO_HASH, payload_json=payload_json,
        )
        # signal_id is unknown pre-delivery. The public precommit deliberately
        # hashes signal_id=0. Persistence reuses that exact envelope and stores
        # the actual signal_id as relational metadata, never as a hash input.
        return PreparedSignalProof(
            proof_id=proof_id, event_key=key, signal_hash=signal_hash,
            event_hash=event_hash_value, payload_json=payload_json,
            committed_at=committed_at, occurred_at=now,
        )

    def commit_prepared(self, signal_id: int, prepared: PreparedSignalProof) -> dict[str, Any]:
        existing = self._existing_signal_proof(signal_id=signal_id)
        if existing:
            if str(existing["event_hash"]) != prepared.event_hash and not prepared.existing:
                raise RuntimeError("signal proof mismatch for existing signal")
            return dict(existing)
        # Keep the exact pre-send hash. signal_id=0 is part of the externally
        # reproducible signal precommit envelope; signal_id remains DB metadata.
        self.conn.execute(
            """INSERT INTO proof_events(signal_id,proof_id,event_type,source_ref,committed_at,occurred_at,
               commit_mode,algorithm,payload_json,previous_hash,event_hash)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (
                int(signal_id), prepared.proof_id, "signal", prepared.event_key,
                prepared.committed_at, _iso(prepared.occurred_at), prepared.commit_mode,
                PROOF_ALGORITHM, prepared.payload_json, ZERO_HASH, prepared.event_hash,
            ),
        )
        self.conn.commit()
        return dict(self._existing_signal_proof(signal_id=signal_id))

    def _commit_signal_row(self, row: dict[str, Any], *, mode: str) -> dict[str, Any]:
        existing = self._existing_signal_proof(signal_id=int(row["id"]))
        if existing:
            return dict(existing)
        payload = signal_payload_from_row(row)
        payload_json = canonical_json(payload)
        signal_hash = sha256_text(payload_json)
        proof_id = _proof_id(str(row.get("event_key") or ""), signal_hash)
        committed_at = _iso()
        occurred_at = str(payload["occurred_at"])
        event_hash_value = _event_hash(
            proof_id=proof_id, signal_id=0, event_type="signal",
            source_ref=str(row.get("event_key") or row["id"]), committed_at=committed_at,
            occurred_at=occurred_at, commit_mode=mode, previous_hash=ZERO_HASH,
            payload_json=payload_json,
        )
        prepared = PreparedSignalProof(
            proof_id=proof_id, event_key=str(row.get("event_key") or row["id"]),
            signal_hash=signal_hash, event_hash=event_hash_value, payload_json=payload_json,
            committed_at=committed_at, occurred_at=_parse(occurred_at) or _utc_now(),
            commit_mode=mode,
        )
        return self.commit_prepared(int(row["id"]), prepared)

    def ensure_signal_proof(self, signal_id: int, *, mode: str = "legacy_backfill") -> dict[str, Any] | None:
        existing = self._existing_signal_proof(signal_id=signal_id)
        if existing:
            return dict(existing)
        row = self.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (int(signal_id),)).fetchone()
        if not row:
            return None
        return self._commit_signal_row(dict(row), mode=mode)

    def commit_observation(self, signal_id: int, observation_id: int, *, mode: str = "live_commit") -> dict[str, Any] | None:
        source_ref = str(int(observation_id))
        existing = self.conn.execute(
            "SELECT * FROM proof_events WHERE event_type='observation' AND source_ref=?",
            (source_ref,),
        ).fetchone()
        if existing:
            return dict(existing)
        signal_proof = self.ensure_signal_proof(signal_id, mode="legacy_backfill" if mode == "legacy_backfill" else "legacy_backfill")
        if not signal_proof:
            return None
        row = self.conn.execute("SELECT * FROM signal_observations WHERE id=? AND signal_id=?", (int(observation_id), int(signal_id))).fetchone()
        if not row:
            return None
        payload = observation_payload_from_row(dict(row))
        payload_json = canonical_json(payload)
        previous = self.conn.execute(
            "SELECT event_hash FROM proof_events WHERE signal_id=? ORDER BY id DESC LIMIT 1",
            (int(signal_id),),
        ).fetchone()
        previous_hash = str(previous["event_hash"]) if previous else ZERO_HASH
        signal_event = self._existing_signal_proof(signal_id=signal_id)
        proof_id = str(signal_event["proof_id"])
        committed_at = _iso()
        occurred_at = str(payload["captured_at"])
        event_hash_value = _event_hash(
            proof_id=proof_id, signal_id=int(signal_id), event_type="observation", source_ref=source_ref,
            committed_at=committed_at, occurred_at=occurred_at, commit_mode=mode,
            previous_hash=previous_hash, payload_json=payload_json,
        )
        self.conn.execute(
            """INSERT INTO proof_events(signal_id,proof_id,event_type,source_ref,committed_at,occurred_at,
               commit_mode,algorithm,payload_json,previous_hash,event_hash)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (
                int(signal_id), proof_id, "observation", source_ref, committed_at, occurred_at,
                mode, PROOF_ALGORITHM, payload_json, previous_hash, event_hash_value,
            ),
        )
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM proof_events WHERE event_hash=?", (event_hash_value,)).fetchone())

    def backfill_legacy(self, *, days: int = 3650, limit: int = 100000) -> dict[str, int]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        rows = self.conn.execute(
            "SELECT * FROM signal_ledger WHERE created_at>=? ORDER BY id ASC LIMIT ?",
            (cutoff, max(1, int(limit))),
        ).fetchall()
        signals = observations = skipped = 0
        for raw in rows:
            row = dict(raw)
            if self._existing_signal_proof(signal_id=int(row["id"])):
                skipped += 1
            else:
                self._commit_signal_row(row, mode="legacy_backfill")
                signals += 1
            obs_rows = self.conn.execute(
                "SELECT id FROM signal_observations WHERE signal_id=? ORDER BY id ASC", (int(row["id"]),)
            ).fetchall()
            for obs in obs_rows:
                exists = self.conn.execute(
                    "SELECT 1 FROM proof_events WHERE event_type='observation' AND source_ref=?", (str(obs["id"]),)
                ).fetchone()
                if exists:
                    continue
                if self.commit_observation(int(row["id"]), int(obs["id"]), mode="legacy_backfill"):
                    observations += 1
        return {"signals_backfilled": signals, "observations_backfilled": observations, "signals_already_proved": skipped}

    def proof_for_signal(self, signal_id: int) -> dict[str, Any] | None:
        events = self.conn.execute("SELECT * FROM proof_events WHERE signal_id=? ORDER BY id", (int(signal_id),)).fetchall()
        if not events:
            return None
        return {
            "signal_id": int(signal_id),
            "proof_id": str(events[0]["proof_id"]),
            "commit_mode": str(events[0]["commit_mode"]),
            "events": [dict(row) for row in events],
        }

    def _recalculate_event(self, row: dict[str, Any]) -> str:
        signal_hash_id = 0 if row.get("event_type") == "signal" else int(row.get("signal_id") or 0)
        return _event_hash(
            proof_id=str(row.get("proof_id") or ""), signal_id=signal_hash_id,
            event_type=str(row.get("event_type") or ""), source_ref=str(row.get("source_ref") or ""),
            committed_at=str(row.get("committed_at") or ""), occurred_at=str(row.get("occurred_at") or ""),
            commit_mode=str(row.get("commit_mode") or ""), previous_hash=str(row.get("previous_hash") or ""),
            payload_json=str(row.get("payload_json") or "{}"),
        )

    def verify_signal(self, signal_id: int) -> dict[str, Any]:
        proof = self.proof_for_signal(signal_id)
        if not proof:
            return {"ok": False, "signal_id": int(signal_id), "reason": "proof_missing"}
        errors: list[str] = []
        previous = ZERO_HASH
        events = proof["events"]
        for pos, event in enumerate(events):
            expected_previous = ZERO_HASH if pos == 0 else previous
            if str(event["previous_hash"]) != expected_previous:
                errors.append(f"event:{event['id']}:previous_hash")
            recalculated = self._recalculate_event(event)
            if recalculated != str(event["event_hash"]):
                errors.append(f"event:{event['id']}:hash")
            previous = str(event["event_hash"])

            if event["event_type"] == "signal":
                source = self.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (int(signal_id),)).fetchone()
                if not source:
                    errors.append("signal_source_missing")
                else:
                    if canonical_json(signal_payload_from_row(dict(source))) != str(event["payload_json"]):
                        errors.append("signal_source_mismatch")
            elif event["event_type"] == "observation":
                source = self.conn.execute("SELECT * FROM signal_observations WHERE id=?", (int(event["source_ref"]),)).fetchone()
                if not source:
                    errors.append(f"observation:{event['source_ref']}:missing")
                elif canonical_json(observation_payload_from_row(dict(source))) != str(event["payload_json"]):
                    errors.append(f"observation:{event['source_ref']}:mismatch")
        return {
            "ok": not errors,
            "signal_id": int(signal_id),
            "proof_id": proof["proof_id"],
            "commit_mode": proof["commit_mode"],
            "events": len(events),
            "head_hash": previous,
            "errors": errors,
        }

    def verify_all(self, *, days: int = 3650) -> dict[str, Any]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        ids = [int(row[0]) for row in self.conn.execute(
            "SELECT DISTINCT signal_id FROM proof_events WHERE committed_at>=? ORDER BY signal_id", (cutoff,)
        ).fetchall()]
        rows = [self.verify_signal(signal_id) for signal_id in ids]
        live = sum(1 for row in rows if row.get("commit_mode") == "live_commit")
        legacy = sum(1 for row in rows if row.get("commit_mode") == "legacy_backfill")
        failed = [row for row in rows if not row.get("ok")]
        roots = self.verify_roots()
        return {
            "ok": not failed and roots["ok"],
            "signals": len(rows),
            "live_commits": live,
            "legacy_backfills": legacy,
            "failed_signals": len(failed),
            "root_verification": roots,
            "failures": failed[:25],
        }

    def _events_for_commit_date(self, day: str) -> list[dict[str, Any]]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM proof_events WHERE substr(committed_at,1,10)=? ORDER BY id", (day,)
        ).fetchall()]

    def current_root(self, day: str | None = None) -> dict[str, Any]:
        day = day or _utc_now().date().isoformat()
        events = self._events_for_commit_date(day)
        return {
            "proof_date": day,
            "event_count": len(events),
            "first_event_id": int(events[0]["id"]) if events else 0,
            "last_event_id": int(events[-1]["id"]) if events else 0,
            "root_hash": merkle_root([row["event_hash"] for row in events]),
            "sealed": bool(self.conn.execute("SELECT 1 FROM proof_daily_roots WHERE proof_date=?", (day,)).fetchone()),
        }

    def seal_root(self, day: str, *, allow_today: bool = False) -> dict[str, Any]:
        try:
            parsed_day = date.fromisoformat(day)
        except ValueError as exc:
            raise ValueError("data deve usar YYYY-MM-DD") from exc
        if parsed_day > _utc_now().date() or (parsed_day == _utc_now().date() and not allow_today):
            raise ValueError("somente dias UTC encerrados podem ser selados")
        existing = self.conn.execute("SELECT * FROM proof_daily_roots WHERE proof_date=?", (day,)).fetchone()
        if existing:
            return dict(existing)
        root = self.current_root(day)
        if int(root["event_count"]) <= 0:
            raise ValueError("nenhum evento de prova nesta data")
        self.conn.execute(
            """INSERT INTO proof_daily_roots(proof_date,root_hash,event_count,first_event_id,last_event_id,algorithm,sealed_at)
               VALUES(?,?,?,?,?,'sha256-merkle-v1',?)""",
            (day, root["root_hash"], root["event_count"], root["first_event_id"], root["last_event_id"], _iso()),
        )
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM proof_daily_roots WHERE proof_date=?", (day,)).fetchone())

    def seal_due_roots(self, *, lookback_days: int = 30) -> int:
        today = _utc_now().date()
        dates = [str(row[0]) for row in self.conn.execute(
            """SELECT DISTINCT substr(committed_at,1,10) FROM proof_events
               WHERE committed_at>=? AND substr(committed_at,1,10)<? ORDER BY 1""",
            (_iso(_utc_now() - timedelta(days=max(1, int(lookback_days)))), today.isoformat()),
        ).fetchall()]
        count = 0
        for day in dates:
            if not self.conn.execute("SELECT 1 FROM proof_daily_roots WHERE proof_date=?", (day,)).fetchone():
                self.seal_root(day)
                count += 1
        return count

    def verify_roots(self) -> dict[str, Any]:
        rows = [dict(row) for row in self.conn.execute("SELECT * FROM proof_daily_roots ORDER BY proof_date").fetchall()]
        errors: list[str] = []
        for row in rows:
            current = self.current_root(str(row["proof_date"]))
            if int(current["event_count"]) != int(row["event_count"]) or current["root_hash"] != row["root_hash"]:
                errors.append(str(row["proof_date"]))
        return {"ok": not errors, "sealed_roots": len(rows), "invalid_dates": errors}

    def register_anchor(self, day: str, *, chain: str, txid: str, url: str = "") -> dict[str, Any]:
        root = self.conn.execute("SELECT * FROM proof_daily_roots WHERE proof_date=?", (day,)).fetchone()
        if not root:
            raise ValueError("raiz diária ainda não selada")
        chain = str(chain or "").strip().lower()
        txid = str(txid or "").strip()
        if not chain or len(txid) < 8:
            raise ValueError("chain e txid válidos são obrigatórios")
        self.conn.execute(
            "INSERT INTO proof_anchors(proof_date,root_hash,chain,txid,url,created_at) VALUES(?,?,?,?,?,?)",
            (day, root["root_hash"], chain[:40], txid[:256], str(url or "")[:1000], _iso()),
        )
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM proof_anchors WHERE chain=? AND txid=?", (chain[:40], txid[:256])).fetchone())

    def status(self) -> dict[str, Any]:
        counts = self.conn.execute(
            """SELECT
               SUM(CASE WHEN event_type='signal' THEN 1 ELSE 0 END),
               SUM(CASE WHEN event_type='signal' AND commit_mode='live_commit' THEN 1 ELSE 0 END),
               SUM(CASE WHEN event_type='signal' AND commit_mode='legacy_backfill' THEN 1 ELSE 0 END),
               SUM(CASE WHEN event_type='observation' THEN 1 ELSE 0 END)
               FROM proof_events"""
        ).fetchone()
        unproved = int(self.conn.execute(
            """SELECT COUNT(*) FROM signal_ledger s WHERE NOT EXISTS(
               SELECT 1 FROM proof_events p WHERE p.signal_id=s.id AND p.event_type='signal')"""
        ).fetchone()[0])
        sealed = int(self.conn.execute("SELECT COUNT(*) FROM proof_daily_roots").fetchone()[0])
        anchors = int(self.conn.execute("SELECT COUNT(*) FROM proof_anchors").fetchone()[0])
        today = self.current_root()
        return {
            "proof_version": PROOF_VERSION,
            "algorithm": PROOF_ALGORITHM,
            "signal_proofs": int(counts[0] or 0),
            "live_commits": int(counts[1] or 0),
            "legacy_backfills": int(counts[2] or 0),
            "observation_proofs": int(counts[3] or 0),
            "unproved_legacy_signals": unproved,
            "sealed_daily_roots": sealed,
            "anchors_registered": anchors,
            "today_provisional_root": today,
            "methodology": "live_commit hashes are prepared before Telegram delivery; legacy_backfill is explicitly post-hoc and never counted as pre-outcome proof.",
        }

    def public_dataset(self, *, days: int = 30) -> dict[str, Any]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        signal_rows = self.conn.execute(
            """SELECT s.id,s.chain,s.address,s.symbol,s.name,s.entry_price,s.final_score,s.goplus_score,
               s.max_return_pct,s.max_drawdown_pct,s.last_return_pct,s.first_tp1_at,s.first_tp2_at,s.first_stop_at,
               s.observations,s.status,s.created_at,p.proof_id,p.commit_mode,p.event_hash AS signal_commit_hash,p.committed_at
               FROM signal_ledger s JOIN proof_events p ON p.signal_id=s.id AND p.event_type='signal'
               WHERE s.created_at>=? ORDER BY s.id""",
            (cutoff,),
        ).fetchall()
        items: list[dict[str, Any]] = []
        for raw in signal_rows:
            row = dict(raw)
            events = [dict(e) for e in self.conn.execute(
                """SELECT proof_id,event_type,source_ref,committed_at,occurred_at,commit_mode,algorithm,payload_json,
                   previous_hash,event_hash FROM proof_events WHERE signal_id=? ORDER BY id""",
                (int(row["id"]),),
            ).fetchall()]
            for event in events:
                event["payload"] = json.loads(event.pop("payload_json"))
            row["proof_events"] = events
            items.append(row)
        roots = []
        for raw_root in self.conn.execute("SELECT * FROM proof_daily_roots ORDER BY proof_date").fetchall():
            root = dict(raw_root)
            root["event_hashes"] = [str(row[0]) for row in self.conn.execute(
                "SELECT event_hash FROM proof_events WHERE substr(committed_at,1,10)=? ORDER BY id",
                (root["proof_date"],),
            ).fetchall()]
            roots.append(root)
        anchors = [dict(row) for row in self.conn.execute("SELECT * FROM proof_anchors ORDER BY id").fetchall()]
        return {
            "format": "CSM_PROOF_EXPORT_V1",
            "generated_at": _iso(),
            "days": int(days),
            "proof_version": PROOF_VERSION,
            "algorithm": PROOF_ALGORITHM,
            "signals": items,
            "sealed_roots": roots,
            "anchors": anchors,
            "disclaimer": "legacy_backfill proves integrity only from backfill time onward; only live_commit was prepared before Telegram delivery.",
        }

    def export_bundle(self, *, days: int = 30, output: str | Path | None = None) -> Path:
        default_dir = settings.data_dir / "exports"
        default_dir.mkdir(parents=True, exist_ok=True)
        output_path = Path(output) if output else default_dir / f"CSM_Proof_Performance_{_utc_now().strftime('%Y%m%d_%H%M%S')}.zip"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        dataset = self.public_dataset(days=days)
        verify_script = _offline_verifier_script()
        readme = textwrap.dedent(
            f"""\
            # CSM V13 Proof of Performance bundle

            Generated: {dataset['generated_at']}
            Proof format: {PROOF_VERSION}
            Hash algorithm: {PROOF_ALGORITHM}

            Run offline verification with:

                python3 verify_proofs.py proofs.json

            `live_commit` means the proof hash was prepared before Telegram delivery.
            `legacy_backfill` means the historical V12 row was hashed only when imported into V13;
            it must never be presented as pre-outcome proof.

            Sealed daily roots can be independently published/anchored. Registered anchor
            transaction IDs are included in the dataset, but this offline verifier validates
            cryptographic consistency only; it does not query blockchains.
            """
        )
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("CSM_PROOF_BUNDLE/proofs.json", json.dumps(dataset, ensure_ascii=False, indent=2, default=str))
            zf.writestr("CSM_PROOF_BUNDLE/verify_proofs.py", verify_script)
            zf.writestr("CSM_PROOF_BUNDLE/README.md", readme)
        return output_path


def _offline_verifier_script() -> str:
    # Keep this verifier dependency-free and self-contained for a buyer/auditor.
    return r'''from __future__ import annotations
import hashlib, json, sys
ZERO="0"*64
ALG="sha256-canonical-json-v1"
def cj(v): return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False,default=str)
def h(t): return hashlib.sha256(t.encode("utf-8")).hexdigest()
def eh(e, signal_id):
    env={"algorithm":ALG,"proof_id":e["proof_id"],"signal_id":signal_id,"event_type":e["event_type"],"source_ref":str(e["source_ref"]),"committed_at":e["committed_at"],"occurred_at":e["occurred_at"],"commit_mode":e["commit_mode"],"previous_hash":e["previous_hash"],"payload":e["payload"]}
    return h(cj(env))
def merkle(values):
    level=[bytes.fromhex(x) for x in values]
    if not level:return ZERO
    while len(level)>1:
        if len(level)%2:level.append(level[-1])
        level=[hashlib.sha256(level[i]+level[i+1]).digest() for i in range(0,len(level),2)]
    return level[0].hex()
def main(path):
    data=json.load(open(path,encoding="utf-8")); errors=[]; byday={}
    for s in data.get("signals",[]):
        prev=ZERO
        for idx,e in enumerate(s.get("proof_events",[])):
            if e.get("previous_hash")!=prev:errors.append(f"{s.get('proof_id')}:previous:{idx}")
            sid=0 if e.get("event_type")=="signal" else int(s["id"])
            calc=eh(e,sid)
            if calc!=e.get("event_hash"):errors.append(f"{s.get('proof_id')}:hash:{idx}")
            prev=e.get("event_hash","")
            byday.setdefault(e.get("committed_at","")[:10],[]).append(e.get("event_hash",""))
    for r in data.get("sealed_roots",[]):
        values=r.get("event_hashes") or byday.get(r["proof_date"],[])
        if len(values)!=int(r["event_count"]) or merkle(values)!=r["root_hash"]:errors.append(f"root:{r['proof_date']}")
    print("CSM Proof Verification:", "OK" if not errors else "FAILED")
    print("Signals:",len(data.get("signals",[])),"Sealed roots:",len(data.get("sealed_roots",[])))
    if errors:
        print("Errors:"); [print("-",x) for x in errors[:50]]
    return 0 if not errors else 1
if __name__=="__main__": raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else "proofs.json"))
'''
