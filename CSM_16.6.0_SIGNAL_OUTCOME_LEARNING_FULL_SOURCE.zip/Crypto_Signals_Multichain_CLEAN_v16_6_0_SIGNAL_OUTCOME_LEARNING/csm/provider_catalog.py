from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class ProviderCatalogEntry:
    provider: str
    priority: int
    enabled: bool
    role: str
    note: str = ""


CATALOG: tuple[ProviderCatalogEntry, ...] = (
    ProviderCatalogEntry("GeckoTerminal", 10, True, "discovery", "Fonte pública validada na linha 8.x."),
    ProviderCatalogEntry("DexScreener", 20, True, "discovery", "Fonte pública com circuit breaker/cache."),
    ProviderCatalogEntry("DexPaprika", 25, True, "discovery+market", "Fonte pública/keyless adicional; API key gratuita opcional."),
    ProviderCatalogEntry("Birdeye", 30, False, "optional", "Adaptador reservado; requer chave/API e homologação antes de ativar."),
    ProviderCatalogEntry("DEXTools", 40, False, "optional", "Adaptador reservado; requer credenciais e homologação antes de ativar."),
    ProviderCatalogEntry("CoinGecko", 50, False, "optional", "Reservado para dados complementares; não usado como descoberta nesta release."),
    ProviderCatalogEntry("GoPlus", 60, True, "security", "Security gate pós-discovery; token opcional."),
    ProviderCatalogEntry("Honeypot.is", 65, True, "security-fallback", "Fallback EVM keyless para Ethereum/BSC/Base; advisory por padrão."),
)


def provider_catalog() -> list[dict[str, Any]]:
    return [asdict(item) for item in CATALOG]
