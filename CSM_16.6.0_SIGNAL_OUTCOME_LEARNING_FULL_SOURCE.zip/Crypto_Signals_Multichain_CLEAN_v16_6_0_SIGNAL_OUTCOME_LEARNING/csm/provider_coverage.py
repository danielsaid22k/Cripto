from __future__ import annotations

"""V16.5.9 provider/network coverage evidence and guard.

This module is deliberately evidence-first. It never changes scanner thresholds,
scores, plan quotas or Telegram delivery. The only active behavior it exposes is
a list of under-covered chains that the discovery layer may use to spend one
extra public-provider request when COVERAGE_GUARD_ENABLED=true.
"""

from collections import defaultdict
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from typing import Any

from .config import settings


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime | None = None) -> str:
    return (dt or _utc_now()).isoformat()


def _parse(value: Any) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        return None


def _i(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _path() -> Path:
    target = settings.data_dir / "reports" / "provider_coverage.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    return target


def _load() -> dict[str, Any]:
    target = _path()
    if not target.exists():
        return {"version": 1, "cycles": []}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"version": 1, "cycles": []}
    except Exception:
        return {"version": 1, "cycles": []}


def _save(data: dict[str, Any]) -> None:
    target = _path()
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temp.replace(target)


def capture_cycle(stats: dict[str, Any]) -> Path:
    """Persist one compact scanner-cycle coverage sample."""
    data = _load()
    cycles = [row for row in (data.get("cycles") or []) if isinstance(row, dict)]
    cycles.append(
        {
            "at": _iso(),
            "cycle_key": str(stats.get("cycle_key") or "")[:80],
            "tier": str(stats.get("discovery_tier") or "")[:20],
            "discovered": _i(stats.get("discovered")),
            "analyzed": _i(stats.get("analyzed")),
            "approved": _i(stats.get("approved")),
            "rejected": _i(stats.get("rejected")),
            "market_unavailable": _i(stats.get("market_unavailable")),
            "errors": _i(stats.get("errors")),
            "chain_stats": stats.get("chain_stats") or {},
            "provider_chain_candidates": stats.get("provider_chain_candidates") or {},
            "provider_chain_unique_added": stats.get("provider_chain_unique_added") or {},
            "provider_sources_ok": stats.get("provider_sources_ok") or {},
            "provider_sources_failed": stats.get("provider_sources_failed") or {},
        }
    )
    # ~48h at one cycle/minute is still tiny JSON and enough for baselines.
    cutoff = _utc_now() - timedelta(hours=48)
    cycles = [row for row in cycles[-3000:] if (_parse(row.get("at")) or cutoff) >= cutoff]
    data = {"version": 1, "updated_at": _iso(), "cycles": cycles}
    _save(data)
    return _path()


def coverage_status(*, minutes: int | None = None) -> dict[str, Any]:
    minutes = int(minutes or getattr(settings, "provider_coverage_window_minutes", 60))
    minutes = max(15, min(minutes, 24 * 60))
    cutoff = _utc_now() - timedelta(minutes=minutes)
    cycles = [
        row for row in (_load().get("cycles") or [])
        if isinstance(row, dict) and (_parse(row.get("at")) or datetime.min.replace(tzinfo=timezone.utc)) >= cutoff
    ]

    chains: dict[str, dict[str, Any]] = defaultdict(lambda: {
        "analyzed": 0, "approved": 0, "rejected": 0, "unavailable": 0,
        "provider_candidates": {}, "provider_unique_added": {},
    })
    providers: dict[str, dict[str, Any]] = defaultdict(lambda: {"candidates": 0, "unique_added": 0, "sources_ok": 0, "sources_failed": 0})

    for cycle in cycles:
        for chain, bucket in (cycle.get("chain_stats") or {}).items():
            target = chains[str(chain).lower()]
            target["analyzed"] += _i(bucket.get("analyzed"))
            target["approved"] += _i(bucket.get("approved"))
            target["rejected"] += _i(bucket.get("rejected"))
            target["unavailable"] += _i(bucket.get("unavailable"))
        for provider, by_chain in (cycle.get("provider_chain_candidates") or {}).items():
            for chain, count in (by_chain or {}).items():
                chain = str(chain).lower()
                chains[chain]["provider_candidates"][provider] = _i(chains[chain]["provider_candidates"].get(provider)) + _i(count)
                providers[provider]["candidates"] += _i(count)
        for provider, by_chain in (cycle.get("provider_chain_unique_added") or {}).items():
            for chain, count in (by_chain or {}).items():
                chain = str(chain).lower()
                chains[chain]["provider_unique_added"][provider] = _i(chains[chain]["provider_unique_added"].get(provider)) + _i(count)
                providers[provider]["unique_added"] += _i(count)
        for provider, count in (cycle.get("provider_sources_ok") or {}).items():
            providers[provider]["sources_ok"] += _i(count)
        for provider, count in (cycle.get("provider_sources_failed") or {}).items():
            providers[provider]["sources_failed"] += _i(count)

    enabled_chains = [str(c).lower() for c in getattr(settings, "scan_chains", ())]
    min_cycles = max(1, int(getattr(settings, "opportunity_coverage_min_cycles", 3)))
    enough = len(cycles) >= min_cycles
    hourly_floor = max(0, int(getattr(settings, "coverage_guard_min_analyzed_per_hour", 2)))
    scaled_floor = max(1 if hourly_floor else 0, int(round(hourly_floor * minutes / 60.0)))
    deficits: list[dict[str, Any]] = []
    if enough and bool(getattr(settings, "coverage_guard_enabled", True)) and scaled_floor > 0:
        for chain in enabled_chains:
            analyzed = _i(chains.get(chain, {}).get("analyzed"))
            if analyzed < scaled_floor:
                deficits.append({"chain": chain, "analyzed": analyzed, "target": scaled_floor, "gap": scaled_floor - analyzed})
        deficits.sort(key=lambda row: (-row["gap"], row["chain"]))

    chain_rows = []
    for chain in sorted(set(enabled_chains) | set(chains)):
        row = dict(chains.get(chain, {})) if chain in chains else {"analyzed": 0, "approved": 0, "rejected": 0, "unavailable": 0, "provider_candidates": {}, "provider_unique_added": {}}
        analyzed = _i(row.get("analyzed"))
        row.update({
            "chain": chain,
            "approval_rate_pct": round(_i(row.get("approved")) / analyzed * 100.0, 2) if analyzed else 0.0,
        })
        chain_rows.append(row)

    provider_rows = []
    for name, row in providers.items():
        attempts = _i(row.get("sources_ok")) + _i(row.get("sources_failed"))
        provider_rows.append({
            "provider": name,
            **row,
            "source_success_pct": round(_i(row.get("sources_ok")) / attempts * 100.0, 1) if attempts else 100.0,
            "utility_pct": round(_i(row.get("unique_added")) / max(1, _i(row.get("candidates"))) * 100.0, 1),
        })
    provider_rows.sort(key=lambda row: (-row["unique_added"], row["provider"]))

    return {
        "version": "16.6.0-signal-outcome-learning",
        "minutes": minutes,
        "cycles": len(cycles),
        "enough_history": enough,
        "state": "GUARDED" if deficits else "HEALTHY" if enough else "INSUFFICIENT_DATA",
        "deficits": deficits,
        "chains": chain_rows,
        "providers": provider_rows,
        "updated_at": _load().get("updated_at"),
    }


def priority_chains(*, limit: int = 3) -> list[str]:
    if not bool(getattr(settings, "opportunity_coverage_watchdog_enabled", True)):
        return []
    report = coverage_status()
    if not report.get("enough_history"):
        return []
    return [str(row.get("chain")) for row in (report.get("deficits") or [])[:max(0, int(limit))] if row.get("chain")]
