from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Iterable

from .config import settings

STATUS_WEIGHT = {"ONLINE": 1.0, "AVAILABLE": 0.92, "DEGRADED": 0.65, "COOLDOWN": 0.45, "QUOTA_EXHAUSTED": 0.20, "OFFLINE": 0.15}


def provider_health_score(row: dict[str, Any]) -> int:
    status = str(row.get("status") or "OFFLINE").upper()
    success_rate = float(row.get("success_rate") or 0.0)
    latency = row.get("average_latency_ms")
    if latency is None:
        latency = row.get("latency_ms", row.get("last_latency_ms"))
    latency_score = 100.0
    if latency is not None:
        latency = max(0.0, float(latency))
        if latency > 5000:
            latency_score = 20.0
        elif latency > 2500:
            latency_score = 45.0
        elif latency > 1200:
            latency_score = 70.0
        elif latency > 600:
            latency_score = 85.0
    base = (success_rate * 0.65) + (latency_score * 0.20) + (100.0 * STATUS_WEIGHT.get(status, 0.15) * 0.15)
    score = max(0, min(100, int(round(base))))
    # Current status must dominate aggregate health. A provider in explicit
    # cooldown/quota exhaustion cannot contribute a misleading near-100 score.
    if status == "COOLDOWN":
        score = min(score, 55)
    elif status == "QUOTA_EXHAUSTED":
        score = min(score, 30)
    elif status == "OFFLINE":
        score = min(score, 25)
    elif status == "DEGRADED":
        score = min(score, 75)
    # After recovery, keep a short grace penalty so the dashboard does not jump
    # immediately back to 100/100 while the circuit is still being revalidated.
    if bool(row.get("recently_recovered")) or int(row.get("recovery_in") or 0) > 0:
        score = min(score, 90)
    return score


def aggregate_provider_health(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    rows = [dict(row) for row in rows if not bool(dict(row).get("diagnostic_only"))]
    for row in rows:
        row["health_score"] = provider_health_score(row)
    if not rows:
        overall = 100
    else:
        overall = int(round(sum(row["health_score"] for row in rows) / len(rows)))
    counts = {"ONLINE": 0, "AVAILABLE": 0, "DEGRADED": 0, "COOLDOWN": 0, "QUOTA_EXHAUSTED": 0, "OFFLINE": 0}
    for row in rows:
        status = str(row.get("status") or "OFFLINE").upper()
        counts[status] = counts.get(status, 0) + 1
    return {
        "generated_at": int(time.time()),
        "overall_health": overall,
        "counts": counts,
        "providers": sorted(rows, key=lambda item: (int(item.get("priority", 999)), item.get("name", ""))),
    }


def health_report_path() -> Path:
    path = settings.data_dir / "reports" / "provider_health.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def save_provider_health(rows: Iterable[dict[str, Any]]) -> Path:
    data = aggregate_provider_health(rows)
    target = health_report_path()
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    temp.replace(target)
    return target


def load_provider_health() -> dict[str, Any]:
    path = health_report_path()
    if not path.exists():
        return {"generated_at": None, "overall_health": 100, "counts": {"ONLINE": 0, "AVAILABLE": 0, "DEGRADED": 0, "COOLDOWN": 0, "QUOTA_EXHAUSTED": 0, "OFFLINE": 0}, "providers": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {"generated_at": None, "overall_health": 0, "counts": {"ONLINE": 0, "AVAILABLE": 0, "DEGRADED": 0, "COOLDOWN": 0, "QUOTA_EXHAUSTED": 0, "OFFLINE": 0}, "providers": []}
