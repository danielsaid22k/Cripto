from __future__ import annotations

"""V16.5.9 provider quality routing and credential/recovery probe state."""

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Iterable

from .config import settings
from .provider_health import load_provider_health
from .provider_coverage import coverage_status


def provider_family(value: str) -> str:
    text = str(value or "").casefold()
    for family in ("dexpaprika", "dexscreener", "geckoterminal", "birdeye", "coingecko", "goplus", "honeypot"):
        if family in text.replace(" ", "") or family in text:
            return family
    return text.split()[0] if text else "unknown"


def credential_fingerprint(secret: str) -> str:
    raw = str(secret or "").strip()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16] if raw else ""


class _JsonState:
    def __init__(self, filename: str):
        self.path = settings.data_dir / "runtime" / "v10" / filename
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def save(self, data: dict[str, Any]) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temp.replace(self.path)


class BirdeyeCredentialProbeState:
    """Remember only a hash of the Birdeye key and the last lightweight probe."""

    def __init__(self):
        self.store = _JsonState("birdeye_credential_probe.json")

    def current_fingerprint(self) -> str:
        return credential_fingerprint(getattr(settings, "birdeye_api_key", ""))

    def needs_probe(self) -> bool:
        return self.needs_probe_secret(getattr(settings, "birdeye_api_key", ""))

    def needs_probe_secret(self, secret: str) -> bool:
        if not bool(getattr(settings, "birdeye_credential_change_probe_enabled", True)):
            return False
        current = credential_fingerprint(secret)
        if not current:
            return False
        saved = self.store.load()
        return str(saved.get("fingerprint") or "") != current

    def mark(self, result: str, *, detail: str = "") -> None:
        self.mark_secret(getattr(settings, "birdeye_api_key", ""), result, detail=detail)

    def mark_secret(self, secret: str, result: str, *, detail: str = "") -> None:
        self.store.save({
            "fingerprint": credential_fingerprint(secret),
            "last_probe_at": int(time.time()),
            "result": str(result or "unknown")[:32],
            "detail": str(detail or "")[:120],
        })

    def status(self) -> dict[str, Any]:
        row = self.store.load()
        current = self.current_fingerprint()
        return {
            "configured": bool(current),
            "fingerprint": current,
            "stored_fingerprint": str(row.get("fingerprint") or ""),
            "credential_changed": bool(current and str(row.get("fingerprint") or "") != current),
            "last_probe_at": row.get("last_probe_at"),
            "last_probe_result": row.get("result"),
            "last_probe_detail": row.get("detail"),
        }


class RecoveryProbeState:
    def __init__(self):
        self.store = _JsonState("provider_recovery_probes.json")

    def due(self, provider: str) -> bool:
        if not bool(getattr(settings, "provider_recovery_probe_enabled", True)):
            return False
        interval = max(60, int(getattr(settings, "provider_recovery_probe_interval_seconds", 300)))
        row = self.store.load()
        last = int((row.get("providers") or {}).get(provider, 0) or 0)
        return time.time() - last >= interval

    def mark(self, provider: str) -> None:
        row = self.store.load()
        providers = dict(row.get("providers") or {})
        providers[str(provider)] = int(time.time())
        self.store.save({"providers": providers})


@dataclass
class ProviderScore:
    provider: str
    chain: str
    function: str
    score: float


class ProviderQualityRouter:
    """Rank providers by current health + recent usefulness, never by signals."""

    def __init__(self):
        self.health = load_provider_health()
        try:
            self.coverage = coverage_status()
        except Exception:
            self.coverage = {"providers": []}

    def _health_score(self, provider: str) -> float:
        family = provider_family(provider)
        rows = [row for row in (self.health.get("providers") or []) if provider_family(str(row.get("name") or "")) == family]
        if not rows:
            return 80.0
        return sum(float(row.get("health_score") or 80.0) for row in rows) / len(rows)

    def _utility(self, provider: str) -> float:
        family = provider_family(provider)
        rows = [row for row in (self.coverage.get("providers") or []) if provider_family(str(row.get("provider") or "")) == family]
        if not rows:
            return 50.0
        # Utility is deliberately low-weight; coverage must never overrule a
        # provider's current circuit/health state.
        return max(
            0.0,
            min(
                100.0,
                sum(float(row.get("utility_pct") or 0.0) for row in rows) / len(rows),
            ),
        )

    def score(self, provider: str, chain: str = "", function: str = "discovery") -> ProviderScore:
        family = provider_family(provider)
        health = self._health_score(family)
        utility = self._utility(family)
        preference = 0.0
        if function == "market":
            preference = {"dexscreener": 7.0, "geckoterminal": 5.0, "dexpaprika": 3.0}.get(family, 0.0)
        elif function == "discovery":
            preference = {"dexpaprika": 5.0, "dexscreener": 4.0, "geckoterminal": 3.0, "coingecko": 2.0, "birdeye": 1.0}.get(family, 0.0)
        total = (health * 0.75) + (utility * 0.20) + preference
        return ProviderScore(family, str(chain or ""), function, round(total, 2))

    def order_sources(self, sources: Iterable[Any]) -> list[Any]:
        rows = list(sources)
        if not bool(getattr(settings, "provider_quality_router_enabled", True)):
            return rows
        indexed = list(enumerate(rows))
        indexed.sort(
            key=lambda pair: (
                0 if bool(getattr(pair[1], "probe_only", False)) else 1,
                -self.score(str(getattr(pair[1], "provider", "")), str(getattr(pair[1], "chain", "") or ""), "discovery").score,
                pair[0],
            )
        )
        return [row for _, row in indexed]

    def market_order(self, chain: str) -> list[str]:
        providers = ["geckoterminal", "dexscreener"]
        if bool(getattr(settings, "dexpaprika_enabled", True)) and bool(getattr(settings, "dexpaprika_market_fallback", True)):
            providers.append("dexpaprika")
        return sorted(providers, key=lambda p: -self.score(p, chain, "market").score)


def intelligence_status() -> dict[str, Any]:
    birdeye = BirdeyeCredentialProbeState().status()
    coverage = coverage_status()
    router = ProviderQualityRouter()
    return {
        "version": "16.6.0-signal-outcome-learning",
        "birdeye": birdeye,
        "coverage": {
            "state": coverage.get("state"),
            "cycles": coverage.get("cycles"),
            "deficits": coverage.get("deficits"),
        },
        "market_order": {
            chain: router.market_order(chain)
            for chain in ("solana", "ethereum", "bsc", "base")
        },
    }
