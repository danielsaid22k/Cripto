from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any, Callable

from .logging_setup import logger


@dataclass
class ProviderState:
    name: str
    priority: int = 100
    status: str = "ONLINE"
    failures: int = 0
    successes: int = 0
    total_calls: int = 0
    retry_at: float = 0.0
    last_error: str | None = None
    last_success: float | None = None
    last_failure: float | None = None
    last_latency_ms: float | None = None
    latency_total_ms: float = 0.0
    cache: Any = None
    cache_at: float = 0.0
    last_logged_status: str = "ONLINE"
    circuit_reason: str = ""
    rate_limit_events: int = 0
    consecutive_rate_limits: int = 0
    quota_exhaustions: int = 0
    recovered_at: float | None = None
    recovery_grace_until: float = 0.0


@dataclass
class ProviderResult:
    name: str
    payload: Any
    cached: bool = False


class ProviderManager:
    """Circuit breaker, cache e telemetria de providers externos.

    V16.1 adds provider-aware rate-limit protection. HTTP 429 opens a COOLDOWN
    circuit for minutes (not seconds), while quota exhaustion is marked
    separately. During an open circuit stale cache may be served and callers can
    continue with fallback providers.
    """

    def __init__(
        self,
        *,
        cache_ttl: int = 30,
        stale_cache_ttl: int = 1800,
        max_backoff: int = 900,
        rate_limit_base: int = 300,
        recovery_grace: int = 600,
    ):
        self.cache_ttl = max(0, int(cache_ttl))
        self.stale_cache_ttl = max(self.cache_ttl, int(stale_cache_ttl))
        self.max_backoff = max(30, int(max_backoff))
        self.rate_limit_base = max(60, int(rate_limit_base))
        self.recovery_grace = max(60, int(recovery_grace))
        self._states: dict[str, ProviderState] = {}

    def state(self, name: str, *, priority: int | None = None) -> ProviderState:
        state = self._states.setdefault(name, ProviderState(name=name))
        if priority is not None:
            state.priority = int(priority)
        return state

    @staticmethod
    def _transition(state: ProviderState, new_status: str, *, delay: int = 0, error_type: str = "") -> None:
        old_status = state.status
        state.status = new_status
        if old_status == new_status and state.last_logged_status == new_status:
            return
        state.last_logged_status = new_status
        if new_status == "ONLINE":
            logger.info("Provider %s ONLINE novamente", state.name)
        elif new_status == "COOLDOWN":
            logger.warning("Provider %s COOLDOWN por rate limit; fallback ativo; novo teste em %ss", state.name, delay)
        elif new_status == "QUOTA_EXHAUSTED":
            logger.error("Provider %s QUOTA_EXHAUSTED; fallback ativo; novo teste em %ss", state.name, delay)
        elif new_status == "DEGRADED":
            logger.warning(
                "Provider %s DEGRADED; fallback/cache ativo; novo teste em %ss%s",
                state.name,
                delay,
                f" ({error_type})" if error_type else "",
            )
        else:
            logger.error(
                "Provider %s OFFLINE; circuito aberto; novo teste em %ss%s",
                state.name,
                delay,
                f" ({error_type})" if error_type else "",
            )

    @staticmethod
    def _http_status(exc: Exception) -> int:
        for attr in ("status", "status_code", "code"):
            try:
                value = int(getattr(exc, attr, 0) or 0)
            except (TypeError, ValueError):
                value = 0
            if value:
                return value
        match = re.search(r"\bHTTP\s*(\d{3})\b", str(exc or ""), flags=re.I)
        return int(match.group(1)) if match else 0

    def _rate_limit_delay(self, state: ProviderState) -> int:
        exponent = min(max(0, state.consecutive_rate_limits - 1), 2)
        base = min(self.max_backoff, self.rate_limit_base * (2 ** exponent))
        jitter = sum(ord(ch) for ch in state.name) % 23
        return min(self.max_backoff, base + jitter)

    def _cache_result(self, state: ProviderState, now: float, *, allow_stale: bool) -> ProviderResult | None:
        if state.cache is None:
            return None
        age = now - state.cache_at
        limit = self.stale_cache_ttl if allow_stale else self.cache_ttl
        if age <= limit:
            return ProviderResult(name=state.name, payload=state.cache, cached=True)
        return None

    def fetch(self, name: str, loader: Callable[[], Any], *, force: bool = False, priority: int | None = None) -> ProviderResult | None:
        now = time.time()
        state = self.state(name, priority=priority)

        if not force:
            fresh = self._cache_result(state, now, allow_stale=False)
            if fresh is not None:
                return fresh
        # force bypasses fresh cache only; it never bypasses an open circuit.
        if now < state.retry_at:
            return self._cache_result(state, now, allow_stale=True)

        started = time.perf_counter()
        state.total_calls += 1
        previous = state.status
        try:
            payload = loader()
            latency_ms = (time.perf_counter() - started) * 1000.0
            state.failures = 0
            state.successes += 1
            state.retry_at = 0.0
            state.last_error = None
            state.last_success = now
            state.last_latency_ms = latency_ms
            state.latency_total_ms += latency_ms
            state.cache = payload
            state.cache_at = now
            state.circuit_reason = ""
            state.consecutive_rate_limits = 0
            if previous != "ONLINE":
                state.recovered_at = now
                state.recovery_grace_until = now + self.recovery_grace
                self._transition(state, "ONLINE")
            else:
                state.status = "ONLINE"
            return ProviderResult(name=name, payload=payload, cached=False)
        except Exception as exc:
            state.failures += 1
            state.last_failure = now
            status = self._http_status(exc)
            text = str(exc or "")
            lowered = text.lower()
            is_rate_limit = status == 429 or "http 429" in lowered or "too many requests" in lowered or "rate limit" in lowered
            quota = "compute units usage limit exceeded" in lowered or ("compute unit" in lowered and "limit" in lowered and ("exceed" in lowered or "reached" in lowered))
            state.last_error = f"{type(exc).__name__}: {exc}"[:300]

            if quota:
                state.quota_exhaustions += 1
                state.circuit_reason = "quota"
                delay = max(1800, self.max_backoff)
                state.retry_at = now + delay
                self._transition(state, "QUOTA_EXHAUSTED", delay=delay)
                return self._cache_result(state, now, allow_stale=True)

            if is_rate_limit:
                state.rate_limit_events += 1
                state.consecutive_rate_limits += 1
                state.circuit_reason = "rate_limit"
                delay = self._rate_limit_delay(state)
                state.retry_at = now + delay
                state.last_error = f"TransientNetworkError: Serviço temporariamente indisponível (HTTP 429). Cooldown {delay}s"
                self._transition(state, "COOLDOWN", delay=delay)
                return self._cache_result(state, now, allow_stale=True)

            state.consecutive_rate_limits = 0
            state.circuit_reason = "transient"
            delay = min(self.max_backoff, 15 * (2 ** min(state.failures - 1, 6)))
            state.retry_at = now + delay
            new_status = "DEGRADED" if state.failures < 3 else "OFFLINE"
            self._transition(state, new_status, delay=delay, error_type=type(exc).__name__)
            return self._cache_result(state, now, allow_stale=True)

    def snapshot(self) -> list[dict[str, Any]]:
        now = time.time()
        rows: list[dict[str, Any]] = []
        for name in sorted(self._states):
            state = self._states[name]
            success_rate = (state.successes / state.total_calls * 100.0) if state.total_calls else 100.0
            avg_latency = (state.latency_total_ms / state.successes) if state.successes else None
            rows.append({
                "name": name,
                "status": state.status,
                "priority": state.priority,
                "failures": state.failures,
                "successes": state.successes,
                "total_calls": state.total_calls,
                "success_rate": round(success_rate, 2),
                "retry_in": max(0, int(state.retry_at - now)),
                "last_error": state.last_error,
                "last_success": state.last_success,
                "last_failure": state.last_failure,
                "last_latency_ms": round(state.last_latency_ms, 2) if state.last_latency_ms is not None else None,
                "average_latency_ms": round(avg_latency, 2) if avg_latency is not None else None,
                "cached": state.cache is not None,
                "cache_age": max(0, int(now - state.cache_at)) if state.cache is not None else None,
                "circuit_reason": state.circuit_reason,
                "rate_limit_events": state.rate_limit_events,
                "quota_exhaustions": state.quota_exhaustions,
                "recently_recovered": bool(state.recovery_grace_until > now),
                "recovery_in": max(0, int(state.recovery_grace_until - now)),
            })
        return rows
