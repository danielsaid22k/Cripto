from __future__ import annotations

from typing import Any


PROMOTION_VERSION = "16.4.9"


def _num(value: Any) -> float | None:
    if value is None:
        return None

    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def assess_quality_promotion(
    report: dict[str, Any],
) -> dict[str, Any]:
    samples = int(
        report.get("samples") or 0
    )

    win_rate = _num(
        report.get("win_rate_pct")
    )

    avg_return = _num(
        report.get("average_return_pct")
    )

    coverage = _num(
        report.get("shadow_coverage_pct")
    )

    checks = {
        "minimum_samples": samples >= 50,
        "win_rate": (
            win_rate is not None
            and win_rate >= 55.0
        ),
        "average_return": (
            avg_return is not None
            and avg_return > 0.0
        ),
        "coverage": (
            coverage is None
            or coverage >= 20.0
        ),
    }

    eligible = all(checks.values())

    return {
        "version": PROMOTION_VERSION,
        "mode": "REVIEW_ONLY",
        "promotion_enabled": False,
        "eligible_for_review": eligible,
        "status": (
            "ELIGIBLE_FOR_REVIEW"
            if eligible
            else "SHADOW_LEARNING"
        ),
        "checks": checks,
        "thresholds": {
            "minimum_samples": 50,
            "minimum_win_rate_pct": 55.0,
            "minimum_average_return_pct": 0.0,
            "minimum_shadow_coverage_pct": 20.0,
        },
        "safety": (
            "Nunca ativa LIVE automaticamente. "
            "Qualquer promoção exige validação "
            "e autorização humana."
        ),
    }


def attach_promotion(
    report: dict[str, Any],
) -> dict[str, Any]:
    result = dict(report)

    result["promotion"] = (
        assess_quality_promotion(result)
    )

    result["promotion_enabled"] = False

    return result
