from __future__ import annotations

from . import __product_version__

import compileall
import json
import shutil
import sqlite3
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .backup_manager import newest_backup, validate_backup
from .config import settings
from .product_ops import build_product_report
from .project_leader import ProjectLeader
from .security import verify_file

RELEASE = "8.2.1"
LTS_BASE = "6.3.0"
RELEASE_LINE = "8.1"


@dataclass(frozen=True)
class GateItem:
    name: str
    passed: bool
    details: str
    critical: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class QualityGateReport:
    generated_at: str
    release: str
    lts_base: str
    passed: bool
    items: tuple[GateItem, ...]

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["items"] = [item.to_dict() for item in self.items]
        return payload


def _gate(name: str, passed: bool, details: str, *, critical: bool = True) -> GateItem:
    return GateItem(name=name, passed=bool(passed), details=str(details), critical=critical)


def _database_gate(db_file: Path) -> GateItem:
    if not db_file.exists():
        return _gate("Banco persistente", True, "ausente; será criado no primeiro uso", critical=False)
    try:
        with sqlite3.connect(db_file) as conn:
            integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
            schema = int(conn.execute("PRAGMA user_version").fetchone()[0])
        return _gate(
            "Banco persistente",
            integrity == "ok" and schema > 0,
            f"integridade={integrity}; schema={schema}",
        )
    except sqlite3.Error as exc:
        return _gate("Banco persistente", False, f"SQLiteError: {exc}")


def _clean_package_gate(base_dir: Path) -> GateItem:
    forbidden: list[str] = []
    for pattern in ("*.pyc", "*.pyo", "*.db", "*.sqlite", "*.sqlite3", "*.zip", "*.log"):
        for path in base_dir.rglob(pattern):
            if any(part in {"backups", "exports", "logs"} for part in path.parts):
                continue
            forbidden.append(str(path.relative_to(base_dir)))
    for cache in base_dir.rglob("__pycache__"):
        forbidden.append(str(cache.relative_to(base_dir)))
    for cache in base_dir.rglob(".pytest_cache"):
        forbidden.append(str(cache.relative_to(base_dir)))
    return _gate("Pacote limpo", not forbidden, "ok" if not forbidden else ", ".join(forbidden[:12]))


def _backup_gate() -> GateItem:
    backup = newest_backup()
    if backup is None:
        return _gate("Backup restaurável", False, "nenhum backup válido localizado", critical=False)
    try:
        manifest = validate_backup(backup)
        verification = verify_file(backup, require_signature=False)
        details = (
            f"{backup.name}; banco={bool(manifest.get('database_included'))}; "
            f"segredos={bool(manifest.get('includes_secrets'))}; assinatura={bool(verification.get('signed'))}"
        )
        return _gate("Backup restaurável", bool(verification.get("ok")), details, critical=False)
    except Exception as exc:
        return _gate("Backup restaurável", False, str(exc), critical=False)


def restore_dry_run(backup_file: str | Path | None = None) -> dict[str, Any]:
    source = Path(backup_file).expanduser() if backup_file else newest_backup()
    if source is None:
        raise FileNotFoundError("nenhum backup válido foi localizado")
    source = source.resolve()
    manifest = validate_backup(source)
    verification = verify_file(source, require_signature=False)
    members: list[str] = []
    with zipfile.ZipFile(source, "r") as archive:
        for info in archive.infolist():
            name = info.filename
            path = Path(name)
            if path.is_absolute() or ".." in path.parts:
                raise RuntimeError(f"caminho inseguro dentro do backup: {name}")
            members.append(name)
    return {
        "backup": str(source),
        "valid": bool(verification.get("ok")),
        "signed": bool(verification.get("signed")),
        "sha256": verification.get("sha256"),
        "manifest": manifest,
        "members": len(members),
        "has_database": "state/signals.db" in members,
        "has_secrets": "state/config.env" in members,
        "would_overwrite_code": any(name.startswith("project/") for name in members),
    }


def health_dashboard() -> dict[str, Any]:
    report = build_product_report().to_dict()
    leader = ProjectLeader()
    maintenance = leader.maintenance()
    backup = newest_backup()
    backup_info: dict[str, Any] | None = None
    if backup is not None:
        try:
            manifest = validate_backup(backup)
            backup_info = {
                "path": str(backup),
                "created_at": manifest.get("created_at"),
                "includes_secrets": bool(manifest.get("includes_secrets")),
                "database_included": bool(manifest.get("database_included")),
            }
        except Exception as exc:
            backup_info = {"path": str(backup), "error": str(exc)}
    scanner_age_seconds: float | None = None
    last_cycle = report.get("last_scanner_cycle")
    if last_cycle:
        try:
            parsed = datetime.fromisoformat(str(last_cycle).replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            scanner_age_seconds = max(0.0, (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds())
        except ValueError:
            scanner_age_seconds = None
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "release": RELEASE,
        "product_release": __product_version__,
        "lts_base": LTS_BASE,
        "environment": report.get("environment"),
        "database": {
            "path": report.get("database_path"),
            "integrity": report.get("database_integrity"),
            "users": report.get("users"),
            "active_subscribers": report.get("active_subscribers"),
            "payments": report.get("payments"),
        },
        "integrations": {
            "telegram_configured": report.get("telegram_configured"),
            "asaas_configured": report.get("asaas_configured"),
        },
        "scanner": {
            "enabled": report.get("scanner_enabled"),
            "cycles_today": report.get("scanner_cycles_today"),
            "discovered_today": report.get("tokens_discovered_today"),
            "approved_today": report.get("tokens_approved_today"),
            "signals_today": report.get("signals_sent_today"),
            "last_cycle": last_cycle,
            "last_cycle_age_seconds": scanner_age_seconds,
        },
        "maintenance": maintenance,
        "latest_backup": backup_info,
    }


def run_quality_gate(*, compile_code: bool = True) -> QualityGateReport:
    items: list[GateItem] = []
    if compile_code:
        compiled = compileall.compile_dir(str(settings.base_dir), quiet=1, force=False)
        items.append(_gate("Compilação Python", compiled, "compileall"))
        for cache in settings.base_dir.rglob("__pycache__"):
            shutil.rmtree(cache, ignore_errors=True)
    items.append(_database_gate(settings.db_file))
    items.append(_clean_package_gate(settings.base_dir))
    items.append(_gate("Diretório persistente", settings.data_dir.exists(), str(settings.data_dir)))
    items.append(_gate(
        "Telegram configurado",
        bool(settings.telegram_token and settings.telegram_chat_id),
        "token e chat id presentes" if settings.telegram_token and settings.telegram_chat_id else "credenciais ausentes",
    ))
    asaas_ok = (not settings.asaas_enabled) or settings.payments_ready
    items.append(_gate(
        "Asaas coerente",
        asaas_ok,
        "desativado" if not settings.asaas_enabled else ("configurado" if settings.payments_ready else "; ".join(settings.asaas_validation_errors())),
    ))
    intervals_ok = (
        settings.auto_scan_interval_free == 900
        and settings.auto_scan_interval_plus == 300
        and settings.auto_scan_interval_premium == 60
    )
    items.append(_gate(
        "Intervalos por plano",
        intervals_ok,
        f"free={settings.auto_scan_interval_free}s; plus={settings.auto_scan_interval_plus}s; premium={settings.auto_scan_interval_premium}s",
    ))
    durations_ok = settings.plan_monthly_duration_days > 0 and settings.plan_annual_duration_days > 0
    items.append(_gate(
        "Duração dos planos",
        durations_ok,
        f"mensal={settings.plan_monthly_duration_days} dias; anual={settings.plan_annual_duration_days} dias",
    ))
    items.append(_backup_gate())
    passed = all(item.passed for item in items if item.critical)
    return QualityGateReport(
        generated_at=datetime.now(timezone.utc).isoformat(),
        release=RELEASE,
        lts_base=LTS_BASE,
        passed=passed,
        items=tuple(items),
    )


def _save_json(name: str, payload: dict[str, Any]) -> Path:
    target = settings.data_dir / "reports" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return target


def save_quality_gate() -> Path:
    return _save_json("quality_gate.json", run_quality_gate().to_dict())


def save_health_dashboard() -> Path:
    return _save_json("health_dashboard.json", health_dashboard())


def release_info() -> dict[str, str]:
    return {
        "release": RELEASE,
        "product_release": __product_version__,
        "release_line": RELEASE_LINE,
        "lts_base": LTS_BASE,
        "policy": "6.3.0 permanece LTS; 7.0 adiciona plataforma em camadas sem reescrever o núcleo",
    }
