from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime, timedelta, timezone
from typing import Any


REPUTATION_SCHEMA_VERSION = 1


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _norm(chain: str, address: str) -> tuple[str, str]:
    chain = str(chain or "").strip().lower()
    address = str(address or "").strip()
    if chain != "solana":
        address = address.lower()
    return chain, address


def evidence_key(chain: str, address: str, source: str, source_ref: str, evidence_type: str) -> str:
    chain, address = _norm(chain, address)
    raw = "|".join((chain, address, str(source), str(source_ref), str(evidence_type)))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS wallet_reputation_evidence (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            evidence_key TEXT NOT NULL UNIQUE,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            role TEXT DEFAULT 'observed',
            signal_id INTEGER,
            evidence_type TEXT NOT NULL,
            polarity INTEGER NOT NULL DEFAULT 0,
            weight REAL NOT NULL DEFAULT 0,
            severity TEXT DEFAULT 'INFO',
            source TEXT NOT NULL,
            source_ref TEXT DEFAULT '',
            details_json TEXT DEFAULT '{}',
            occurred_at TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE RESTRICT
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_rep_evidence_wallet
        ON wallet_reputation_evidence(chain,address,occurred_at DESC);
        CREATE INDEX IF NOT EXISTS idx_wallet_rep_evidence_signal
        ON wallet_reputation_evidence(signal_id,evidence_type);

        CREATE TRIGGER IF NOT EXISTS trg_wallet_rep_evidence_no_update
        BEFORE UPDATE ON wallet_reputation_evidence
        BEGIN SELECT RAISE(ABORT, 'wallet reputation evidence is append-only'); END;
        CREATE TRIGGER IF NOT EXISTS trg_wallet_rep_evidence_no_delete
        BEFORE DELETE ON wallet_reputation_evidence
        BEGIN SELECT RAISE(ABORT, 'wallet reputation evidence is append-only'); END;

        CREATE TABLE IF NOT EXISTS wallet_reputation_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            role TEXT DEFAULT 'observed',
            reputation_score INTEGER NOT NULL,
            confidence_score INTEGER NOT NULL,
            rating TEXT NOT NULL,
            evidence_count INTEGER DEFAULT 0,
            independent_samples INTEGER DEFAULT 0,
            positive_evidence INTEGER DEFAULT 0,
            negative_evidence INTEGER DEFAULT 0,
            linked_signals INTEGER DEFAULT 0,
            risky_signals INTEGER DEFAULT 0,
            successful_signals INTEGER DEFAULT 0,
            total_weight REAL DEFAULT 0,
            factors_json TEXT DEFAULT '[]',
            captured_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_rep_snapshots_wallet
        ON wallet_reputation_snapshots(chain,address,captured_at DESC);

        CREATE TABLE IF NOT EXISTS wallet_reputation_state (
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            role TEXT DEFAULT 'observed',
            reputation_score INTEGER NOT NULL DEFAULT 50,
            confidence_score INTEGER NOT NULL DEFAULT 0,
            rating TEXT NOT NULL DEFAULT 'UNPROVEN',
            evidence_count INTEGER DEFAULT 0,
            independent_samples INTEGER DEFAULT 0,
            positive_evidence INTEGER DEFAULT 0,
            negative_evidence INTEGER DEFAULT 0,
            linked_signals INTEGER DEFAULT 0,
            risky_signals INTEGER DEFAULT 0,
            successful_signals INTEGER DEFAULT 0,
            total_weight REAL DEFAULT 0,
            factors_json TEXT DEFAULT '[]',
            first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
            last_seen TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(chain,address)
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_rep_state_score
        ON wallet_reputation_state(role,reputation_score,confidence_score DESC);
        """
    )
    conn.commit()


EVENT_WEIGHTS: dict[str, float] = {
    "deployer_outflow": -18.0,
    "deployer_inflow": 0.0,
    "mint_event": -16.0,
    "supply_increase": -14.0,
    "supply_decrease": 1.0,
    "burn_event": 1.0,
    "liquidity_deterioration": -18.0,
    # A large transfer is activity, not proof of malicious intent.
    "whale_transfer": 0.0,
}


class ReputationEngine:
    """Evidence-based wallet/deployer reputation.

    Canonical reputation is derived from append-only evidence.  The mutable
    ``wallet_reputation_state`` table is only a materialized cache.  Reputation
    is advisory: scanner integration may reduce CSM Confidence for a well-
    evidenced risky deployer, but it never changes ``final_score`` and never
    overrides GoPlus blockers.
    """

    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)

    def add_evidence(
        self,
        chain: str,
        address: str,
        *,
        evidence_type: str,
        source: str,
        source_ref: str,
        role: str = "observed",
        signal_id: int | None = None,
        weight: float = 0.0,
        severity: str = "INFO",
        details: dict[str, Any] | None = None,
        occurred_at: str | datetime | None = None,
    ) -> bool:
        chain, address = _norm(chain, address)
        if not chain or not address:
            return False
        key = evidence_key(chain, address, source, source_ref, evidence_type)
        when = occurred_at.isoformat() if isinstance(occurred_at, datetime) else str(occurred_at or _iso())
        polarity = 1 if weight > 0 else -1 if weight < 0 else 0
        try:
            self.conn.execute(
                """INSERT INTO wallet_reputation_evidence(
                    evidence_key,chain,address,role,signal_id,evidence_type,polarity,weight,severity,
                    source,source_ref,details_json,occurred_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (key, chain, address, str(role or "observed"), signal_id, str(evidence_type), polarity,
                 float(weight), str(severity or "INFO").upper(), str(source), str(source_ref),
                 _json(details or {}), when),
            )
            self.conn.commit()
        except Exception as exc:
            if "UNIQUE constraint failed" in str(exc):
                return False
            raise
        return True

    @staticmethod
    def _event_weight(event_type: str, severity: str) -> float:
        base = EVENT_WEIGHTS.get(str(event_type), 0.0)
        sev = str(severity or "INFO").upper()
        if base < 0:
            if sev == "CRITICAL":
                base *= 1.35
            elif sev == "HIGH":
                base *= 1.15
        return round(base, 2)

    def ingest_onchain_events(self, *, days: int = 3650, limit: int = 5000) -> int:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        rows = self.conn.execute(
            """SELECT e.*,s.goplus_creator_address,s.goplus_owner_address
               FROM onchain_events e JOIN signal_ledger s ON s.id=e.signal_id
               WHERE e.occurred_at>=? ORDER BY e.id ASC LIMIT ?""",
            (cutoff, max(1, int(limit))),
        ).fetchall()
        inserted = 0
        for raw in rows:
            row = dict(raw)
            event_type = str(row.get("event_type") or "")
            wallet = str(row.get("wallet_address") or "").strip()
            deployer = str(row.get("goplus_creator_address") or row.get("goplus_owner_address") or "").strip()
            # Some risk observations are token-level.  They still become
            # deployer evidence when the signal has a known creator/owner.
            targets: list[tuple[str, str]] = []
            if wallet:
                if deployer and _norm(row.get("chain"), wallet)[1] == _norm(row.get("chain"), deployer)[1]:
                    event_role = "deployer"
                elif event_type.startswith("whale_"):
                    event_role = "whale"
                else:
                    event_role = "observed"
                targets.append((wallet, event_role))
            if deployer and event_type in {"mint_event", "supply_increase", "liquidity_deterioration"}:
                if not any(_norm(row.get("chain"), addr)[1] == _norm(row.get("chain"), deployer)[1] for addr, _ in targets):
                    targets.append((deployer, "deployer"))
            for address, role in targets:
                if self.add_evidence(
                    str(row.get("chain") or ""), address,
                    evidence_type=event_type, source="onchain_event", source_ref=str(row.get("id")),
                    role=role, signal_id=_i(row.get("signal_id")) or None,
                    weight=self._event_weight(event_type, str(row.get("severity") or "INFO")),
                    severity=str(row.get("severity") or "INFO"),
                    details={"txid": row.get("txid"), "amount_usd": _f(row.get("amount_usd")), "token": row.get("address")},
                    occurred_at=str(row.get("occurred_at") or _iso()),
                ):
                    inserted += 1
        return inserted

    def ingest_signal_outcomes(self, *, days: int = 3650, limit: int = 5000) -> int:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        rows = self.conn.execute(
            """SELECT * FROM signal_ledger
               WHERE created_at>=? AND COALESCE(goplus_creator_address,goplus_owner_address,'')!=''
               ORDER BY id ASC LIMIT ?""",
            (cutoff, max(1, int(limit))),
        ).fetchall()
        inserted = 0
        for raw in rows:
            s = dict(raw)
            deployer = str(s.get("goplus_creator_address") or s.get("goplus_owner_address") or "").strip()
            if not deployer:
                continue
            sid = _i(s.get("id"))
            chain = str(s.get("chain") or "")
            created = str(s.get("created_at") or _iso())
            evidence: list[tuple[str, float, str, dict[str, Any]]] = []
            if s.get("first_tp1_at"):
                evidence.append(("signal_tp1", 7.0, "POSITIVE", {"max_return_pct": _f(s.get("max_return_pct"))}))
            if s.get("first_tp2_at"):
                evidence.append(("signal_tp2", 10.0, "POSITIVE", {"max_return_pct": _f(s.get("max_return_pct"))}))
            if s.get("first_stop_at"):
                evidence.append(("signal_stop", -9.0, "HIGH", {"max_drawdown_pct": _f(s.get("max_drawdown_pct"))}))
            drawdown = _f(s.get("max_drawdown_pct"))
            if drawdown <= -50:
                evidence.append(("signal_drawdown_50", -12.0, "CRITICAL", {"max_drawdown_pct": drawdown}))
            elif drawdown <= -30:
                evidence.append(("signal_drawdown_30", -6.0, "HIGH", {"max_drawdown_pct": drawdown}))
            # Positive performance requires at least one real observation.
            if _i(s.get("observations")) >= 1 and _f(s.get("max_return_pct")) >= 100:
                evidence.append(("signal_return_100", 6.0, "POSITIVE", {"max_return_pct": _f(s.get("max_return_pct"))}))
            for etype, weight, severity, details in evidence:
                if self.add_evidence(chain, deployer, evidence_type=etype, source="signal_outcome",
                                     source_ref=f"{sid}:{etype}", role="deployer", signal_id=sid,
                                     weight=weight, severity=severity, details=details, occurred_at=created):
                    inserted += 1
        return inserted

    def _aggregate(self, chain: str, address: str) -> dict[str, Any] | None:
        chain, address = _norm(chain, address)
        if not chain or not address:
            return None
        rows = self.conn.execute(
            "SELECT * FROM wallet_reputation_evidence WHERE chain=? AND address=? ORDER BY occurred_at,id",
            (chain, address),
        ).fetchall()
        if not rows:
            return None
        data = [dict(row) for row in rows]
        total_weight = sum(_f(row.get("weight")) for row in data)
        score = max(0, min(100, round(50 + total_weight)))
        count = len(data)
        # Confidence counts independent contexts, not every row. Multiple facts
        # from one token/signal may move score but cannot fake a larger sample.
        units = set()
        for row in data:
            if row.get("signal_id") is not None:
                units.add(("signal", int(row["signal_id"])))
            else:
                units.add((str(row.get("source") or ""), str(row.get("source_ref") or row.get("id"))))
        independent_samples = len(units)
        # Confidence grows slowly: one independent context ~12; three ~31;
        # eight ~63; twenty ~92.
        confidence = max(0, min(100, round(100 * (1.0 - math.exp(-independent_samples / 8.0)))))
        roles = [str(row.get("role") or "observed") for row in data]
        role = "deployer" if "deployer" in roles else "whale" if "whale" in roles else "observed"
        linked = {int(row["signal_id"]) for row in data if row.get("signal_id") is not None}
        risky_signals = {int(row["signal_id"]) for row in data if row.get("signal_id") is not None and _f(row.get("weight")) <= -8}
        successful_signals = {int(row["signal_id"]) for row in data if row.get("signal_id") is not None and str(row.get("evidence_type")) in {"signal_tp1", "signal_tp2", "signal_return_100"}}
        positive = sum(1 for row in data if _f(row.get("weight")) > 0)
        negative = sum(1 for row in data if _f(row.get("weight")) < 0)
        if confidence < 25:
            rating = "UNPROVEN"
        elif score >= 80:
            rating = "STRONG"
        elif score >= 65:
            rating = "POSITIVE"
        elif score >= 40:
            rating = "NEUTRAL"
        elif score >= 20:
            rating = "CAUTION"
        else:
            rating = "HIGH_RISK"
        factors = sorted(
            ({"type": str(row.get("evidence_type")), "weight": _f(row.get("weight")), "severity": str(row.get("severity"))} for row in data),
            key=lambda x: abs(float(x["weight"])), reverse=True,
        )[:8]
        return {
            "chain": chain, "address": address, "role": role,
            "reputation_score": score, "confidence_score": confidence, "rating": rating,
            "evidence_count": count, "independent_samples": independent_samples, "positive_evidence": positive, "negative_evidence": negative,
            "linked_signals": len(linked), "risky_signals": len(risky_signals),
            "successful_signals": len(successful_signals), "total_weight": round(total_weight, 2),
            "factors": factors, "first_seen": str(data[0].get("occurred_at") or ""),
            "last_seen": str(data[-1].get("occurred_at") or ""),
        }

    def materialize(self, chain: str, address: str, *, snapshot: bool = False) -> dict[str, Any] | None:
        profile = self._aggregate(chain, address)
        if profile is None:
            return None
        self.conn.execute(
            """INSERT INTO wallet_reputation_state(
               chain,address,role,reputation_score,confidence_score,rating,evidence_count,independent_samples,positive_evidence,
               negative_evidence,linked_signals,risky_signals,successful_signals,total_weight,factors_json,
               first_seen,last_seen,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(chain,address) DO UPDATE SET
               role=excluded.role,reputation_score=excluded.reputation_score,confidence_score=excluded.confidence_score,
               rating=excluded.rating,evidence_count=excluded.evidence_count,independent_samples=excluded.independent_samples,positive_evidence=excluded.positive_evidence,
               negative_evidence=excluded.negative_evidence,linked_signals=excluded.linked_signals,
               risky_signals=excluded.risky_signals,successful_signals=excluded.successful_signals,
               total_weight=excluded.total_weight,factors_json=excluded.factors_json,last_seen=excluded.last_seen,
               updated_at=excluded.updated_at""",
            (profile["chain"], profile["address"], profile["role"], profile["reputation_score"],
             profile["confidence_score"], profile["rating"], profile["evidence_count"], profile["independent_samples"], profile["positive_evidence"],
             profile["negative_evidence"], profile["linked_signals"], profile["risky_signals"], profile["successful_signals"],
             profile["total_weight"], _json(profile["factors"]), profile["first_seen"], profile["last_seen"], _iso()),
        )
        if snapshot:
            self.conn.execute(
                """INSERT INTO wallet_reputation_snapshots(chain,address,role,reputation_score,confidence_score,rating,
                   evidence_count,independent_samples,positive_evidence,negative_evidence,linked_signals,risky_signals,successful_signals,
                   total_weight,factors_json,captured_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (profile["chain"], profile["address"], profile["role"], profile["reputation_score"], profile["confidence_score"],
                 profile["rating"], profile["evidence_count"], profile["independent_samples"], profile["positive_evidence"], profile["negative_evidence"],
                 profile["linked_signals"], profile["risky_signals"], profile["successful_signals"], profile["total_weight"],
                 _json(profile["factors"]), _iso()),
            )
        # Keep the legacy V13.5 cache useful without making it canonical.
        self.conn.execute(
            "UPDATE wallet_profiles SET reputation_score=?,positive_events=?,risky_events=?,last_seen=? WHERE chain=? AND address=?",
            (profile["reputation_score"], profile["positive_evidence"], profile["negative_evidence"], profile["last_seen"], profile["chain"], profile["address"]),
        )
        self.conn.commit()
        return profile

    def refresh(self, *, days: int = 3650, limit: int = 5000, snapshot: bool = False) -> dict[str, Any]:
        onchain_added = self.ingest_onchain_events(days=days, limit=limit)
        outcomes_added = self.ingest_signal_outcomes(days=days, limit=limit)
        rows = self.conn.execute(
            "SELECT chain,address FROM wallet_reputation_evidence GROUP BY chain,address ORDER BY MAX(id) DESC LIMIT ?",
            (max(1, int(limit)),),
        ).fetchall()
        materialized = 0
        for row in rows:
            if self.materialize(str(row[0]), str(row[1]), snapshot=snapshot):
                materialized += 1
        return {"onchain_evidence_added": onchain_added, "outcome_evidence_added": outcomes_added, "profiles_materialized": materialized}

    def profile(self, chain: str, address: str, *, refresh: bool = False) -> dict[str, Any] | None:
        chain, address = _norm(chain, address)
        if refresh:
            return self.materialize(chain, address)
        row = self.conn.execute("SELECT * FROM wallet_reputation_state WHERE chain=? AND address=?", (chain, address)).fetchone()
        if not row:
            return self.materialize(chain, address)
        data = dict(row)
        try:
            data["factors"] = json.loads(str(data.get("factors_json") or "[]"))
        except Exception:
            data["factors"] = []
        return data

    def candidate_profile(self, item: dict[str, Any]) -> dict[str, Any] | None:
        address = str(item.get("goplus_creator_address") or item.get("goplus_owner_address") or "").strip()
        if not address:
            return None
        return self.profile(str(item.get("chain") or ""), address, refresh=True)

    def enrich_candidate(self, item: dict[str, Any], *, min_confidence: int = 30, max_penalty: int = 20) -> dict[str, Any]:
        profile = self.candidate_profile(item)
        if not profile:
            return item
        item["deployer_reputation_score"] = _i(profile.get("reputation_score"), 50)
        item["deployer_reputation_confidence"] = _i(profile.get("confidence_score"), 0)
        item["deployer_reputation_rating"] = str(profile.get("rating") or "UNPROVEN")
        item["deployer_reputation_evidence"] = _i(profile.get("evidence_count"), 0)
        item["deployer_reputation_signals"] = _i(profile.get("linked_signals"), 0)
        item["deployer_reputation_factors"] = profile.get("factors") or []
        current = _i(item.get("csm_confidence_score"), _i(item.get("final_score")))
        score = _i(profile.get("reputation_score"), 50)
        confidence = _i(profile.get("confidence_score"), 0)
        # Reputation is one-way safety context: strong history never inflates a
        # current signal.  A sufficiently evidenced risky deployer may only
        # reduce CSM Confidence, never final_score or GoPlus decisions.
        penalty = 0
        if confidence >= int(min_confidence) and score < 50:
            risk_gap = (50 - score) / 50.0
            evidence_factor = min(1.0, confidence / 100.0)
            penalty = round(max(0, int(max_penalty)) * risk_gap * evidence_factor)
            item["csm_confidence_score"] = max(0, current - penalty)
        item["deployer_reputation_penalty"] = penalty
        return item

    def status(self, *, days: int = 3650) -> dict[str, Any]:
        cutoff = _iso(_utc_now() - timedelta(days=max(1, int(days))))
        total = _i(self.conn.execute("SELECT COUNT(*) FROM wallet_reputation_state").fetchone()[0])
        evidence = _i(self.conn.execute("SELECT COUNT(*) FROM wallet_reputation_evidence WHERE occurred_at>=?", (cutoff,)).fetchone()[0])
        deployers = _i(self.conn.execute("SELECT COUNT(*) FROM wallet_reputation_state WHERE role='deployer'").fetchone()[0])
        risky = _i(self.conn.execute("SELECT COUNT(*) FROM wallet_reputation_state WHERE rating IN ('CAUTION','HIGH_RISK') AND confidence_score>=25").fetchone()[0])
        strong = _i(self.conn.execute("SELECT COUNT(*) FROM wallet_reputation_state WHERE rating IN ('STRONG','POSITIVE') AND confidence_score>=25").fetchone()[0])
        avg = self.conn.execute("SELECT AVG(reputation_score) FROM wallet_reputation_state WHERE confidence_score>=25").fetchone()[0]
        return {
            "days": days, "profiles": total, "deployers": deployers, "evidence": evidence,
            "risk_profiles": risky, "positive_profiles": strong,
            "average_reputation_score": round(_f(avg), 2) if avg is not None else None,
            "canonical_source": "append-only-evidence", "network_requests": 0,
            "public_webhooks": False,
        }

    def report(self, *, days: int = 3650, limit: int = 50) -> dict[str, Any]:
        summary = self.status(days=days)
        worst = self.conn.execute(
            """SELECT * FROM wallet_reputation_state WHERE confidence_score>=25
               ORDER BY reputation_score ASC,confidence_score DESC,evidence_count DESC LIMIT ?""",
            (max(1, min(200, int(limit))),),
        ).fetchall()
        best = self.conn.execute(
            """SELECT * FROM wallet_reputation_state WHERE confidence_score>=25
               ORDER BY reputation_score DESC,confidence_score DESC,evidence_count DESC LIMIT ?""",
            (max(1, min(200, int(limit))),),
        ).fetchall()
        return {"summary": summary, "highest_risk": [dict(x) for x in worst], "strongest": [dict(x) for x in best]}
