from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from .config import STATE_DIR, settings
from .runtime_status_v831 import runtime_status_v831


class RetoolControlError(RuntimeError):
    pass


def _pid_alive(pid: int) -> bool:
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _pid_cmdline(pid: int) -> str:
    try:
        return Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", errors="replace")
    except Exception:
        return ""


def _is_csm_bot_pid(pid: int) -> bool:
    if not _pid_alive(pid):
        return False
    cmdline = _pid_cmdline(pid)
    if not cmdline:
        # /proc may be restricted on some runtimes. Never stop an unverifiable
        # PID except the one recorded in the current CSM runtime state.
        return False
    low = cmdline.lower()
    return ("launcher.py" in low or "main.py" in low) and " bot" in (" " + low)


def _tmux_has_session(name: str) -> bool:
    try:
        return subprocess.run(
            ["tmux", "has-session", "-t", name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        ).returncode == 0
    except Exception:
        return False


def _tmux_pane_pid(name: str) -> int | None:
    if not _tmux_has_session(name):
        return None
    try:
        proc = subprocess.run(
            ["tmux", "display-message", "-p", "-t", name, "#{pane_pid}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
            check=False,
        )
        pid = int((proc.stdout or "").strip() or 0)
        return pid or None
    except Exception:
        return None


def _http_probe(url: str, *, timeout: float = 0.8) -> dict[str, Any]:
    from urllib import error as urllib_error
    from urllib import request as urllib_request

    started = time.monotonic()
    try:
        with urllib_request.urlopen(url, timeout=max(0.1, float(timeout))) as response:
            code = int(getattr(response, "status", 200) or 200)
            response.read(1024)
        return {
            "ok": code == 200,
            "http_status": code,
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "error": None,
        }
    except urllib_error.HTTPError as exc:
        return {
            "ok": False,
            "http_status": int(exc.code),
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "error": f"HTTP {exc.code}",
        }
    except Exception as exc:
        return {
            "ok": False,
            "http_status": None,
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "error": f"{type(exc).__name__}: {exc}",
        }


def runtime_snapshot() -> dict[str, Any]:
    """Retool runtime snapshot with authoritative v10 liveness.

    v16.5.2 treated tmux session presence as process liveness. That can produce
    a false ``degraded`` state when the bot remains healthy but orchestration
    metadata is temporarily missing. v16.5.3 uses the v10 lease +
    session/heartbeat contract as the primary bot authority and keeps tmux as
    orchestration/fallback metadata only.
    """

    raw = runtime_status_v831()
    bot_tmux = _tmux_has_session("csm-bot")
    api_tmux = _tmux_has_session("csm-api")

    v10: dict[str, Any] = {}
    try:
        from phantom_v10.runtime import runtime_state

        v10 = runtime_state("bot", stale_after=60.0)
    except Exception as exc:
        v10 = {
            "healthy": False,
            "state": "unavailable",
            "error": f"{type(exc).__name__}: {exc}",
        }

    has_v10_evidence = bool(
        v10.get("lock_exists")
        or v10.get("session_exists")
        or v10.get("session")
    )
    authoritative_bot_healthy = bool(v10.get("healthy"))

    # Only fall back to tmux when the authoritative runtime has no evidence at
    # all. If a v10 session exists but its heartbeat/lease is unhealthy, tmux
    # must not hide that degradation.
    bot_healthy = authoritative_bot_healthy or (not has_v10_evidence and bot_tmux)
    bot_process_present = bool(
        authoritative_bot_healthy
        or bot_tmux
        or (has_v10_evidence and v10.get("pid_alive") is True)
    )

    api_probe = _http_probe("http://127.0.0.1:8787/healthz", timeout=0.8)
    api_healthy = bool(api_probe.get("ok"))
    api_process_present = bool(api_tmux or api_healthy)

    if bot_healthy and api_healthy:
        state = "running"
        reason = "bot_lease_heartbeat_and_api_healthz_ok"
    elif bot_process_present or api_process_present:
        state = "degraded"
        if not bot_healthy and not api_healthy:
            reason = "bot_and_api_not_healthy"
        elif not bot_healthy:
            reason = "bot_liveness_not_healthy"
        else:
            reason = "saas_api_healthz_not_healthy"
    else:
        state = "stopped"
        reason = "bot_and_api_not_present"

    pid = v10.get("pid_diagnostic_only") or _tmux_pane_pid("csm-bot")
    liveness_source = (
        "v10-lease-session-heartbeat"
        if has_v10_evidence
        else "tmux-fallback"
        if bot_tmux
        else "none"
    )

    try:
        from . import __product_version__
    except Exception:
        __product_version__ = "unknown"

    return {
        **raw,
        "runtime_state": state,
        "runtime_pid": pid,
        "pid_alive": bool(bot_process_present),
        "pid_verified_as_csm": bool(authoritative_bot_healthy),
        "process_active": bool(bot_process_present),
        "bot_healthy": bool(bot_healthy),
        "bot_health_reason": (
            "v10_authoritative_healthy"
            if authoritative_bot_healthy
            else "tmux_fallback_no_v10_state"
            if bot_healthy and not has_v10_evidence
            else str(v10.get("error") or v10.get("state") or "liveness_unhealthy")
        ),
        "heartbeat_age_seconds": v10.get("heartbeat_age_seconds"),
        "lease_alive": v10.get("lease_alive"),
        "runtime_session": v10.get("session"),
        "liveness_source": liveness_source,
        "runtime_health_reason": reason,
        "health_score": (60 if bot_healthy else 0) + (40 if api_healthy else 0),
        "release": __product_version__,
        "tmux_bot": bot_tmux,
        "tmux_api": api_tmux,
        "saas_api_online": bool(api_healthy),
        "saas_api_healthy": bool(api_healthy),
        "saas_api_process_present": bool(api_process_present),
        "saas_api_http_status": api_probe.get("http_status"),
        "saas_api_latency_ms": api_probe.get("latency_ms"),
        "saas_api_health_reason": "healthz_ok" if api_healthy else str(api_probe.get("error") or "healthz_unavailable"),
        "control_mode": "termux-tmux+v10-liveness",
        "commercial_release": __product_version__,
        "legacy_status_source": "runtime/v831",
    }


def _runtime_log() -> Path:
    path = STATE_DIR / "logs" / "retool_runtime.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _run_csm_script(name: str, *, timeout_seconds: int) -> dict[str, Any]:
    script = Path.home() / "bin" / name
    if not script.is_file():
        raise RetoolControlError(f"Script {script} não encontrado.")

    proc = subprocess.run(
        [str(script)],
        cwd=str(settings.base_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=max(15, int(timeout_seconds)),
        check=False,
        env=os.environ.copy(),
    )

    return {
        "returncode": proc.returncode,
        "output": (proc.stdout or "")[-12000:],
    }


def _supervisor_runtime_action(action: str, *, timeout_seconds: float = 35.0) -> dict[str, Any]:
    import json
    from urllib import request

    if action not in {"start", "stop", "restart"}:
        raise RetoolControlError("Ação de runtime inválida.")

    url = f"http://127.0.0.1:8790/runtime/{action}"
    req = request.Request(url, data=b"", method="POST")

    try:
        with request.urlopen(req, timeout=timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        return {
            "ok": False,
            "action": action,
            "result": "supervisor_unavailable",
            "message": str(exc),
            "runtime": runtime_snapshot(),
        }

    state = runtime_snapshot()
    ok = bool(payload.get("ok"))

    if action == "start":
        running = bool(state.get("tmux_bot") and state.get("tmux_api"))
        ok = ok and running
        if payload.get("bot") == "already_running" and payload.get("api") == "already_running":
            result = "already_running"
        else:
            result = "started" if ok else "failed"

    elif action == "stop":
        stopped = not state.get("tmux_bot") and not state.get("tmux_api")
        ok = ok and stopped
        if payload.get("bot") == "already_stopped" and payload.get("api") == "already_stopped":
            result = "already_stopped"
        else:
            result = "stopped" if ok else "failed"

    else:
        running = bool(state.get("tmux_bot") and state.get("tmux_api"))
        ok = ok and running
        result = "restarted" if ok else "failed"

    return {
        "ok": ok,
        "action": action,
        "result": result,
        "supervisor": payload,
        "runtime": state,
    }


def start_bot() -> dict[str, Any]:
    return _supervisor_runtime_action("start")


def stop_bot(*, timeout_seconds: float = 20.0) -> dict[str, Any]:
    return _supervisor_runtime_action(
        "stop",
        timeout_seconds=max(20.0, float(timeout_seconds)),
    )


def restart_bot() -> dict[str, Any]:
    return _supervisor_runtime_action("restart", timeout_seconds=60.0)


def run_local_command(command: str, *, timeout_seconds: int = 180) -> dict[str, Any]:
    # CONFIG_INTEGRITY_PREFLIGHT_V1646
    if str(command) in {'start', 'restart'}:
        from .config_integrity import ConfigIntegrityGuard
        _integrity = ConfigIntegrityGuard().preflight(
            f'runtime_{command}'
        )
        if not _integrity.get('allowed', True):
            raise RetoolControlError(
                'config_integrity_blocked: '
                f"status={_integrity.get('status')} "
                f"critical_missing={_integrity.get('critical_missing_count')}"
            )

    allowed = {
        "doctor": [sys.executable, "main.py", "doctor"],
        "db-backup": [sys.executable, "main.py", "db-backup"],
        "selftest": [sys.executable, "main.py", "selftest"],
    }
    if command not in allowed:
        raise RetoolControlError("Ação não permitida.")
    try:
        proc = subprocess.run(
            allowed[command],
            cwd=str(settings.base_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=max(15, int(timeout_seconds)),
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "") if isinstance(exc.stdout, str) else ""
        return {"ok": False, "action": command, "result": "timeout", "output": output[-12000:]}
    return {
        "ok": proc.returncode == 0,
        "action": command,
        "returncode": proc.returncode,
        "output": (proc.stdout or "")[-12000:],
    }
