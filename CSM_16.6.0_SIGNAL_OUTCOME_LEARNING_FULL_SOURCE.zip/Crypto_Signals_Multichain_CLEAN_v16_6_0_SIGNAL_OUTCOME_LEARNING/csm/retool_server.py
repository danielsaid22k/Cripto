from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from .config import STATE_DIR, settings


class RetoolServerError(RuntimeError):
    pass


def _runtime_dir() -> Path:
    p = STATE_DIR / "runtime" / "retool_admin"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _pid_file() -> Path:
    return _runtime_dir() / "admin_web.pid"


def _log_file() -> Path:
    p = STATE_DIR / "logs" / "retool_admin.log"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _pid_alive(pid: int) -> bool:
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _cmdline(pid: int) -> str:
    try:
        return Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", errors="replace")
    except Exception:
        return ""


def _verified(pid: int) -> bool:
    low = _cmdline(pid).lower()
    return _pid_alive(pid) and "main.py" in low and "admin-web" in low


def _read_pid() -> int:
    try:
        return int(_pid_file().read_text(encoding="utf-8").strip())
    except Exception:
        return 0


def status() -> dict[str, Any]:
    pid = _read_pid()
    alive = _pid_alive(pid)
    verified = _verified(pid) if alive else False
    return {
        "running": bool(alive and verified),
        "pid": pid or None,
        "pid_alive": alive,
        "pid_verified": verified,
        "host": "127.0.0.1",
        "port": int(settings.admin_web_port),
        "protected": bool(settings.admin_web_token),
        "log": str(_log_file()),
    }


def start() -> dict[str, Any]:
    current = status()
    if current["running"]:
        return {"ok": True, "result": "already_running", **current}
    if not str(settings.admin_web_token or "").strip():
        raise RetoolServerError("ADMIN_WEB_TOKEN não configurado. Execute: python main.py retool-token")
    base = Path(settings.base_dir)
    main = base / "main.py"
    if not main.is_file():
        raise RetoolServerError(f"main.py não encontrado em {base}")
    log_handle = _log_file().open("ab", buffering=0)
    try:
        proc = subprocess.Popen(
            [sys.executable, "-u", str(main), "admin-web", "--host", "127.0.0.1", "--port", str(settings.admin_web_port)],
            cwd=str(base),
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
            env=os.environ.copy(),
        )
    finally:
        log_handle.close()
    _pid_file().write_text(str(proc.pid), encoding="utf-8")
    time.sleep(0.8)
    current = status()
    return {"ok": bool(current["running"]), "result": "started" if current["running"] else "failed", **current}


def stop(timeout_seconds: float = 6.0) -> dict[str, Any]:
    current = status()
    pid = int(current.get("pid") or 0)
    if not current.get("pid_alive"):
        _pid_file().unlink(missing_ok=True)
        return {"ok": True, "result": "already_stopped", **status()}
    if not current.get("pid_verified"):
        raise RetoolServerError("PID do painel não pôde ser validado; parada recusada por segurança.")
    if pid == os.getpid():
        raise RetoolServerError("O processo não pode encerrar a si próprio.")
    os.kill(pid, signal.SIGTERM)
    deadline = time.time() + max(1.0, timeout_seconds)
    while time.time() < deadline and _pid_alive(pid):
        time.sleep(0.2)
    if not _pid_alive(pid):
        _pid_file().unlink(missing_ok=True)
    current = status()
    return {"ok": not current["running"], "result": "stopped" if not current["running"] else "still_running", **current}
