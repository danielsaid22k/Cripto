from __future__ import annotations

import atexit
import json
import os
import time
from pathlib import Path

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


class AlreadyRunningError(RuntimeError):
    pass


class SingleInstance:
    """Trava de processo liberada automaticamente até após crash nativo."""

    def __init__(self, name: str = "bot") -> None:
        self.path = Path("data") / f".{name}.lock"
        self._handle = None
        self.acquired = False

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+", encoding="utf-8")
        if fcntl is not None:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                handle.seek(0)
                try:
                    payload = json.loads(handle.read() or "{}")
                    pid = int(payload.get("pid", 0))
                except Exception:
                    pid = 0
                handle.close()
                raise AlreadyRunningError(
                    f"Já existe uma instância do bot em execução (PID {pid or '?'}). "
                    "Pare-a com Ctrl+C antes de iniciar outra."
                )
        handle.seek(0)
        handle.truncate()
        handle.write(json.dumps({"pid": os.getpid(), "started_at": time.time()}))
        handle.flush()
        self._handle = handle
        self.acquired = True
        atexit.register(self.release)

    def release(self) -> None:
        if not self.acquired:
            return
        try:
            if self._handle is not None:
                if fcntl is not None:
                    try:
                        fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
                    except OSError:
                        pass
                self._handle.close()
            try:
                self.path.unlink()
            except OSError:
                pass
        finally:
            self._handle = None
            self.acquired = False
