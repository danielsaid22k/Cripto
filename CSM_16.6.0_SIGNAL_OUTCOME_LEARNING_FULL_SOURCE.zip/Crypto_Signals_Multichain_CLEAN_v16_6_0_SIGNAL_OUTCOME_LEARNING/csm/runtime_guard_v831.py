from __future__ import annotations

import atexit
import json
import os
import time
from pathlib import Path

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None

from .config import STATE_DIR


class AlreadyRunningError(RuntimeError):
    pass


class RuntimeGuardV831:
    """Trava de processo sem thread/heartbeat Python auxiliar."""

    def __init__(self, name: str = "bot") -> None:
        self.runtime_dir = STATE_DIR / "runtime" / "v831"
        self.lock_path = self.runtime_dir / f".{name}.lock"
        self.status_path = self.runtime_dir / f".{name}.status.json"
        self._handle = None
        self.acquired = False
        self.started_at = time.time()

    def _payload(self, state: str) -> dict:
        return {
            "pid": os.getpid(),
            "state": state,
            "started_at": self.started_at,
            "updated_at": time.time(),
            "version": "8.3.1",
            "single_python_runtime": True,
        }

    def _write_status(self, state: str) -> None:
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        tmp = self.status_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self._payload(state)), encoding="utf-8")
        tmp.replace(self.status_path)

    def acquire(self) -> None:
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        handle = self.lock_path.open("a+", encoding="utf-8")
        if fcntl is not None:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                handle.seek(0)
                try:
                    metadata = json.loads(handle.read() or "{}")
                except Exception:
                    metadata = {}
                handle.close()
                raise AlreadyRunningError(
                    f"Já existe uma instância do bot em execução (PID {metadata.get('pid', '?')}). "
                    "Pare-a com Ctrl+C antes de iniciar outra."
                )
        handle.seek(0); handle.truncate(); handle.write(json.dumps(self._payload("running"))); handle.flush()
        self._handle = handle; self.acquired = True
        self._write_status("running")
        atexit.register(self.release)

    def touch(self, state: str = "running") -> None:
        if self.acquired:
            try:
                self._write_status(state)
            except Exception:
                pass

    def release(self) -> None:
        if not self.acquired:
            return
        try:
            self._write_status("stopped")
        except Exception:
            pass
        try:
            if self._handle is not None:
                if fcntl is not None:
                    try:
                        fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
                    except OSError:
                        pass
                self._handle.close()
            try:
                self.lock_path.unlink(missing_ok=True)
            except Exception:
                pass
        finally:
            self._handle = None; self.acquired = False
