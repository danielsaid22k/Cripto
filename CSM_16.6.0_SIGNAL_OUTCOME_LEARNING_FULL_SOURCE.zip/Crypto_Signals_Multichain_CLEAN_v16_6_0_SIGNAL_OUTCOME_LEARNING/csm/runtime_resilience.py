from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any
from urllib import error as urllib_error
from urllib import request as urllib_request

from .config import STATE_DIR, settings

VERSION = "16.5.3"
STATE_FILE = STATE_DIR / "runtime_resilience" / "state.json"
HISTORY_FILE = STATE_DIR / "logs" / "runtime_resilience.jsonl"

FAILURES_BEFORE_RECOVERY = 2
RECOVERY_COOLDOWN_SECONDS = 60
RESTART_WINDOW_SECONDS = 15 * 60
MAX_RESTARTS_PER_WINDOW = 3


def _now() -> float:
    return time.time()


def _tmux_has_session(name: str) -> bool:
    try:
        return subprocess.run(
            ["tmux", "has-session", "-t", name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=3,
        ).returncode == 0
    except Exception:
        return False


def _probe_http(
    url: str,
    *,
    timeout: float = 0.8,
    accepted: set[int] | None = None,
    headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    accepted_codes = accepted or {200}
    req = urllib_request.Request(url, headers=headers or {}, method="GET")
    started = time.monotonic()
    try:
        with urllib_request.urlopen(req, timeout=max(0.1, float(timeout))) as response:
            body = response.read(65536)
            code = int(getattr(response, "status", 200) or 200)
        return {
            "ok": code in accepted_codes,
            "reachable": True,
            "http_status": code,
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "body": body,
            "error": None,
        }
    except urllib_error.HTTPError as exc:
        return {
            "ok": int(exc.code) in accepted_codes,
            "reachable": True,
            "http_status": int(exc.code),
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "body": b"",
            "error": None if int(exc.code) in accepted_codes else f"HTTP {exc.code}",
        }
    except Exception as exc:
        return {
            "ok": False,
            "reachable": False,
            "http_status": None,
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "body": b"",
            "error": f"{type(exc).__name__}: {exc}",
        }


def _probe_json(url: str, *, timeout: float = 0.8) -> dict[str, Any]:
    result = _probe_http(url, timeout=timeout, accepted={200})
    payload: dict[str, Any] = {}
    if result.get("ok"):
        try:
            parsed = json.loads((result.get("body") or b"{}").decode("utf-8"))
            if isinstance(parsed, dict):
                payload = parsed
        except Exception as exc:
            result["ok"] = False
            result["error"] = f"JSON {type(exc).__name__}"
    result.pop("body", None)
    result["payload"] = payload
    return result


def _component(
    name: str,
    state: str,
    *,
    expected: bool = True,
    recovery_supported: bool = False,
    reason: str = "",
    **details: Any,
) -> dict[str, Any]:
    normalized = str(state or "UNKNOWN").upper()
    return {
        "name": name,
        "state": normalized,
        "healthy": normalized == "HEALTHY",
        "expected": bool(expected),
        "recovery_supported": bool(recovery_supported),
        "reason": str(reason or ""),
        **details,
    }


def _supervisor_component() -> tuple[dict[str, Any], dict[str, Any]]:
    probe = _probe_json("http://127.0.0.1:8790/status", timeout=0.7)
    payload = probe.get("payload") or {}
    ok = bool(probe.get("ok") and payload.get("ok", True))
    state = "HEALTHY" if ok else "DOWN"
    component = _component(
        "supervisor",
        state,
        expected=True,
        recovery_supported=True,
        reason="endpoint_8790_ok" if ok else str(probe.get("error") or "endpoint_8790_unavailable"),
        http_status=probe.get("http_status"),
        latency_ms=probe.get("latency_ms"),
        tmux_session=_tmux_has_session("csm-supervisor"),
    )
    return component, payload


def _runtime_components(
    runtime_override: dict[str, Any] | None = None,
    desired_state: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    if runtime_override is None:
        from .retool_control import runtime_snapshot

        snap = runtime_snapshot()
    else:
        snap = dict(runtime_override)

    desired = desired_state if isinstance(desired_state, dict) else {}
    bot_expected = str(desired.get("bot") or "running").lower() != "stopped"
    api_expected = str(desired.get("api") or "running").lower() != "stopped"

    bot_healthy = bool(snap.get("bot_healthy"))
    bot_present = bool(snap.get("process_active"))
    bot_state = (
        "HEALTHY" if bot_healthy
        else "DEGRADED" if bot_present
        else "DOWN" if bot_expected
        else "STOPPED"
    )
    bot = _component(
        "bot",
        bot_state,
        expected=bot_expected,
        recovery_supported=True,
        reason=str(snap.get("bot_health_reason") or snap.get("runtime_health_reason") or ""),
        heartbeat_age_seconds=snap.get("heartbeat_age_seconds"),
        tmux_session=bool(snap.get("tmux_bot")),
        liveness_source=snap.get("liveness_source"),
        pid=snap.get("runtime_pid"),
    )

    api_healthy = bool(snap.get("saas_api_healthy"))
    api_present = bool(snap.get("saas_api_process_present") or snap.get("tmux_api"))
    api_state = (
        "HEALTHY" if api_healthy
        else "DEGRADED" if api_present
        else "DOWN" if api_expected
        else "STOPPED"
    )
    api = _component(
        "saas_api",
        api_state,
        expected=api_expected,
        recovery_supported=True,
        reason=str(snap.get("saas_api_health_reason") or ""),
        http_status=snap.get("saas_api_http_status"),
        latency_ms=snap.get("saas_api_latency_ms"),
        tmux_session=bool(snap.get("tmux_api")),
    )
    return bot, api, snap


def _admin_bridge_component(
    *,
    current_admin_bridge: bool = False,
    expected: bool = True,
) -> dict[str, Any]:
    if current_admin_bridge:
        return _component(
            "admin_bridge",
            "HEALTHY",
            expected=expected,
            recovery_supported=True,
            reason="current_request_is_served_by_admin_bridge",
            http_status=200,
        )

    token = str(getattr(settings, "admin_web_token", "") or "").strip()
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    accepted = {200} if token else {200, 401}
    probe = _probe_http(
        "http://127.0.0.1:8765/healthz",
        timeout=0.7,
        accepted=accepted,
        headers=headers,
    )
    if probe.get("ok"):
        reason = "healthz_ok" if probe.get("http_status") == 200 else "auth_guard_reachable"
        state = "HEALTHY"
    else:
        reason = str(probe.get("error") or "admin_bridge_unavailable")
        state = "DOWN"
    if not expected and state == "DOWN":
        state = "STOPPED"
        reason = "desired_state_stopped"
    return _component(
        "admin_bridge",
        state,
        expected=expected,
        recovery_supported=True,
        reason=reason,
        http_status=probe.get("http_status"),
        latency_ms=probe.get("latency_ms"),
    )


def _ngrok_component(supervisor_payload: dict[str, Any]) -> dict[str, Any]:
    desired = supervisor_payload.get("desired_state") if isinstance(supervisor_payload, dict) else {}
    expected = bool(
        (isinstance(desired, dict) and str(desired.get("ngrok") or "").lower() == "running")
        or _tmux_has_session("csm-ngrok")
    )
    probe = _probe_json("http://127.0.0.1:4040/api/tunnels", timeout=0.7)
    tunnels = []
    if probe.get("ok"):
        tunnels = (probe.get("payload") or {}).get("tunnels") or []
        if not isinstance(tunnels, list):
            tunnels = []
    active = bool(tunnels)
    tmux = _tmux_has_session("csm-ngrok")

    if active:
        state = "HEALTHY"
        reason = "ngrok_tunnel_active"
    elif tmux:
        state = "DEGRADED"
        reason = "ngrok_session_without_active_tunnel"
    elif expected:
        state = "DOWN"
        reason = "ngrok_expected_but_unavailable"
    else:
        state = "NOT_CONFIGURED"
        reason = "ngrok_not_declared"

    public_urls = []
    for item in tunnels[:5]:
        if isinstance(item, dict) and item.get("public_url"):
            public_urls.append(str(item.get("public_url")))

    return _component(
        "ngrok",
        state,
        expected=expected,
        recovery_supported=(Path.home() / ".termux/boot/95-csm-ngrok-admin.sh").is_file(),
        reason=reason,
        tmux_session=tmux,
        tunnel_count=len(tunnels),
        public_urls=public_urls,
        local_api_status=probe.get("http_status"),
    )


def _auditor_component() -> dict[str, Any]:
    boot = Path.home() / ".termux/boot/90-csm-config-audit.sh"
    script = Path.home() / "csm-config-audit/config_audit.py"
    tmux = _tmux_has_session("csm-config-audit")
    expected = boot.is_file() or script.is_file() or tmux
    if tmux:
        state = "HEALTHY"
        reason = "tmux_session_active"
    elif expected:
        state = "DOWN"
        reason = "auditor_expected_but_session_missing"
    else:
        state = "NOT_CONFIGURED"
        reason = "auditor_not_installed"
    return _component(
        "config_auditor",
        state,
        expected=expected,
        recovery_supported=script.is_file(),
        reason=reason,
        tmux_session=tmux,
        boot_persistent=boot.is_file(),
    )


def collect_components(
    *,
    current_admin_bridge: bool = False,
    runtime_override: dict[str, Any] | None = None,
) -> dict[str, Any]:
    supervisor, supervisor_payload = _supervisor_component()
    desired = (
        supervisor_payload.get("desired_state")
        if isinstance(supervisor_payload, dict)
        else {}
    )
    if not isinstance(desired, dict):
        desired = {}
    bot, api, runtime = _runtime_components(runtime_override, desired)
    admin_expected = str(desired.get("admin_bridge") or "running").lower() != "stopped"
    admin = _admin_bridge_component(
        current_admin_bridge=current_admin_bridge,
        expected=admin_expected,
    )
    ngrok = _ngrok_component(supervisor_payload)
    auditor = _auditor_component()

    components = {
        item["name"]: item
        for item in (bot, api, supervisor, admin, ngrok, auditor)
    }

    weights = {
        "bot": 30,
        "saas_api": 20,
        "supervisor": 15,
        "admin_bridge": 15,
        "ngrok": 10,
        "config_auditor": 10,
    }

    earned = 0.0
    possible = 0.0
    expected_problem = False
    core_down = False
    for name, item in components.items():
        if not item.get("expected"):
            continue
        weight = float(weights.get(name, 0))
        possible += weight
        state = str(item.get("state") or "UNKNOWN")
        if state == "HEALTHY":
            earned += weight
        elif state == "DEGRADED":
            earned += weight * 0.5
            expected_problem = True
        else:
            expected_problem = True
            if name in {"bot", "saas_api"}:
                core_down = True

    score = int(round(100 * earned / possible)) if possible else 100
    if core_down and score < 50:
        overall_state = "FAILED"
    elif expected_problem:
        overall_state = "DEGRADED"
    else:
        overall_state = "HEALTHY"

    return {
        "version": VERSION,
        "state": overall_state,
        "health_score": score,
        "generated_at": _now(),
        "components": components,
        "runtime": runtime,
        "automatic_recovery_policy": {
            "enabled_by_watcher_only": True,
            "failures_before_recovery": FAILURES_BEFORE_RECOVERY,
            "cooldown_seconds": RECOVERY_COOLDOWN_SECONDS,
            "max_restarts": MAX_RESTARTS_PER_WINDOW,
            "window_seconds": RESTART_WINDOW_SECONDS,
            "config_changes_allowed": False,
            "secret_values_logged": False,
        },
    }


def _read_state() -> dict[str, Any]:
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_state(data: dict[str, Any]) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STATE_FILE)


def _append_history(event: dict[str, Any]) -> None:
    HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    safe = {
        "ts": float(event.get("ts") or _now()),
        "component": str(event.get("component") or "unknown"),
        "action": str(event.get("action") or "none"),
        "result": str(event.get("result") or "unknown"),
        "reason": str(event.get("reason") or "")[:500],
    }
    with HISTORY_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(safe, ensure_ascii=False) + "\n")


def _restart_budget(state: dict[str, Any], component: str, now: float) -> tuple[bool, list[float]]:
    runtime = state.setdefault("components", {}).setdefault(component, {})
    restarts = [
        float(ts)
        for ts in (runtime.get("restart_attempts") or [])
        if now - float(ts) <= RESTART_WINDOW_SECONDS
    ]
    runtime["restart_attempts"] = restarts
    last = float(runtime.get("last_attempt") or 0)
    if now - last < RECOVERY_COOLDOWN_SECONDS:
        return False, restarts
    if len(restarts) >= MAX_RESTARTS_PER_WINDOW:
        return False, restarts
    return True, restarts


def _record_attempt(state: dict[str, Any], component: str, now: float) -> None:
    runtime = state.setdefault("components", {}).setdefault(component, {})
    attempts = [
        float(ts)
        for ts in (runtime.get("restart_attempts") or [])
        if now - float(ts) <= RESTART_WINDOW_SECONDS
    ]
    attempts.append(now)
    runtime["restart_attempts"] = attempts
    runtime["last_attempt"] = now


def _recover_supervisor() -> tuple[bool, str]:
    directory = Path.home() / "csm-supervisor"
    api = directory / "api.py"
    if not api.is_file():
        return False, "supervisor_api_not_found"
    if _tmux_has_session("csm-supervisor"):
        return True, "already_running"
    try:
        subprocess.run(
            [
                "tmux",
                "new-session",
                "-d",
                "-s",
                "csm-supervisor",
                f"cd '{directory}' && exec python -u api.py >> logs/api.log 2>&1",
            ],
            check=False,
            timeout=5,
        )
        time.sleep(1.0)
        return _tmux_has_session("csm-supervisor"), "tmux_start_requested"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _recover_runtime_core() -> tuple[bool, str]:
    req = urllib_request.Request(
        "http://127.0.0.1:8790/runtime/start",
        data=b"",
        method="POST",
    )
    try:
        with urllib_request.urlopen(req, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return bool(payload.get("ok")), str(payload.get("message") or payload.get("result") or "runtime_start_requested")
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _recover_admin_bridge() -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            [sys.executable, "main.py", "retool-admin-start"],
            cwd=str(settings.base_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=25,
            check=False,
        )
        return proc.returncode == 0, (proc.stdout or "")[-500:].strip()
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _recover_ngrok() -> tuple[bool, str]:
    boot = Path.home() / ".termux/boot/95-csm-ngrok-admin.sh"
    if not boot.is_file():
        return False, "ngrok_boot_script_not_found"
    try:
        subprocess.Popen(
            [str(boot)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return True, "boot_script_started"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _recover_auditor() -> tuple[bool, str]:
    script = Path.home() / "csm-config-audit/config_audit.py"
    directory = script.parent
    if not script.is_file():
        return False, "auditor_script_not_found"
    if _tmux_has_session("csm-config-audit"):
        return True, "already_running"
    log = STATE_DIR / "logs" / "config_write_audit.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(
            [
                "tmux",
                "new-session",
                "-d",
                "-s",
                "csm-config-audit",
                f"cd '{directory}' && exec python -u config_audit.py >> '{log}' 2>&1",
            ],
            check=False,
            timeout=5,
        )
        return _tmux_has_session("csm-config-audit"), "tmux_start_requested"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _eligible_for_recovery(
    state: dict[str, Any],
    component: str,
    unhealthy: bool,
    now: float,
) -> tuple[bool, str]:
    entry = state.setdefault("components", {}).setdefault(component, {})
    failures = int(entry.get("consecutive_failures") or 0)
    if unhealthy:
        failures += 1
    else:
        failures = 0
    entry["consecutive_failures"] = failures
    entry["last_seen"] = now

    if not unhealthy:
        return False, "healthy"
    if failures < FAILURES_BEFORE_RECOVERY:
        return False, "confirmation_pending"

    allowed, attempts = _restart_budget(state, component, now)
    if not allowed:
        if len(attempts) >= MAX_RESTARTS_PER_WINDOW:
            entry["blocked_reason"] = "restart_storm_protection"
            return False, "restart_storm_protection"
        return False, "cooldown"
    entry.pop("blocked_reason", None)
    return True, "eligible"


def watch_once(*, recover: bool = True) -> dict[str, Any]:
    now = _now()
    state = _read_state()
    before = collect_components(current_admin_bridge=False)
    components = before.get("components") or {}
    actions: list[dict[str, Any]] = []

    maintenance: dict[str, Any] = {}
    try:
        from .project_leader import ProjectLeader

        maintenance = ProjectLeader().maintenance() or {}
    except Exception as exc:
        maintenance = {
            "active": False,
            "error": f"{type(exc).__name__}: {exc}",
        }
    maintenance_active = bool(maintenance.get("active"))
    recovery_enabled = bool(recover and not maintenance_active)

    if recover and maintenance_active:
        actions.append({
            "component": "system",
            "action": "none",
            "result": "maintenance_active",
            "reason": str(maintenance.get("reason") or "project_leader_maintenance"),
        })

    recovery_order = [
        ("supervisor", _recover_supervisor),
        ("admin_bridge", _recover_admin_bridge),
        ("ngrok", _recover_ngrok),
        ("config_auditor", _recover_auditor),
    ]

    for name, recovery in recovery_order:
        item = components.get(name) or {}
        unhealthy = bool(item.get("expected") and item.get("state") not in {"HEALTHY", "NOT_CONFIGURED"})
        eligible, reason = _eligible_for_recovery(state, name, unhealthy, now)
        if recovery_enabled and eligible and item.get("recovery_supported"):
            _record_attempt(state, name, now)
            ok, message = recovery()
            action = {
                "component": name,
                "action": "recover",
                "result": "requested" if ok else "failed",
                "reason": message,
            }
            actions.append(action)
            _append_history({"ts": now, **action})
        elif unhealthy:
            actions.append({
                "component": name,
                "action": "none",
                "result": reason,
                "reason": str(item.get("reason") or ""),
            })

    # Runtime core recovery is grouped to avoid restarting bot and API separately.
    runtime_unhealthy = any(
        bool((components.get(name) or {}).get("expected"))
        and (components.get(name) or {}).get("state") != "HEALTHY"
        for name in ("bot", "saas_api")
    )
    eligible, reason = _eligible_for_recovery(state, "runtime_core", runtime_unhealthy, now)
    supervisor_ok = (components.get("supervisor") or {}).get("state") == "HEALTHY"
    integrity_allowed = True
    integrity_reason = "ok"
    if runtime_unhealthy and recovery_enabled:
        try:
            from .config_integrity import ConfigIntegrityGuard

            integrity = ConfigIntegrityGuard().preflight(
                "runtime_resilience_recovery"
            )
            integrity_allowed = bool(integrity.get("allowed", True))
            if not integrity_allowed:
                integrity_reason = (
                    f"config_integrity_blocked:"
                    f"critical_missing={integrity.get('critical_missing_count', 0)}"
                )
        except Exception as exc:
            integrity_allowed = False
            integrity_reason = f"config_integrity_unavailable:{type(exc).__name__}"

    if recovery_enabled and eligible and supervisor_ok and integrity_allowed:
        _record_attempt(state, "runtime_core", now)
        ok, message = _recover_runtime_core()
        action = {
            "component": "runtime_core",
            "action": "recover",
            "result": "requested" if ok else "failed",
            "reason": message,
        }
        actions.append(action)
        _append_history({"ts": now, **action})
    elif runtime_unhealthy:
        if not recovery_enabled and maintenance_active:
            runtime_result = "maintenance_active"
        elif not supervisor_ok:
            runtime_result = "supervisor_unavailable"
        elif not integrity_allowed:
            runtime_result = integrity_reason
        else:
            runtime_result = reason
        actions.append({
            "component": "runtime_core",
            "action": "none",
            "result": runtime_result,
            "reason": "bot_or_api_not_healthy",
        })

    state["updated_at"] = now
    _write_state(state)

    if recovery_enabled and any(item.get("action") == "recover" and item.get("result") == "requested" for item in actions):
        time.sleep(1.5)
    after = collect_components(current_admin_bridge=False)
    after["actions"] = actions
    after["maintenance"] = maintenance
    after["recovery_enabled"] = recovery_enabled
    after["watcher_state"] = state
    return after


def overview(
    *,
    current_admin_bridge: bool = False,
    runtime_override: dict[str, Any] | None = None,
) -> dict[str, Any]:
    data = collect_components(
        current_admin_bridge=current_admin_bridge,
        runtime_override=runtime_override,
    )
    state = _read_state()
    data["watcher"] = {
        "state_file": str(STATE_FILE),
        "history_file": str(HISTORY_FILE),
        "last_watch_at": state.get("updated_at"),
        "restart_storm_protection": True,
        "automatic_config_restore": False,
        "automatic_config_block": False,
        "secret_values_logged": False,
    }
    return data


def watch_loop(*, interval_seconds: int = 60) -> None:
    interval = max(30, int(interval_seconds))
    while True:
        try:
            result = watch_once(recover=True)
            summary = {
                "ts": _now(),
                "state": result.get("state"),
                "health_score": result.get("health_score"),
                "actions": result.get("actions") or [],
            }
            print(json.dumps(summary, ensure_ascii=False), flush=True)
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            print(
                json.dumps(
                    {
                        "ts": _now(),
                        "state": "ERROR",
                        "error": f"{type(exc).__name__}: {exc}",
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )
        time.sleep(interval)
