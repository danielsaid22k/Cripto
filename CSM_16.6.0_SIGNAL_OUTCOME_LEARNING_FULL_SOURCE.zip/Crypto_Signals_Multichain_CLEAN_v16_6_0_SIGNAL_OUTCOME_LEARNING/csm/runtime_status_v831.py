from __future__ import annotations

import json
import os
import resource
import time
from pathlib import Path

from .ashell_runtime_v831 import runtime_capabilities
from .config import STATE_DIR


def runtime_status_v831() -> dict:
    caps = runtime_capabilities()
    status_file = STATE_DIR / "runtime" / "v831" / ".bot.status.json"
    saved = {}
    try:
        saved = json.loads(status_file.read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    except Exception:
        rss = None
    updated = float(saved.get("updated_at") or 0)
    return {
        **caps,
        "status_file": str(status_file),
        "runtime_state": saved.get("state", "not-started"),
        "runtime_pid": saved.get("pid"),
        "status_age_seconds": max(0.0, time.time() - updated) if updated else None,
        "memory_max_rss": rss,
        "python_workers_enabled": False,
        "scanner_mode": "single-python-cooperative-v831",
        "market_transport": "curl" if caps.get("ashell") else "python-safehttp",
    }
