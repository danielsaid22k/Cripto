from __future__ import annotations

import hashlib
import secrets
import time
from datetime import datetime, timezone
from typing import Any

from .config import settings
from .entitlements import EntitlementManager, ensure_schema as ensure_entitlement_schema


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS saas_tenants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            status TEXT DEFAULT 'ACTIVE',
            brand_name TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS saas_api_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id INTEGER NOT NULL,
            name TEXT DEFAULT 'default',
            key_prefix TEXT NOT NULL,
            key_hash TEXT NOT NULL UNIQUE,
            rpm_limit INTEGER NOT NULL DEFAULT 60,
            daily_limit INTEGER NOT NULL DEFAULT 10000,
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            last_used_at TEXT,
            FOREIGN KEY(tenant_id) REFERENCES saas_tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_saas_api_keys_tenant ON saas_api_keys(tenant_id, active);
        CREATE TABLE IF NOT EXISTS saas_usage (
            key_id INTEGER NOT NULL,
            minute_bucket TEXT NOT NULL,
            day_bucket TEXT NOT NULL,
            requests INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(key_id, minute_bucket),
            FOREIGN KEY(key_id) REFERENCES saas_api_keys(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_saas_usage_day ON saas_usage(key_id, day_bucket);
        """
    )
    conn.commit()
    ensure_entitlement_schema(conn)


def _slug(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "-" for ch in str(value or ""))
    while "--" in text:
        text = text.replace("--", "-")
    return text.strip("-")[:64]


def _hash_key(raw: str) -> str:
    return hashlib.sha256(str(raw).encode("utf-8")).hexdigest()


class SaaSManager:
    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)

    def create_tenant(
        self,
        name: str,
        slug: str | None = None,
        brand_name: str = "",
        *,
        plan: str = "free",
        user_id: int | None = None,
    ) -> dict[str, Any]:
        clean_name = str(name or "").strip()
        if not clean_name:
            raise ValueError("nome do tenant é obrigatório")
        clean_slug = _slug(slug or clean_name)
        if not clean_slug:
            raise ValueError("slug inválido")
        clean_plan = str(plan or "free").strip().lower()
        if clean_plan not in {"free", "plus", "premium", "enterprise"}:
            raise ValueError("plano SaaS inválido")
        self.conn.execute(
            """INSERT INTO saas_tenants(
                   slug,name,brand_name,entitlement_plan,entitlement_status,linked_user_id
               ) VALUES(?,?,?,?,?,?)""",
            (
                clean_slug, clean_name[:120], str(brand_name or clean_name)[:120],
                clean_plan, "ACTIVE", int(user_id) if user_id is not None else None,
            ),
        )
        self.conn.commit()
        row = self.conn.execute("SELECT * FROM saas_tenants WHERE slug=?", (clean_slug,)).fetchone()
        return dict(row)

    def list_tenants(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT t.*,COUNT(k.id) AS api_keys
               FROM saas_tenants t LEFT JOIN saas_api_keys k ON k.tenant_id=t.id AND k.active=1
               GROUP BY t.id ORDER BY t.id"""
        ).fetchall()
        return [dict(row) for row in rows]

    def create_api_key(self, tenant_slug: str, *, name: str = "default", rpm: int | None = None, daily: int | None = None) -> dict[str, Any]:
        tenant = self.conn.execute("SELECT * FROM saas_tenants WHERE slug=? AND status='ACTIVE'", (_slug(tenant_slug),)).fetchone()
        if not tenant:
            raise ValueError("tenant ativo não encontrado")
        entitlement = EntitlementManager(self.storage).effective(dict(tenant)) or {}
        limits = entitlement.get("limits") or {}
        default_rpm = int(limits.get("api_rpm") or settings.saas_default_rpm)
        default_daily = int(limits.get("api_daily") or settings.saas_default_daily_limit)
        final_rpm = max(1, int(rpm if rpm is not None else default_rpm))
        final_daily = max(1, int(daily if daily is not None else default_daily))
        raw = "csm_live_" + secrets.token_urlsafe(24)
        prefix = raw[:16]
        self.conn.execute(
            """INSERT INTO saas_api_keys(tenant_id,name,key_prefix,key_hash,rpm_limit,daily_limit)
               VALUES(?,?,?,?,?,?)""",
            (
                int(tenant["id"]), str(name or "default")[:80], prefix, _hash_key(raw),
                final_rpm, final_daily,
            ),
        )
        self.conn.commit()
        return {
            "tenant": tenant["slug"],
            "name": str(name or "default"),
            "api_key": raw,
            "key_prefix": prefix,
            "rpm_limit": final_rpm,
            "daily_limit": final_daily,
            "warning": "A chave completa é exibida apenas nesta criação. Guarde-a em local seguro.",
        }

    def revoke_key(self, key_prefix: str) -> bool:
        cur = self.conn.execute("UPDATE saas_api_keys SET active=0 WHERE key_prefix=?", (str(key_prefix),))
        self.conn.commit()
        return bool(cur.rowcount)

    def authenticate(self, raw_key: str, *, consume: bool = True) -> dict[str, Any] | None:
        digest = _hash_key(raw_key)
        row = self.conn.execute(
            """SELECT k.*,t.slug AS tenant_slug,t.name AS tenant_name,t.brand_name,
                      t.entitlement_plan,t.entitlement_status,t.entitlement_expires_at,
                      t.entitlement_grace_until,t.linked_user_id
               FROM saas_api_keys k JOIN saas_tenants t ON t.id=k.tenant_id
               WHERE k.key_hash=? AND k.active=1 AND t.status='ACTIVE'""",
            (digest,),
        ).fetchone()
        if not row:
            return None
        data = dict(row)
        if consume:
            self._consume(data)
        return data

    def _consume(self, key: dict[str, Any]) -> None:
        now = datetime.now(timezone.utc)
        minute = now.strftime("%Y-%m-%dT%H:%M")
        day = now.strftime("%Y-%m-%d")
        key_id = int(key["id"])
        current = self.conn.execute(
            "SELECT requests FROM saas_usage WHERE key_id=? AND minute_bucket=?", (key_id, minute)
        ).fetchone()
        minute_count = int(current["requests"] if current else 0)
        daily_count = int(self.conn.execute(
            "SELECT COALESCE(SUM(requests),0) FROM saas_usage WHERE key_id=? AND day_bucket=?", (key_id, day)
        ).fetchone()[0])
        if minute_count >= int(key["rpm_limit"]):
            raise RuntimeError("rate_limit_rpm")
        if daily_count >= int(key["daily_limit"]):
            raise RuntimeError("rate_limit_daily")
        self.conn.execute(
            """INSERT INTO saas_usage(key_id,minute_bucket,day_bucket,requests) VALUES(?,?,?,1)
               ON CONFLICT(key_id,minute_bucket) DO UPDATE SET requests=requests+1""",
            (key_id, minute, day),
        )
        self.conn.execute("UPDATE saas_api_keys SET last_used_at=CURRENT_TIMESTAMP WHERE id=?", (key_id,))
        # Keep the usage table bounded.
        self.conn.execute("DELETE FROM saas_usage WHERE day_bucket < date('now','-35 days')")
        self.conn.commit()

    def usage_summary(self, tenant_slug: str, key_id: int | None = None) -> dict[str, Any]:
        tenant = self.conn.execute("SELECT id,slug FROM saas_tenants WHERE slug=?", (_slug(tenant_slug),)).fetchone()
        if not tenant:
            raise ValueError("tenant não encontrado")
        params: list[Any] = [int(tenant["id"])]
        key_filter = ""
        if key_id is not None:
            key_filter = " AND k.id=?"
            params.append(int(key_id))
        rows = self.conn.execute(
            f"""SELECT k.id,k.name,k.key_prefix,k.rpm_limit,k.daily_limit,k.active,k.last_used_at,
                       COALESCE(SUM(CASE WHEN u.day_bucket=date('now') THEN u.requests ELSE 0 END),0) AS requests_today
                FROM saas_api_keys k
                LEFT JOIN saas_usage u ON u.key_id=k.id
                WHERE k.tenant_id=?{key_filter}
                GROUP BY k.id ORDER BY k.id""",
            tuple(params),
        ).fetchall()
        items = [dict(row) for row in rows]
        return {
            "tenant": tenant["slug"],
            "requests_today": sum(int(row.get("requests_today") or 0) for row in items),
            "active_keys": sum(1 for row in items if int(row.get("active") or 0)),
            "keys": items,
        }

    def entitlement(self, tenant_slug: str) -> dict[str, Any] | None:
        return EntitlementManager(self.storage).effective(_slug(tenant_slug))

    def safe_keys(self, tenant_slug: str | None = None) -> list[dict[str, Any]]:
        sql = """SELECT k.id,t.slug AS tenant,k.name,k.key_prefix,k.rpm_limit,k.daily_limit,k.active,k.created_at,k.last_used_at
                 FROM saas_api_keys k JOIN saas_tenants t ON t.id=k.tenant_id"""
        params: tuple[Any, ...] = ()
        if tenant_slug:
            sql += " WHERE t.slug=?"
            params = (_slug(tenant_slug),)
        sql += " ORDER BY k.id DESC"
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]
