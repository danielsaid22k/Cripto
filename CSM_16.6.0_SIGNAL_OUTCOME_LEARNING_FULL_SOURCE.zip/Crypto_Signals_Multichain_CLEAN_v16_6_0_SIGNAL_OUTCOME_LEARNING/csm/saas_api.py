from __future__ import annotations

import json
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import __product_version__
from .branding import load_branding
from .config import settings
from .performance import PerformanceLedger
from .onchain import OnChainLedger
from .reputation import ReputationEngine
from .observability import ObservabilityEngine
from .distribution import DistributionManager
from .proof import ProofLedger
from .provider_health import load_provider_health
from .saas import SaaSManager
from .entitlements import EntitlementManager
from .customer_portal import portal_page
from .storage import Storage


def _json(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":")).encode("utf-8")


def _int_arg(query: dict[str, list[str]], key: str, default: int, lo: int, hi: int) -> int:
    try:
        value = int((query.get(key) or [str(default)])[0])
    except Exception:
        value = default
    return max(lo, min(hi, value))


class SaaSAPIHandler(BaseHTTPRequestHandler):
    server_version = "CSM-SaaS/16.0"

    def _send(self, status: int, payload) -> None:
        body = _json(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, status: int, body: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
        )
        self.end_headers()
        self.wfile.write(body)

    @staticmethod
    def _feature_for_path(path: str) -> str:
        if path.startswith("/api/v1/portal/"):
            return "portal"
        if path.startswith("/api/v1/enterprise/"):
            return "enterprise"
        if path == "/api/v1/status":
            return "status"
        if path == "/api/v1/branding":
            return "branding"
        if path.startswith("/api/v1/providers"):
            return "providers"
        if path.startswith("/api/v1/distribution"):
            return "distribution"
        if path.startswith("/api/v1/observability"):
            return "observability"
        if path.startswith("/api/v1/performance"):
            return "performance"
        if path.startswith("/api/v1/reputation"):
            return "reputation"
        if path.startswith("/api/v1/onchain"):
            return "onchain"
        if path.startswith("/api/v1/proof"):
            return "proofs"
        if path.startswith("/api/v1/signals"):
            return "signals"
        if path.startswith("/api/v1/security"):
            return "security"
        return "status"

    def _raw_key(self) -> str:
        auth = str(self.headers.get("Authorization") or "").strip()
        if auth.lower().startswith("bearer "):
            return auth.split(" ", 1)[1].strip()
        return str(self.headers.get("X-API-Key") or "").strip()

    def _auth(self):
        raw = self._raw_key()
        if not raw:
            self._send(HTTPStatus.UNAUTHORIZED, {"error": "missing_api_key"})
            return None
        with self.server.db_lock:  # type: ignore[attr-defined]
            try:
                tenant = self.server.saas.authenticate(raw, consume=True)  # type: ignore[attr-defined]
            except RuntimeError as exc:
                code = str(exc)
                self._send(HTTPStatus.TOO_MANY_REQUESTS, {"error": code})
                return None
        if not tenant:
            self._send(HTTPStatus.UNAUTHORIZED, {"error": "invalid_api_key"})
            return None
        return tenant

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        query = parse_qs(parsed.query)
        if path == "/healthz":
            self._send(HTTPStatus.OK, {"status": "ok", "version": __product_version__})
            return
        if path == "/portal":
            if not settings.customer_portal_enabled:
                self._send(HTTPStatus.NOT_FOUND, {"error": "portal_disabled"})
                return
            brand = load_branding()
            self._send_html(HTTPStatus.OK, portal_page(
                str(brand.get("product_name") or "Crypto Signals Multichain"),
                __product_version__, str(brand.get("logo_emoji") or "🌐"),
            ))
            return
        tenant = self._auth()
        if tenant is None:
            return
        entitlement = self.server.entitlements.effective(tenant)  # type: ignore[attr-defined]
        feature = self._feature_for_path(path)
        if not entitlement or feature not in set(entitlement.get("features") or []):
            self._send(HTTPStatus.FORBIDDEN, {
                "error": "feature_not_available",
                "feature": feature,
                "plan": (entitlement or {}).get("plan", "free"),
                "entitlement_status": (entitlement or {}).get("status", "UNKNOWN"),
            })
            return
        limits = entitlement.get("limits") or {}
        signal_days_cap = max(1, int(limits.get("signal_days") or 1))
        signal_limit_cap = max(1, int(limits.get("signal_limit") or 1))
        performance_days_cap = max(1, int(limits.get("performance_days") or signal_days_cap))
        try:
            if path == "/api/v1/portal/me":
                self._send(HTTPStatus.OK, {
                    "tenant": tenant["tenant_slug"],
                    "tenant_name": tenant["tenant_name"],
                    "brand_name": tenant.get("brand_name") or tenant["tenant_name"],
                    "key_prefix": tenant.get("key_prefix"),
                    "entitlement": entitlement,
                })
                return
            if path == "/api/v1/portal/usage":
                with self.server.db_lock:  # type: ignore[attr-defined]
                    usage = self.server.saas.usage_summary(tenant["tenant_slug"], key_id=int(tenant["id"]))  # type: ignore[attr-defined]
                item = (usage.get("keys") or [{}])[0]
                self._send(HTTPStatus.OK, {
                    "tenant": tenant["tenant_slug"],
                    "requests_today": int(item.get("requests_today") or 0),
                    "rpm_limit": int(item.get("rpm_limit") or tenant.get("rpm_limit") or 0),
                    "daily_limit": int(item.get("daily_limit") or tenant.get("daily_limit") or 0),
                    "key_prefix": item.get("key_prefix") or tenant.get("key_prefix"),
                    "last_used_at": item.get("last_used_at"),
                })
                return
            if path == "/api/v1/portal/subscription":
                payload = {
                    "source": "tenant-entitlement",
                    "plan": entitlement.get("plan"),
                    "status": entitlement.get("status"),
                    "expires_at": entitlement.get("expires_at"),
                    "grace_until": entitlement.get("grace_until"),
                }
                linked_user = entitlement.get("linked_user_id")
                if linked_user is not None:
                    with self.server.db_lock:  # type: ignore[attr-defined]
                        user = self.server.storage.conn.execute(  # type: ignore[attr-defined]
                            "SELECT user_id,plan,expires_at,blocked FROM users WHERE user_id=?", (int(linked_user),)
                        ).fetchone()
                        subscription = self.server.storage.active_subscription(int(linked_user)) if user else None  # type: ignore[attr-defined]
                    if user:
                        payload.update({
                            "source": "linked-user", "user_id": int(user["user_id"]),
                            "user_plan": user["plan"], "expires_at": user["expires_at"],
                            "blocked": bool(user["blocked"]), "subscription": subscription,
                        })
                self._send(HTTPStatus.OK, payload)
                return
            if path == "/api/v1/portal/overview":
                limit = max(1, min(int(settings.customer_portal_max_signals), signal_limit_cap))
                portal_days = min(30, signal_days_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    usage_all = self.server.saas.usage_summary(tenant["tenant_slug"], key_id=int(tenant["id"]))  # type: ignore[attr-defined]
                    rows = self.server.ledger.signals(days=portal_days, limit=limit) if "signals" in entitlement["features"] else []  # type: ignore[attr-defined]
                    subscription = {
                        "source": "tenant-entitlement", "plan": entitlement.get("plan"),
                        "status": entitlement.get("status"), "expires_at": entitlement.get("expires_at"),
                    }
                    linked_user = entitlement.get("linked_user_id")
                    if linked_user is not None:
                        user = self.server.storage.conn.execute(  # type: ignore[attr-defined]
                            "SELECT user_id,plan,expires_at,blocked FROM users WHERE user_id=?", (int(linked_user),)
                        ).fetchone()
                        if user:
                            subscription = {
                                "source": "linked-user", "user_id": int(user["user_id"]), "plan": user["plan"],
                                "expires_at": user["expires_at"], "blocked": bool(user["blocked"]),
                            }
                    perf = self.server.ledger.report(days=30) if "performance" in entitlement["features"] else {}  # type: ignore[attr-defined]
                    proof = self.server.proofs.status() if "proofs" in entitlement["features"] else {}  # type: ignore[attr-defined]
                    enterprise_payload = None
                    if "enterprise" in entitlement["features"] and settings.enterprise_dashboard_enabled:
                        ops = self.server.observability.status(days=7)  # type: ignore[attr-defined]
                        dist = self.server.distribution.status(days=7)  # type: ignore[attr-defined]
                        enterprise_payload = {
                            "health_score": ops.get("health_score"),
                            "open_incidents": ops.get("open_incidents"),
                            "distribution_destinations": dist.get("active_destinations"),
                            "distribution_jobs": dist.get("jobs", {}),
                        }
                safe_signals = [{
                    key: row.get(key) for key in (
                        "id","chain","address","symbol","name","entry_price","final_score","goplus_score",
                        "goplus_risk","last_return_pct","max_return_pct","status","created_at"
                    )
                } for row in rows]
                usage_item = (usage_all.get("keys") or [{}])[0]
                self._send(HTTPStatus.OK, {
                    "me": {
                        "tenant": tenant["tenant_slug"], "tenant_name": tenant["tenant_name"],
                        "key_prefix": tenant.get("key_prefix"), "entitlement": entitlement,
                    },
                    "usage": {
                        "requests_today": int(usage_item.get("requests_today") or 0),
                        "rpm_limit": int(usage_item.get("rpm_limit") or tenant.get("rpm_limit") or 0),
                        "daily_limit": int(usage_item.get("daily_limit") or tenant.get("daily_limit") or 0),
                    },
                    "subscription": subscription,
                    "signals": {"items": safe_signals, "count": len(safe_signals)},
                    "performance": perf, "proof": proof, "enterprise": enterprise_payload,
                })
                return
            if path == "/api/v1/enterprise/overview":
                if not settings.enterprise_dashboard_enabled:
                    self._send(HTTPStatus.NOT_FOUND, {"error": "enterprise_dashboard_disabled"})
                    return
                with self.server.db_lock:  # type: ignore[attr-defined]
                    perf = self.server.ledger.report(days=30)  # type: ignore[attr-defined]
                    ops = self.server.observability.report(days=7, limit=50)  # type: ignore[attr-defined]
                    dist = self.server.distribution.status(days=7)  # type: ignore[attr-defined]
                    proof = self.server.proofs.status()  # type: ignore[attr-defined]
                    onchain = self.server.onchain.status(days=30)  # type: ignore[attr-defined]
                    reputation = self.server.reputation.status(days=3650)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, {
                    "tenant": tenant["tenant_slug"], "entitlement": entitlement,
                    "performance": perf, "observability": ops, "distribution": dist,
                    "proof": proof, "onchain": onchain, "reputation": reputation,
                })
                return
            if path == "/api/v1/status":
                self._send(HTTPStatus.OK, {
                    "product": load_branding().get("product_name"),
                    "version": __product_version__,
                    "tenant": tenant["tenant_slug"],
                    "entitlement": entitlement,
                    "capabilities": entitlement.get("features", []),
                    "portal": "/portal" if settings.customer_portal_enabled else None,
                })
                return
            if path == "/api/v1/branding":
                brand = load_branding()
                if tenant.get("brand_name"):
                    brand = {**brand, "product_name": tenant["brand_name"]}
                self._send(HTTPStatus.OK, brand)
                return
            if path == "/api/v1/providers":
                self._send(HTTPStatus.OK, load_provider_health())
                return
            if path == "/api/v1/distribution":
                days = min(_int_arg(query, "days", 7, 1, 3650), performance_days_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    status = self.server.distribution.status(days=days)  # type: ignore[attr-defined]
                    jobs = self.server.distribution.jobs(limit=100)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, {"status": status, "jobs": jobs})
                return
            if path == "/api/v1/distribution/dead-letter":
                limit = _int_arg(query, "limit", 100, 1, 500)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    jobs = self.server.distribution.jobs(limit=limit, status="DEAD")  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, {"items": jobs, "count": len(jobs)})
                return
            if path == "/api/v1/observability":
                days = min(_int_arg(query, "days", 7, 1, 3650), performance_days_cap)
                limit = _int_arg(query, "limit", 100, 1, 500)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    payload = self.server.observability.report(days=days, limit=limit)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, payload)
                return
            if path == "/api/v1/observability/incidents":
                limit = _int_arg(query, "limit", 100, 1, 1000)
                open_only = str((query.get("open_only") or ["false"])[0]).lower() in {"1","true","yes"}
                with self.server.db_lock:  # type: ignore[attr-defined]
                    items = self.server.observability.incidents(open_only=open_only, limit=limit)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, {"items": items, "count": len(items)})
                return
            if path == "/api/v1/performance":
                days = min(_int_arg(query, "days", 30, 1, 3650), performance_days_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    report = self.server.ledger.report(days=days)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, report)
                return
            if path == "/api/v1/reputation":
                days = min(_int_arg(query, "days", 3650, 1, 3650), performance_days_cap)
                limit = min(_int_arg(query, "limit", 100, 1, 1000), signal_limit_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    payload = self.server.reputation.report(days=days, limit=limit)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, payload)
                return
            if path.startswith("/api/v1/reputation/"):
                parts = path.split("/")
                if len(parts) < 6:
                    self._send(HTTPStatus.BAD_REQUEST, {"error": "chain_and_address_required"})
                    return
                chain, address = parts[-2], parts[-1]
                with self.server.db_lock:  # type: ignore[attr-defined]
                    payload = self.server.reputation.profile(chain, address)  # type: ignore[attr-defined]
                if not payload:
                    self._send(HTTPStatus.NOT_FOUND, {"error": "reputation_not_found"})
                    return
                self._send(HTTPStatus.OK, payload)
                return
            if path == "/api/v1/onchain":
                days = min(_int_arg(query, "days", 30, 1, 3650), performance_days_cap)
                limit = min(_int_arg(query, "limit", 100, 1, 1000), signal_limit_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    payload = self.server.onchain.report(days=days, limit=limit)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, payload)
                return
            if path == "/api/v1/onchain-wallets":
                # Compatibility alias: V14 canonical reputation replaces the
                # provisional V13.5 wallet score cache.
                limit = _int_arg(query, "limit", 100, 1, 1000)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    payload = self.server.reputation.report(days=3650, limit=limit)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, {"wallet_profiles": payload.get("highest_risk", []), "source": "v14-reputation-evidence"})
                return
            if path.startswith("/api/v1/onchain/"):
                try:
                    signal_id = int(path.rsplit("/", 1)[-1])
                except ValueError:
                    self._send(HTTPStatus.BAD_REQUEST, {"error": "invalid_signal_id"})
                    return
                with self.server.db_lock:  # type: ignore[attr-defined]
                    snapshots = [dict(x) for x in self.server.storage.conn.execute(  # type: ignore[attr-defined]
                        "SELECT * FROM onchain_snapshots WHERE signal_id=? ORDER BY captured_at", (signal_id,)
                    ).fetchall()]
                    events = [dict(x) for x in self.server.storage.conn.execute(  # type: ignore[attr-defined]
                        "SELECT * FROM onchain_events WHERE signal_id=? ORDER BY occurred_at", (signal_id,)
                    ).fetchall()]
                self._send(HTTPStatus.OK, {"signal_id": signal_id, "snapshots": snapshots, "events": events})
                return
            if path == "/api/v1/proofs":
                days = min(_int_arg(query, "days", 30, 1, 3650), performance_days_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    payload = self.server.proofs.public_dataset(days=days)  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, payload)
                return
            if path.startswith("/api/v1/proofs/"):
                proof_id = path.rsplit("/", 1)[-1].strip()
                with self.server.db_lock:  # type: ignore[attr-defined]
                    row = self.server.storage.conn.execute(  # type: ignore[attr-defined]
                        "SELECT signal_id FROM proof_events WHERE proof_id=? AND event_type='signal' LIMIT 1",
                        (proof_id,),
                    ).fetchone()
                    result = self.server.proofs.verify_signal(int(row["signal_id"])) if row else None  # type: ignore[attr-defined]
                    proof = self.server.proofs.proof_for_signal(int(row["signal_id"])) if row else None  # type: ignore[attr-defined]
                if not row or not proof:
                    self._send(HTTPStatus.NOT_FOUND, {"error": "proof_not_found"})
                    return
                self._send(HTTPStatus.OK, {"verification": result, "proof": proof})
                return
            if path == "/api/v1/proof-roots":
                with self.server.db_lock:  # type: ignore[attr-defined]
                    roots = [dict(x) for x in self.server.storage.conn.execute("SELECT * FROM proof_daily_roots ORDER BY proof_date DESC LIMIT 365").fetchall()]  # type: ignore[attr-defined]
                    anchors = [dict(x) for x in self.server.storage.conn.execute("SELECT * FROM proof_anchors ORDER BY id DESC LIMIT 365").fetchall()]  # type: ignore[attr-defined]
                self._send(HTTPStatus.OK, {"roots": roots, "anchors": anchors})
                return
            if path == "/api/v1/signals":
                days = min(_int_arg(query, "days", 30, 1, 3650), signal_days_cap)
                limit = min(_int_arg(query, "limit", 100, 1, 1000), signal_limit_cap)
                with self.server.db_lock:  # type: ignore[attr-defined]
                    rows = self.server.ledger.signals(days=days, limit=limit)  # type: ignore[attr-defined]
                safe = []
                for row in rows:
                    safe.append({
                        key: row.get(key) for key in (
                            "id", "chain", "address", "symbol", "name", "entry_price", "final_score",
                            "goplus_score", "goplus_risk", "liquidity", "volume24h", "marketcap",
                            "source", "max_return_pct", "max_drawdown_pct", "last_return_pct",
                            "first_tp1_at", "first_tp2_at", "first_stop_at", "observations", "status", "created_at",
                        )
                    })
                self._send(HTTPStatus.OK, {"items": safe, "count": len(safe)})
                return
            if path.startswith("/api/v1/signals/"):
                try:
                    signal_id = int(path.rsplit("/", 1)[-1])
                except ValueError:
                    self._send(HTTPStatus.BAD_REQUEST, {"error": "invalid_signal_id"})
                    return
                with self.server.db_lock:  # type: ignore[attr-defined]
                    row = self.server.storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (signal_id,)).fetchone()  # type: ignore[attr-defined]
                    observations = self.server.storage.conn.execute(  # type: ignore[attr-defined]
                        "SELECT captured_at,age_seconds,price,return_pct,liquidity,volume24h,marketcap,source FROM signal_observations WHERE signal_id=? ORDER BY id",
                        (signal_id,),
                    ).fetchall()
                    onchain = self.server.storage.conn.execute(  # type: ignore[attr-defined]
                        "SELECT * FROM onchain_snapshots WHERE signal_id=? ORDER BY captured_at DESC LIMIT 1",
                        (signal_id,),
                    ).fetchone()
                if not row:
                    self._send(HTTPStatus.NOT_FOUND, {"error": "signal_not_found"})
                    return
                self._send(HTTPStatus.OK, {"signal": dict(row), "observations": [dict(x) for x in observations], "onchain": dict(onchain) if onchain else None})
                return
            if path.startswith("/api/v1/security/"):
                parts = path.split("/")
                if len(parts) < 6:
                    self._send(HTTPStatus.BAD_REQUEST, {"error": "expected_chain_and_address"})
                    return
                chain, address = parts[-2], parts[-1]
                with self.server.db_lock:  # type: ignore[attr-defined]
                    row = self.server.storage.conn.execute(  # type: ignore[attr-defined]
                        """SELECT chain,address,goplus_score,goplus_risk,goplus_buy_tax_pct,goplus_sell_tax_pct,
                           goplus_top10_holders_pct,created_at FROM signal_ledger
                           WHERE lower(chain)=lower(?) AND lower(address)=lower(?) ORDER BY id DESC LIMIT 1""",
                        (chain, address),
                    ).fetchone()
                if not row:
                    self._send(HTTPStatus.NOT_FOUND, {"error": "security_snapshot_not_found"})
                    return
                self._send(HTTPStatus.OK, dict(row))
                return
            self._send(HTTPStatus.NOT_FOUND, {"error": "not_found"})
        except Exception as exc:
            self._send(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "internal_error", "type": type(exc).__name__})

    def log_message(self, fmt: str, *args) -> None:
        # Never echo headers/API keys. Query strings are intentionally excluded.
        message = fmt % args
        path = urlparse(self.path).path
        print(f"[saas-api] {self.client_address[0]} {path} {message}", flush=True)


def serve_saas_api(host: str | None = None, port: int | None = None) -> None:
    host = host or settings.saas_api_host
    port = int(port or settings.saas_api_port)
    storage = Storage()
    server = ThreadingHTTPServer((host, port), SaaSAPIHandler)
    server.storage = storage  # type: ignore[attr-defined]
    server.saas = SaaSManager(storage)  # type: ignore[attr-defined]
    server.entitlements = EntitlementManager(storage)  # type: ignore[attr-defined]
    server.ledger = PerformanceLedger(storage)  # type: ignore[attr-defined]
    server.proofs = ProofLedger(storage)  # type: ignore[attr-defined]
    server.onchain = OnChainLedger(storage)  # type: ignore[attr-defined]
    server.reputation = ReputationEngine(storage)  # type: ignore[attr-defined]
    server.observability = ObservabilityEngine(storage)  # type: ignore[attr-defined]
    server.distribution = DistributionManager(storage)  # type: ignore[attr-defined]
    server.db_lock = threading.RLock()  # type: ignore[attr-defined]
    print(f"🌐 CSM SaaS API v16.0: http://{host}:{port} | /healthz | /portal", flush=True)
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
        storage.close()
