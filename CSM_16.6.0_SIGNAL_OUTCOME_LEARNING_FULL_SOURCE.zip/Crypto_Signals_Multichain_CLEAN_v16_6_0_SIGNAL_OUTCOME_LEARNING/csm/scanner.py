from __future__ import annotations

import os
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

from .config import settings
from .formatting import score_market
from .experience import opportunity_profile
from .http_client import HTTPTransientError, SafeHTTP
from .provider_manager import ProviderManager
from .logging_setup import logger
from .market import MarketClient

CHAIN_MAP = {
    "solana": "solana", "eth": "ethereum", "ethereum": "ethereum",
    "bsc": "bsc", "binance-smart-chain": "bsc", "base": "base",
    "arbitrum": "arbitrum", "polygon_pos": "polygon", "polygon": "polygon",
    "avax": "avalanche", "avalanche": "avalanche", "optimism": "optimism",
    "fantom": "fantom", "cronos": "cronos",
}

@dataclass(frozen=True)
class DiscoverySource:
    name: str
    url: str
    parser: Callable[[Any], list[tuple[str, str]]]
    priority: int = 100


def _dex_rows(payload: Any) -> list[tuple[str, str]]:
    rows = payload if isinstance(payload, list) else []
    out=[]
    for row in rows:
        if not isinstance(row, dict): continue
        chain=CHAIN_MAP.get(str(row.get("chainId") or "").lower())
        address=str(row.get("tokenAddress") or "").strip()
        if chain and address: out.append((chain,address))
    return out


def _gecko_rows(payload: Any) -> list[tuple[str, str]]:
    out=[]
    for item in (payload.get("data", []) if isinstance(payload, dict) else []):
        if not isinstance(item, dict): continue
        attrs=item.get("attributes") or {}
        rel=item.get("relationships") or {}
        network=str(attrs.get("network") or item.get("id", "").split("_")[0]).lower()
        chain=CHAIN_MAP.get(network)
        token=((rel.get("base_token") or {}).get("data") or {}).get("id", "")
        address=str(token).split("_",1)[-1].strip()
        if chain and address: out.append((chain,address))
    return out

SOURCES=(
    DiscoverySource("GeckoTerminal trending", "https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?include=base_token", _gecko_rows, 10),
    DiscoverySource("GeckoTerminal novos", "https://api.geckoterminal.com/api/v2/networks/solana/new_pools?include=base_token", _gecko_rows, 20),
    DiscoverySource("DexScreener perfis", "https://api.dexscreener.com/token-profiles/latest/v1", _dex_rows, 30),
    DiscoverySource("DexScreener boosts", "https://api.dexscreener.com/token-boosts/top/v1", _dex_rows, 40),
)

def _is_mobile_runtime() -> bool:
    """Detecta a-Shell/iOS de forma defensiva.

    Algumas builds do a-Shell não reportam ``sys.platform`` como ``darwin``.
    Por isso usamos também os caminhos típicos dos containers iOS e variáveis
    do ambiente. Falso positivo aqui apenas reduz paralelismo; falso negativo
    pode causar falha nativa em SSL/threading.
    """
    parts = [
        sys.platform,
        sys.executable or "",
        str(Path(sys.executable).resolve()) if sys.executable else "",
        os.getcwd(),
        os.getenv("HOME", ""),
        os.getenv("APPDIR", ""),
    ]
    text = " ".join(parts).lower()
    markers = (
        "a-shell", "ashell", "/private/var/mobile/containers/",
        "/var/mobile/containers/", "/bundle/application/",
    )
    return sys.platform in {"ios", "darwin"} or any(marker in text for marker in markers)


class MultichainScanner:
    def __init__(self, market: MarketClient|None=None, http: SafeHTTP|None=None):
        self.market=market or MarketClient(); self.http=http or SafeHTTP(settings.request_timeout)
        self._lock=threading.RLock(); self._discovery_cache=None; self._scan_cache={}
        self.providers = ProviderManager(cache_ttl=30, max_backoff=900)
        self.last_stats={"discovered":0,"analyzed":0,"approved":0,"rejected":0,"errors":0,"sources_ok":0,"sources_failed":0}

    @staticmethod
    def _normalize_chains(chains):
        configured=tuple(settings.scan_chains)
        if not chains: return configured
        req={str(x).strip().lower() for x in chains if str(x).strip()}
        return tuple(x for x in configured if x in req)

    def discover(self, limit=None, *, chains=None, force=False):
        target=min(max(limit or settings.scan_limit,10),settings.scan_max_candidates)
        allowed=set(self._normalize_chains(chains)); now=time.time()
        with self._lock:
            if not force and self._discovery_cache and now-self._discovery_cache[0]<=settings.scan_discovery_ttl:
                return [x for x in self._discovery_cache[1] if x[0] in allowed][:target]
        found=[]; seen=set(); ok=failed=0
        for source in sorted(SOURCES, key=lambda item: item.priority):
            result = self.providers.fetch(
                source.name,
                lambda source=source: self.http.get_json(source.url),
                force=force,
                priority=source.priority,
            )
            if result is None:
                failed += 1
                continue
            try:
                rows=source.parser(result.payload); ok+=1
                for chain,address in rows:
                    key=(chain,address)
                    if chain in allowed and address and key not in seen:
                        seen.add(key); found.append(key)
                        if len(found)>=settings.scan_max_candidates: break
            except Exception as exc:
                failed += 1
                logger.warning("Resposta inválida do provider %s (%s)", source.name, type(exc).__name__)
        with self._lock:
            if found: self._discovery_cache=(now,list(found))
            elif self._discovery_cache: found=list(self._discovery_cache[1])
        self.last_stats["sources_ok"]=ok; self.last_stats["sources_failed"]=failed
        self.last_stats["providers"] = self.providers.snapshot()
        try:
            from .provider_health import save_provider_health
            save_provider_health(self.last_stats["providers"])
        except Exception as exc:
            logger.debug("Não foi possível persistir saúde dos providers: %s", exc)
        return [x for x in found if x[0] in allowed][:target]

    @staticmethod
    def _passes_filters(m):
        liq=float(m.get("liquidity") or 0); vol=float(m.get("volume24h") or 0); cap=float(m.get("marketcap") or 0)
        age=m.get("age_days"); change=float(m.get("change24h") or 0); buys=int(m.get("buys24h") or 0); sells=int(m.get("sells24h") or 0)
        if liq<settings.scan_min_liquidity or (settings.scan_max_liquidity and liq>settings.scan_max_liquidity): return False
        if vol<settings.scan_min_volume24h or (settings.scan_max_volume24h and vol>settings.scan_max_volume24h): return False
        if settings.scan_min_marketcap and cap<settings.scan_min_marketcap: return False
        if settings.scan_max_marketcap and cap>settings.scan_max_marketcap: return False
        if age is not None:
            age_value = float(age)
            if age_value < settings.scan_min_age_days: return False
            if settings.scan_max_age_days and age_value > settings.scan_max_age_days: return False
        if change < settings.scan_min_change24h: return False
        if settings.scan_max_change24h and change > settings.scan_max_change24h: return False
        if buys+sells<settings.scan_min_txns24h: return False
        if sells>0 and buys/sells<settings.scan_min_buy_sell_ratio: return False
        return True

    def scan(self, limit=None, *, chains=None, force=False):
        target=min(max(limit or settings.scan_limit,10),settings.scan_max_candidates); normalized=self._normalize_chains(chains)
        key=(target,normalized); now=time.time()
        with self._lock:
            cached=self._scan_cache.get(key)
            if not force and cached and now-cached[0]<=settings.scan_cache_ttl:
                self.last_stats=dict(cached[2]); return [dict(x,scanner_cached=True) for x in cached[1]]
        candidates=self.discover(target,chains=normalized,force=force); source_stats={k:self.last_stats.get(k,0) for k in ("sources_ok","sources_failed")}
        results=[]; stats={"discovered":len(candidates),"analyzed":0,"approved":0,"rejected":0,"errors":0,**source_stats}
        if candidates:
            stats["mode"] = "sequential-mobile" if _is_mobile_runtime() else "sequential-v8-safe"

            def consume_market(market):
                stats["analyzed"] += 1
                if not self._passes_filters(market):
                    stats["rejected"] += 1
                    return
                market = dict(market)
                market["score"] = score_market(market)
                market.update(opportunity_profile(market))
                market["scanner_cached"] = False
                results.append(market)
                stats["approved"] += 1

            delay_ms = max(0, int(settings.scan_mobile_delay_ms or 0))
            for index, (chain, address) in enumerate(candidates):
                try:
                    consume_market(self.market.fetch(chain, address, force))
                except Exception as exc:
                    stats["errors"] += 1
                    logger.debug("Falha no candidato %s/%s: %s", chain, address, exc)
                if delay_ms and index + 1 < len(candidates):
                    time.sleep(delay_ms / 1000.0)
        results.sort(key=lambda x:(float(x.get("opportunity_score") or x.get("score") or 0),float(x.get("volume24h") or 0),float(x.get("liquidity") or 0)),reverse=True)
        results=results[:settings.scan_result_limit]; self.last_stats=stats
        with self._lock: self._scan_cache[key]=(now,[dict(x) for x in results],dict(stats))
        return results
