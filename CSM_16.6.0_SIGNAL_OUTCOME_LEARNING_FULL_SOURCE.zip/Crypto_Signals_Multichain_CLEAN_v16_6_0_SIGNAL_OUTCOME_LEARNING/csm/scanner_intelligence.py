from __future__ import annotations

import json
import sqlite3
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any


REASON_LABELS = {
    "liquidity_below_min": "liquidez abaixo do mínimo",
    "liquidity_above_max": "liquidez acima do máximo",
    "volume_below_min": "volume 24h abaixo do mínimo",
    "volume_above_max": "volume 24h acima do máximo",
    "marketcap_below_min": "market cap abaixo do mínimo",
    "marketcap_above_max": "market cap acima do máximo",
    "age_below_min": "idade abaixo do mínimo",
    "age_above_max": "idade acima do máximo",
    "change_below_min": "variação 24h abaixo do mínimo",
    "change_above_max": "variação 24h acima do máximo",
    "txns_below_min": "transações 24h abaixo do mínimo",
    "buy_sell_ratio_below_min": "pressão compradora abaixo do mínimo",
    "goplus_unavailable": "GoPlus indisponível em modo fail-closed",
    "goplus_no_data": "GoPlus sem dados em modo fail-closed",
    "goplus_critical_risk": "risco crítico no GoPlus",
    "goplus_score_below_min": "score GoPlus abaixo do mínimo",
    "market_unavailable": "mercado indisponível nos providers de preço",
    "normalization_error": "erro de normalização de mercado",
    "unknown": "motivo não classificado",
}


def reason_label(reason: str) -> str:
    key = str(reason or "unknown").strip() or "unknown"
    return REASON_LABELS.get(key, key.replace("_", " "))


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS scanner_intelligence_cycles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cycle_key TEXT NOT NULL UNIQUE,
            discovery_tier TEXT DEFAULT '',
            discovered INTEGER DEFAULT 0,
            analyzed INTEGER DEFAULT 0,
            approved INTEGER DEFAULT 0,
            rejected INTEGER DEFAULT 0,
            market_unavailable INTEGER DEFAULT 0,
            errors INTEGER DEFAULT 0,
            security_blocked INTEGER DEFAULT 0,
            decisions_recorded INTEGER DEFAULT 0,
            decisions_truncated INTEGER DEFAULT 0,
            rejection_reasons_json TEXT DEFAULT '{}',
            chain_stats_json TEXT DEFAULT '{}',
            providers_json TEXT DEFAULT '[]',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_scanner_intelligence_cycles_created
        ON scanner_intelligence_cycles(created_at DESC);

        CREATE TABLE IF NOT EXISTS scanner_decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cycle_key TEXT NOT NULL,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            symbol TEXT DEFAULT '',
            name TEXT DEFAULT '',
            decision TEXT NOT NULL,
            reason TEXT DEFAULT '',
            analytic_score INTEGER DEFAULT 0,
            final_score INTEGER DEFAULT 0,
            liquidity REAL DEFAULT 0,
            volume24h REAL DEFAULT 0,
            marketcap REAL DEFAULT 0,
            change24h REAL DEFAULT 0,
            buys24h INTEGER DEFAULT 0,
            sells24h INTEGER DEFAULT 0,
            source TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_scanner_decisions_created
        ON scanner_decisions(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_scanner_decisions_chain_created
        ON scanner_decisions(chain, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_scanner_decisions_reason_created
        ON scanner_decisions(reason, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_scanner_decisions_cycle
        ON scanner_decisions(cycle_key);
        """
    )
    conn.commit()


def _safe_json(value: Any, fallback: Any) -> Any:
    if value in (None, ""):
        return fallback
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return fallback


def _float(value: Any) -> float:
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


class ScannerIntelligenceStore:
    """Persist scanner decisions without changing scanner gates.

    This layer records evidence only. It never changes thresholds, scores,
    provider ordering, user plans, or delivery rules.
    """

    def __init__(self, storage_or_conn: Any):
        self.conn: sqlite3.Connection = getattr(storage_or_conn, "conn", storage_or_conn)
        ensure_schema(self.conn)

    def capture_cycle(self, stats: dict[str, Any]) -> dict[str, int]:
        from csm.config import settings

        if not bool(getattr(settings, "scanner_intelligence_enabled", True)):
            return {"cycles": 0, "decisions": 0, "pruned": 0}
        cycle_key = str(stats.get("cycle_key") or "").strip()
        if not cycle_key:
            cycle_key = datetime.now(timezone.utc).strftime("legacy-%Y%m%dT%H%M%S%f")
        decisions = [dict(row) for row in (stats.get("decisions") or []) if isinstance(row, dict)]
        per_cycle = max(10, int(getattr(settings, "scanner_intelligence_max_decisions_per_cycle", 1000)))
        truncated = max(0, len(decisions) - per_cycle) + _int(stats.get("decisions_truncated"))
        decisions = decisions[:per_cycle]
        self.conn.execute(
            """INSERT INTO scanner_intelligence_cycles(
                   cycle_key,discovery_tier,discovered,analyzed,approved,rejected,market_unavailable,
                   errors,security_blocked,decisions_recorded,decisions_truncated,rejection_reasons_json,
                   chain_stats_json,providers_json
               ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(cycle_key) DO UPDATE SET
                   discovery_tier=excluded.discovery_tier,discovered=excluded.discovered,
                   analyzed=excluded.analyzed,approved=excluded.approved,rejected=excluded.rejected,
                   market_unavailable=excluded.market_unavailable,errors=excluded.errors,
                   security_blocked=excluded.security_blocked,decisions_recorded=excluded.decisions_recorded,
                   decisions_truncated=excluded.decisions_truncated,rejection_reasons_json=excluded.rejection_reasons_json,
                   chain_stats_json=excluded.chain_stats_json,providers_json=excluded.providers_json""",
            (
                cycle_key,
                str(stats.get("discovery_tier") or "")[:20],
                _int(stats.get("discovered")),
                _int(stats.get("analyzed")),
                _int(stats.get("approved")),
                _int(stats.get("rejected")),
                _int(stats.get("market_unavailable")),
                _int(stats.get("errors")),
                _int(stats.get("security_blocked")),
                len(decisions),
                truncated,
                json.dumps(stats.get("rejection_reasons") or {}, ensure_ascii=False, sort_keys=True),
                json.dumps(stats.get("chain_stats") or {}, ensure_ascii=False, sort_keys=True),
                json.dumps(stats.get("providers_used") or [], ensure_ascii=False),
            ),
        )
        # Idempotent if capture is retried after a late exception.
        self.conn.execute("DELETE FROM scanner_decisions WHERE cycle_key=?", (cycle_key,))
        if decisions:
            self.conn.executemany(
                """INSERT INTO scanner_decisions(
                       cycle_key,chain,address,symbol,name,decision,reason,analytic_score,final_score,
                       liquidity,volume24h,marketcap,change24h,buys24h,sells24h,source
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [
                    (
                        cycle_key,
                        str(row.get("chain") or "unknown")[:40].lower(),
                        str(row.get("address") or "")[:180],
                        str(row.get("symbol") or "")[:80],
                        str(row.get("name") or "")[:160],
                        str(row.get("decision") or "UNKNOWN")[:24].upper(),
                        str(row.get("reason") or "")[:80],
                        _int(row.get("analytic_score")),
                        _int(row.get("final_score")),
                        _float(row.get("liquidity")),
                        _float(row.get("volume24h")),
                        _float(row.get("marketcap")),
                        _float(row.get("change24h")),
                        _int(row.get("buys24h")),
                        _int(row.get("sells24h")),
                        str(row.get("source") or "")[:100],
                    )
                    for row in decisions
                ],
            )
        self.conn.commit()
        pruned = self.prune()
        return {"cycles": 1, "decisions": len(decisions), "pruned": pruned}

    def prune(self) -> int:
        from csm.config import settings

        retention = max(1, int(getattr(settings, "scanner_intelligence_retention_days", 14)))
        max_rows = max(1000, int(getattr(settings, "scanner_intelligence_max_decisions", 10000)))
        removed = 0
        cur = self.conn.execute(
            "DELETE FROM scanner_decisions WHERE datetime(created_at) < datetime('now', ?)",
            (f"-{retention} days",),
        )
        removed += int(cur.rowcount or 0)
        cur = self.conn.execute(
            """DELETE FROM scanner_decisions WHERE id IN (
                   SELECT id FROM scanner_decisions ORDER BY id DESC LIMIT -1 OFFSET ?
               )""",
            (max_rows,),
        )
        removed += int(cur.rowcount or 0)
        self.conn.execute(
            "DELETE FROM scanner_intelligence_cycles WHERE datetime(created_at) < datetime('now', ?)",
            (f"-{retention} days",),
        )
        self.conn.commit()
        return removed


def scanner_funnel(conn: sqlite3.Connection, hours: int = 24, chain: str = "") -> dict[str, Any]:
    hours = max(1, min(int(hours or 24), 24 * 30))
    chain = str(chain or "").strip().lower()
    cutoff = f"-{hours} hours"

    cycle = conn.execute(
        """SELECT COUNT(*) cycles,COALESCE(SUM(discovered),0) discovered,
                  COALESCE(SUM(analyzed),0) analyzed,COALESCE(SUM(approved),0) approved,
                  COALESCE(SUM(rejected),0) rejected,COALESCE(SUM(market_unavailable),0) market_unavailable,
                  COALESCE(SUM(errors),0) errors,COALESCE(SUM(decisions_recorded),0) decisions_recorded,
                  COALESCE(SUM(decisions_truncated),0) decisions_truncated,MAX(created_at) last_cycle_at
           FROM scanner_intelligence_cycles WHERE datetime(created_at)>=datetime('now',?)""",
        (cutoff,),
    ).fetchone()
    base = dict(cycle) if cycle else {}

    where = "datetime(created_at)>=datetime('now',?)"
    params: list[Any] = [cutoff]
    if chain:
        where += " AND lower(chain)=?"
        params.append(chain)

    dec = conn.execute(
        f"""SELECT COUNT(*) total,
                   COALESCE(SUM(CASE WHEN decision='APPROVED' THEN 1 ELSE 0 END),0) approved,
                   COALESCE(SUM(CASE WHEN decision='REJECTED' THEN 1 ELSE 0 END),0) rejected,
                   COALESCE(SUM(CASE WHEN decision='UNAVAILABLE' THEN 1 ELSE 0 END),0) unavailable
            FROM scanner_decisions WHERE {where}""",
        tuple(params),
    ).fetchone()
    decision_totals = dict(dec) if dec else {"total": 0, "approved": 0, "rejected": 0, "unavailable": 0}
    if chain:
        # For a chain query, decision rows are the authoritative analyzed set.
        base["analyzed"] = _int(decision_totals.get("approved")) + _int(decision_totals.get("rejected"))
        base["approved"] = _int(decision_totals.get("approved"))
        base["rejected"] = _int(decision_totals.get("rejected"))
        base["market_unavailable"] = _int(decision_totals.get("unavailable"))

    reason_rows = conn.execute(
        f"""SELECT reason,COUNT(*) count FROM scanner_decisions
            WHERE {where} AND decision='REJECTED'
            GROUP BY reason ORDER BY count DESC,reason LIMIT 20""",
        tuple(params),
    ).fetchall()
    total_rejected = sum(_int(r["count"]) for r in reason_rows)
    reasons = [
        {
            "reason": str(r["reason"] or "unknown"),
            "label": reason_label(str(r["reason"] or "unknown")),
            "count": _int(r["count"]),
            "pct": round((_int(r["count"]) / total_rejected * 100.0), 1) if total_rejected else 0.0,
        }
        for r in reason_rows
    ]

    network_rows = conn.execute(
        """SELECT chain,COUNT(*) total,
                  SUM(CASE WHEN decision='APPROVED' THEN 1 ELSE 0 END) approved,
                  SUM(CASE WHEN decision='REJECTED' THEN 1 ELSE 0 END) rejected,
                  SUM(CASE WHEN decision='UNAVAILABLE' THEN 1 ELSE 0 END) unavailable
           FROM scanner_decisions WHERE datetime(created_at)>=datetime('now',?)
           GROUP BY chain ORDER BY total DESC,chain""",
        (cutoff,),
    ).fetchall()
    networks = []
    for row in network_rows:
        analyzed = _int(row["approved"]) + _int(row["rejected"])
        top_reason_row = conn.execute(
            """SELECT reason,COUNT(*) count FROM scanner_decisions
               WHERE datetime(created_at)>=datetime('now',?) AND lower(chain)=lower(?) AND decision='REJECTED'
               GROUP BY reason ORDER BY count DESC,reason LIMIT 1""",
            (cutoff, str(row["chain"])),
        ).fetchone()
        top_reason = str(top_reason_row["reason"] or "") if top_reason_row else ""
        networks.append(
            {
                "chain": str(row["chain"] or "unknown"),
                "analyzed": analyzed,
                "approved": _int(row["approved"]),
                "rejected": _int(row["rejected"]),
                "unavailable": _int(row["unavailable"]),
                "approval_rate_pct": round(_int(row["approved"]) / analyzed * 100.0, 2) if analyzed else 0.0,
                "top_rejection_reason": top_reason,
                "top_rejection_label": reason_label(top_reason) if top_reason else "",
            }
        )

    analyzed = _int(base.get("analyzed"))
    approved = _int(base.get("approved"))
    base.update(
        {
            "hours": hours,
            "chain": chain,
            "approval_rate_pct": round(approved / analyzed * 100.0, 2) if analyzed else 0.0,
            "rejection_reasons": reasons,
            "networks": networks,
            "decision_totals": decision_totals,
            "reason_labels_version": 1,
        }
    )
    return base


def compare_approved_rejected(conn: sqlite3.Connection, hours: int = 24, chain: str = "") -> dict[str, Any]:
    hours = max(1, min(int(hours or 24), 24 * 30))
    chain = str(chain or "").strip().lower()
    where = "datetime(created_at)>=datetime('now',?) AND decision IN ('APPROVED','REJECTED')"
    params: list[Any] = [f"-{hours} hours"]
    if chain:
        where += " AND lower(chain)=?"
        params.append(chain)
    rows = conn.execute(
        f"""SELECT decision,COUNT(*) samples,
                   AVG(analytic_score) avg_analytic_score,AVG(liquidity) avg_liquidity,
                   AVG(volume24h) avg_volume24h,AVG(marketcap) avg_marketcap,
                   AVG(change24h) avg_change24h,
                   AVG(CASE WHEN buys24h+sells24h>0 THEN (100.0*buys24h)/(buys24h+sells24h) END) avg_buy_pressure_pct
            FROM scanner_decisions WHERE {where} GROUP BY decision""",
        tuple(params),
    ).fetchall()
    data = {str(r["decision"]).lower(): dict(r) for r in rows}
    return {"hours": hours, "chain": chain, "approved": data.get("approved", {}), "rejected": data.get("rejected", {})}


def recent_decisions(conn: sqlite3.Connection, *, hours: int = 24, chain: str = "", decision: str = "", limit: int = 50) -> list[dict[str, Any]]:
    hours = max(1, min(int(hours or 24), 24 * 30))
    chain = str(chain or "").strip().lower()
    decision = str(decision or "").strip().upper()
    where = ["datetime(created_at)>=datetime('now',?)"]
    params: list[Any] = [f"-{hours} hours"]
    if chain:
        where.append("lower(chain)=?")
        params.append(chain)
    if decision in {"APPROVED", "REJECTED", "UNAVAILABLE"}:
        where.append("decision=?")
        params.append(decision)
    params.append(max(1, min(int(limit or 50), 200)))
    rows = conn.execute(
        f"""SELECT chain,address,symbol,name,decision,reason,analytic_score,final_score,
                   liquidity,volume24h,marketcap,change24h,buys24h,sells24h,source,created_at
            FROM scanner_decisions WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT ?""",
        tuple(params),
    ).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["reason_label"] = reason_label(str(item.get("reason") or "")) if item.get("reason") else ""
        result.append(item)
    return result


def provider_rejection_diagnostics(conn: sqlite3.Connection, *, hours: int = 24, chain: str = "") -> dict[str, Any]:
    """Evidence-only rejection breakdown by network and market-data provider."""
    hours = max(1, min(int(hours or 24), 24 * 30))
    chain = str(chain or "").strip().lower()
    where = ["datetime(created_at)>=datetime('now',?)", "decision='REJECTED'"]
    params: list[Any] = [f"-{hours} hours"]
    if chain:
        where.append("lower(chain)=?")
        params.append(chain)
    rows = conn.execute(
        f"""SELECT lower(chain) chain,COALESCE(NULLIF(source,''),'unknown') source,reason,COUNT(*) count,
                   AVG(liquidity) avg_liquidity,AVG(volume24h) avg_volume24h,AVG(analytic_score) avg_score
            FROM scanner_decisions WHERE {' AND '.join(where)}
            GROUP BY lower(chain),COALESCE(NULLIF(source,''),'unknown'),reason
            ORDER BY count DESC,chain,source LIMIT 200""",
        tuple(params),
    ).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["reason_label"] = reason_label(str(item.get("reason") or "unknown"))
        item["count"] = _int(item.get("count"))
        items.append(item)
    provider_rows = conn.execute(
        f"""SELECT COALESCE(NULLIF(source,''),'unknown') source,COUNT(*) total,
                   SUM(CASE WHEN decision='APPROVED' THEN 1 ELSE 0 END) approved,
                   SUM(CASE WHEN decision='REJECTED' THEN 1 ELSE 0 END) rejected,
                   SUM(CASE WHEN decision='UNAVAILABLE' THEN 1 ELSE 0 END) unavailable
            FROM scanner_decisions WHERE datetime(created_at)>=datetime('now',?)
            {('AND lower(chain)=?' if chain else '')}
            GROUP BY COALESCE(NULLIF(source,''),'unknown') ORDER BY total DESC""",
        tuple([f"-{hours} hours"] + ([chain] if chain else [])),
    ).fetchall()
    providers = []
    for row in provider_rows:
        item = dict(row)
        analyzed = _int(item.get("approved")) + _int(item.get("rejected"))
        item["approval_rate_pct"] = round(_int(item.get("approved")) / analyzed * 100.0, 2) if analyzed else 0.0
        providers.append(item)
    return {"hours": hours, "chain": chain, "items": items, "providers": providers}
