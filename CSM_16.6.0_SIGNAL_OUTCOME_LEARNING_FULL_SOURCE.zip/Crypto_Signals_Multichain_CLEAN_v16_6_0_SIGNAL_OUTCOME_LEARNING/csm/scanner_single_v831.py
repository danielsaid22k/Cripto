from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from .ashell_runtime_v831 import is_ashell_runtime
from .config import settings
from .curl_http_v831 import MarketHTTPV831
from .experience import opportunity_profile
from .formatting import score_market
from .logging_setup import logger
from .market_single_v831 import SingleRuntimeMarketV831
from .provider_manager import ProviderManager

CHAIN_MAP = {
    "solana": "solana", "eth": "ethereum", "ethereum": "ethereum", "bsc": "bsc",
    "binance-smart-chain": "bsc", "base": "base", "arbitrum": "arbitrum",
    "polygon_pos": "polygon", "polygon": "polygon", "avax": "avalanche",
    "avalanche": "avalanche", "optimism": "optimism", "fantom": "fantom", "cronos": "cronos",
}


@dataclass(frozen=True)
class DiscoverySourceV831:
    name: str
    url: str
    parser: Callable[[Any], list[tuple[str, str]]]
    priority: int


@dataclass(frozen=True)
class ScanCompletionV831:
    results: list[dict[str, Any]]
    stats: dict[str, Any]
    ok: bool


def _dex_rows(payload: Any) -> list[tuple[str, str]]:
    rows = payload if isinstance(payload, list) else []
    out: list[tuple[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        chain = CHAIN_MAP.get(str(row.get("chainId") or "").lower())
        address = str(row.get("tokenAddress") or "").strip()
        if chain and address:
            out.append((chain, address))
    return out


def _gecko_rows(payload: Any) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    for item in (payload.get("data", []) if isinstance(payload, dict) else []):
        if not isinstance(item, dict):
            continue
        attrs = item.get("attributes") or {}; rel = item.get("relationships") or {}
        network = str(attrs.get("network") or item.get("id", "").split("_")[0]).lower()
        chain = CHAIN_MAP.get(network)
        token = ((rel.get("base_token") or {}).get("data") or {}).get("id", "")
        address = str(token).split("_", 1)[-1].strip()
        if chain and address:
            out.append((chain, address))
    return out


SOURCES_V831 = (
    DiscoverySourceV831("GeckoTerminal trending", "https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?include=base_token", _gecko_rows, 10),
    DiscoverySourceV831("GeckoTerminal novos", "https://api.geckoterminal.com/api/v2/networks/solana/new_pools?include=base_token", _gecko_rows, 20),
    DiscoverySourceV831("DexScreener perfis", "https://api.dexscreener.com/token-profiles/latest/v1", _dex_rows, 30),
    DiscoverySourceV831("DexScreener boosts", "https://api.dexscreener.com/token-boosts/top/v1", _dex_rows, 40),
)


class SingleRuntimeScannerV831:
    """Scanner cooperativo para o a-Shell usando um único Python.

    Cada chamada de ``poll`` executa no máximo uma unidade de rede (um provider
    de descoberta ou um candidato). Portanto o loop do Telegram volta a receber
    eventos entre as etapas, e nenhum worker Python é criado.
    """

    def __init__(self, market=None, http=None, *, mobile: bool | None = None):
        self.mobile = is_ashell_runtime() if mobile is None else bool(mobile)
        self.http = http or MarketHTTPV831(mobile=self.mobile, timeout=settings.request_timeout)
        self.market = market or SingleRuntimeMarketV831(http=self.http, mobile=self.mobile)
        self.providers = ProviderManager(cache_ttl=30, max_backoff=900)
        self.active = False
        self.phase = "idle"
        self._sources: list[DiscoverySourceV831] = []
        self._source_index = 0
        self._candidates: list[tuple[str, str]] = []
        self._seen: set[tuple[str, str]] = set()
        self._candidate_index = 0
        self._results: list[dict[str, Any]] = []
        self._allowed: set[str] = set()
        self._target = 0
        self._force = True
        self._started = 0.0
        self.last_results: list[dict[str, Any]] = []
        self.last_stats: dict[str, Any] = self._empty_stats()

    @staticmethod
    def _empty_stats() -> dict[str, Any]:
        return {
            "discovered": 0, "analyzed": 0, "approved": 0, "rejected": 0,
            "errors": 0, "sources_ok": 0, "sources_failed": 0,
            "mode": "single-python-cooperative-v831",
        }

    @staticmethod
    def _normalize_chains(chains):
        configured = tuple(settings.scan_chains)
        if not chains:
            return configured
        req = {str(x).strip().lower() for x in chains if str(x).strip()}
        return tuple(x for x in configured if x in req)

    @staticmethod
    def _passes_filters(m: dict[str, Any]) -> bool:
        liq = float(m.get("liquidity") or 0); vol = float(m.get("volume24h") or 0); cap = float(m.get("marketcap") or 0)
        age = m.get("age_days"); change = float(m.get("change24h") or 0); buys = int(m.get("buys24h") or 0); sells = int(m.get("sells24h") or 0)
        if liq < settings.scan_min_liquidity or (settings.scan_max_liquidity and liq > settings.scan_max_liquidity): return False
        if vol < settings.scan_min_volume24h or (settings.scan_max_volume24h and vol > settings.scan_max_volume24h): return False
        if settings.scan_min_marketcap and cap < settings.scan_min_marketcap: return False
        if settings.scan_max_marketcap and cap > settings.scan_max_marketcap: return False
        if age is not None:
            av = float(age)
            if av < settings.scan_min_age_days: return False
            if settings.scan_max_age_days and av > settings.scan_max_age_days: return False
        if change < settings.scan_min_change24h: return False
        if settings.scan_max_change24h and change > settings.scan_max_change24h: return False
        if buys + sells < settings.scan_min_txns24h: return False
        if sells > 0 and buys / sells < settings.scan_min_buy_sell_ratio: return False
        return True

    def start(self, *, limit=None, chains=None, force=True) -> bool:
        if self.active:
            return False
        self._target = min(max(limit or settings.scan_limit, 10), settings.scan_max_candidates)
        self._allowed = set(self._normalize_chains(chains))
        self._sources = list(sorted(SOURCES_V831, key=lambda item: item.priority))
        self._source_index = 0; self._candidate_index = 0
        self._candidates = []; self._seen = set(); self._results = []
        self._force = bool(force); self._started = time.monotonic()
        self.last_stats = self._empty_stats()
        self.phase = "discover"; self.active = True
        return True

    def _discover_step(self) -> None:
        if self._source_index >= len(self._sources) or len(self._candidates) >= self._target:
            self.last_stats["discovered"] = len(self._candidates)
            self.phase = "analyze"
            return
        source = self._sources[self._source_index]; self._source_index += 1
        result = self.providers.fetch(
            source.name,
            lambda source=source: self.http.get_json(source.url),
            force=self._force,
            priority=source.priority,
        )
        if result is None:
            self.last_stats["sources_failed"] += 1
            return
        try:
            rows = source.parser(result.payload)
            self.last_stats["sources_ok"] += 1
            for chain, address in rows:
                key = (chain, address)
                if chain in self._allowed and address and key not in self._seen:
                    self._seen.add(key); self._candidates.append(key)
                    if len(self._candidates) >= self._target:
                        break
        except Exception as exc:
            self.last_stats["sources_failed"] += 1
            logger.warning("Resposta inválida do provider %s (%s)", source.name, type(exc).__name__)

    def _analyze_step(self) -> None:
        if self._candidate_index >= len(self._candidates):
            self.phase = "done"
            return
        chain, address = self._candidates[self._candidate_index]; self._candidate_index += 1
        try:
            market = self.market.fetch(chain, address, force=self._force)
            self.last_stats["analyzed"] += 1
            if not self._passes_filters(market):
                self.last_stats["rejected"] += 1
                return
            item = dict(market); item["score"] = score_market(item); item.update(opportunity_profile(item)); item["scanner_cached"] = False
            self._results.append(item); self.last_stats["approved"] += 1
        except Exception as exc:
            self.last_stats["errors"] += 1
            logger.debug("Falha no candidato %s/%s: %s", chain, address, exc)

    def poll(self) -> ScanCompletionV831 | None:
        if not self.active:
            return None
        if self.phase == "discover":
            self._discover_step()
        elif self.phase == "analyze":
            self._analyze_step()
        if self.phase != "done":
            return None
        self._results.sort(
            key=lambda x: (float(x.get("opportunity_score") or x.get("score") or 0), float(x.get("volume24h") or 0), float(x.get("liquidity") or 0)),
            reverse=True,
        )
        results = self._results[:settings.scan_result_limit]
        self.last_stats["discovered"] = len(self._candidates)
        self.last_stats["elapsed_ms"] = round((time.monotonic() - self._started) * 1000, 2)
        self.last_stats["providers"] = self.providers.snapshot()
        self.last_results = [dict(x) for x in results]
        self.active = False; self.phase = "idle"
        try:
            from .provider_health import save_provider_health
            save_provider_health(self.last_stats["providers"])
        except Exception:
            pass
        return ScanCompletionV831([dict(x) for x in results], dict(self.last_stats), True)

    def scan(self, limit=None, *, chains=None, force=False) -> list[dict[str, Any]]:
        """Compatibilidade com comandos e testes fora do loop Telegram.

        No bot, o ciclo automático usa start/poll. Se já houver ciclo ativo,
        devolve o último resultado em vez de iniciar um segundo trabalho.
        """
        if self.active:
            return [dict(x) for x in self.last_results]
        self.start(limit=limit, chains=chains, force=force)
        completion = None
        while completion is None:
            completion = self.poll()
        return completion.results
