from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
from pathlib import Path

from .config import settings

KEY_FILE = "integrity.key"


def _key_path() -> Path:
    return settings.data_dir / KEY_FILE


def integrity_key() -> bytes:
    path = _key_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_bytes(secrets.token_bytes(32))
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    key = path.read_bytes()
    if len(key) < 32:
        raise RuntimeError("Chave de integridade inválida")
    return key


def sha256_file(path: str | Path) -> str:
    source = Path(path)
    digest = hashlib.sha256()
    with source.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sign_file(path: str | Path) -> dict[str, str]:
    source = Path(path).resolve()
    sha256 = sha256_file(source)
    signature = hmac.new(integrity_key(), sha256.encode("ascii"), hashlib.sha256).hexdigest()
    payload = {"file": source.name, "sha256": sha256, "hmac_sha256": signature}
    sidecar = source.with_suffix(source.suffix + ".integrity.json")
    sidecar.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        os.chmod(sidecar, 0o600)
    except OSError:
        pass
    return payload


def verify_file(path: str | Path, *, require_signature: bool = False) -> dict[str, object]:
    source = Path(path).resolve()
    sidecar = source.with_suffix(source.suffix + ".integrity.json")
    actual = sha256_file(source)
    if not sidecar.exists():
        if require_signature:
            raise RuntimeError(f"Assinatura de integridade ausente: {sidecar.name}")
        return {"ok": True, "signed": False, "sha256": actual}
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    expected_sha = str(payload.get("sha256") or "")
    expected_sig = str(payload.get("hmac_sha256") or "")
    calculated_sig = hmac.new(integrity_key(), actual.encode("ascii"), hashlib.sha256).hexdigest()
    ok = hmac.compare_digest(actual, expected_sha) and hmac.compare_digest(calculated_sig, expected_sig)
    if not ok:
        raise RuntimeError(f"Falha de integridade em {source.name}")
    return {"ok": True, "signed": True, "sha256": actual}
