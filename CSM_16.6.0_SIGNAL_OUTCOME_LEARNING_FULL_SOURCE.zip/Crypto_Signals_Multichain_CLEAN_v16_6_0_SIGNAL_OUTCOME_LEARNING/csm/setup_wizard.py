from __future__ import annotations

import os
import re
from pathlib import Path
from dotenv import dotenv_values

from .credential_audit import secret_fingerprint, update_credential_marker

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"
_raw_state_dir = os.getenv("CSM_STATE_DIR", "").strip()
STATE_DIR = Path(_raw_state_dir).expanduser() if _raw_state_dir else BASE_DIR.parent / "Crypto_Signals_Multichain_State"
if not STATE_DIR.is_absolute():
    STATE_DIR = (BASE_DIR.parent / STATE_DIR).resolve()
PERSISTENT_ENV_FILE = STATE_DIR / "config.env"
EXAMPLE_FILE = BASE_DIR / ".env.example"


def ask(label: str, current: str = "", required: bool = False) -> str:
    suffix = " [Enter mantém atual]" if current else ""
    while True:
        value = input(f"{label}{suffix}: ").strip()
        if value:
            return value
        if current:
            return current
        if not required:
            return ""
        print("Este campo é obrigatório.")


def normalize_secret_input(value: str, variable: str) -> str:
    """Normalize common copy/paste forms without logging the secret."""
    raw = str(value or "").strip()
    prefix = f"{variable}="
    if raw.upper().startswith(prefix.upper()):
        raw = raw[len(prefix):].strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in {"'", '"'}:
        raw = raw[1:-1].strip()
    return raw


def ask_secret(label: str, variable: str, current: str = "") -> str:
    """Prompt for a secret while making keep/replace/clear semantics explicit."""
    current = str(current or "").strip()
    if current:
        print(f"🔐 {label} atual: {secret_fingerprint(current)} • valor oculto")
        prompt = f"{label} [Enter mantém atual; digite - para apagar]: "
    else:
        prompt = f"{label} (opcional; digite - para manter vazio): "
    raw = input(prompt).strip()
    if raw == "-":
        return ""
    if not raw:
        return current
    return normalize_secret_input(raw, variable)


def ask_positive_int(label: str, current: str, default: int) -> str:
    while True:
        raw = ask(label, current or str(default)).strip()
        try:
            value = int(raw)
        except ValueError:
            print("Informe um número inteiro de dias.")
            continue
        if value <= 0:
            print("A quantidade de dias deve ser maior que zero.")
            continue
        return str(value)


def yes_no(label: str, default: bool = True) -> bool:
    hint = "S/n" if default else "s/N"
    value = input(f"{label} [{hint}]: ").strip().lower()
    if not value:
        return default
    return value in {"s", "sim", "y", "yes", "1", "true"}


def write_env(values: dict[str, str]) -> None:
    values["CSM_STATE_DIR"] = str(STATE_DIR)
    order = []
    if EXAMPLE_FILE.exists():
        for line in EXAMPLE_FILE.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                key = stripped.split("=", 1)[0].strip()
                if key not in order:
                    order.append(key)
    for key in values:
        if key not in order:
            order.append(key)

    groups = {
        "TELEGRAM": ["ENABLE_TELEGRAM", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "ADMIN_USER_IDS"],
        "ASAAS": [key for key in order if key.startswith("ASAAS_")],
        "PROVIDERS": [key for key in order if key.startswith("MULTI_PROVIDER_") or key.startswith("GOPLUS_") or key.startswith("HONEYPOT_") or key.startswith("DEXPAPRIKA_") or key in {"BIRDEYE_API_KEY", "COINGECKO_API_KEY", "BIRDEYE_QUOTA_COOLDOWN_SECONDS"}],
        "ONCHAIN": [key for key in order if key.startswith("ONCHAIN_") or key.startswith("HELIUS_") or key.startswith("EVM_RPC_")],
        "REPUTATION": [key for key in order if key.startswith("REPUTATION_")],
        "OBSERVABILITY": [key for key in order if key.startswith("OBSERVABILITY_")],
        "SAAS_PORTAL": [key for key in order if key.startswith("SAAS_") or key.startswith("CUSTOMER_PORTAL_") or key.startswith("ENTERPRISE_DASHBOARD_")],
        "SCANNER": [key for key in order if key.startswith("SCAN_")],
    }
    written = set()
    lines = ["# Gerado pelo configurador multiplataforma v6.3.0", "# Não compartilhe este arquivo.", ""]
    for title, keys in groups.items():
        lines.append(f"# {title}")
        for key in keys:
            if key in values:
                lines.append(f"{key}={values[key]}")
                written.add(key)
        lines.append("")
    lines.append("# OPERAÇÃO")
    for key in order:
        if key in values and key not in written:
            lines.append(f"{key}={values[key]}")
    payload = "\n".join(lines).rstrip() + "\n"
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    def atomic_write(target: Path) -> None:
        temp = target.with_suffix(target.suffix + ".tmp")
        temp.write_text(payload, encoding="utf-8")
        os.replace(temp, target)
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass

    # Fonte persistente: não é apagada quando a pasta da versão muda.
    atomic_write(PERSISTENT_ENV_FILE)
    # Cópia local para compatibilidade; deve ser idêntica à fonte persistente.
    atomic_write(ENV_FILE)

    required = ("TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID")
    missing = [key for key in required if not values.get(key, "").strip()]
    if missing:
        raise RuntimeError("Configuração não foi salva: " + ", ".join(missing))
    saved = dotenv_values(PERSISTENT_ENV_FILE)
    verify_keys = required + ("BIRDEYE_API_KEY", "COINGECKO_API_KEY", "DEXPAPRIKA_API_KEY", "HONEYPOT_API_KEY", "HELIUS_API_KEY", "HELIUS_SECURE_RPC_URL")
    mismatch = [
        key for key in verify_keys
        if str(saved.get(key, "") or "").strip() != str(values.get(key, "") or "").strip()
    ]
    if mismatch:
        raise RuntimeError("Falha ao validar configuração persistente: " + ", ".join(mismatch))
    local_saved = dotenv_values(ENV_FILE)
    local_mismatch = [
        key for key in verify_keys
        if str(local_saved.get(key, "") or "").strip() != str(values.get(key, "") or "").strip()
    ]
    if local_mismatch:
        raise RuntimeError("Falha ao validar cópia local da configuração: " + ", ".join(local_mismatch))

    # Registra somente a impressão digital da geração atual. Isso impede que uma
    # chave Birdeye antiga volte de um backup automático após uma rotação/limpeza.
    update_credential_marker("BIRDEYE_API_KEY", values.get("BIRDEYE_API_KEY", ""), STATE_DIR)


def _auto_probe_birdeye(values: dict[str, str]) -> None:
    """Probe a newly saved Birdeye credential once, without discovery or Telegram.

    This is intentionally a setup-time credential check. It never parses
    candidates, never emits signals and never sends operational notifications.
    """
    key = str(values.get("BIRDEYE_API_KEY", "") or "").strip()
    if not key:
        return
    try:
        from .provider_intelligence import BirdeyeCredentialProbeState
        state = BirdeyeCredentialProbeState()
        if not state.needs_probe_secret(key):
            return
        print("🦅 Nova credencial Birdeye detectada • probe seguro, sem sinais/Telegram...")
        from phantom_v10.provider_diagnostics import check_birdeye
        from phantom_v10.discovery import MultiProviderDiscovery

        report = check_birdeye(api_key=key, check_listing=True)
        discovery = MultiProviderDiscovery()
        detail = str(report.get("message") or report.get("listing_message") or "")[:120]

        if report.get("listing_ok") is True:
            state.mark_secret(key, "OK", detail=detail or "New Listing OK")
            discovery.clear_provider_pause("birdeye")
            print("✅ Birdeye: nova credencial validada; provider liberado imediatamente.")
            return

        if bool(report.get("quota_exhausted")):
            state.mark_secret(key, "QUOTA", detail=detail or "Compute Units esgotadas")
            ttl = max(300, int(values.get("BIRDEYE_QUOTA_COOLDOWN_SECONDS", "21600") or 21600))
            discovery.pause_provider("birdeye", reason="Compute Units usage limit exceeded", ttl_seconds=ttl)
            print("⚠️ Birdeye: credencial reconhecida, porém a cota está esgotada; fallbacks seguem ativos.")
            return

        if bool(report.get("rate_limited")) or int(report.get("status") or 0) == 429:
            state.mark_secret(key, "RATE_LIMIT", detail=detail or "HTTP 429")
            discovery.pause_provider("birdeye", reason="rate limit no credential probe", ttl_seconds=300)
            print("⚠️ Birdeye: nova credencial em rate limit; revalidação ficará para o runtime.")
            return

        status = int(report.get("status") or 0)
        if status in {401, 403} or report.get("credential_ok") is False:
            state.mark_secret(key, "INVALID", detail=detail or f"HTTP {status}")
            discovery.pause_provider("birdeye", reason="credencial Birdeye inválida/sem acesso", ttl_seconds=300)
            print("⚠️ Birdeye: nova credencial não foi aceita; provider segue isolado e fallbacks permanecem ativos.")
            return

        state.mark_secret(key, "INCONCLUSIVE", detail=detail or "probe inconclusivo")
        discovery.pause_provider("birdeye", reason="credential probe inconclusivo", ttl_seconds=300)
        print("⚠️ Birdeye: probe inconclusivo; nenhuma entrega foi afetada e os fallbacks permanecem ativos.")
    except Exception as exc:
        # Setup must never become unusable because an external provider is down.
        print(f"⚠️ Birdeye: probe não concluído ({type(exc).__name__}); configuração foi salva e os fallbacks seguem ativos.")


def configure_telegram(values):
    print("\n📨 CONFIGURAÇÃO DO TELEGRAM")
    while True:
        token = ask("Seu Token Telegram", values.get("TELEGRAM_BOT_TOKEN", ""), True)
        valid_format = bool(re.fullmatch(r"\d{6,15}:[A-Za-z0-9_-]{20,}", token))
        if not valid_format:
            print("❌ Token inválido. Cole o token completo fornecido pelo BotFather.")
            continue
        break
    values["ENABLE_TELEGRAM"] = "true"
    values["TELEGRAM_BOT_TOKEN"] = token
    values["TELEGRAM_CHAT_ID"] = ask("Seu Chat ID Telegram", values.get("TELEGRAM_CHAT_ID", ""), True)
    values["ADMIN_USER_IDS"] = ask(
        "ID do administrador",
        values.get("ADMIN_USER_IDS", values["TELEGRAM_CHAT_ID"]),
        True,
    )


def configure_asaas(values):
    print("\n💳 CONFIGURAÇÃO DO ASAAS")
    enabled = yes_no("Ativar cobranças pelo Asaas", values.get("ASAAS_ENABLED", "false").lower() == "true")
    values["ASAAS_ENABLED"] = "true" if enabled else "false"
    if not enabled:
        return
    env = ask("Ambiente (sandbox/production)", values.get("ASAAS_ENVIRONMENT", "sandbox")).lower()
    values["ASAAS_ENVIRONMENT"] = env if env in {"sandbox", "production"} else "sandbox"
    values["ASAAS_API_KEY"] = ask("API Key do Asaas", values.get("ASAAS_API_KEY", ""), True)

    pix = yes_no("Aceitar PIX", "PIX" in values.get("ASAAS_PAYMENT_METHODS", "PIX,CREDIT_CARD"))
    card = yes_no("Aceitar cartão de crédito", "CREDIT_CARD" in values.get("ASAAS_PAYMENT_METHODS", "PIX,CREDIT_CARD"))
    methods = []
    if pix:
        methods.append("PIX")
    if card:
        methods.append("CREDIT_CARD")
    if not methods:
        print("⚠️ Nenhuma forma escolhida; PIX e cartão foram ativados.")
        methods = ["PIX", "CREDIT_CARD"]
    values["ASAAS_PAYMENT_METHODS"] = ",".join(methods)
    values["ASAAS_PLUS_VALUE"] = ask("Valor Plus mensal", values.get("ASAAS_PLUS_VALUE", "49.90"))
    values["ASAAS_PREMIUM_VALUE"] = ask("Valor Premium mensal", values.get("ASAAS_PREMIUM_VALUE", "99.90"))
    values["ASAAS_PLUS_ANNUAL_VALUE"] = ask("Valor Plus anual", values.get("ASAAS_PLUS_ANNUAL_VALUE", "598.80"))
    values["ASAAS_PREMIUM_ANNUAL_VALUE"] = ask("Valor Premium anual", values.get("ASAAS_PREMIUM_ANNUAL_VALUE", "1198.90"))
    values["PLAN_MONTHLY_DURATION_DAYS"] = ask_positive_int(
        "Dias de validade dos planos mensais",
        values.get("PLAN_MONTHLY_DURATION_DAYS", "30"),
        30,
    )
    values["PLAN_ANNUAL_DURATION_DAYS"] = ask_positive_int(
        "Dias de validade dos planos anuais",
        values.get("PLAN_ANNUAL_DURATION_DAYS", "365"),
        365,
    )
    values["ASAAS_DUE_DAYS"] = ask_positive_int(
        "Dias até o vencimento da cobrança",
        values.get("ASAAS_DUE_DAYS", "1"),
        1,
    )


def configure_providers(values):
    print("\n🌐 DESCOBERTA MULTI-PROVIDER")
    enabled = yes_no("Ativar camada multi-provider", values.get("MULTI_PROVIDER_ENABLED", "true").lower() == "true")
    values["MULTI_PROVIDER_ENABLED"] = "true" if enabled else "false"
    if not enabled:
        return
    print("DexScreener + GeckoTerminal continuam ativos sem chave.")
    print("DexPaprika entra como fonte pública adicional; chave é opcional.")
    print("Birdeye amplia o Plus/Premium; CoinGecko Onchain amplia o Premium.")
    dp_enabled = yes_no("Ativar DexPaprika pública", values.get("DEXPAPRIKA_ENABLED", "true").lower() == "true")
    values["DEXPAPRIKA_ENABLED"] = "true" if dp_enabled else "false"
    if dp_enabled:
        values["DEXPAPRIKA_BASE_URL"] = ask("DexPaprika Base URL HTTPS", values.get("DEXPAPRIKA_BASE_URL", "https://api.dexpaprika.com"))
        values["DEXPAPRIKA_API_KEY"] = ask_secret("DexPaprika API Key (opcional)", "DEXPAPRIKA_API_KEY", values.get("DEXPAPRIKA_API_KEY", ""))
        values["DEXPAPRIKA_CHAIN_SOURCES"] = ask("Redes DexPaprika por ciclo", values.get("DEXPAPRIKA_CHAIN_SOURCES", "1"))
        values["DEXPAPRIKA_DISCOVERY_LIMIT"] = ask("Candidatos DexPaprika por rede", values.get("DEXPAPRIKA_DISCOVERY_LIMIT", "30"))
        values["DEXPAPRIKA_MARKET_FALLBACK"] = "true" if yes_no("Usar DexPaprika como fallback de mercado", values.get("DEXPAPRIKA_MARKET_FALLBACK", "true").lower() == "true") else "false"
        values["DEXPAPRIKA_QUOTA_COOLDOWN_SECONDS"] = ask("Cooldown ao esgotar créditos DexPaprika (segundos)", values.get("DEXPAPRIKA_QUOTA_COOLDOWN_SECONDS", "21600"))
    values["BIRDEYE_API_KEY"] = ask_secret(
        "Birdeye API Key", "BIRDEYE_API_KEY", values.get("BIRDEYE_API_KEY", "")
    )
    values["COINGECKO_API_KEY"] = ask_secret(
        "CoinGecko Demo API Key", "COINGECKO_API_KEY", values.get("COINGECKO_API_KEY", "")
    )
    values["BIRDEYE_QUOTA_COOLDOWN_SECONDS"] = ask(
        "Cooldown Birdeye ao esgotar Compute Units (segundos)", values.get("BIRDEYE_QUOTA_COOLDOWN_SECONDS", "21600")
    )
    print("GeckoTerminal HTTP 429 usa backoff adaptativo; Retry-After do servidor tem prioridade.")
    values["GECKOTERMINAL_RATE_LIMIT_INITIAL_SECONDS"] = ask(
        "GeckoTerminal 1º 429 (segundos)", values.get("GECKOTERMINAL_RATE_LIMIT_INITIAL_SECONDS", "300")
    )
    values["GECKOTERMINAL_RATE_LIMIT_SECOND_SECONDS"] = ask(
        "GeckoTerminal 2º 429 consecutivo (segundos)", values.get("GECKOTERMINAL_RATE_LIMIT_SECOND_SECONDS", "600")
    )
    values["GECKOTERMINAL_RATE_LIMIT_THIRD_SECONDS"] = ask(
        "GeckoTerminal 3º 429 consecutivo (segundos)", values.get("GECKOTERMINAL_RATE_LIMIT_THIRD_SECONDS", "1200")
    )
    values["GECKOTERMINAL_RATE_LIMIT_MAX_SECONDS"] = ask(
        "GeckoTerminal máximo do backoff 429 (segundos)", values.get("GECKOTERMINAL_RATE_LIMIT_MAX_SECONDS", "1800")
    )
    # Mantido por compatibilidade com instalações anteriores; o runtime V16.5.9
    # usa os quatro degraus adaptativos acima.
    values["GECKOTERMINAL_RATE_LIMIT_COOLDOWN_SECONDS"] = values.get(
        "GECKOTERMINAL_RATE_LIMIT_COOLDOWN_SECONDS", values["GECKOTERMINAL_RATE_LIMIT_MAX_SECONDS"]
    )
    print("\n🍯 HONEYPOT.IS SECURITY FALLBACK")
    print("Fallback EVM público para Ethereum/BSC/Base; não é fonte de discovery.")
    hp_enabled = yes_no("Ativar Honeypot.is keyless", values.get("HONEYPOT_ENABLED", "true").lower() == "true")
    values["HONEYPOT_ENABLED"] = "true" if hp_enabled else "false"
    if hp_enabled:
        values["HONEYPOT_BASE_URL"] = ask("Honeypot.is Base URL HTTPS", values.get("HONEYPOT_BASE_URL", "https://api.honeypot.is"))
        values["HONEYPOT_API_KEY"] = ask_secret("Honeypot.is API Key (opcional/futuro)", "HONEYPOT_API_KEY", values.get("HONEYPOT_API_KEY", ""))
        values["HONEYPOT_CACHE_TTL"] = ask("Cache Honeypot.is (segundos)", values.get("HONEYPOT_CACHE_TTL", "1800"))
        values["HONEYPOT_ENFORCE_BLOCKS"] = "true" if yes_no("Permitir Honeypot.is bloquear sinais (experimental)", values.get("HONEYPOT_ENFORCE_BLOCKS", "false").lower() == "true") else "false"
    print("\n🛡️ GOPLUS SECURITY GATE")
    print("A GoPlus valida risco do contrato depois dos filtros de mercado; não é fonte de descoberta.")
    gp_enabled = yes_no("Ativar GoPlus Token Security", values.get("GOPLUS_ENABLED", "true").lower() == "true")
    values["GOPLUS_ENABLED"] = "true" if gp_enabled else "false"
    if gp_enabled:
        values["GOPLUS_ACCESS_TOKEN"] = ask_secret(
            "GoPlus Bearer Access Token", "GOPLUS_ACCESS_TOKEN", values.get("GOPLUS_ACCESS_TOKEN", "")
        )
        print("ℹ️ Token GoPlus é opcional; vazio usa a rota pública quando disponível.")
        values["GOPLUS_CACHE_TTL"] = ask("Cache GoPlus por contrato (segundos)", values.get("GOPLUS_CACHE_TTL", "1800"))
        values["GOPLUS_STALE_TTL"] = ask("Fallback stale GoPlus (segundos)", values.get("GOPLUS_STALE_TTL", "86400"))
        values["GOPLUS_MIN_SECURITY_SCORE"] = ask("Score mínimo de segurança GoPlus (0-100)", values.get("GOPLUS_MIN_SECURITY_SCORE", "55"))
        values["GOPLUS_SCORE_WEIGHT_PCT"] = ask("Peso máximo da segurança no score final (%)", values.get("GOPLUS_SCORE_WEIGHT_PCT", "25"))
        values["GOPLUS_MAX_BUY_TAX_PCT"] = ask("Buy tax máxima permitida (%)", values.get("GOPLUS_MAX_BUY_TAX_PCT", "25"))
        values["GOPLUS_MAX_SELL_TAX_PCT"] = ask("Sell/transfer tax máxima permitida (%)", values.get("GOPLUS_MAX_SELL_TAX_PCT", "25"))
        values["GOPLUS_FAIL_CLOSED"] = "true" if yes_no(
            "Bloquear sinal quando GoPlus estiver indisponível", values.get("GOPLUS_FAIL_CLOSED", "false").lower() == "true"
        ) else "false"
    values["MULTI_PROVIDER_DISCOVERY_TTL"] = ask("Cache das fontes extras (segundos)", values.get("MULTI_PROVIDER_DISCOVERY_TTL", "120"))
    values["MULTI_PROVIDER_PLUS_CHAIN_SOURCES"] = ask("Redes extras por ciclo Plus", values.get("MULTI_PROVIDER_PLUS_CHAIN_SOURCES", "1"))
    values["MULTI_PROVIDER_PREMIUM_CHAIN_SOURCES"] = ask("Redes extras por ciclo Premium", values.get("MULTI_PROVIDER_PREMIUM_CHAIN_SOURCES", "2"))


def configure_onchain(values):
    print("\n🔗 ON-CHAIN INTELLIGENCE v13.5")
    print("Modo móvel: polling HTTPS cooperativo. Não usa webhook público, porta de entrada ou servidor externo.")
    enabled = yes_no("Ativar On-Chain Intelligence", values.get("ONCHAIN_ENABLED", "true").lower() == "true")
    values["ONCHAIN_ENABLED"] = "true" if enabled else "false"
    if not enabled:
        return
    print("\n☀️ Solana / Helius")
    values["HELIUS_API_KEY"] = ask_secret("Helius API Key", "HELIUS_API_KEY", values.get("HELIUS_API_KEY", ""))
    values["HELIUS_SECURE_RPC_URL"] = ask_secret("Helius Secure RPC URL (opcional; substitui key na URL)", "HELIUS_SECURE_RPC_URL", values.get("HELIUS_SECURE_RPC_URL", ""))
    print("\n⛓️ EVM JSON-RPC (opcional por rede; HTTPS apenas)")
    print("Deixe vazio nas redes que não quiser monitorar. O scanner continua funcionando normalmente.")
    for chain, key in (
        ("Ethereum", "EVM_RPC_ETHEREUM"), ("BSC", "EVM_RPC_BSC"), ("Base", "EVM_RPC_BASE"),
        ("Arbitrum", "EVM_RPC_ARBITRUM"), ("Polygon", "EVM_RPC_POLYGON"), ("Avalanche", "EVM_RPC_AVALANCHE"),
        ("Optimism", "EVM_RPC_OPTIMISM"), ("Fantom", "EVM_RPC_FANTOM"), ("Cronos", "EVM_RPC_CRONOS"),
    ):
        values[key] = ask_secret(f"RPC HTTPS {chain}", key, values.get(key, ""))
    values["ONCHAIN_MONITOR_INTERVAL"] = ask("Intervalo do monitor on-chain (segundos)", values.get("ONCHAIN_MONITOR_INTERVAL", "300"))
    values["ONCHAIN_MONITOR_BATCH"] = ask("Sinais on-chain por recarga de fila", values.get("ONCHAIN_MONITOR_BATCH", "8"))
    values["ONCHAIN_WHALE_MIN_USD"] = ask("Valor mínimo para classificar whale transfer (USD)", values.get("ONCHAIN_WHALE_MIN_USD", "10000"))
    values["ONCHAIN_LIQUIDITY_WARN_DROP_PCT"] = ask("Queda de liquidez para alerta (%)", values.get("ONCHAIN_LIQUIDITY_WARN_DROP_PCT", "25"))


def configure_reputation(values):
    print("\n🧬 WALLET/DEPLOYER REPUTATION v14")
    print("Usa somente evidências locais do On-Chain + resultados reais. Não faz chamadas de rede.")
    enabled = yes_no("Ativar Reputation Engine", values.get("REPUTATION_ENABLED", "true").lower() == "true")
    values["REPUTATION_ENABLED"] = "true" if enabled else "false"
    if not enabled:
        return
    values["REPUTATION_REFRESH_INTERVAL"] = ask("Intervalo para consolidar reputação (segundos)", values.get("REPUTATION_REFRESH_INTERVAL", "300"))
    values["REPUTATION_REFRESH_LIMIT"] = ask("Máximo de evidências por consolidação", values.get("REPUTATION_REFRESH_LIMIT", "1000"))
    values["REPUTATION_MIN_CONFIDENCE"] = ask("Confiança mínima para penalizar CSM Confidence (0-100)", values.get("REPUTATION_MIN_CONFIDENCE", "30"))
    values["REPUTATION_CSM_MAX_PENALTY"] = ask("Penalidade máxima no CSM Confidence por deployer de risco", values.get("REPUTATION_CSM_MAX_PENALTY", "20"))


def configure_observability(values):
    print("\n📡 OBSERVABILITY & OPERATIONS v14.5")
    print("Telemetria local/cooperativa: SQLite + dashboard/API existentes. Sem webhook público e sem coletor externo obrigatório.")
    enabled = yes_no("Ativar Observability & Operations", values.get("OBSERVABILITY_ENABLED", "true").lower() == "true")
    values["OBSERVABILITY_ENABLED"] = "true" if enabled else "false"
    if not enabled:
        return
    values["OBSERVABILITY_RUNTIME_INTERVAL"] = ask("Heartbeat operacional local (segundos)", values.get("OBSERVABILITY_RUNTIME_INTERVAL", "60"))
    values["OBSERVABILITY_RETENTION_DAYS"] = ask("Retenção de métricas detalhadas (dias)", values.get("OBSERVABILITY_RETENTION_DAYS", "30"))
    values["OBSERVABILITY_PROVIDER_LATENCY_WARN_MS"] = ask("Avisar latência de provider acima de (ms)", values.get("OBSERVABILITY_PROVIDER_LATENCY_WARN_MS", "2500"))
    values["OBSERVABILITY_PROVIDER_SUCCESS_WARN_PCT"] = ask("Avisar sucesso de provider abaixo de (%)", values.get("OBSERVABILITY_PROVIDER_SUCCESS_WARN_PCT", "70"))
    values["OBSERVABILITY_DELIVERY_ERROR_COUNT"] = ask("Falhas Telegram por ciclo para incidente", values.get("OBSERVABILITY_DELIVERY_ERROR_COUNT", "2"))
    values["OBSERVABILITY_DELIVERY_ERROR_PCT"] = ask("Taxa de falha Telegram para incidente (%)", values.get("OBSERVABILITY_DELIVERY_ERROR_PCT", "25"))
    values["OBSERVABILITY_NETWORK_BUSY_WARN_SECONDS"] = ask("Barramento HTTPS ocupado para alerta (segundos)", values.get("OBSERVABILITY_NETWORK_BUSY_WARN_SECONDS", "15"))
    values["OBSERVABILITY_ADMIN_ALERTS"] = "true" if yes_no("Enviar incidentes HIGH/CRITICAL ao administrador pelo Telegram", values.get("OBSERVABILITY_ADMIN_ALERTS", "true").lower() == "true") else "false"
    values["OBSERVABILITY_ADMIN_ALERT_COOLDOWN"] = ask("Cooldown dos alertas operacionais (segundos)", values.get("OBSERVABILITY_ADMIN_ALERT_COOLDOWN", "1800"))


def configure_distribution(values):
    print("\n📤 DISTRIBUTION PLATFORM v15")
    print("Somente saída: Telegram continua principal. Webhook assinado, Discord e e-mail não abrem porta pública.")
    enabled = yes_no("Ativar Distribution Platform", values.get("DISTRIBUTION_ENABLED", "true").lower() == "true")
    values["DISTRIBUTION_ENABLED"] = "true" if enabled else "false"
    if not enabled:
        return
    values["DISTRIBUTION_MAX_ATTEMPTS"] = ask("Máximo de tentativas por entrega", values.get("DISTRIBUTION_MAX_ATTEMPTS", "5"))
    values["DISTRIBUTION_TIMEOUT_SECONDS"] = ask("Timeout por canal (segundos)", values.get("DISTRIBUTION_TIMEOUT_SECONDS", "6"))
    if yes_no("Configurar SMTP para e-mail agora", bool(values.get("SMTP_HOST"))):
        values["SMTP_HOST"] = ask("SMTP host", values.get("SMTP_HOST", ""))
        values["SMTP_PORT"] = ask("SMTP port", values.get("SMTP_PORT", "587"))
        values["SMTP_USERNAME"] = ask("SMTP usuário (pode ser vazio)", values.get("SMTP_USERNAME", ""))
        values["SMTP_PASSWORD"] = ask_secret("SMTP senha/app password", "SMTP_PASSWORD", values.get("SMTP_PASSWORD", ""))
        values["SMTP_FROM"] = ask("E-mail remetente", values.get("SMTP_FROM", ""))
        values["SMTP_STARTTLS"] = "true" if yes_no("Usar STARTTLS", values.get("SMTP_STARTTLS", "true").lower() == "true") else "false"
        values["SMTP_SSL"] = "true" if yes_no("Usar SSL direto", values.get("SMTP_SSL", "false").lower() == "true") else "false"


def configure_customer_portal(values):
    print("\n🧭 CUSTOMER PORTAL & ENTERPRISE DASHBOARD v16")
    print("O portal usa a mesma SaaS API e API key; não cria outro serviço nem altera o scanner.")
    api_enabled = yes_no("Ativar SaaS API / Portal", values.get("SAAS_API_ENABLED", "false").lower() == "true")
    values["SAAS_API_ENABLED"] = "true" if api_enabled else "false"
    if not api_enabled:
        values["CUSTOMER_PORTAL_ENABLED"] = "false"
        return
    values["SAAS_API_HOST"] = ask("Host local da SaaS API", values.get("SAAS_API_HOST", "127.0.0.1"))
    values["SAAS_API_PORT"] = ask("Porta da SaaS API", values.get("SAAS_API_PORT", "8787"))
    values["CUSTOMER_PORTAL_ENABLED"] = "true" if yes_no(
        "Ativar Customer Portal", values.get("CUSTOMER_PORTAL_ENABLED", "true").lower() == "true"
    ) else "false"
    values["CUSTOMER_PORTAL_MAX_SIGNALS"] = ask(
        "Máximo de sinais mostrados no portal", values.get("CUSTOMER_PORTAL_MAX_SIGNALS", "100")
    )
    values["ENTERPRISE_DASHBOARD_ENABLED"] = "true" if yes_no(
        "Ativar visão Enterprise por tenant", values.get("ENTERPRISE_DASHBOARD_ENABLED", "true").lower() == "true"
    ) else "false"
    print("🔐 Recomendado no Termux: mantenha 127.0.0.1 enquanto não houver proxy HTTPS/VPN privada.")


def configure_scanner(values):
    # Frequências comerciais fixas solicitadas: Grátis 15 min, Plus 5 min, Premium 1 min.
    values["AUTO_SCAN_INTERVAL_FREE"] = "900"
    values["AUTO_SCAN_INTERVAL_PLUS"] = "300"
    values["AUTO_SCAN_INTERVAL_PREMIUM"] = "60"
    print("\n🚀 CONFIGURAÇÃO DO SCANNER")
    print("⏱️ Sinais automáticos: Grátis 15 min | Plus 5 min | Premium 1 min")
    print("1 - Econômico (iPhone/a-Shell)")
    print("2 - Balanceado (recomendado)")
    print("3 - Agressivo")
    print("4 - Personalizado (todos os limites)")
    choice = input("Escolha [2]: ").strip() or "2"
    profiles = {
        "1": {"SCAN_LIMIT":"50","SCAN_WORKERS":"1","SCAN_MIN_LIQUIDITY":"15000","SCAN_MAX_LIQUIDITY":"0","SCAN_MIN_VOLUME24H":"50000","SCAN_MAX_VOLUME24H":"0","SCAN_MIN_MARKETCAP":"0","SCAN_MAX_MARKETCAP":"50000000","SCAN_MIN_AGE_DAYS":"0","SCAN_MAX_AGE_DAYS":"30","SCAN_MIN_CHANGE24H":"-25","SCAN_MAX_CHANGE24H":"150","SCAN_MIN_TXNS24H":"30","SCAN_MIN_BUY_SELL_RATIO":"0.80","SCAN_RESULT_LIMIT":"10","AUTO_SIGNAL_MIN_SCORE":"82"},
        "2": {"SCAN_LIMIT":"100","SCAN_WORKERS":"2","SCAN_MIN_LIQUIDITY":"25000","SCAN_MAX_LIQUIDITY":"0","SCAN_MIN_VOLUME24H":"50000","SCAN_MAX_VOLUME24H":"0","SCAN_MIN_MARKETCAP":"0","SCAN_MAX_MARKETCAP":"50000000","SCAN_MIN_AGE_DAYS":"0","SCAN_MAX_AGE_DAYS":"30","SCAN_MIN_CHANGE24H":"-35","SCAN_MAX_CHANGE24H":"250","SCAN_MIN_TXNS24H":"20","SCAN_MIN_BUY_SELL_RATIO":"0.70","SCAN_RESULT_LIMIT":"15","AUTO_SIGNAL_MIN_SCORE":"78"},
        "3": {"SCAN_LIMIT":"250","SCAN_WORKERS":"2","SCAN_MIN_LIQUIDITY":"5000","SCAN_MAX_LIQUIDITY":"0","SCAN_MIN_VOLUME24H":"25000","SCAN_MAX_VOLUME24H":"0","SCAN_MIN_MARKETCAP":"0","SCAN_MAX_MARKETCAP":"100000000","SCAN_MIN_AGE_DAYS":"0","SCAN_MAX_AGE_DAYS":"90","SCAN_MIN_CHANGE24H":"-50","SCAN_MAX_CHANGE24H":"500","SCAN_MIN_TXNS24H":"10","SCAN_MIN_BUY_SELL_RATIO":"0.55","SCAN_RESULT_LIMIT":"20","AUTO_SIGNAL_MIN_SCORE":"72"},
    }
    if choice in profiles:
        values.update(profiles[choice])
        print("✅ Perfil aplicado. Limites máximos 0 significam ilimitado.")
        return

    print("\nDigite 0 nos limites máximos para deixar ILIMITADO.")
    fields = [
        ("SCAN_LIMIT", "Quantidade máxima por ciclo", "100"),
        ("SCAN_MAX_CANDIDATES", "Máximo de candidatos descobertos", "1000"),
        ("SCAN_WORKERS", "Processos simultâneos (a-Shell: use 1)", "1"),
        ("SCAN_MIN_LIQUIDITY", "Liquidez mínima USD", "25000"),
        ("SCAN_MAX_LIQUIDITY", "Liquidez máxima USD (0 = ilimitada)", "0"),
        ("SCAN_MIN_VOLUME24H", "Volume mínimo 24h USD", "50000"),
        ("SCAN_MAX_VOLUME24H", "Volume máximo 24h USD (0 = ilimitado)", "0"),
        ("SCAN_MIN_MARKETCAP", "Market cap mínimo USD", "0"),
        ("SCAN_MAX_MARKETCAP", "Market cap máximo USD (0 = ilimitado)", "50000000"),
        ("SCAN_MIN_AGE_DAYS", "Idade mínima em dias", "0"),
        ("SCAN_MAX_AGE_DAYS", "Idade máxima em dias (0 = ilimitada)", "30"),
        ("SCAN_MIN_CHANGE24H", "Variação mínima 24h (%)", "-35"),
        ("SCAN_MAX_CHANGE24H", "Variação máxima 24h (%) (0 = ilimitada)", "250"),
        ("SCAN_MIN_TXNS24H", "Mínimo de transações 24h", "20"),
        ("SCAN_MIN_BUY_SELL_RATIO", "Relação mínima compras/vendas", "0.70"),
        ("SCAN_RESULT_LIMIT", "Quantidade de resultados exibidos", "15"),
        ("SCAN_DISCOVERY_TTL", "Cache da descoberta (segundos)", "300"),
        ("SCAN_CACHE_TTL", "Cache dos resultados (segundos)", "120"),
        ("AUTO_SIGNAL_MIN_SCORE", "Score mínimo para sinais automáticos", "78"),
        ("AUTO_SIGNAL_LIMIT", "Máximo de sinais por ciclo", "2"),
        ("FAVORITE_MONITOR_INTERVAL", "Intervalo do monitor de favoritos (segundos)", "300"),
        ("FAVORITE_ALERT_UP_PCT", "Alerta de alta nos favoritos (%)", "10"),
        ("FAVORITE_ALERT_DOWN_PCT", "Alerta de queda nos favoritos (%)", "10"),
    ]
    for key, label, default in fields:
        values[key] = ask(label, values.get(key, default))
    values["SCAN_CHAINS"] = ask(
        "Redes separadas por vírgula",
        values.get("SCAN_CHAINS", "solana,ethereum,bsc,base,arbitrum,polygon,avalanche,optimism"),
    )
    print("✅ Perfil personalizado configurado. Salve e reinicie o bot para aplicar.")

def run_setup() -> int:
    project_env = ENV_FILE.parent.resolve() == Path(__file__).resolve().parent.parent
    if not ENV_FILE.exists() and project_env:
        try:
            from .backup_manager import newest_backup, import_legacy_env, restore_backup
            previous = newest_backup()
            if previous and yes_no(f"Backup anterior encontrado em {previous}. Restaurar configurações e banco", True):
                result = restore_backup(previous, restore_secrets=True)
                print(f"✅ Backup anterior restaurado: {result}")
            elif not previous:
                legacy = import_legacy_env()
                if legacy:
                    print(f"✅ Configuração antiga importada de {legacy}")
        except Exception as exc:
            print(f"⚠️ Importação automática não pôde ser concluída: {type(exc).__name__}: {exc}")

    values = {k: str(v) for k, v in dotenv_values(EXAMPLE_FILE).items() if v is not None}
    values.update({k: str(v) for k, v in dotenv_values(ENV_FILE).items() if v is not None})
    values.update({k: str(v) for k, v in dotenv_values(PERSISTENT_ENV_FILE).items() if v is not None})

    while True:
        print("\n==============================")
        print(" CONFIGURAÇÃO — Crypto Signals Multichain v16.5.9")
        print("==============================")
        print("1 - Configurar Telegram")
        print("2 - Configurar Asaas (PIX/cartão)")
        print("3 - Configurar Scanner")
        print("4 - Mostrar resumo seguro")
        print("5 - Configuração completa")
        print("6 - Configurar fontes Multi-Provider")
        print("7 - Configurar On-Chain Intelligence (Helius/EVM polling)")
        print("8 - Configurar Wallet/Deployer Reputation")
        print("9 - Configurar Observability & Operations")
        print("10 - Configurar Distribution Platform")
        print("11 - Configurar Customer Portal & Enterprise Dashboard")
        print("0 - Salvar e sair")
        option = input("Opção: ").strip()

        if option == "1":
            configure_telegram(values)
        elif option == "2":
            configure_asaas(values)
        elif option == "3":
            configure_scanner(values)
        elif option == "4":
            print("\nTelegram:", "configurado" if values.get("TELEGRAM_BOT_TOKEN") else "não configurado")
            print("Asaas:", "ativado" if values.get("ASAAS_ENABLED") == "true" else "desativado")
            print("Formas:", values.get("ASAAS_PAYMENT_METHODS", "não definidas"))
            print("Scanner limite:", values.get("SCAN_LIMIT", "100"))
            print("Liquidez:", values.get("SCAN_MIN_LIQUIDITY", "0"), "até", values.get("SCAN_MAX_LIQUIDITY", "0"), "(0 = ilimitada)")
            print("Volume 24h:", values.get("SCAN_MIN_VOLUME24H", "0"), "até", values.get("SCAN_MAX_VOLUME24H", "0"), "(0 = ilimitado)")
            print("Multi-provider:", "ativado" if values.get("MULTI_PROVIDER_ENABLED", "true") == "true" else "desativado")
            print("Birdeye:", "chave presente (valide com birdeye-check)" if values.get("BIRDEYE_API_KEY") else "sem chave")
            print("CoinGecko:", "configurado" if values.get("COINGECKO_API_KEY") else "sem chave")
            print("DexPaprika:", "ativa (chave opcional presente)" if values.get("DEXPAPRIKA_API_KEY") else ("ativa keyless" if values.get("DEXPAPRIKA_ENABLED", "true").lower() == "true" else "desativada"))
            print("Honeypot.is:", "ativo keyless" if values.get("HONEYPOT_ENABLED", "true").lower() == "true" and not values.get("HONEYPOT_API_KEY") else ("ativo com chave" if values.get("HONEYPOT_ENABLED", "true").lower() == "true" else "desativado"))
            print("GoPlus Security:", "ativado" if values.get("GOPLUS_ENABLED", "true") == "true" else "desativado", "• token", "presente" if values.get("GOPLUS_ACCESS_TOKEN") else "opcional/ausente")
            print("On-Chain:", "ativado" if values.get("ONCHAIN_ENABLED", "true") == "true" else "desativado", "• Helius", "configurado" if values.get("HELIUS_API_KEY") or values.get("HELIUS_SECURE_RPC_URL") else "ausente")
            evm_count = sum(1 for key in values if key.startswith("EVM_RPC_") and values.get(key))
            print("EVM RPCs configurados:", evm_count)
            print("Reputation Engine:", "ativado" if values.get("REPUTATION_ENABLED", "true") == "true" else "desativado")
            print("Observability:", "ativada" if values.get("OBSERVABILITY_ENABLED", "true") == "true" else "desativada")
            print("Distribution Platform:", "ativada" if values.get("DISTRIBUTION_ENABLED", "true") == "true" else "desativada")
            print("SaaS API:", "ativada" if values.get("SAAS_API_ENABLED", "false") == "true" else "desativada", "•", values.get("SAAS_API_HOST", "127.0.0.1"), values.get("SAAS_API_PORT", "8787"))
            print("Customer Portal:", "ativado" if values.get("CUSTOMER_PORTAL_ENABLED", "true") == "true" else "desativado")
            print("Enterprise Dashboard:", "ativado" if values.get("ENTERPRISE_DASHBOARD_ENABLED", "true") == "true" else "desativado")
        elif option == "5":
            configure_telegram(values)
            configure_asaas(values)
            configure_scanner(values)
            write_env(values)
            _auto_probe_birdeye(values)
            print(f"\n✅ Configuração persistente salva em {PERSISTENT_ENV_FILE}")
            try:
                from .backup_manager import create_backup
                backup = create_backup(include_secrets=True)
                print(f"✅ Backup automático criado: {backup}")
                print("⚠️ O backup contém chaves privadas. Não compartilhe.")
            except Exception as exc:
                print(f"⚠️ Não foi possível criar o backup automático: {type(exc).__name__}: {exc}")
            if values.get("BIRDEYE_API_KEY"):
                print("🦅 Diagnóstico manual opcional: python3 main.py birdeye-check")
            if values.get("HONEYPOT_ENABLED", "true").lower() == "true":
                print("🍯 Valide Honeypot.is depois de sair: python3 main.py honeypot-check")
            if values.get("GOPLUS_ENABLED", "true").lower() == "true":
                print("🛡️ Valide a GoPlus depois de sair: python3 main.py goplus-check")
            if values.get("ONCHAIN_ENABLED", "true").lower() == "true":
                print("🔗 Valide On-Chain depois de sair: python3 main.py onchain-check --chain solana")
            if values.get("DISTRIBUTION_ENABLED", "true").lower() == "true":
                print("📤 Confira Distribution depois de sair: python3 main.py distribution-status --days 7")
            return 0
        elif option == "6":
            configure_providers(values)
        elif option == "7":
            configure_onchain(values)
        elif option == "8":
            configure_reputation(values)
        elif option == "9":
            configure_observability(values)
        elif option == "10":
            configure_distribution(values)
        elif option == "11":
            configure_customer_portal(values)
        elif option == "0":
            write_env(values)
            _auto_probe_birdeye(values)
            print(f"\n✅ Configuração persistente salva em {PERSISTENT_ENV_FILE}")
            try:
                from .backup_manager import create_backup
                backup = create_backup(include_secrets=True)
                print(f"✅ Backup automático criado: {backup}")
                print("⚠️ O backup contém chaves privadas. Não compartilhe.")
            except Exception as exc:
                print(f"⚠️ Não foi possível criar o backup automático: {type(exc).__name__}: {exc}")
            if values.get("BIRDEYE_API_KEY"):
                print("🦅 Diagnóstico manual opcional: python3 main.py birdeye-check")
            if values.get("HONEYPOT_ENABLED", "true").lower() == "true":
                print("🍯 Valide Honeypot.is depois de sair: python3 main.py honeypot-check")
            if values.get("GOPLUS_ENABLED", "true").lower() == "true":
                print("🛡️ Valide a GoPlus depois de sair: python3 main.py goplus-check")
            if values.get("ONCHAIN_ENABLED", "true").lower() == "true":
                print("🔗 Valide On-Chain depois de sair: python3 main.py onchain-check --chain solana")
            if values.get("DISTRIBUTION_ENABLED", "true").lower() == "true":
                print("📤 Confira Distribution depois de sair: python3 main.py distribution-status --days 7")
            return 0
        else:
            print("Opção inválida.")


if __name__ == "__main__":
    raise SystemExit(run_setup())
