from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


VERSION = "16.5.4"


def _num(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _timestamp(value: Any) -> float | None:
    if value is None:
        return None

    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip()

    if not text:
        return None

    try:
        return datetime.fromisoformat(
            text.replace("Z", "+00:00")
        ).timestamp()
    except Exception:
        return None


def classify_shadow_age(
    age_seconds: float,
    *,
    target_seconds: int = 300,
    grace_seconds: int = 180,
) -> str:
    if age_seconds < target_seconds:
        return "WAITING"

    if age_seconds <= target_seconds + grace_seconds:
        return "DUE"

    return "LATE"


def build_recovery_plan(
    rows: list[dict[str, Any]],
    *,
    now_ts: float | None = None,
    target_seconds: int = 300,
    grace_seconds: int = 180,
    max_batch: int = 25,
) -> dict[str, Any]:
    now_ts = (
        float(now_ts)
        if now_ts is not None
        else datetime.now(timezone.utc).timestamp()
    )

    waiting = []
    due = []
    late = []
    invalid = []

    seen: set[str] = set()

    for row in rows:
        item = dict(row)

        signal_id = str(
            item.get("signal_id")
            or item.get("id")
            or ""
        ).strip()

        if not signal_id:
            invalid.append(item)
            continue

        if signal_id in seen:
            continue

        seen.add(signal_id)

        created_ts = _timestamp(
            item.get("created_at")
            or item.get("signal_created_at")
            or item.get("timestamp")
        )

        if created_ts is None:
            invalid.append(item)
            continue

        age = max(
            0.0,
            now_ts - created_ts,
        )

        state = classify_shadow_age(
            age,
            target_seconds=target_seconds,
            grace_seconds=grace_seconds,
        )

        item["signal_id"] = signal_id
        item["shadow_age_seconds"] = round(age, 2)
        item["shadow_state"] = state

        if state == "WAITING":
            waiting.append(item)
        elif state == "DUE":
            due.append(item)
        else:
            late.append(item)

    due.sort(
        key=lambda x: x["shadow_age_seconds"],
        reverse=True,
    )

    batch = due[:max_batch]

    return {
        "version": VERSION,
        "mode": "SHADOW",
        "target_seconds": target_seconds,
        "grace_seconds": grace_seconds,
        "pending_total": len(seen),
        "waiting": len(waiting),
        "due": len(due),
        "late": len(late),
        "invalid": len(invalid),
        "recovery_batch": batch,
        "recovery_batch_size": len(batch),
        "methodology": (
            "Não fabrica observação retroativa. "
            "Somente prioriza sinais ainda dentro da "
            "janela válida de evidência Shadow."
        ),
    }


def evidence_health(
    *,
    total: int,
    confirmed: int,
) -> dict[str, Any]:
    total = max(int(total or 0), 0)
    confirmed = max(int(confirmed or 0), 0)

    coverage = (
        confirmed / total * 100
        if total
        else 0.0
    )

    if confirmed >= 50 and coverage >= 20:
        status = "MATURE"
    elif confirmed >= 20:
        status = "GROWING"
    else:
        status = "EARLY"

    return {
        "version": VERSION,
        "total": total,
        "confirmed": confirmed,
        "pending": max(total - confirmed, 0),
        "coverage_pct": round(coverage, 2),
        "status": status,
        "target_confirmed": 50,
        "target_coverage_pct": 20.0,
    }
