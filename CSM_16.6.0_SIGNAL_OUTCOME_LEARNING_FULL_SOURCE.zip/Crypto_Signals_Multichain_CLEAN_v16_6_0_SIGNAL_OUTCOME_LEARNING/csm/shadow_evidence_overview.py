from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import STATE_DIR
from .shadow_evidence_accelerator import evidence_health


VERSION = "16.5.4"


def _load_queue_status(
    state_dir: Path,
) -> dict[str, Any]:
    path = (
        state_dir
        / "shadow_evidence"
        / "queue_status.json"
    )

    if not path.is_file():
        return {
            "queue_size": 0,
            "waiting": 0,
            "due": 0,
            "late": 0,
            "unknown": 0,
            "by_chain": {},
            "by_provider": {},
        }

    try:
        data = json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )

        return (
            data
            if isinstance(data, dict)
            else {}
        )

    except Exception:
        return {
            "queue_size": 0,
            "waiting": 0,
            "due": 0,
            "late": 0,
            "unknown": 0,
            "by_chain": {},
            "by_provider": {},
        }


def attach_shadow_evidence(
    report: dict[str, Any],
    *,
    state_dir: Path | str | None = None,
    queue_override: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = dict(report)

    root = Path(
        state_dir or STATE_DIR
    )

    total = int(
        result.get("samples")
        or 0
    )

    confirmed = int(
        result.get("shadow_confirmed")
        or 0
    )

    health = evidence_health(
        total=total,
        confirmed=confirmed,
    )

    queue = dict(queue_override or _load_queue_status(root))

    result["shadow_evidence"] = {
        "version": VERSION,
        "status": health["status"],
        "total": health["total"],
        "confirmed": health["confirmed"],
        "pending": health["pending"],
        "coverage_pct": health["coverage_pct"],
        "target_confirmed": (
            health["target_confirmed"]
        ),
        "target_coverage_pct": (
            health["target_coverage_pct"]
        ),
        "queue": {
            "size": int(
                queue.get("queue_size")
                or 0
            ),
            "waiting": int(
                queue.get("waiting")
                or 0
            ),
            "due": int(
                queue.get("due")
                or 0
            ),
            "late": int(
                queue.get("late")
                or 0
            ),
            "unknown": int(
                queue.get("unknown")
                or 0
            ),
        },
        "queue_by_chain": (
            queue.get("by_chain")
            or {}
        ),
        "queue_by_provider": (
            queue.get("by_provider")
            or {}
        ),
        "queue_source": queue.get("source") or "scheduler_cache",
        "queue_confirmed_recent": int(queue.get("confirmed") or 0),
        "queue_lookback_hours": queue.get("lookback_hours"),
        "mode": "SHADOW",
        "live_impact": False,
    }

    return result
