from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import STATE_DIR
from .shadow_evidence_accelerator import (
    classify_shadow_age,
)


VERSION = "16.5.4"


def _ts(value: Any) -> float | None:
    if value is None:
        return None

    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip()

    if not text:
        return None

    try:
        return datetime.fromisoformat(
            text.replace("Z", "+00:00")
        ).timestamp()
    except Exception:
        return None


def _item_state(
    item: dict[str, Any],
    now_ts: float,
    target_seconds: int,
    grace_seconds: int,
) -> tuple[str, float]:
    due = _ts(
        item.get("due_at")
        or item.get("shadow_due_at")
    )

    if due is not None:
        delta = now_ts - due

        if delta < 0:
            return "WAITING", delta

        if delta <= grace_seconds:
            return "DUE", delta

        return "LATE", delta

    created = _ts(
        item.get("created_at")
        or item.get("signal_created_at")
        or item.get("timestamp")
        or item.get("queued_at")
    )

    if created is None:
        return "UNKNOWN", 0.0

    age = max(0.0, now_ts - created)

    return (
        classify_shadow_age(
            age,
            target_seconds=target_seconds,
            grace_seconds=grace_seconds,
        ),
        age,
    )


def prioritize_shadow_queue(
    queue: Any,
    *,
    now_ts: float | None = None,
    target_seconds: int = 300,
    grace_seconds: int = 180,
):
    if queue is None:
        return queue

    try:
        items = list(queue)
    except Exception:
        return queue

    if len(items) < 2:
        return queue

    now_ts = (
        float(now_ts)
        if now_ts is not None
        else datetime.now(timezone.utc).timestamp()
    )

    enriched = []

    for index, item in enumerate(items):
        if not isinstance(item, dict):
            return queue

        state, age = _item_state(
            item,
            now_ts,
            target_seconds,
            grace_seconds,
        )

        priority = {
            "DUE": 0,
            "WAITING": 1,
            "UNKNOWN": 2,
            "LATE": 3,
        }.get(state, 2)

        # Dentro de DUE, o mais próximo de perder
        # a janela válida vem primeiro.
        age_order = (
            -float(age)
            if state == "DUE"
            else float(index)
        )

        enriched.append(
            (
                priority,
                age_order,
                index,
                item,
            )
        )

    ordered = [
        row[3]
        for row in sorted(
            enriched,
            key=lambda row: (
                row[0],
                row[1],
                row[2],
            ),
        )
    ]

    try:
        return type(queue)(ordered)
    except Exception:
        return ordered


def queue_status(
    queue: Any,
    *,
    now_ts: float | None = None,
    target_seconds: int = 300,
    grace_seconds: int = 180,
) -> dict[str, Any]:
    try:
        items = list(queue or [])
    except Exception:
        items = []

    now_ts = (
        float(now_ts)
        if now_ts is not None
        else datetime.now(timezone.utc).timestamp()
    )

    states = Counter()
    chains = Counter()
    providers = Counter()

    for item in items:
        if not isinstance(item, dict):
            states["UNKNOWN"] += 1
            continue

        state, _ = _item_state(
            item,
            now_ts,
            target_seconds,
            grace_seconds,
        )

        states[state] += 1

        chain = str(
            item.get("chain")
            or item.get("network")
            or ""
        ).strip()

        provider = str(
            item.get("provider")
            or item.get("source")
            or ""
        ).strip()

        if chain:
            chains[chain] += 1

        if provider:
            providers[provider] += 1

    return {
        "version": VERSION,
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "queue_size": len(items),
        "waiting": states["WAITING"],
        "due": states["DUE"],
        "late": states["LATE"],
        "unknown": states["UNKNOWN"],
        "by_chain": dict(chains),
        "by_provider": dict(providers),
        "mode": "SHADOW",
    }


def persist_queue_status(queue: Any) -> None:
    try:
        root = (
            Path(STATE_DIR)
            / "shadow_evidence"
        )

        root.mkdir(
            parents=True,
            exist_ok=True,
        )

        report = queue_status(queue)

        (
            root / "queue_status.json"
        ).write_text(
            json.dumps(
                report,
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    except Exception:
        # Telemetria nunca pode derrubar scheduler.
        return


def prepare_shadow_queue(queue: Any):
    prepared = prioritize_shadow_queue(
        queue
    )

    persist_queue_status(prepared)

    return prepared
