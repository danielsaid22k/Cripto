from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Any


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat()


def buy_pressure(buys: Any, sells: Any) -> float | None:
    b, s = _i(buys), _i(sells)
    total = b + s
    return (b / total * 100.0) if total > 0 else None


def ensure_schema(conn: sqlite3.Connection) -> None:
    columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(signal_ledger)").fetchall()}
    additions = {
        "target3_pct": "REAL DEFAULT 100",
        "first_tp3_at": "TEXT",
        "lifecycle_state": "TEXT DEFAULT 'ACTIVE'",
        "deterioration_score": "INTEGER DEFAULT 0",
        "deterioration_reasons_json": "TEXT DEFAULT '[]'",
        "last_buy_pressure_pct": "REAL",
        "last_liquidity_change_pct": "REAL DEFAULT 0",
        "last_volume_change_pct": "REAL DEFAULT 0",
        "last_score_delta": "INTEGER DEFAULT 0",
        "next_check_at": "TEXT",
        "last_lifecycle_event": "TEXT DEFAULT ''",
        "closed_at": "TEXT",
    }
    for name, ddl in additions.items():
        if name not in columns:
            conn.execute(f"ALTER TABLE signal_ledger ADD COLUMN {name} {ddl}")

    obs_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(signal_observations)").fetchall()}
    obs_additions = {
        "buys24h": "INTEGER DEFAULT 0",
        "sells24h": "INTEGER DEFAULT 0",
        "buy_pressure_pct": "REAL",
        "change1h": "REAL DEFAULT 0",
        "volume1h": "REAL DEFAULT 0",
        "liquidity_change_pct": "REAL DEFAULT 0",
        "volume_change_pct": "REAL DEFAULT 0",
        "score_delta": "INTEGER DEFAULT 0",
    }
    for name, ddl in obs_additions.items():
        if name not in obs_columns:
            conn.execute(f"ALTER TABLE signal_observations ADD COLUMN {name} {ddl}")

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS signal_lifecycle_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            event_key TEXT NOT NULL UNIQUE,
            event_type TEXT NOT NULL,
            state TEXT NOT NULL,
            return_pct REAL DEFAULT 0,
            price REAL DEFAULT 0,
            deterioration_score INTEGER DEFAULT 0,
            reasons_json TEXT DEFAULT '[]',
            details_json TEXT DEFAULT '{}',
            notified_at TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(signal_id) REFERENCES signal_ledger(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_signal_lifecycle_events_created
        ON signal_lifecycle_events(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_signal_lifecycle_events_signal
        ON signal_lifecycle_events(signal_id, created_at DESC);
        """
    )
    event_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(signal_lifecycle_events)").fetchall()}
    if "event_key" not in event_columns:
        conn.execute("ALTER TABLE signal_lifecycle_events ADD COLUMN event_key TEXT")
        conn.execute("UPDATE signal_lifecycle_events SET event_key=CAST(signal_id AS TEXT)||':'||event_type||':'||CAST(id AS TEXT) WHERE event_key IS NULL OR event_key='' ")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_signal_lifecycle_event_key ON signal_lifecycle_events(event_key)")
    conn.commit()


def adaptive_gap_seconds(signal: dict[str, Any], *, now: datetime | None = None, floor_seconds: int = 300) -> int:
    """Return a quota-conscious observation cadence for one signal.

    New/deteriorating signals are observed more often; stable older signals back off.
    The floor keeps compatibility with the cooperative single-network scheduler.
    """
    from csm.config import settings

    now = now or datetime.now(timezone.utc)
    created = _parse(signal.get("created_at")) or now
    age = max(0.0, (now - created).total_seconds())
    state = str(signal.get("lifecycle_state") or "ACTIVE").upper()
    floor = max(60, int(floor_seconds or 60))

    if state == "DETERIORATING":
        return max(floor, int(getattr(settings, "signal_lifecycle_deteriorating_gap", 300)))
    if age <= 60 * 60:
        return max(floor, int(getattr(settings, "signal_lifecycle_recent_gap", 300)))
    if age <= 6 * 60 * 60:
        return max(floor, int(getattr(settings, "signal_lifecycle_active_gap", 600)))
    if age <= 24 * 60 * 60:
        return max(floor, int(getattr(settings, "signal_lifecycle_stable_gap", 900)))
    return max(floor, int(getattr(settings, "signal_lifecycle_old_gap", 1800)))


def evaluate(
    signal: dict[str, Any], market: dict[str, Any], *, captured_at: datetime, return_pct: float
) -> dict[str, Any]:
    """Evaluate lifecycle facts without changing the original approval/scoring."""
    from csm.config import settings

    initial_liq = _f(signal.get("liquidity"))
    initial_vol = _f(signal.get("volume24h"))
    current_liq = _f(market.get("liquidity"))
    current_vol = _f(market.get("volume24h"))
    liq_change = ((current_liq / initial_liq) - 1.0) * 100.0 if initial_liq > 0 and current_liq > 0 else 0.0
    vol_change = ((current_vol / initial_vol) - 1.0) * 100.0 if initial_vol > 0 and current_vol > 0 else 0.0

    initial_pressure = buy_pressure(signal.get("buys24h"), signal.get("sells24h"))
    pressure = buy_pressure(market.get("buys24h"), market.get("sells24h"))
    pressure_drop = (initial_pressure - pressure) if initial_pressure is not None and pressure is not None else 0.0

    initial_score = _i(signal.get("final_score"))
    current_score = _i(market.get("final_score") or market.get("opportunity_score") or market.get("score"))
    score_delta = current_score - initial_score if current_score > 0 and initial_score > 0 else 0

    reasons: list[str] = []
    severity = 0
    liq_warn = abs(_f(getattr(settings, "signal_lifecycle_liquidity_drop_pct", 30.0), 30.0))
    if initial_liq > 0 and current_liq > 0 and liq_change <= -liq_warn:
        reasons.append(f"liquidez {liq_change:.1f}% vs. entrada")
        severity += 50 if liq_change <= -(liq_warn + 20) else 35
    pressure_warn = abs(_f(getattr(settings, "signal_lifecycle_buy_pressure_drop_points", 15.0), 15.0))
    if pressure is not None and pressure_drop >= pressure_warn:
        reasons.append(f"pressão compradora caiu {pressure_drop:.1f} p.p.")
        severity += 25
    if pressure is not None and pressure < 42.0:
        reasons.append(f"pressão compradora baixa ({pressure:.1f}%)")
        severity += 15
    score_warn = abs(_i(getattr(settings, "signal_lifecycle_score_drop", 15), 15))
    if current_score > 0 and score_delta <= -score_warn:
        reasons.append(f"score observado caiu {abs(score_delta)} pontos")
        severity += 25
    if current_vol > 0 and initial_vol > 0 and vol_change <= -60.0:
        reasons.append(f"volume 24h caiu {abs(vol_change):.1f}%")
        severity += 15
    change1h = _f(market.get("change1h"))
    if change1h <= -12.0:
        reasons.append(f"momentum 1h negativo ({change1h:.1f}%)")
        severity += 20
    severity = min(100, severity)

    target1 = _f(signal.get("target1_pct"), 25.0)
    target2 = _f(signal.get("target2_pct"), 50.0)
    target3 = _f(signal.get("target3_pct"), _f(getattr(settings, "signal_lifecycle_target3_pct", 100.0), 100.0))
    stop = abs(_f(signal.get("stop_pct"), 12.0))
    created = _parse(signal.get("created_at")) or captured_at
    age = max(0.0, (captured_at - created).total_seconds())
    expire_hours = max(1, _i(getattr(settings, "signal_lifecycle_expire_hours", 168), 168))

    old_state = str(signal.get("lifecycle_state") or "ACTIVE").upper()
    state = old_state
    status = str(signal.get("status") or "ACTIVE").upper()
    closed_at = signal.get("closed_at")
    events: list[str] = []

    if return_pct <= -stop:
        state = "STOPPED"
        status = "COMPLETE"
        closed_at = closed_at or _iso(captured_at)
        if not signal.get("first_stop_at"):
            events.append("STOP")
    elif return_pct >= target3:
        state = "TP3"
        status = "COMPLETE"
        closed_at = closed_at or _iso(captured_at)
        if not signal.get("first_tp1_at"):
            events.append("TP1")
        if not signal.get("first_tp2_at"):
            events.append("TP2")
        if not signal.get("first_tp3_at"):
            events.append("TP3")
    elif age >= expire_hours * 3600:
        state = "EXPIRED"
        status = "COMPLETE"
        closed_at = closed_at or _iso(captured_at)
        if old_state != "EXPIRED":
            events.append("EXPIRED")
    else:
        if return_pct >= target2:
            state = "TP2"
            if not signal.get("first_tp1_at"):
                events.append("TP1")
            if not signal.get("first_tp2_at"):
                events.append("TP2")
        elif return_pct >= target1:
            state = "TP1"
            if not signal.get("first_tp1_at"):
                events.append("TP1")
        else:
            state = "ACTIVE"
        if severity >= 35:
            if old_state != "DETERIORATING":
                events.append("DETERIORATION")
            state = "DETERIORATING"
        elif old_state == "DETERIORATING":
            events.append("RECOVERED")

    # Never duplicate transition labels in a single observation.
    events = list(dict.fromkeys(events))
    gap = adaptive_gap_seconds({**signal, "lifecycle_state": state}, now=captured_at, floor_seconds=60)
    next_check = None if status == "COMPLETE" else _iso(captured_at + timedelta(seconds=gap))

    return {
        "state": state,
        "status": status,
        "closed_at": closed_at,
        "deterioration_score": severity,
        "reasons": reasons[:8],
        "buy_pressure_pct": pressure,
        "liquidity_change_pct": liq_change,
        "volume_change_pct": vol_change,
        "score_delta": score_delta,
        "events": events,
        "next_check_at": next_check,
        "next_gap_seconds": gap,
        "target3_pct": target3,
    }


def record_event(
    conn: sqlite3.Connection, signal_id: int, event_type: str, state: str, *, return_pct: float,
    price: float, deterioration_score: int = 0, reasons: list[str] | None = None, details: dict[str, Any] | None = None,
) -> bool:
    try:
        normalized = str(event_type).upper()
        if normalized in {"DETERIORATION", "RECOVERED"}:
            bucket = int(datetime.now(timezone.utc).timestamp()) // 1800
            event_key = f"{int(signal_id)}:{normalized}:{bucket}"
        else:
            event_key = f"{int(signal_id)}:{normalized}"
        conn.execute(
            """INSERT INTO signal_lifecycle_events(
                signal_id,event_key,event_type,state,return_pct,price,deterioration_score,reasons_json,details_json
            ) VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                int(signal_id), event_key, normalized, str(state).upper(), float(return_pct), float(price),
                int(deterioration_score), json.dumps(reasons or [], ensure_ascii=False),
                json.dumps(details or {}, ensure_ascii=False, sort_keys=True),
            ),
        )
        return True
    except sqlite3.IntegrityError:
        return False


def lifecycle_summary(conn: sqlite3.Connection, *, hours: int = 24, chain: str = "") -> dict[str, Any]:
    ensure_schema(conn)
    hours = max(1, min(int(hours), 24 * 90))
    params: list[Any] = [f"-{hours} hours"]
    where = "WHERE datetime(created_at)>=datetime('now', ?)"
    if chain:
        where += " AND lower(chain)=?"
        params.append(str(chain).lower())
    rows = conn.execute(
        f"""SELECT lifecycle_state,COUNT(*) AS qty,
                   AVG(CASE WHEN observations>0 THEN last_return_pct END) AS avg_return,
                   SUM(CASE WHEN observations>0 THEN 1 ELSE 0 END) AS observed
            FROM signal_ledger {where} GROUP BY lifecycle_state ORDER BY qty DESC""",
        params,
    ).fetchall()
    states = {str(r["lifecycle_state"] or "ACTIVE").upper(): int(r["qty"] or 0) for r in rows}
    total = sum(states.values())
    event_params: list[Any] = [f"-{hours} hours"]
    event_where = "WHERE datetime(e.created_at)>=datetime('now', ?)"
    if chain:
        event_where += " AND lower(s.chain)=?"
        event_params.append(str(chain).lower())
    events = conn.execute(
        f"""SELECT e.event_type,COUNT(*) AS qty FROM signal_lifecycle_events e
            JOIN signal_ledger s ON s.id=e.signal_id {event_where}
            GROUP BY e.event_type ORDER BY qty DESC""",
        event_params,
    ).fetchall()
    event_counts = {str(r["event_type"]): int(r["qty"] or 0) for r in events}
    deteriorating = conn.execute(
        f"""SELECT id,chain,symbol,name,last_return_pct,deterioration_score,deterioration_reasons_json,next_check_at
            FROM signal_ledger {where} AND lifecycle_state='DETERIORATING'
            ORDER BY deterioration_score DESC,updated_at DESC LIMIT 12""",
        params,
    ).fetchall()
    det = []
    for r in deteriorating:
        d = dict(r)
        try:
            d["reasons"] = json.loads(d.pop("deterioration_reasons_json") or "[]")
        except Exception:
            d["reasons"] = []
        det.append(d)
    return {
        "hours": hours, "chain": str(chain or "").lower(), "signals": total, "states": states,
        "events": event_counts, "deteriorating": det,
    }


def recent_events(conn: sqlite3.Connection, *, hours: int = 24, chain: str = "", limit: int = 30) -> list[dict[str, Any]]:
    ensure_schema(conn)
    hours = max(1, min(int(hours), 24 * 90))
    params: list[Any] = [f"-{hours} hours"]
    where = "WHERE datetime(e.created_at)>=datetime('now', ?)"
    if chain:
        where += " AND lower(s.chain)=?"
        params.append(str(chain).lower())
    params.append(max(1, min(int(limit), 200)))
    rows = conn.execute(
        f"""SELECT e.id,e.signal_id,e.event_type,e.state,e.return_pct,e.price,e.deterioration_score,
                   e.reasons_json,e.details_json,e.notified_at,e.created_at,s.chain,s.symbol,s.name,s.address
            FROM signal_lifecycle_events e JOIN signal_ledger s ON s.id=e.signal_id
            {where} ORDER BY e.id DESC LIMIT ?""",
        params,
    ).fetchall()
    out=[]
    for row in rows:
        d=dict(row)
        for key, fallback in (("reasons_json", []),("details_json", {})):
            try: d[key[:-5]] = json.loads(d.pop(key) or json.dumps(fallback))
            except Exception: d[key[:-5]] = fallback
        out.append(d)
    return out
