from __future__ import annotations

"""V16.6.0 Signal Outcome Learning — evidence-only outcome intelligence.

This layer learns from *delivered* signals and their append-only performance
ledger.  It can generate evidence snapshots and recommendations, but it has no
code path that mutates scanner filters, scoring, plan delivery, or live signal
eligibility.  Automatic optimization is intentionally out of scope for V16.6.0.
"""

import json
import math
import statistics
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Iterable

from .config import settings
from .performance import PerformanceLedger

VERSION = "16.6.0-signal-outcome-learning"
MODE = "EVIDENCE_ONLY"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _split_csv(value: Any) -> list[str]:
    return [part.strip() for part in str(value or "").split(",") if part.strip()]


def _decode_list(value: Any) -> list[str]:
    if isinstance(value, (list, tuple)):
        return [str(item).strip() for item in value if str(item).strip()]
    try:
        decoded = json.loads(str(value or "[]"))
        if isinstance(decoded, list):
            return [str(item).strip() for item in decoded if str(item).strip()]
    except Exception:
        pass
    return []


def _provider_family(value: str) -> str:
    text = str(value or "").strip().casefold().replace(" ", "")
    aliases = (
        ("dexpaprika", "dexpaprika"),
        ("dexscreener", "dexscreener"),
        ("geckoterminal", "geckoterminal"),
        ("birdeye", "birdeye"),
        ("coingecko", "coingecko"),
        ("goplus", "goplus"),
        ("honeypot", "honeypot"),
    )
    for needle, family in aliases:
        if needle in text:
            return family
    return text or "unknown"


def _score_band(score: float) -> str:
    if score >= 90:
        return "90-100"
    if score >= 80:
        return "80-89"
    if score >= 70:
        return "70-79"
    if score >= 60:
        return "60-69"
    return "0-59"


def _liquidity_band(value: float) -> str:
    if value < 25_000:
        return "<25k"
    if value < 50_000:
        return "25k-50k"
    if value < 100_000:
        return "50k-100k"
    if value < 250_000:
        return "100k-250k"
    if value < 1_000_000:
        return "250k-1m"
    return ">=1m"


def _volume_band(value: float) -> str:
    if value < 50_000:
        return "<50k"
    if value < 100_000:
        return "50k-100k"
    if value < 250_000:
        return "100k-250k"
    if value < 1_000_000:
        return "250k-1m"
    return ">=1m"


def _parse_dt(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _tp_before_stop(row: dict[str, Any]) -> bool:
    tp = _parse_dt(row.get("first_tp1_at"))
    stop = _parse_dt(row.get("first_stop_at"))
    if tp is None:
        return False
    if stop is None:
        return True
    return tp <= stop


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS signal_outcome_learning_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version TEXT NOT NULL,
            mode TEXT NOT NULL,
            lookback_days INTEGER NOT NULL,
            signals_total INTEGER DEFAULT 0,
            signals_observed INTEGER DEFAULT 0,
            global_json TEXT DEFAULT '{}',
            segments_json TEXT DEFAULT '[]',
            recommendations_json TEXT DEFAULT '[]',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_signal_outcome_learning_runs_created
        ON signal_outcome_learning_runs(created_at DESC);
        """
    )
    conn.commit()


@dataclass
class _Bucket:
    signals: int = 0
    wins: int = 0
    tp1: int = 0
    tp2: int = 0
    stops: int = 0
    return_sum: float = 0.0
    max_return_sum: float = 0.0
    drawdown_sum: float = 0.0

    def add(self, row: dict[str, Any]) -> None:
        self.signals += 1
        last_return = _f(row.get("last_return_pct"))
        self.wins += int(_tp_before_stop(row) or (not row.get("first_stop_at") and last_return > 0))
        self.tp1 += int(bool(row.get("first_tp1_at")))
        self.tp2 += int(bool(row.get("first_tp2_at")))
        self.stops += int(bool(row.get("first_stop_at")))
        self.return_sum += last_return
        self.max_return_sum += _f(row.get("max_return_pct"))
        self.drawdown_sum += _f(row.get("max_drawdown_pct"))

    def finalize(self, *, prior_rate: float, prior_strength: float, min_samples: int) -> dict[str, Any]:
        n = max(0, int(self.signals))
        if n <= 0:
            return {
                "signals": 0,
                "wins": 0,
                "win_rate_pct": 0.0,
                "smoothed_win_rate_pct": round(prior_rate * 100.0, 2),
                "tp1_hit_rate_pct": 0.0,
                "tp2_hit_rate_pct": 0.0,
                "stop_touch_rate_pct": 0.0,
                "average_last_return_pct": 0.0,
                "average_max_return_pct": 0.0,
                "average_drawdown_pct": 0.0,
                "confidence_pct": 0.0,
                "enough_samples": False,
            }
        raw_rate = self.wins / n
        smoothed = (self.wins + prior_rate * prior_strength) / (n + prior_strength)
        confidence = min(100.0, n / max(1, min_samples) * 100.0)
        return {
            "signals": n,
            "wins": int(self.wins),
            "win_rate_pct": round(raw_rate * 100.0, 2),
            "smoothed_win_rate_pct": round(smoothed * 100.0, 2),
            "tp1_hit_rate_pct": round(self.tp1 / n * 100.0, 2),
            "tp2_hit_rate_pct": round(self.tp2 / n * 100.0, 2),
            "stop_touch_rate_pct": round(self.stops / n * 100.0, 2),
            "average_last_return_pct": round(self.return_sum / n, 2),
            "average_max_return_pct": round(self.max_return_sum / n, 2),
            "average_drawdown_pct": round(self.drawdown_sum / n, 2),
            "confidence_pct": round(confidence, 1),
            "enough_samples": n >= min_samples,
        }


class SignalOutcomeLearning:
    """Evidence-only learning over delivered-signal outcomes."""

    def __init__(self, storage):
        self.storage = storage
        self.conn = storage.conn
        ensure_schema(self.conn)
        self.ledger = PerformanceLedger(storage)

    def _segment_keys(self, row: dict[str, Any]) -> Iterable[tuple[str, str]]:
        chain = str(row.get("chain") or "unknown").strip().lower() or "unknown"
        yield "chain", chain

        providers = _decode_list(row.get("providers_json"))
        if not providers and row.get("source"):
            providers = [str(row.get("source"))]
        families = list(dict.fromkeys(_provider_family(provider) for provider in providers if provider)) or ["unknown"]
        for family in families:
            yield "provider", family
            yield "chain_provider", f"{chain}:{family}"

        yield "score_band", _score_band(_f(row.get("final_score")))
        yield "liquidity_band", _liquidity_band(_f(row.get("liquidity")))
        yield "volume_band", _volume_band(_f(row.get("volume24h")))

        plans = _split_csv(row.get("plan_groups")) or ["unknown"]
        for plan in dict.fromkeys(plans):
            yield "plan", plan.lower()

    def _observed_rows(self, days: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        rows = self.ledger.signals(days=days, limit=10000)
        observed = [dict(row) for row in rows if _i(row.get("observations")) > 0]
        return rows, observed

    def build(self, *, days: int | None = None) -> dict[str, Any]:
        days = max(1, int(days or getattr(settings, "signal_outcome_learning_lookback_days", 30)))
        min_samples = max(2, int(getattr(settings, "signal_outcome_learning_min_samples", 12)))
        prior_strength = max(1.0, float(getattr(settings, "signal_outcome_learning_prior_strength", 8.0)))
        rows, observed = self._observed_rows(days)

        global_bucket = _Bucket()
        buckets: dict[tuple[str, str], _Bucket] = {}
        for row in observed:
            global_bucket.add(row)
            for key in self._segment_keys(row):
                buckets.setdefault(key, _Bucket()).add(row)

        empirical_prior = (global_bucket.wins / global_bucket.signals) if global_bucket.signals else 0.25
        prior_rate = min(0.95, max(0.05, empirical_prior))
        global_metrics = global_bucket.finalize(
            prior_rate=prior_rate,
            prior_strength=prior_strength,
            min_samples=min_samples,
        )

        segments: list[dict[str, Any]] = []
        for (dimension, key), bucket in buckets.items():
            metrics = bucket.finalize(
                prior_rate=prior_rate,
                prior_strength=prior_strength,
                min_samples=min_samples,
            )
            metrics.update({"dimension": dimension, "segment": key})
            segments.append(metrics)
        segments.sort(key=lambda row: (row["dimension"], -int(row["signals"]), str(row["segment"])))

        recommendations: list[dict[str, Any]] = []
        global_win = _f(global_metrics.get("smoothed_win_rate_pct"))
        global_return = _f(global_metrics.get("average_last_return_pct"))
        global_stop = _f(global_metrics.get("stop_touch_rate_pct"))
        for row in segments:
            if not row.get("enough_samples"):
                continue
            delta_win = _f(row.get("smoothed_win_rate_pct")) - global_win
            delta_return = _f(row.get("average_last_return_pct")) - global_return
            delta_stop = _f(row.get("stop_touch_rate_pct")) - global_stop
            action = "OBSERVE"
            reason = "desempenho próximo do baseline"
            if delta_win >= 8.0 and delta_return > 0.0 and delta_stop <= 5.0:
                action = "PROMISING"
                reason = "win suavizado e retorno acima do baseline"
            elif delta_win <= -8.0 or delta_stop >= 12.0:
                action = "CAUTION"
                reason = "win abaixo do baseline ou stop significativamente maior"
            elif delta_return >= 3.0:
                action = "PROMISING"
                reason = "retorno médio acima do baseline"
            recommendations.append({
                "dimension": row["dimension"],
                "segment": row["segment"],
                "action": action,
                "signals": row["signals"],
                "confidence_pct": row["confidence_pct"],
                "delta_win_pp": round(delta_win, 2),
                "delta_return_pp": round(delta_return, 2),
                "delta_stop_pp": round(delta_stop, 2),
                "reason": reason,
                "live_impact": False,
            })
        order = {"PROMISING": 0, "CAUTION": 1, "OBSERVE": 2}
        recommendations.sort(key=lambda row: (order.get(row["action"], 9), -_f(row["confidence_pct"]), -int(row["signals"])))

        perf = self.ledger.report(days=days)
        return {
            "version": VERSION,
            "mode": MODE,
            "generated_at": _iso(),
            "lookback_days": days,
            "signals_total": len(rows),
            "signals_observed": len(observed),
            "observation_coverage_pct": round(len(observed) / len(rows) * 100.0, 2) if rows else 0.0,
            "min_samples": min_samples,
            "prior_strength": prior_strength,
            "global": global_metrics,
            "horizons": perf.get("horizons") or {},
            "segments": segments,
            "recommendations": recommendations,
            "safety": {
                "live_impact": False,
                "changes_filters": False,
                "changes_scoring": False,
                "changes_delivery": False,
                "auto_apply_available": False,
                "human_approval_required_for_future_optimization": True,
            },
            "methodology": (
                "Aprende apenas com sinais efetivamente entregues e observações append-only. "
                "Segmenta por rede, provider, score, liquidez, volume e plano; usa suavização "
                "Bayesiana para reduzir conclusões de amostra pequena. V16.6.0 é evidence-only."
            ),
        }

    def run(self, *, days: int | None = None, persist: bool = True) -> dict[str, Any]:
        report = self.build(days=days)
        if persist:
            self.conn.execute(
                """INSERT INTO signal_outcome_learning_runs(
                       version,mode,lookback_days,signals_total,signals_observed,
                       global_json,segments_json,recommendations_json,created_at
                   ) VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    report["version"], report["mode"], report["lookback_days"],
                    report["signals_total"], report["signals_observed"],
                    json.dumps(report["global"], ensure_ascii=False),
                    json.dumps(report["segments"], ensure_ascii=False),
                    json.dumps(report["recommendations"], ensure_ascii=False),
                    report["generated_at"],
                ),
            )
            self.conn.commit()
            self._persist_snapshot(report)
        return report

    def _persist_snapshot(self, report: dict[str, Any]) -> Path:
        target = settings.data_dir / "reports" / "signal_outcome_learning.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_suffix(".tmp")
        temp.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
        temp.replace(target)
        return target

    def latest(self) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM signal_outcome_learning_runs ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        data = dict(row)
        for key in ("global_json", "segments_json", "recommendations_json"):
            default_json = "{}" if key == "global_json" else "[]"
            try:
                data[key.removesuffix("_json")] = json.loads(str(data.get(key) or default_json))
            except Exception:
                data[key.removesuffix("_json")] = {} if key == "global_json" else []
        return data

    def status(self) -> dict[str, Any]:
        latest = self.latest()
        return {
            "version": VERSION,
            "mode": MODE,
            "enabled": bool(getattr(settings, "signal_outcome_learning_enabled", True)),
            "auto_apply_available": False,
            "live_impact": False,
            "lookback_days": int(getattr(settings, "signal_outcome_learning_lookback_days", 30)),
            "interval_seconds": int(getattr(settings, "signal_outcome_learning_interval_seconds", 1800)),
            "min_samples": int(getattr(settings, "signal_outcome_learning_min_samples", 12)),
            "latest_run": latest,
        }

    def recommendations(self, *, days: int | None = None, limit: int = 20) -> list[dict[str, Any]]:
        return list(self.build(days=days).get("recommendations") or [])[:max(1, int(limit))]
