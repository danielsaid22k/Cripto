from __future__ import annotations

from collections import defaultdict
from statistics import mean
from typing import Any


QUALITY_VERSION = "16.4.9"


def _num(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _text(value: Any, default: str = "unknown") -> str:
    value = str(value or "").strip()
    return value or default


def score_band(score: Any) -> str:
    value = _num(score)

    if value >= 90:
        return "90-100"
    if value >= 80:
        return "80-89"
    if value >= 70:
        return "70-79"
    if value >= 60:
        return "60-69"
    return "<60"


def liquidity_band(value: Any) -> str:
    value = _num(value)

    if value >= 500_000:
        return "500k+"
    if value >= 200_000:
        return "200k-499k"
    if value >= 100_000:
        return "100k-199k"
    if value >= 50_000:
        return "50k-99k"
    return "<50k"


def classify_result(row: dict[str, Any]) -> str:
    ret = _num(
        row.get("return_pct")
        or row.get("shadow_return_pct")
        or row.get("pnl_pct")
    )

    if ret > 0:
        return "WIN"
    if ret < 0:
        return "LOSS"
    return "FLAT"


def probable_loss_reasons(row: dict[str, Any]) -> list[str]:
    reasons: list[str] = []

    liquidity = _num(
        row.get("liquidity_usd")
        or row.get("liquidity")
    )

    volume = _num(
        row.get("volume_24h_usd")
        or row.get("volume_24h")
        or row.get("volume_usd")
    )

    buy_pressure = _num(
        row.get("buy_pressure_pct")
        or row.get("buy_pressure")
    )

    score = _num(row.get("score"))

    goplus = _text(
        row.get("goplus_risk_level"),
        "",
    ).lower()

    provider_count = int(
        _num(
            row.get("provider_count")
            or row.get("provider_agreement")
            or 1
        )
    )

    if liquidity and liquidity < 50_000:
        reasons.append("LOW_LIQUIDITY")

    if volume and volume < 25_000:
        reasons.append("LOW_VOLUME")

    if buy_pressure and buy_pressure < 50:
        reasons.append("WEAK_BUY_PRESSURE")

    if score and score < 70:
        reasons.append("LOW_SCORE")

    if goplus in {
        "high",
        "critical",
        "danger",
        "risky",
    }:
        reasons.append("SECURITY_RISK")

    if provider_count <= 1:
        reasons.append("SINGLE_PROVIDER")

    return reasons or ["UNDETERMINED"]


def shadow_quality_decision(
    row: dict[str, Any],
) -> dict[str, Any]:
    reasons: list[str] = []

    score = _num(row.get("score"))

    liquidity = _num(
        row.get("liquidity_usd")
        or row.get("liquidity")
    )

    volume = _num(
        row.get("volume_24h_usd")
        or row.get("volume_24h")
        or row.get("volume_usd")
    )

    buy_pressure = _num(
        row.get("buy_pressure_pct")
        or row.get("buy_pressure")
    )

    providers = int(
        _num(
            row.get("provider_count")
            or row.get("provider_agreement")
            or 1
        )
    )

    if score and score < 70:
        reasons.append("score_below_70")

    if liquidity and liquidity < 50_000:
        reasons.append("liquidity_below_50k")

    if volume and volume < 25_000:
        reasons.append("volume_below_25k")

    if buy_pressure and buy_pressure < 50:
        reasons.append("buy_pressure_below_50")

    if providers <= 1:
        reasons.append("single_provider")

    approved = len(reasons) == 0

    return {
        "mode": "SHADOW",
        "approved": approved,
        "reasons": reasons,
        "would_block": not approved,
    }


def _group_stats(
    rows: list[dict[str, Any]],
    key_name: str,
) -> list[dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for row in rows:
        value = _text(row.get(key_name))
        groups[value].append(row)

    output = []

    for key, items in groups.items():
        returns = [
            _num(
                item.get("return_pct")
                or item.get("shadow_return_pct")
                or item.get("pnl_pct")
            )
            for item in items
        ]

        wins = sum(
            1
            for item in items
            if classify_result(item) == "WIN"
        )

        losses = sum(
            1
            for item in items
            if classify_result(item) == "LOSS"
        )

        total = len(items)

        output.append({
            key_name: key,
            "samples": total,
            "wins": wins,
            "losses": losses,
            "win_rate_pct": round(
                (wins / total * 100)
                if total
                else 0.0,
                2,
            ),
            "average_return_pct": round(
                mean(returns)
                if returns
                else 0.0,
                2,
            ),
        })

    return sorted(
        output,
        key=lambda row: (
            -row["samples"],
            -row["win_rate_pct"],
        ),
    )


def analyze_signal_quality(
    rows: list[dict[str, Any]],
) -> dict[str, Any]:
    normalized = []

    shadow_approved = 0
    shadow_rejected = 0

    loss_reasons: dict[str, int] = defaultdict(int)

    for source in rows:
        row = dict(source)

        row["chain"] = _text(
            row.get("chain")
            or row.get("network")
        )

        row["provider"] = _text(
            row.get("provider")
            or row.get("source")
        )

        row["score_band"] = score_band(
            row.get("score")
        )

        row["liquidity_band"] = liquidity_band(
            row.get("liquidity_usd")
            or row.get("liquidity")
        )

        result = classify_result(row)
        row["result"] = result

        shadow = shadow_quality_decision(row)
        row["shadow_quality"] = shadow

        if shadow["approved"]:
            shadow_approved += 1
        else:
            shadow_rejected += 1

        if result == "LOSS":
            for reason in probable_loss_reasons(row):
                loss_reasons[reason] += 1

        normalized.append(row)

    total = len(normalized)

    wins = sum(
        1
        for row in normalized
        if row["result"] == "WIN"
    )

    losses = sum(
        1
        for row in normalized
        if row["result"] == "LOSS"
    )

    returns = [
        _num(
            row.get("return_pct")
            or row.get("shadow_return_pct")
            or row.get("pnl_pct")
        )
        for row in normalized
    ]

    reasons_ranked = [
        {
            "reason": reason,
            "count": count,
        }
        for reason, count in sorted(
            loss_reasons.items(),
            key=lambda item: -item[1],
        )
    ]

    return {
        "version": QUALITY_VERSION,
        "mode": "SHADOW",
        "promotion_enabled": False,
        "samples": total,
        "wins": wins,
        "losses": losses,
        "win_rate_pct": round(
            (wins / total * 100)
            if total
            else 0.0,
            2,
        ),
        "average_return_pct": round(
            mean(returns)
            if returns
            else 0.0,
            2,
        ),
        "shadow_approved": shadow_approved,
        "shadow_rejected": shadow_rejected,
        "loss_reasons": reasons_ranked,
        "by_chain": _group_stats(
            normalized,
            "chain",
        ),
        "by_provider": _group_stats(
            normalized,
            "provider",
        ),
        "by_score_band": _group_stats(
            normalized,
            "score_band",
        ),
        "by_liquidity_band": _group_stats(
            normalized,
            "liquidity_band",
        ),
        "methodology": (
            "Evidence-only. Analisa sinais existentes e "
            "simula filtros em SHADOW. Não altera score, "
            "aprovação, entrega, Telegram, Discord ou lifecycle."
        ),
    }
