from __future__ import annotations

from typing import Any

from .signal_quality_intelligence import (
    analyze_signal_quality,
)
from .quality_promotion import attach_promotion
from .shadow_evidence_overview import attach_shadow_evidence
from .evidence_attribution_runtime import attach_evidence_attribution


def _find_rows(value: Any) -> list[dict]:
    if isinstance(value, list):
        rows = [
            row for row in value
            if isinstance(row, dict)
        ]

        if rows:
            useful = [
                row for row in rows
                if any(
                    key in row
                    for key in (
                        "return_pct",
                        "shadow_return_pct",
                        "pnl_pct",
                    )
                )
            ]

            if useful:
                return useful

    if isinstance(value, dict):
        preferred = (
            "signal_outcomes",
            "outcomes",
            "observations",
            "recent_signals",
            "signals",
            "rows",
        )

        for key in preferred:
            if key in value:
                found = _find_rows(value[key])
                if found:
                    return found

        for child in value.values():
            found = _find_rows(child)
            if found:
                return found

    return []


def build_signal_quality_overview(
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    performance = snapshot.get("performance") or {}

    rows = _find_rows(performance)

    if rows:
        report = analyze_signal_quality(rows)
        report["analysis_source"] = "performance_evidence"
        report["evidence_rows"] = len(rows)
        return attach_evidence_attribution(attach_shadow_evidence(attach_promotion(report), queue_override=performance.get("shadow_queue")), performance)

    shadow = (
        performance.get("signal_quality_shadow")
        or {}
    )

    samples = int(
        shadow.get("signals_with_baseline")
        or shadow.get("signals_total")
        or 0
    )

    confirmed = int(
        shadow.get("shadow_confirmed")
        or 0
    )

    missing = int(
        shadow.get("shadow_missing")
        or 0
    )

    report = {
        "version": "16.4.9",
        "mode": "SHADOW",
        "promotion_enabled": False,
        "analysis_source": "shadow_summary",
        "samples": samples,
        "wins": None,
        "losses": None,
        "win_rate_pct": (
            shadow.get("shadow_positive_rate_pct")
        ),
        "average_return_pct": (
            shadow.get("average_shadow_return_pct")
        ),
        "shadow_confirmed": confirmed,
        "shadow_missing": missing,
        "shadow_coverage_pct": (
            shadow.get("shadow_coverage_pct")
        ),
        "average_shadow_age_seconds": (
            shadow.get("average_shadow_age_seconds")
        ),
        "median_shadow_age_seconds": (
            shadow.get("median_shadow_age_seconds")
        ),
        "average_liquidity_change_pct": (
            shadow.get("average_liquidity_change_pct")
        ),
        "average_volume_change_pct": (
            shadow.get("average_volume_change_pct")
        ),
        "average_buy_pressure_pct": (
            shadow.get("average_buy_pressure_pct")
        ),
        "average_score_delta": (
            shadow.get("average_score_delta")
        ),
        "by_chain": [],
        "by_provider": [],
        "loss_reasons": [],
        "methodology": (
            "Evidence-only. Usa exclusivamente dados "
            "já produzidos pelo CSM. SHADOW não altera "
            "score, aprovação, lifecycle, Telegram, "
            "Discord, SaaS ou entrega."
        ),
        }

    return attach_evidence_attribution(attach_shadow_evidence(attach_promotion(report), queue_override=performance.get("shadow_queue")), performance)
