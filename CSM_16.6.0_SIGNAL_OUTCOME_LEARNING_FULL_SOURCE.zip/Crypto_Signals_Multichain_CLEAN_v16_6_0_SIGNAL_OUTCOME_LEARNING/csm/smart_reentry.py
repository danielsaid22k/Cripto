from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Any

from .config import settings


STRICT_PRIOR_STATES = {"STOPPED", "DETERIORATING", "TP3"}


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _utc_now()).astimezone(timezone.utc).isoformat()


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _canonical_chain(value: Any) -> str:
    return str(value or "").strip().lower()


def _canonical_address(value: Any) -> str:
    return str(value or "").strip()


def _buy_pressure(item: dict[str, Any]) -> float | None:
    explicit = item.get("buy_pressure_pct")
    if explicit is not None:
        try:
            return float(explicit)
        except (TypeError, ValueError):
            pass
    buys = _i(item.get("buys24h"))
    sells = _i(item.get("sells24h"))
    total = buys + sells
    if total <= 0:
        return None
    return (buys / total) * 100.0


def cooldown_hours(plan_group: str) -> int:
    group = str(plan_group or "free").strip().lower()
    if group == "premium":
        return max(1, int(getattr(settings, "signal_reentry_cooldown_premium_hours", 6)))
    if group == "plus":
        return max(1, int(getattr(settings, "signal_reentry_cooldown_plus_hours", 12)))
    return max(1, int(getattr(settings, "signal_reentry_cooldown_free_hours", 24)))


def ensure_schema(conn) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS signal_reentry_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            symbol TEXT DEFAULT '',
            name TEXT DEFAULT '',
            plan_group TEXT NOT NULL,
            delivery_kind TEXT NOT NULL DEFAULT 'INITIAL',
            signal_id INTEGER,
            parent_signal_id INTEGER,
            prior_lifecycle_state TEXT DEFAULT '',
            cooldown_hours INTEGER DEFAULT 0,
            score INTEGER DEFAULT 0,
            evidence_json TEXT DEFAULT '{}',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_signal_reentry_user_asset
        ON signal_reentry_history(user_id, chain, address, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_signal_reentry_created
        ON signal_reentry_history(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_signal_reentry_signal
        ON signal_reentry_history(signal_id);
        """
    )
    conn.commit()


@dataclass(frozen=True)
class ReentryDecision:
    allowed: bool
    is_reentry: bool
    delivery_kind: str
    plan_group: str
    cooldown_hours: int
    elapsed_hours: float | None
    remaining_hours: float
    prior_delivery_at: str
    parent_signal_id: int | None
    prior_lifecycle_state: str
    strict_revalidation: bool
    improvement_reasons: tuple[str, ...]
    block_reason: str
    metrics: dict[str, Any]

    def public_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["improvement_reasons"] = list(self.improvement_reasons)
        return data


class SmartReentry:
    """Plan-aware reentry gate for scanner-approved candidates.

    The caller must supply only candidates approved by the *current* scanner.
    This class never approves a rejected token and never changes scoring. It
    only decides whether an already-delivered asset may be delivered again.
    """

    def __init__(self, storage, performance=None):
        self.storage = storage
        self.conn = storage.conn
        self.performance = performance
        ensure_schema(self.conn)

    def _latest_history(self, user_id: int, chain: str, address: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            """SELECT * FROM signal_reentry_history
               WHERE user_id=? AND chain=? AND lower(address)=lower(?)
               ORDER BY id DESC LIMIT 1""",
            (int(user_id), chain, address),
        ).fetchone()
        if row:
            return dict(row)
        # Upgrade compatibility: use the old dedup row as the first historical
        # delivery until V16.4 records its own append-only history.
        row = self.conn.execute(
            """SELECT created_at,score FROM alert_deliveries
               WHERE user_id=? AND chain=? AND lower(address)=lower(?)
                 AND alert_type='entry' AND confirmed=1
               ORDER BY created_at DESC LIMIT 1""",
            (int(user_id), chain, address),
        ).fetchone()
        if not row:
            return None
        return {
            "created_at": row["created_at"],
            "score": row["score"],
            "delivery_kind": "LEGACY",
            "signal_id": None,
        }

    def _latest_signal(self, chain: str, address: str) -> dict[str, Any] | None:
        try:
            row = self.conn.execute(
                """SELECT * FROM signal_ledger
                   WHERE chain=? AND lower(address)=lower(?)
                   ORDER BY id DESC LIMIT 1""",
                (chain, address),
            ).fetchone()
        except Exception:
            return None
        return dict(row) if row else None

    def _latest_observation(self, signal_id: int) -> dict[str, Any] | None:
        try:
            row = self.conn.execute(
                """SELECT * FROM signal_observations
                   WHERE signal_id=? ORDER BY captured_at DESC,id DESC LIMIT 1""",
                (int(signal_id),),
            ).fetchone()
        except Exception:
            return None
        return dict(row) if row else None

    def _improvements(self, item: dict[str, Any], prior: dict[str, Any], observation: dict[str, Any] | None) -> tuple[list[str], dict[str, Any]]:
        reasons: list[str] = []
        metrics: dict[str, Any] = {}

        current_score = _i(item.get("final_score") or item.get("opportunity_score") or item.get("score"))
        prior_score = _i(prior.get("final_score") or prior.get("market_score")) + _i(prior.get("last_score_delta"))
        score_delta = current_score - prior_score
        metrics.update(current_score=current_score, prior_score=prior_score, score_delta=score_delta)
        if score_delta >= int(getattr(settings, "signal_reentry_score_improvement", 3)):
            reasons.append(f"score +{score_delta} pontos")

        current_liq = _f(item.get("liquidity"))
        prior_liq = _f((observation or {}).get("liquidity")) or _f(prior.get("liquidity"))
        liq_change = ((current_liq / prior_liq) - 1.0) * 100.0 if current_liq > 0 and prior_liq > 0 else 0.0
        metrics.update(current_liquidity=current_liq, prior_liquidity=prior_liq, liquidity_change_pct=liq_change)
        if liq_change >= float(getattr(settings, "signal_reentry_liquidity_improvement_pct", 10.0)):
            reasons.append(f"liquidez +{liq_change:.1f}%")

        current_bp = _buy_pressure(item)
        prior_bp = prior.get("last_buy_pressure_pct")
        if prior_bp is None:
            prior_bp = _buy_pressure(prior)
        bp_delta = (float(current_bp) - float(prior_bp)) if current_bp is not None and prior_bp is not None else 0.0
        metrics.update(current_buy_pressure_pct=current_bp, prior_buy_pressure_pct=prior_bp, buy_pressure_delta=bp_delta)
        if current_bp is not None and prior_bp is not None and bp_delta >= float(getattr(settings, "signal_reentry_buy_pressure_improvement_points", 5.0)):
            reasons.append(f"buyer pressure +{bp_delta:.1f} p.p.")

        current_volume = _f(item.get("volume24h"))
        prior_volume = _f((observation or {}).get("volume24h")) or _f(prior.get("volume24h"))
        volume_ratio = current_volume / prior_volume if current_volume > 0 and prior_volume > 0 else 0.0
        metrics.update(current_volume24h=current_volume, prior_volume24h=prior_volume, volume_ratio=volume_ratio)
        if volume_ratio >= float(getattr(settings, "signal_reentry_volume_ratio", 1.20)):
            reasons.append(f"volume {volume_ratio:.2f}x")

        current_momentum = _f(item.get("change1h"))
        prior_momentum = _f((observation or {}).get("change1h"))
        momentum_delta = current_momentum - prior_momentum
        metrics.update(current_change1h=current_momentum, prior_change1h=prior_momentum, momentum_delta=momentum_delta)
        if current_momentum and momentum_delta >= float(getattr(settings, "signal_reentry_momentum_improvement_points", 5.0)):
            reasons.append(f"momentum 1h +{momentum_delta:.1f} p.p.")

        return reasons, metrics

    def evaluate(self, *, user_id: int, plan_group: str, item: dict[str, Any], now: datetime | None = None) -> ReentryDecision:
        now = now or _utc_now()
        group = str(plan_group or "free").strip().lower()
        chain = _canonical_chain(item.get("chain"))
        address = _canonical_address(item.get("address"))
        cd_hours = cooldown_hours(group)

        if not bool(getattr(settings, "signal_reentry_enabled", True)):
            # Legacy behavior when explicitly disabled: old dedup still blocks
            # until its global pruning window has passed.
            exists = self.storage.alert_delivery_exists(user_id, chain, address, "entry")
            return ReentryDecision(
                allowed=not exists, is_reentry=exists, delivery_kind="INITIAL" if not exists else "BLOCKED",
                plan_group=group, cooldown_hours=cd_hours, elapsed_hours=None, remaining_hours=0.0,
                prior_delivery_at="", parent_signal_id=None, prior_lifecycle_state="",
                strict_revalidation=False, improvement_reasons=(),
                block_reason="deduplicação legada ativa" if exists else "", metrics={},
            )

        previous = self._latest_history(user_id, chain, address)
        if previous is None:
            return ReentryDecision(
                allowed=True, is_reentry=False, delivery_kind="INITIAL", plan_group=group,
                cooldown_hours=cd_hours, elapsed_hours=None, remaining_hours=0.0,
                prior_delivery_at="", parent_signal_id=None, prior_lifecycle_state="",
                strict_revalidation=False, improvement_reasons=(), block_reason="", metrics={"current_revalidated": True},
            )

        previous_at = _parse(previous.get("created_at"))
        elapsed_hours = ((now - previous_at).total_seconds() / 3600.0) if previous_at else None
        remaining = max(0.0, cd_hours - (elapsed_hours if elapsed_hours is not None else 0.0))
        if elapsed_hours is None or elapsed_hours < cd_hours:
            return ReentryDecision(
                allowed=False, is_reentry=True, delivery_kind="BLOCKED", plan_group=group,
                cooldown_hours=cd_hours, elapsed_hours=elapsed_hours, remaining_hours=remaining,
                prior_delivery_at=str(previous.get("created_at") or ""), parent_signal_id=None,
                prior_lifecycle_state="", strict_revalidation=False, improvement_reasons=(),
                block_reason=f"cooldown do plano ainda ativo ({remaining:.2f}h restantes)",
                metrics={"current_revalidated": True},
            )

        prior = self._latest_signal(chain, address)
        if prior is None:
            return ReentryDecision(
                allowed=True, is_reentry=True, delivery_kind="REENTRY", plan_group=group,
                cooldown_hours=cd_hours, elapsed_hours=elapsed_hours, remaining_hours=0.0,
                prior_delivery_at=str(previous.get("created_at") or ""), parent_signal_id=None,
                prior_lifecycle_state="UNKNOWN", strict_revalidation=False,
                improvement_reasons=("reencontrado e aprovado novamente pelos filtros atuais",),
                block_reason="", metrics={"current_revalidated": True},
            )

        state = str(prior.get("lifecycle_state") or prior.get("status") or "ACTIVE").upper()
        observation = self._latest_observation(int(prior.get("id") or 0))
        improvements, metrics = self._improvements(item, prior, observation)
        metrics["current_revalidated"] = True
        strict = state in STRICT_PRIOR_STATES
        allowed = bool(improvements) if strict else True
        reasons = list(improvements)
        if not strict:
            reasons.insert(0, "reencontrado e aprovado novamente pelos filtros atuais")
        block_reason = ""
        if strict and not allowed:
            block_reason = f"estado anterior {state} exige melhora material antes da reentrada"

        return ReentryDecision(
            allowed=allowed, is_reentry=True, delivery_kind="REENTRY" if allowed else "BLOCKED",
            plan_group=group, cooldown_hours=cd_hours, elapsed_hours=elapsed_hours, remaining_hours=0.0,
            prior_delivery_at=str(previous.get("created_at") or ""),
            parent_signal_id=int(prior.get("id") or 0) or None, prior_lifecycle_state=state,
            strict_revalidation=strict, improvement_reasons=tuple(reasons), block_reason=block_reason,
            metrics=metrics,
        )

    def record_confirmed_delivery(
        self, *, user_id: int, item: dict[str, Any], decision: ReentryDecision,
        signal_id: int | None, score: int, now: datetime | None = None,
    ) -> int:
        now = now or _utc_now()
        chain = _canonical_chain(item.get("chain"))
        address = _canonical_address(item.get("address"))
        evidence = decision.public_dict()
        cursor = self.conn.execute(
            """INSERT INTO signal_reentry_history(
                   user_id,chain,address,symbol,name,plan_group,delivery_kind,signal_id,parent_signal_id,
                   prior_lifecycle_state,cooldown_hours,score,evidence_json,created_at
               ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                int(user_id), chain, address, str(item.get("symbol") or "")[:64], str(item.get("name") or "")[:120],
                decision.plan_group, decision.delivery_kind, int(signal_id) if signal_id else None,
                decision.parent_signal_id, decision.prior_lifecycle_state, int(decision.cooldown_hours), int(score),
                json.dumps(evidence, ensure_ascii=False, sort_keys=True), _iso(now),
            ),
        )
        # Keep the append-only evidence useful without unbounded growth.
        cutoff = _iso(now - timedelta(days=max(30, int(getattr(settings, "signal_reentry_history_days", 365)))))
        self.conn.execute("DELETE FROM signal_reentry_history WHERE created_at < ?", (cutoff,))
        self.conn.commit()
        return int(cursor.lastrowid)


def reentry_summary(conn, *, hours: int = 24, plan_group: str = "", limit: int = 20) -> dict[str, Any]:
    ensure_schema(conn)
    hours = max(1, min(int(hours), 24 * 365))
    cutoff = _iso(_utc_now() - timedelta(hours=hours))
    clauses = ["r.created_at>=?"]
    params: list[Any] = [cutoff]
    if plan_group:
        clauses.append("r.plan_group=?")
        params.append(str(plan_group).strip().lower())
    where = " AND ".join(clauses)

    total = int(conn.execute(f"SELECT COUNT(*) FROM signal_reentry_history r WHERE {where}", params).fetchone()[0])
    reentries = int(conn.execute(f"SELECT COUNT(*) FROM signal_reentry_history r WHERE {where} AND r.delivery_kind='REENTRY'", params).fetchone()[0])
    initials = total - reentries
    by_plan_rows = conn.execute(
        f"SELECT plan_group,delivery_kind,COUNT(*) qty FROM signal_reentry_history r WHERE {where} GROUP BY plan_group,delivery_kind ORDER BY qty DESC",
        params,
    ).fetchall()
    by_plan: dict[str, dict[str, int]] = {}
    for row in by_plan_rows:
        group = str(row["plan_group"] or "free")
        by_plan.setdefault(group, {})[str(row["delivery_kind"] or "INITIAL")] = int(row["qty"] or 0)

    recent_rows = conn.execute(
        f"""SELECT r.*,s.last_return_pct,s.max_return_pct,s.lifecycle_state,s.first_tp1_at,s.first_tp2_at,s.first_tp3_at,s.first_stop_at
             FROM signal_reentry_history r
             LEFT JOIN signal_ledger s ON s.id=r.signal_id
             WHERE {where} AND r.delivery_kind='REENTRY'
             ORDER BY r.id DESC LIMIT ?""",
        [*params, max(1, min(int(limit), 100))],
    ).fetchall()
    recent: list[dict[str, Any]] = []
    for row in recent_rows:
        item = dict(row)
        try:
            item["evidence"] = json.loads(item.pop("evidence_json") or "{}")
        except Exception:
            item["evidence"] = {}
        recent.append(item)

    observed = [r for r in recent if r.get("signal_id") is not None]
    positive = sum(1 for r in observed if _f(r.get("last_return_pct")) > 0)
    tp1 = sum(1 for r in observed if r.get("first_tp1_at"))
    stopped = sum(1 for r in observed if r.get("first_stop_at") or str(r.get("lifecycle_state") or "").upper() == "STOPPED")
    return {
        "hours": hours,
        "plan_group": plan_group,
        "deliveries": total,
        "initials": initials,
        "reentries": reentries,
        "cooldowns": {"free": cooldown_hours("free"), "plus": cooldown_hours("plus"), "premium": cooldown_hours("premium")},
        "by_plan": by_plan,
        "recent": recent,
        "observed_reentries": len(observed),
        "positive_rate_pct": round((positive / len(observed)) * 100.0, 1) if observed else 0.0,
        "tp1_rate_pct": round((tp1 / len(observed)) * 100.0, 1) if observed else 0.0,
        "stop_rate_pct": round((stopped / len(observed)) * 100.0, 1) if observed else 0.0,
    }


def find_reentries(conn, *, term: str = "", hours: int = 24 * 30, limit: int = 20) -> list[dict[str, Any]]:
    ensure_schema(conn)
    cutoff = _iso(_utc_now() - timedelta(hours=max(1, min(int(hours), 24 * 3650))))
    clauses = ["r.created_at>=?", "r.delivery_kind='REENTRY'"]
    params: list[Any] = [cutoff]
    term = str(term or "").strip()
    if term:
        like = f"%{term}%"
        clauses.append("(r.symbol LIKE ? OR r.name LIKE ? OR r.address LIKE ?)")
        params.extend([like, like, like])
    rows = conn.execute(
        f"""SELECT r.*,s.last_return_pct,s.max_return_pct,s.lifecycle_state,s.first_tp1_at,s.first_tp2_at,s.first_tp3_at,s.first_stop_at
             FROM signal_reentry_history r
             LEFT JOIN signal_ledger s ON s.id=r.signal_id
             WHERE {' AND '.join(clauses)} ORDER BY r.id DESC LIMIT ?""",
        [*params, max(1, min(int(limit), 100))],
    ).fetchall()
    result: list[dict[str, Any]] = []
    for row in rows:
        data = dict(row)
        try:
            data["evidence"] = json.loads(data.pop("evidence_json") or "{}")
        except Exception:
            data["evidence"] = {}
        result.append(data)
    return result
