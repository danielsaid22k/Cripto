from __future__ import annotations

import sqlite3
import shutil
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Any

from .config import settings
from .plans import normalize_plan, base_plan as plan_base
from .persistence import prepare_schema_migration, finalize_schema, copy_legacy_database, inspect_database


# Estados que ainda precisam continuar consultáveis. Um checkout não deve
# desaparecer apenas porque a primeira consulta retornou AWAITING_PAYMENT.
OPEN_CHECKOUT_STATUSES = (
    "ACTIVE",
    "PENDING",
    "AWAITING_PAYMENT",
    "AWAITING_RISK_ANALYSIS",
    "PAID",
    "OVERDUE",
)

# Paid rows with activated_at=NULL can exist if the process stops between the
# Asaas status update and the local plan activation. They must remain
# recoverable on the next boot/check instead of getting stranded forever.
RECOVERABLE_PAID_STATUSES = (
    "RECEIVED",
    "CONFIRMED",
    "RECEIVED_IN_CASH",
)


class Storage:
    def __init__(self, path=None):
        # Legacy discovery/import belongs only to the canonical persistent database.
        # Explicit database paths are used by tests, staging and maintenance tools and
        # must remain isolated from the user's production state.
        explicit_path = path is not None
        self.path = Path(path or settings.db_file)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._legacy_import_enabled = not explicit_path
        if self._legacy_import_enabled:
            self._bootstrap_legacy_database()
        self.pre_migration_backup = prepare_schema_migration(self.path)
        self.conn = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.initialize()
        finalize_schema(self.conn, self.path.parent)
        if self._legacy_import_enabled:
            self._merge_legacy_databases()

    def _legacy_candidates(self) -> list[Path]:
        root = settings.base_dir.parent
        candidates = []
        patterns = (
            "Crypto_Signals_Multichain_CLEAN_v*/data/signals.db",
            "Crypto_Signals_Multichain_CLEAN_v*/signals.db",
            "Crypto_Signals_Multichain_CLEAN/data/signals.db",
            "Crypto_Signals_Multichain_State/signals.db",
        )
        for pattern in patterns:
            candidates.extend(root.glob(pattern))
        return [
            p for p in candidates
            if p.resolve() != self.path.resolve() and p.is_file() and ".Trash" not in p.parts
        ]

    @staticmethod
    def _database_score(path: Path) -> tuple:
        report = inspect_database(path)
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        return (*tuple(report["score"]), mtime)

    def _bootstrap_legacy_database(self) -> None:
        if self.path.exists() and self.path.stat().st_size > 0:
            return
        candidates = [p for p in self._legacy_candidates() if inspect_database(p)["valid"]]
        if not candidates:
            return
        source = max(candidates, key=self._database_score)
        copy_legacy_database(source, self.path)

    def _merge_legacy_databases(self) -> None:
        # Idempotent merge: import useful state from previous project folders
        # without replacing newer canonical records. Table failures are isolated
        # so one malformed legacy table cannot block users/payments from others.
        tables = (
            "users", "analyses", "favorites", "payment_orders", "subscriptions",
            "user_preferences", "subscription_reminders", "alert_deliveries",
            "signal_positions", "signal_ledger", "signal_observations", "signal_lifecycle_events", "performance_runs",
            "signal_outcome_learning_runs",
            "saas_tenants", "saas_api_keys", "saas_usage",
            "proof_events", "proof_daily_roots", "proof_anchors",
            "onchain_snapshots", "onchain_events", "onchain_cursors", "wallet_profiles",
            "wallet_reputation_evidence", "wallet_reputation_snapshots", "wallet_reputation_state",
            "ops_metrics", "ops_incidents", "ops_state",
            "distribution_destinations", "distribution_jobs", "distribution_attempts",
            "scanner_intelligence_cycles", "scanner_decisions", "signal_reentry_history",
        )
        for index, source in enumerate(self._legacy_candidates()):
            alias = f"legacy{index}"
            try:
                self.conn.execute(f"ATTACH DATABASE ? AS {alias}", (str(source),))
            except sqlite3.Error:
                continue
            try:
                for table in tables:
                    try:
                        exists = self.conn.execute(
                            f"SELECT 1 FROM {alias}.sqlite_master WHERE type='table' AND name=?", (table,)
                        ).fetchone()
                        if not exists:
                            continue
                        columns = [r[1] for r in self.conn.execute(f"PRAGMA main.table_info({table})").fetchall()]
                        legacy_columns = {r[1] for r in self.conn.execute(f"PRAGMA {alias}.table_info({table})").fetchall()}
                        common = [c for c in columns if c in legacy_columns]
                        if not common:
                            continue

                        if table == "users" and "user_id" in common:
                            # INSERT OR IGNORE alone can strand a paid legacy user
                            # as Free when the new runtime already created the same
                            # Telegram user_id. Merge paid-plan/customer/expiry data
                            # conservatively into the existing row instead.
                            select_cols = ",".join(common)
                            legacy_rows = self.conn.execute(
                                f"SELECT {select_cols} FROM {alias}.users"
                            ).fetchall()
                            for raw in legacy_rows:
                                incoming = {name: raw[pos] for pos, name in enumerate(common)}
                                uid = int(incoming.get("user_id") or 0)
                                if uid == 0:
                                    continue
                                current_row = self.conn.execute(
                                    "SELECT * FROM main.users WHERE user_id=?", (uid,)
                                ).fetchone()
                                if current_row is None:
                                    placeholders = ",".join("?" for _ in common)
                                    self.conn.execute(
                                        f"INSERT OR IGNORE INTO main.users ({select_cols}) VALUES ({placeholders})",
                                        tuple(incoming.get(c) for c in common),
                                    )
                                    continue

                                current = dict(current_row)
                                cur_plan = normalize_plan(current.get("plan"))
                                inc_plan = normalize_plan(incoming.get("plan")) if "plan" in incoming else "free"
                                chosen_plan = cur_plan
                                chosen_expiry = current.get("expires_at")
                                if cur_plan == "free" and inc_plan != "free":
                                    chosen_plan = inc_plan
                                    chosen_expiry = incoming.get("expires_at")
                                elif cur_plan == inc_plan and inc_plan != "free":
                                    cur_exp = self._parse_utc_datetime(current.get("expires_at"))
                                    inc_exp = self._parse_utc_datetime(incoming.get("expires_at"))
                                    if inc_exp is not None and (cur_exp is None or inc_exp > cur_exp):
                                        chosen_expiry = incoming.get("expires_at")

                                username = str(current.get("username") or incoming.get("username") or "")
                                first_name = str(current.get("first_name") or incoming.get("first_name") or "")
                                customer = str(current.get("asaas_customer_id") or incoming.get("asaas_customer_id") or "")
                                self.conn.execute(
                                    """UPDATE main.users SET username=?, first_name=?, plan=?, expires_at=?,
                                       asaas_customer_id=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?""",
                                    (username, first_name, chosen_plan, chosen_expiry, customer, uid),
                                )
                        else:
                            cols = ",".join(common)
                            self.conn.execute(
                                f"INSERT OR IGNORE INTO main.{table} ({cols}) SELECT {cols} FROM {alias}.{table}"
                            )
                        self.conn.commit()
                    except (sqlite3.Error, ValueError, TypeError):
                        self.conn.rollback()
                        continue
            finally:
                try:
                    self.conn.execute(f"DETACH DATABASE {alias}")
                except sqlite3.Error:
                    pass

        # Rows imported after initialize() may still contain historical plan
        # aliases; normalize them now as well.
        self._migrate_legacy_schema()
        self.conn.commit()


    def _sync_saas_entitlements_best_effort(self) -> None:
        """Keep linked SaaS tenants aligned without making payments depend on SaaS.

        The commercial core remains authoritative. Entitlement sync is fail-open
        so a portal-side issue can never block plan activation or Telegram.
        """
        try:
            from .entitlements import EntitlementManager
            EntitlementManager(self).sync_from_users()
        except Exception:
            pass

    def close(self) -> None:
        """Fecha a conexão SQLite de forma idempotente."""
        conn = getattr(self, "conn", None)
        if conn is None:
            return
        try:
            conn.commit()
        finally:
            conn.close()
            self.conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    @staticmethod
    def _parse_utc_datetime(value: Any) -> datetime | None:
        """Parse old/new ISO timestamps without letting legacy naive values crash paid users."""
        if value in (None, ""):
            return None
        text = str(value).strip()
        if not text:
            return None
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(text)
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)

    def _table_columns(self, table: str) -> set[str]:
        return {str(row[1]) for row in self.conn.execute(f"PRAGMA table_info({table})").fetchall()}

    def _ensure_columns(self, table: str, definitions: dict[str, str]) -> None:
        """Idempotently add non-PK columns required by current runtime.

        Some old SQLite builds reject ADD COLUMN with CURRENT_TIMESTAMP as a
        non-constant default. For those timestamp fields we add a nullable TEXT
        column and backfill existing rows, which is enough for runtime queries.
        """
        columns = self._table_columns(table)
        for name, ddl in definitions.items():
            if name in columns:
                continue
            try:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")
            except sqlite3.OperationalError as exc:
                if "non-constant default" not in str(exc).lower():
                    raise
                base_type = ddl.split(" DEFAULT", 1)[0]
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {base_type}")
                if "CURRENT_TIMESTAMP" in ddl.upper():
                    self.conn.execute(f"UPDATE {table} SET {name}=CURRENT_TIMESTAMP WHERE {name} IS NULL")
            columns.add(name)

    def _migrate_legacy_schema(self) -> None:
        """Bring supported legacy databases to the active subscription schema.

        This runs on every open and is intentionally idempotent. It never
        deletes users/payments and it normalizes only known historical plan
        aliases used by this project.
        """
        self._ensure_columns("users", {
            "username": "TEXT DEFAULT ''",
            "first_name": "TEXT DEFAULT ''",
            "plan": "TEXT DEFAULT 'free'",
            "expires_at": "TEXT",
            "blocked": "INTEGER DEFAULT 0",
            "created_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
            "updated_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
            "asaas_customer_id": "TEXT DEFAULT ''",
        })
        self._ensure_columns("payment_orders", {
            "user_id": "INTEGER NOT NULL DEFAULT 0",
            "plan": "TEXT NOT NULL DEFAULT 'free'",
            "invoice_url": "TEXT NOT NULL DEFAULT ''",
            "external_reference": "TEXT NOT NULL DEFAULT ''",
            "status": "TEXT DEFAULT 'PENDING'",
            "billing_type": "TEXT DEFAULT ''",
            "activated_at": "TEXT",
            "created_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
            "updated_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
        })
        self._ensure_columns("subscriptions", {
            "user_id": "INTEGER NOT NULL DEFAULT 0",
            "plan": "TEXT NOT NULL DEFAULT 'free'",
            "status": "TEXT DEFAULT 'ACTIVE'",
            "cycle": "TEXT NOT NULL DEFAULT 'MONTHLY'",
            "value": "REAL NOT NULL DEFAULT 0",
            "next_due_date": "TEXT",
            "auto_renew": "INTEGER DEFAULT 1",
            "created_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
            "updated_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
        })
        self._ensure_columns("user_preferences", {
            "auto_signals": "INTEGER DEFAULT 1",
            "favorite_alerts": "INTEGER DEFAULT 1",
            "expiry_alerts": "INTEGER DEFAULT 1",
            "compact_messages": "INTEGER DEFAULT 0",
            "updated_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
        })
        self._ensure_columns("alert_deliveries", {
            "confirmed": "INTEGER DEFAULT 0",
        })

        # Normalize only aliases previously emitted by this project. Unknown
        # values are preserved rather than silently changing a future plan.
        aliases = {
            "vip": "plus",
            "plus_mensal": "plus",
            "premium_mensal": "premium",
            "plus_anual": "plus_annual",
            "premium_anual": "premium_annual",
        }
        for table in ("users", "payment_orders", "subscriptions"):
            columns = self._table_columns(table)
            if "plan" not in columns:
                continue
            for old, new in aliases.items():
                self.conn.execute(
                    f"UPDATE {table} SET plan=? WHERE lower(trim(COALESCE(plan,'')))=?",
                    (new, old),
                )
            for canonical in ("free", "plus", "premium", "plus_annual", "premium_annual"):
                self.conn.execute(
                    f"UPDATE {table} SET plan=? WHERE lower(trim(COALESCE(plan,'')))=?",
                    (canonical, canonical),
                )

    def initialize(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT DEFAULT '',
                first_name TEXT DEFAULT '',
                plan TEXT DEFAULT 'free',
                expires_at TEXT,
                blocked INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                asaas_customer_id TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                chain TEXT NOT NULL,
                address TEXT NOT NULL,
                token_name TEXT DEFAULT '',
                token_symbol TEXT DEFAULT '',
                score INTEGER DEFAULT 0,
                source TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                chain TEXT NOT NULL,
                address TEXT NOT NULL,
                token_name TEXT DEFAULT '',
                token_symbol TEXT DEFAULT '',
                initial_price REAL DEFAULT 0,
                last_price REAL DEFAULT 0,
                last_change_pct REAL DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, chain, address)
            );

            CREATE INDEX IF NOT EXISTS idx_analyses_user_created
            ON analyses(user_id, created_at DESC);

            CREATE TABLE IF NOT EXISTS payment_orders (
                payment_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                plan TEXT NOT NULL,
                invoice_url TEXT NOT NULL,
                external_reference TEXT NOT NULL,
                status TEXT DEFAULT 'PENDING',
                billing_type TEXT DEFAULT '',
                activated_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_payment_orders_user_status
            ON payment_orders(user_id, status);

            CREATE INDEX IF NOT EXISTS idx_favorites_user
            ON favorites(user_id);

            CREATE TABLE IF NOT EXISTS subscriptions (
                subscription_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                plan TEXT NOT NULL,
                status TEXT DEFAULT 'ACTIVE',
                cycle TEXT NOT NULL,
                value REAL NOT NULL,
                next_due_date TEXT,
                auto_renew INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON subscriptions(user_id, status);

            CREATE TABLE IF NOT EXISTS alert_deliveries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                chain TEXT NOT NULL,
                address TEXT NOT NULL,
                alert_type TEXT NOT NULL,
                score INTEGER DEFAULT 0,
                confirmed INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, chain, address, alert_type)
            );
            CREATE INDEX IF NOT EXISTS idx_alert_deliveries_user_created
            ON alert_deliveries(user_id, created_at DESC);

            CREATE TABLE IF NOT EXISTS signal_positions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                chain TEXT NOT NULL,
                address TEXT NOT NULL,
                symbol TEXT DEFAULT '',
                entry_price REAL NOT NULL,
                target1_price REAL NOT NULL,
                target2_price REAL NOT NULL,
                stop_price REAL NOT NULL,
                target1_sent INTEGER DEFAULT 0,
                target2_sent INTEGER DEFAULT 0,
                stop_sent INTEGER DEFAULT 0,
                status TEXT DEFAULT 'OPEN',
                last_price REAL DEFAULT 0,
                peak_price REAL DEFAULT 0,
                result_pct REAL DEFAULT 0,
                outcome TEXT DEFAULT '',
                context_score INTEGER DEFAULT 0,
                context_volume REAL DEFAULT 0,
                context_peak_price REAL DEFAULT 0,
                context_risk_rank INTEGER DEFAULT 0,
                context_alerts INTEGER DEFAULT 0,
                last_context_event TEXT DEFAULT '',
                closed_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, chain, address, status)
            );
            CREATE INDEX IF NOT EXISTS idx_signal_positions_open
            ON signal_positions(status, updated_at);


            CREATE TABLE IF NOT EXISTS subscription_reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                expires_at TEXT NOT NULL,
                days_before INTEGER NOT NULL,
                sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, expires_at, days_before)
            );
            CREATE INDEX IF NOT EXISTS idx_subscription_reminders_user
            ON subscription_reminders(user_id, expires_at);

            CREATE TABLE IF NOT EXISTS user_preferences (
                user_id INTEGER PRIMARY KEY,
                auto_signals INTEGER DEFAULT 1,
                favorite_alerts INTEGER DEFAULT 1,
                expiry_alerts INTEGER DEFAULT 1,
                compact_messages INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS scanner_cycles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plan_group TEXT NOT NULL,
                discovered INTEGER DEFAULT 0,
                approved INTEGER DEFAULT 0,
                eligible INTEGER DEFAULT 0,
                sent INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                top_score INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_scanner_cycles_created
            ON scanner_cycles(created_at DESC);
            """
        )
        # v11/v11.5 additive schemas live in focused modules so they can also
        # be used by isolated tools without duplicating SQL definitions.
        from .performance import ensure_schema as ensure_performance_schema
        from .proof import ensure_schema as ensure_proof_schema
        from .saas import ensure_schema as ensure_saas_schema
        from .onchain import ensure_schema as ensure_onchain_schema
        from .reputation import ensure_schema as ensure_reputation_schema
        from .observability import ensure_schema as ensure_observability_schema
        from .distribution import ensure_schema as ensure_distribution_schema
        from .scanner_intelligence import ensure_schema as ensure_scanner_intelligence_schema
        from .smart_reentry import ensure_schema as ensure_smart_reentry_schema
        from .signal_outcome_learning import ensure_schema as ensure_signal_outcome_learning_schema
        ensure_performance_schema(self.conn)
        ensure_proof_schema(self.conn)
        ensure_saas_schema(self.conn)
        ensure_onchain_schema(self.conn)
        ensure_reputation_schema(self.conn)
        ensure_observability_schema(self.conn)
        ensure_distribution_schema(self.conn)
        ensure_scanner_intelligence_schema(self.conn)
        ensure_smart_reentry_schema(self.conn)
        ensure_signal_outcome_learning_schema(self.conn)
        self._migrate_legacy_schema()
        favorite_columns = self._table_columns("favorites")
        for name, ddl in {
            "initial_price": "REAL DEFAULT 0",
            "last_price": "REAL DEFAULT 0",
            "last_change_pct": "REAL DEFAULT 0",
            "updated_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
        }.items():
            if name not in favorite_columns:
                self.conn.execute(f"ALTER TABLE favorites ADD COLUMN {name} {ddl}")
        signal_columns = self._table_columns("signal_positions")
        for name, ddl in {
            "last_price": "REAL DEFAULT 0",
            "peak_price": "REAL DEFAULT 0",
            "result_pct": "REAL DEFAULT 0",
            "outcome": "TEXT DEFAULT ''",
            "context_score": "INTEGER DEFAULT 0",
            "context_volume": "REAL DEFAULT 0",
            "context_peak_price": "REAL DEFAULT 0",
            "context_risk_rank": "INTEGER DEFAULT 0",
            "context_alerts": "INTEGER DEFAULT 0",
            "last_context_event": "TEXT DEFAULT ''",
            "closed_at": "TEXT",
        }.items():
            if name not in signal_columns:
                self.conn.execute(f"ALTER TABLE signal_positions ADD COLUMN {name} {ddl}")
        self.conn.commit()
        self.conn.execute("DROP TABLE IF EXISTS payment_checkouts")
        self.conn.commit()

    def upsert_user(self, user_id: int, username: str = "", first_name: str = "") -> dict[str, Any]:
        self.conn.execute(
            """
            INSERT INTO users(user_id, username, first_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name,
                updated_at=CURRENT_TIMESTAMP
            """,
            (user_id, username or "", first_name or ""),
        )
        self.conn.commit()
        return self.get_user(user_id)

    def get_user(self, user_id: int) -> dict[str, Any]:
        row = self.conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row is None:
            return self.upsert_user(user_id)

        data = dict(row)
        expires = data.get("expires_at")
        if expires:
            parsed_expiry = self._parse_utc_datetime(expires)
            if parsed_expiry is None or parsed_expiry < datetime.now(timezone.utc):
                self.set_plan(user_id, "free", 0)
                data = dict(self.conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone())

        data["plan"] = normalize_plan(data.get("plan"))
        return data

    def set_plan(self, user_id: int, plan: str, days: int = 30) -> None:
        plan = normalize_plan(plan)
        expires = None
        if plan != "free" and days > 0:
            expires = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()

        self.conn.execute(
            """
            INSERT INTO users(user_id, plan, expires_at)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                plan=excluded.plan,
                expires_at=excluded.expires_at,
                updated_at=CURRENT_TIMESTAMP
            """,
            (user_id, plan, expires),
        )
        self.conn.commit()
        self._sync_saas_entitlements_best_effort()

    def set_blocked(self, user_id: int, blocked: bool) -> None:
        self.conn.execute(
            """
            INSERT INTO users(user_id, blocked)
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET blocked=excluded.blocked
            """,
            (user_id, int(blocked)),
        )
        self.conn.commit()
        self._sync_saas_entitlements_best_effort()

    def count_today(self, user_id: int) -> int:
        return int(
            self.conn.execute(
                "SELECT COUNT(*) FROM analyses WHERE user_id=? AND date(created_at)=date('now')",
                (user_id,),
            ).fetchone()[0]
        )

    def save_analysis(self, user_id: int, chain: str, address: str, score: int, market: dict) -> int:
        cursor = self.conn.execute(
            """
            INSERT INTO analyses(
                user_id, chain, address, token_name, token_symbol, score, source
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                chain,
                address,
                market.get("name", ""),
                market.get("symbol", ""),
                score,
                market.get("source", ""),
            ),
        )
        self.conn.commit()
        return int(cursor.lastrowid)

    def history(self, user_id: int, limit: int = 10, offset: int = 0) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT * FROM analyses
            WHERE user_id=?
            ORDER BY id DESC
            LIMIT ? OFFSET ?
            """,
            (user_id, max(1, limit), max(0, offset)),
        ).fetchall()
        return [dict(row) for row in rows]

    def history_count(self, user_id: int) -> int:
        return int(self.conn.execute("SELECT COUNT(*) FROM analyses WHERE user_id=?", (user_id,)).fetchone()[0])

    def add_favorite(self, user_id: int, chain: str, address: str, market: dict) -> bool:
        try:
            self.conn.execute(
                """
                INSERT INTO favorites(user_id, chain, address, token_name, token_symbol, initial_price, last_price)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    chain,
                    address,
                    market.get("name", ""),
                    market.get("symbol", ""),
                    float(market.get("price") or 0),
                    float(market.get("price") or 0),
                ),
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def remove_favorite(self, user_id: int, chain: str, address: str) -> bool:
        cursor = self.conn.execute(
            "DELETE FROM favorites WHERE user_id=? AND chain=? AND address=?",
            (user_id, chain, address),
        )
        self.conn.commit()
        return cursor.rowcount > 0

    def favorites(self, user_id: int, limit: int = 100) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT * FROM favorites
            WHERE user_id=?
            ORDER BY id DESC
            LIMIT ?
            """,
            (user_id, max(1, limit)),
        ).fetchall()
        return [dict(row) for row in rows]

    def favorite_count(self, user_id: int) -> int:
        return int(self.conn.execute("SELECT COUNT(*) FROM favorites WHERE user_id=?", (user_id,)).fetchone()[0])


    def update_favorite_market(self, favorite_id: int, price: float, change_pct: float) -> None:
        self.conn.execute(
            "UPDATE favorites SET last_price=?, last_change_pct=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (float(price), float(change_pct), int(favorite_id)),
        )
        self.conn.commit()

    def paid_favorites(self, limit: int = 300) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT f.*, u.plan, u.expires_at, u.blocked
               FROM favorites f JOIN users u ON u.user_id=f.user_id
               WHERE u.plan!='free' AND u.blocked=0
               ORDER BY f.updated_at ASC LIMIT ?""",
            (max(1, int(limit)),),
        ).fetchall()
        return [dict(row) for row in rows]

    def user_signal_stats(self, user_id: int) -> dict[str, Any]:
        row = self.conn.execute(
            """SELECT COUNT(*) total,
                      SUM(CASE WHEN status='OPEN' THEN 1 ELSE 0 END) open_count,
                      SUM(CASE WHEN outcome IN ('TARGET1','TARGET2') THEN 1 ELSE 0 END) wins,
                      SUM(CASE WHEN outcome='STOP' THEN 1 ELSE 0 END) losses,
                      AVG(CASE WHEN status='CLOSED' THEN result_pct END) avg_result,
                      MAX(CASE WHEN status='CLOSED' THEN result_pct END) best_result
               FROM signal_positions WHERE user_id=?""",
            (int(user_id),),
        ).fetchone()
        data = dict(row) if row else {}
        for key in ("total","open_count","wins","losses"):
            data[key] = int(data.get(key) or 0)
        data["avg_result"] = float(data.get("avg_result") or 0)
        data["best_result"] = float(data.get("best_result") or 0)
        closed = data["wins"] + data["losses"]
        data["hit_rate"] = (data["wins"] / closed * 100) if closed else 0.0
        return data

    def recent_signal_results(self, user_id: int, limit: int = 5) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM signal_positions WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (int(user_id), max(1, int(limit))),
        ).fetchall()
        return [dict(row) for row in rows]

    def expire_plans(self) -> int:
        cursor = self.conn.execute(
            "UPDATE users SET plan='free', expires_at=NULL, updated_at=CURRENT_TIMESTAMP "
            "WHERE plan!='free' AND expires_at IS NOT NULL AND datetime(expires_at) <= datetime('now')"
        )
        self.conn.commit()
        count = int(cursor.rowcount or 0)
        if count:
            self._sync_saas_entitlements_best_effort()
        return count


    def all_user_ids(self) -> list[int]:
        rows = self.conn.execute("SELECT user_id FROM users WHERE blocked=0 ORDER BY user_id").fetchall()
        return [int(row[0]) for row in rows]

    def users(self, limit: int = 20) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM users ORDER BY updated_at DESC LIMIT ?",
            (max(1, limit),),
        ).fetchall()
        return [dict(row) for row in rows]

    def network_ranking(self, limit: int = 10) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT chain, COUNT(*) AS total
            FROM analyses
            GROUP BY chain
            ORDER BY total DESC
            LIMIT ?
            """,
            (max(1, limit),),
        ).fetchall()
        return [dict(row) for row in rows]

    def stats(self) -> dict[str, int]:
        result = {
            "users": int(self.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]),
            "analyses": int(self.conn.execute("SELECT COUNT(*) FROM analyses").fetchone()[0]),
            "favorites": int(self.conn.execute("SELECT COUNT(*) FROM favorites").fetchone()[0]),
            "today": int(
                self.conn.execute("SELECT COUNT(*) FROM analyses WHERE date(created_at)=date('now')").fetchone()[0]
            ),
        }
        for plan in ("free", "plus", "premium"):
            result[plan] = int(
                self.conn.execute("SELECT COUNT(*) FROM users WHERE plan=?", (plan,)).fetchone()[0]
            )
        return result

    def set_asaas_customer(self, user_id: int, customer_id: str) -> None:
        self.conn.execute(
            "UPDATE users SET asaas_customer_id=?, updated_at=CURRENT_TIMESTAMP WHERE user_id=?",
            (customer_id, user_id),
        )
        self.conn.commit()

    def save_payment(self, *, payment_id: str, user_id: int, plan: str, invoice_url: str, external_reference: str, status: str, billing_type: str = "") -> None:
        self.conn.execute(
            """INSERT OR REPLACE INTO payment_orders
               (payment_id, user_id, plan, invoice_url, external_reference, status, billing_type, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)""",
            (payment_id, user_id, normalize_plan(plan), invoice_url, external_reference, status.upper(), billing_type.upper()),
        )
        self.conn.commit()

    def get_payment(self, payment_id: str) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM payment_orders WHERE payment_id=?", (payment_id,)).fetchone()
        return dict(row) if row else None

    @staticmethod
    def _payment_recheck_statuses() -> tuple[str, ...]:
        return OPEN_CHECKOUT_STATUSES + RECOVERABLE_PAID_STATUSES

    def latest_open_payment(self, user_id: int, plan: str | None = None, billing_type: str | None = None) -> dict[str, Any] | None:
        statuses = self._payment_recheck_statuses()
        placeholders = ",".join("?" for _ in statuses)
        paid_placeholders = ",".join("?" for _ in RECOVERABLE_PAID_STATUSES)
        params: list[Any] = [user_id, *statuses, *RECOVERABLE_PAID_STATUSES]
        sql = (
            f"SELECT * FROM payment_orders WHERE user_id=? AND status IN ({placeholders}) "
            f"AND (status NOT IN ({paid_placeholders}) OR activated_at IS NULL)"
        )
        if plan:
            sql += " AND plan=?"
            params.append(normalize_plan(plan))
        if billing_type:
            sql += " AND billing_type=?"
            params.append(billing_type.upper())
        sql += " ORDER BY created_at DESC LIMIT 1"
        row = self.conn.execute(sql, tuple(params)).fetchone()
        return dict(row) if row else None

    def open_payments(self, user_id: int | None = None, limit: int = 100) -> list[dict[str, Any]]:
        statuses = self._payment_recheck_statuses()
        placeholders = ",".join("?" for _ in statuses)
        paid_placeholders = ",".join("?" for _ in RECOVERABLE_PAID_STATUSES)
        where = (
            f"status IN ({placeholders}) "
            f"AND (status NOT IN ({paid_placeholders}) OR activated_at IS NULL)"
        )
        shared_params: tuple[Any, ...] = (*statuses, *RECOVERABLE_PAID_STATUSES)
        if user_id is None:
            rows = self.conn.execute(
                f"SELECT * FROM payment_orders WHERE {where} ORDER BY created_at ASC LIMIT ?",
                (*shared_params, max(1, limit)),
            ).fetchall()
        else:
            rows = self.conn.execute(
                f"SELECT * FROM payment_orders WHERE user_id=? AND {where} ORDER BY created_at ASC LIMIT ?",
                (user_id, *shared_params, max(1, limit)),
            ).fetchall()
        return [dict(row) for row in rows]

    def update_payment_status(self, payment_id: str, status: str) -> None:
        self.conn.execute(
            "UPDATE payment_orders SET status=?, updated_at=CURRENT_TIMESTAMP WHERE payment_id=?",
            (status.upper(), payment_id),
        )
        self.conn.commit()

    def activate_payment(self, payment_id: str, days: int = 30) -> bool:
        """Atomically activate a paid order exactly once.

        Returns True when this call performed the activation. A repeated check
        of the same payment is idempotent and never extends the expiry twice.
        """
        row = self.get_payment(payment_id)
        if not row:
            raise RuntimeError("Cobrança não encontrada.")
        if row.get("activated_at"):
            return False

        user_id = int(row["user_id"])
        plan = normalize_plan(row["plan"])
        now = datetime.now(timezone.utc)
        base = now
        current = self.conn.execute(
            "SELECT plan, expires_at FROM users WHERE user_id=?", (user_id,)
        ).fetchone()
        if current is not None and normalize_plan(current["plan"]) == plan:
            current_expiry = self._parse_utc_datetime(current["expires_at"])
            if current_expiry is not None and current_expiry > base:
                base = current_expiry
        expires = (base + timedelta(days=max(0, int(days)))).isoformat() if plan != "free" and days > 0 else None

        with self.conn:
            # Conditional update prevents duplicate activation if this method is
            # reached twice for the same payment in rapid succession.
            cursor = self.conn.execute(
                """UPDATE payment_orders
                   SET status='CONFIRMED', activated_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP
                   WHERE payment_id=? AND activated_at IS NULL""",
                (payment_id,),
            )
            if int(cursor.rowcount or 0) == 0:
                return False
            self.conn.execute(
                """INSERT INTO users(user_id, plan, expires_at)
                   VALUES (?, ?, ?)
                   ON CONFLICT(user_id) DO UPDATE SET
                       plan=excluded.plan, expires_at=excluded.expires_at,
                       updated_at=CURRENT_TIMESTAMP""",
                (user_id, plan, expires),
            )
        self._sync_saas_entitlements_best_effort()
        return True

    def save_subscription(self, *, subscription_id: str, user_id: int, plan: str, status: str, cycle: str, value: float, next_due_date: str | None, auto_renew: bool = True) -> None:
        self.conn.execute(
            """INSERT OR REPLACE INTO subscriptions
               (subscription_id,user_id,plan,status,cycle,value,next_due_date,auto_renew,updated_at)
               VALUES (?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
            (subscription_id,user_id,normalize_plan(plan),status.upper(),cycle.upper(),float(value),next_due_date,1 if auto_renew else 0),
        )
        self.conn.commit()

    def active_subscription(self, user_id: int) -> dict[str, Any] | None:
        row=self.conn.execute(
            "SELECT * FROM subscriptions WHERE user_id=? AND status IN ('ACTIVE','PENDING') ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        return dict(row) if row else None

    def set_subscription_status(self, subscription_id: str, status: str, next_due_date: str | None = None) -> None:
        self.conn.execute(
            "UPDATE subscriptions SET status=?, next_due_date=COALESCE(?,next_due_date), updated_at=CURRENT_TIMESTAMP WHERE subscription_id=?",
            (status.upper(),next_due_date,subscription_id),
        )
        self.conn.commit()

    def renewal_history(self, user_id: int, limit: int = 5) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT payment_id, plan, status, billing_type, activated_at, created_at
               FROM payment_orders
               WHERE user_id=? AND status IN ('CONFIRMED','RECEIVED','RECEIVED_IN_CASH')
               ORDER BY COALESCE(activated_at, created_at) DESC LIMIT ?""",
            (int(user_id), int(limit)),
        ).fetchall()
        return [dict(row) for row in rows]

    def payment_stats(self) -> dict[str, int]:
        return {
            "pending": int(self.conn.execute("SELECT COUNT(*) FROM payment_orders WHERE status IN ('PENDING','OVERDUE')").fetchone()[0]),
            "confirmed": int(self.conn.execute("SELECT COUNT(*) FROM payment_orders WHERE status IN ('CONFIRMED','RECEIVED','RECEIVED_IN_CASH')").fetchone()[0]),
        }

    def expiring_users(self, reminder_days: tuple[int, ...] = (30, 15, 7, 3, 1, 0)) -> list[dict[str, Any]]:
        """Assinaturas pagas que atingiram uma janela de aviso ainda não enviada."""
        now = datetime.now(timezone.utc)
        rows = self.conn.execute(
            "SELECT * FROM users WHERE plan!='free' AND blocked=0 AND expires_at IS NOT NULL"
        ).fetchall()
        due: list[dict[str, Any]] = []
        for raw in rows:
            user = dict(raw)
            try:
                expires = datetime.fromisoformat(str(user["expires_at"]))
                if expires.tzinfo is None:
                    expires = expires.replace(tzinfo=timezone.utc)
            except (TypeError, ValueError):
                continue
            seconds = (expires - now).total_seconds()
            days_left = max(0, int((seconds + 86399) // 86400)) if seconds > 0 else 0
            # Anuais recebem todas as janelas; mensais recebem 7, 3, 1 e 0.
            allowed = reminder_days if str(user.get("plan", "")).endswith("_annual") else (7, 3, 1, 0)
            if days_left not in allowed:
                continue
            sent = self.conn.execute(
                "SELECT 1 FROM subscription_reminders WHERE user_id=? AND expires_at=? AND days_before=?",
                (int(user["user_id"]), str(user["expires_at"]), days_left),
            ).fetchone()
            if sent:
                continue
            user["days_left"] = days_left
            due.append(user)
        return due

    def mark_subscription_reminder(self, user_id: int, expires_at: str, days_before: int) -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO subscription_reminders(user_id,expires_at,days_before) VALUES(?,?,?)",
            (int(user_id), str(expires_at), int(days_before)),
        )
        self.conn.commit()

    def user_preferences(self, user_id: int) -> dict[str, bool]:
        self.conn.execute("INSERT OR IGNORE INTO user_preferences(user_id) VALUES(?)", (int(user_id),))
        self.conn.commit()
        row = self.conn.execute("SELECT * FROM user_preferences WHERE user_id=?", (int(user_id),)).fetchone()
        return {
            "auto_signals": bool(row["auto_signals"]),
            "favorite_alerts": bool(row["favorite_alerts"]),
            "expiry_alerts": bool(row["expiry_alerts"]),
            "compact_messages": bool(row["compact_messages"]),
        }

    def toggle_user_preference(self, user_id: int, name: str) -> bool:
        allowed = {"auto_signals", "favorite_alerts", "expiry_alerts", "compact_messages"}
        if name not in allowed:
            raise ValueError("Preferência inválida")
        self.conn.execute("INSERT OR IGNORE INTO user_preferences(user_id) VALUES(?)", (int(user_id),))
        self.conn.execute(
            f"UPDATE user_preferences SET {name}=CASE {name} WHEN 1 THEN 0 ELSE 1 END, updated_at=CURRENT_TIMESTAMP WHERE user_id=?",
            (int(user_id),),
        )
        self.conn.commit()
        return bool(self.conn.execute(f"SELECT {name} FROM user_preferences WHERE user_id=?", (int(user_id),)).fetchone()[0])

    def record_scanner_cycle(self, plan_group: str, summary: dict[str, Any]) -> None:
        self.conn.execute(
            """INSERT INTO scanner_cycles(plan_group,discovered,approved,eligible,sent,errors,top_score)
               VALUES(?,?,?,?,?,?,?)""",
            (
                str(plan_group), int(summary.get("candidates", 0)), int(summary.get("approved", 0)),
                int(summary.get("eligible", 0)), int(summary.get("sent", 0)),
                int(summary.get("errors", 0)), int(summary.get("top_score", 0)),
            ),
        )
        self.conn.commit()

    def scanner_stats_today(self) -> dict[str, Any]:
        row = self.conn.execute(
            """SELECT COUNT(*) cycles, COALESCE(SUM(discovered),0) discovered,
                      COALESCE(SUM(approved),0) approved, COALESCE(SUM(sent),0) sent,
                      COALESCE(SUM(errors),0) errors, COALESCE(MAX(top_score),0) top_score,
                      MAX(created_at) last_cycle
               FROM scanner_cycles WHERE date(created_at,'localtime')=date('now','localtime')"""
        ).fetchone()
        return dict(row) if row else {"cycles": 0, "discovered": 0, "approved": 0, "sent": 0, "errors": 0, "top_score": 0, "last_cycle": None}

    def export_user_data(self, user_id: int) -> dict[str, Any]:
        user = self.get_user(int(user_id))
        return {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "user": user,
            "preferences": self.user_preferences(int(user_id)),
            "favorites": self.favorites(int(user_id), 1000),
            "history": self.history(int(user_id), 1000, 0),
            "signals": self.recent_signal_results(int(user_id), 1000),
            "signal_stats": self.user_signal_stats(int(user_id)),
        }

    def reset_user_to_free(self, user_id: int) -> bool:
        """Volta um usuário ao plano gratuito sem apagar histórico ou cadastro."""
        cursor = self.conn.execute(
            "UPDATE users SET plan='free', expires_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE user_id=?",
            (int(user_id),),
        )
        self.conn.execute("DELETE FROM signal_positions WHERE user_id=?", (int(user_id),))
        self.conn.execute("DELETE FROM alert_deliveries WHERE user_id=?", (int(user_id),))
        self.conn.commit()
        changed = bool(cursor.rowcount)
        if changed:
            self._sync_saas_entitlements_best_effort()
        return changed

    def paid_users(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM users WHERE plan != 'free' AND blocked=0 ORDER BY updated_at DESC"
        ).fetchall()
        result=[]
        for row in rows:
            user=dict(row)
            user["plan"]=normalize_plan(user.get("plan"))
            expires=user.get("expires_at")
            if expires:
                parsed_expiry = self._parse_utc_datetime(expires)
                if parsed_expiry is None or parsed_expiry < datetime.now(timezone.utc):
                    continue
            result.append(user)
        return result

    def signal_users(self, base_plan: str) -> list[dict[str, Any]]:
        """Return users eligible for one automatic-signal base plan.

        Filtering happens after plan normalization so legacy ``vip`` rows and
        migrated annual aliases do not disappear from Plus/Premium delivery.
        """
        requested_base = (base_plan or "free").strip().lower()
        if requested_base not in {"free", "plus", "premium"}:
            return []

        rows = self.conn.execute(
            "SELECT * FROM users WHERE blocked=0 ORDER BY updated_at DESC"
        ).fetchall()
        result: list[dict[str, Any]] = []
        now = datetime.now(timezone.utc)
        for row in rows:
            user = dict(row)
            user["plan"] = normalize_plan(user.get("plan"))
            if plan_base(user["plan"]) != requested_base:
                continue
            expires = user.get("expires_at")
            if requested_base != "free" and expires:
                parsed_expiry = self._parse_utc_datetime(expires)
                if parsed_expiry is None or parsed_expiry < now:
                    continue
            result.append(user)
        return result

    def alert_delivery_exists(self, user_id:int, chain:str, address:str, alert_type:str) -> bool:
        """True only for a Telegram delivery that was actually confirmed."""
        row = self.conn.execute(
            """SELECT 1 FROM alert_deliveries
               WHERE user_id=? AND chain=? AND address=? AND alert_type=? AND confirmed=1
               LIMIT 1""",
            (int(user_id), str(chain), str(address), str(alert_type)),
        ).fetchone()
        return row is not None

    def mark_alert_delivery(self, user_id:int, chain:str, address:str, alert_type:str, score:int=0) -> bool:
        """Persist deduplication only after Telegram has confirmed sendMessage."""
        self.conn.execute(
            """INSERT INTO alert_deliveries
               (user_id,chain,address,alert_type,score,confirmed,created_at)
               VALUES(?,?,?,?,?,1,CURRENT_TIMESTAMP)
               ON CONFLICT(user_id,chain,address,alert_type) DO UPDATE SET
                   score=excluded.score,
                   confirmed=1,
                   created_at=CURRENT_TIMESTAMP""",
            (int(user_id), str(chain), str(address), str(alert_type), int(score)),
        )
        self.conn.commit()
        return True

    def prune_alert_deliveries(self, hours:int=24) -> int:
        cursor=self.conn.execute(
            "DELETE FROM alert_deliveries WHERE created_at < datetime('now', ?)",
            (f'-{max(1,int(hours))} hours',),
        )
        self.conn.commit()
        return int(cursor.rowcount or 0)

    def create_signal_position(
        self, *, user_id:int, chain:str, address:str, symbol:str, entry_price:float,
        target1_price:float, target2_price:float, stop_price:float,
        entry_score:int=0, entry_volume:float=0.0, entry_risk_rank:int=0,
    ) -> None:
        if entry_price <= 0:
            return
        self.conn.execute(
            """INSERT OR IGNORE INTO signal_positions
               (user_id,chain,address,symbol,entry_price,target1_price,target2_price,stop_price,
                context_score,context_volume,context_peak_price,context_risk_rank)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (user_id,chain,address,symbol,entry_price,target1_price,target2_price,stop_price,
             int(entry_score or 0),float(entry_volume or 0),float(entry_price),int(entry_risk_rank or 0)),
        )
        self.conn.commit()

    def open_signal_positions(self, limit:int=200) -> list[dict[str,Any]]:
        rows=self.conn.execute(
            "SELECT * FROM signal_positions WHERE status='OPEN' ORDER BY updated_at ASC LIMIT ?",
            (max(1,int(limit)),),
        ).fetchall()
        return [dict(row) for row in rows]

    def update_signal_position(
        self, position_id:int, *, target1_sent:bool|None=None, target2_sent:bool|None=None,
        stop_sent:bool|None=None, status:str|None=None, last_price:float|None=None,
        peak_price:float|None=None, result_pct:float|None=None, outcome:str|None=None,
        context_score:int|None=None, context_volume:float|None=None,
        context_peak_price:float|None=None, context_risk_rank:int|None=None,
        context_alerts:int|None=None, last_context_event:str|None=None,
    ) -> None:
        fields=[]; params=[]
        for name,value in (("target1_sent",target1_sent),("target2_sent",target2_sent),("stop_sent",stop_sent)):
            if value is not None:
                fields.append(f"{name}=?"); params.append(1 if value else 0)
        if status is not None:
            fields.append("status=?"); params.append(status.upper())
            if status.upper()=="CLOSED": fields.append("closed_at=CURRENT_TIMESTAMP")
        for name,value in (("last_price",last_price),("peak_price",peak_price),("result_pct",result_pct),
                           ("context_volume",context_volume),("context_peak_price",context_peak_price)):
            if value is not None:
                fields.append(f"{name}=?"); params.append(float(value))
        for name,value in (("context_score",context_score),("context_risk_rank",context_risk_rank),("context_alerts",context_alerts)):
            if value is not None:
                fields.append(f"{name}=?"); params.append(int(value))
        if outcome is not None:
            fields.append("outcome=?"); params.append(str(outcome).upper())
        if last_context_event is not None:
            fields.append("last_context_event=?"); params.append(str(last_context_event)[:120])
        if not fields:
            return
        fields.append("updated_at=CURRENT_TIMESTAMP")
        params.append(int(position_id))
        self.conn.execute(f"UPDATE signal_positions SET {', '.join(fields)} WHERE id=?",tuple(params))
        self.conn.commit()

