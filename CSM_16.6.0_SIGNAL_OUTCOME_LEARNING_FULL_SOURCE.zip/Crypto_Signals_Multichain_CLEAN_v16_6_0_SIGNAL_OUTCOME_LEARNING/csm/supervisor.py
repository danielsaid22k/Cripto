from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from .logging_setup import logger


@dataclass
class SupervisorState:
    failures: int = 0
    last_error: str | None = None
    retry_at: float = 0.0


class ScannerSupervisor:
    """Isola falhas recuperáveis do scanner do loop principal do Telegram."""

    def __init__(self, scanner, max_backoff: int = 300):
        self.scanner = scanner
        self.max_backoff = max(15, int(max_backoff))
        self.state = SupervisorState()

    def scan(self, *args, **kwargs) -> list[dict[str, Any]]:
        now = time.monotonic()
        if now < self.state.retry_at:
            return []
        try:
            result = self.scanner.scan(*args, **kwargs)
            self.state = SupervisorState()
            return result
        except Exception as exc:
            failures = self.state.failures + 1
            delay = min(self.max_backoff, 15 * (2 ** min(failures - 1, 4)))
            self.state = SupervisorState(
                failures=failures,
                last_error=f"{type(exc).__name__}: {exc}",
                retry_at=now + delay,
            )
            logger.exception("Scanner isolado pelo supervisor; nova tentativa em %ss", delay)
            return []
