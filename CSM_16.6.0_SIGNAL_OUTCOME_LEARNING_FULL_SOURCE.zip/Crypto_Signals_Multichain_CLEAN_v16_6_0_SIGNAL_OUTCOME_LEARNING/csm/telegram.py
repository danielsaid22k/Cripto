from __future__ import annotations

import json
import logging
import time


from .http_client import HTTPJSONError, HTTPTransientError, SafeHTTP
from .config import settings

logger = logging.getLogger(__name__)


class Telegram:
    """Small resilient Telegram Bot API client.

    UI callbacks are acknowledged independently from screen rendering. This keeps
    Telegram's loading indicator from hanging even when a later edit fails.
    """

    def __init__(self, http=None):
        self.http = http or SafeHTTP(settings.request_timeout)
        self.base = f"https://api.telegram.org/bot{settings.telegram_token}"

    def call(self, method: str, data=None):
        response = self.http.post_json(f"{self.base}/{method}", data)
        if not response.get("ok"):
            raise RuntimeError(response.get("description", "Erro Telegram"))
        return response.get("result")

    def get_me(self):
        return self.call("getMe")

    def send(self, chat_id, text: str, reply_markup=None):
        data = {
            "chat_id": str(chat_id),
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true",
        }
        if reply_markup:
            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        return self.call("sendMessage", data)

    def edit(self, chat_id, message_id, text: str, reply_markup=None):
        data = {
            "chat_id": str(chat_id),
            "message_id": str(message_id),
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true",
        }
        if reply_markup:
            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        return self.call("editMessageText", data)

    def edit_or_send(self, chat_id, message_id, text: str, reply_markup=None):
        """Edit an inline screen, falling back to a fresh message.

        Telegram refuses edits in a few harmless situations (message unchanged,
        old message, non-editable source). The user should still receive the UI.
        """
        try:
            return self.edit(chat_id, message_id, text, reply_markup)
        except Exception as exc:
            logger.warning("Falha ao editar tela; enviando nova mensagem: %s", exc)
            return self.send(chat_id, text, reply_markup)

    def updates(self, offset=None):
        data = {
            "timeout": settings.poll_timeout,
            "allowed_updates": '["message","callback_query"]',
        }
        if offset is not None:
            data["offset"] = offset
        read_timeout = max(settings.request_timeout, settings.poll_timeout + 10)
        try:
            response = self.http.post_json(
                f"{self.base}/getUpdates", data, timeout=read_timeout
            )
            if not response.get("ok"):
                raise RuntimeError(response.get("description", "Erro Telegram"))
            return response.get("result") or []
        except (HTTPTransientError,) as exc:
            logger.warning("Polling temporariamente indisponível: %s", exc)
            time.sleep(max(2.0, settings.http_backoff))
            return []
        except HTTPJSONError as exc:
            if exc.status_code == 429 or 500 <= exc.status_code <= 599:
                logger.warning("Telegram temporariamente indisponível: HTTP %s", exc.status_code)
                time.sleep(max(2.0, settings.http_backoff))
                return []
            raise

    def answer_callback(self, callback_id: str, text: str = "") -> bool:
        if not callback_id:
            return False
        payload = {"callback_query_id": callback_id, "cache_time": "0"}
        if text:
            payload["text"] = text[:180]
        for attempt in range(2):
            try:
                self.call("answerCallbackQuery", payload)
                return True
            except Exception as exc:
                if attempt == 0:
                    time.sleep(0.15)
                    continue
                logger.warning("Não foi possível confirmar callback: %s", exc)
        return False

    def prepare(self):
        self.call("deleteWebhook", {"drop_pending_updates": "false"})
        commands = [
            {"command": "start", "description": "Abrir menu principal"},
            {"command": "analisar", "description": "Analisar um contrato"},
            {"command": "sol", "description": "Analisar na Solana"},
            {"command": "eth", "description": "Analisar no Ethereum"},
            {"command": "bnb", "description": "Analisar na BNB Chain"},
            {"command": "redes", "description": "Ver redes disponíveis"},
            {"command": "planos", "description": "Comparar planos"},
            {"command": "meuplano", "description": "Consultar assinatura"},
            {"command": "assinar", "description": "Assinar VIP/Plus ou Premium"},
            {"command": "verificar_pagamento", "description": "Verificar pagamento Asaas"},
            {"command": "historico", "description": "Últimas análises"},
            {"command": "favoritos", "description": "Tokens favoritos"},
            {"command": "status", "description": "Status do serviço"},
            {"command": "admin", "description": "Painel administrativo"},
            {"command": "admin_dashboard", "description": "Dashboard executivo"},
            {"command": "leader", "description": "Líder de Projeto"},
            {"command": "leader_audit", "description": "Auditar sistema"},
        ]
        self.call("setMyCommands", {"commands": json.dumps(commands, ensure_ascii=False)})
