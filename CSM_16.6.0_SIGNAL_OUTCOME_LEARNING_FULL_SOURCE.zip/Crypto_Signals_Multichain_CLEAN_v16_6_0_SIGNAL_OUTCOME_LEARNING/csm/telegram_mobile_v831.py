from __future__ import annotations

from .config import settings
from .http_client import HTTPJSONError, HTTPTransientError
from .telegram import Telegram


class TelegramMobileV831(Telegram):
    """Polling curto para o loop cooperativo no a-Shell.

    Não cria threads nem novos Pythons. O timeout de 1s devolve controle ao loop
    frequentemente para que o scanner execute uma etapa sem congelar callbacks.
    """

    def updates(self, offset=None):
        data = {"timeout": 1, "allowed_updates": '["message","callback_query"]'}
        if offset is not None:
            data["offset"] = offset
        try:
            response = self.http.post_json(f"{self.base}/getUpdates", data, timeout=max(3, int(settings.request_timeout)))
            if not response.get("ok"):
                raise RuntimeError(response.get("description", "Erro Telegram"))
            return response.get("result") or []
        except HTTPTransientError:
            return []
        except HTTPJSONError as exc:
            if exc.status_code == 429 or 500 <= exc.status_code <= 599:
                return []
            raise
