from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from .config import BASE_DIR, STATE_DIR
from .ui_registry_v830 import REPLY_BUTTONS, matches_callback, source_callback_literals

@dataclass
class UIAuditReport:
    callbacks_found: int
    callbacks_unmatched: list[str]
    reply_buttons_expected: int
    reply_buttons_missing: list[str]
    result: str


def _message_handler_text() -> str:
    return (BASE_DIR / 'csm' / 'app.py').read_text(encoding='utf-8')


def audit_ui() -> UIAuditReport:
    callbacks = source_callback_literals(BASE_DIR / 'csm')
    unmatched = sorted(v for v in callbacks if not matches_callback(v))
    handler = _message_handler_text().lower()
    missing = sorted(button for button in REPLY_BUTTONS if button.lower() not in handler)
    result = 'APROVADO' if not unmatched and not missing else 'BLOQUEADO'
    return UIAuditReport(len(callbacks), unmatched, len(REPLY_BUTTONS), missing, result)


def save_ui_audit() -> Path:
    report = audit_ui()
    target = STATE_DIR / 'reports' / 'ui_audit_v830.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(asdict(report), ensure_ascii=False, indent=2), encoding='utf-8')
    return target
