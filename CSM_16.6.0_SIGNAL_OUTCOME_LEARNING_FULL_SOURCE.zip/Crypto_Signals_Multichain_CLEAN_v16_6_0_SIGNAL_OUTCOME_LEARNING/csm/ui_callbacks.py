from __future__ import annotations

import json
from html import escape

from .config import settings
from .experience import BRAND_DIVIDER, plan_group
from .logging_setup import logger
from .plans import PLANS
from .preferences_ui import build_preferences_screen
from .central_v823 import build_central_v2
from .ui_guard_v823 import acknowledge_callback_fast, safe_send_screen


class CallbackRouter:
    """Isolated and rebuilt Telegram callback router."""

    def __init__(self, app):
        self.app = app

    def _screen(self, chat_id, message_id, text, keyboard=None):
        return self.app.telegram.edit_or_send(chat_id, message_id, text, keyboard)

    def handle(self, callback: dict):
        callback_id = str(callback.get("id") or "")
        data = str(callback.get("data") or "")
        message = callback.get("message") or {}
        chat_id = (message.get("chat") or {}).get("id")
        message_id = message.get("message_id")
        sender = callback.get("from") or {}
        user_id = int(sender.get("id") or chat_id)

        acknowledge_callback_fast(self.app.telegram, callback_id)
        try:
            return self._dispatch(data, chat_id, message_id, user_id, sender)
        except Exception as exc:
            logger.exception("Falha no callback %s: %s", data, exc)
            acknowledge_callback_fast(self.app.telegram, callback_id, "Ação indisponível no momento")
            user = self.app.storage.get_user(user_id)
            return self.app.telegram.send(
                chat_id,
                "⚠️ <b>NÃO FOI POSSÍVEL ABRIR ESTA OPÇÃO</b>\n\n"
                "O bot continua online. Tente novamente ou use /start.",
                self.app.user_keyboard(user),
            )

    def _dispatch(self, data, chat_id, message_id, user_id, sender):
        app = self.app
        if app.project_leader and user_id not in (settings.admin_ids or set()):
            notice = app.project_leader.maintenance_message()
            if notice:
                return app.telegram.send(chat_id, notice)

        if data == "enter_app":
            user = app.storage.get_user(user_id)
            app.telegram.send(
                chat_id,
                app.main_menu(user, sender.get("first_name", "")),
                app.user_keyboard(user),
            )
            return self._screen(
                chat_id,
                message_id,
                f"{BRAND_DIVIDER}\n✅ <b>EXPERIÊNCIA INICIADA</b>\n{BRAND_DIVIDER}\n\n"
                "Seu plano foi reconhecido e o radar automático está ativo.",
            )

        if data == "menu":
            user = app.storage.get_user(user_id)
            return app.telegram.send(
                chat_id,
                app.main_menu(user, sender.get("first_name", "")),
                app.user_keyboard(user),
            )
        if data == "plans":
            return self._screen(chat_id, message_id, app.plans_text(), app.sales_keyboard())

        if data == "preferences":
            text, keyboard = build_preferences_screen(app, user_id)
            return app.telegram.send(chat_id, text, keyboard)
        if data.startswith("pref|"):
            app.storage.toggle_user_preference(user_id, data.split("|", 1)[1])
            text, keyboard = build_preferences_screen(app, user_id)
            return self._screen(chat_id, message_id, text, keyboard)
        if data.startswith("profile|"):
            action = data.split("|", 1)[1]
            actions = {
                "chains": app.user_profiles.cycle_chains,
                "detail": app.user_profiles.cycle_detail_mode,
                "quiet": app.user_profiles.cycle_quiet_hours,
                "risk": app.user_profiles.cycle_risk_profile,
                "frequency": app.user_profiles.cycle_notification_frequency,
                "language": app.user_profiles.cycle_language,
            }
            if action not in actions:
                raise ValueError("Preferência desconhecida")
            actions[action](user_id)
            text, keyboard = build_preferences_screen(app, user_id)
            return self._screen(chat_id, message_id, text, keyboard)

        if data == "intelligence_center":
            text, keyboard = build_central_v2(app, user_id)
            # A Central v2 é sempre uma nova mensagem: não depende de editar a
            # tela anterior e não consulta providers/scanner.
            return safe_send_screen(app.telegram, chat_id, text, keyboard)
        if data == "dashboard":
            keyboard = {
                "inline_keyboard": [
                    [
                        {"text": "⭐ Favoritos", "callback_data": "favorites"},
                        {"text": "🧾 Histórico", "callback_data": "history|0"},
                    ],
                    [{"text": "🎛️ Preferências", "callback_data": "preferences"}],
                    [{"text": "🏠 Menu", "callback_data": "menu"}],
                ]
            }
            return self._screen(chat_id, message_id, app.dashboard_text(user_id), keyboard)
        if data == "my_plan":
            return self._screen(
                chat_id,
                message_id,
                app.plan_status_text(app.storage.get_user(user_id)),
                app.sales_keyboard(),
            )
        if data == "favorites":
            text, keyboard = app.favorites_text(user_id)
            return self._screen(chat_id, message_id, text, keyboard)
        if data == "export_user":
            export_dir = settings.base_dir / "exports"
            export_dir.mkdir(parents=True, exist_ok=True)
            target = export_dir / f"user_{user_id}_export.json"
            target.write_text(
                json.dumps(
                    app.storage.export_user_data(user_id),
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                ),
                encoding="utf-8",
            )
            return self._screen(
                chat_id,
                message_id,
                "📤 <b>EXPORTAÇÃO CONCLUÍDA</b>\n\n"
                "Seus dados foram exportados no ambiente administrativo.",
                {"inline_keyboard": [[{"text": "⬅️ Painel", "callback_data": "dashboard"}]]},
            )

        if data in {"scanner", "scanner_force"}:
            user = app.storage.get_user(user_id)
            if plan_group(user.get("plan")) != "free":
                return self._screen(
                    chat_id,
                    message_id,
                    "📡 <b>SCANNER AUTOMÁTICO ATIVO</b>\n\n"
                    "Seu plano recebe oportunidades em segundo plano.",
                    {
                        "inline_keyboard": [
                            [{"text": "⚙️ Abrir painel", "callback_data": "dashboard"}],
                            [{"text": "🏠 Menu", "callback_data": "menu"}],
                        ]
                    },
                )
            text, keyboard = app.scanner_text(user_id, force=data == "scanner_force")
            return self._screen(chat_id, message_id, text, keyboard)
        if data == "scanner_noop":
            return None
        if data.startswith("scanner_page|"):
            text, keyboard = app.scanner_text(
                user_id, page=int(data.split("|", 1)[1])
            )
            return self._screen(chat_id, message_id, text, keyboard)
        if data.startswith("scanner_detail|"):
            index = int(data.split("|", 1)[1])
            results = app.scanner_sessions.get(user_id, [])
            if index < 0 or index >= len(results):
                return app.telegram.send(
                    chat_id,
                    "⚠️ O resultado expirou. Abra o Scanner novamente.",
                    app.user_keyboard(app.storage.get_user(user_id)),
                )
            item = results[index]
            chain = str(item.get("chain") or "")
            address = str(item.get("address") or "")
            if not chain or not address:
                return app.telegram.send(
                    chat_id,
                    "⚠️ Este ativo não possui contrato válido.",
                    app.user_keyboard(app.storage.get_user(user_id)),
                )
            return app.send_analysis(chat_id, user_id, chain, address)

        if data.startswith("subscribe|"):
            plan = data.split("|", 1)[1]
            return self._screen(
                chat_id,
                message_id,
                "💳 <b>ESCOLHA A FORMA DE PAGAMENTO</b>\n\n"
                "⚡ PIX — pagamento rápido\n"
                "💳 Cartão — página segura do Asaas",
                app.payment_method_keyboard(plan),
            )
        if data.startswith("paymethod|"):
            _, plan, billing = data.split("|", 2)
            return app.request_payment_document(chat_id, user_id, plan, sender, billing)
        if data == "payment_check":
            return app.verify_payment(chat_id, user_id)
        if data.startswith("history|"):
            text, keyboard = app.history_text(
                user_id, int(data.split("|", 1)[1])
            )
            return self._screen(chat_id, message_id, text, keyboard)

        parts = data.split("|")
        if len(parts) == 3:
            action, chain, address = parts
            if action == "copy":
                return app.telegram.send(
                    chat_id,
                    "📋 <b>CONTRATO PRONTO PARA COPIAR</b>\n\n"
                    f"<code>{escape(address)}</code>",
                    app.user_keyboard(app.storage.get_user(user_id)),
                )
            if action == "refresh":
                return app.send_analysis(chat_id, user_id, chain, address, force=True)
            if action == "favorite":
                user = app.storage.get_user(user_id)
                plan = PLANS[user["plan"]]
                if plan["favorites"] <= 0:
                    return app.telegram.send(
                        chat_id,
                        "⭐ Favoritos exigem Plus ou Premium.",
                        app.sales_keyboard(),
                    )
                if app.storage.favorite_count(user_id) >= plan["favorites"]:
                    return app.telegram.send(
                        chat_id,
                        "⛔ Limite de favoritos atingido.",
                        app.user_keyboard(user),
                    )
                market = app.last_results.get(user_id, (None, None, None))[2]
                if not market or market.get("address") != address:
                    try:
                        market = app.market.fetch(chain, address)
                    except Exception:
                        market = {"name": "Token", "symbol": ""}
                added = app.storage.add_favorite(user_id, chain, address, market)
                return app.telegram.send(
                    chat_id,
                    "⭐ Token adicionado aos favoritos."
                    if added
                    else "ℹ️ Token já estava nos favoritos.",
                    app.user_keyboard(user),
                )
            if action == "unfavorite":
                removed = app.storage.remove_favorite(user_id, chain, address)
                return app.telegram.send(
                    chat_id,
                    "🗑️ Favorito removido."
                    if removed
                    else "ℹ️ Favorito não encontrado.",
                    app.user_keyboard(app.storage.get_user(user_id)),
                )

        raise ValueError(f"Callback não reconhecido: {data}")
