from __future__ import annotations

# Router novo da v8.3.0. Reaproveita a lógica funcional validada da v8.2.3,
# mas valida cada callback contra um registro central antes do dispatch.
from .ui_callbacks import CallbackRouter as LegacyRouter
from .ui_registry_v830 import matches_callback
from .logging_setup import logger

class CallbackRouterV830(LegacyRouter):
    def handle(self, callback: dict):
        data=str(callback.get('data') or '')
        if data and not matches_callback(data):
            callback_id=str(callback.get('id') or '')
            try: self.app.telegram.answer_callback(callback_id,'Opção indisponível nesta versão')
            except Exception: pass
            message=callback.get('message') or {}; chat_id=(message.get('chat') or {}).get('id')
            logger.error('Callback sem rota registrado: %s',data)
            if chat_id:
                return self.app.telegram.send(chat_id,'⚠️ Esta opção não possui uma rota válida. Use /start para atualizar o menu.',self.app.user_keyboard(self.app.storage.get_user(int((callback.get('from') or {}).get('id') or chat_id))))
            return None
        return super().handle(callback)
