from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


def acknowledge_callback_fast(telegram: Any, callback_id: str, text: str = "", *, timeout: float = 2.0) -> bool:
    """Confirma callback com timeout curto e sem retry bloqueante.

    O router antigo usava ``Telegram.answer_callback`` com até duas tentativas e o
    timeout HTTP padrão. Em ambiente móvel, uma oscilação de rede podia manter o
    indicador nativo "Carregando..." por muitos segundos. Esta função é best-effort:
    tenta uma vez e devolve imediatamente o controle ao loop principal.
    """
    if not callback_id:
        return False
    payload: dict[str, str] = {"callback_query_id": str(callback_id), "cache_time": "0"}
    if text:
        payload["text"] = str(text)[:180]
    try:
        response = telegram.http.post_json(
            f"{telegram.base}/answerCallbackQuery",
            payload,
            timeout=max(0.5, float(timeout)),
        )
        return bool(response.get("ok", False))
    except Exception as exc:
        logger.warning("Callback não confirmado no fast-ack v8.2.3: %s", exc)
        return False


def safe_send_screen(telegram: Any, chat_id: int, text: str, keyboard: dict | None = None):
    """Envia uma nova tela; falha de edição nunca é necessária para a Central v2."""
    return telegram.send(chat_id, text, keyboard)
