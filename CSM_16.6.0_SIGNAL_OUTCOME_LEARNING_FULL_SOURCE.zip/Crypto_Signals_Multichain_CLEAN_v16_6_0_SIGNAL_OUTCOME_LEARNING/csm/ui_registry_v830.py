from __future__ import annotations

from dataclasses import dataclass
import re
from pathlib import Path

@dataclass(frozen=True)
class RouteSpec:
    name: str
    pattern: str
    description: str

ROUTES = (
    RouteSpec('enter_app', r'^enter_app$', 'Entrada no aplicativo'),
    RouteSpec('menu', r'^menu$', 'Menu principal'),
    RouteSpec('plans', r'^plans$', 'Planos'),
    RouteSpec('preferences', r'^preferences$', 'Preferências'),
    RouteSpec('pref', r'^pref\|[^|]+$', 'Alternância de preferência'),
    RouteSpec('profile', r'^profile\|[^|]+$', 'Perfil do usuário'),
    RouteSpec('intelligence_center', r'^intelligence_center$', 'Minha Central'),
    RouteSpec('dashboard', r'^dashboard$', 'Central Premium/Painel'),
    RouteSpec('my_plan', r'^my_plan$', 'Assinatura'),
    RouteSpec('favorites', r'^favorites$', 'Favoritos'),
    RouteSpec('export_user', r'^export_user$', 'Exportação'),
    RouteSpec('scanner', r'^scanner(?:_force|_noop)?$', 'Scanner'),
    RouteSpec('scanner_page', r'^scanner_page\|[^|]+$', 'Paginação scanner'),
    RouteSpec('scanner_detail', r'^scanner_detail\|[^|]+$', 'Detalhe scanner'),
    RouteSpec('subscribe', r'^subscribe\|[^|]+$', 'Assinatura de plano'),
    RouteSpec('paymethod', r'^paymethod\|[^|]+\|[^|]+$', 'Método de pagamento'),
    RouteSpec('payment_check', r'^payment_check$', 'Verificação de pagamento'),
    RouteSpec('history', r'^history\|[^|]+$', 'Histórico'),
    RouteSpec('token_action', r'^(copy|refresh|favorite|unfavorite)\|[^|]+\|.+$', 'Ação do token'),
)

COMPILED = tuple((spec, re.compile(spec.pattern)) for spec in ROUTES)

REPLY_BUTTONS = {
    '🔍 Analisar', '🚀 Scanner', '🌐 Redes', '🧾 Histórico', '👤 Meu plano', '💎 Planos',
    '🧠 Minha Central', '🎛️ Preferências', '🟢 Status', '📡 Sinais automáticos', '⭐ Favoritos',
    '👑 Conhecer Premium', '👑 Central Premium', '👤 Minha assinatura',
}


def matches_callback(data: str) -> bool:
    return any(rx.match(str(data or '')) for _, rx in COMPILED)


def callback_name(data: str) -> str | None:
    for spec, rx in COMPILED:
        if rx.match(str(data or '')):
            return spec.name
    return None


def source_callback_literals(root: Path) -> set[str]:
    values: set[str] = set()
    rx = re.compile(r'["\']callback_data["\']\s*:\s*f?["\']([^"\']+)["\']')
    for path in root.rglob('*.py'):
        if any(part in {'tests', '__pycache__'} for part in path.parts):
            continue
        try:
            text = path.read_text(encoding='utf-8')
        except Exception:
            continue
        for match in rx.finditer(text):
            value = match.group(1)
            # Converte placeholders simples de f-string em amostras compatíveis.
            # Expressões com indexação (row['x']) são cobertas pelos testes funcionais
            # do router e não são confiáveis para extração por regex textual.
            if '{row[' in value:
                continue
            value = re.sub(r'\{[^}]+\}', 'sample', value)
            values.add(value)
    return values
