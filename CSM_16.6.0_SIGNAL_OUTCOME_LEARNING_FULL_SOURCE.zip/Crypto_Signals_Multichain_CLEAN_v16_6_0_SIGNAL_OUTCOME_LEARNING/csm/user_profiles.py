from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


class UserProfileStore:
    """Preferências avançadas fora do schema LTS.

    O arquivo fica no diretório persistente de estado e não altera o banco
    congelado da v6.3.0. Escritas são atômicas para reduzir risco de corrupção.
    """

    DEFAULT = {
        "preferred_chains": [],
        "quiet_hours": "off",
        "detail_mode": "standard",
        "risk_profile": "moderate",
        "language": "pt-BR",
        "notification_frequency": "plan",
    }

    def __init__(self, path: Path | None = None):
        self.path = path or (settings.data_dir / "user_profiles.json")
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"version": 1, "users": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("users"), dict):
                return data
        except (OSError, json.JSONDecodeError):
            pass
        return {"version": 1, "users": {}}

    def _save(self, data: dict[str, Any]) -> None:
        data["updated_at"] = datetime.now(timezone.utc).isoformat()
        fd, temp_name = tempfile.mkstemp(prefix="profiles-", suffix=".json", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def get(self, user_id: int) -> dict[str, Any]:
        data = self._load()
        raw = data["users"].get(str(int(user_id)), {})
        profile = dict(self.DEFAULT)
        if isinstance(raw, dict):
            profile.update(raw)
        chains = profile.get("preferred_chains")
        profile["preferred_chains"] = [str(item) for item in chains] if isinstance(chains, list) else []
        if profile.get("detail_mode") not in {"compact", "standard", "detailed"}:
            profile["detail_mode"] = "standard"
        if profile.get("quiet_hours") not in {"off", "22-07", "00-07"}:
            profile["quiet_hours"] = "off"
        if profile.get("risk_profile") not in {"conservative", "moderate", "aggressive"}:
            profile["risk_profile"] = "moderate"
        if profile.get("language") not in {"pt-BR", "en"}:
            profile["language"] = "pt-BR"
        if profile.get("notification_frequency") not in {"plan", "reduced", "priority"}:
            profile["notification_frequency"] = "plan"
        return profile

    def update(self, user_id: int, **changes: Any) -> dict[str, Any]:
        data = self._load()
        user_key = str(int(user_id))
        current = self.get(user_id)
        current.update(changes)
        data["users"][user_key] = current
        self._save(data)
        return current

    def cycle_detail_mode(self, user_id: int) -> dict[str, Any]:
        current = self.get(user_id)
        values = ["compact", "standard", "detailed"]
        index = (values.index(current["detail_mode"]) + 1) % len(values)
        return self.update(user_id, detail_mode=values[index])

    def cycle_chains(self, user_id: int) -> dict[str, Any]:
        current = self.get(user_id)
        presets = [[], ["solana"], ["ethereum"], ["bsc"], ["base"], ["solana", "base", "bsc"]]
        try:
            index = presets.index(current["preferred_chains"])
        except ValueError:
            index = 0
        return self.update(user_id, preferred_chains=presets[(index + 1) % len(presets)])

    def cycle_quiet_hours(self, user_id: int) -> dict[str, Any]:
        current = self.get(user_id)
        values = ["off", "22-07", "00-07"]
        index = (values.index(current["quiet_hours"]) + 1) % len(values)
        return self.update(user_id, quiet_hours=values[index])

    def cycle_risk_profile(self, user_id: int) -> dict[str, Any]:
        current = self.get(user_id)
        values = ["conservative", "moderate", "aggressive"]
        index = (values.index(current["risk_profile"]) + 1) % len(values)
        return self.update(user_id, risk_profile=values[index])

    def cycle_language(self, user_id: int) -> dict[str, Any]:
        current = self.get(user_id)
        values = ["pt-BR", "en"]
        index = (values.index(current["language"]) + 1) % len(values)
        return self.update(user_id, language=values[index])

    def cycle_notification_frequency(self, user_id: int) -> dict[str, Any]:
        current = self.get(user_id)
        values = ["plan", "reduced", "priority"]
        index = (values.index(current["notification_frequency"]) + 1) % len(values)
        return self.update(user_id, notification_frequency=values[index])

    @staticmethod
    def is_quiet(profile: dict[str, Any], now: datetime | None = None) -> bool:
        rule = str(profile.get("quiet_hours") or "off")
        if rule == "off":
            return False
        now = now or datetime.now().astimezone()
        start_text, end_text = rule.split("-", 1)
        start, end = int(start_text), int(end_text)
        hour = now.hour
        if start > end:
            return hour >= start or hour < end
        return start <= hour < end
