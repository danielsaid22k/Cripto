"""Daniel AI: camada inteligente local e opcional do Crypto Signals Multichain.

V1.3.1 preserva o Daniel Smart/LLM local da V1.3.0 e adiciona Speechify
Neural Voice opcional como primeira camada TTS quando configurada. Edge Neural,
Supertonic, Kokoro e eSpeak permanecem como fallbacks automáticos.
"""

__version__ = "1.3.1"
