from __future__ import annotations

from typing import Any

from .engine import DanielAI


def status_payload() -> dict[str, Any]:
    return DanielAI().status()


def ask_payload(question: str, user_id: int = 0, source: str = "api") -> dict[str, Any]:
    ai = DanielAI()
    answer = ai.ask(question, user_id=user_id, source=source)
    return {"ok": True, "answer": answer, "status": {"version": ai.status()["version"], "mode": ai.status()["mode"]}}
