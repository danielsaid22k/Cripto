from __future__ import annotations

import os
from dataclasses import dataclass, replace
from pathlib import Path

from csm.config import STATE_DIR


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on", "sim"}


def _int(name: str, default: int, minimum: int = 0) -> int:
    try:
        value = int(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        value = default
    return max(minimum, value)


def _float(name: str, default: float, minimum: float = 0.0, maximum: float | None = None) -> float:
    try:
        value = float(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        value = default
    value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


@dataclass(frozen=True)
class DanielSettings:
    enabled: bool
    admin_only: bool
    memory_enabled: bool
    history_limit: int
    max_question_chars: int
    openai_enabled: bool
    openai_api_key: str
    openai_model: str
    web_enabled: bool
    documents_enabled: bool
    documents_dir: Path
    state_dir: Path
    db_file: Path
    documents_max_file_mb: int = 8
    knowledge_max_results: int = 5
    web_timeout_seconds: int = 8
    web_max_bytes: int = 700000
    web_max_results: int = 5
    learning_enabled: bool = True
    learning_interval_minutes: int = 60
    learning_max_sources_per_topic: int = 3
    learning_ttl_hours: int = 168
    learning_max_items: int = 500
    learning_web_timeout_seconds: int = 5
    learned_dir: Path | None = None
    voice_enabled: bool = True
    voice_language: str = "pt"
    voice_model: str = "tiny"
    voice_model_path: str = ""
    voice_whisper_bin: str = ""
    voice_ffmpeg_bin: str = "ffmpeg"
    voice_max_seconds: int = 90
    voice_max_bytes: int = 12 * 1024 * 1024
    voice_transcribe_timeout_seconds: int = 150
    voice_dir: Path | None = None
    tts_enabled: bool = True
    tts_engine: str = "auto"
    tts_voice: str = "pt-br"
    tts_speed: int = 155
    tts_max_chars: int = 1400
    tts_ffmpeg_bin: str = "ffmpeg"
    tts_timeout_seconds: int = 120
    # V1.2.3 Natural Neural Voice: Microsoft Edge Neural PT-BR online primary,
    # local neural fallbacks remain Supertonic 3 + Kokoro, then eSpeak.
    # All critical CSM logic remains isolated.
    tts_edge_bin: str = "edge-tts"
    tts_edge_voice: str = "pt-BR-AntonioNeural"
    tts_edge_rate: str = "-4%"
    tts_edge_pitch: str = "+0Hz"
    tts_edge_volume: str = "+0%"
    tts_edge_timeout_seconds: int = 35
    # V1.3.1 Speechify Neural Voice: optional cloud TTS. It is first in auto
    # mode only when a key + voice are configured; all existing engines stay as fallbacks.
    tts_speechify_enabled: bool = False
    tts_speechify_api_key: str = ""
    tts_speechify_voice_id: str = ""
    tts_speechify_model: str = "simba-3.0"
    tts_speechify_language: str = "pt-BR"
    tts_speechify_base_url: str = "https://api.speechify.ai"
    tts_speechify_timeout_seconds: int = 35
    tts_supertonic_bin: str = "supertonic"
    tts_supertonic_voice: str = "M1"
    tts_supertonic_lang: str = "pt"
    tts_supertonic_steps: int = 8
    tts_supertonic_speed: float = 1.0
    tts_kokoro_python: str = "python"
    tts_kokoro_model_path: str = ""
    tts_kokoro_voices_path: str = ""
    tts_kokoro_voice: str = "pm_alex"
    tts_kokoro_speed: float = 1.0
    tts_espeak_bin: str = "espeak"
    # V1.2.4 Adaptive Conversational Voice: the screen keeps the technical
    # answer while TTS receives a local spoken briefing built from the same facts.
    conversational_voice_enabled: bool = True
    conversational_voice_style: str = "adaptive"
    conversational_voice_detail: str = "balanced"
    conversational_voice_max_chars: int = 1250
    conversational_voice_command_explainer: bool = True
    conversational_voice_natural_variation: bool = True
    # V1.3.0 Daniel Smart / Local Generative Brain. The GGUF model lives in
    # Termux private storage and is invoked through llama.cpp only for free-form
    # questions that did not match a deterministic CSM route.
    local_llm_enabled: bool = True
    local_llm_mode: str = "smart"
    local_llm_model_name: str = "Qwen3-4B Q4_K_M"
    local_llm_model_path: str = ""
    local_llm_bin: str = ""
    local_llm_context_size: int = 4096
    local_llm_max_tokens: int = 320
    local_llm_threads: int = 4
    local_llm_timeout_seconds: int = 180
    local_llm_temperature: float = 0.7
    local_llm_top_p: float = 0.8
    local_llm_top_k: int = 20
    local_llm_min_p: float = 0.0
    local_llm_history_messages: int = 6

    @property
    def mode(self) -> str:
        return "openai" if self.openai_enabled else "local"

    @property
    def openai_ready(self) -> bool:
        return bool(self.openai_enabled and self.openai_api_key)

    @classmethod
    def from_env(cls) -> "DanielSettings":
        state_dir = STATE_DIR / "daniel_ai"
        raw_docs = os.getenv("DANIEL_AI_DOCUMENTS_DIR", "").strip()
        documents_dir = Path(raw_docs).expanduser() if raw_docs else state_dir / "documents"
        if not documents_dir.is_absolute():
            documents_dir = (STATE_DIR.parent / documents_dir).resolve()
        learned_dir = state_dir / "learned"
        voice_dir = state_dir / "voice"
        return cls(
            enabled=_bool("DANIEL_AI_ENABLED", True),
            admin_only=_bool("DANIEL_AI_ADMIN_ONLY", True),
            memory_enabled=_bool("DANIEL_AI_MEMORY_ENABLED", True),
            history_limit=_int("DANIEL_AI_HISTORY_LIMIT", 50, 5),
            max_question_chars=_int("DANIEL_AI_MAX_QUESTION_CHARS", 4000, 200),
            openai_enabled=_bool("OPENAI_ENABLED", False),
            openai_api_key=os.getenv("OPENAI_API_KEY", "").strip(),
            openai_model=os.getenv("OPENAI_MODEL", "").strip(),
            web_enabled=_bool("DANIEL_AI_WEB_ENABLED", False),
            documents_enabled=_bool("DANIEL_AI_DOCUMENTS_ENABLED", True),
            documents_dir=documents_dir,
            state_dir=state_dir,
            db_file=state_dir / "daniel_ai.db",
            documents_max_file_mb=_int("DANIEL_AI_DOCUMENTS_MAX_FILE_MB", 8, 1),
            knowledge_max_results=_int("DANIEL_AI_KNOWLEDGE_MAX_RESULTS", 5, 1),
            web_timeout_seconds=_int("DANIEL_AI_WEB_TIMEOUT_SECONDS", 8, 2),
            web_max_bytes=_int("DANIEL_AI_WEB_MAX_BYTES", 700000, 50000),
            web_max_results=_int("DANIEL_AI_WEB_MAX_RESULTS", 5, 1),
            learning_enabled=_bool("DANIEL_AI_LEARNING_ENABLED", True),
            learning_interval_minutes=_int("DANIEL_AI_LEARNING_INTERVAL_MINUTES", 60, 10),
            learning_max_sources_per_topic=_int("DANIEL_AI_LEARNING_MAX_SOURCES", 3, 1),
            learning_ttl_hours=_int("DANIEL_AI_LEARNING_TTL_HOURS", 168, 6),
            learning_max_items=_int("DANIEL_AI_LEARNING_MAX_ITEMS", 500, 20),
            learning_web_timeout_seconds=_int("DANIEL_AI_LEARNING_WEB_TIMEOUT_SECONDS", 5, 2),
            learned_dir=learned_dir,
            voice_enabled=_bool("DANIEL_AI_VOICE_ENABLED", True),
            voice_language=os.getenv("DANIEL_AI_VOICE_LANGUAGE", "pt").strip() or "pt",
            voice_model=os.getenv("DANIEL_AI_VOICE_MODEL", "tiny").strip() or "tiny",
            voice_model_path=os.getenv("DANIEL_AI_VOICE_MODEL_PATH", "").strip(),
            voice_whisper_bin=os.getenv("DANIEL_AI_VOICE_WHISPER_BIN", "").strip(),
            voice_ffmpeg_bin=os.getenv("DANIEL_AI_VOICE_FFMPEG_BIN", "ffmpeg").strip() or "ffmpeg",
            voice_max_seconds=_int("DANIEL_AI_VOICE_MAX_SECONDS", 90, 10),
            voice_max_bytes=_int("DANIEL_AI_VOICE_MAX_BYTES", 12 * 1024 * 1024, 1024 * 1024),
            voice_transcribe_timeout_seconds=_int("DANIEL_AI_VOICE_TIMEOUT_SECONDS", 150, 30),
            voice_dir=voice_dir,
            tts_enabled=_bool("DANIEL_AI_TTS_ENABLED", True),
            tts_engine=os.getenv("DANIEL_AI_TTS_ENGINE", "auto").strip().lower() or "auto",
            tts_voice=os.getenv("DANIEL_AI_TTS_VOICE", "pt-br").strip() or "pt-br",
            tts_speed=_int("DANIEL_AI_TTS_SPEED", 155, 80),
            tts_max_chars=_int("DANIEL_AI_TTS_MAX_CHARS", 1400, 200),
            tts_ffmpeg_bin=os.getenv("DANIEL_AI_TTS_FFMPEG_BIN", "ffmpeg").strip() or "ffmpeg",
            tts_timeout_seconds=_int("DANIEL_AI_TTS_TIMEOUT_SECONDS", 120, 15),
            tts_edge_bin=os.getenv("DANIEL_AI_TTS_EDGE_BIN", "edge-tts").strip() or "edge-tts",
            tts_edge_voice=os.getenv("DANIEL_AI_TTS_EDGE_VOICE", "pt-BR-AntonioNeural").strip() or "pt-BR-AntonioNeural",
            tts_edge_rate=os.getenv("DANIEL_AI_TTS_EDGE_RATE", "-4%").strip() or "-4%",
            tts_edge_pitch=os.getenv("DANIEL_AI_TTS_EDGE_PITCH", "+0Hz").strip() or "+0Hz",
            tts_edge_volume=os.getenv("DANIEL_AI_TTS_EDGE_VOLUME", "+0%").strip() or "+0%",
            tts_edge_timeout_seconds=_int("DANIEL_AI_TTS_EDGE_TIMEOUT_SECONDS", 35, 10),
            tts_speechify_enabled=_bool("DANIEL_AI_TTS_SPEECHIFY_ENABLED", False),
            tts_speechify_api_key=os.getenv("SPEECHIFY_API_KEY", "").strip(),
            tts_speechify_voice_id=os.getenv("SPEECHIFY_VOICE_ID", "").strip(),
            tts_speechify_model=os.getenv("SPEECHIFY_MODEL", "simba-3.0").strip() or "simba-3.0",
            tts_speechify_language=os.getenv("SPEECHIFY_LANGUAGE", "pt-BR").strip() or "pt-BR",
            tts_speechify_base_url=os.getenv("SPEECHIFY_BASE_URL", "https://api.speechify.ai").strip() or "https://api.speechify.ai",
            tts_speechify_timeout_seconds=_int("SPEECHIFY_TIMEOUT_SECONDS", 35, 10),
            tts_supertonic_bin=os.getenv("DANIEL_AI_TTS_SUPERTONIC_BIN", "supertonic").strip() or "supertonic",
            tts_supertonic_voice=os.getenv("DANIEL_AI_TTS_SUPERTONIC_VOICE", "M1").strip() or "M1",
            tts_supertonic_lang=os.getenv("DANIEL_AI_TTS_SUPERTONIC_LANG", "pt").strip() or "pt",
            tts_supertonic_steps=_int("DANIEL_AI_TTS_SUPERTONIC_STEPS", 8, 5),
            tts_supertonic_speed=_float("DANIEL_AI_TTS_SUPERTONIC_SPEED", 1.0, 0.7, 2.0),
            tts_kokoro_python=os.getenv("DANIEL_AI_TTS_KOKORO_PYTHON", "python").strip() or "python",
            tts_kokoro_model_path=os.getenv("DANIEL_AI_TTS_KOKORO_MODEL_PATH", "").strip(),
            tts_kokoro_voices_path=os.getenv("DANIEL_AI_TTS_KOKORO_VOICES_PATH", "").strip(),
            tts_kokoro_voice=os.getenv("DANIEL_AI_TTS_KOKORO_VOICE", "pm_alex").strip() or "pm_alex",
            tts_kokoro_speed=_float("DANIEL_AI_TTS_KOKORO_SPEED", 1.0, 0.5, 2.0),
            tts_espeak_bin=os.getenv("DANIEL_AI_TTS_ESPEAK_BIN", "espeak").strip() or "espeak",
            conversational_voice_enabled=_bool("DANIEL_AI_CONVERSATIONAL_VOICE_ENABLED", True),
            conversational_voice_style=os.getenv("DANIEL_AI_CONVERSATIONAL_VOICE_STYLE", "adaptive").strip().lower() or "adaptive",
            conversational_voice_detail=os.getenv("DANIEL_AI_CONVERSATIONAL_VOICE_DETAIL", "balanced").strip().lower() or "balanced",
            conversational_voice_max_chars=_int("DANIEL_AI_CONVERSATIONAL_VOICE_MAX_CHARS", 1250, 350),
            conversational_voice_command_explainer=_bool("DANIEL_AI_CONVERSATIONAL_COMMAND_EXPLAINER", True),
            conversational_voice_natural_variation=_bool("DANIEL_AI_CONVERSATIONAL_NATURAL_VARIATION", True),
            local_llm_enabled=_bool("DANIEL_LOCAL_LLM_ENABLED", True),
            local_llm_mode=os.getenv("DANIEL_LOCAL_LLM_MODE", "smart").strip().lower() or "smart",
            local_llm_model_name=os.getenv("DANIEL_LOCAL_LLM_MODEL_NAME", "Qwen3-4B Q4_K_M").strip() or "Qwen3-4B Q4_K_M",
            local_llm_model_path=os.getenv("DANIEL_LOCAL_LLM_MODEL_PATH", "").strip(),
            local_llm_bin=os.getenv("DANIEL_LOCAL_LLM_BIN", "").strip(),
            local_llm_context_size=_int("DANIEL_LOCAL_LLM_CONTEXT", 4096, 1024),
            local_llm_max_tokens=_int("DANIEL_LOCAL_LLM_MAX_TOKENS", 320, 64),
            local_llm_threads=_int("DANIEL_LOCAL_LLM_THREADS", 4, 1),
            local_llm_timeout_seconds=_int("DANIEL_LOCAL_LLM_TIMEOUT_SECONDS", 180, 30),
            local_llm_temperature=_float("DANIEL_LOCAL_LLM_TEMPERATURE", 0.7, 0.0, 2.0),
            local_llm_top_p=_float("DANIEL_LOCAL_LLM_TOP_P", 0.8, 0.0, 1.0),
            local_llm_top_k=_int("DANIEL_LOCAL_LLM_TOP_K", 20, 1),
            local_llm_min_p=_float("DANIEL_LOCAL_LLM_MIN_P", 0.0, 0.0, 1.0),
            local_llm_history_messages=_int("DANIEL_LOCAL_LLM_HISTORY_MESSAGES", 6, 0),
        )


def ensure_directories(cfg: DanielSettings | None = None) -> DanielSettings:
    cfg = cfg or DanielSettings.from_env()
    if cfg.learned_dir is None:
        cfg = replace(cfg, learned_dir=cfg.state_dir / "learned")
    if cfg.voice_dir is None:
        cfg = replace(cfg, voice_dir=cfg.state_dir / "voice")
    cfg.state_dir.mkdir(parents=True, exist_ok=True)
    if cfg.documents_enabled:
        cfg.documents_dir.mkdir(parents=True, exist_ok=True)
    if cfg.learned_dir is not None:
        cfg.learned_dir.mkdir(parents=True, exist_ok=True)
    if cfg.voice_dir is not None:
        (cfg.voice_dir / "inbox").mkdir(parents=True, exist_ok=True)
        (cfg.voice_dir / "tmp").mkdir(parents=True, exist_ok=True)
    return cfg
