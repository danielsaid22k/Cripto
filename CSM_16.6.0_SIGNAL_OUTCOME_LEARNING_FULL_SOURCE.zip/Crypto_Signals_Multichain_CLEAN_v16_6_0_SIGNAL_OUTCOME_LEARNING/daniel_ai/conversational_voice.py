from __future__ import annotations

import html
import re
import unicodedata
import zlib
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ConversationalVoiceStatus:
    enabled: bool
    style: str
    detail: str
    max_chars: int
    structure: tuple[str, ...]
    profiles: tuple[str, ...] = ("executivo", "analista", "explicativo")
    command_explainer: bool = True
    natural_variation: bool = True


def _fold(text: str) -> str:
    value = unicodedata.normalize("NFKD", str(text or ""))
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return value.casefold()


def _clean_line(line: str) -> str:
    text = html.unescape(str(line or ""))
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"^[\s•·\-*—–]+", "", text)
    text = re.sub(r"^[^\wÀ-ÿ$%]+", "", text)
    text = text.replace("•", ", ").replace("/100", " de 100")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _lines(answer: str) -> list[str]:
    raw = html.unescape(str(answer or ""))
    raw = re.sub(r"<br\s*/?>", "\n", raw, flags=re.I)
    raw = re.sub(r"</(?:p|div|li|h\d)>", "\n", raw, flags=re.I)
    raw = re.sub(r"<[^>]+>", "", raw)
    out: list[str] = []
    for part in raw.splitlines():
        line = _clean_line(part)
        if not line:
            continue
        folded = _fold(line)
        if any(key in folded for key in (
            "somente leitura", "nao altera", "não altera", "nao e recomendacao",
            "não é recomendação", "openai:", "interpretação local baseada",
        )):
            continue
        out.append(line)
    return out


def _num(pattern: str, text: str, default: float | None = None) -> float | None:
    m = re.search(pattern, text, re.I)
    if not m:
        return default
    try:
        return float(m.group(1).replace(",", "."))
    except Exception:
        return default


def _first(pattern: str, text: str, default: str = "") -> str:
    m = re.search(pattern, text, re.I)
    return (m.group(1).strip() if m else default)


def _sentence(text: str) -> str:
    text = str(text or "").strip(" .")
    if not text:
        return ""
    text = re.sub(r"\s*,\s*,+", ", ", text)
    return text[0].upper() + text[1:] + "."


def _pt_number(value: float, digits: int = 1) -> str:
    rendered = f"{value:.{digits}f}"
    if digits and rendered.endswith("." + ("0" * digits)):
        rendered = rendered.split(".", 1)[0]
    return rendered.replace(".", ",")


def _spoken_money(value: str) -> str:
    raw = str(value or "").strip()
    m = re.fullmatch(r"\$\s*(\d+(?:[.,]\d+)?)\s*([KMB])?", raw, re.I)
    if not m:
        return raw
    try:
        numeric = float(m.group(1).replace(",", "."))
    except Exception:
        return raw
    suffix = (m.group(2) or "").upper()
    spoken = _pt_number(numeric, 1)
    if suffix == "K":
        return f"{spoken} mil dólares"
    if suffix == "M":
        return f"{spoken} milhões de dólares"
    if suffix == "B":
        return f"{spoken} bilhões de dólares"
    return f"{spoken} dólares"


def _risk_label(value: str) -> str:
    key = _fold(value).strip()
    return {
        "low": "baixo", "baixo": "baixo",
        "medium": "moderado", "moderate": "moderado", "medio": "moderado", "médio": "moderado",
        "high": "alto", "alto": "alto",
        "critical": "crítico", "critico": "crítico", "crítico": "crítico",
    }.get(key, str(value or "").strip())


def _lifecycle_label(value: str) -> str:
    key = str(value or "").strip().upper()
    return {
        "ACTIVE": "ativo", "DETERIORATING": "em deterioração", "STOPPED": "encerrado por stop",
        "EXPIRED": "expirado", "TP1": "no primeiro alvo", "TP2": "no segundo alvo", "TP3": "no terceiro alvo",
    }.get(key, str(value or "").strip())


def _looks_like_command(line: str) -> bool:
    text = re.sub(r"^\s*\d+[.)-]?\s*", "", str(line or "").strip())
    low = _fold(text)
    prefixes = (
        "csm-", "cd ", "python ", "python3 ", "bash ", "sh ", "pkg ", "apt ", "pip ",
        "pip3 ", "unzip ", "zip ", "sed ", "grep ", "printf ", "echo ", "ssh ", "scp ",
        "chmod ", "cp ", "mv ", "rm ", "mkdir ", "termux-", "git ", "curl ", "wget ",
    )
    return low.startswith(prefixes) or " main.py " in f" {low} " or low.startswith("./")


def _command_stage(line: str) -> str:
    text = re.sub(r"^\s*\d+[.)-]?\s*", "", str(line or "").strip())
    low = _fold(text)
    if low.startswith("csm-stop"):
        return "parar o serviço antes de mexer nos arquivos"
    if low.startswith("cd "):
        return "entrar na pasta correta do projeto"
    if low.startswith("unzip "):
        return "extrair o pacote da atualização"
    if low.startswith("bash install") or low.startswith("sh install"):
        return "rodar o instalador da camada nova"
    if "main.py migrate" in low:
        return "aplicar a migração preservando o estado existente"
    if "main.py db-check" in low:
        return "confirmar a integridade do banco"
    if "main.py selftest" in low:
        return "rodar o autoteste antes de subir o bot"
    if "main.py daniel" in low and "status" in low:
        return "conferir o status específico do Daniel"
    if low.startswith("sed ") and "boot" in low:
        return "apontar o boot para a nova versão"
    if low.startswith("grep ") and "project" in low:
        return "confirmar que o boot ficou apontando para a pasta certa"
    if low.startswith("csm-start"):
        return "iniciar o serviço novamente"
    if low.startswith("csm-status"):
        return "confirmar que o sistema subiu saudável"
    if low.startswith("ssh "):
        return "abrir a conexão remota com o Android"
    if low.startswith("scp "):
        return "copiar o pacote para o Android"
    return "executar a próxima etapa técnica mostrada no texto"


def _naturalize_tokens(text: str) -> str:
    value = str(text or "")
    value = re.sub(r"\b24h\b", "24 horas", value, flags=re.I)
    value = re.sub(r"\bTP1\b", "primeiro alvo", value, flags=re.I)
    value = re.sub(r"\bTP2\b", "segundo alvo", value, flags=re.I)
    value = re.sub(r"\bTP3\b", "terceiro alvo", value, flags=re.I)
    value = re.sub(r"\bGoPlus\b", "Go Plus", value, flags=re.I)
    value = re.sub(r"\bHTTP\s*429\b", "erro 429 de limite de requisições", value, flags=re.I)
    value = re.sub(r"(?<!\w)([+-]?\d+(?:[.,]\d+)?)%", lambda m: m.group(1).replace(".", ",") + " por cento", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


class ConversationalVoice:
    """Adaptive spoken layer for Daniel AI.

    Telegram keeps the complete technical answer. This class creates a second,
    voice-only representation from the same facts. V1.2.4 automatically chooses
    an executive, analyst or explanatory delivery and avoids reading commands or
    metrics line by line. It is deterministic/local and never changes CSM logic.
    """

    PROFILES = ("executive", "analyst", "explanatory")

    def __init__(self, cfg: Any):
        self.cfg = cfg

    def status(self) -> ConversationalVoiceStatus:
        style = str(getattr(self.cfg, "conversational_voice_style", "adaptive") or "adaptive").strip().lower()
        if style not in {"adaptive", "executive", "analyst", "explanatory", "concise"}:
            style = "adaptive"
        detail = str(getattr(self.cfg, "conversational_voice_detail", "balanced") or "balanced").strip().lower()
        if detail not in {"brief", "balanced", "detailed"}:
            detail = "balanced"
        return ConversationalVoiceStatus(
            enabled=bool(getattr(self.cfg, "conversational_voice_enabled", True)),
            style=style,
            detail=detail,
            max_chars=max(350, int(getattr(self.cfg, "conversational_voice_max_chars", 1250) or 1250)),
            structure=("prioridade", "contexto", "significado", "próximo passo"),
            profiles=("executivo", "analista", "explicativo"),
            command_explainer=bool(getattr(self.cfg, "conversational_voice_command_explainer", True)),
            natural_variation=bool(getattr(self.cfg, "conversational_voice_natural_variation", True)),
        )

    def select_profile(self, question: str, answer: str = "") -> str:
        configured = self.status().style
        if configured in self.PROFILES:
            return configured
        if configured == "concise":
            return "executive"
        q = _fold(question)
        a = _fold(_clean_line(answer))
        explanation_terms = (
            "por que", "porque", "me explica", "me explique", "explique", "explica", "como funciona",
            "o que significa", "qual o motivo", "qual motivo", "nao entendi", "não entendi", "como faco",
            "como faço", "como instalar", "comandos", "comando", "o que aconteceu", "como resolvo", "erro",
        )
        analyst_terms = (
            "analise", "análise", "analisa", "avaliar", "avalie", "token", "moeda", "sinal", "score",
            "liquidez", "volume", "momentum", "holder", "whale", "reentrada", "lifecycle", "tp1", "tp2",
            "tp3", "stop", "risco", "pressao compradora", "pressão compradora",
        )
        executive_terms = (
            "status", "resumo", "panorama", "como esta o sistema", "como está o sistema", "saude", "saúde",
            "operacional", "provider", "provedor", "scanner", "hoje", "agora",
        )
        if any(term in q for term in explanation_terms):
            return "explanatory"
        if any(term in q for term in analyst_terms):
            return "analyst"
        if any(term in q for term in executive_terms):
            return "executive"
        if sum(_looks_like_command(line) for line in _lines(answer)) >= 2:
            return "explanatory"
        if any(term in a for term in ("score final", "liquidez", "pressao compradora", "pressão compradora", "lifecycle")):
            return "analyst"
        return "executive"

    def _variant(self, question: str, options: tuple[str, ...]) -> str:
        if not options:
            return ""
        if not self.status().natural_variation:
            return options[0]
        seed = zlib.crc32(str(question or "").encode("utf-8"))
        return options[seed % len(options)]

    def _limit(self, text: str) -> str:
        limit = self.status().max_chars
        if len(text) <= limit:
            return text
        cut = text[:limit]
        stop = max(cut.rfind("."), cut.rfind("!"), cut.rfind("?"))
        if stop >= int(limit * 0.65):
            cut = cut[: stop + 1]
        else:
            cut = cut.rstrip(" ,;:") + "."
        return cut

    def _operational(self, question: str, lines: list[str]) -> str:
        joined = "\n".join(lines)
        health = _num(r"Providers:\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?100", joined)
        analyzed = _num(r"Scanner[^\n]*analisados\s*(\d+)", joined)
        approved = _num(r"Scanner[^\n]*aprovados\s*(\d+)", joined)
        rate = _num(r"Scanner[^\n]*taxa\s*(\d+(?:[.,]\d+)?)%", joined)
        active = _num(r"Lifecycle:[^\n]*ativos\s*(\d+)", joined, 0) or 0
        deteriorating = _num(r"Lifecycle:[^\n]*deteriorando\s*(\d+)", joined, 0) or 0
        tp3 = _num(r"Lifecycle:[^\n]*TP3\s*(\d+)", joined, 0) or 0
        stops = _num(r"Lifecycle:[^\n]*stops\s*(\d+)", joined, 0) or 0
        rejection = _first(r"Principal rejei(?:ç|c)ão:\s*([^\n,(]+)", joined)

        lead = self._variant(question, (
            "No geral, o sistema está estável.",
            "O panorama agora é bom, sem sinal de falha crítica.",
            "A leitura operacional está saudável neste momento.",
        ))
        if health is not None and health < 70:
            lead = f"O ponto mais importante agora é a saúde dos provedores, que caiu para {int(health)} de 100."
        elif deteriorating > 0:
            lead = f"O sistema continua operando, mas eu colocaria os {int(deteriorating)} sinais em deterioração no topo da atenção."
        parts = [lead]
        if health is not None and health >= 70:
            parts.append(f"Os provedores estão em {int(health)} de 100, então a infraestrutura continua respondendo bem.")
        if analyzed is not None and approved is not None:
            if rate is not None:
                parts.append(f"O scanner analisou {int(analyzed)} oportunidades e aprovou {int(approved)}, cerca de {_pt_number(rate)} por cento do total.")
            else:
                parts.append(f"O scanner analisou {int(analyzed)} oportunidades e aprovou {int(approved)}.")
            if rejection:
                parts.append(f"O principal freio nas aprovações foi {rejection}.")
        if deteriorating > 0:
            parts.append("Na prática, isso importa mais do que repetir todas as métricas, porque deterioração indica mudança de condição depois do sinal.")
        elif stops > 0:
            parts.append(f"Também há {int(stops)} registro de stop; eu revisaria esse ponto para ver se existe algum padrão se repetindo.")
        elif active or tp3:
            parts.append(f"No pós-sinal, há {int(active)} ativos em acompanhamento e {int(tp3)} que chegaram ao terceiro alvo, sem um alerta forte de deterioração no resumo.")
        parts.append(self._variant(question, (
            "Se eu tivesse que priorizar uma coisa agora, seria acompanhar qualquer mudança nos sinais ativos antes de mexer no restante.",
            "Então eu manteria o sistema rodando e observaria primeiro qualquer piora no lifecycle ou nos provedores.",
            "Em resumo, não vejo motivo para intervenção imediata; eu só manteria atenção nas mudanças de condição.",
        )))
        return " ".join(parts)

    def _signal(self, question: str, lines: list[str]) -> str:
        joined = "\n".join(lines)
        name = "o ativo"
        for line in lines[:4]:
            m = re.match(r"([^,]+),\s*[A-Z0-9_-]{2,15}$", line)
            if m and "Daniel AI" not in line:
                name = m.group(1).strip()
                break
        if name == "o ativo" and len(lines) > 1:
            candidate = re.sub(r"\s*,.*$", "", lines[1]).strip()
            if candidate and "score" not in _fold(candidate):
                name = candidate
        score = _num(r"Score final:\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?100", joined)
        liquidity = _first(r"Liquidez:\s*([^,\n]+)", joined)
        volume = _first(r"Vol24h:\s*([^,\n]+)", joined)
        pressure = _num(r"Pressão compradora 24h:\s*(\d+(?:[.,]\d+)?)%", joined)
        risk = _first(r"GoPlus:[^\n]*risco\s*([^,\n]+)", joined)
        lifecycle = _first(r"Lifecycle:\s*([^,\n]+)", joined)

        parts: list[str] = []
        if score is not None:
            s = int(score)
            if s >= 85:
                parts.append(f"{name} está com uma leitura forte: o score registrado é {s} de 100.")
            elif s >= 70:
                parts.append(f"{name} está numa faixa positiva, com score de {s} de 100, mas ainda vale olhar o conjunto antes de tirar conclusão.")
            else:
                parts.append(f"{name} está com uma leitura mais cautelosa, em {s} de 100.")
        else:
            parts.append(f"Sobre {name}, eu olharia primeiro a qualidade do conjunto, e não uma métrica isolada.")
        market_bits = []
        if liquidity:
            market_bits.append(f"liquidez de {_spoken_money(liquidity)}")
        if volume:
            market_bits.append(f"volume de 24 horas de {_spoken_money(volume)}")
        if market_bits:
            parts.append("A estrutura de mercado mostra " + " e ".join(market_bits) + ".")
        if pressure is not None:
            if pressure >= 60:
                parts.append(f"O fluxo ainda favorece compradores, com pressão compradora em {_pt_number(pressure)} por cento.")
            elif pressure < 45:
                parts.append(f"Aqui aparece um sinal de enfraquecimento: a pressão compradora está em {_pt_number(pressure)} por cento.")
            else:
                parts.append(f"A pressão compradora está equilibrada, em {_pt_number(pressure)} por cento.")
        if risk:
            parts.append(f"Na segurança, o risco do Go Plus aparece como {_risk_label(risk)}.")
        if lifecycle:
            parts.append(f"Depois do envio, o lifecycle está {_lifecycle_label(lifecycle)}.")
        parts.append(self._variant(question, (
            "O que eu observaria daqui para frente é se preço, liquidez e fluxo continuam apontando na mesma direção.",
            "O ponto decisivo agora é a continuidade: se o fluxo enfraquecer junto com liquidez, a leitura muda rapidamente.",
            "Então eu usaria esses dados como contexto e acompanharia a evolução antes de tratar o score como conclusão final.",
        )))
        return " ".join(parts)

    def _score(self, question: str, lines: list[str]) -> str:
        joined = "\n".join(lines)
        title = _first(r"Explicação do score\s*[-—:]\s*([^\n]+)", joined, "esse ativo")
        score = _num(r"Score final registrado:\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?100", joined)
        market = _num(r"Score de mercado registrado:\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?100", joined)
        goplus = _num(r"GoPlus registrado:\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?100", joined)
        reasons = [ln for ln in lines if any(k in _fold(ln) for k in ("liquidez", "pressao", "volume", "holder", "risco", "momentum", "compra", "segur"))]
        parts = [f"O jeito mais útil de entender o score de {title} é pensar nele como um resumo de várias evidências, não como uma nota mágica."]
        if score is not None:
            parts.append(f"O valor final registrado é {int(score)} de 100.")
        comps = []
        if market is not None:
            comps.append(f"mercado em {int(market)} de 100")
        if goplus is not None:
            comps.append(f"segurança Go Plus em {int(goplus)} de 100")
        if comps:
            parts.append("Entre as referências persistidas aparecem " + " e ".join(comps) + ".")
        if reasons:
            cleaned = [r.rstrip(".") for r in reasons[:2] if len(r) <= 180]
            if cleaned:
                parts.append("Os fatores que mais ajudam a explicar a leitura são " + "; ".join(cleaned) + ".")
        parts.append("Na prática, eu confiaria mais na direção conjunta desses fatores do que numa diferença pequena de alguns pontos no score.")
        return " ".join(parts)

    def _lifecycle(self, question: str, lines: list[str]) -> str:
        states_line = next((ln for ln in lines if "ativos" in _fold(ln) and "deterior" in _fold(ln)), "")
        deteriorating = [ln for ln in lines if "risco" in _fold(ln) and "retorno" in _fold(ln)][:3]
        parts = ["No lifecycle, o que importa é a mudança depois que o sinal já foi enviado."]
        if states_line:
            parts.append(_sentence(_naturalize_tokens(states_line)))
        if deteriorating:
            names = [re.split(r"\s+[A-Z]{2,12}\s*,|,\s*retorno", ln)[0].strip() for ln in deteriorating]
            names = [n for n in names if n]
            if names:
                parts.append("Os que mais chamam atenção agora são " + ", ".join(names) + ", porque já existe deterioração registrada.")
        parts.append(self._variant(question, (
            "Eu acompanharia se essa deterioração continua aumentando ou se os sinais voltam a estabilizar nas próximas leituras.",
            "O próximo passo é simples: observar a direção, porque uma piora contínua pesa mais do que uma oscilação isolada.",
            "Então a prioridade é acompanhar tendência de melhora ou piora, e não reagir a um único ponto do histórico.",
        )))
        return " ".join(parts)

    def _providers(self, question: str, lines: list[str], profile: str = "executive") -> str:
        joined = "\n".join(lines)
        health = _num(r"(?:health geral|Providers:)\s*(\d+(?:[.,]\d+)?)\s*(?:de\s*)?100", joined)
        issues = [ln for ln in lines if any(k in _fold(ln) for k in ("quota", "cooldown", "degraded", "offline", "429", "atencao"))][:2]
        if profile == "explanatory":
            parts = ["O ponto central é separar o que aconteceu do impacto real no scanner."]
            if issues:
                parts.append("O que aconteceu foi isto: " + "; ".join(_naturalize_tokens(i.rstrip(".")) for i in issues) + ".")
                parts.append("Isso importa porque uma limitação do provedor não significa, por si só, que o scanner parou.")
                parts.append("Como consequência, o fallback pode continuar cobrindo a consulta enquanto o provedor principal se recupera.")
            else:
                parts.append("No resumo atual eu não vejo uma falha de provedor que esteja produzindo impacto operacional relevante.")
            if health is not None:
                parts.append(f"A saúde agregada está em {int(health)} de 100, que serve como contexto para medir se a situação está piorando ou estabilizando.")
            parts.append("Eu só trataria isso como prioridade alta se a falha persistisse e começasse a reduzir a cobertura do scanner.")
            return " ".join(parts)
        parts = []
        if health is not None and health >= 90 and not issues:
            parts.append(f"Os provedores estão saudáveis, em {int(health)} de 100, e eu não vejo impacto operacional relevante agora.")
        elif health is not None:
            parts.append(f"A saúde agregada dos provedores está em {int(health)} de 100.")
        else:
            parts.append("Sobre os provedores, o ponto principal é separar uma falha isolada de um impacto real no scanner.")
        if issues:
            parts.append("Há alguns pontos de atenção: " + "; ".join(_naturalize_tokens(i.rstrip(".")) for i in issues) + ".")
            parts.append("Mesmo assim, isso só vira problema maior se começar a reduzir cobertura; antes disso, o fallback continua absorvendo parte da instabilidade.")
        else:
            parts.append("No resumo atual não aparece uma degradação que exija intervenção.")
        parts.append("Eu só elevaria a prioridade se a falha persistisse ou começasse a afetar a capacidade do scanner de encontrar e validar oportunidades.")
        return " ".join(parts)

    def _command_guidance(self, question: str, lines: list[str]) -> str:
        commands = [ln for ln in lines if _looks_like_command(ln)]
        stages: list[str] = []
        for command in commands:
            stage = _command_stage(command)
            if stage not in stages:
                stages.append(stage)
        if not stages:
            return self._generic(question, lines, profile="explanatory")
        parts = [self._variant(question, (
            "Eu não vou ler os comandos um por um, porque isso fica pouco natural. O texto continua com tudo para você copiar.",
            "Os comandos exatos ficam no texto. No áudio, eu prefiro te explicar o que cada etapa está fazendo.",
            "Em vez de soletrar terminal linha por linha, vou te passar a lógica da sequência e deixar os comandos completos na mensagem.",
        ))]
        if stages:
            parts.append("A sequência é esta: primeiro, " + stages[0] + ".")
        if len(stages) > 1:
            parts.append("Depois, " + "; em seguida, ".join(stages[1:6]) + ".")
        if len(stages) > 6:
            parts.append("As etapas finais ficam no texto, na mesma ordem, para você executar sem risco de copiar algo errado pelo áudio.")
        parts.append("Se alguma etapa devolver erro, pare ali e use a mensagem exata do terminal como referência; não vale continuar no escuro.")
        return " ".join(parts)

    def _generic(self, question: str, lines: list[str], *, profile: str) -> str:
        useful: list[str] = []
        for line in lines:
            folded = _fold(line)
            if len(line) < 3 or folded.startswith("daniel ai v") or _looks_like_command(line):
                continue
            useful.append(_naturalize_tokens(re.sub(r"\s*,\s*", ", ", line)))
            if len(useful) >= (4 if profile == "executive" else 6):
                break
        if not useful:
            return "Eu processei a solicitação, mas não tenho conteúdo suficiente para montar uma explicação falada confiável. O texto continua sendo a referência completa."
        if profile == "explanatory":
            parts = [self._variant(question, (
                "O ponto central é o seguinte.",
                "A forma mais simples de entender isso é esta.",
                "O que está acontecendo, na prática, é o seguinte.",
            ))]
            parts.append(_sentence(useful[0]))
            if len(useful) > 1:
                parts.append("Isso importa porque " + useful[1][:1].lower() + useful[1][1:].rstrip(".") + ".")
            if len(useful) > 2:
                parts.append("Como consequência, " + useful[2][:1].lower() + useful[2][1:].rstrip(".") + ".")
            for line in useful[3:5]:
                parts.append(_sentence(line))
            parts.append("Se você quiser conferir os detalhes exatos, eles continuam no texto; no áudio eu estou priorizando entendimento, não leitura literal.")
            return " ".join(parts)
        if profile == "analyst":
            parts = [self._variant(question, (
                "O que mais pesa nessa leitura é o seguinte.",
                "O dado mais útil aqui não é um número isolado, e sim o conjunto.",
                "Eu separaria essa análise em sinal principal e contexto.",
            ))]
            parts.extend(_sentence(line) for line in useful[:4])
            parts.append("Eu acompanharia principalmente qualquer mudança de direção nos próximos dados, porque é isso que pode alterar a interpretação.")
            return " ".join(parts)
        parts = [self._variant(question, (
            "O resumo é este.",
            "O que importa agora é o seguinte.",
            "Em poucas palavras, a situação é esta.",
        ))]
        parts.extend(_sentence(line) for line in useful[:3])
        return " ".join(parts)

    def _apply_profile(self, text: str, profile: str) -> str:
        status = self.status()
        sentences = [x.strip() for x in re.split(r"(?<=[.!?])\s+", text) if x.strip()]
        if status.detail == "brief":
            cap = 4
        elif profile == "executive":
            cap = 6 if status.detail == "balanced" else 8
        elif profile == "analyst":
            cap = 8 if status.detail == "balanced" else 11
        else:
            cap = 8 if status.detail == "balanced" else 10
        if status.style == "concise":
            cap = min(cap, 5)
        return " ".join(sentences[:cap])

    def render(self, question: str, answer: str) -> str:
        status = self.status()
        if not status.enabled:
            return _clean_line(answer)
        lines = _lines(answer)
        q = _fold(question)
        a = _fold("\n".join(lines))
        profile = self.select_profile(question, answer)
        command_count = sum(_looks_like_command(line) for line in lines)

        if status.command_explainer and command_count >= 2:
            spoken = self._command_guidance(question, lines)
            profile = "explanatory"
        elif any(k in q for k in ("status operacional", "como esta o sistema", "como está o sistema", "operacional do sistema")) or "operational copilot" in a:
            spoken = self._operational(question, lines)
        elif ((any(k in q for k in ("por que", "porque", "explique", "explica", "me explica")) and "score" in q) or "explicacao do score" in a):
            spoken = self._score(question, lines)
            profile = "explanatory"
        elif any(k in q for k in ("como estao os sinais", "como estão os sinais", "sinais deterior", "lifecycle", "tp1", "tp2", "tp3", "stop")):
            spoken = self._lifecycle(question, lines)
        elif any(k in q for k in ("provider", "provedor", "birdeye", "gecko", "dexscreener", "goplus")):
            spoken = self._providers(question, lines, profile=profile)
        elif any(k in q for k in ("analise", "análise", "analisa", "avaliar", "avalie")) or "analise local" in a or "análise local" in a:
            spoken = self._signal(question, lines)
        else:
            spoken = self._generic(question, lines, profile=profile)
        spoken = _naturalize_tokens(re.sub(r"\s+", " ", spoken).strip())
        spoken = self._apply_profile(spoken, profile)
        return self._limit(spoken)
