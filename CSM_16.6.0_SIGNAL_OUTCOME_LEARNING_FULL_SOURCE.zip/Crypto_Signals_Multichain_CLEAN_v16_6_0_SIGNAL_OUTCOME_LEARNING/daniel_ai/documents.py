from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

TEXT_EXTENSIONS = {".txt", ".md", ".json", ".csv", ".log"}
RICH_EXTENSIONS = {".docx", ".pdf"}
SUPPORTED_EXTENSIONS = TEXT_EXTENSIONS | RICH_EXTENSIONS


@dataclass(frozen=True)
class ExtractedDocument:
    name: str
    path: Path
    text: str
    size: int
    sha256: str
    modified_ns: int
    format: str


def _clean_text(text: str) -> str:
    text = str(text or "").replace("\x00", " ")
    text = re.sub(r"[\t\f\v]+", " ", text)
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _extract_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as zf:
        raw = zf.read("word/document.xml")
    root = ElementTree.fromstring(raw)
    paragraphs: list[str] = []
    for paragraph in root.iter():
        if not paragraph.tag.endswith("}p"):
            continue
        words: list[str] = []
        for node in paragraph.iter():
            if node.tag.endswith("}t") and node.text:
                words.append(node.text)
        if words:
            paragraphs.append("".join(words))
    return _clean_text("\n".join(paragraphs))


def _extract_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except Exception as exc:  # pragma: no cover - guarded by packaging/runtime
        raise RuntimeError("suporte PDF requer pypdf") from exc
    reader = PdfReader(str(path))
    pages: list[str] = []
    for page in reader.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception:
            pages.append("")
    return _clean_text("\n\n".join(pages))


def _extract_csv(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="replace")
    try:
        rows = list(csv.reader(io.StringIO(raw)))
    except Exception:
        return _clean_text(raw)
    return _clean_text("\n".join(" | ".join(cell.strip() for cell in row) for row in rows))


def _extract_json(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="replace")
    try:
        data = json.loads(raw)
        return _clean_text(json.dumps(data, ensure_ascii=False, indent=2))
    except Exception:
        return _clean_text(raw)


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError("formato não permitido")
    if suffix == ".docx":
        return _extract_docx(path)
    if suffix == ".pdf":
        return _extract_pdf(path)
    if suffix == ".csv":
        return _extract_csv(path)
    if suffix == ".json":
        return _extract_json(path)
    return _clean_text(path.read_text(encoding="utf-8", errors="replace"))


def document_fingerprint(path: Path) -> tuple[str, int, int]:
    payload = path.read_bytes()
    stat = path.stat()
    return hashlib.sha256(payload).hexdigest(), int(stat.st_size), int(stat.st_mtime_ns)


def load_document(root: Path, path: Path, *, max_bytes: int = 8 * 1024 * 1024) -> ExtractedDocument:
    root = root.resolve()
    target = path.resolve()
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise ValueError("caminho fora da pasta autorizada") from exc
    if not target.is_file() or target.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError("documento inexistente ou formato não permitido")
    stat = target.stat()
    if stat.st_size > max_bytes:
        raise ValueError(f"documento excede o limite de {max_bytes // (1024 * 1024)} MB")
    sha256, size, modified_ns = document_fingerprint(target)
    text = extract_text(target)
    return ExtractedDocument(
        name=target.relative_to(root).as_posix(),
        path=target,
        text=text,
        size=size,
        sha256=sha256,
        modified_ns=modified_ns,
        format=target.suffix.lower().lstrip("."),
    )


def chunk_text(text: str, *, chunk_chars: int = 1400, overlap: int = 180) -> list[str]:
    clean = _clean_text(text)
    if not clean:
        return []
    chunk_chars = max(400, min(int(chunk_chars), 4000))
    overlap = max(0, min(int(overlap), chunk_chars // 3))
    chunks: list[str] = []
    start = 0
    length = len(clean)
    while start < length:
        end = min(length, start + chunk_chars)
        if end < length:
            boundary = max(clean.rfind("\n", start + chunk_chars // 2, end), clean.rfind(". ", start + chunk_chars // 2, end))
            if boundary > start:
                end = boundary + 1
        chunk = clean[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= length:
            break
        start = max(start + 1, end - overlap)
    return chunks


def query_tokens(text: str) -> list[str]:
    words = re.findall(r"[A-Za-zÀ-ÿ0-9][A-Za-zÀ-ÿ0-9._-]{1,}", str(text or "").casefold())
    stop = {
        "sobre", "documento", "documentos", "arquivo", "arquivos", "procure", "buscar", "busque", "pesquise",
        "diga", "que", "dos", "das", "nos", "nas", "para", "com", "uma", "um", "por", "qual", "quais",
        "leia", "base", "conhecimento", "local", "daniel", "ai", "me", "o", "a", "e", "de", "do", "da",
    }
    return [word for word in words if word not in stop][:12]
