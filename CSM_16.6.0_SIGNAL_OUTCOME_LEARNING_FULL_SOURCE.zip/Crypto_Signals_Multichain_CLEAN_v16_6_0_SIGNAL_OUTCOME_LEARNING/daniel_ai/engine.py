from __future__ import annotations

import html
import re
import unicodedata
from typing import Any
from urllib.parse import urlparse

from . import __version__
from .config import DanielSettings, ensure_directories
from .memory import DanielMemory
from .documents import chunk_text, load_document, query_tokens
from .personality import CAPABILITIES
from .tools import DanielTools, ToolResult
from .web import WebClient, WebSecurityError


def _fmt_money(value: Any) -> str:
    try:
        v = float(value or 0)
    except (TypeError, ValueError):
        v = 0.0
    if abs(v) >= 1_000_000_000:
        return f"${v/1_000_000_000:.2f}B"
    if abs(v) >= 1_000_000:
        return f"${v/1_000_000:.2f}M"
    if abs(v) >= 1_000:
        return f"${v/1_000:.1f}K"
    return f"${v:.2f}"


def _pct(value: Any) -> str:
    try:
        return f"{float(value or 0):+.2f}%"
    except (TypeError, ValueError):
        return "0.00%"


def _float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _fold_text(text: str) -> str:
    raw = unicodedata.normalize("NFKD", str(text or "").casefold())
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", raw).strip()


def _safe(value: Any, limit: int = 300) -> str:
    text = str(value or "").strip()
    return html.escape(text[:limit])


def _plain_text(value: Any, limit: int = 300) -> str:
    text = html.unescape(str(value or ""))
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:limit]


def _normalize_memory_key(text: str) -> str:
    raw = _fold_text(text)
    raw = re.sub(r"^[\s]*(?:o|a|os|as)\s+", "", raw)
    raw = re.sub(r"^[\s]*(?:meu|minha|meus|minhas)\s+", "", raw)
    raw = re.sub(r"[^a-z0-9 _-]+", " ", raw)
    return re.sub(r"\s+", " ", raw).strip()[:120]


def _memory_statement(question: str) -> tuple[str, str] | None:
    text = str(question or "").strip().rstrip(".!?")
    m = re.match(r"(?is)^(?:por favor[,.]?\s*)?(?:lembre(?:-se)?|lembra|memorize|guarde|salve|anote)\s+(?:de\s+)?(?:que\s+)?(.+)$", text)
    if not m:
        return None
    statement = m.group(1).strip()
    pair = re.match(r"(?is)^(?:o\s+|a\s+)?(?:meu|minha|meus|minhas)\s+(.+?)\s+(?:é|e|=|:)\s*(.+)$", statement)
    if not pair:
        pair = re.match(r"(?is)^(.+?)\s*(?:=|:)\s*(.+)$", statement)
    if pair:
        key = _normalize_memory_key(pair.group(1))
        value = pair.group(2).strip()
    else:
        key = _normalize_memory_key(statement[:80])
        value = statement
    if not key or not value:
        return None
    return key, value[:4000]


def _memory_query_key(question: str) -> str:
    q = str(question or "").strip().rstrip(".!?")
    q = re.sub(r"(?is)^(?:daniel[,.]?\s*)?", "", q)
    q = re.sub(r"(?is)^(?:qual|quais|o que|oque|me diga|diga|lembra|recorda)\s+(?:é|e|são|sao|sobre)?\s*", "", q)
    q = re.sub(r"(?is)^(?:o|a|os|as)\s+", "", q)
    return _normalize_memory_key(q)


def _buyer_pressure(row: dict[str, Any]) -> float | None:
    buys = _float(row.get("buys24h"))
    sells = _float(row.get("sells24h"))
    total = buys + sells
    if total <= 0:
        return None
    return buys / total * 100.0


def _extract_compare_terms(question: str) -> tuple[str, str] | None:
    text = str(question or "").strip().rstrip(".!?")
    patterns = (
        r"(?is)^(?:compare|comparar|comparação|comparacao)\s+(?:o\s+|a\s+)?(.+?)\s+(?:com|versus|vs\.?|x)\s+(?:o\s+|a\s+)?(.+)$",
        r"(?is)^(?:compare|comparar|comparação|comparacao)\s+(?:o\s+|a\s+)?(.+?)\s+e\s+(?:o\s+|a\s+)?(.+)$",
    )
    for pattern in patterns:
        m = re.match(pattern, text)
        if m:
            left = m.group(1).strip(" \"'“”")
            right = m.group(2).strip(" \"'“”")
            if left and right:
                return left[:120], right[:120]
    return None


def _extract_signal_term(question: str) -> str:
    text = str(question or "").strip().rstrip(".!?")
    patterns = (
        r"(?is)^(?:analise|análise|analisa|analisar|avalie|avaliar)\s+(?:o\s+|a\s+)?(?:token|moeda|sinal|ativo)?\s*[:\-]?\s*(.+)$",
        r"(?is)^(?:explique|explica)\s+(?:o\s+)?score\s+(?:do|da|de)\s+(?:token\s+|moeda\s+|sinal\s+)?(.+)$",
        r"(?is)^(?:score)\s+(?:do|da|de)\s+(?:token\s+|moeda\s+|sinal\s+)?(.+)$",
        r"(?is)^por\s+que\s+(?:o\s+|a\s+)?(?:token\s+|moeda\s+|sinal\s+)?(.+?)\s+(?:recebeu|tem|ficou|esta|está)\s+(?:com\s+)?score\b.*$",
    )
    for pattern in patterns:
        m = re.match(pattern, text)
        if m:
            candidate = m.group(1).strip(" \"'“”")
            candidate = re.sub(r"(?is)\s+(?:recebeu|tem|ficou|esta|está)\s+(?:com\s+)?score.*$", "", candidate).strip()
            if candidate:
                return candidate[:120]
    # Uppercase ticker fallback is deliberately conservative. It avoids
    # treating words such as "scanner" or "sistema" as token identifiers.
    tickers = re.findall(r"(?<![A-Za-z0-9])([A-Z][A-Z0-9._-]{1,19})(?![A-Za-z0-9])", text)
    blocked = {"AI", "CSM", "API", "OFF", "ON", "BSC", "BNB", "ETH", "SOL", "BASE"}
    for ticker in tickers:
        if ticker not in blocked:
            return ticker
    return ""


def _extract_network(question: str) -> str:
    q = _fold_text(question)
    aliases = (
        ("binance smart chain", "bsc"), ("bnb smart chain", "bsc"), ("bsc", "bsc"), ("bnb", "bsc"),
        ("ethereum", "ethereum"), ("etherium", "ethereum"), ("eth", "ethereum"),
        ("solana", "solana"), ("sol", "solana"), ("base", "base"),
        ("arbitrum", "arbitrum"), ("polygon", "polygon"), ("avalanche", "avalanche"),
        ("optimism", "optimism"), ("fantom", "fantom"), ("cronos", "cronos"),
        ("sui", "sui"), ("ton", "ton"), ("zksync", "zksync"), ("sonic", "sonic"),
    )
    for alias, canonical in aliases:
        if re.search(rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])", q):
            return canonical
    return ""


class DanielAI:
    def __init__(self, cfg: DanielSettings | None = None, *, tools: DanielTools | None = None, memory: DanielMemory | None = None, web_client: WebClient | None = None):
        self.cfg = ensure_directories(cfg or DanielSettings.from_env())
        self.tools = tools or DanielTools(self.cfg)
        self._memory = memory
        self._web_client = web_client

    def _web_ctx(self) -> WebClient:
        if self._web_client is None:
            self._web_client = WebClient(
                timeout_seconds=self.cfg.web_timeout_seconds,
                max_bytes=self.cfg.web_max_bytes,
                max_results=self.cfg.web_max_results,
            )
        return self._web_client

    def _memory_ctx(self) -> DanielMemory:
        if self._memory is None:
            self._memory = DanielMemory(self.cfg.db_file)
        return self._memory

    def status(self) -> dict[str, Any]:
        result = self.tools.system_status()
        counts = {"conversations": 0, "memories": 0, "tool_audit": 0}
        learning = {"learned_items": 0, "pending_topics": 0, "expired_items": 0, "last_topic": "", "last_learned_at": "", "last_confidence": 0}
        if self.cfg.memory_enabled:
            try:
                counts = self._memory_ctx().counts()
                learning = self._memory_ctx().learning_stats()
            except Exception:
                pass
        voice = {"enabled": bool(getattr(self.cfg, "voice_enabled", True)), "ready": False, "backend": "whisper.cpp", "missing": []}
        try:
            from .voice import DanielVoice
            vs = DanielVoice(self.cfg).status()
            voice = {
                "enabled": vs.enabled,
                "ready": vs.ready,
                "backend": vs.backend,
                "language": vs.language,
                "model_path": vs.model_path,
                "whisper_bin": vs.whisper_bin,
                "ffmpeg_bin": vs.ffmpeg_bin,
                "max_seconds": vs.max_seconds,
                "max_bytes": vs.max_bytes,
                "missing": list(vs.missing),
            }
        except Exception:
            pass
        speech = {"enabled": bool(getattr(self.cfg, "tts_enabled", True)), "ready": False, "backend": "neural auto", "missing": []}
        conversational_voice = {"enabled": bool(getattr(self.cfg, "conversational_voice_enabled", True)), "style": "executive", "detail": "balanced"}
        try:
            from .conversational_voice import ConversationalVoice
            cvs = ConversationalVoice(self.cfg).status()
            conversational_voice = {
                "enabled": cvs.enabled,
                "style": cvs.style,
                "detail": cvs.detail,
                "max_chars": cvs.max_chars,
                "structure": list(cvs.structure),
            }
        except Exception:
            pass
        local_llm = {"enabled": bool(getattr(self.cfg, "local_llm_enabled", True)), "ready": False, "mode": "smart", "backend": "llama.cpp / GGUF local", "missing": []}
        try:
            from .local_llm import DanielLocalLLM
            ls = DanielLocalLLM(self.cfg).status()
            local_llm = {
                "enabled": ls.enabled,
                "ready": ls.ready,
                "mode": ls.mode,
                "backend": ls.backend,
                "model_name": ls.model_name,
                "model_path": ls.model_path,
                "llama_bin": ls.llama_bin,
                "context_size": ls.context_size,
                "max_tokens": ls.max_tokens,
                "threads": ls.threads,
                "timeout_seconds": ls.timeout_seconds,
                "missing": list(ls.missing),
            }
        except Exception:
            pass
        try:
            from .tts import DanielSpeech
            ss = DanielSpeech(self.cfg).status()
            speech = {
                "enabled": ss.enabled,
                "ready": ss.ready,
                "backend": ss.backend,
                "selected_engine": ss.selected_engine,
                "neural_ready": ss.neural_ready,
                "available_engines": list(ss.available_engines),
                "voice": ss.voice,
                "espeak_bin": ss.espeak_bin,
                "supertonic_bin": ss.supertonic_bin,
                "kokoro_model_path": ss.kokoro_model_path,
                "ffmpeg_bin": ss.ffmpeg_bin,
                "speed": ss.speed,
                "max_chars": ss.max_chars,
                "missing": list(ss.missing),
            }
        except Exception:
            pass
        return {
            "version": __version__,
            "enabled": self.cfg.enabled,
            "mode": self.cfg.mode,
            "openai_enabled": self.cfg.openai_enabled,
            "openai_ready": self.cfg.openai_ready,
            "admin_only": self.cfg.admin_only,
            "memory_enabled": self.cfg.memory_enabled,
            "web_enabled": self.cfg.web_enabled,
            "web_timeout_seconds": self.cfg.web_timeout_seconds,
            "learning_enabled": self.cfg.learning_enabled,
            "learning_interval_minutes": self.cfg.learning_interval_minutes,
            "learning_ttl_hours": self.cfg.learning_ttl_hours,
            "voice": voice,
            "speech": speech,
            "conversational_voice": conversational_voice,
            "local_llm": local_llm,
            "web_max_results": self.cfg.web_max_results,
            "documents_enabled": self.cfg.documents_enabled,
            "documents_dir": str(self.cfg.documents_dir),
            "state_dir": str(self.cfg.state_dir),
            "counts": counts,
            "learning": learning,
            "csm": result.data if result.ok else {"error": result.summary},
            "tools": self.tools.names(),
        }

    def _audit(self, user_id: int, result: ToolResult) -> None:
        if not self.cfg.memory_enabled:
            return
        try:
            self._memory_ctx().audit_tool(user_id, result.name, result.summary)
        except Exception:
            pass

    def _audit_external(self, user_id: int, tool: str, summary: str) -> None:
        if not self.cfg.memory_enabled:
            return
        try:
            self._memory_ctx().audit_tool(user_id, tool, summary)
        except Exception:
            pass

    def _remember_exchange(self, user_id: int, question: str, answer: str, source: str = "local") -> None:
        if not self.cfg.memory_enabled:
            return
        try:
            mem = self._memory_ctx()
            mem.add_message(user_id, "user", question, source=source)
            mem.add_message(user_id, "assistant", answer, source=source)
        except Exception:
            pass

    def _remember_fact(self, user_id: int, question: str) -> str | None:
        if not self.cfg.memory_enabled:
            return "⚠️ A memória do Daniel AI está desativada."
        parsed = _memory_statement(question)
        if not parsed:
            return None
        key, value = parsed
        try:
            self._memory_ctx().remember(key, value, user_id)
        except Exception:
            return "⚠️ Não consegui gravar essa memória agora."
        return f"🧠 <b>Memória salva</b>\n<b>{_safe(key)}</b>: {_safe(value, 1000)}\n\nEla fica no banco local do Daniel AI."

    def _list_memories(self, user_id: int) -> str:
        if not self.cfg.memory_enabled:
            return "⚠️ A memória do Daniel AI está desativada."
        rows = self._memory_ctx().memories(user_id, limit=20)
        if not rows:
            return "🧠 Ainda não tenho memórias explícitas salvas para você."
        lines = ["🧠 <b>Memórias salvas</b>"]
        for row in rows:
            lines.append(f"• <b>{_safe(row['key'])}</b>: {_safe(row['value'], 500)}")
        return "\n".join(lines)

    def _conversation_history(self, user_id: int, limit: int = 8) -> str:
        if not self.cfg.memory_enabled:
            return "⚠️ O histórico persistente está desativado."
        rows = self._memory_ctx().history(user_id, limit=max(2, min(limit, 20)))
        if not rows:
            return "🧠 Ainda não há conversas persistidas para este usuário."
        lines = ["🗂️ <b>Histórico recente com Daniel AI</b>"]
        for row in rows:
            role = "Você" if row.get("role") == "user" else "Daniel"
            # Respostas antigas podem conter HTML do Telegram. Removemos as tags
            # antes de escapar para que <b> não apareça literalmente no histórico.
            content = _plain_text(row.get("content"), 190 if role == "Daniel" else 150)
            if not content:
                continue
            if len(_plain_text(row.get("content"), 10000)) > len(content):
                content = content.rstrip(" .") + "…"
            lines.append(f"• <b>{role}</b>: {_safe(content, 220)}")
        lines.append("\nℹ️ Histórico compacto; respostas longas são resumidas para manter o Telegram legível.")
        return "\n".join(lines)

    def _recall_fact(self, user_id: int, question: str) -> str | None:
        if not self.cfg.memory_enabled:
            return None
        rows = self._memory_ctx().memories(user_id, limit=100)
        if not rows:
            return None
        wanted = _memory_query_key(question)
        if not wanted:
            return None
        wanted_tokens = set(wanted.split())
        ranked = []
        for row in rows:
            key = _normalize_memory_key(row.get("key", ""))
            key_tokens = set(key.split())
            overlap = len(wanted_tokens & key_tokens)
            exact = 3 if key == wanted else 0
            contains = 2 if key and (key in wanted or wanted in key) else 0
            score = exact + contains + overlap
            if score > 0:
                ranked.append((score, row))
        if not ranked:
            return None
        ranked.sort(key=lambda item: item[0], reverse=True)
        row = ranked[0][1]
        return f"🧠 Eu lembro: <b>{_safe(row['key'])}</b> = {_safe(row['value'], 1000)}"

    def _forget_fact(self, user_id: int, question: str) -> str | None:
        if not self.cfg.memory_enabled:
            return "⚠️ A memória do Daniel AI está desativada."
        text = str(question or "").strip().rstrip(".!?")
        m = re.match(r"(?is)^(?:esqueça|esqueca|apague|remova)\s+(?:da\s+memória\s+)?(?:que\s+)?(.+)$", text)
        if not m:
            return None
        key = _normalize_memory_key(m.group(1))
        rows = self._memory_ctx().memories(user_id, limit=100)
        for row in rows:
            stored = _normalize_memory_key(row.get("key", ""))
            if stored == key or stored in key or key in stored:
                self._memory_ctx().forget(row["key"], user_id)
                return f"🗑️ Memória removida: <b>{_safe(row['key'])}</b>."
        return "🧠 Não encontrei uma memória correspondente para apagar."

    def _top_signals(self, user_id: int, days: int = 1) -> str:
        result = self.tools.top_signals(days=days, limit=5)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Não consegui consultar sinais: {_safe(result.summary)}."
        if not result.data:
            return f"📭 Não há sinais registrados nos últimos {days} dia(s)."
        lines = [f"🏆 <b>Melhores sinais — {days} dia(s)</b>"]
        for i, row in enumerate(result.data, 1):
            symbol = row.get("symbol") or row.get("name") or str(row.get("address") or "")[:10]
            lines.append(
                f"{i}. <b>{_safe(symbol)}</b> • {_safe(str(row.get('chain') or '').upper())} • score {_int(row.get('final_score'))}/100\n"
                f"   Liquidez {_fmt_money(row.get('liquidity'))} • Vol24h {_fmt_money(row.get('volume24h'))} • 24h {_pct(row.get('change24h'))}"
            )
        lines.append("\n🧠 Modo local: ranking baseado nos dados já persistidos pelo CSM.")
        return "\n".join(lines)

    def _recent_signals(self, user_id: int) -> str:
        result = self.tools.recent_signals(limit=5)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Não consegui consultar sinais: {_safe(result.summary)}."
        if not result.data:
            return "📭 Ainda não há sinais registrados no ledger."
        lines = ["🧾 <b>Sinais mais recentes</b>"]
        for row in result.data:
            symbol = row.get("symbol") or row.get("name") or str(row.get("address") or "")[:10]
            lines.append(f"• <b>{_safe(symbol)}</b> • {_safe(str(row.get('chain') or '').upper())} • score {_int(row.get('final_score'))}/100 • {_safe(row.get('created_at'))}")
        return "\n".join(lines)

    def _providers(self, user_id: int) -> str:
        result = self.tools.provider_health()
        self._audit(user_id, result)
        data = result.data or {}
        providers = data.get("providers") or []
        counts = data.get("counts") or {}
        lines = [f"🌐 <b>Daniel AI — Provider Resilience</b> • health geral {_int(data.get('overall_health'))}/100"]
        if counts:
            parts = []
            for key in ("ONLINE", "COOLDOWN", "QUOTA_EXHAUSTED", "DEGRADED", "OFFLINE"):
                value = _int(counts.get(key))
                if value:
                    parts.append(f"{key}={value}")
            if parts:
                lines.append("Estados: " + " • ".join(parts))
        if not providers:
            lines.append("Ainda não há relatório persistido de providers.")
            return "\n".join(lines)

        unhealthy = []
        online = []
        for row in providers[:20]:
            name = row.get("name") or row.get("provider")
            status = str(row.get("status") or "?").upper()
            latency = row.get("average_latency_ms", row.get("latency_ms"))
            retry = _int(row.get("retry_in"))
            extra = f" • {_float(latency):.0f} ms" if latency not in (None, "") else ""
            if retry > 0:
                extra += f" • retry {retry}s"
            if row.get("recently_recovered"):
                extra += " • recuperando"
            lines.append(f"• {_safe(name)}: <b>{_safe(status)}</b> • health {_int(row.get('health_score'))}/100{extra}")
            if status in {"COOLDOWN", "QUOTA_EXHAUSTED", "DEGRADED", "OFFLINE"}:
                unhealthy.append(row)
            elif status in {"ONLINE", "AVAILABLE"}:
                online.append(row)

        if unhealthy:
            fallback_names = []
            for row in online:
                raw = str(row.get("name") or row.get("provider") or "")
                base = raw.split()[0]
                if base and base not in fallback_names:
                    fallback_names.append(base)
            lines.append("\n🔄 <b>Failover</b>: provider limitado é pulado enquanto o circuito estiver aberto.")
            if fallback_names:
                lines.append("Alternativas atualmente saudáveis: " + ", ".join(_safe(x) for x in fallback_names[:4]) + ".")
            for row in unhealthy[:4]:
                reason = str(row.get("circuit_reason") or "")
                retry = _int(row.get("retry_in"))
                if reason or retry:
                    lines.append(f"• {_safe(row.get('name'))}: motivo {_safe(reason or 'degradação')} • nova tentativa em {retry}s")
        else:
            lines.append("\n✅ Nenhum circuito de provider está aberto neste snapshot.")
        lines.append("Leitura somente operacional; Daniel AI não altera chaves nem configuração.")
        return "\n".join(lines)

    def _scanner(self, user_id: int) -> str:
        result = self.tools.scanner_status(limit=5)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Scanner: {_safe(result.summary)}."
        lines = ["📡 <b>Ciclos recentes do scanner</b>"]
        if not result.data:
            lines.append("Nenhum ciclo persistido ainda.")
        for row in result.data:
            lines.append(
                f"• {_safe(row.get('plan_group','?'))}: descobertos {_int(row.get('discovered'))}, aprovados {_int(row.get('approved'))}, "
                f"enviados {_int(row.get('sent'))}, erros {_int(row.get('errors'))}, top {_int(row.get('top_score'))}"
            )
        return "\n".join(lines)

    def _performance(self, user_id: int, days: int = 30) -> str:
        result = self.tools.performance_summary(days=days)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Performance: {_safe(result.summary)}."
        d = result.data
        return (
            f"📊 <b>Performance — {d.get('days')} dias</b>\n"
            f"Sinais: <b>{d.get('signals',0)}</b> • observados: <b>{d.get('observed',0)}</b>\n"
            f"Win rate observado: <b>{_float(d.get('win_rate_pct')):.2f}%</b>\n"
            f"Retorno médio observado: <b>{_float(d.get('average_return_pct')):+.2f}%</b>\n"
            f"TP1: <b>{d.get('tp1_hits',0)}</b> • stop tocado: <b>{d.get('stop_touches',0)}</b>\n\n"
            "ℹ️ Usa somente fatos do ledger; não é promessa de resultado futuro."
        )

    def _users(self, user_id: int) -> str:
        result = self.tools.user_plan_summary()
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Usuários: {_safe(result.summary)}."
        lines = [f"👥 <b>Usuários por plano</b> • total {sum((result.data or {}).values())}"]
        for plan, qty in (result.data or {}).items():
            lines.append(f"• {_safe(plan)}: {qty}")
        return "\n".join(lines)

    def _sync_knowledge(self, user_id: int) -> tuple[int, int, list[str]]:
        if not self.cfg.documents_enabled:
            return 0, 0, ["leitura de documentos desativada"]
        listing = self.tools.documents(limit=100)
        self._audit(user_id, listing)
        if not listing.ok:
            return 0, 0, [listing.summary]
        mem = self._memory_ctx()
        indexed = {str(row.get("name")): row for row in mem.indexed_documents(limit=500)}
        actual = {str(row.get("name")) for row in (listing.data or [])}
        changed = 0
        errors: list[str] = []
        root = self.cfg.documents_dir.resolve()
        max_bytes = max(1, int(self.cfg.documents_max_file_mb)) * 1024 * 1024
        for row in listing.data or []:
            name = str(row.get("name") or "")
            if not name:
                continue
            try:
                doc = load_document(root, root / name, max_bytes=max_bytes)
                previous = indexed.get(name) or {}
                if str(previous.get("sha256") or "") == doc.sha256:
                    continue
                chunks = chunk_text(doc.text)
                mem.replace_knowledge_document(
                    name=doc.name, format=doc.format, size_bytes=doc.size, modified_ns=doc.modified_ns,
                    sha256=doc.sha256, text=doc.text, chunks=chunks,
                )
                changed += 1
            except Exception as exc:
                errors.append(f"{name}: {str(exc)[:120]}")
        removed = 0
        for name in set(indexed) - actual:
            if mem.remove_knowledge_document(name):
                removed += 1
        return changed, removed, errors

    def _knowledge_search(self, user_id: int, query: str) -> str:
        if not self.cfg.documents_enabled:
            return "⚠️ A base de conhecimento local está desativada."
        changed, removed, errors = self._sync_knowledge(user_id)
        tokens = query_tokens(query)
        if not tokens:
            return "📚 Informe o assunto que devo procurar nos documentos locais."
        chunks = self._memory_ctx().knowledge_chunks(limit=20000)
        ranked: list[tuple[float, dict[str, Any]]] = []
        phrase = " ".join(tokens)
        for row in chunks:
            content = str(row.get("content") or "")
            folded = _fold_text(content)
            score = 0.0
            for token in tokens:
                token_fold = _fold_text(token)
                hits = folded.count(token_fold)
                if hits:
                    score += min(hits, 6) * 2.0
            if phrase and _fold_text(phrase) in folded:
                score += 6.0
            if score > 0:
                ranked.append((score, row))
        ranked.sort(key=lambda item: (-item[0], str(item[1].get("name")), _int(item[1].get("chunk_no"))))
        top = ranked[: max(1, min(int(self.cfg.knowledge_max_results), 8))]
        if not top:
            return f"📚 Não encontrei referência a <b>{_safe(query, 180)}</b> nos documentos indexados."
        lines = [f"📚 <b>Base de conhecimento local — {_safe(query, 180)}</b>"]
        for _, row in top:
            snippet = _plain_text(row.get("content"), 360)
            lines.append(f"\n📄 <b>{_safe(row.get('name'), 160)}</b> • trecho {_int(row.get('chunk_no')) + 1}\n{_safe(snippet, 420)}")
        if changed or removed:
            lines.append(f"\n🔄 Índice atualizado: {changed} alterado(s) • {removed} removido(s).")
        if errors:
            lines.append(f"⚠️ {len(errors)} documento(s) não puderam ser indexados.")
        lines.append("\nℹ️ Busca local por conteúdo; OpenAI permanece OFF.")
        return "\n".join(lines)

    def _docs(self, user_id: int, question: str) -> str:
        qn = _fold_text(question)
        quoted = re.search(r'["“](.+?)["”]', question)
        if quoted and any(k in qn for k in ("leia", "ler", "abra", "arquivo", "documento")):
            result = self.tools.read_document(quoted.group(1))
            self._audit(user_id, result)
            if not result.ok:
                return f"📄 {_safe(result.summary)}."
            text = _safe((result.data or {}).get("text", ""), 3500)
            return f"📄 <b>{_safe((result.data or {}).get('name','documento'))}</b>\n\n{text}"
        if any(k in qn for k in ("reindexe", "reindexar", "indexe", "atualize a base", "atualizar a base")):
            changed, removed, errors = self._sync_knowledge(user_id)
            total = len(self._memory_ctx().indexed_documents(limit=500))
            lines = [f"🔄 <b>Base de conhecimento atualizada</b>", f"Documentos indexados: <b>{total}</b> • alterados: {changed} • removidos: {removed}"]
            if errors:
                lines.append(f"⚠️ Falhas de leitura: {len(errors)}")
                lines.extend(f"• {_safe(err, 220)}" for err in errors[:5])
            return "\n".join(lines)
        result = self.tools.documents(limit=30)
        self._audit(user_id, result)
        # Listing also performs an incremental sync, so knowledge is ready without
        # requiring an explicit indexing command from the user.
        self._sync_knowledge(user_id)
        indexed = {str(row.get("name")): row for row in self._memory_ctx().indexed_documents(limit=500)}
        lines = ["📚 <b>Documentos locais / base de conhecimento</b>"]
        if not result.data:
            lines.append(
                "Coloque .txt, .md, .json, .csv, .log, .docx ou .pdf em:\n"
                f"<code>{_safe(self.cfg.documents_dir, 1000)}</code>"
            )
        for row in result.data or []:
            name = str(row.get("name") or "")
            mark = "✅" if name in indexed else "⚠️"
            lines.append(f"{mark} {_safe(name)} • {_safe(row.get('format','?'))} • {row.get('size')} bytes")
        lines.append("\nLer: <code>/daniel leia \"arquivo.pdf\"</code>")
        lines.append("Buscar: <code>/daniel procure nos documentos tokenomics</code>")
        return "\n".join(lines)

    def _queue_learning(self, question: str, source: str = "conversation", priority: int = 20) -> None:
        if not (self.cfg.learning_enabled and self.cfg.memory_enabled):
            return
        text = re.sub(r"\s+", " ", str(question or "")).strip()[:300]
        if len(text) < 4:
            return
        qn = _fold_text(text)
        skip = ("status do sistema", "diagnostico do scanner", "historico da conversa", "minhas memorias", "web status", "ultimos erros", "aprendizado status", "funil do scanner", "motivos de rejeicao", "aprovados", "rejeitados", "padroes dos sinais")
        if any(x in qn for x in skip) or qn.startswith(("aprenda ", "aprender ", "estude ", "estudar ")):
            return
        # Para pesquisas explícitas, guardamos o tema e não a frase de comando.
        explicit_web = bool(re.match(r"(?is)^(?:pesquise|pesquisa|busque|procure)\s+(?:na\s+)?(?:internet|web)", text))
        text = re.sub(r"(?is)^(?:pesquise|pesquisa|busque|procure)\s+(?:na\s+)?(?:internet|web)\s*[:\-]?\s*", "", text).strip() or text
        public_terms = (
            "bitcoin", "btc", "ethereum", "eth", "solana", "bnb", "bsc", "base", "arbitrum", "polygon",
            "avalanche", "optimism", "fantom", "cronos", "sui", "ton", "zksync", "sonic", "token", "moeda",
            "crypto", "cripto", "memecoin", "etf", "mercado", "blockchain", "defi", "dex", "provider", "gecko",
            "birdeye", "dexscreener", "coingecko", "goplus", "liquidez", "volume", "holder", "whale", "contrato",
        )
        # Privacidade: aprendizado automático não envia conversa pessoal genérica
        # para mecanismos públicos. Só temas públicos/cripto ou pesquisa web explícita.
        if not explicit_web and not any(term in _fold_text(text) for term in public_terms):
            return
        try:
            self._memory_ctx().enqueue_learning_topic(text, source=source, priority=priority)
        except Exception:
            pass

    def _learning_status(self) -> str:
        if not self.cfg.memory_enabled:
            return "🧠 Aprendizado indisponível porque a memória persistente está OFF."
        try:
            stats = self._memory_ctx().learning_stats()
        except Exception as exc:
            return f"⚠️ Não consegui consultar o aprendizado: {_safe(type(exc).__name__ + ': ' + str(exc), 220)}"
        lines = [
            f"🧠 <b>Daniel AI V{__version__} — Continuous Learning</b>",
            f"Aprendizado automático: <b>{'ON' if self.cfg.learning_enabled else 'OFF'}</b>",
            f"Internet: <b>{'ON' if self.cfg.web_enabled else 'OFF'}</b>",
            f"Conhecimentos: <b>{_int(stats.get('learned_items'))}</b> • fila: {_int(stats.get('pending_topics'))} • expirados: {_int(stats.get('expired_items'))}",
            f"Intervalo mínimo: {self.cfg.learning_interval_minutes} min • validade padrão: {self.cfg.learning_ttl_hours}h",
        ]
        if stats.get("last_topic"):
            lines.append(f"Último: <b>{_safe(stats.get('last_topic'), 180)}</b> • confiança {_int(stats.get('last_confidence'))}% • {_safe(stats.get('last_learned_at'), 80)}")
        if self.cfg.learning_enabled and not self.cfg.web_enabled:
            lines.append("⚠️ Aprendizado está ON, mas aguarda a web ser ativada para novas pesquisas.")
        lines.append("🔒 Ele aprende e cria conhecimento, mas não altera scanner, score, pagamentos, chaves ou limites do CSM.")
        return "\n".join(lines)

    def _learned_list(self, query: str = "") -> str:
        if not self.cfg.memory_enabled:
            return "🧠 Memória persistente desativada."
        mem = self._memory_ctx()
        rows = mem.search_learned(query, limit=5) if query else mem.learned_items(limit=8)
        if not rows:
            if query:
                self._queue_learning(query, source="question", priority=60)
                return f"🧠 Ainda não tenho conhecimento persistido sobre <b>{_safe(query,180)}</b>. Coloquei o tema na fila automática de pesquisa."
            return "🧠 Ainda não há conhecimento automático persistido."
        lines = [f"📚 <b>Conhecimento aprendido{' — ' + _safe(query,160) if query else ''}</b>"]
        for row in rows:
            summary = _plain_text(row.get("summary"), 420)
            lines.append(
                f"\n• <b>{_safe(row.get('topic'),180)}</b> • confiança {_int(row.get('confidence'))}% • "
                f"fontes {_int(row.get('source_count'))} • aprendido {_safe(row.get('learned_at'),80)}\n{_safe(summary,460)}"
            )
        lines.append("\nℹ️ Conhecimento versionado por data/fontes; itens vencidos são pesquisados novamente pelo ciclo automático.")
        return "\n".join(lines)

    def _learn_now(self, user_id: int, topic: str) -> str:
        topic = re.sub(r"\s+", " ", str(topic or "")).strip()[:300]
        if not topic:
            return "🧠 Informe o tema: <code>/daniel aprenda sobre Bitcoin ETF</code>."
        if not self.cfg.learning_enabled:
            return "🧠 Aprendizado automático está OFF. Ative pelo CLI <code>python main.py daniel-learning-on</code>."
        try:
            from .learning import AutoLearner
            result = AutoLearner(self.cfg, memory=self._memory_ctx(), web_client=self._web_ctx()).research_topic(topic, source="manual")
        except Exception as exc:
            return f"⚠️ Não consegui aprender agora: {_safe(type(exc).__name__ + ': ' + str(exc),240)}"
        if not result.get("ok"):
            if result.get("reason") == "web_off":
                return "🌐 Aprendizado está ON, mas a web está OFF. Ative a web para pesquisar novas fontes."
            return f"🧠 Tema enfileirado, mas a pesquisa não concluiu agora: {_safe(result.get('reason'),120)}."
        return (f"🧠 <b>Aprendizado concluído</b>\nTema: <b>{_safe(topic,180)}</b>\n"
                f"Fontes distintas: {_int(result.get('source_count'))} • confiança {_int(result.get('confidence'))}%\n"
                f"Validade até: {_safe(result.get('expires_at'),100)}\n"
                "O conteúdo ficou salvo no banco e em uma nota local auditável.")

    def _web_status(self) -> str:
        return (
            f"🌐 <b>Daniel AI Web V{__version__}</b>\n"
            f"Internet: <b>{'ON' if self.cfg.web_enabled else 'OFF'}</b>\n"
            f"OpenAI: <b>{'ON' if self.cfg.openai_enabled else 'OFF'}</b>\n"
            f"Timeout: {self.cfg.web_timeout_seconds}s • resultados: {self.cfg.web_max_results}\n"
            "Segurança: somente HTTP/HTTPS públicos; localhost e redes privadas são bloqueados.\n\n"
            "A pesquisa web não exige chave OpenAI. Na V0.7, quando o aprendizado automático está ON, pesquisas de aprendizado também podem ocorrer em segundo plano."
        )

    def _web_search(self, user_id: int, query: str) -> str:
        if not self.cfg.web_enabled:
            return (
                "🌐 <b>Pesquisa web desativada</b>\n"
                "A V0.5 possui pesquisa resiliente com múltiplos fallbacks, mas a web continua opt-in.\n"
                "Ative <code>DANIEL_AI_WEB_ENABLED=true</code> no config.env persistente e reinicie o CSM.\n"
                "OpenAI pode continuar OFF; esta pesquisa não usa a API da OpenAI."
            )
        query = re.sub(r"\s+", " ", str(query or "")).strip()[:500]
        if not query:
            return "🌐 Informe o que devo pesquisar na internet."
        try:
            rows = self._web_ctx().search(query)
        except Exception as exc:
            return f"⚠️ Pesquisa web indisponível: {_safe(type(exc).__name__ + ': ' + str(exc), 260)}"
        self._audit_external(user_id, "web_search", f"query={query[:180]} resultados={len(rows)}")
        diagnostics = getattr(self._web_ctx(), "last_search_diagnostics", []) or []
        if not rows:
            attempted = ", ".join(str(item.get("provider")) for item in diagnostics if item.get("provider"))
            detail = f"\nFontes tentadas: {_safe(attempted, 240)}." if attempted else ""
            return f"🌐 Não encontrei resultados públicos para <b>{_safe(query, 180)}</b>.{detail}\nA leitura direta de URLs públicas continua disponível."
        lines = [f"🌐 <b>Pesquisa web — {_safe(query, 180)}</b>"]
        sources: list[str] = []
        for idx, row in enumerate(rows[: self.cfg.web_max_results], 1):
            domain = urlparse(row.url).hostname or "fonte"
            source = str(getattr(row, "source", "") or domain)
            if source not in sources:
                sources.append(source)
            lines.append(f"\n{idx}. <b>{_safe(row.title, 220)}</b> • {_safe(source, 80)} • {_safe(domain, 80)}")
            if row.snippet:
                lines.append(_safe(_plain_text(row.snippet, 360), 420))
            lines.append(_safe(row.url, 1500))
        if sources:
            lines.append(f"\n🔎 Fontes de descoberta: {_safe(', '.join(sources), 300)}")
        lines.append("ℹ️ Resultados externos; confirme informações sensíveis na fonte original. Nenhum dado do CSM foi alterado.")
        return "\n".join(lines)

    def _web_open(self, user_id: int, url: str) -> str:
        if not self.cfg.web_enabled:
            return "🌐 Pesquisa web desativada. Ative DANIEL_AI_WEB_ENABLED=true para ler páginas públicas."
        try:
            page = self._web_ctx().fetch(url)
        except WebSecurityError as exc:
            return f"🛡️ URL bloqueada: {_safe(str(exc), 240)}"
        except Exception as exc:
            return f"⚠️ Não consegui abrir a página: {_safe(type(exc).__name__ + ': ' + str(exc), 260)}"
        self._audit_external(user_id, "web_fetch", f"url={page.url[:300]} bytes={page.bytes_read}")
        excerpt = _plain_text(page.text, 2200)
        return (
            f"🌐 <b>{_safe(page.title, 240)}</b>\n"
            f"Fonte: {_safe(page.url, 1500)}\n"
            f"Tipo: {_safe(page.content_type or 'desconhecido', 80)} • lidos {page.bytes_read} bytes\n\n"
            f"{_safe(excerpt, 2400)}\n\n"
            "ℹ️ Leitura externa em modo somente leitura; scripts não são executados."
        )

    def _recent_errors(self, user_id: int) -> str:
        result = self.tools.recent_operational_errors(limit=8)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Últimos erros: {_safe(result.summary)}."
        if not result.data:
            return "✅ <b>Últimos erros/incidentes</b>\nNenhum incidente operacional persistido."
        lines = ["🧾 <b>Últimos erros/incidentes — ordem cronológica</b>"]
        for row in result.data:
            when = row.get("last_seen") or row.get("first_seen") or "?"
            lines.append(
                f"• <b>{_safe(when, 40)}</b> • {_safe(row.get('severity') or '?')} • {_safe(row.get('component') or '?')}\n"
                f"  {_safe(row.get('summary'), 220)} • status {_safe(row.get('status') or '?')} • ocorrências {_int(row.get('occurrences'))}"
            )
        lines.append("\nℹ️ Histórico somente leitura; nenhuma configuração foi alterada.")
        return "\n".join(lines)

    def _signal_analysis(self, user_id: int, term: str) -> str:
        result = self.tools.signal_detail(term)
        self._audit(user_id, result)
        if not result.ok or not result.data:
            return f"🔎 Não encontrei um sinal persistido correspondente a <b>{_safe(term)}</b>."
        data = result.data
        row = dict(data.get("signal") or {})
        symbol = row.get("symbol") or row.get("name") or term
        chain = str(row.get("chain") or "?").upper()
        score = _int(row.get("final_score"))
        market_score = row.get("market_score")
        pressure = _buyer_pressure(row)
        lines = [f"🧠 <b>Daniel AI V{__version__} — análise local</b>", f"🔎 <b>{_safe(symbol)}</b> • {_safe(chain)}"]
        score_line = f"Score final: <b>{score}/100</b>"
        if market_score not in (None, ""):
            score_line += f" • mercado {_int(market_score)}/100"
        lines.append(score_line)
        lines.append(f"💧 Liquidez: <b>{_fmt_money(row.get('liquidity'))}</b> • Vol24h: <b>{_fmt_money(row.get('volume24h'))}</b>")
        lines.append(f"🏦 Market cap: <b>{_fmt_money(row.get('marketcap'))}</b> • 24h: <b>{_pct(row.get('change24h'))}</b>")
        if pressure is not None:
            lines.append(f"🟢 Pressão compradora 24h: <b>{pressure:.1f}%</b> ({_int(row.get('buys24h'))} compras / {_int(row.get('sells24h'))} vendas)")

        if row.get("goplus_score") not in (None, "") or row.get("goplus_risk"):
            lines.append(f"🛡️ GoPlus: score <b>{_int(row.get('goplus_score'))}/100</b> • risco <b>{_safe(row.get('goplus_risk') or '?')}</b>")
        top10 = row.get("goplus_top10_holders_pct")
        if top10 not in (None, ""):
            lines.append(f"👥 Top 10 holders (GoPlus): <b>{_float(top10):.1f}%</b>")

        if row.get("observations") not in (None, ""):
            lines.append(
                f"📈 Pós-sinal: {_int(row.get('observations'))} observações • atual <b>{_pct(row.get('last_return_pct'))}</b> • "
                f"máxima <b>{_pct(row.get('max_return_pct'))}</b> • drawdown <b>{_pct(row.get('max_drawdown_pct'))}</b>"
            )
            lifecycle_state = str(row.get("lifecycle_state") or "ACTIVE").upper()
            if lifecycle_state:
                lines.append(f"🧭 Lifecycle: <b>{_safe(lifecycle_state)}</b>" + (f" • deterioração {_int(row.get('deterioration_score'))}/100" if lifecycle_state == "DETERIORATING" else ""))

        onchain = data.get("onchain") or {}
        if onchain:
            on_line = f"⛓️ On-chain: <b>{_int(onchain.get('onchain_score'))}/100</b> • risco <b>{_safe(onchain.get('risk_level') or '?')}</b>"
            if onchain.get("top10_holders_pct") not in (None, ""):
                on_line += f" • top10 {_float(onchain.get('top10_holders_pct')):.1f}%"
            lines.append(on_line)
            if _int(onchain.get("whale_transfer_count")) or _float(onchain.get("whale_volume_usd")):
                lines.append(f"🐋 Whales: {_int(onchain.get('whale_transfer_count'))} transferência(s) • {_fmt_money(onchain.get('whale_volume_usd'))}")

        reasons = row.get("approval_reasons") or []
        if reasons:
            lines.append("\n✅ <b>Razões registradas no sinal</b>")
            for reason in reasons[:5]:
                if isinstance(reason, dict):
                    label = reason.get("reason") or reason.get("label") or reason.get("name") or str(reason)
                else:
                    label = reason
                lines.append(f"• {_safe(label, 220)}")

        observations: list[str] = []
        if score >= 90:
            observations.append("score final muito alto no ledger")
        elif score >= 80:
            observations.append("score final alto no ledger")
        elif score < 60:
            observations.append("score final abaixo de 60")
        if pressure is not None and pressure >= 60:
            observations.append("pressão compradora registrada acima de 60%")
        elif pressure is not None and pressure < 45:
            observations.append("pressão compradora registrada abaixo de 45%")
        risk = _fold_text(str(row.get("goplus_risk") or ""))
        if risk in {"high", "critical", "alto", "critico"}:
            observations.append("risco GoPlus elevado")
        if onchain and _fold_text(str(onchain.get("risk_level") or "")) in {"high", "critical", "alto", "critico"}:
            observations.append("risco on-chain elevado")
        if observations:
            lines.append("\n🧩 <b>Leitura objetiva</b>: " + "; ".join(observations) + ".")
        lines.append("\nℹ️ Interpretação local baseada nos fatos persistidos. Não altera o sinal e não é recomendação financeira.")
        return "\n".join(lines)

    def _score_explanation(self, user_id: int, term: str) -> str:
        result = self.tools.signal_detail(term)
        self._audit(user_id, result)
        if not result.ok or not result.data:
            return f"🔎 Não encontrei um sinal persistido para <b>{_safe(term)}</b>."
        row = dict((result.data or {}).get("signal") or {})
        symbol = row.get("symbol") or row.get("name") or term
        lines = [f"🧮 <b>Explicação do score — {_safe(symbol)}</b>"]
        lines.append(f"Score final registrado: <b>{_int(row.get('final_score'))}/100</b>")
        if row.get("market_score") not in (None, ""):
            lines.append(f"Score de mercado registrado: <b>{_int(row.get('market_score'))}/100</b>")
        if row.get("goplus_score") not in (None, ""):
            lines.append(f"GoPlus registrado: <b>{_int(row.get('goplus_score'))}/100</b> • risco {_safe(row.get('goplus_risk') or '?')}")
        if row.get("deployer_reputation_score") not in (None, ""):
            lines.append(
                f"Reputação do deployer: <b>{_int(row.get('deployer_reputation_score'))}/100</b> "
                f"({_safe(row.get('deployer_reputation_rating') or 'sem rating')})"
            )
        reasons = row.get("approval_reasons") or []
        if reasons:
            lines.append("\n✅ <b>Motivos gravados no momento da aprovação</b>")
            for reason in reasons[:8]:
                label = reason
                if isinstance(reason, dict):
                    label = reason.get("reason") or reason.get("label") or reason.get("name") or str(reason)
                lines.append(f"• {_safe(label, 240)}")
        else:
            lines.append("\nℹ️ Este registro não contém a decomposição ponto a ponto do score.")
        lines.append("\nEu não invento pesos que não estejam gravados. Posso explicar os fatos registrados, mas não atribuir pontos inexistentes no ledger.")
        return "\n".join(lines)

    def _compare(self, user_id: int, left: str, right: str) -> str:
        result = self.tools.compare_signals(left, right)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Não consegui comparar: {_safe(result.summary)}."
        a = dict(((result.data or {}).get("left") or {}).get("signal") or {})
        b = dict(((result.data or {}).get("right") or {}).get("signal") or {})
        an = a.get("symbol") or a.get("name") or left
        bn = b.get("symbol") or b.get("name") or right
        ap = _buyer_pressure(a)
        bp = _buyer_pressure(b)
        lines = [f"⚖️ <b>Comparação local — {_safe(an)} x {_safe(bn)}</b>"]
        lines.append(
            f"<b>{_safe(an)}</b> • {_safe(str(a.get('chain') or '').upper())} • score {_int(a.get('final_score'))}/100 • "
            f"liq {_fmt_money(a.get('liquidity'))} • vol {_fmt_money(a.get('volume24h'))} • 24h {_pct(a.get('change24h'))}"
        )
        lines.append(
            f"<b>{_safe(bn)}</b> • {_safe(str(b.get('chain') or '').upper())} • score {_int(b.get('final_score'))}/100 • "
            f"liq {_fmt_money(b.get('liquidity'))} • vol {_fmt_money(b.get('volume24h'))} • 24h {_pct(b.get('change24h'))}"
        )
        if ap is not None or bp is not None:
            lines.append(f"🟢 Pressão compradora: {_safe(an)} {ap:.1f}%" if ap is not None else f"🟢 Pressão compradora: {_safe(an)} sem dados")
            lines[-1] += f" • {_safe(bn)} {bp:.1f}%" if bp is not None else f" • {_safe(bn)} sem dados"

        factual = []
        if _int(a.get("final_score")) != _int(b.get("final_score")):
            factual.append(f"maior score: {_safe(an if _int(a.get('final_score')) > _int(b.get('final_score')) else bn)}")
        if _float(a.get("liquidity")) != _float(b.get("liquidity")):
            factual.append(f"maior liquidez: {_safe(an if _float(a.get('liquidity')) > _float(b.get('liquidity')) else bn)}")
        if _float(a.get("volume24h")) != _float(b.get("volume24h")):
            factual.append(f"maior volume 24h: {_safe(an if _float(a.get('volume24h')) > _float(b.get('volume24h')) else bn)}")
        if factual:
            lines.append("\n📌 <b>Diferenças factuais</b>: " + "; ".join(factual) + ".")
        lines.append("\nℹ️ Comparação de métricas registradas; não escolhe automaticamente qual ativo comprar.")
        return "\n".join(lines)

    def _incidents(self, user_id: int) -> str:
        result = self.tools.operations_incidents(limit=8, open_only=True)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Incidentes: {_safe(result.summary)}."
        if not result.data:
            return "✅ <b>Incidentes operacionais</b>\nNenhum incidente aberto está persistido no momento."
        lines = [f"🚨 <b>Incidentes operacionais abertos</b> • {len(result.data)}"]
        for row in result.data:
            lines.append(f"• <b>{_safe(row.get('severity'))}</b> • {_safe(row.get('component'))}: {_safe(row.get('summary'), 220)}")
        return "\n".join(lines)

    def _scanner_intelligence(self, user_id: int, hours: int = 24, chain: str = "") -> str:
        funnel = self.tools.scanner_funnel(hours=hours, chain=chain)
        comparison = self.tools.scanner_compare(hours=hours, chain=chain)
        self._audit(user_id, funnel)
        self._audit(user_id, comparison)
        if not funnel.ok:
            return f"⚠️ Scanner Intelligence: {_safe(funnel.summary)}."
        d = funnel.data or {}
        analyzed = _int(d.get("analyzed"))
        approved = _int(d.get("approved"))
        rejected = _int(d.get("rejected"))
        unavailable = _int(d.get("market_unavailable"))
        title_chain = f" • {_safe(chain.upper())}" if chain else ""
        lines = [f"🔎 <b>CSM Scanner Intelligence — {hours}h{title_chain}</b>"]
        if analyzed <= 0 and not (d.get("decision_totals") or {}).get("total"):
            lines.append("Ainda não há decisões V16.2 persistidas neste período. A coleta começa automaticamente nos próximos ciclos do scanner.")
            lines.append("Nenhum filtro foi alterado.")
            return "\n".join(lines)
        lines.append(
            f"Descobertos: <b>{_int(d.get('discovered'))}</b> • analisados: <b>{analyzed}</b> • "
            f"aprovados: <b>{approved}</b> • rejeitados: <b>{rejected}</b> • mercado indisponível: <b>{unavailable}</b>"
        )
        if analyzed:
            lines.append(f"Taxa de aprovação entre analisados: <b>{_float(d.get('approval_rate_pct')):.2f}%</b>")

        reasons = d.get("rejection_reasons") or []
        if reasons:
            lines.append("\n🚫 <b>Principais motivos de rejeição</b>")
            for row in reasons[:7]:
                lines.append(f"• {_safe(row.get('label') or row.get('reason'),180)}: <b>{_int(row.get('count'))}</b> ({_float(row.get('pct')):.1f}%)")

        networks = d.get("networks") or []
        if networks and not chain:
            ranked = sorted(networks, key=lambda r: (_int(r.get("analyzed")), _float(r.get("approval_rate_pct"))), reverse=True)
            lines.append("\n🌐 <b>Funil por rede</b>")
            for row in ranked[:8]:
                top = str(row.get("top_rejection_label") or "")
                suffix = f" • principal bloqueio: {_safe(top,120)}" if top else ""
                lines.append(
                    f"• {_safe(str(row.get('chain') or '?').upper())}: analisados {_int(row.get('analyzed'))} • "
                    f"aprovados {_int(row.get('approved'))} • taxa {_float(row.get('approval_rate_pct')):.1f}%{suffix}"
                )

        c = comparison.data or {}
        a = c.get("approved") or {}
        r = c.get("rejected") or {}
        if _int(a.get("samples")) and _int(r.get("samples")):
            lines.append("\n⚖️ <b>Aprovados × rejeitados</b>")
            lines.append(
                f"Score analítico médio: {_float(a.get('avg_analytic_score')):.1f} × {_float(r.get('avg_analytic_score')):.1f} • "
                f"liquidez média: {_fmt_money(a.get('avg_liquidity'))} × {_fmt_money(r.get('avg_liquidity'))}"
            )
            lines.append(
                f"Volume 24h médio: {_fmt_money(a.get('avg_volume24h'))} × {_fmt_money(r.get('avg_volume24h'))} • "
                f"pressão compradora média: {_float(a.get('avg_buy_pressure_pct')):.1f}% × {_float(r.get('avg_buy_pressure_pct')):.1f}%"
            )

        if reasons:
            top = reasons[0]
            lines.append(
                f"\n🧩 <b>Leitura factual</b>: o maior bloqueio registrado foi "
                f"<b>{_safe(top.get('label') or top.get('reason'),180)}</b> ({_int(top.get('count'))} ocorrências)."
            )
        lines.append("🔒 Evidência somente leitura. Daniel pode estudar e sugerir; não altera filtros ou scoring automaticamente.")
        return "\n".join(lines)

    def _signal_lifecycle(self, user_id: int, hours: int = 24, chain: str = "") -> str:
        result = self.tools.signal_lifecycle(hours=hours, chain=chain)
        events = self.tools.signal_lifecycle_events(hours=hours, chain=chain, limit=12)
        self._audit(user_id, result)
        self._audit(user_id, events)
        if not result.ok:
            return f"⚠️ Signal Lifecycle: {_safe(result.summary)}."
        d = result.data or {}
        title_chain = f" • {_safe(chain.upper())}" if chain else ""
        lines = [f"📈 <b>CSM Signal Lifecycle — {hours}h{title_chain}</b>"]
        if _int(d.get("signals")) <= 0:
            lines.append("Ainda não há sinais V16.3 acompanhados neste período. O histórico será criado automaticamente nos próximos ciclos pós-sinal.")
            return "\n".join(lines)
        states = d.get("states") or {}
        lines.append(f"Sinais acompanhados: <b>{_int(d.get('signals'))}</b>")
        labels = {"ACTIVE":"ativos","TP1":"TP1","TP2":"TP2","TP3":"TP3","DETERIORATING":"deteriorando","STOPPED":"stop","EXPIRED":"expirados"}
        state_bits=[]
        for key in ("ACTIVE","TP1","TP2","TP3","DETERIORATING","STOPPED","EXPIRED"):
            if _int(states.get(key)):
                state_bits.append(f"{labels[key]} <b>{_int(states.get(key))}</b>")
        if state_bits:
            lines.append(" • ".join(state_bits))
        event_counts=d.get("events") or {}
        if event_counts:
            lines.append("Eventos: " + " • ".join(f"{_safe(k)} {_int(v)}" for k,v in sorted(event_counts.items())))
        det=d.get("deteriorating") or []
        if det:
            lines.append("\n⚠️ <b>Sinais deteriorando</b>")
            for row in det[:8]:
                name=row.get("symbol") or row.get("name") or f"#{row.get('id')}"
                reasons=row.get("reasons") or []
                reason=f" • {_safe(reasons[0],160)}" if reasons else ""
                lines.append(f"• <b>{_safe(name)}</b> {_safe(str(row.get('chain') or '').upper())} • retorno {_pct(row.get('last_return_pct'))} • risco {_int(row.get('deterioration_score'))}/100{reason}")
        recent = events.data if events.ok else []
        if recent:
            lines.append("\n🧭 <b>Transições recentes</b>")
            for row in recent[:6]:
                name=row.get("symbol") or row.get("name") or "TOKEN"
                lines.append(f"• {_safe(row.get('event_type'))} • {_safe(name)} {_safe(str(row.get('chain') or '').upper())} • {_pct(row.get('return_pct'))}")
        lines.append("\n🔒 O acompanhamento é observacional. Daniel não altera a aprovação, score ou filtros originais.")
        return "\n".join(lines)

    def _smart_reentry(self, user_id: int, hours: int = 24 * 30, term: str = "", recoveries_only: bool = False) -> str:
        result = self.tools.find_reentries(query=term, hours=hours, limit=30) if term or recoveries_only else self.tools.smart_reentry(hours=hours, limit=20)
        self._audit(user_id, result)
        if not result.ok:
            return f"⚠️ Smart Reentry: {_safe(result.summary)}."
        if term or recoveries_only:
            rows = list(result.data or [])
            if recoveries_only:
                rows = [row for row in rows if str(row.get("prior_lifecycle_state") or "").upper() in {"DETERIORATING", "STOPPED"} and (_float(row.get("last_return_pct")) > 0 or row.get("first_tp1_at"))]
            if not rows:
                label = f" para {_safe(term)}" if term else ""
                return f"🔄 <b>Smart Reentry V16.4</b>\nAinda não há reentrada observada{label} neste período."
            if term:
                row = rows[0]
                evidence = row.get("evidence") or {}
                reasons = evidence.get("improvement_reasons") or []
                lines = [
                    f"🔄 <b>Por que {_safe(row.get('symbol') or row.get('name') or term)} foi reenviado?</b>",
                    f"Plano: <b>{_safe(str(row.get('plan_group') or '').upper())}</b> • cooldown: <b>{_int(row.get('cooldown_hours'))}h</b>",
                    f"Estado anterior: <b>{_safe(str(row.get('prior_lifecycle_state') or 'N/D').upper())}</b>",
                    "✅ O token foi reencontrado e já havia passado novamente pelos filtros atuais do scanner.",
                ]
                if reasons:
                    lines.append("Evidência de melhora: " + "; ".join(_safe(reason, 140) for reason in reasons[:4]))
                lines.append(f"Resultado observado da reentrada: <b>{_pct(row.get('last_return_pct'))}</b> • máxima {_pct(row.get('max_return_pct'))} • lifecycle {_safe(row.get('lifecycle_state') or 'ACTIVE')}")
                lines.append("🔒 Explicação somente leitura; o Daniel não aprovou nem alterou o score.")
                return "\n".join(lines)

            title = "♻️ <b>Recuperações após deterioração/stop</b>" if recoveries_only else "🔄 <b>Reentradas recentes</b>"
            ranked = sorted(rows, key=lambda row: _float(row.get("max_return_pct")), reverse=True)
            lines = [title]
            for row in ranked[:10]:
                name = row.get("symbol") or row.get("name") or "TOKEN"
                evidence = row.get("evidence") or {}
                reasons = evidence.get("improvement_reasons") or []
                why = f" • {_safe(reasons[0],120)}" if reasons else ""
                lines.append(
                    f"• <b>{_safe(name)}</b> {_safe(str(row.get('chain') or '').upper())} • {_safe(str(row.get('plan_group') or '').upper())} "
                    f"• retorno {_pct(row.get('last_return_pct'))} • máxima {_pct(row.get('max_return_pct'))} • anterior {_safe(row.get('prior_lifecycle_state') or 'N/D')}{why}"
                )
            lines.append("🔒 Outcomes observacionais; nenhuma regra de entrada foi alterada automaticamente.")
            return "\n".join(lines)

        d = result.data or {}
        lines = [f"🔄 <b>CSM Smart Reentry — {hours}h</b>"]
        lines.append(f"Entregas registradas: <b>{_int(d.get('deliveries'))}</b> • reentradas confirmadas: <b>{_int(d.get('reentries'))}</b>")
        cooldowns = d.get("cooldowns") or {}
        lines.append(f"Cooldown: Free <b>{_int(cooldowns.get('free') or 24)}h</b> • Plus <b>{_int(cooldowns.get('plus') or 12)}h</b> • Premium <b>{_int(cooldowns.get('premium') or 6)}h</b>")
        if _int(d.get("observed_reentries")):
            lines.append(
                f"Outcomes observados: positivo <b>{_float(d.get('positive_rate_pct')):.1f}%</b> • "
                f"TP1 <b>{_float(d.get('tp1_rate_pct')):.1f}%</b> • stop <b>{_float(d.get('stop_rate_pct')):.1f}%</b>"
            )
        recent = d.get("recent") or []
        if recent:
            lines.append("\n🧭 <b>Últimas reentradas</b>")
            for row in recent[:7]:
                name = row.get("symbol") or row.get("name") or "TOKEN"
                lines.append(f"• {_safe(name)} {_safe(str(row.get('chain') or '').upper())} • {_safe(str(row.get('plan_group') or '').upper())} • anterior {_safe(row.get('prior_lifecycle_state') or 'N/D')} • retorno {_pct(row.get('last_return_pct'))}")
        lines.append("\n✅ Reentrada só ocorre após reencontro + aprovação atual; STOP/DETERIORATING/TP3 exigem melhora material.")
        lines.append("🔒 Daniel explica e aprende outcomes, mas não altera filtros ou scoring.")
        return "\n".join(lines)

    def _operational_copilot(self, user_id: int, hours: int = 24) -> str:
        providers = self.tools.provider_health()
        scanner = self.tools.scanner_funnel(hours=hours)
        lifecycle = self.tools.signal_lifecycle(hours=hours)
        reentry = self.tools.smart_reentry(hours=hours, limit=5)
        for result in (providers, scanner, lifecycle, reentry):
            self._audit(user_id, result)
        status = self.status()
        lines = [f"🧠 <b>Daniel AI V{__version__} — Operational Copilot</b>"]
        if providers.ok:
            pd = providers.data or {}
            lines.append(f"🌐 Providers: <b>{_int(pd.get('overall_health'))}/100</b>")
        if scanner.ok:
            sd = scanner.data or {}
            lines.append(f"🔎 Scanner {hours}h: analisados <b>{_int(sd.get('analyzed'))}</b> • aprovados <b>{_int(sd.get('approved'))}</b> • taxa <b>{_float(sd.get('approval_rate_pct')):.1f}%</b>")
            reasons = sd.get("rejection_reasons") or []
            if reasons:
                lines.append(f"🚫 Principal rejeição: <b>{_safe(reasons[0].get('label') or reasons[0].get('reason'),120)}</b> ({_int(reasons[0].get('count'))})")
        if lifecycle.ok:
            ld = lifecycle.data or {}; states = ld.get("states") or {}
            lines.append(f"📈 Lifecycle: ativos <b>{_int(states.get('ACTIVE'))}</b> • deteriorando <b>{_int(states.get('DETERIORATING'))}</b> • TP3 <b>{_int(states.get('TP3'))}</b> • stops <b>{_int(states.get('STOPPED'))}</b>")
        if reentry.ok:
            rd = reentry.data or {}
            lines.append(f"🔄 Smart Reentry: <b>{_int(rd.get('reentries'))}</b> reentrada(s) • positivo observado <b>{_float(rd.get('positive_rate_pct')):.1f}%</b>")
        lines.append(f"📚 Continuous Learning: <b>{'ON' if status.get('learning_enabled') else 'OFF'}</b> • conhecimentos {_int((status.get('learning') or {}).get('learned_items'))}")
        lines.append(f"🤖 OpenAI: <b>{'ON' if status.get('openai_enabled') else 'OFF'}</b>")
        lines.append("\n🔒 Copilot operacional somente leitura: recomenda e explica; não altera regras críticas sozinho.")
        return "\n".join(lines)

    def _outcome_patterns(self) -> str:
        rows = self._memory_ctx().search_learned("CSM outcome patterns", limit=3)
        rows = [row for row in rows if str(row.get("origin") or "") == "csm_outcomes" or "csm outcome patterns" in str(row.get("topic") or "").casefold()]
        if not rows:
            return (
                "🧠 <b>Padrões pós-sinal</b>\n"
                "Ainda não há amostra observada suficiente persistida pelo ciclo V0.8. "
                "O Daniel aprende isso automaticamente a partir do Performance Ledger quando houver resultados pós-sinal suficientes."
            )
        lines = ["🧠 <b>Padrões aprendidos com resultados reais do CSM</b>"]
        for row in rows[:2]:
            lines.append(
                f"\n<b>{_safe(row.get('topic'),160)}</b> • confiança {_int(row.get('confidence'))}% • "
                f"atualizado {_safe(row.get('learned_at'),80)}\n{_safe(row.get('summary'),1800)}"
            )
        lines.append("\nℹ️ São correlações observacionais; não modificam o scoring automaticamente.")
        return "\n".join(lines)

    def _diagnostics(self, user_id: int, hours: int = 2, chain: str = "") -> str:
        scan = self.tools.scanner_summary(hours=hours)
        funnel = self.tools.scanner_funnel(hours=hours, chain=chain)
        providers = self.tools.provider_health()
        incidents = self.tools.operations_incidents(limit=6, open_only=True)
        for result in (scan, funnel, providers, incidents):
            self._audit(user_id, result)
        lines = [f"🩺 <b>Daniel AI — diagnóstico administrativo ({hours}h)</b>"]

        if scan.ok:
            d = scan.data or {}
            discovered = _int(d.get("discovered"))
            approved = _int(d.get("approved"))
            sent = _int(d.get("sent"))
            errors = _int(d.get("errors"))
            cycles = _int(d.get("cycles"))
            lines.append(f"📡 Scanner: {cycles} registro(s) • descobertos <b>{discovered}</b> • aprovados <b>{approved}</b> • enviados <b>{sent}</b> • erros <b>{errors}</b>")
            if discovered > 0:
                lines.append(f"Taxa agregada de aprovação registrada: <b>{approved/discovered*100:.1f}%</b>")
            ops = d.get("observability") or {}
            if ops:
                lines.append(
                    f"Observabilidade: analisados {_int(ops.get('analyzed'))} • rejeitados {_int(ops.get('rejected'))} • "
                    f"suspensões {_int(ops.get('suspensions'))}"
                )
        else:
            lines.append(f"📡 Scanner: {_safe(scan.summary)}")

        if funnel.ok and _int((funnel.data or {}).get("analyzed")) > 0:
            fd = funnel.data or {}
            lines.append(
                f"🔎 Funil V16.2: analisados <b>{_int(fd.get('analyzed'))}</b> • rejeitados <b>{_int(fd.get('rejected'))}</b> • "
                f"aprovação <b>{_float(fd.get('approval_rate_pct')):.1f}%</b>"
            )
            reasons = fd.get("rejection_reasons") or []
            if reasons:
                top = reasons[0]
                lines.append(f"Principal motivo registrado: <b>{_safe(top.get('label') or top.get('reason'),180)}</b> • {_int(top.get('count'))} ocorrência(s).")

        pdata = providers.data or {}
        lines.append(f"🌐 Providers: health geral <b>{_int(pdata.get('overall_health'))}/100</b>")
        unhealthy = [r for r in (pdata.get("providers") or []) if str(r.get("status") or "").upper() not in {"ONLINE", "OK"} or _int(r.get("health_score"), 100) < 70]
        for row in unhealthy[:4]:
            lines.append(f"• atenção: {_safe(row.get('name') or row.get('provider'))} • {_safe(row.get('status'))} • health {_int(row.get('health_score'))}/100")

        open_incidents = incidents.data if incidents.ok else []
        if open_incidents:
            lines.append(f"🚨 Incidentes abertos: <b>{len(open_incidents)}</b>")
            for row in open_incidents[:4]:
                lines.append(f"• {_safe(row.get('severity'))}: {_safe(row.get('summary'), 200)}")
        else:
            lines.append("✅ Nenhum incidente operacional aberto persistido.")

        if chain:
            network = self.tools.network_summary(chain, hours=max(hours, 1))
            self._audit(user_id, network)
            if network.ok:
                nd = network.data or {}
                lines.append(
                    f"\n🔗 <b>{_safe(chain.upper())}</b>: {_int(nd.get('signals'))} sinal(is) persistido(s) no período • "
                    f"score médio {_float(nd.get('average_score')):.1f} • top {_int(nd.get('top_score'))}"
                )
                recent = nd.get("recent") or []
                if recent:
                    names = ", ".join(_safe(r.get("symbol") or r.get("name") or "?", 40) for r in recent[:5])
                    lines.append(f"Recentes: {names}")
                chain_funnel = nd.get("scanner_funnel") or {}
                reasons = chain_funnel.get("rejection_reasons") or []
                if reasons:
                    top = reasons[0]
                    lines.append(
                        f"Rejeição principal registrada na rede: <b>{_safe(top.get('label') or top.get('reason'),180)}</b> "
                        f"• {_int(top.get('count'))} ({_float(top.get('pct')):.1f}%)."
                    )
                elif not nd.get("chain_rejection_reasons_available"):
                    lines.append("ℹ️ Ainda não há decisões V16.2 suficientes desta rede no período.")

        # Conservative local conclusion: describe only conditions supported by
        # the retrieved metrics rather than inventing root causes.
        issues = []
        if scan.ok and _int((scan.data or {}).get("errors")) > 0:
            issues.append("há erros de scanner registrados")
        if _int(pdata.get("overall_health"), 100) < 80:
            issues.append("saúde agregada dos providers está abaixo de 80/100")
        if open_incidents:
            issues.append("existem incidentes operacionais abertos")
        if issues:
            lines.append("\n🧩 <b>Conclusão local</b>: " + "; ".join(issues) + ".")
        else:
            lines.append("\n🧩 <b>Conclusão local</b>: não encontrei falha crítica persistida nos indicadores consultados.")
        lines.append("Diagnóstico somente leitura; nenhuma configuração foi alterada.")
        return "\n".join(lines)

    def _local_llm_answer(self, user_id: int, question: str) -> str | None:
        """Use the local generative brain only as a safe conversational fallback."""
        try:
            from .local_llm import DanielLocalLLM, LocalLLMError, LocalLLMNotReady
            llm = DanielLocalLLM(self.cfg)
            if not llm.status().ready:
                return None
            history = []
            if self.cfg.memory_enabled:
                try:
                    limit = max(0, int(getattr(self.cfg, "local_llm_history_messages", 6) or 0))
                    if limit:
                        history = self._memory_ctx().history(user_id, limit=limit)
                except Exception:
                    history = []
            generated = llm.generate(question, history=history)
            # The Telegram transport uses HTML parse mode. Local model output is
            # therefore escaped and remains plain, authoritative text.
            return html.escape(generated)
        except (LocalLLMNotReady, LocalLLMError):
            return None
        except Exception:
            return None

    def ask(self, question: str, user_id: int = 0, source: str = "local") -> str:
        if not self.cfg.enabled:
            return "⛔ Daniel AI está desativado (DANIEL_AI_ENABLED=false)."
        question = str(question or "").strip()
        if not question:
            answer = self.help_text()
            self._remember_exchange(user_id, "[ajuda]", answer, source)
            return answer
        if len(question) > self.cfg.max_question_chars:
            question = question[: self.cfg.max_question_chars]
        q = question.casefold()
        qn = _fold_text(question)

        days_match = re.search(r"(\d{1,3})\s*(?:dias?|d)\b", qn)
        days = max(1, min(int(days_match.group(1)), 365)) if days_match else None
        hours_match = re.search(r"(\d{1,4})\s*(?:horas?|h)\b", qn)
        hours = max(1, min(int(hours_match.group(1)), 24 * 30)) if hours_match else ((days or 0) * 24 if days else 2)

        remembered = self._remember_fact(user_id, question)
        forgotten = None if remembered is not None else self._forget_fact(user_id, question)
        compare_terms = _extract_compare_terms(question)
        signal_term = _extract_signal_term(question)
        chain = _extract_network(question)

        if remembered is not None:
            answer = remembered
        elif forgotten is not None:
            answer = forgotten
        elif any(k in qn for k in ("minhas memorias", "o que voce lembra", "o que lembra de mim", "memorias salvas")):
            answer = self._list_memories(user_id)
        elif any(k in qn for k in ("qual e meu", "qual e minha", "voce lembra", "lembra qual", "recorda")):
            answer = self._recall_fact(user_id, question) or "🧠 Não encontrei essa informação nas minhas memórias explícitas."
        elif any(k in qn for k in ("historico da conversa", "historico de conversa", "nossa conversa", "conversas recentes", "historico do daniel")):
            answer = self._conversation_history(user_id)
        elif any(k in qn for k in ("aprendizado status", "aprendizagem status", "status do aprendizado", "status da aprendizagem", "continuous learning")):
            answer = self._learning_status()
        elif any(k in qn for k in ("o que voce aprendeu", "o que aprendeu", "conhecimento aprendido", "ultimos aprendizados")) and "sobre" not in qn:
            answer = self._learned_list()
        elif re.match(r"(?is)^(?:aprenda|aprender|estude|estudar)\s+(?:sobre\s+)?", question.strip()):
            topic = re.sub(r"(?is)^(?:aprenda|aprender|estude|estudar)\s+(?:sobre\s+)?", "", question).strip()
            answer = self._learn_now(user_id, topic)
        elif any(k in qn for k in ("o que voce sabe sobre", "o que sabe sobre", "o que aprendeu sobre", "conhecimento sobre")):
            topic = re.sub(r"(?is)^.*?(?:sabe|aprendeu|conhecimento)\s+sobre\s+", "", question).strip()
            answer = self._learned_list(topic or question)
        elif any(k in qn for k in ("web status", "status da internet", "internet status", "status web")):
            answer = self._web_status()
        elif re.match(r"(?is)^(?:abra|abrir|leia|ler)\s+(?:a\s+)?(?:pagina|página|url|site)?\s*https?://", question.strip()):
            m = re.search(r"https?://\S+", question)
            answer = self._web_open(user_id, m.group(0).rstrip('.,;)') if m else "")
        elif any(k in qn for k in ("pesquise na internet", "pesquisa na internet", "busque na internet", "procure na internet", "pesquise na web", "busque na web", "procure na web", "web pesquisa", "web search")):
            query = re.sub(r"(?is)^(?:pesquise|pesquisa|busque|procure)\s+(?:na\s+)?(?:internet|web)\s*[:\-]?\s*", "", question).strip()
            query = re.sub(r"(?is)^web\s+(?:pesquisa|search)\s*[:\-]?\s*", "", query).strip()
            answer = self._web_search(user_id, query or question)
        elif any(k in qn for k in ("operational copilot", "copilot operacional", "status operacional", "visao operacional", "visão operacional", "painel operacional", "resumo operacional")):
            answer = self._operational_copilot(user_id, hours=max(hours, 1))
        elif any(k in qn for k in ("reentrada", "reentradas", "reenviado", "reenviada", "reenviados", "reentrou", "reentrar")):
            recoveries = any(k in qn for k in ("recuper", "depois de deterior", "apos deterior", "após deterior"))
            answer = self._smart_reentry(user_id, hours=max(hours, 1), term=signal_term if (signal_term and not recoveries) else "", recoveries_only=recoveries)
        elif any(k in qn for k in ("como estao os sinais", "como estão os sinais", "sinais de hoje", "sinais ativos", "sinais deteriorando", "sinais estao deteriorando", "sinais que estao deteriorando", "sinais que estão deteriorando", "signal lifecycle", "lifecycle dos sinais", "tp1", "tp2", "tp3", "stops de hoje")):
            answer = self._signal_lifecycle(user_id, hours=max(hours, 1), chain=chain)
        elif any(k in qn for k in ("padroes dos sinais", "padroes nos sinais", "padroes pos sinal", "padroes pós sinal", "quais padroes", "resultado dos sinais")):
            answer = self._outcome_patterns()
        elif any(k in qn for k in ("funil do scanner", "scanner intelligence", "motivos de rejeicao", "motivo de rejeicao", "aprovados e rejeitados", "aprovados com rejeitados", "rejeitados com aprovados", "compare os rejeitados", "compare rejeitados", "redes estao melhores", "rede esta melhor")):
            answer = self._scanner_intelligence(user_id, hours=max(hours, 1), chain=chain)
        elif compare_terms is not None:
            answer = self._compare(user_id, *compare_terms)
        elif signal_term and "score" in qn and any(k in qn for k in ("por que", "porque", "explique", "explica", "score do", "score da", "score de")):
            answer = self._score_explanation(user_id, signal_term)
        elif any(k in qn for k in ("ultimos erros", "ultimos problemas", "erros recentes", "incidentes recentes")):
            answer = self._recent_errors(user_id)
        elif any(k in qn for k in ("diagnostico", "diagnosticar", "o que esta errado", "tem algum problema")) or (
            any(k in qn for k in ("por que", "porque", "nao encontra", "nao estamos encontrando", "poucas moedas", "poucos sinais"))
            and any(k in qn for k in ("scanner", "rede", "bsc", "bnb", "solana", "ethereum", "base", "provider"))
        ):
            if any(k in qn for k in ("poucos sinais", "poucas moedas", "nao encontra", "nao estamos encontrando")):
                answer = self._scanner_intelligence(user_id, hours=max(hours, 1), chain=chain)
            else:
                answer = self._diagnostics(user_id, hours=hours, chain=chain)
        elif signal_term and any(k in qn for k in ("analise", "analisa", "analisar", "avalie", "avaliar")):
            answer = self._signal_analysis(user_id, signal_term)
        elif any(k in qn for k in ("incidente", "incidentes", "erros operacionais", "falhas operacionais")):
            answer = self._incidents(user_id)
        elif any(k in qn for k in ("melhor", "top", "oportunidade")) and any(k in qn for k in ("sinal", "sinais", "token", "moeda", "moedas", "oportunidade")):
            answer = self._top_signals(user_id, days or 1)
        elif any(k in qn for k in ("provider", "fonte", "gecko", "dexscreener", "birdeye", "coingecko", "failover", "fallback", "cooldown", "resiliencia", "cota")):
            answer = self._providers(user_id)
        elif "scanner" in qn or "ciclo" in qn:
            answer = self._scanner(user_id)
        elif any(k in qn for k in ("performance", "desempenho", "win rate", "resultado")):
            answer = self._performance(user_id, days or 30)
        elif any(k in qn for k in ("usuario", "cliente", "planos")):
            answer = self._users(user_id)
        elif any(k in qn for k in ("procure nos documentos", "busque nos documentos", "pesquise nos documentos", "base de conhecimento", "o que os documentos dizem", "o que esta nos documentos")) and not any(k in qn for k in ("listar", "liste", "quais documentos")):
            query = re.sub(r"(?is)^(?:procure|busque|pesquise)\s+(?:na\s+base\s+de\s+conhecimento|nos\s+documentos|em\s+documentos)\s*[:\-]?\s*", "", question).strip()
            query = re.sub(r"(?is)^o\s+que\s+(?:os\s+)?documentos\s+(?:dizem|falam)\s+sobre\s+", "", query).strip()
            query = re.sub(r"(?is)^base\s+de\s+conhecimento\s*[:\-]?\s*", "", query).strip()
            answer = self._knowledge_search(user_id, query or question)
        elif any(k in qn for k in ("documento", "arquivo", "leia", "docs", "indexe", "reindexe")):
            answer = self._docs(user_id, question)
        elif any(k in qn for k in ("sinal recente", "sinais recentes", "ultimos sinais")):
            answer = self._recent_signals(user_id)
        elif any(k in qn for k in ("status", "como esta", "sistema")):
            s = self.status()
            answer = (
                f"🧠 <b>Daniel AI V{__version__}</b>\n"
                f"Estado: <b>{'ATIVO' if s['enabled'] else 'DESATIVADO'}</b>\n"
                f"Modo: <b>{s['mode'].upper()}</b>\n"
                f"OpenAI: <b>{'ON' if s['openai_enabled'] else 'OFF'}</b>\n"
                f"Memória: <b>{'ON' if s['memory_enabled'] else 'OFF'}</b>\n"
                f"Internet: <b>{'ON' if s['web_enabled'] else 'OFF'}</b>\n"
                f"Aprendizado: <b>{'ON' if s.get('learning_enabled') else 'OFF'}</b> • conhecimentos {s.get('learning',{}).get('learned_items',0)}\n"
                f"Banco CSM: <b>{'OK' if s['csm'].get('csm_database_exists') else 'AUSENTE'}</b>\n"
                f"Provider health: <b>{s['csm'].get('provider_health',0)}/100</b>"
            )
        else:
            answer = self._local_llm_answer(user_id, question)
            if not answer:
                answer = (
                    f"🧠 <b>Daniel AI V{__version__}</b>\n\n"
                    "Entendi o pedido, mas ele não encaixou em uma rota específica do CSM e o Daniel Smart local ainda não está pronto para responder essa pergunta livre.\n\n"
                    "Você pode consultar sinais, scanner, providers, memória, documentos e pesquisa web; ou instalar/ativar o Daniel Smart para conversa generativa local."
                )

        if self.cfg.learning_enabled:
            # Perguntas normais entram na fila de aprendizado com prioridade baixa.
            # Pesquisas explícitas já são aprendidas imediatamente/por comando.
            self._queue_learning(question, source="conversation", priority=15)
        self._remember_exchange(user_id, question, answer, source)
        return answer

    def help_text(self) -> str:
        caps = "\n".join(f"• {item}" for item in CAPABILITIES)
        return (
            f"🧠 <b>Daniel AI V{__version__}</b>\n"
            "Modo: <b>LOCAL / SEM CUSTO DE API</b>\n"
            "Daniel Smart: <b>LLM local via llama.cpp</b> quando instalado\n"
            "OpenAI: <b>OFF</b> por padrão\n\n"
            f"{caps}\n\n"
            "Telegram: <code>/daniel status do sistema</code>\n"
            "Análise: <code>/daniel analise CATE</code>\n"
            "Comparar: <code>/daniel compare CATE e GORE</code>\n"
            "Diagnóstico: <code>/daniel diagnóstico do scanner</code>\n"
            "Funil: <code>/daniel motivos de rejeição nas últimas 24h</code>\n"
            "Comparar funil: <code>/daniel compare os rejeitados com os aprovados</code>\n"
            "Padrões: <code>/daniel quais padrões você encontrou nos sinais?</code>\n"
            "Memória: <code>/daniel lembre que meu teste favorito é CATE</code>\n"
            "Documentos: <code>/daniel documentos</code>\n"
            "Base local: <code>/daniel procure nos documentos liquidez</code>\n"
            "Web: <code>/daniel pesquise na internet bitcoin ETF</code>\n"
            "Web status: <code>/daniel web status</code>\n"
            "Aprendizado: <code>/daniel aprendizado status</code>\n"
            "Aprender agora: <code>/daniel aprenda sobre Bitcoin ETF</code>\n"
            "Conhecimento: <code>/daniel o que você aprendeu</code>\n"
            "CLI: <code>python main.py daniel-ask diagnostico do scanner</code>"
        )
