from __future__ import annotations

import argparse
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Daniel AI Kokoro local worker")
    parser.add_argument("--model", required=True)
    parser.add_argument("--voices", required=True)
    parser.add_argument("--voice", default="pm_alex")
    parser.add_argument("--speed", type=float, default=1.0)
    parser.add_argument("--output", required=True)
    parser.add_argument("--text", required=True)
    args = parser.parse_args()

    import soundfile as sf
    from kokoro_onnx import Kokoro

    model = Path(args.model).expanduser()
    voices = Path(args.voices).expanduser()
    output = Path(args.output).expanduser()
    if not model.is_file() or not voices.is_file():
        raise SystemExit("Kokoro model/voices missing")

    kokoro = Kokoro(str(model), str(voices))
    # Current kokoro-onnx supports language-aware phonemization internally.
    # pt-br selects Brazilian Portuguese while pm_alex is a male PT-BR voice.
    samples, sample_rate = kokoro.create(
        args.text,
        voice=args.voice,
        speed=max(0.5, min(2.0, args.speed)),
        lang="pt-br",
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(output), samples, sample_rate)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
