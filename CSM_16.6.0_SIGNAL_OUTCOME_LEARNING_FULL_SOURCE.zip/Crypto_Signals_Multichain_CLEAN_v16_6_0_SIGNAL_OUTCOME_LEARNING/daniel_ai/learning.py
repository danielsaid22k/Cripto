from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

from .config import DanielSettings, ensure_directories
from .memory import DanielMemory
from .web import WebClient


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat()


def _slug(text: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(text or "").strip()).strip("_")
    return (clean or "topic")[:80]


def ttl_hours_for_topic(topic: str, default_hours: int) -> int:
    q = str(topic or "").casefold()
    if any(k in q for k in ("hoje", "noticia", "notícia", "news", "preço", "price", "etf")):
        return min(default_hours, 12)
    if any(k in q for k in ("geckoterminal", "birdeye", "dexscreener", "coingecko", "api", "provider")):
        return min(default_hours, 24)
    return default_hours


class AutoLearner:
    SEEDS = (
        "Bitcoin ETF",
        "Solana ecosystem",
        "Ethereum ecosystem",
        "BNB Smart Chain",
        "memecoin market",
        "GeckoTerminal API rate limits",
        "Birdeye API",
        "DexScreener",
        "CoinGecko onchain",
    )

    def __init__(self, cfg: DanielSettings | None = None, memory: DanielMemory | None = None, web_client: WebClient | None = None):
        self.cfg = ensure_directories(cfg or DanielSettings.from_env())
        self._memory = memory
        self._web_client = web_client

    def _mem(self) -> DanielMemory:
        if self._memory is None:
            self._memory = DanielMemory(self.cfg.db_file)
        return self._memory

    def _web(self) -> WebClient:
        if self._web_client is None:
            self._web_client = WebClient(
                timeout_seconds=self.cfg.learning_web_timeout_seconds,
                max_bytes=min(self.cfg.web_max_bytes, 350000),
                max_results=self.cfg.learning_max_sources_per_topic,
            )
        return self._web_client

    def ensure_seed_topics(self) -> None:
        mem = self._mem()
        for topic in self.SEEDS:
            mem.enqueue_learning_topic(topic, source="seed", priority=10)

    def research_topic(self, topic: str, source: str = "auto") -> dict:
        topic = re.sub(r"\s+", " ", str(topic or "")).strip()[:300]
        if not topic:
            return {"ok": False, "reason": "empty_topic"}
        if not self.cfg.learning_enabled:
            return {"ok": False, "reason": "learning_disabled", "topic": topic}
        if not self.cfg.web_enabled:
            self._mem().defer_learning_topic(topic, minutes=30, reason="web_off")
            return {"ok": False, "reason": "web_off", "topic": topic}
        rows = self._web().search(topic)
        if not rows:
            self._mem().mark_learning_failure(topic, "no_public_results", retry_minutes=60)
            return {"ok": False, "reason": "no_results", "topic": topic}

        sources = []
        evidence = []
        domains = set()
        for row in rows[: self.cfg.learning_max_sources_per_topic]:
            domain = (urlparse(row.url).hostname or "fonte").lower()
            domains.add(domain)
            sources.append({"title": row.title[:240], "url": row.url[:1600], "source": row.source[:80], "domain": domain})
            snippet = re.sub(r"\s+", " ", str(row.snippet or "")).strip()[:500]
            line = row.title.strip()[:240]
            if snippet:
                line += " — " + snippet
            evidence.append(line)
        source_count = len(domains)
        confidence = min(95, 45 + 15 * min(source_count, 3))
        ttl_hours = ttl_hours_for_topic(topic, self.cfg.learning_ttl_hours)
        learned_at = _utcnow()
        expires_at = learned_at + timedelta(hours=ttl_hours)
        summary = "\n".join(f"• {item}" for item in evidence[:5])[:5000]
        mem = self._mem()
        mem.save_learned_knowledge(
            topic=topic,
            summary=summary,
            confidence=confidence,
            source_count=source_count,
            sources=sources,
            learned_at=_iso(learned_at),
            expires_at=_iso(expires_at),
            origin=source,
        )
        mem.prune_learned(self.cfg.learning_max_items)
        self._write_note(topic, summary, confidence, sources, learned_at, expires_at)
        return {"ok": True, "topic": topic, "confidence": confidence, "source_count": source_count, "expires_at": _iso(expires_at)}

    def _write_note(self, topic: str, summary: str, confidence: int, sources: list[dict], learned_at: datetime, expires_at: datetime) -> None:
        self.cfg.learned_dir.mkdir(parents=True, exist_ok=True)
        path = self.cfg.learned_dir / f"{_slug(topic)}.md"
        lines = [
            f"# {topic}", "", f"Aprendido: {_iso(learned_at)}", f"Expira: {_iso(expires_at)}",
            f"Confiança: {confidence}%", f"Fontes distintas: {len({s.get('domain') for s in sources})}", "", "## Evidências", "", summary, "", "## Fontes", "",
        ]
        for src in sources:
            lines.append(f"- {src.get('title')} — {src.get('url')}")
        lines += ["", "> Conhecimento coletado automaticamente; não altera configurações do CSM.", ""]
        path.write_text("\n".join(lines), encoding="utf-8")

    def learn_csm_outcomes(self, conn, *, days: int = 30, minimum_samples: int = 8) -> dict:
        """Learn bounded, local patterns from observed CSM signal outcomes.

        This is descriptive analytics only. It writes only to Daniel's own
        knowledge database and never changes score/filter configuration.
        """
        if not self.cfg.learning_enabled:
            return {"ok": False, "reason": "learning_disabled"}
        try:
            exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='signal_ledger'").fetchone()
        except Exception as exc:
            return {"ok": False, "reason": f"csm_db_error:{type(exc).__name__}"}
        if not exists:
            return {"ok": False, "reason": "signal_ledger_missing"}
        days = max(1, min(int(days or 30), 365))
        columns = {str(r[1]) for r in conn.execute("PRAGMA table_info(signal_ledger)").fetchall()}
        desired = [
            "chain","final_score","liquidity","volume24h","marketcap","change24h","buys24h","sells24h",
            "observations","last_return_pct","max_return_pct","first_tp1_at","first_stop_at",
            "first_tp2_at","first_tp3_at","lifecycle_state","deterioration_score",
            "last_liquidity_change_pct","last_volume_change_pct","last_buy_pressure_pct",
        ]
        selected = [name for name in desired if name in columns]
        rows = conn.execute(
            f"""SELECT {','.join(selected)} FROM signal_ledger
               WHERE observations>0 AND datetime(created_at)>=datetime('now', ?)
               ORDER BY id DESC LIMIT 1200""",
            (f"-{days} days",),
        ).fetchall()
        data = [dict(r) for r in rows]
        if len(data) < max(3, int(minimum_samples)):
            return {"ok": False, "reason": "insufficient_observed_signals", "samples": len(data)}

        def num(row, key):
            try:
                return float(row.get(key) or 0)
            except (TypeError, ValueError):
                return 0.0

        def median(key):
            values = sorted(num(r, key) for r in data if num(r, key) > 0)
            if not values:
                return 0.0
            mid = len(values) // 2
            return values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2.0

        def metrics(group):
            n = len(group)
            if not n:
                return {"n": 0, "positive_rate": 0.0, "avg_return": 0.0, "tp1_rate": 0.0, "stop_rate": 0.0}
            positives = sum(1 for r in group if num(r, "last_return_pct") > 0)
            tp1 = sum(1 for r in group if r.get("first_tp1_at"))
            stop = sum(1 for r in group if r.get("first_stop_at"))
            tp2 = sum(1 for r in group if r.get("first_tp2_at"))
            tp3 = sum(1 for r in group if r.get("first_tp3_at"))
            deteriorating = sum(1 for r in group if str(r.get("lifecycle_state") or "").upper() == "DETERIORATING")
            return {
                "n": n,
                "positive_rate": positives / n * 100.0,
                "avg_return": sum(num(r, "last_return_pct") for r in group) / n,
                "tp1_rate": tp1 / n * 100.0,
                "tp2_rate": tp2 / n * 100.0,
                "tp3_rate": tp3 / n * 100.0,
                "stop_rate": stop / n * 100.0,
                "deteriorating_rate": deteriorating / n * 100.0,
            }

        overall = metrics(data)
        med_liq = median("liquidity")
        med_vol = median("volume24h")
        groups = []
        candidates = [
            ("score ≥ 80", lambda r: num(r, "final_score") >= 80),
            ("liquidez ≥ mediana", lambda r: med_liq > 0 and num(r, "liquidity") >= med_liq),
            ("volume 24h ≥ mediana", lambda r: med_vol > 0 and num(r, "volume24h") >= med_vol),
            ("pressão compradora ≥ 55%", lambda r: (num(r, "buys24h") + num(r, "sells24h")) > 0 and 100.0 * num(r, "buys24h") / (num(r, "buys24h") + num(r, "sells24h")) >= 55.0),
        ]
        for label, predicate in candidates:
            group = [r for r in data if predicate(r)]
            m = metrics(group)
            if m["n"] >= max(5, minimum_samples // 2):
                m["label"] = label
                m["uplift_positive_pp"] = m["positive_rate"] - overall["positive_rate"]
                groups.append(m)

        chains = {}
        for row in data:
            chain = str(row.get("chain") or "unknown").lower()
            chains.setdefault(chain, []).append(row)
        for chain, group in chains.items():
            m = metrics(group)
            if m["n"] >= max(5, minimum_samples // 2):
                m["label"] = f"rede {chain}"
                m["uplift_positive_pp"] = m["positive_rate"] - overall["positive_rate"]
                groups.append(m)

        groups.sort(key=lambda m: (float(m.get("uplift_positive_pp") or 0), float(m.get("avg_return") or 0), int(m.get("n") or 0)), reverse=True)
        lines = [
            f"• Base observada: {overall['n']} sinais em {days}d • positivos {overall['positive_rate']:.1f}% • retorno médio {overall['avg_return']:+.2f}%.",
            f"• Lifecycle: TP1 {overall.get('tp1_rate',0):.1f}% • TP2 {overall.get('tp2_rate',0):.1f}% • TP3 {overall.get('tp3_rate',0):.1f}% • stop {overall.get('stop_rate',0):.1f}% • deteriorando {overall.get('deteriorating_rate',0):.1f}%.",
        ]
        for item in groups[:6]:
            lines.append(
                f"• {item['label']}: n={item['n']} • positivos {item['positive_rate']:.1f}% "
                f"({item['uplift_positive_pp']:+.1f} pp vs base) • retorno médio {item['avg_return']:+.2f}% "
                f"• TP1 {item['tp1_rate']:.1f}% • TP2 {item.get('tp2_rate',0):.1f}% • TP3 {item.get('tp3_rate',0):.1f}% "
                f"• stop {item['stop_rate']:.1f}% • deteriorando {item.get('deteriorating_rate',0):.1f}%."
            )
        lines.append("• Correlação observacional; não prova causalidade e não altera o scoring automaticamente.")
        summary = "\n".join(lines)[:7000]
        learned_at = _utcnow()
        expires_at = learned_at + timedelta(hours=24)
        confidence = min(92, 50 + min(40, len(data) // 5))
        topic = f"CSM lifecycle outcome patterns — {days}d"
        sources = [{
            "title": "CSM Performance Ledger observado",
            "url": "local://signals.db/signal_ledger",
            "source": "CSM local",
            "domain": "local",
        }]
        mem = self._mem()
        mem.save_learned_knowledge(
            topic=topic, summary=summary, confidence=confidence, source_count=1,
            sources=sources, learned_at=_iso(learned_at), expires_at=_iso(expires_at), origin="csm_outcomes",
        )
        mem.prune_learned(self.cfg.learning_max_items)
        self._write_note(topic, summary, confidence, sources, learned_at, expires_at)
        return {
            "ok": True, "topic": topic, "samples": len(data), "confidence": confidence,
            "overall_positive_rate": round(overall["positive_rate"], 2),
            "patterns": groups[:6], "expires_at": _iso(expires_at),
        }

    def step(self) -> dict:
        if not self.cfg.learning_enabled:
            return {"ok": False, "reason": "disabled"}
        self.ensure_seed_topics()
        mem = self._mem()
        topic = mem.next_learning_topic()
        if not topic:
            return {"ok": True, "reason": "nothing_due"}
        return self.research_topic(str(topic.get("topic") or ""), source=str(topic.get("source") or "auto"))
