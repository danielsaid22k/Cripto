from __future__ import annotations

import html
import os
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from .config import DanielSettings


class LocalLLMError(RuntimeError):
    pass


class LocalLLMNotReady(LocalLLMError):
    pass


@dataclass(frozen=True)
class LocalLLMStatus:
    enabled: bool
    ready: bool
    mode: str
    backend: str
    model_name: str
    model_path: str
    llama_bin: str
    context_size: int
    max_tokens: int
    threads: int
    timeout_seconds: int
    missing: tuple[str, ...]


class DanielLocalLLM:
    """Local generative fallback for Daniel AI.

    V1.3 intentionally keeps deterministic CSM routes above this component.
    The model can explain, summarize and converse, but it is not given direct
    write access to CSM configuration, wallets, payments or safety controls.
    """

    def __init__(self, cfg: DanielSettings | None = None):
        self.cfg = cfg or DanielSettings.from_env()

    @staticmethod
    def _default_root() -> Path:
        return Path.home() / ".local" / "share" / "csm_daniel_llm"

    def _model_path(self) -> Path:
        raw = str(getattr(self.cfg, "local_llm_model_path", "") or "").strip()
        if raw:
            return Path(raw).expanduser()
        return self._default_root() / "models" / "Qwen3-4B-Q4_K_M.gguf"

    def _llama_bin(self) -> str:
        raw = str(getattr(self.cfg, "local_llm_bin", "") or "").strip()
        if raw:
            return raw
        candidate = self._default_root() / "llama.cpp" / "build" / "bin" / "llama-cli"
        if candidate.is_file():
            return str(candidate)
        return shutil.which("llama-cli") or ""

    def status(self) -> LocalLLMStatus:
        model = self._model_path()
        binary = self._llama_bin()
        missing: list[str] = []
        if not binary or not Path(binary).is_file():
            missing.append("llama.cpp/llama-cli")
        if not model.is_file() or model.stat().st_size < 100_000_000:
            missing.append("modelo GGUF")
        enabled = bool(getattr(self.cfg, "local_llm_enabled", True))
        return LocalLLMStatus(
            enabled=enabled,
            ready=bool(enabled and not missing),
            mode=str(getattr(self.cfg, "local_llm_mode", "smart") or "smart"),
            backend="llama.cpp / GGUF local",
            model_name=str(getattr(self.cfg, "local_llm_model_name", "Qwen3-4B Q4_K_M") or "Qwen3-4B Q4_K_M"),
            model_path=str(model),
            llama_bin=binary,
            context_size=int(getattr(self.cfg, "local_llm_context_size", 4096) or 4096),
            max_tokens=int(getattr(self.cfg, "local_llm_max_tokens", 320) or 320),
            threads=int(getattr(self.cfg, "local_llm_threads", 4) or 4),
            timeout_seconds=int(getattr(self.cfg, "local_llm_timeout_seconds", 180) or 180),
            missing=tuple(missing),
        )

    @staticmethod
    def _clean_history(history: Iterable[dict[str, Any]], limit_chars: int = 5000) -> str:
        parts: list[str] = []
        total = 0
        for item in history:
            role = str(item.get("role") or "user").strip().lower()
            label = "Usuário" if role == "user" else "Daniel"
            text = html.unescape(str(item.get("content") or ""))
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            if not text:
                continue
            text = text[:1200]
            line = f"{label}: {text}"
            if total + len(line) > limit_chars:
                break
            parts.append(line)
            total += len(line)
        return "\n".join(parts)

    def _build_prompt(self, question: str, history: Iterable[dict[str, Any]] | None = None) -> str:
        history_text = self._clean_history(history or [])
        system = (
            "Você é Daniel, o assistente local do Crypto Signals Multichain. "
            "Responda sempre em português brasileiro natural, claro e conversacional. "
            "Priorize responder diretamente ao que a pessoa perguntou. Use parágrafos curtos. "
            "Explique o significado dos dados em vez de apenas recitar números. "
            "Não diga que precisa de um modelo pago e não mencione OpenAI, API paga ou limitações de custo, "
            "a menos que o usuário pergunte explicitamente sobre isso. "
            "Não invente dados atuais do CSM, saldos, sinais, preços ou eventos. Se uma informação atual não foi "
            "fornecida no contexto, diga de forma simples que precisa consultar os dados apropriados. "
            "Você pode conversar, explicar, resumir, raciocinar e sugerir. Você não tem autoridade para alterar "
            "configurações críticas, pagamentos, carteiras, filtros de segurança, chaves ou executar operações financeiras. "
            "Quando houver comandos de terminal no contexto, explique a finalidade deles sem fingir que foram executados. "
            "Mantenha a resposta útil e geralmente abaixo de 6 parágrafos. /no_think"
        )
        chunks = [f"INSTRUÇÕES:\n{system}"]
        if history_text:
            chunks.append(f"CONTEXTO RECENTE DA CONVERSA:\n{history_text}")
        chunks.append(f"PERGUNTA ATUAL:\n{question.strip()} /no_think")
        chunks.append("RESPOSTA DO DANIEL:")
        return "\n\n".join(chunks)

    @staticmethod
    def _strip_output(text: str, prompt: str = "") -> str:
        out = str(text or "")
        out = re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", out)
        out = re.sub(r"(?is)<think>.*?</think>", "", out)
        out = re.sub(r"(?is)^.*?RESPOSTA DO DANIEL:\s*", "", out, count=1) if "RESPOSTA DO DANIEL:" in out else out
        if "(truncated)" in out: out = out.rsplit("(truncated)", 1)[-1]
        # llama-cli may print timing lines depending on build flags.
        lines = []
        for line in out.splitlines():
            low = line.strip().casefold()
            if low == "exiting...":
                continue
            if low.startswith(("llama_", "ggml_", "load_tensors", "main:", "sampler ", "common_init")):
                continue
            if "tokens per second" in low or low.startswith("prompt eval time") or low.startswith("eval time"):
                continue
            lines.append(line)
        out = "\n".join(lines).strip()
        if prompt and out.startswith(prompt):
            out = out[len(prompt):].strip()
        out = re.sub(r"\n{3,}", "\n\n", out).strip()
        return out

    def generate(
        self,
        question: str,
        *,
        history: Iterable[dict[str, Any]] | None = None,
        max_tokens: int | None = None,
    ) -> str:
        st = self.status()
        if not st.enabled:
            raise LocalLLMNotReady("Daniel Smart está desativado")
        if not st.ready:
            raise LocalLLMNotReady("Daniel Smart ainda não está instalado: " + ", ".join(st.missing))

        prompt = self._build_prompt(question, history)
        token_limit = max(32, min(int(max_tokens or st.max_tokens), 768))
        threads = max(1, min(st.threads, max(1, os.cpu_count() or 4)))
        cmd = [
            st.llama_bin,
            "-m", st.model_path,
            "-c", str(max(1024, min(st.context_size, 8192))),
            "-n", str(token_limit),
            "-t", str(threads),
            "--temp", str(getattr(self.cfg, "local_llm_temperature", 0.7)),
            "--top-p", str(getattr(self.cfg, "local_llm_top_p", 0.8)),
            "--top-k", str(getattr(self.cfg, "local_llm_top_k", 20)),
            "--min-p", str(getattr(self.cfg, "local_llm_min_p", 0.0)),
            "--no-display-prompt",
            "--single-turn",
            "--simple-io",
            "--log-disable",
            "--no-show-timings",
            "--single-turn",
            "--simple-io",
            "--log-disable",
            "--no-show-timings",
            "-p", prompt,
        ]
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=st.timeout_seconds,
                check=False,
                env={**os.environ, "LC_ALL": os.environ.get("LC_ALL", "C.UTF-8")},
            )
        except subprocess.TimeoutExpired as exc:
            raise LocalLLMError(f"Daniel Smart excedeu {st.timeout_seconds}s") from exc
        except OSError as exc:
            raise LocalLLMError(f"Não consegui iniciar o llama.cpp: {exc}") from exc

        if proc.returncode != 0:
            err = self._strip_output(proc.stderr)[-500:] or f"código {proc.returncode}"
            raise LocalLLMError(f"llama.cpp falhou: {err}")
        answer = self._strip_output(proc.stdout, prompt)
        if not answer:
            raise LocalLLMError("o modelo local não retornou texto")
        return answer[:6000]

    def benchmark(self, prompt: str = "Responda em uma frase: por que a liquidez importa em um token?") -> dict[str, Any]:
        started = time.monotonic()
        answer = self.generate(prompt, history=[], max_tokens=96)
        elapsed = max(0.001, time.monotonic() - started)
        return {
            "elapsed_seconds": round(elapsed, 2),
            "characters": len(answer),
            "answer": answer,
            "mode": self.status().mode,
            "model": self.status().model_name,
        }
