from __future__ import annotations

import sqlite3
import re
from pathlib import Path
from typing import Any


class DanielMemory:
    """Banco isolado do Daniel AI; nunca grava no signals.db."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path), timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.initialize()

    def initialize(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL DEFAULT 0,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT NOT NULL DEFAULT 'local',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_daniel_conversations_user
            ON conversations(user_id, id DESC);

            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL DEFAULT 0,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, key)
            );

            CREATE TABLE IF NOT EXISTS tool_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL DEFAULT 0,
                tool TEXT NOT NULL,
                result_summary TEXT NOT NULL DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS knowledge_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                format TEXT NOT NULL DEFAULT '',
                size_bytes INTEGER NOT NULL DEFAULT 0,
                modified_ns INTEGER NOT NULL DEFAULT 0,
                sha256 TEXT NOT NULL DEFAULT '',
                characters INTEGER NOT NULL DEFAULT 0,
                chunks INTEGER NOT NULL DEFAULT 0,
                indexed_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS knowledge_chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id INTEGER NOT NULL,
                chunk_no INTEGER NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(document_id, chunk_no),
                FOREIGN KEY(document_id) REFERENCES knowledge_documents(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_daniel_knowledge_chunks_doc
            ON knowledge_chunks(document_id, chunk_no);

            CREATE TABLE IF NOT EXISTS learning_topics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL UNIQUE,
                source TEXT NOT NULL DEFAULT 'auto',
                priority INTEGER NOT NULL DEFAULT 10,
                status TEXT NOT NULL DEFAULT 'PENDING',
                attempts INTEGER NOT NULL DEFAULT 0,
                last_error TEXT NOT NULL DEFAULT '',
                next_run_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_run_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_daniel_learning_topics_due
            ON learning_topics(status,next_run_at,priority);

            CREATE TABLE IF NOT EXISTS learned_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL UNIQUE,
                summary TEXT NOT NULL,
                confidence INTEGER NOT NULL DEFAULT 0,
                source_count INTEGER NOT NULL DEFAULT 0,
                sources_json TEXT NOT NULL DEFAULT '[]',
                origin TEXT NOT NULL DEFAULT 'auto',
                status TEXT NOT NULL DEFAULT 'VERIFIED',
                learned_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_daniel_learned_expiry ON learned_knowledge(expires_at);
            """
        )
        self.conn.commit()

    def add_message(self, user_id: int, role: str, content: str, source: str = "local") -> int:
        cur = self.conn.execute(
            "INSERT INTO conversations(user_id,role,content,source) VALUES(?,?,?,?)",
            (int(user_id or 0), str(role), str(content), str(source)),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def history(self, user_id: int = 0, limit: int = 20) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT id,user_id,role,content,source,created_at FROM conversations WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (int(user_id or 0), max(1, min(int(limit), 200))),
        ).fetchall()
        return [dict(r) for r in reversed(rows)]

    def remember(self, key: str, value: str, user_id: int = 0) -> None:
        key = str(key).strip()[:120]
        value = str(value).strip()[:4000]
        if not key:
            raise ValueError("chave de memória vazia")
        self.conn.execute(
            """INSERT INTO memories(user_id,key,value) VALUES(?,?,?)
               ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP""",
            (int(user_id or 0), key, value),
        )
        self.conn.commit()

    def recall(self, key: str, user_id: int = 0) -> str | None:
        row = self.conn.execute(
            "SELECT value FROM memories WHERE user_id=? AND key=?",
            (int(user_id or 0), str(key).strip()),
        ).fetchone()
        return str(row["value"]) if row else None

    def memories(self, user_id: int = 0, limit: int = 50) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT key,value,updated_at FROM memories WHERE user_id=? ORDER BY updated_at DESC LIMIT ?",
            (int(user_id or 0), max(1, min(int(limit), 200))),
        ).fetchall()
        return [dict(r) for r in rows]

    def forget(self, key: str, user_id: int = 0) -> bool:
        cur = self.conn.execute(
            "DELETE FROM memories WHERE user_id=? AND key=?",
            (int(user_id or 0), str(key).strip()),
        )
        self.conn.commit()
        return bool(cur.rowcount)


    def knowledge_document(self, name: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT id,name,format,size_bytes,modified_ns,sha256,characters,chunks,indexed_at FROM knowledge_documents WHERE name=?",
            (str(name),),
        ).fetchone()
        return dict(row) if row else None

    def indexed_documents(self, limit: int = 100) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT id,name,format,size_bytes,modified_ns,sha256,characters,chunks,indexed_at FROM knowledge_documents ORDER BY name LIMIT ?",
            (max(1, min(int(limit), 500)),),
        ).fetchall()
        return [dict(r) for r in rows]

    def replace_knowledge_document(self, *, name: str, format: str, size_bytes: int, modified_ns: int, sha256: str, text: str, chunks: list[str]) -> None:
        self.conn.execute(
            """INSERT INTO knowledge_documents(name,format,size_bytes,modified_ns,sha256,characters,chunks,indexed_at)
               VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
               ON CONFLICT(name) DO UPDATE SET
                 format=excluded.format,size_bytes=excluded.size_bytes,modified_ns=excluded.modified_ns,
                 sha256=excluded.sha256,characters=excluded.characters,chunks=excluded.chunks,indexed_at=CURRENT_TIMESTAMP""",
            (str(name), str(format), int(size_bytes), int(modified_ns), str(sha256), len(str(text)), len(chunks)),
        )
        row = self.conn.execute("SELECT id FROM knowledge_documents WHERE name=?", (str(name),)).fetchone()
        document_id = int(row[0])
        self.conn.execute("DELETE FROM knowledge_chunks WHERE document_id=?", (document_id,))
        self.conn.executemany(
            "INSERT INTO knowledge_chunks(document_id,chunk_no,content) VALUES(?,?,?)",
            [(document_id, idx, str(chunk)) for idx, chunk in enumerate(chunks)],
        )
        self.conn.commit()

    def remove_knowledge_document(self, name: str) -> bool:
        cur = self.conn.execute("DELETE FROM knowledge_documents WHERE name=?", (str(name),))
        self.conn.commit()
        return bool(cur.rowcount)

    def knowledge_chunks(self, limit: int = 10000) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """SELECT d.name,d.format,c.chunk_no,c.content
               FROM knowledge_chunks c JOIN knowledge_documents d ON d.id=c.document_id
               ORDER BY d.name,c.chunk_no LIMIT ?""",
            (max(1, min(int(limit), 20000)),),
        ).fetchall()
        return [dict(r) for r in rows]


    def enqueue_learning_topic(self, topic: str, source: str = "auto", priority: int = 10) -> None:
        topic = " ".join(str(topic or "").split())[:300]
        if not topic:
            return
        self.conn.execute(
            """INSERT INTO learning_topics(topic,source,priority,status,next_run_at) VALUES(?,?,?,'PENDING',CURRENT_TIMESTAMP)
               ON CONFLICT(topic) DO UPDATE SET source=excluded.source,priority=MAX(priority,excluded.priority),
               status=CASE WHEN status='RUNNING' THEN status ELSE 'PENDING' END,updated_at=CURRENT_TIMESTAMP""",
            (topic, str(source)[:40], int(priority)),
        )
        self.conn.commit()

    def next_learning_topic(self) -> dict[str, Any] | None:
        row = self.conn.execute(
            """SELECT id,topic,source,priority,status,attempts,next_run_at FROM learning_topics
               WHERE status IN ('PENDING','RETRY') AND datetime(next_run_at) <= datetime('now')
               ORDER BY priority DESC, datetime(next_run_at) ASC, id ASC LIMIT 1"""
        ).fetchone()
        if not row:
            return None
        self.conn.execute("UPDATE learning_topics SET status='RUNNING',last_run_at=CURRENT_TIMESTAMP,attempts=attempts+1,updated_at=CURRENT_TIMESTAMP WHERE id=?", (int(row['id']),))
        self.conn.commit()
        return dict(row)

    def defer_learning_topic(self, topic: str, minutes: int = 30, reason: str = "deferred") -> None:
        self.conn.execute(
            "UPDATE learning_topics SET status='RETRY',last_error=?,next_run_at=datetime('now', ?),updated_at=CURRENT_TIMESTAMP WHERE topic=?",
            (str(reason)[:300], f"+{max(1,int(minutes))} minutes", str(topic)),
        )
        self.conn.commit()

    def mark_learning_failure(self, topic: str, error: str, retry_minutes: int = 60) -> None:
        self.defer_learning_topic(topic, retry_minutes, error)

    def save_learned_knowledge(self, *, topic: str, summary: str, confidence: int, source_count: int, sources: list[dict[str, Any]], learned_at: str, expires_at: str, origin: str = "auto") -> None:
        import json
        self.conn.execute(
            """INSERT INTO learned_knowledge(topic,summary,confidence,source_count,sources_json,origin,status,learned_at,expires_at)
               VALUES(?,?,?,?,?,?,'VERIFIED',?,?)
               ON CONFLICT(topic) DO UPDATE SET summary=excluded.summary,confidence=excluded.confidence,
               source_count=excluded.source_count,sources_json=excluded.sources_json,origin=excluded.origin,status='VERIFIED',
               learned_at=excluded.learned_at,expires_at=excluded.expires_at,updated_at=CURRENT_TIMESTAMP""",
            (str(topic), str(summary)[:8000], int(confidence), int(source_count), json.dumps(sources, ensure_ascii=False), str(origin)[:40], str(learned_at), str(expires_at)),
        )
        self.conn.execute(
            "UPDATE learning_topics SET status='PENDING',last_error='',next_run_at=?,updated_at=CURRENT_TIMESTAMP WHERE topic=?",
            (str(expires_at), str(topic)),
        )
        self.conn.commit()

    def prune_learned(self, max_items: int = 500) -> int:
        max_items = max(20, int(max_items))
        cur = self.conn.execute(
            """DELETE FROM learned_knowledge WHERE id IN (
                 SELECT id FROM learned_knowledge ORDER BY datetime(learned_at) DESC, id DESC LIMIT -1 OFFSET ?
               )""",
            (max_items,),
        )
        self.conn.commit()
        return int(cur.rowcount or 0)

    def learned_items(self, limit: int = 30) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT topic,summary,confidence,source_count,sources_json,origin,status,learned_at,expires_at,updated_at FROM learned_knowledge ORDER BY datetime(learned_at) DESC LIMIT ?",
            (max(1,min(int(limit),500)),),
        ).fetchall()
        return [dict(r) for r in rows]

    def search_learned(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        tokens = [t for t in re.sub(r'[^a-zA-Z0-9À-ÿ]+',' ',str(query or '').casefold()).split() if len(t) > 2]
        rows = self.learned_items(limit=500)
        ranked=[]
        for row in rows:
            hay=(str(row.get('topic') or '')+' '+str(row.get('summary') or '')).casefold()
            score=sum(2 if t in str(row.get('topic') or '').casefold() else 1 for t in tokens if t in hay)
            if score:
                ranked.append((score,row))
        ranked.sort(key=lambda x:(-x[0], str(x[1].get('learned_at') or '')), reverse=False)
        return [r for _,r in ranked[:max(1,min(int(limit),20))]]

    def learning_stats(self) -> dict[str, Any]:
        total=int(self.conn.execute('SELECT COUNT(*) FROM learned_knowledge').fetchone()[0])
        pending=int(self.conn.execute("SELECT COUNT(*) FROM learning_topics WHERE status IN ('PENDING','RETRY','RUNNING')").fetchone()[0])
        expired=int(self.conn.execute("SELECT COUNT(*) FROM learned_knowledge WHERE datetime(expires_at) <= datetime('now')").fetchone()[0])
        last=self.conn.execute('SELECT topic,learned_at,confidence FROM learned_knowledge ORDER BY datetime(learned_at) DESC LIMIT 1').fetchone()
        return {'learned_items':total,'pending_topics':pending,'expired_items':expired,'last_topic':str(last['topic']) if last else '', 'last_learned_at':str(last['learned_at']) if last else '', 'last_confidence':int(last['confidence']) if last else 0}

    def audit_tool(self, user_id: int, tool: str, result_summary: str = "") -> None:
        self.conn.execute(
            "INSERT INTO tool_audit(user_id,tool,result_summary) VALUES(?,?,?)",
            (int(user_id or 0), str(tool)[:80], str(result_summary)[:500]),
        )
        self.conn.commit()

    def counts(self) -> dict[str, int]:
        def count(table: str) -> int:
            return int(self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        return {"conversations": count("conversations"), "memories": count("memories"), "tool_audit": count("tool_audit"), "knowledge_documents": count("knowledge_documents"), "knowledge_chunks": count("knowledge_chunks"), "learned_knowledge": count("learned_knowledge"), "learning_topics": count("learning_topics")}

    def close(self) -> None:
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
