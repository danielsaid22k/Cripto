from __future__ import annotations

from .config import DanielSettings


class OpenAIDisabled(RuntimeError):
    pass


class OpenAIProvider:
    """Ponto de extensão deliberadamente seguro para a futura API da OpenAI.

    V0.1.0 não contém cliente de rede OpenAI. Mesmo que alguém deixe uma chave no
    ambiente, nenhuma chamada ocorre enquanto OPENAI_ENABLED=false. A implementação
    real será adicionada numa release posterior, com orçamento e limites explícitos.
    """

    def __init__(self, cfg: DanielSettings | None = None):
        self.cfg = cfg or DanielSettings.from_env()

    def generate(self, prompt: str) -> str:
        if not self.cfg.openai_enabled:
            raise OpenAIDisabled("OpenAI está desligada: OPENAI_ENABLED=false")
        if not self.cfg.openai_api_key:
            raise OpenAIDisabled("OPENAI_API_KEY não configurada")
        raise OpenAIDisabled("Cliente OpenAI reservado para uma atualização futura; nenhuma cobrança é realizada nesta V0.1.0")
