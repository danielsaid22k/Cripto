from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class SpeechifyError(RuntimeError):
    """Erro sanitizado do provider Speechify; nunca inclui a chave de API."""


@dataclass(frozen=True)
class SpeechifyStatus:
    enabled: bool
    configured: bool
    ready: bool
    model: str
    language: str
    voice_id: str
    base_url: str


class SpeechifyProvider:
    """Cliente REST mínimo para SpeechifyAI Build.

    Não adiciona SDK/dependência ao CSM. A chave fica apenas no config.env
    persistente. O texto já produzido pelo Daniel é enviado à API somente quando
    este provider está habilitado.
    """

    def __init__(self, cfg: Any):
        self.cfg = cfg
        self.base_url = str(getattr(cfg, "tts_speechify_base_url", "https://api.speechify.ai") or "https://api.speechify.ai").rstrip("/")
        self.api_key = str(getattr(cfg, "tts_speechify_api_key", "") or "").strip()
        self.voice_id = str(getattr(cfg, "tts_speechify_voice_id", "") or "").strip()
        self.model = str(getattr(cfg, "tts_speechify_model", "simba-3.0") or "simba-3.0").strip()
        self.language = str(getattr(cfg, "tts_speechify_language", "pt-BR") or "pt-BR").strip()
        self.timeout = max(10, int(getattr(cfg, "tts_speechify_timeout_seconds", 35) or 35))
        self.enabled = bool(getattr(cfg, "tts_speechify_enabled", False))

    def status(self) -> SpeechifyStatus:
        configured = bool(self.api_key and self.voice_id)
        return SpeechifyStatus(
            enabled=self.enabled,
            configured=configured,
            ready=bool(self.enabled and configured),
            model=self.model,
            language=self.language,
            voice_id=self.voice_id,
            base_url=self.base_url,
        )

    def _headers(self) -> dict[str, str]:
        if not self.api_key:
            raise SpeechifyError("SPEECHIFY_API_KEY não configurada.")
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "CSM-DanielAI/1.3.1",
        }

    def _json_request(self, method: str, path: str, payload: dict | None = None, *, timeout_seconds: int | None = None) -> dict:
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = Request(self.base_url + path, data=data, headers=self._headers(), method=method)
        try:
            with urlopen(req, timeout=max(10, int(timeout_seconds or self.timeout))) as resp:
                raw = resp.read(8 * 1024 * 1024)
        except HTTPError as exc:
            try:
                detail = exc.read(4096).decode("utf-8", errors="replace")
            except Exception:
                detail = ""
            detail = detail.replace(self.api_key, "***") if self.api_key else detail
            raise SpeechifyError(f"Speechify HTTP {exc.code}: {detail[:700] or exc.reason}") from None
        except (URLError, TimeoutError, OSError) as exc:
            raise SpeechifyError(f"Speechify indisponível: {type(exc).__name__}: {exc}") from None
        try:
            value = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise SpeechifyError(f"Resposta inválida da Speechify: {type(exc).__name__}") from None
        if not isinstance(value, dict):
            raise SpeechifyError("Resposta inesperada da Speechify.")
        return value

    def list_voices(self, *, locale: str = "pt-BR", limit: int = 50) -> list[dict]:
        query = urlencode({"locale": locale, "limit": max(1, min(200, int(limit)))})
        payload = self._json_request("GET", f"/v1/voices?{query}")
        rows = payload.get("voices") or []
        return [dict(x) for x in rows if isinstance(x, dict)]

    def synthesize_mp3(self, text: str, output: Path, *, timeout_seconds: int | None = None) -> dict:
        if not self.enabled:
            raise SpeechifyError("Speechify está desativada.")
        if not self.voice_id:
            raise SpeechifyError("SPEECHIFY_VOICE_ID não configurado.")
        payload = self._json_request(
            "POST",
            "/v1/audio/speech",
            {
                "input": str(text),
                "voice_id": self.voice_id,
                "audio_format": "mp3",
                "model": self.model,
                "language": self.language,
            },
            timeout_seconds=timeout_seconds,
        )
        audio_data = payload.get("audio_data")
        if not isinstance(audio_data, str) or not audio_data.strip():
            raise SpeechifyError("Speechify não retornou audio_data.")
        try:
            binary = base64.b64decode(audio_data, validate=False)
        except Exception as exc:
            raise SpeechifyError(f"Áudio Speechify inválido: {type(exc).__name__}") from None
        if len(binary) < 128:
            raise SpeechifyError("Áudio Speechify vazio ou incompleto.")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(binary)
        return {
            "audio_format": payload.get("audio_format") or "mp3",
            "billable_characters_count": int(payload.get("billable_characters_count") or len(str(text))),
        }
