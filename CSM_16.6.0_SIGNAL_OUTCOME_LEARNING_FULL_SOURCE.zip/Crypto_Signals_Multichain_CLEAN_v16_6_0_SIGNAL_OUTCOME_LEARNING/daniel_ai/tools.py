from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from csm.config import settings as csm_settings
from csm.provider_health import load_provider_health

from .config import DanielSettings
from .documents import SUPPORTED_EXTENSIONS, load_document


@dataclass(frozen=True)
class ToolResult:
    name: str
    ok: bool
    data: Any
    summary: str


class DanielTools:
    """Ferramentas read-only do Daniel AI.

    O banco principal é aberto em modo SQLite read-only. Dessa forma, perguntas
    da IA não podem alterar sinais, usuários, pagamentos ou configuração.

    V0.2 adiciona inteligência administrativa sobre os dados já persistidos:
    busca/análise de sinais, comparação, diagnóstico operacional, incidentes e
    resumo por rede. Nenhuma dessas ferramentas escreve em ``signals.db``.
    """

    def __init__(self, cfg: DanielSettings | None = None, csm_db: str | Path | None = None):
        self.cfg = cfg or DanielSettings.from_env()
        self.csm_db = Path(csm_db) if csm_db else Path(csm_settings.db_file)
        self.registry: dict[str, Callable[..., ToolResult]] = {
            "system_status": self.system_status,
            "provider_health": self.provider_health,
            "provider_detail": self.provider_detail,
            "scanner_status": self.scanner_status,
            "scanner_summary": self.scanner_summary,
            "scanner_funnel": self.scanner_funnel,
            "scanner_compare": self.scanner_compare,
            "scanner_decisions": self.scanner_decisions,
            "signal_lifecycle": self.signal_lifecycle,
            "signal_lifecycle_events": self.signal_lifecycle_events,
            "smart_reentry": self.smart_reentry,
            "find_reentries": self.find_reentries,
            "recent_signals": self.recent_signals,
            "top_signals": self.top_signals,
            "find_signals": self.find_signals,
            "signal_detail": self.signal_detail,
            "compare_signals": self.compare_signals,
            "network_summary": self.network_summary,
            "operations_incidents": self.operations_incidents,
            "performance_summary": self.performance_summary,
            "user_plan_summary": self.user_plan_summary,
            "documents": self.documents,
            "read_document": self.read_document,
            "recent_operational_errors": self.recent_operational_errors,
        }

    def names(self) -> list[str]:
        return sorted(self.registry)

    def run(self, name: str, **kwargs: Any) -> ToolResult:
        fn = self.registry.get(name)
        if fn is None:
            return ToolResult(name, False, None, "ferramenta desconhecida")
        try:
            return fn(**kwargs)
        except Exception as exc:
            return ToolResult(name, False, None, f"{type(exc).__name__}: {exc}")

    def _connect_ro(self) -> sqlite3.Connection | None:
        if not self.csm_db.exists():
            return None
        uri = f"file:{self.csm_db.resolve().as_posix()}?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
        row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
        return bool(row)

    @staticmethod
    def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
        if not DanielTools._table_exists(conn, table):
            return set()
        return {str(row["name"]) for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}

    @staticmethod
    def _json(value: Any, default: Any) -> Any:
        if value in (None, ""):
            return default
        if isinstance(value, (list, dict)):
            return value
        try:
            parsed = json.loads(str(value))
            return parsed
        except Exception:
            return default

    @staticmethod
    def _bounded_hours(value: int | float, *, maximum: int = 24 * 30) -> int:
        try:
            hours = int(value)
        except (TypeError, ValueError):
            hours = 1
        return max(1, min(hours, maximum))

    def system_status(self) -> ToolResult:
        health = load_provider_health()
        data = {
            "csm_database": str(self.csm_db),
            "csm_database_exists": self.csm_db.exists(),
            "provider_health": int(health.get("overall_health") or 0),
            "daniel_enabled": self.cfg.enabled,
            "daniel_mode": self.cfg.mode,
            "openai_enabled": self.cfg.openai_enabled,
            "openai_ready": self.cfg.openai_ready,
            "web_enabled": self.cfg.web_enabled,
            "documents_enabled": self.cfg.documents_enabled,
        }
        return ToolResult("system_status", True, data, f"Daniel AI {self.cfg.mode}; banco CSM={'ok' if self.csm_db.exists() else 'ausente'}")

    def provider_health(self) -> ToolResult:
        data = load_provider_health()
        return ToolResult("provider_health", True, data, f"health geral {int(data.get('overall_health') or 0)}/100")

    def provider_detail(self, name: str) -> ToolResult:
        wanted = str(name or "").strip().casefold()
        data = load_provider_health()
        rows = [dict(row) for row in (data.get("providers") or [])]
        if not wanted:
            return ToolResult("provider_detail", False, None, "provider não informado")
        exact = [row for row in rows if str(row.get("name") or row.get("provider") or "").casefold() == wanted]
        partial = [row for row in rows if wanted in str(row.get("name") or row.get("provider") or "").casefold()]
        row = (exact or partial or [None])[0]
        if not row:
            return ToolResult("provider_detail", False, None, f"provider {name} não encontrado no relatório atual")
        return ToolResult("provider_detail", True, row, f"{row.get('name') or row.get('provider')}: {row.get('status','?')}")

    def scanner_status(self, limit: int = 5) -> ToolResult:
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("scanner_status", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "scanner_cycles"):
                return ToolResult("scanner_status", True, [], "sem tabela scanner_cycles")
            rows = conn.execute(
                "SELECT plan_group,discovered,approved,eligible,sent,errors,top_score,created_at FROM scanner_cycles ORDER BY id DESC LIMIT ?",
                (max(1, min(int(limit), 20)),),
            ).fetchall()
            data = [dict(r) for r in rows]
            return ToolResult("scanner_status", True, data, f"{len(data)} ciclo(s) recente(s)")
        finally:
            conn.close()

    def scanner_summary(self, hours: int = 2) -> ToolResult:
        hours = self._bounded_hours(hours)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("scanner_summary", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "scanner_cycles"):
                return ToolResult("scanner_summary", True, {"hours": hours, "cycles": 0}, "sem tabela scanner_cycles")
            row = conn.execute(
                """SELECT COUNT(*) AS cycles,
                          COALESCE(SUM(discovered),0) AS discovered,
                          COALESCE(SUM(approved),0) AS approved,
                          COALESCE(SUM(eligible),0) AS eligible,
                          COALESCE(SUM(sent),0) AS sent,
                          COALESCE(SUM(errors),0) AS errors,
                          COALESCE(MAX(top_score),0) AS top_score,
                          MAX(created_at) AS last_cycle_at
                   FROM scanner_cycles
                   WHERE datetime(created_at) >= datetime('now', ?)""",
                (f"-{hours} hours",),
            ).fetchone()
            plans = conn.execute(
                """SELECT plan_group,COUNT(*) AS cycles,
                          COALESCE(SUM(discovered),0) AS discovered,
                          COALESCE(SUM(approved),0) AS approved,
                          COALESCE(SUM(sent),0) AS sent,
                          COALESCE(SUM(errors),0) AS errors
                   FROM scanner_cycles
                   WHERE datetime(created_at) >= datetime('now', ?)
                   GROUP BY plan_group ORDER BY plan_group""",
                (f"-{hours} hours",),
            ).fetchall()
            data = dict(row) if row else {"cycles": 0}
            data["hours"] = hours
            data["plans"] = [dict(r) for r in plans]

            # Observability has richer scanner totals (analyzed/rejected) on
            # newer databases. Treat it as supplemental, never mandatory.
            ops: dict[str, float] = {}
            if self._table_exists(conn, "ops_metrics"):
                metrics = conn.execute(
                    """SELECT metric_name,COALESCE(SUM(value),0) AS value
                       FROM ops_metrics
                       WHERE component='scanner'
                         AND datetime(occurred_at) >= datetime('now', ?)
                         AND metric_name IN ('discovered','analyzed','approved','rejected','errors','suspensions')
                       GROUP BY metric_name""",
                    (f"-{hours} hours",),
                ).fetchall()
                ops = {str(r["metric_name"]): float(r["value"] or 0) for r in metrics}
            data["observability"] = ops
            return ToolResult("scanner_summary", True, data, f"{int(data.get('cycles') or 0)} registro(s) de ciclo em {hours}h")
        finally:
            conn.close()

    def scanner_funnel(self, hours: int = 24, chain: str = "") -> ToolResult:
        hours = self._bounded_hours(hours)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("scanner_funnel", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "scanner_intelligence_cycles"):
                return ToolResult("scanner_funnel", True, {"hours": hours, "chain": chain, "cycles": 0, "rejection_reasons": [], "networks": []}, "Scanner Intelligence ainda sem dados")
            from csm.scanner_intelligence import scanner_funnel
            data = scanner_funnel(conn, hours=hours, chain=chain)
            return ToolResult(
                "scanner_funnel", True, data,
                f"{int(data.get('analyzed') or 0)} analisado(s), {int(data.get('approved') or 0)} aprovado(s), {int(data.get('rejected') or 0)} rejeitado(s) em {hours}h",
            )
        finally:
            conn.close()

    def scanner_compare(self, hours: int = 24, chain: str = "") -> ToolResult:
        hours = self._bounded_hours(hours)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("scanner_compare", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "scanner_decisions"):
                return ToolResult("scanner_compare", True, {"hours": hours, "approved": {}, "rejected": {}}, "Scanner Intelligence ainda sem decisões")
            from csm.scanner_intelligence import compare_approved_rejected
            data = compare_approved_rejected(conn, hours=hours, chain=chain)
            return ToolResult("scanner_compare", True, data, f"comparação aprovados x rejeitados em {hours}h")
        finally:
            conn.close()

    def scanner_decisions(self, hours: int = 24, chain: str = "", decision: str = "", limit: int = 30) -> ToolResult:
        hours = self._bounded_hours(hours)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("scanner_decisions", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "scanner_decisions"):
                return ToolResult("scanner_decisions", True, [], "Scanner Intelligence ainda sem decisões")
            from csm.scanner_intelligence import recent_decisions
            data = recent_decisions(conn, hours=hours, chain=chain, decision=decision, limit=limit)
            return ToolResult("scanner_decisions", True, data, f"{len(data)} decisão(ões) recente(s)")
        finally:
            conn.close()

    def _signals(self, *, days: int | None = None, limit: int = 5, top: bool = False) -> ToolResult:
        conn = self._connect_ro()
        name = "top_signals" if top else "recent_signals"
        if conn is None:
            return ToolResult(name, False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_ledger"):
                return ToolResult(name, True, [], "ainda não há signal_ledger")
            where = ""
            params: list[Any] = []
            if days is not None:
                where = "WHERE datetime(created_at) >= datetime('now', ?)"
                params.append(f"-{max(1, int(days))} days")
            order = "final_score DESC, id DESC" if top else "id DESC"
            params.append(max(1, min(int(limit), 20)))
            rows = conn.execute(
                f"""SELECT id,chain,address,symbol,name,final_score,liquidity,volume24h,marketcap,change24h,
                           buys24h,sells24h,goplus_score,goplus_risk,last_return_pct,max_return_pct,status,source,created_at
                    FROM signal_ledger {where} ORDER BY {order} LIMIT ?""",
                tuple(params),
            ).fetchall()
            data = [dict(r) for r in rows]
            return ToolResult(name, True, data, f"{len(data)} sinal(is)")
        finally:
            conn.close()

    def signal_lifecycle(self, hours: int = 24, chain: str = "") -> ToolResult:
        hours = self._bounded_hours(hours, maximum=24 * 90)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("signal_lifecycle", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_ledger"):
                return ToolResult("signal_lifecycle", True, {"hours": hours, "signals": 0, "states": {}, "events": {}, "deteriorating": []}, "sem signal_ledger")
            cols = self._columns(conn, "signal_ledger")
            if "lifecycle_state" not in cols:
                return ToolResult("signal_lifecycle", True, {"hours": hours, "signals": 0, "states": {}, "events": {}, "deteriorating": []}, "Signal Lifecycle ainda sem dados")
            params: list[Any] = [f"-{hours} hours"]
            where = "WHERE datetime(created_at)>=datetime('now', ?)"
            if chain:
                where += " AND lower(chain)=?"
                params.append(str(chain).lower())
            rows = conn.execute(f"SELECT lifecycle_state,COUNT(*) qty FROM signal_ledger {where} GROUP BY lifecycle_state ORDER BY qty DESC", params).fetchall()
            states = {str(r["lifecycle_state"] or "ACTIVE").upper(): int(r["qty"] or 0) for r in rows}
            events = {}
            if self._table_exists(conn, "signal_lifecycle_events"):
                ep: list[Any] = [f"-{hours} hours"]
                ew = "WHERE datetime(e.created_at)>=datetime('now', ?)"
                if chain:
                    ew += " AND lower(s.chain)=?"
                    ep.append(str(chain).lower())
                erows = conn.execute(f"SELECT e.event_type,COUNT(*) qty FROM signal_lifecycle_events e JOIN signal_ledger s ON s.id=e.signal_id {ew} GROUP BY e.event_type", ep).fetchall()
                events = {str(r["event_type"]): int(r["qty"] or 0) for r in erows}
            det = conn.execute(f"SELECT id,chain,symbol,name,last_return_pct,deterioration_score,deterioration_reasons_json,next_check_at FROM signal_ledger {where} AND lifecycle_state='DETERIORATING' ORDER BY deterioration_score DESC,updated_at DESC LIMIT 12", params).fetchall()
            deteriorating=[]
            for r in det:
                d=dict(r); d["reasons"] = self._json(d.pop("deterioration_reasons_json", "[]"), []); deteriorating.append(d)
            data = {"hours": hours, "chain": str(chain or "").lower(), "signals": sum(states.values()), "states": states, "events": events, "deteriorating": deteriorating}
            return ToolResult("signal_lifecycle", True, data, f"{data['signals']} sinal(is) no lifecycle")
        finally:
            conn.close()

    def signal_lifecycle_events(self, hours: int = 24, chain: str = "", limit: int = 30) -> ToolResult:
        hours = self._bounded_hours(hours, maximum=24 * 90)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("signal_lifecycle_events", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_lifecycle_events"):
                return ToolResult("signal_lifecycle_events", True, [], "Signal Lifecycle ainda sem eventos")
            params: list[Any] = [f"-{hours} hours"]
            where = "WHERE datetime(e.created_at)>=datetime('now', ?)"
            if chain:
                where += " AND lower(s.chain)=?"
                params.append(str(chain).lower())
            params.append(max(1, min(int(limit), 100)))
            rows = conn.execute(f"""SELECT e.event_type,e.state,e.return_pct,e.price,e.deterioration_score,e.reasons_json,e.created_at,
                           s.chain,s.symbol,s.name,s.address
                    FROM signal_lifecycle_events e JOIN signal_ledger s ON s.id=e.signal_id
                    {where} ORDER BY e.id DESC LIMIT ?""", params).fetchall()
            data=[]
            for r in rows:
                d=dict(r); d["reasons"] = self._json(d.pop("reasons_json", "[]"), []); data.append(d)
            return ToolResult("signal_lifecycle_events", True, data, f"{len(data)} evento(s) de lifecycle")
        finally:
            conn.close()

    def smart_reentry(self, hours: int = 24, plan_group: str = "", limit: int = 20) -> ToolResult:
        hours = self._bounded_hours(hours, maximum=24 * 365)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("smart_reentry", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_reentry_history"):
                return ToolResult("smart_reentry", True, {"hours": hours, "deliveries": 0, "reentries": 0, "recent": []}, "Smart Reentry ainda sem histórico")
            clauses = ["datetime(r.created_at)>=datetime('now', ?)"]
            params: list[Any] = [f"-{hours} hours"]
            if plan_group:
                clauses.append("lower(r.plan_group)=?")
                params.append(str(plan_group).lower())
            where = " AND ".join(clauses)
            total = int(conn.execute(f"SELECT COUNT(*) FROM signal_reentry_history r WHERE {where}", params).fetchone()[0])
            reentries = int(conn.execute(f"SELECT COUNT(*) FROM signal_reentry_history r WHERE {where} AND r.delivery_kind='REENTRY'", params).fetchone()[0])
            plan_rows = conn.execute(
                f"SELECT plan_group,delivery_kind,COUNT(*) qty FROM signal_reentry_history r WHERE {where} GROUP BY plan_group,delivery_kind ORDER BY qty DESC",
                params,
            ).fetchall()
            by_plan: dict[str, dict[str, int]] = {}
            for row in plan_rows:
                group = str(row["plan_group"] or "free")
                by_plan.setdefault(group, {})[str(row["delivery_kind"] or "INITIAL")] = int(row["qty"] or 0)
            rows = conn.execute(
                f"""SELECT r.id,r.user_id,r.chain,r.address,r.symbol,r.name,r.plan_group,r.delivery_kind,r.signal_id,r.parent_signal_id,
                           r.prior_lifecycle_state,r.cooldown_hours,r.score,r.evidence_json,r.created_at,
                           s.last_return_pct,s.max_return_pct,s.lifecycle_state,s.first_tp1_at,s.first_tp2_at,s.first_tp3_at,s.first_stop_at
                    FROM signal_reentry_history r LEFT JOIN signal_ledger s ON s.id=r.signal_id
                    WHERE {where} AND r.delivery_kind='REENTRY' ORDER BY r.id DESC LIMIT ?""",
                [*params, max(1, min(int(limit), 100))],
            ).fetchall()
            recent=[]
            for row in rows:
                d=dict(row); d["evidence"] = self._json(d.pop("evidence_json", "{}"), {}); recent.append(d)
            observed=[row for row in recent if row.get("signal_id") is not None]
            positive=sum(1 for row in observed if float(row.get("last_return_pct") or 0) > 0)
            tp1=sum(1 for row in observed if row.get("first_tp1_at"))
            stops=sum(1 for row in observed if row.get("first_stop_at") or str(row.get("lifecycle_state") or "").upper()=="STOPPED")
            data={
                "hours": hours, "plan_group": str(plan_group or "").lower(), "deliveries": total,
                "initials": total-reentries, "reentries": reentries, "by_plan": by_plan, "recent": recent,
                "observed_reentries": len(observed),
                "positive_rate_pct": round((positive/len(observed))*100,1) if observed else 0.0,
                "tp1_rate_pct": round((tp1/len(observed))*100,1) if observed else 0.0,
                "stop_rate_pct": round((stops/len(observed))*100,1) if observed else 0.0,
                "cooldowns": {"free":24,"plus":12,"premium":6},
            }
            return ToolResult("smart_reentry", True, data, f"{reentries} reentrada(s) confirmada(s)")
        finally:
            conn.close()

    def find_reentries(self, query: str = "", hours: int = 24 * 30, limit: int = 20) -> ToolResult:
        hours = self._bounded_hours(hours, maximum=24 * 3650)
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("find_reentries", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_reentry_history"):
                return ToolResult("find_reentries", True, [], "Smart Reentry ainda sem histórico")
            clauses=["datetime(r.created_at)>=datetime('now', ?)", "r.delivery_kind='REENTRY'"]
            params: list[Any]=[f"-{hours} hours"]
            term=str(query or "").strip()
            if term:
                like=f"%{term}%"
                clauses.append("(r.symbol LIKE ? OR r.name LIKE ? OR r.address LIKE ?)")
                params.extend([like,like,like])
            params.append(max(1,min(int(limit),100)))
            rows=conn.execute(
                f"""SELECT r.id,r.chain,r.address,r.symbol,r.name,r.plan_group,r.signal_id,r.parent_signal_id,r.prior_lifecycle_state,
                           r.cooldown_hours,r.score,r.evidence_json,r.created_at,s.last_return_pct,s.max_return_pct,s.lifecycle_state,
                           s.first_tp1_at,s.first_tp2_at,s.first_tp3_at,s.first_stop_at
                    FROM signal_reentry_history r LEFT JOIN signal_ledger s ON s.id=r.signal_id
                    WHERE {' AND '.join(clauses)} ORDER BY r.id DESC LIMIT ?""", params
            ).fetchall()
            data=[]
            for row in rows:
                d=dict(row); d["evidence"] = self._json(d.pop("evidence_json", "{}"), {}); data.append(d)
            return ToolResult("find_reentries", True, data, f"{len(data)} reentrada(s)")
        finally:
            conn.close()

    def recent_signals(self, limit: int = 5) -> ToolResult:
        return self._signals(limit=limit, top=False)

    def top_signals(self, days: int = 1, limit: int = 5) -> ToolResult:
        return self._signals(days=days, limit=limit, top=True)

    def find_signals(self, query: str, limit: int = 5) -> ToolResult:
        term = str(query or "").strip()
        if not term:
            return ToolResult("find_signals", False, [], "token/sinal não informado")
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("find_signals", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_ledger"):
                return ToolResult("find_signals", True, [], "ainda não há signal_ledger")
            cols = self._columns(conn, "signal_ledger")
            desired = [
                "id", "event_key", "chain", "address", "symbol", "name", "plan_groups", "entry_price",
                "market_score", "final_score", "goplus_score", "goplus_risk", "goplus_buy_tax_pct",
                "goplus_sell_tax_pct", "goplus_top10_holders_pct", "deployer_reputation_score",
                "deployer_reputation_confidence", "deployer_reputation_rating", "liquidity", "volume24h",
                "marketcap", "change24h", "buys24h", "sells24h", "source", "providers_json",
                "approval_reasons_json", "target1_pct", "target2_pct", "stop_pct", "delivered_count",
                "observations", "last_price", "last_return_pct", "max_return_pct", "max_drawdown_pct",
                "first_tp1_at", "first_tp2_at", "first_stop_at", "status", "created_at", "updated_at",
            ]
            selected = [name for name in desired if name in cols]
            if not selected:
                return ToolResult("find_signals", False, [], "schema de signal_ledger incompatível")
            low = term.casefold()
            like = f"%{low}%"
            rows = conn.execute(
                f"""SELECT {','.join(selected)} FROM signal_ledger
                    WHERE lower(COALESCE(symbol,'')) LIKE ?
                       OR lower(COALESCE(name,'')) LIKE ?
                       OR lower(COALESCE(address,'')) LIKE ?
                    ORDER BY CASE
                        WHEN lower(COALESCE(symbol,''))=? THEN 0
                        WHEN lower(COALESCE(address,''))=? THEN 1
                        WHEN lower(COALESCE(name,''))=? THEN 2
                        ELSE 3 END,
                        id DESC LIMIT ?""",
                (like, like, like, low, low, low, max(1, min(int(limit), 20))),
            ).fetchall()
            data = [dict(r) for r in rows]
            return ToolResult("find_signals", True, data, f"{len(data)} correspondência(s) para {term}")
        finally:
            conn.close()

    def signal_detail(self, query: str) -> ToolResult:
        found = self.find_signals(query, limit=1)
        if not found.ok:
            return ToolResult("signal_detail", False, None, found.summary)
        if not found.data:
            return ToolResult("signal_detail", False, None, f"nenhum sinal encontrado para {query}")
        signal = dict(found.data[0])
        signal["providers"] = self._json(signal.get("providers_json"), [])
        signal["approval_reasons"] = self._json(signal.get("approval_reasons_json"), [])

        data: dict[str, Any] = {"signal": signal, "onchain": None, "last_observation": None}
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("signal_detail", True, data, f"sinal {signal.get('symbol') or query}")
        try:
            signal_id = int(signal.get("id") or 0)
            if signal_id and self._table_exists(conn, "onchain_snapshots"):
                cols = self._columns(conn, "onchain_snapshots")
                desired = [
                    "signal_id", "captured_at", "chain", "address", "source", "onchain_score", "risk_level",
                    "top10_holders_pct", "transfer_count", "unique_wallets", "whale_transfer_count",
                    "whale_volume_usd", "mint_events", "burn_events", "liquidity", "liquidity_change_pct",
                    "deployer_address", "deployer_score", "activity_count", "notes_json",
                ]
                selected = [name for name in desired if name in cols]
                if selected:
                    row = conn.execute(
                        f"SELECT {','.join(selected)} FROM onchain_snapshots WHERE signal_id=? ORDER BY id DESC LIMIT 1",
                        (signal_id,),
                    ).fetchone()
                    if row:
                        onchain = dict(row)
                        onchain["notes"] = self._json(onchain.get("notes_json"), [])
                        data["onchain"] = onchain

            if signal_id and self._table_exists(conn, "signal_observations"):
                cols = self._columns(conn, "signal_observations")
                desired = ["captured_at", "age_seconds", "price", "return_pct", "liquidity", "volume24h", "marketcap", "score"]
                selected = [name for name in desired if name in cols]
                if selected:
                    row = conn.execute(
                        f"SELECT {','.join(selected)} FROM signal_observations WHERE signal_id=? ORDER BY id DESC LIMIT 1",
                        (signal_id,),
                    ).fetchone()
                    if row:
                        data["last_observation"] = dict(row)
        finally:
            conn.close()
        return ToolResult("signal_detail", True, data, f"sinal {signal.get('symbol') or signal.get('name') or query}")

    def compare_signals(self, left: str, right: str) -> ToolResult:
        a = self.signal_detail(left)
        b = self.signal_detail(right)
        if not a.ok or not b.ok:
            missing = a.summary if not a.ok else b.summary
            return ToolResult("compare_signals", False, None, missing)
        return ToolResult("compare_signals", True, {"left": a.data, "right": b.data}, f"{left} x {right}")

    def network_summary(self, chain: str, hours: int = 24) -> ToolResult:
        chain = str(chain or "").strip().lower()
        hours = self._bounded_hours(hours)
        if not chain:
            return ToolResult("network_summary", False, {}, "rede não informada")
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("network_summary", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_ledger"):
                return ToolResult("network_summary", True, {"chain": chain, "signals": 0}, "sem signal_ledger")
            row = conn.execute(
                """SELECT COUNT(*) AS signals,
                          COALESCE(AVG(final_score),0) AS average_score,
                          COALESCE(MAX(final_score),0) AS top_score,
                          COALESCE(AVG(liquidity),0) AS average_liquidity,
                          COALESCE(AVG(volume24h),0) AS average_volume24h,
                          COALESCE(SUM(CASE WHEN observations>0 THEN 1 ELSE 0 END),0) AS observed,
                          COALESCE(SUM(CASE WHEN observations>0 AND last_return_pct>0 THEN 1 ELSE 0 END),0) AS positive_observed,
                          MAX(created_at) AS last_signal_at
                   FROM signal_ledger
                   WHERE lower(chain)=? AND datetime(created_at) >= datetime('now', ?)""",
                (chain, f"-{hours} hours"),
            ).fetchone()
            recent = conn.execute(
                """SELECT symbol,name,final_score,created_at FROM signal_ledger
                   WHERE lower(chain)=? AND datetime(created_at) >= datetime('now', ?)
                   ORDER BY id DESC LIMIT 5""",
                (chain, f"-{hours} hours"),
            ).fetchall()
            data = dict(row) if row else {"signals": 0}
            data.update({"chain": chain, "hours": hours, "recent": [dict(r) for r in recent]})
            if self._table_exists(conn, "scanner_intelligence_cycles"):
                from csm.scanner_intelligence import scanner_funnel
                funnel = scanner_funnel(conn, hours=hours, chain=chain)
                data["scanner_funnel"] = funnel
                data["chain_rejection_reasons_available"] = bool(funnel.get("decision_totals", {}).get("total") or funnel.get("rejection_reasons"))
            else:
                data["scanner_funnel"] = {}
                data["chain_rejection_reasons_available"] = False
            return ToolResult("network_summary", True, data, f"{int(data.get('signals') or 0)} sinal(is) persistido(s) em {chain}/{hours}h")
        finally:
            conn.close()

    def operations_incidents(self, limit: int = 10, open_only: bool = True) -> ToolResult:
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("operations_incidents", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "ops_incidents"):
                return ToolResult("operations_incidents", True, [], "observabilidade sem incidentes persistidos")
            where = "WHERE status='OPEN'" if open_only else ""
            rows = conn.execute(
                f"""SELECT id,incident_key,component,severity,status,summary,details_json,first_seen,last_seen,occurrences,resolved_at
                    FROM ops_incidents {where}
                    ORDER BY CASE severity WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END,
                             last_seen DESC LIMIT ?""",
                (max(1, min(int(limit), 30)),),
            ).fetchall()
            data = []
            for raw in rows:
                row = dict(raw)
                row["details"] = self._json(row.get("details_json"), {})
                data.append(row)
            return ToolResult("operations_incidents", True, data, f"{len(data)} incidente(s){' aberto(s)' if open_only else ''}")
        finally:
            conn.close()

    def performance_summary(self, days: int = 30) -> ToolResult:
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("performance_summary", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "signal_ledger"):
                return ToolResult("performance_summary", True, {"signals": 0}, "sem sinais")
            row = conn.execute(
                """SELECT COUNT(*) AS signals,
                          SUM(CASE WHEN observations>0 THEN 1 ELSE 0 END) AS observed,
                          AVG(CASE WHEN observations>0 THEN last_return_pct END) AS avg_return,
                          SUM(CASE WHEN observations>0 AND last_return_pct>0 THEN 1 ELSE 0 END) AS wins,
                          SUM(CASE WHEN first_tp1_at IS NOT NULL THEN 1 ELSE 0 END) AS tp1,
                          SUM(CASE WHEN first_stop_at IS NOT NULL THEN 1 ELSE 0 END) AS stop
                   FROM signal_ledger WHERE datetime(created_at) >= datetime('now', ?)""",
                (f"-{max(1, int(days))} days",),
            ).fetchone()
            observed = int(row["observed"] or 0)
            data = {
                "days": max(1, int(days)),
                "signals": int(row["signals"] or 0),
                "observed": observed,
                "win_rate_pct": round((int(row["wins"] or 0) / observed * 100), 2) if observed else 0.0,
                "average_return_pct": round(float(row["avg_return"] or 0), 2),
                "tp1_hits": int(row["tp1"] or 0),
                "stop_touches": int(row["stop"] or 0),
            }
            return ToolResult("performance_summary", True, data, f"{data['signals']} sinais / {data['observed']} observados")
        finally:
            conn.close()

    def user_plan_summary(self) -> ToolResult:
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("user_plan_summary", False, {}, "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "users"):
                return ToolResult("user_plan_summary", True, {}, "sem usuários")
            rows = conn.execute("SELECT lower(trim(COALESCE(plan,'free'))) AS plan,COUNT(*) AS qty FROM users GROUP BY plan ORDER BY qty DESC").fetchall()
            data = {str(r["plan"] or "free"): int(r["qty"] or 0) for r in rows}
            return ToolResult("user_plan_summary", True, data, f"{sum(data.values())} usuário(s)")
        finally:
            conn.close()

    def recent_operational_errors(self, limit: int = 8) -> ToolResult:
        conn = self._connect_ro()
        if conn is None:
            return ToolResult("recent_operational_errors", False, [], "banco CSM ainda não existe")
        try:
            if not self._table_exists(conn, "ops_incidents"):
                return ToolResult("recent_operational_errors", True, [], "observabilidade sem incidentes persistidos")
            rows = conn.execute(
                """SELECT id,component,severity,status,summary,last_seen,first_seen,occurrences,resolved_at
                   FROM ops_incidents
                   ORDER BY datetime(COALESCE(last_seen,first_seen)) DESC, id DESC LIMIT ?""",
                (max(1, min(int(limit), 30)),),
            ).fetchall()
            data = [dict(r) for r in rows]
            return ToolResult("recent_operational_errors", True, data, f"{len(data)} incidente(s) recente(s)")
        finally:
            conn.close()

    def documents(self, limit: int = 30) -> ToolResult:
        if not self.cfg.documents_enabled:
            return ToolResult("documents", False, [], "leitura de documentos desativada")
        root = self.cfg.documents_dir
        if not root.exists():
            return ToolResult("documents", True, [], "pasta de documentos vazia")
        rows = []
        for path in sorted(root.rglob("*")):
            if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS:
                rows.append({"name": path.relative_to(root).as_posix(), "size": path.stat().st_size, "format": path.suffix.lower().lstrip(".")})
                if len(rows) >= max(1, min(int(limit), 100)):
                    break
        return ToolResult("documents", True, rows, f"{len(rows)} documento(s) local(is)")

    def read_document(self, name: str, max_chars: int = 12000) -> ToolResult:
        if not self.cfg.documents_enabled:
            return ToolResult("read_document", False, None, "leitura de documentos desativada")
        root = self.cfg.documents_dir.resolve()
        target = (root / str(name)).resolve()
        try:
            doc = load_document(root, target, max_bytes=max(1, int(self.cfg.documents_max_file_mb)) * 1024 * 1024)
        except ValueError as exc:
            return ToolResult("read_document", False, None, str(exc))
        except RuntimeError as exc:
            return ToolResult("read_document", False, None, str(exc))
        except Exception as exc:
            return ToolResult("read_document", False, None, f"falha ao ler documento: {type(exc).__name__}")
        text = doc.text[:max(500, min(int(max_chars), 50000))]
        return ToolResult("read_document", True, {"name": doc.name, "format": doc.format, "text": text, "sha256": doc.sha256, "size": doc.size}, f"{len(text)} caracteres lidos")
