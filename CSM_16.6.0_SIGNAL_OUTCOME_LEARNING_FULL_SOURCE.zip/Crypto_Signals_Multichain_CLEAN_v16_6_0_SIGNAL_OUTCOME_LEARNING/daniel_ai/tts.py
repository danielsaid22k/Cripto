from __future__ import annotations

import html
import os
import re
import shutil
import subprocess
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from daniel_ai.speechify_provider import SpeechifyProvider, SpeechifyError


class SpeechError(RuntimeError):
    pass


@dataclass(frozen=True)
class SpeechStatus:
    enabled: bool
    ready: bool
    backend: str
    selected_engine: str
    voice: str
    espeak_bin: str
    ffmpeg_bin: str
    speed: int
    max_chars: int
    missing: tuple[str, ...]
    neural_ready: bool = False
    available_engines: tuple[str, ...] = ()
    supertonic_bin: str = ""
    supertonic_voice: str = ""
    kokoro_python: str = ""
    kokoro_model_path: str = ""
    kokoro_voices_path: str = ""
    kokoro_voice: str = ""
    edge_bin: str = ""
    edge_voice: str = ""
    online_neural_ready: bool = False
    speechify_enabled: bool = False
    speechify_configured: bool = False
    speechify_voice_id: str = ""
    speechify_model: str = ""


class DanielSpeech:
    """Natural TTS for Daniel AI V1.3.1.

    Engine order in ``auto`` mode:
      1. Speechify Neural Voice (online, optional API key)
      2. Microsoft Edge Neural PT-BR (online fallback)
      3. Supertonic 3 (neural, local fallback)
      4. Kokoro 82M PT-BR (neural, local fallback)
      5. eSpeak (emergency fallback)

    Input transcription remains local with whisper.cpp. Only the already-built
    answer text is sent to an online TTS service. Telegram text is delivered
    independently; TTS failures are non-fatal and automatically fall through.
    """

    ENGINE_ORDER = ("speechify", "edge", "supertonic", "kokoro", "espeak")

    def __init__(self, cfg: Any):
        self.cfg = cfg
        voice_dir = Path(getattr(cfg, "voice_dir", None) or (cfg.state_dir / "voice"))
        self.tmp_dir = voice_dir / "tmp"
        self.tmp_dir.mkdir(parents=True, exist_ok=True)
        self.neural_dir = Path.home() / ".local" / "share" / "csm_daniel_tts"

    @staticmethod
    def _resolve_executable(value: str) -> str:
        raw = str(value or "").strip()
        if not raw:
            return ""
        p = Path(raw).expanduser()
        if p.is_absolute() or "/" in raw:
            return str(p) if p.exists() and os.access(p, os.X_OK) else ""
        return shutil.which(raw) or ""

    def _resolve_espeak(self) -> str:
        configured = self._resolve_executable(getattr(self.cfg, "tts_espeak_bin", "espeak"))
        if configured:
            return configured
        # Termux package is named ``espeak``; installations can expose either
        # executable name depending on build/repository generation.
        return shutil.which("espeak") or shutil.which("espeak-ng") or ""

    def _kokoro_paths(self) -> tuple[Path, Path]:
        model_raw = str(getattr(self.cfg, "tts_kokoro_model_path", "") or "").strip()
        voices_raw = str(getattr(self.cfg, "tts_kokoro_voices_path", "") or "").strip()
        root = self.neural_dir / "kokoro"
        model = Path(model_raw).expanduser() if model_raw else root / "kokoro-v1.0.int8.onnx"
        voices = Path(voices_raw).expanduser() if voices_raw else root / "voices-v1.0.bin"
        return model, voices

    def _engine_availability(self) -> dict[str, bool | str]:
        speechify = SpeechifyProvider(self.cfg)
        speechify_status = speechify.status()
        edge = self._resolve_executable(getattr(self.cfg, "tts_edge_bin", "edge-tts"))
        supertonic = self._resolve_executable(getattr(self.cfg, "tts_supertonic_bin", "supertonic"))
        python_bin = self._resolve_executable(getattr(self.cfg, "tts_kokoro_python", "python"))
        model, voices = self._kokoro_paths()
        espeak = self._resolve_espeak()
        ffmpeg = self._resolve_executable(getattr(self.cfg, "tts_ffmpeg_bin", "ffmpeg"))
        return {
            "speechify": bool(speechify_status.ready),
            "speechify_enabled": bool(speechify_status.enabled),
            "speechify_voice_id": str(speechify_status.voice_id or ""),
            "speechify_model": str(speechify_status.model or ""),
            "edge": bool(edge),
            "edge_bin": edge,
            "supertonic": bool(supertonic),
            "supertonic_bin": supertonic,
            "kokoro": bool(python_bin and model.is_file() and model.stat().st_size > 1024 * 1024 and voices.is_file() and voices.stat().st_size > 1024),
            "kokoro_python": python_bin,
            "kokoro_model": str(model),
            "kokoro_voices": str(voices),
            "espeak": bool(espeak),
            "espeak_bin": espeak,
            "ffmpeg": bool(ffmpeg),
            "ffmpeg_bin": ffmpeg,
        }

    def _preferred_order(self) -> tuple[str, ...]:
        configured = str(getattr(self.cfg, "tts_engine", "auto") or "auto").strip().lower()
        if configured not in {"auto", *self.ENGINE_ORDER}:
            configured = "auto"
        if configured == "auto":
            return self.ENGINE_ORDER
        return (configured,) + tuple(x for x in self.ENGINE_ORDER if x != configured)

    def status(self) -> SpeechStatus:
        a = self._engine_availability()
        available = tuple(e for e in self.ENGINE_ORDER if bool(a[e]))
        selected = next((e for e in self._preferred_order() if e in available), "")
        ffmpeg = str(a["ffmpeg_bin"])
        missing: list[str] = []
        if not ffmpeg:
            missing.append("ffmpeg")
        if not selected:
            missing.append("Speechify/Edge Neural/Supertonic/Kokoro/eSpeak")
        enabled = bool(getattr(self.cfg, "tts_enabled", True))
        ready = enabled and bool(ffmpeg) and bool(selected)
        labels = {
            "speechify": "Speechify Neural Voice PT-BR online + ffmpeg/opus",
            "edge": "Microsoft Edge Neural PT-BR online + ffmpeg/opus",
            "supertonic": "Supertonic 3 neural local + ffmpeg/opus",
            "kokoro": "Kokoro 82M PT-BR neural local + ffmpeg/opus",
            "espeak": "eSpeak emergency + ffmpeg/opus",
            "": "nenhum motor disponível",
        }
        model, voices = self._kokoro_paths()
        if selected == "speechify":
            voice = str(getattr(self.cfg, "tts_speechify_voice_id", "") or "Speechify")
        elif selected == "edge":
            voice = str(getattr(self.cfg, "tts_edge_voice", "pt-BR-AntonioNeural") or "pt-BR-AntonioNeural")
        elif selected == "supertonic":
            voice = str(getattr(self.cfg, "tts_supertonic_voice", "M1") or "M1")
        elif selected == "kokoro":
            voice = str(getattr(self.cfg, "tts_kokoro_voice", "pm_alex") or "pm_alex")
        else:
            voice = str(getattr(self.cfg, "tts_voice", "pt-br") or "pt-br")
        return SpeechStatus(
            enabled=enabled,
            ready=ready,
            backend=labels[selected],
            selected_engine=selected or "none",
            voice=voice,
            espeak_bin=str(a["espeak_bin"]),
            ffmpeg_bin=ffmpeg,
            speed=int(getattr(self.cfg, "tts_speed", 155) or 155),
            max_chars=int(getattr(self.cfg, "tts_max_chars", 1400) or 1400),
            missing=tuple(missing),
            neural_ready="speechify" in available or "edge" in available or "supertonic" in available or "kokoro" in available,
            available_engines=available,
            supertonic_bin=str(a["supertonic_bin"]),
            supertonic_voice=str(getattr(self.cfg, "tts_supertonic_voice", "M1") or "M1"),
            kokoro_python=str(a["kokoro_python"]),
            kokoro_model_path=str(model),
            kokoro_voices_path=str(voices),
            kokoro_voice=str(getattr(self.cfg, "tts_kokoro_voice", "pm_alex") or "pm_alex"),
            edge_bin=str(a["edge_bin"]),
            edge_voice=str(getattr(self.cfg, "tts_edge_voice", "pt-BR-AntonioNeural") or "pt-BR-AntonioNeural"),
            online_neural_ready="speechify" in available or "edge" in available,
            speechify_enabled=bool(a["speechify_enabled"]),
            speechify_configured=bool(a["speechify"]),
            speechify_voice_id=str(a["speechify_voice_id"]),
            speechify_model=str(a["speechify_model"]),
        )

    @staticmethod
    def _plain_text(text: str) -> str:
        raw = html.unescape(str(text or ""))
        raw = re.sub(r"<[^>]+>", " ", raw)
        raw = re.sub(r"https?://\S+", " link ", raw)
        raw = re.sub(r"[`*_#|]", " ", raw)
        raw = re.sub(r"\s+", " ", raw).strip()
        return raw

    def _run_speechify(self, plain: str, mp3: Path, timeout: int) -> None:
        provider = SpeechifyProvider(self.cfg)
        try:
            provider.synthesize_mp3(plain, mp3, timeout_seconds=timeout)
        except SpeechifyError as exc:
            raise SpeechError(str(exc)) from exc

    def _run_edge(self, plain: str, mp3: Path, timeout: int) -> None:
        edge_bin = self._resolve_executable(getattr(self.cfg, "tts_edge_bin", "edge-tts"))
        if not edge_bin:
            raise SpeechError("Microsoft Edge Neural não está instalado.")
        voice = str(getattr(self.cfg, "tts_edge_voice", "pt-BR-AntonioNeural") or "pt-BR-AntonioNeural")
        rate = str(getattr(self.cfg, "tts_edge_rate", "-4%") or "-4%")
        pitch = str(getattr(self.cfg, "tts_edge_pitch", "+0Hz") or "+0Hz")
        volume = str(getattr(self.cfg, "tts_edge_volume", "+0%") or "+0%")
        edge_timeout = max(10, int(getattr(self.cfg, "tts_edge_timeout_seconds", 35) or 35))
        cmd = [
            edge_bin, "--voice", voice, f"--rate={rate}", f"--pitch={pitch}",
            f"--volume={volume}", "--text", plain, "--write-media", str(mp3),
        ]
        proc = subprocess.run(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            timeout=min(timeout, edge_timeout), check=False,
        )
        if proc.returncode != 0 or not mp3.is_file() or mp3.stat().st_size < 128:
            detail = (proc.stderr or proc.stdout or "falha no Microsoft Edge Neural")[-600:]
            raise SpeechError(f"Microsoft Edge Neural falhou: {detail}")

    def _run_supertonic(self, plain: str, wav: Path, timeout: int) -> None:
        bin_path = self._resolve_executable(getattr(self.cfg, "tts_supertonic_bin", "supertonic"))
        if not bin_path:
            raise SpeechError("Supertonic não encontrado.")
        voice = str(getattr(self.cfg, "tts_supertonic_voice", "M1") or "M1")
        lang = str(getattr(self.cfg, "tts_supertonic_lang", "pt") or "pt")
        steps = max(5, min(12, int(getattr(self.cfg, "tts_supertonic_steps", 8) or 8)))
        speed = float(getattr(self.cfg, "tts_supertonic_speed", 1.0) or 1.0)
        cmd = [bin_path, "tts", plain, "-o", str(wav), "--voice", voice, "--steps", str(steps), "--lang", lang, "--speed", str(speed)]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, check=False)
        if proc.returncode != 0 or not wav.is_file() or wav.stat().st_size < 44:
            detail = (proc.stderr or proc.stdout or "falha no Supertonic")[-500:]
            raise SpeechError(f"Supertonic falhou: {detail}")

    def _run_kokoro(self, plain: str, wav: Path, timeout: int) -> None:
        python_bin = self._resolve_executable(getattr(self.cfg, "tts_kokoro_python", "python"))
        model, voices = self._kokoro_paths()
        if not python_bin or not model.is_file() or not voices.is_file():
            raise SpeechError("Kokoro não está instalado por completo.")
        voice = str(getattr(self.cfg, "tts_kokoro_voice", "pm_alex") or "pm_alex")
        speed = float(getattr(self.cfg, "tts_kokoro_speed", 1.0) or 1.0)
        cmd = [
            python_bin,
            "-m", "daniel_ai.kokoro_worker",
            "--model", str(model),
            "--voices", str(voices),
            "--voice", voice,
            "--speed", str(speed),
            "--output", str(wav),
            "--text", plain,
        ]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, check=False)
        if proc.returncode != 0 or not wav.is_file() or wav.stat().st_size < 44:
            detail = (proc.stderr or proc.stdout or "falha no Kokoro")[-500:]
            raise SpeechError(f"Kokoro falhou: {detail}")

    def _run_espeak(self, plain: str, wav: Path, timeout: int) -> None:
        espeak = self._resolve_espeak()
        if not espeak:
            raise SpeechError("eSpeak não encontrado.")
        voice = str(getattr(self.cfg, "tts_voice", "pt-br") or "pt-br")
        speed = int(getattr(self.cfg, "tts_speed", 155) or 155)
        proc = subprocess.run(
            [espeak, "-v", voice, "-s", str(speed), "-w", str(wav), plain],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
        if proc.returncode != 0 or not wav.is_file() or wav.stat().st_size < 44:
            detail = (proc.stderr or "falha no eSpeak")[-400:]
            raise SpeechError(f"eSpeak falhou: {detail}")

    def _encode_telegram_voice(self, source: Path, ogg: Path, ffmpeg: str, timeout: int) -> None:
        enc = subprocess.run(
            [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
             "-c:a", "libopus", "-b:a", "40k", "-application", "voip", str(ogg)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
        if enc.returncode != 0 or not ogg.is_file() or ogg.stat().st_size < 64:
            detail = (enc.stderr or "falha no ffmpeg/opus")[-400:]
            raise SpeechError(f"Falha ao gerar áudio Opus: {detail}")

    def synthesize(self, text: str, *, engine: str | None = None) -> Path:
        status = self.status()
        if not status.enabled:
            raise SpeechError("Resposta falada está desligada.")
        if not status.ready:
            raise SpeechError("TTS não está pronto: " + ", ".join(status.missing))
        plain = self._plain_text(text)
        if not plain:
            raise SpeechError("Não há texto para sintetizar.")
        if len(plain) > status.max_chars:
            plain = plain[: max(1, status.max_chars - 30)].rstrip() + ". A resposta completa está no texto."

        token = uuid.uuid4().hex
        wav = self.tmp_dir / f"daniel_tts_{token}.wav"
        mp3 = self.tmp_dir / f"daniel_tts_{token}.mp3"
        ogg = self.tmp_dir / f"daniel_tts_{token}.ogg"
        timeout = max(20, int(getattr(self.cfg, "tts_timeout_seconds", 120) or 120))
        availability = self._engine_availability()
        failures: list[str] = []
        requested_engine = str(engine or "").strip().lower()
        if requested_engine and requested_engine not in self.ENGINE_ORDER:
            raise SpeechError(f"Motor de fala inválido: {requested_engine}")
        engine_order = (requested_engine,) if requested_engine else self._preferred_order()
        try:
            for current_engine in engine_order:
                if not bool(availability.get(current_engine)):
                    continue
                try:
                    wav.unlink(missing_ok=True)
                    mp3.unlink(missing_ok=True)
                    source = wav
                    if current_engine == "speechify":
                        source = mp3
                        self._run_speechify(plain, mp3, timeout)
                    elif current_engine == "edge":
                        source = mp3
                        self._run_edge(plain, mp3, timeout)
                    elif current_engine == "supertonic":
                        self._run_supertonic(plain, wav, timeout)
                    elif current_engine == "kokoro":
                        self._run_kokoro(plain, wav, timeout)
                    else:
                        self._run_espeak(plain, wav, timeout)
                    self._encode_telegram_voice(source, ogg, status.ffmpeg_bin, timeout)
                    return ogg
                except (SpeechError, subprocess.TimeoutExpired, OSError) as exc:
                    failures.append(f"{current_engine}: {type(exc).__name__}: {exc}")
                    # auto/fallback contract: keep trying the next engine.
                    continue
            detail = " | ".join(failures)[-900:] or "nenhum motor disponível"
            raise SpeechError("Todos os motores de fala falharam. " + detail)
        finally:
            for source in (wav, mp3):
                try:
                    source.unlink(missing_ok=True)
                except Exception:
                    pass
