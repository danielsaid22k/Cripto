from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class VoiceError(RuntimeError):
    pass


class VoiceNotReadyError(VoiceError):
    pass


@dataclass(frozen=True)
class VoiceStatus:
    enabled: bool
    ready: bool
    backend: str
    language: str
    model_path: str
    whisper_bin: str
    ffmpeg_bin: str
    max_seconds: int
    max_bytes: int
    missing: tuple[str, ...]


class DanielVoice:
    """Bounded local speech-to-text adapter for Telegram voice messages.

    V1.1 deliberately keeps voice isolated from the CSM decision engine. It
    converts one downloaded Telegram audio file to 16 kHz mono WAV and invokes
    a local whisper.cpp CLI. No OpenAI/API key is required. Failures are
    returned to the caller and never stop the bot runtime.
    """

    def __init__(self, cfg: Any):
        self.cfg = cfg
        self.voice_dir = Path(getattr(cfg, "voice_dir", None) or (cfg.state_dir / "voice"))
        self.inbox_dir = self.voice_dir / "inbox"
        self.tmp_dir = self.voice_dir / "tmp"
        self.voice_dir.mkdir(parents=True, exist_ok=True)
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        self.tmp_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _resolve_executable(value: str) -> str:
        raw = str(value or "").strip()
        if not raw:
            return ""
        p = Path(raw).expanduser()
        if p.is_absolute() or "/" in raw:
            return str(p) if p.exists() and os.access(p, os.X_OK) else ""
        return shutil.which(raw) or ""

    def _whisper_bin(self) -> str:
        configured = self._resolve_executable(getattr(self.cfg, "voice_whisper_bin", ""))
        if configured:
            return configured
        candidates = [
            self.voice_dir / "whisper.cpp" / "build" / "bin" / "whisper-cli",
            self.voice_dir / "whisper.cpp" / "build" / "bin" / "main",
            self.voice_dir / "whisper.cpp" / "main",
        ]
        for path in candidates:
            if path.exists() and os.access(path, os.X_OK):
                return str(path)
        return shutil.which("whisper-cli") or shutil.which("whisper.cpp") or ""

    def _model_path(self) -> Path:
        configured = str(getattr(self.cfg, "voice_model_path", "") or "").strip()
        if configured:
            return Path(configured).expanduser()
        model = str(getattr(self.cfg, "voice_model", "tiny") or "tiny").strip().lower()
        return self.voice_dir / "whisper.cpp" / "models" / f"ggml-{model}.bin"

    def status(self) -> VoiceStatus:
        ffmpeg = self._resolve_executable(getattr(self.cfg, "voice_ffmpeg_bin", "ffmpeg"))
        whisper = self._whisper_bin()
        model = self._model_path()
        missing: list[str] = []
        if not ffmpeg:
            missing.append("ffmpeg")
        if not whisper:
            missing.append("whisper.cpp")
        if not model.is_file() or model.stat().st_size < 1024 * 1024:
            missing.append("modelo")
        enabled = bool(getattr(self.cfg, "voice_enabled", True))
        return VoiceStatus(
            enabled=enabled,
            ready=enabled and not missing,
            backend="whisper.cpp",
            language=str(getattr(self.cfg, "voice_language", "pt") or "pt"),
            model_path=str(model),
            whisper_bin=whisper,
            ffmpeg_bin=ffmpeg,
            max_seconds=int(getattr(self.cfg, "voice_max_seconds", 90) or 90),
            max_bytes=int(getattr(self.cfg, "voice_max_bytes", 12 * 1024 * 1024) or 12 * 1024 * 1024),
            missing=tuple(missing),
        )

    def validate_message(self, voice: dict[str, Any]) -> None:
        status = self.status()
        if not status.enabled:
            raise VoiceNotReadyError("O Daniel AI Voice está desligado.")
        duration = int(voice.get("duration") or 0)
        file_size = int(voice.get("file_size") or 0)
        if duration > status.max_seconds:
            raise VoiceError(f"Áudio acima do limite de {status.max_seconds}s.")
        if file_size > status.max_bytes:
            mb = max(1, status.max_bytes // (1024 * 1024))
            raise VoiceError(f"Áudio acima do limite de {mb} MB.")
        if not voice.get("file_id"):
            raise VoiceError("Telegram não forneceu file_id para o áudio.")
        if not status.ready:
            missing = ", ".join(status.missing) or "backend"
            raise VoiceNotReadyError(f"Módulo de voz ainda não está pronto: {missing}.")

    @staticmethod
    def _clean_transcript(text: str) -> str:
        raw = str(text or "").replace("\x00", " ")
        # whisper.cpp may prefix timestamps if a build ignores -nt.
        raw = re.sub(r"\[[0-9:.\- >]+\]", " ", raw)
        raw = re.sub(r"\s+", " ", raw).strip()
        # Natural wake word is optional; strip it so the same local engine sees
        # the query it would receive after /daniel.
        raw = re.sub(r"(?is)^\s*(?:ei\s+)?daniel[\s,.:;-]+", "", raw).strip()
        return raw[:4000]

    def transcribe(self, source: str | Path) -> str:
        src = Path(source)
        if not src.is_file():
            raise VoiceError("Arquivo de voz não encontrado.")
        status = self.status()
        if not status.ready:
            raise VoiceNotReadyError("Backend local de voz não está pronto.")
        if src.stat().st_size > status.max_bytes:
            raise VoiceError("Arquivo de voz excede o limite configurado.")

        with tempfile.TemporaryDirectory(prefix="daniel_voice_", dir=str(self.tmp_dir)) as td:
            temp = Path(td)
            wav = temp / "voice.wav"
            out_prefix = temp / "transcript"
            try:
                ff = subprocess.run(
                    [status.ffmpeg_bin, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", str(wav)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=45,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise VoiceError(f"Falha local no ffmpeg: {type(exc).__name__}") from exc
            if ff.returncode != 0 or not wav.is_file():
                detail = (ff.stderr or "falha de conversão")[-300:]
                raise VoiceError(f"Não foi possível converter o áudio: {detail}")

            cmd = [
                status.whisper_bin,
                "-m", status.model_path,
                "-f", str(wav),
                "-l", status.language,
                "-otxt", "-of", str(out_prefix),
                "-nt",
            ]
            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=max(60, int(getattr(self.cfg, "voice_transcribe_timeout_seconds", 150) or 150)),
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise VoiceError(f"Falha local na transcrição: {type(exc).__name__}") from exc
            txt_path = Path(str(out_prefix) + ".txt")
            transcript = txt_path.read_text(encoding="utf-8", errors="replace") if txt_path.exists() else (proc.stdout or "")
            transcript = self._clean_transcript(transcript)
            if proc.returncode != 0 and not transcript:
                detail = (proc.stderr or "falha do whisper.cpp")[-400:]
                raise VoiceError(f"whisper.cpp não conseguiu transcrever: {detail}")
            if not transcript:
                raise VoiceError("Não consegui reconhecer fala nesse áudio.")
            return transcript
