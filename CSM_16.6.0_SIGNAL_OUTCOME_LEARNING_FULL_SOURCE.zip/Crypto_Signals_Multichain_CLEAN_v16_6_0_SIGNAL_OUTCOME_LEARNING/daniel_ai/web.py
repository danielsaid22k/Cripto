from __future__ import annotations

import html
import ipaddress
import json
import re
import socket
import ssl
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote_plus, unquote, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

try:
    import certifi
except Exception:  # pragma: no cover
    certifi = None


class WebSecurityError(ValueError):
    pass


@dataclass(frozen=True)
class WebSearchResult:
    title: str
    url: str
    snippet: str = ""
    source: str = ""


@dataclass(frozen=True)
class WebPage:
    url: str
    title: str
    text: str
    content_type: str
    bytes_read: int


def _public_ip(address: str) -> bool:
    ip = ipaddress.ip_address(address)
    return not (
        ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
        or ip.is_reserved or ip.is_unspecified
    )


def validate_public_url(url: str) -> str:
    raw = str(url or "").strip()
    parsed = urlparse(raw)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise WebSecurityError("somente URLs http/https públicas são permitidas")
    host = (parsed.hostname or "").strip().lower()
    if not host:
        raise WebSecurityError("URL sem hostname")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise WebSecurityError("host local bloqueado")
    try:
        direct_ip = ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        direct_ip = None
    if direct_ip is not None:
        if not _public_ip(str(direct_ip)):
            raise WebSecurityError("endereço IP privado/reservado bloqueado")
    else:
        try:
            infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
        except socket.gaierror as exc:
            raise WebSecurityError("hostname não pôde ser resolvido") from exc
        addresses = {item[4][0] for item in infos if item and item[4]}
        if not addresses:
            raise WebSecurityError("hostname sem endereço resolvido")
        for address in addresses:
            try:
                if not _public_ip(address):
                    raise WebSecurityError("hostname resolve para rede privada/reservada")
            except ValueError:
                continue
    return raw


class _SafeRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        validate_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.title_depth = 0
        self.title_parts: list[str] = []
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs):  # noqa: ANN001
        tag = tag.lower()
        if tag in {"script", "style", "noscript", "svg", "canvas"}:
            self.skip += 1
        if tag == "title":
            self.title_depth += 1
        if tag in {"p", "br", "li", "h1", "h2", "h3", "h4", "article", "section"} and not self.skip:
            self.parts.append("\n")

    def handle_endtag(self, tag: str):
        tag = tag.lower()
        if tag in {"script", "style", "noscript", "svg", "canvas"} and self.skip:
            self.skip -= 1
        if tag == "title" and self.title_depth:
            self.title_depth -= 1
        if tag in {"p", "li", "h1", "h2", "h3", "h4", "article", "section"} and not self.skip:
            self.parts.append("\n")

    def handle_data(self, data: str):
        if self.skip:
            return
        text = re.sub(r"\s+", " ", data).strip()
        if not text:
            return
        if self.title_depth:
            self.title_parts.append(text)
        self.parts.append(text + " ")

    def result(self) -> tuple[str, str]:
        title = re.sub(r"\s+", " ", " ".join(self.title_parts)).strip()
        text = "".join(self.parts)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n\s*\n+", "\n\n", text)
        return title[:300], text.strip()


class _DuckParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.results: list[WebSearchResult] = []
        self._href = ""
        self._title: list[str] = []
        self._capture_title = False
        self._snippet: list[str] = []
        self._capture_snippet = False

    @staticmethod
    def _decode_url(href: str) -> str:
        href = html.unescape(href)
        if href.startswith("//"):
            href = "https:" + href
        parsed = urlparse(href)
        q = parse_qs(parsed.query)
        if "uddg" in q and q["uddg"]:
            return unquote(q["uddg"][0])
        return href

    def handle_starttag(self, tag: str, attrs):  # noqa: ANN001
        attrs_d = dict(attrs)
        classes = set(str(attrs_d.get("class") or "").split())
        if tag.lower() == "a" and "result__a" in classes:
            self._href = self._decode_url(str(attrs_d.get("href") or ""))
            self._title = []
            self._capture_title = True
        if tag.lower() in {"a", "div", "span"} and "result__snippet" in classes:
            self._snippet = []
            self._capture_snippet = True

    def handle_endtag(self, tag: str):
        if tag.lower() == "a" and self._capture_title:
            title = re.sub(r"\s+", " ", " ".join(self._title)).strip()
            if title and self._href:
                self.results.append(WebSearchResult(title=title[:240], url=self._href[:1600], snippet="", source="DuckDuckGo"))
            self._capture_title = False
        if tag.lower() in {"a", "div", "span"} and self._capture_snippet:
            snippet = re.sub(r"\s+", " ", " ".join(self._snippet)).strip()
            if snippet and self.results and not self.results[-1].snippet:
                last = self.results[-1]
                self.results[-1] = WebSearchResult(last.title, last.url, snippet[:500], last.source)
            self._capture_snippet = False

    def handle_data(self, data: str):
        text = data.strip()
        if not text:
            return
        if self._capture_title:
            self._title.append(text)
        if self._capture_snippet:
            self._snippet.append(text)


def _strip_html(value: str, limit: int = 600) -> str:
    text = re.sub(r"<[^>]+>", " ", html.unescape(str(value or "")))
    return re.sub(r"\s+", " ", text).strip()[:limit]


def _rss_results(raw: bytes, source: str) -> list[WebSearchResult]:
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return []
    rows: list[WebSearchResult] = []
    for item in root.findall(".//item"):
        title = _strip_html(item.findtext("title") or "", 240)
        link = html.unescape(str(item.findtext("link") or "")).strip()
        description = _strip_html(item.findtext("description") or "", 500)
        if title and link:
            rows.append(WebSearchResult(title, link[:1600], description, source))
    return rows


class WebClient:
    """Read-only public web client with resilient, keyless search fallbacks.

    Search discovery is intentionally independent from OpenAI. Providers are
    best-effort public endpoints; direct URL reading remains available even if
    all discovery providers fail.
    """

    def __init__(self, *, timeout_seconds: int = 8, max_bytes: int = 700_000, max_results: int = 5, user_agent: str = "DanielAI-CSM/0.5"):
        self.timeout_seconds = max(2, min(int(timeout_seconds), 30))
        self.max_bytes = max(50_000, min(int(max_bytes), 2_000_000))
        self.max_results = max(1, min(int(max_results), 8))
        self.user_agent = str(user_agent or "DanielAI-CSM/0.5")[:120]
        self.last_search_diagnostics: list[dict[str, str | int]] = []
        ctx = ssl.create_default_context(cafile=certifi.where() if certifi else None)
        self.opener = build_opener(_SafeRedirectHandler(), _HTTPSHandler(ctx))

    def _get(self, url: str, *, accept: str | None = None) -> tuple[str, str, bytes]:
        safe = validate_public_url(url)
        req = Request(safe, headers={
            "User-Agent": self.user_agent,
            "Accept": accept or "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5",
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.7",
        })
        with self.opener.open(req, timeout=self.timeout_seconds) as resp:
            final = validate_public_url(resp.geturl())
            content_type = str(resp.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            raw = resp.read(self.max_bytes + 1)
            if len(raw) > self.max_bytes:
                raw = raw[: self.max_bytes]
            return final, content_type, raw

    @staticmethod
    def _decode(raw: bytes, content_type_header: str = "") -> str:
        return raw.decode("utf-8", errors="replace")

    def _search_duckduckgo(self, q: str) -> list[WebSearchResult]:
        url = "https://html.duckduckgo.com/html/?q=" + quote_plus(q[:500])
        _, _, raw = self._get(url)
        parser = _DuckParser()
        parser.feed(self._decode(raw))
        return parser.results

    def _search_bing_rss(self, q: str) -> list[WebSearchResult]:
        url = "https://www.bing.com/search?q=" + quote_plus(q[:500]) + "&format=rss&cc=BR&setlang=pt-BR"
        _, _, raw = self._get(url, accept="application/rss+xml,application/xml,text/xml;q=0.9,*/*;q=0.5")
        return _rss_results(raw, "Bing RSS")

    def _search_google_news(self, q: str) -> list[WebSearchResult]:
        clean = re.sub(r"(?i)\b(not[ií]cias?|news)\b", " ", q).strip() or q
        url = "https://news.google.com/rss/search?q=" + quote_plus(clean[:500]) + "&hl=pt-BR&gl=BR&ceid=BR:pt-419"
        _, _, raw = self._get(url, accept="application/rss+xml,application/xml,text/xml;q=0.9,*/*;q=0.5")
        return _rss_results(raw, "Google News")

    def _search_wikipedia(self, q: str) -> list[WebSearchResult]:
        url = (
            "https://pt.wikipedia.org/w/api.php?action=opensearch&search="
            + quote_plus(q[:300])
            + f"&limit={self.max_results}&namespace=0&format=json"
        )
        _, _, raw = self._get(url, accept="application/json,text/plain;q=0.9,*/*;q=0.5")
        try:
            payload = json.loads(self._decode(raw))
        except Exception:
            return []
        if not isinstance(payload, list) or len(payload) < 4:
            return []
        titles = payload[1] if isinstance(payload[1], list) else []
        snippets = payload[2] if isinstance(payload[2], list) else []
        urls = payload[3] if isinstance(payload[3], list) else []
        rows: list[WebSearchResult] = []
        for idx, title in enumerate(titles):
            link = str(urls[idx] if idx < len(urls) else "").strip()
            if not link:
                continue
            snippet = str(snippets[idx] if idx < len(snippets) else "")
            rows.append(WebSearchResult(str(title)[:240], link[:1600], _strip_html(snippet, 500), "Wikipedia"))
        return rows

    def search(self, query: str) -> list[WebSearchResult]:
        q = re.sub(r"\s+", " ", str(query or "")).strip()
        if not q:
            self.last_search_diagnostics = []
            return []

        news_query = bool(re.search(r"(?i)\b(not[ií]cias?|news|hoje|últimas?|recentes?)\b", q))
        providers = (
            [("Google News", self._search_google_news), ("Bing RSS", self._search_bing_rss), ("DuckDuckGo", self._search_duckduckgo), ("Wikipedia", self._search_wikipedia)]
            if news_query else
            [("Bing RSS", self._search_bing_rss), ("DuckDuckGo", self._search_duckduckgo), ("Wikipedia", self._search_wikipedia), ("Google News", self._search_google_news)]
        )

        gathered: list[WebSearchResult] = []
        diagnostics: list[dict[str, str | int]] = []
        for name, provider in providers:
            try:
                rows = provider(q)
                diagnostics.append({"provider": name, "status": "ok", "results": len(rows)})
            except Exception as exc:
                diagnostics.append({"provider": name, "status": "error", "results": 0, "error": f"{type(exc).__name__}: {str(exc)[:140]}"})
                continue
            gathered.extend(rows)
            if len(gathered) >= self.max_results * 2:
                break

        cleaned: list[WebSearchResult] = []
        seen: set[str] = set()
        for row in gathered:
            try:
                validated = validate_public_url(row.url)
            except Exception:
                continue
            key = validated.rstrip("/").casefold()
            if key in seen:
                continue
            seen.add(key)
            cleaned.append(WebSearchResult(row.title, validated, row.snippet, row.source))
            if len(cleaned) >= self.max_results:
                break
        self.last_search_diagnostics = diagnostics
        return cleaned

    def fetch(self, url: str) -> WebPage:
        final, content_type, raw = self._get(url)
        allowed = {"", "text/html", "application/xhtml+xml", "text/plain", "application/json", "application/xml", "text/xml"}
        if content_type not in allowed:
            raise WebSecurityError(f"tipo de conteúdo não textual bloqueado: {content_type or 'desconhecido'}")
        text_raw = self._decode(raw, content_type)
        if content_type in {"text/plain", "application/json", "application/xml", "text/xml"}:
            title = urlparse(final).hostname or final
            text = re.sub(r"\s+", " ", text_raw).strip()
        else:
            parser = _TextExtractor()
            parser.feed(text_raw)
            title, text = parser.result()
            title = title or (urlparse(final).hostname or final)
        return WebPage(final, title[:300], text[:12000], content_type, len(raw))


from urllib.request import HTTPSHandler as _StdHTTPSHandler


class _HTTPSHandler(_StdHTTPSHandler):
    def __init__(self, context):  # noqa: ANN001
        super().__init__(context=context)
