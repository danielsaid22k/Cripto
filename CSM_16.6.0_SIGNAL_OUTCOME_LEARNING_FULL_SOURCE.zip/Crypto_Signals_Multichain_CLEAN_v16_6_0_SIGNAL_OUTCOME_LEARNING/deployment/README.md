# Deployment v12

## Docker
1. Copie `.env.example` para `config.env` e preencha os segredos localmente.
2. `docker compose up -d csm-bot`
3. Para API SaaS: `docker compose --profile saas up -d`

## systemd
Os arquivos `csm.service` e `csm-api.service` são modelos para VPS Linux. Use usuário sem privilégio, estado em `/var/lib/crypto-signals-multichain` e segredos em `/etc/crypto-signals-multichain/config.env`.

A API deve ficar atrás de HTTPS/reverse proxy quando exposta publicamente.
