#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 -m pip install --disable-pip-version-check -r requirements.txt
[ -f .env ] || cp .env.example .env
python3 main.py selftest
echo "✅ Instalação a-Shell concluída."
echo "Upgrade: python3 main.py config-recover"
echo "Nova instalação: python3 main.py setup"
