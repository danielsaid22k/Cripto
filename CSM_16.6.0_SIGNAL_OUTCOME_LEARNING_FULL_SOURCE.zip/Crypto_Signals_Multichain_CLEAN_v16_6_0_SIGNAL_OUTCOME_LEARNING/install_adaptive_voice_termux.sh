#!/data/data/com.termux/files/usr/bin/bash
# Daniel AI V1.2.4 — Adaptive Conversational Voice
# No new model or paid API. Preserves STT/TTS and changes only voice-language preparation.
set -e
cd "$(dirname "$0")"

echo "🧠 Daniel AI V1.2.4 — Adaptive Conversational Voice"
echo "Perfis automáticos: executivo | analista | explicativo"
echo "Texto técnico permanece completo; áudio passa a explicar em vez de ler."
echo

echo "[1/4] Validando código..."
python -m py_compile daniel_ai/conversational_voice.py daniel_ai/config.py phantom_v10/router.py main.py

echo "[2/4] Ativando perfil adaptativo no estado persistente..."
python - <<'PY'
from pathlib import Path
from dotenv import dotenv_values
from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env

values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
values['DANIEL_AI_CONVERSATIONAL_VOICE_ENABLED'] = 'true'
values['DANIEL_AI_CONVERSATIONAL_VOICE_STYLE'] = 'adaptive'
values['DANIEL_AI_CONVERSATIONAL_VOICE_DETAIL'] = 'balanced'
values['DANIEL_AI_CONVERSATIONAL_VOICE_MAX_CHARS'] = '1250'
values['DANIEL_AI_CONVERSATIONAL_COMMAND_EXPLAINER'] = 'true'
values['DANIEL_AI_CONVERSATIONAL_NATURAL_VARIATION'] = 'true'

# Recovery-safe: never clear a working Whisper installation during an update.
home = Path.home()
whisper = home / '.local/share/csm_daniel_voice/whisper.cpp/build/bin/whisper-cli'
model = home / '.local/share/csm_daniel_voice/whisper.cpp/models/ggml-tiny.bin'
if not values.get('DANIEL_AI_VOICE_WHISPER_BIN') and whisper.is_file():
    values['DANIEL_AI_VOICE_WHISPER_BIN'] = str(whisper)
if not values.get('DANIEL_AI_VOICE_MODEL_PATH') and model.is_file():
    values['DANIEL_AI_VOICE_MODEL_PATH'] = str(model)
if whisper.is_file() and model.is_file():
    values.setdefault('DANIEL_AI_VOICE_ENABLED', 'true')

write_env(values)
print('Config persistente:', PERSISTENT_ENV_FILE)
PY

echo "[3/4] Status da conversa adaptativa..."
python main.py daniel-conversational-voice-status

echo "[4/4] Testando os três estilos..."
python main.py daniel-conversational-voice-test || {
  echo "⚠️ Os roteiros adaptativos foram instalados. Se o TTS estiver offline, o texto continua funcionando e os fallbacks permanecem ativos."
}

echo
echo "✅ V1.2.4 instalada. Scanner, score, filtros, pagamentos e banco não foram alterados."
echo "Reinicie: csm-stop && csm-start"
