#!/data/data/com.termux/files/usr/bin/bash
# Daniel AI V1.2.3 — Conversational Voice Intelligence
# No new heavy dependency: preserves STT/TTS and only enables local narration.
set -e
cd "$(dirname "$0")"

echo "🧠 Daniel AI V1.2.3 — Conversational Voice Intelligence"
echo "Texto no Telegram continua técnico; áudio vira briefing conversacional."
echo

echo "[1/4] Validando base Python..."
python -m py_compile daniel_ai/conversational_voice.py daniel_ai/config.py phantom_v10/router.py main.py

echo "[2/4] Persistindo somente a nova camada..."
python - <<'PY'
from pathlib import Path
from dotenv import dotenv_values
from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env

values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
values['DANIEL_AI_CONVERSATIONAL_VOICE_ENABLED'] = 'true'
values.setdefault('DANIEL_AI_CONVERSATIONAL_VOICE_STYLE', 'executive')
values.setdefault('DANIEL_AI_CONVERSATIONAL_VOICE_DETAIL', 'balanced')
values.setdefault('DANIEL_AI_CONVERSATIONAL_VOICE_MAX_CHARS', '1150')

# Recovery-safe: V1.2.3 never clears working Whisper paths. If an older update
# omitted them from the persistent env but the already-installed files exist,
# recover the canonical local paths automatically.
home = Path.home()
whisper = home / '.local/share/csm_daniel_voice/whisper.cpp/build/bin/whisper-cli'
model = home / '.local/share/csm_daniel_voice/whisper.cpp/models/ggml-tiny.bin'
if not values.get('DANIEL_AI_VOICE_WHISPER_BIN') and whisper.is_file():
    values['DANIEL_AI_VOICE_WHISPER_BIN'] = str(whisper)
if not values.get('DANIEL_AI_VOICE_MODEL_PATH') and model.is_file():
    values['DANIEL_AI_VOICE_MODEL_PATH'] = str(model)
if whisper.is_file() and model.is_file():
    values.setdefault('DANIEL_AI_VOICE_ENABLED', 'true')

write_env(values)
print('Config persistente:', PERSISTENT_ENV_FILE)
PY

echo "[3/4] Status da camada conversacional..."
python main.py daniel-conversational-voice-status

echo "[4/4] Teste do roteiro falado + TTS..."
python main.py daniel-conversational-voice-test || {
  echo "⚠️ O roteiro conversacional foi instalado. Se o TTS online estiver indisponível, o texto continua funcionando e os fallbacks permanecem ativos."
}

echo
echo "✅ V1.2.3 instalada sem alterar scanner, score, filtros, pagamentos ou banco."
echo "Reinicie: csm-stop && csm-start"
