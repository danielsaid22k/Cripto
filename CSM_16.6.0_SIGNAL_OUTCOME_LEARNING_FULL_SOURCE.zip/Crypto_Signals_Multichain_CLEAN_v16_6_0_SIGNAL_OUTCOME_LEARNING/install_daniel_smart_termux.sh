#!/data/data/com.termux/files/usr/bin/bash
# Daniel AI V1.3.0 — Daniel Smart / Local Generative Brain
# Qwen3-4B Q4_K_M + llama.cpp. No OpenAI/API key is required.
set -euo pipefail
cd "$(dirname "$0")"

ROOT="$HOME/.local/share/csm_daniel_llm"
LLAMA_DIR="$ROOT/llama.cpp"
MODEL_DIR="$ROOT/models"
MODEL="$MODEL_DIR/Qwen3-4B-Q4_K_M.gguf"
MODEL_URL="https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf?download=true"
JOBS="${DANIEL_LLM_BUILD_JOBS:-2}"

echo "🧠 Daniel AI V1.3.0 — DANIEL SMART"
echo "Modelo: Qwen3-4B Q4_K_M (~2,5 GB)"
echo "Backend: llama.cpp local no Android/Termux"
echo "OpenAI/API paga: não necessária"
echo

echo "[1/7] Validando espaço livre..."
mkdir -p "$ROOT" "$MODEL_DIR"
FREE_KB="$(df -Pk "$HOME" | awk 'NR==2 {print $4}')"
NEED_KB=4200000
if [ "${FREE_KB:-0}" -lt "$NEED_KB" ] && [ ! -s "$MODEL" ]; then
  echo "❌ Espaço insuficiente no armazenamento interno do Termux."
  echo "São recomendados pelo menos 4,2 GB livres para compilar o llama.cpp e baixar o modelo Smart."
  exit 1
fi
echo "✅ Espaço mínimo verificado."

echo "[2/7] Dependências Termux..."
pkg install -y git cmake clang make curl libandroid-spawn

echo "[3/7] Preparando llama.cpp..."
if [ ! -d "$LLAMA_DIR/.git" ]; then
  rm -rf "$LLAMA_DIR"
  git clone --depth 1 https://github.com/ggml-org/llama.cpp "$LLAMA_DIR"
else
  git -C "$LLAMA_DIR" pull --ff-only || true
fi

echo "[4/7] Compilando llama.cpp de forma conservadora..."
cmake -S "$LLAMA_DIR" -B "$LLAMA_DIR/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DGGML_OPENMP=OFF \
  -DBUILD_SHARED_LIBS=OFF
cmake --build "$LLAMA_DIR/build" --config Release -j"$JOBS" --target llama-cli
LLAMA_BIN="$LLAMA_DIR/build/bin/llama-cli"
if [ ! -x "$LLAMA_BIN" ]; then
  echo "❌ llama-cli não foi criado em $LLAMA_BIN"
  exit 1
fi
echo "✅ llama-cli: $LLAMA_BIN"

echo "[5/7] Baixando modelo Smart, se necessário..."
if [ ! -s "$MODEL" ] || [ "$(wc -c < "$MODEL" 2>/dev/null || echo 0)" -lt 2000000000 ]; then
  rm -f "$MODEL.part"
  curl -L --fail --retry 3 --retry-delay 3 --continue-at - "$MODEL_URL" -o "$MODEL.part"
  mv "$MODEL.part" "$MODEL"
else
  echo "✅ Modelo já existe; download ignorado."
fi
python - "$MODEL" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
if not p.is_file() or p.stat().st_size < 2_000_000_000:
    raise SystemExit("modelo GGUF incompleto")
with p.open('rb') as f:
    magic=f.read(4)
if magic != b'GGUF':
    raise SystemExit(f"arquivo não parece GGUF: magic={magic!r}")
print(f"✅ GGUF verificado: {p.stat().st_size/1024/1024/1024:.2f} GB")
PY

echo "[6/7] Persistindo configuração segura..."
export DANIEL_SMART_BIN="$LLAMA_BIN"
export DANIEL_SMART_MODEL="$MODEL"
python - <<'PY'
import os
from pathlib import Path
from dotenv import dotenv_values
from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env

values={str(k): str(v or '') for k,v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
values['DANIEL_LOCAL_LLM_ENABLED']='true'
values['DANIEL_LOCAL_LLM_MODE']='smart'
values['DANIEL_LOCAL_LLM_MODEL_NAME']='Qwen3-4B Q4_K_M'
values['DANIEL_LOCAL_LLM_MODEL_PATH']=os.environ['DANIEL_SMART_MODEL']
values['DANIEL_LOCAL_LLM_BIN']=os.environ['DANIEL_SMART_BIN']
values['DANIEL_LOCAL_LLM_CONTEXT']='4096'
values['DANIEL_LOCAL_LLM_MAX_TOKENS']='320'
values['DANIEL_LOCAL_LLM_THREADS']='4'
values['DANIEL_LOCAL_LLM_TIMEOUT_SECONDS']='180'
values['DANIEL_LOCAL_LLM_TEMPERATURE']='0.7'
values['DANIEL_LOCAL_LLM_TOP_P']='0.8'
values['DANIEL_LOCAL_LLM_TOP_K']='20'
values['DANIEL_LOCAL_LLM_MIN_P']='0.0'
values['DANIEL_LOCAL_LLM_HISTORY_MESSAGES']='6'

# Preserve the already-installed local voice receiver across upgrades.
home=Path.home()
whisper=home/'.local/share/csm_daniel_voice/whisper.cpp/build/bin/whisper-cli'
model=home/'.local/share/csm_daniel_voice/whisper.cpp/models/ggml-tiny.bin'
if not values.get('DANIEL_AI_VOICE_WHISPER_BIN') and whisper.is_file():
    values['DANIEL_AI_VOICE_WHISPER_BIN']=str(whisper)
if not values.get('DANIEL_AI_VOICE_MODEL_PATH') and model.is_file():
    values['DANIEL_AI_VOICE_MODEL_PATH']=str(model)
if whisper.is_file() and model.is_file():
    values.setdefault('DANIEL_AI_VOICE_ENABLED','true')

write_env(values)
print('Config persistente:', PERSISTENT_ENV_FILE)
PY

echo "[7/7] Status e teste curto..."
python main.py daniel-smart-status
python main.py daniel-smart-test

echo
echo "✅ Daniel Smart instalado."
echo "As rotas do CSM continuam prioritárias e read-only."
echo "Perguntas livres agora podem usar o cérebro generativo local."
echo "Benchmark: python main.py daniel-smart-benchmark"
echo "Depois reinicie: csm-stop && csm-start"
