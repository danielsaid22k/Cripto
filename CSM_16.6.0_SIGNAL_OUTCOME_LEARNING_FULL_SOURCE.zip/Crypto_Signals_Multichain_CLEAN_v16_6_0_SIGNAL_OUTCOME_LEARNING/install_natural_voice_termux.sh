#!/data/data/com.termux/files/usr/bin/bash
# Daniel AI V1.2.3 — Natural Neural Voice
# Microsoft Edge Neural PT-BR online primary + local neural fallbacks.
set -e
cd "$(dirname "$0")"

printf '%s\n' "🗣️ Daniel AI V1.2.3 — Natural Neural Voice"
printf '%s\n' "Entrada de voz continua local (whisper.cpp)."
printf '%s\n' "Saída principal usa Microsoft Edge online TTS via edge-tts, sem chave de API."
printf '%s\n' "Se a internet/serviço falhar: Supertonic → Kokoro → eSpeak."
echo

printf '%s\n' "[1/5] Dependências Termux..."
pkg install -y python ffmpeg espeak

printf '%s\n' "[2/5] Instalando edge-tts..."
python -m pip install --upgrade edge-tts
EDGE_BIN="$(command -v edge-tts 2>/dev/null || true)"
FFMPEG_BIN="$(command -v ffmpeg 2>/dev/null || true)"
if [ -z "$EDGE_BIN" ]; then
  echo "❌ edge-tts não foi localizado no PATH após a instalação."
  exit 1
fi
if [ -z "$FFMPEG_BIN" ]; then
  echo "❌ ffmpeg não foi localizado no PATH."
  exit 1
fi
echo "✅ edge-tts: $EDGE_BIN"

printf '%s\n' "[3/5] Validando vozes PT-BR online..."
VOICE_OK=0
if timeout 35 "$EDGE_BIN" --list-voices 2>/dev/null | grep -q 'pt-BR-AntonioNeural'; then
  VOICE_OK=1
  echo "✅ pt-BR-AntonioNeural disponível."
else
  echo "⚠️ Não foi possível confirmar a lista online agora. O runtime fará fallback local se necessário."
fi

printf '%s\n' "[4/5] Persistindo configuração..."
export DANIEL_NATURAL_EDGE_BIN="$EDGE_BIN"
export DANIEL_NATURAL_FFMPEG_BIN="$FFMPEG_BIN"
python - <<'PY'
import os
from dotenv import dotenv_values
from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
values={str(k): str(v or '') for k,v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
values['DANIEL_AI_TTS_ENABLED']='true'
values['DANIEL_AI_TTS_ENGINE']='edge'
values['DANIEL_AI_TTS_EDGE_BIN']=os.environ.get('DANIEL_NATURAL_EDGE_BIN') or 'edge-tts'
values['DANIEL_AI_TTS_EDGE_VOICE']='pt-BR-AntonioNeural'
values['DANIEL_AI_TTS_EDGE_RATE']='-4%'
values['DANIEL_AI_TTS_EDGE_PITCH']='+0Hz'
values['DANIEL_AI_TTS_EDGE_VOLUME']='+0%'
values['DANIEL_AI_TTS_EDGE_TIMEOUT_SECONDS']='35'
values['DANIEL_AI_TTS_FFMPEG_BIN']=os.environ.get('DANIEL_NATURAL_FFMPEG_BIN') or 'ffmpeg'
write_env(values)
print('Config persistente:', PERSISTENT_ENV_FILE)
PY

printf '%s\n' "[5/5] Teste real do novo motor..."
if python main.py daniel-speech-test; then
  echo "✅ Microsoft Edge Neural gerou o teste com sucesso."
else
  echo "⚠️ O teste online falhou agora. O texto do Telegram continua funcionando e o runtime tentará os motores locais automaticamente."
fi

echo
echo "✅ Instalação concluída sem alterar scanner, pagamentos, filtros ou banco do CSM."
echo "Status: python main.py daniel-speech-status"
echo "Comparar vozes: python main.py daniel-speech-compare"
echo "Escolher voz: python main.py daniel-speech-use antonio"
echo "Depois reinicie: csm-stop && csm-start"
