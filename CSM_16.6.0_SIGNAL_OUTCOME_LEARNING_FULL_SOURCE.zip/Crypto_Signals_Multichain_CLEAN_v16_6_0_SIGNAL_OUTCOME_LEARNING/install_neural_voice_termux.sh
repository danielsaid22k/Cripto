#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")"

printf '%s\n' "🔊 Daniel AI V1.2.1 — Neural Human Voice"
printf '%s\n' "Supertonic 3 → Kokoro PT-BR → eSpeak (emergência)"
printf '%s\n' "OpenAI não é necessária. Os motores neurais funcionam localmente após baixar os modelos."

TTS_HOME="$HOME/.local/share/csm_daniel_tts"
KOKORO_DIR="$TTS_HOME/kokoro"
mkdir -p "$KOKORO_DIR"

printf '%s\n' "[1/7] Dependências Termux..."
# Termux chama o pacote de eSpeak de 'espeak'. O executável pode aparecer como
# espeak ou espeak-ng dependendo do repositório/build.
pkg install -y ffmpeg espeak libsndfile wget python-numpy python-onnxruntime || {
  echo "⚠️ Algumas dependências não instalaram na primeira tentativa. Atualizando índices..."
  pkg update -y || true
  pkg install -y ffmpeg espeak libsndfile wget python-numpy python-onnxruntime || true
}

FFMPEG_BIN="$(command -v ffmpeg 2>/dev/null || true)"
ESPEAK_BIN="$(command -v espeak 2>/dev/null || command -v espeak-ng 2>/dev/null || true)"

printf '%s\n' "[2/7] Validando ONNX Runtime nativo do Termux..."
ORT_OK=0
if python - <<'PY' >/dev/null 2>&1
import onnxruntime
print(onnxruntime.__version__)
PY
then
  ORT_OK=1
  python - <<'PY'
import onnxruntime
print("✅ ONNX Runtime:", onnxruntime.__version__)
PY
else
  echo "⚠️ python-onnxruntime ainda não importa. Tentando reinstalação do pacote Termux..."
  pkg reinstall -y python-onnxruntime || true
  if python - <<'PY' >/dev/null 2>&1
import onnxruntime
PY
  then ORT_OK=1; fi
fi

printf '%s\n' "[3/7] Instalando Supertonic 3..."
SUPERTONIC_OK=0
SUPERTONIC_BIN=""
if [ "$ORT_OK" = "1" ]; then
  # Usa o onnxruntime empacotado pelo Termux; --no-deps impede o pip de tentar
  # substituir esse binário Android por uma wheel Linux incompatível.
  python -m pip install --upgrade huggingface-hub soundfile >/dev/null 2>&1 || true
  python -m pip install --upgrade --no-deps supertonic >/dev/null 2>&1 || true
  SUPERTONIC_BIN="$(command -v supertonic 2>/dev/null || true)"
  if [ -n "$SUPERTONIC_BIN" ] && python - <<'PY' >/dev/null 2>&1
import onnxruntime, soundfile
import supertonic
PY
  then
    SUPERTONIC_OK=1
    echo "✅ Supertonic instalado: $SUPERTONIC_BIN"
  else
    echo "⚠️ Supertonic não ficou disponível; o instalador continuará para o fallback neural."
  fi
else
  echo "⚠️ ONNX Runtime indisponível; pulando motores neurais e preservando fallback eSpeak."
fi

printf '%s\n' "[4/7] Aquecendo/testando Supertonic 3 (primeiro uso baixa ~400 MB)..."
WARMUP="$TTS_HOME/supertonic_warmup.wav"
if [ "$SUPERTONIC_OK" = "1" ]; then
  rm -f "$WARMUP"
  if "$SUPERTONIC_BIN" tts "Olá. Eu sou o Daniel. Minha nova voz neural está pronta." -o "$WARMUP" --voice M1 --steps 8 --lang pt --speed 1.0 >/dev/null 2>&1 && [ -s "$WARMUP" ]; then
    echo "✅ Supertonic 3 gerou áudio local com sucesso."
  else
    echo "⚠️ O warm-up do Supertonic falhou. Kokoro/eSpeak continuarão disponíveis."
    SUPERTONIC_OK=0
  fi
fi
rm -f "$WARMUP"

printf '%s\n' "[5/7] Preparando Kokoro 82M PT-BR como fallback neural..."
KOKORO_OK=0
KOKORO_MODEL="$KOKORO_DIR/kokoro-v1.0.int8.onnx"
KOKORO_VOICES="$KOKORO_DIR/voices-v1.0.bin"
if [ "$ORT_OK" = "1" ]; then
  # A instalação é best-effort. Falha do Kokoro não derruba Supertonic nem CSM.
  python -m pip install --upgrade kokoro-onnx soundfile >/dev/null 2>&1 || true
  if [ ! -s "$KOKORO_MODEL" ]; then
    wget -q --show-progress -O "$KOKORO_MODEL.part" \
      "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.int8.onnx" || true
    if [ -s "$KOKORO_MODEL.part" ]; then mv "$KOKORO_MODEL.part" "$KOKORO_MODEL"; else rm -f "$KOKORO_MODEL.part"; fi
  fi
  if [ ! -s "$KOKORO_VOICES" ]; then
    wget -q --show-progress -O "$KOKORO_VOICES.part" \
      "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin" || true
    if [ -s "$KOKORO_VOICES.part" ]; then mv "$KOKORO_VOICES.part" "$KOKORO_VOICES"; else rm -f "$KOKORO_VOICES.part"; fi
  fi
  if python - <<PY >/dev/null 2>&1
import onnxruntime, soundfile
from kokoro_onnx import Kokoro
assert __import__('pathlib').Path('$KOKORO_MODEL').is_file()
assert __import__('pathlib').Path('$KOKORO_VOICES').is_file()
PY
  then
    KOKORO_OK=1
    echo "✅ Kokoro PT-BR preparado."
  else
    echo "⚠️ Kokoro não ficou pronto. Isso não bloqueia o Supertonic/eSpeak."
  fi
fi

printf '%s\n' "[6/7] Persistindo configuração segura..."
export DANIEL_NEURAL_SUPERTONIC_BIN="$SUPERTONIC_BIN"
export DANIEL_NEURAL_KOKORO_MODEL="$KOKORO_MODEL"
export DANIEL_NEURAL_KOKORO_VOICES="$KOKORO_VOICES"
export DANIEL_NEURAL_ESPEAK_BIN="$ESPEAK_BIN"
export DANIEL_NEURAL_FFMPEG_BIN="$FFMPEG_BIN"
python - <<'PY'
import os
from dotenv import dotenv_values
from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
values={str(k): str(v or '') for k,v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
values['DANIEL_AI_TTS_ENABLED']='true'
values['DANIEL_AI_TTS_ENGINE']='auto'
values['DANIEL_AI_TTS_SUPERTONIC_BIN']=os.environ.get('DANIEL_NEURAL_SUPERTONIC_BIN') or 'supertonic'
values['DANIEL_AI_TTS_SUPERTONIC_VOICE']='M1'
values['DANIEL_AI_TTS_SUPERTONIC_LANG']='pt'
values['DANIEL_AI_TTS_SUPERTONIC_STEPS']='8'
values['DANIEL_AI_TTS_SUPERTONIC_SPEED']='1.0'
values['DANIEL_AI_TTS_KOKORO_PYTHON']='python'
values['DANIEL_AI_TTS_KOKORO_MODEL_PATH']=os.environ.get('DANIEL_NEURAL_KOKORO_MODEL','')
values['DANIEL_AI_TTS_KOKORO_VOICES_PATH']=os.environ.get('DANIEL_NEURAL_KOKORO_VOICES','')
values['DANIEL_AI_TTS_KOKORO_VOICE']='pm_alex'
values['DANIEL_AI_TTS_KOKORO_SPEED']='1.0'
values['DANIEL_AI_TTS_ESPEAK_BIN']=os.environ.get('DANIEL_NEURAL_ESPEAK_BIN') or 'espeak'
values['DANIEL_AI_TTS_FFMPEG_BIN']=os.environ.get('DANIEL_NEURAL_FFMPEG_BIN') or 'ffmpeg'
values['DANIEL_AI_TTS_TIMEOUT_SECONDS']='180'
write_env(values)
print('Config persistente:', PERSISTENT_ENV_FILE)
PY

printf '%s\n' "[7/7] Status final..."
python main.py daniel-speech-status || true

echo
echo "✅ Instalador finalizado sem alterar scanner, pagamentos, filtros ou estado do CSM."
if [ "$SUPERTONIC_OK" = "1" ]; then
  echo "🏆 Motor principal pronto: Supertonic 3"
elif [ "$KOKORO_OK" = "1" ]; then
  echo "🧠 Motor neural pronto: Kokoro PT-BR"
elif [ -n "$ESPEAK_BIN" ]; then
  echo "⚠️ Neural não ficou pronto; fallback eSpeak continua funcional."
else
  echo "❌ Nenhum TTS funcional detectado. Veja o status acima."
fi
echo "Teste: python main.py daniel-speech-test"
echo "Depois reinicie: csm-stop && csm-start"
