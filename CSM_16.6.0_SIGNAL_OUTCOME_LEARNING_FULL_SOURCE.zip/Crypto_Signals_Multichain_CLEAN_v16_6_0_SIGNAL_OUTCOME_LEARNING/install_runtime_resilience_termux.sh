#!/data/data/com.termux/files/usr/bin/bash
set -eu

PROJECT="$(cd "$(dirname "$0")" && pwd)"
STATE="$HOME/storage/downloads/Crypto_Signals_Multichain_State"
BOOT="$HOME/.termux/boot"
BOOT_SCRIPT="$BOOT/96-csm-runtime-resilience.sh"
LOG="$STATE/logs/runtime_resilience_watch.log"

mkdir -p "$BOOT" "$STATE/logs"

cat > "$BOOT_SCRIPT" <<EOF
#!/data/data/com.termux/files/usr/bin/bash
PROJECT='$PROJECT'
STATE='$STATE'
LOG='$LOG'

sleep 35

if tmux has-session -t csm-runtime-resilience 2>/dev/null; then
    exit 0
fi

tmux new-session -d \\
  -s csm-runtime-resilience \\
  "cd '\$PROJECT' && exec python -u main.py runtime-resilience-watch --interval 60 >> '\$LOG' 2>&1"
EOF

chmod +x "$BOOT_SCRIPT"

tmux kill-session -t csm-runtime-resilience 2>/dev/null || true

tmux new-session -d \
  -s csm-runtime-resilience \
  "cd '$PROJECT' && exec python -u main.py runtime-resilience-watch --interval 60 >> '$LOG' 2>&1"

sleep 2

if tmux has-session -t csm-runtime-resilience 2>/dev/null; then
    echo "✅ Runtime Resilience V16.5.3 ativo"
    echo "✅ Boot: $BOOT_SCRIPT"
    echo "✅ Log: $LOG"
else
    echo "❌ Runtime Resilience não iniciou"
    tail -30 "$LOG" 2>/dev/null || true
    exit 1
fi
