#!/data/data/com.termux/files/usr/bin/bash
# Compatibilidade: a instalação de resposta falada agora usa a camada V1.2.3.
set -e
cd "$(dirname "$0")"
exec bash install_natural_voice_termux.sh
