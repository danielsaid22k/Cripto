#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
pkg install python -y
python -m pip install --disable-pip-version-check -r requirements.txt
[ -f .env ] || cp .env.example .env
python main.py selftest
echo "✅ Instalação Termux concluída."
echo "Configurar: python main.py setup"
echo "Executar:  python -u launcher.py bot"
