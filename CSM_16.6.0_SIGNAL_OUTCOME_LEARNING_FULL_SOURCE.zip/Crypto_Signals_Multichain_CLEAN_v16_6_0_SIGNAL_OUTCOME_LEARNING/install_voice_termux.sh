#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

echo "🎙️ Daniel AI V1.1 — instalação do Native Voice local"

echo "[1/5] Dependências Termux..."
pkg install -y ffmpeg git cmake clang make wget espeak

# Android shared storage is mounted noexec. Keep the executable engine in
# Termux HOME, not under ~/storage/downloads. Daniel's DB/transcripts remain
# under Crypto_Signals_Multichain_State as before.
ENGINE_DIR="$HOME/.local/share/csm_daniel_voice"
MODEL="${DANIEL_AI_VOICE_MODEL:-tiny}"
WHISPER_DIR="$ENGINE_DIR/whisper.cpp"

echo "[2/5] Motor local persistente: $ENGINE_DIR"
mkdir -p "$ENGINE_DIR"
if [ ! -d "$WHISPER_DIR/.git" ]; then
  rm -rf "$WHISPER_DIR"
  git clone --depth 1 https://github.com/ggerganov/whisper.cpp.git "$WHISPER_DIR"
else
  git -C "$WHISPER_DIR" pull --ff-only || true
fi

echo "[3/5] Compilando whisper.cpp..."
cmake -S "$WHISPER_DIR" -B "$WHISPER_DIR/build" -DWHISPER_BUILD_TESTS=OFF -DWHISPER_BUILD_SERVER=OFF
cmake --build "$WHISPER_DIR/build" --config Release -j2

BIN="$WHISPER_DIR/build/bin/whisper-cli"
if [ ! -x "$BIN" ]; then
  BIN="$WHISPER_DIR/build/bin/main"
fi
if [ ! -x "$BIN" ]; then
  echo "❌ whisper.cpp compilou, mas o executável não foi encontrado."
  exit 1
fi

echo "[4/5] Modelo multilíngue: $MODEL"
MODEL_FILE="$WHISPER_DIR/models/ggml-$MODEL.bin"
if [ ! -s "$MODEL_FILE" ]; then
  bash "$WHISPER_DIR/models/download-ggml-model.sh" "$MODEL"
fi
if [ ! -s "$MODEL_FILE" ]; then
  echo "❌ Modelo não foi baixado."
  exit 1
fi

echo "[5/5] Persistindo configuração..."
python - <<PYI
from dotenv import dotenv_values
from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
values={str(k): str(v or '') for k,v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
values['DANIEL_AI_VOICE_ENABLED']='true'
values['DANIEL_AI_VOICE_LANGUAGE']='pt'
values['DANIEL_AI_VOICE_MODEL']='$MODEL'
values['DANIEL_AI_VOICE_WHISPER_BIN']='$BIN'
values['DANIEL_AI_VOICE_MODEL_PATH']='$MODEL_FILE'
values['DANIEL_AI_VOICE_FFMPEG_BIN']='ffmpeg'
values['DANIEL_AI_TTS_ENABLED']='true'
values['DANIEL_AI_TTS_VOICE']='pt-br'
values['DANIEL_AI_TTS_SPEED']='155'
values['DANIEL_AI_TTS_ESPEAK_BIN']='espeak'
values['DANIEL_AI_TTS_FFMPEG_BIN']='ffmpeg'
write_env(values)
print('Config persistente:', PERSISTENT_ENV_FILE)
PYI

python main.py daniel-voice-status

echo "✅ Native Voice instalado."
echo "Agora reinicie: csm-stop && csm-start"
echo "Depois envie uma mensagem de voz ao bot no Telegram."
