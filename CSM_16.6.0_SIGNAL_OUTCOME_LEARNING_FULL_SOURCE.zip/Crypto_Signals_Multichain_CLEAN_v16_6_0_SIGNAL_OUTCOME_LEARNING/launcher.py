import traceback
print('[launcher] Crypto Signals Multichain CLEAN',flush=True)
try:
 from main import main
 raise SystemExit(main())
except SystemExit:raise
except Exception as e:
 print(f'ERRO: {type(e).__name__}: {e}',flush=True);traceback.print_exc();raise SystemExit(1)
