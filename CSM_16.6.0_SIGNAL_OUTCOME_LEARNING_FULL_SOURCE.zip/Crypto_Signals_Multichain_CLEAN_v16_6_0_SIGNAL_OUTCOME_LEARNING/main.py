from __future__ import annotations

import argparse
import faulthandler
import os
import sys
import traceback
from pathlib import Path

faulthandler.enable(all_threads=True)


def _safe_print(message: str = "") -> None:
    print(message, flush=True)


def _bootstrap_error(stage: str, exc: BaseException) -> int:
    _safe_print(f"❌ Falha durante {stage}: {type(exc).__name__}: {exc}")
    traceback.print_exc()
    return 1


def _version() -> str:
    try:
        from phantom_v10 import __version__
        return __version__
    except Exception as exc:
        _bootstrap_error("importação da versão", exc)
        return "16.0.0-import-error"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=f"Crypto Signals Multichain v{_version()}")
    sub = parser.add_subparsers(dest="cmd")
    for command in ("bot", "health", "doctor", "version", "selftest", "setup", "migrate", "db-check", "db-backup", "backup-list", "backup-check", "leader-audit", "leader-proposals", "leader-status", "maintenance-off", "product-report", "environment-status", "staging-init", "integrity-check", "scanner-report", "lts-status", "admin-dashboard", "release-check", "leader-report", "quality-gate", "health-dashboard", "restore-dry-run", "release-info", "intelligence-report", "platform-dashboard", "leader-simulate", "ops-alerts", "production-readiness", "enterprise-dashboard", "audit-events", "platform-lines", "foundation-audit", "foundation-health", "plugins-status", "foundation-release", "release-tests", "release-summary", "provider-health", "provider-catalog", "dexpaprika-check", "honeypot-check", "birdeye-check", "birdeye-key-audit", "stability-status", "runtime-status", "runtime-recover", "config-recover", "ui-audit", "daniel-status", "daniel-history", "daniel-tools", "daniel-web-on", "daniel-web-off", "daniel-learning-on", "daniel-learning-off", "daniel-learning-status", "daniel-learning-run", "daniel-panel-token", "daniel-voice-status", "daniel-voice-on", "daniel-voice-off", "daniel-speech-status", "daniel-speech-test", "daniel-speech-compare", "daniel-speech-on", "daniel-speech-off", "daniel-speechify-setup", "daniel-speechify-status", "daniel-speechify-voices", "daniel-speechify-test", "retool-token", "retool-admin-start", "retool-admin-stop", "retool-admin-status", "post-update-status", "daniel-conversational-voice-status", "daniel-conversational-voice-test", "daniel-conversational-voice-on", "daniel-conversational-voice-off", "daniel-smart-status", "daniel-smart-test", "daniel-smart-benchmark", "daniel-smart-on", "daniel-smart-off"):

        sub.add_parser(command)

    post_update = sub.add_parser("post-update", help="Finaliza atualização: migra, valida e reinicia serviços somente se tudo passar")
    post_update.add_argument("--delay", type=float, default=0.0, help="Atraso antes de iniciar; usado pelo Retool para liberar a resposta HTTP")
    post_update.add_argument("--no-runtime-restart", action="store_true", help="Executa validações sem reiniciar Runtime")
    post_update.add_argument("--no-admin-restart", action="store_true", help="Executa validações sem reiniciar Admin Bridge")

    lifecycle = sub.add_parser("signal-lifecycle", help="Signal Lifecycle V16.3: estados pós-sinal")
    lifecycle.add_argument("--hours", type=int, default=24)
    lifecycle.add_argument("--chain", default="")

    lifecycle_events = sub.add_parser("signal-lifecycle-events", help="Eventos recentes do Signal Lifecycle")
    lifecycle_events.add_argument("--hours", type=int, default=24)
    lifecycle_events.add_argument("--chain", default="")
    lifecycle_events.add_argument("--limit", type=int, default=30)

    reentry = sub.add_parser("smart-reentry", help="Smart Reentry V16.4: reentradas confirmadas por plano")
    reentry.add_argument("--hours", type=int, default=24)
    reentry.add_argument("--plan", choices=["free", "plus", "premium"], default="")
    reentry.add_argument("--limit", type=int, default=20)

    scanner_intel = sub.add_parser("scanner-intelligence", help="Funil V16.2: aprovados/rejeitados e motivos")
    scanner_intel.add_argument("--hours", type=int, default=24)
    scanner_intel.add_argument("--chain", default="")

    scanner_decisions = sub.add_parser("scanner-decisions", help="Decisões recentes do Scanner Intelligence")
    scanner_decisions.add_argument("--hours", type=int, default=24)
    scanner_decisions.add_argument("--chain", default="")
    scanner_decisions.add_argument("--decision", choices=["approved","rejected","unavailable"], default="")
    scanner_decisions.add_argument("--limit", type=int, default=30)

    provider_coverage = sub.add_parser("provider-coverage", help="Cobertura V16.5.9 por rede/provider")
    provider_coverage.add_argument("--minutes", type=int, default=60)

    provider_intel = sub.add_parser("provider-intelligence-status", help="Quality Router, Birdeye probe e Coverage Guard V16.5.9")

    scanner_provider_diag = sub.add_parser("scanner-provider-diagnostics", help="Rejeições por rede/provider V16.5.9")
    scanner_provider_diag.add_argument("--hours", type=int, default=24)
    scanner_provider_diag.add_argument("--chain", default="")

    daniel_ask = sub.add_parser("daniel-ask", help="Pergunta ao Daniel AI local")
    daniel_ask.add_argument("question", nargs="*", help="Pergunta; se omitida, abre prompt curto")

    daniel_voice_transcribe = sub.add_parser("daniel-voice-transcribe", help="Transcreve um arquivo de áudio usando o backend local V1.1")
    daniel_voice_transcribe.add_argument("audio_file")

    daniel_speech_use = sub.add_parser("daniel-speech-use", help="Escolhe uma voz PT-BR natural do motor Edge")
    daniel_speech_use.add_argument("voice", choices=["antonio", "fabio", "humberto", "francisca"])

    daniel_speechify_use = sub.add_parser("daniel-speechify-use", help="Ativa uma voz Speechify pelo voice_id")
    daniel_speechify_use.add_argument("voice_id")

    daniel_panel = sub.add_parser("daniel-panel", help="Inicia o painel web dedicado do Daniel AI")
    daniel_panel.add_argument("--host", default=None)
    daniel_panel.add_argument("--port", type=int, default=None)
    daniel_panel.add_argument("--token", default=None)

    backup = sub.add_parser("backup", help="Cria backup portátil em ZIP")
    backup.add_argument("--include-secrets", action="store_true")
    backup.add_argument("--output")

    restore = sub.add_parser("restore", help="Restaura um backup")
    restore.add_argument("backup_file", nargs="?")
    restore.add_argument("--restore-secrets", action="store_true")
    restore.add_argument("--choose", action="store_true", help="Lista backups e permite escolher")

    analyze = sub.add_parser("analyze")
    analyze.add_argument("address")
    analyze.add_argument("--chain", "-c")
    analyze.add_argument("--plan", choices=["free", "plus", "premium", "plus_annual", "premium_annual"], default="premium")

    goplus_check = sub.add_parser("goplus-check", help="Valida a API GoPlus e opcionalmente um contrato")
    goplus_check.add_argument("--chain", choices=["solana", "ethereum", "bsc", "base", "arbitrum", "polygon", "avalanche", "optimism", "fantom", "cronos"])
    goplus_check.add_argument("--address")

    sub.add_parser(
        "config-integrity",
        help="Verifica integridade da configuração persistente",
    )

    sub.add_parser(
        "config-integrity-accept",
        help="Aceita a configuração atual como baseline saudável",
    )

    sub.add_parser(
        "config-change-history",
        help="Histórico seguro de alterações do config.env",
    )

    sub.add_parser(
        "runtime-resilience-status",
        help="Saúde consolidada do runtime e serviços V16.5.3",
    )

    resilience_once = sub.add_parser(
        "runtime-resilience-once",
        help="Executa uma rodada do watchdog de resiliência",
    )
    resilience_once.add_argument(
        "--no-recover",
        action="store_true",
        help="Somente diagnostica; não solicita recuperação",
    )

    resilience_watch = sub.add_parser(
        "runtime-resilience-watch",
        help="Watchdog controlado de resiliência V16.5.3",
    )
    resilience_watch.add_argument(
        "--interval",
        type=int,
        default=60,
        help="Intervalo em segundos; mínimo 30",
    )

    sub.add_parser(
        "evidence-attribution-report",
        help="Relatório Evidence Attribution Intelligence 16.5.1",
    )

    sub.add_parser(
        "shadow-evidence-status",
        help="Status do Shadow Evidence Accelerator 16.5.0",
    )

    sub.add_parser(
        "signal-quality-report",
        help="Relatório Signal Quality Intelligence 16.4.9",
    )

    perf = sub.add_parser("performance-report", help="Relatório auditável de desempenho dos sinais entregues")
    perf.add_argument("--days", type=int, default=30)

    sub.add_parser("signal-learning-status", help="Status da V16.6.0 Signal Outcome Learning evidence-only")
    learning_run = sub.add_parser("signal-learning-run", help="Gera snapshot manual do aprendizado de resultados")
    learning_run.add_argument("--days", type=int, default=30)
    learning_report = sub.add_parser("signal-learning-report", help="Relatório evidence-only por rede/provider/faixas")
    learning_report.add_argument("--days", type=int, default=30)
    learning_recs = sub.add_parser("signal-learning-recommendations", help="Recomendações evidence-only; nunca aplica mudanças")
    learning_recs.add_argument("--days", type=int, default=30)
    learning_recs.add_argument("--limit", type=int, default=20)

    shadow_report = sub.add_parser(
        "signal-quality-shadow-report",
        help="Relatório evidence-only da confirmação temporal de qualidade",
    )
    shadow_report.add_argument("--days", type=int, default=30)
    shadow_report.add_argument("--target-seconds", type=int, default=300)
    shadow_report.add_argument("--grace-seconds", type=int, default=180)

    backtest = sub.add_parser("performance-backtest", help="Replay dos sinais históricos persistidos")
    backtest.add_argument("--days", type=int, default=30)
    backtest.add_argument("--min-score", type=int, default=0)
    backtest.add_argument("--min-goplus", type=int, default=0)
    backtest.add_argument("--max-sell-tax", type=float, default=100.0)

    compare = sub.add_parser("performance-compare", help="Compara estratégias A/B sobre o mesmo ledger observado")
    compare.add_argument("--days", type=int, default=30)
    compare.add_argument("--a-min-score", type=int, default=0)
    compare.add_argument("--a-min-goplus", type=int, default=0)
    compare.add_argument("--a-max-sell-tax", type=float, default=100.0)
    compare.add_argument("--b-min-score", type=int, default=80)
    compare.add_argument("--b-min-goplus", type=int, default=80)
    compare.add_argument("--b-max-sell-tax", type=float, default=10.0)

    onchain_status = sub.add_parser("onchain-status", help="Status da camada V13.5 On-Chain Intelligence")
    onchain_status.add_argument("--days", type=int, default=30)

    onchain_report = sub.add_parser("onchain-report", help="Relatório das observações on-chain pós-sinal")
    onchain_report.add_argument("--days", type=int, default=30)
    onchain_report.add_argument("--limit", type=int, default=20)

    onchain_check = sub.add_parser("onchain-check", help="Valida Helius/EVM RPC sem webhook público")
    onchain_check.add_argument("--chain", choices=["solana", "ethereum", "bsc", "base", "arbitrum", "polygon", "avalanche", "optimism", "fantom", "cronos"], default="solana")

    onchain_once = sub.add_parser("onchain-run-once", help="Executa uma fatia cooperativa on-chain manual")
    onchain_once.add_argument("--limit", type=int, default=3)

    rep_status = sub.add_parser("reputation-status", help="Status da V14 Wallet/Deployer Reputation")
    rep_status.add_argument("--days", type=int, default=3650)

    rep_report = sub.add_parser("reputation-report", help="Relatório de reputação baseado em evidências locais")
    rep_report.add_argument("--days", type=int, default=3650)
    rep_report.add_argument("--limit", type=int, default=20)

    rep_lookup = sub.add_parser("reputation-lookup", help="Consulta reputação de uma wallet/deployer")
    rep_lookup.add_argument("--chain", required=True)
    rep_lookup.add_argument("--address", required=True)

    rep_refresh = sub.add_parser("reputation-refresh", help="Consolida evidências on-chain + resultados sem chamadas de rede")
    rep_refresh.add_argument("--days", type=int, default=3650)
    rep_refresh.add_argument("--limit", type=int, default=1000)

    ops_status = sub.add_parser("observability-status", help="Saúde operacional local V14.5")
    ops_status.add_argument("--days", type=int, default=7)

    ops_report = sub.add_parser("observability-report", help="Métricas e incidentes operacionais V14.5")
    ops_report.add_argument("--days", type=int, default=7)
    ops_report.add_argument("--limit", type=int, default=50)

    ops_incidents = sub.add_parser("observability-incidents", help="Lista incidentes operacionais")
    ops_incidents.add_argument("--open-only", action="store_true")
    ops_incidents.add_argument("--limit", type=int, default=50)

    ops_export = sub.add_parser("observability-export", help="Exporta métricas sanitizadas em JSON/Prometheus")
    dist_status = sub.add_parser("distribution-status", help="Status da V15 Distribution Platform")
    dist_status.add_argument("--days", type=int, default=7)
    dist_add = sub.add_parser("distribution-add", help="Adiciona destino outbound webhook/Discord/e-mail")
    dist_add.add_argument("--channel", choices=["webhook","discord","email"], required=True)
    dist_add.add_argument("--name", required=True)
    dist_add.add_argument("--target", default="", help="URL/e-mail; omita para prompt não-ecoado")
    dist_add.add_argument("--tenant", default="crypto-signals")
    dist_add.add_argument("--plans", default="free,plus,premium")
    dist_add.add_argument("--events", default="signal.created")
    dist_add.add_argument("--secret", default="", help="HMAC webhook opcional; omita para gerar")
    sub.add_parser("distribution-list", help="Lista destinos sem revelar URLs/segredos")
    dist_toggle = sub.add_parser("distribution-enable", help="Ativa destino por id")
    dist_toggle.add_argument("--id", type=int, required=True)
    dist_disable = sub.add_parser("distribution-disable", help="Desativa destino por id")
    dist_disable.add_argument("--id", type=int, required=True)
    dist_test = sub.add_parser("distribution-test", help="Testa um destino outbound")
    dist_test.add_argument("--id", type=int, required=True)
    dist_once = sub.add_parser("distribution-run-once", help="Processa jobs V15 agora")
    dist_once.add_argument("--limit", type=int, default=5)
    dist_jobs = sub.add_parser("distribution-jobs", help="Lista jobs/dead-letter sanitizados")
    dist_jobs.add_argument("--status", default="")
    dist_jobs.add_argument("--limit", type=int, default=50)
    dist_retry = sub.add_parser("distribution-retry", help="Recoloca job RETRY/DEAD na fila")
    dist_retry.add_argument("--job-id", type=int, required=True)
    ops_export.add_argument("--days", type=int, default=7)
    ops_export.add_argument("--format", choices=["json", "prometheus"], default="json")
    ops_export.add_argument("--output")

    proof_status = sub.add_parser("proof-status", help="Status do Proof of Performance V13")

    proof_backfill = sub.add_parser("proof-backfill", help="Hash de histórico V12 marcado explicitamente como legacy_backfill")
    proof_backfill.add_argument("--days", type=int, default=3650)

    proof_verify = sub.add_parser("proof-verify", help="Verifica hashes, cadeia e raízes do Proof of Performance")
    proof_verify.add_argument("--days", type=int, default=3650)
    proof_verify.add_argument("--signal-id", type=int)

    proof_export = sub.add_parser("proof-export", help="Gera bundle público verificável sem PII/segredos")
    proof_export.add_argument("--days", type=int, default=30)
    proof_export.add_argument("--output")

    proof_root = sub.add_parser("proof-root", help="Mostra ou sela a raiz Merkle diária")
    proof_root.add_argument("--date")
    proof_root.add_argument("--seal", action="store_true")

    proof_anchor = sub.add_parser("proof-anchor-register", help="Registra referência externa de uma raiz diária já selada")
    proof_anchor.add_argument("--date", required=True)
    proof_anchor.add_argument("--chain", required=True)
    proof_anchor.add_argument("--txid", required=True)
    proof_anchor.add_argument("--url", default="")

    saas_api = sub.add_parser("saas-api", help="Inicia API SaaS read-only autenticada")
    saas_api.add_argument("--host", default=None)
    saas_api.add_argument("--port", type=int, default=None)

    tenant_create = sub.add_parser("tenant-create", help="Cria tenant white-label local")
    tenant_create.add_argument("--name", required=True)
    tenant_create.add_argument("--slug")
    tenant_create.add_argument("--brand")
    tenant_create.add_argument("--plan", choices=["free","plus","premium","enterprise"], default="free")
    tenant_create.add_argument("--user-id", type=int)

    tenant_list = sub.add_parser("tenant-list", help="Lista tenants SaaS")

    key_create = sub.add_parser("api-key-create", help="Cria API key SaaS; chave completa aparece uma única vez")
    key_create.add_argument("--tenant", required=True)
    key_create.add_argument("--name", default="default")
    key_create.add_argument("--rpm", type=int, default=None)
    key_create.add_argument("--daily", type=int, default=None)

    key_list = sub.add_parser("api-key-list", help="Lista somente prefixos/limites das API keys")
    key_list.add_argument("--tenant")

    key_revoke = sub.add_parser("api-key-revoke", help="Revoga API key pelo prefixo público")
    key_revoke.add_argument("--prefix", required=True)

    ent_set = sub.add_parser("entitlement-set", help="Define plano/status SaaS de um tenant V16")
    ent_set.add_argument("--tenant", required=True)
    ent_set.add_argument("--plan", choices=["free","plus","premium","enterprise"], required=True)
    ent_set.add_argument("--status", choices=["ACTIVE","GRACE","SUSPENDED","EXPIRED","CANCELLED"], default="ACTIVE")
    ent_set.add_argument("--expires-at")
    ent_set.add_argument("--grace-until")

    ent_status = sub.add_parser("entitlement-status", help="Mostra entitlement e recursos liberados")
    ent_status.add_argument("--tenant", required=True)

    ent_sync = sub.add_parser("entitlement-sync", help="Sincroniza tenants vinculados com plano local/Asaas")
    ent_sync.add_argument("--tenant")

    tenant_link = sub.add_parser("tenant-link-user", help="Vincula tenant SaaS a usuário Telegram local")
    tenant_link.add_argument("--tenant", required=True)
    tenant_link.add_argument("--user-id", type=int, required=True)

    portal_info = sub.add_parser("portal-info", help="Mostra URL/configuração segura do Customer Portal V16")
    portal_info.add_argument("--tenant", default="crypto-signals")

    brand_show = sub.add_parser("brand-show", help="Mostra branding white-label ativo")

    brand_set = sub.add_parser("brand-set", help="Atualiza branding sem editar código")
    brand_set.add_argument("--product-name")
    brand_set.add_argument("--short-name")
    brand_set.add_argument("--platform-name")
    brand_set.add_argument("--telegram-title")
    brand_set.add_argument("--logo-emoji")
    brand_set.add_argument("--support-contact")
    brand_set.add_argument("--legal-disclaimer")

    sub.add_parser("adaptive-report", help="Mostra evidência disponível para CSM Confidence")
    sub.add_parser("acquisition-readiness", help="Calcula prontidão técnica/comercial para aquisição")
    sale_pack = sub.add_parser("sale-pack", help="Gera Buyer Data Room sem segredos/PII")
    sale_pack.add_argument("--output")

    reset_plan = sub.add_parser("reset-plan", help="Volta um usuário ao plano grátis")
    reset_plan.add_argument("--user-id", type=int, required=True)

    user_export = sub.add_parser("user-export", help="Exporta dados de um usuário em JSON")
    user_export.add_argument("--user-id", type=int, required=True)

    signal_test = sub.add_parser("signal-test", help="Testa o envio automático para um usuário")
    signal_test.add_argument("--user-id", type=int, required=True)

    leader_approve = sub.add_parser("leader-approve", help="Aprova proposta do Líder de Projeto")
    leader_approve.add_argument("proposal_id")
    leader_approve.add_argument("approval_code")

    leader_apply = sub.add_parser("leader-apply", help="Aplica proposta já aprovada")
    leader_apply.add_argument("proposal_id")
    leader_apply.add_argument("--eta", type=int, default=5)

    leader_bundle = sub.add_parser("leader-bundle", help="Registra pacote ZIP para auditoria")
    leader_bundle.add_argument("bundle_file")

    admin_web = sub.add_parser("admin-web", help="Inicia painel administrativo web somente leitura")
    admin_web.add_argument("--host", default=None)
    admin_web.add_argument("--port", type=int, default=None)
    admin_web.add_argument("--token", default=None)

    scan = sub.add_parser("scan")
    scan.add_argument("--limit", type=int, default=None)
    scan.add_argument("--chain", action="append", dest="chains")
    scan.add_argument("--force", action="store_true")
    return parser


def _selftest() -> int:
    _safe_print("🧪 SELFTEST v16.6.0 • Signal Outcome Learning + Runtime Resilience + Retool Admin Bridge + Daniel AI V1.3.1")
    checks: list[tuple[str, callable]] = []

    def check_imports() -> None:
        from phantom_v10.app import PhantomApp
        from phantom_v10.scanner import ScannerEngine
        from phantom_v10.telegram import TelegramClient
        from phantom_v10.runtime import RuntimeGuard
        from phantom_v10.transport import StdlibHttpTransport
        from phantom_v10.provider_diagnostics import check_birdeye, check_goplus
        from phantom_v10.goplus_security import evaluate, request_spec
        from csm.performance import PerformanceLedger, HistoricalConfidenceModel
        from csm.signal_outcome_learning import SignalOutcomeLearning
        from csm.saas import SaaSManager
        from csm.entitlements import EntitlementManager
        from csm.customer_portal import portal_page
        from csm.acquisition import acquisition_readiness
        from csm.distribution import DistributionManager
        assert EntitlementManager and portal_page and DistributionManager and PhantomApp and ScannerEngine and TelegramClient and RuntimeGuard and StdlibHttpTransport and check_birdeye and check_goplus and evaluate and request_spec and PerformanceLedger and HistoricalConfidenceModel and SignalOutcomeLearning and SaaSManager and acquisition_readiness

    def check_database() -> None:
        from csm.storage import Storage
        storage = Storage()
        try:
            result = storage.conn.execute("PRAGMA integrity_check").fetchone()[0]
            if result != "ok":
                raise RuntimeError(f"SQLite integrity_check={result}")
        finally:
            storage.close()

    def check_score() -> None:
        from csm.formatting import score_market
        sample = {"liquidity":150000,"volume24h":600000,"marketcap":1000000,"buys24h":100,"sells24h":80,"change24h":5,"age_days":10}
        if score_market(sample) < 75:
            raise AssertionError("score inesperado")

    def check_runtime() -> None:
        from phantom_v10.release import runtime_audit
        audit = runtime_audit()
        if audit["result"] != "APROVADO":
            raise RuntimeError(str(audit))

    checks.extend([
        ("Importações v10", check_imports),
        ("SQLite", check_database),
        ("Score de mercado", check_score),
        ("Runtime coerente", check_runtime),
    ])
    failures = 0
    for label, func in checks:
        try:
            func()
            _safe_print(f"✅ {label}")
        except Exception as exc:
            failures += 1
            _safe_print(f"❌ {label}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    if failures:
        _safe_print(f"❌ SELFTEST FALHOU: {failures} etapa(s)")
        return 1
    _safe_print("✅ SELFTEST OK")
    return 0

def main() -> int:
    args = build_parser().parse_args()
    if not args.cmd:
        build_parser().print_help()
        return 0

    version = _version()
    if args.cmd == "version":
        _safe_print(version)
        return 0

    if args.cmd == "post-update":
        try:
            import time as _time
            from csm.post_update import run as run_post_update

            delay = max(0.0, float(getattr(args, "delay", 0.0) or 0.0))
            if delay:
                _time.sleep(delay)
            report = run_post_update(
                restart_runtime=not bool(getattr(args, "no_runtime_restart", False)),
                restart_admin_bridge=not bool(getattr(args, "no_admin_restart", False)),
            )
            _safe_print("🔁 POST-UPDATE FINALIZER v16.6.0")
            for name, item in (report.get("steps") or {}).items():
                marker = "✅" if item.get("ok") else "❌"
                suffix = " (SKIP)" if item.get("skipped") else ""
                _safe_print(f"{marker} {name}{suffix}")
            _safe_print(f"Status final: {report.get('status')}")
            if report.get("blocked_by"):
                _safe_print(f"Bloqueado por: {report.get('blocked_by')}")
            return 0 if report.get("status") == "APPROVED" else 1
        except Exception as exc:
            return _bootstrap_error("post-update finalizer", exc)

    if args.cmd == "post-update-status":
        try:
            import json
            from csm.post_update import status as post_update_status
            _safe_print(json.dumps(post_update_status(), ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("post-update status", exc)

    # v8.2.2: recuperação segura de configuração antes de comandos operacionais.
    # Apenas preenche chaves ausentes; nunca sobrescreve valores atuais não vazios.
    if args.cmd in {"migrate", "bot"}:
        try:
            from phantom.config.recovery_v822 import recover_persistent_config
            recovery = recover_persistent_config(merge_missing=True)
            if recovery.restored_keys:
                _safe_print(f"🔐 Configuração recuperada: {len(recovery.restored_keys)} chave(s) ausente(s) restaurada(s) sem sobrescrever valores atuais.")
        except Exception as exc:
            _safe_print(f"⚠️ Recuperação automática de configuração ignorada: {type(exc).__name__}: {exc}")

    _safe_print(f"▶️ Comando: {args.cmd} | versão {version}")

    if args.cmd == "selftest":
        return _selftest()

    if args.cmd == "daniel-status":
        try:
            from daniel_ai import __version__ as daniel_version
            from daniel_ai.engine import DanielAI
            report = DanielAI().status()
            _safe_print(f"🧠 DANIEL AI V{daniel_version}")
            _safe_print(f"Estado: {'ATIVO' if report['enabled'] else 'DESATIVADO'}")
            _safe_print(f"Modo: {report['mode'].upper()}")
            _safe_print(f"OpenAI: {'ON' if report['openai_enabled'] else 'OFF'}")
            _safe_print(f"Memória: {'ON' if report['memory_enabled'] else 'OFF'}")
            _safe_print(f"Internet: {'ON' if report['web_enabled'] else 'OFF'}")
            _safe_print(f"Aprendizado: {'ON' if report.get('learning_enabled') else 'OFF'}")
            voice = report.get('voice') or {}
            _safe_print(f"Voz nativa: {'PRONTA' if voice.get('ready') else ('ON / INSTALAÇÃO PENDENTE' if voice.get('enabled') else 'OFF')}")
            speech = report.get('speech') or {}
            _safe_print(f"Resposta falada: {'PRONTA' if speech.get('ready') else ('ON / INSTALAÇÃO PENDENTE' if speech.get('enabled') else 'OFF')}")
            convo = report.get('conversational_voice') or {}
            _safe_print(f"Fala conversacional: {'ON' if convo.get('enabled') else 'OFF'} | estilo {convo.get('style','executive')} | detalhe {convo.get('detail','balanced')}")
            smart = report.get('local_llm') or {}
            _safe_print(f"Daniel Smart: {'PRONTO' if smart.get('ready') else ('ON / INSTALAÇÃO PENDENTE' if smart.get('enabled') else 'OFF')} | {smart.get('model_name','Qwen3-4B Q4_K_M')}")
            learning = report.get('learning') or {}
            _safe_print(f"Conhecimentos: {learning.get('learned_items',0)} | fila: {learning.get('pending_topics',0)} | expirados: {learning.get('expired_items',0)}")
            _safe_print(f"Admin-only: {'SIM' if report['admin_only'] else 'NÃO'}")
            _safe_print(f"Banco Daniel: {report['state_dir']}")
            _safe_print(f"Conversas: {report['counts']['conversations']} | memórias: {report['counts']['memories']}")
            _safe_print(f"Base local: {report['counts'].get('knowledge_documents',0)} documento(s) | {report['counts'].get('knowledge_chunks',0)} trecho(s)")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI status", exc)

    if args.cmd == "daniel-panel-token":
        try:
            import secrets
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or "") for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            token = secrets.token_urlsafe(24)
            values["ADMIN_WEB_TOKEN"] = token
            write_env(values)
            _safe_print("🔐 Token do painel Daniel AI criado e salvo.")
            _safe_print(f"ADMIN_WEB_TOKEN={token}")
            _safe_print(f"Config persistente: {PERSISTENT_ENV_FILE}")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI panel token", exc)

    if args.cmd in {"daniel-voice-on", "daniel-voice-off"}:
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or "") for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            enabled = args.cmd == "daniel-voice-on"
            values["DANIEL_AI_VOICE_ENABLED"] = "true" if enabled else "false"
            write_env(values)
            _safe_print(f"🎙️ Daniel AI Native Voice: {'ATIVADO' if enabled else 'DESATIVADO'}")
            _safe_print(f"Config persistente: {PERSISTENT_ENV_FILE}")
            _safe_print("Reinicie com csm-stop e csm-start para aplicar ao bot em execução.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI voice config", exc)

    if args.cmd == "daniel-voice-status":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.voice import DanielVoice
            cfg = ensure_directories(DanielSettings.from_env())
            report = DanielVoice(cfg).status()
            _safe_print("🎙️ DANIEL AI V1.1 — NATIVE VOICE")
            _safe_print(f"Estado: {'ON' if report.enabled else 'OFF'}")
            _safe_print(f"Backend: {report.backend}")
            _safe_print(f"Idioma: {report.language}")
            _safe_print(f"Pronto: {'SIM' if report.ready else 'NÃO'}")
            _safe_print(f"Modelo: {report.model_path}")
            _safe_print(f"whisper.cpp: {report.whisper_bin or 'NÃO ENCONTRADO'}")
            _safe_print(f"ffmpeg: {report.ffmpeg_bin or 'NÃO ENCONTRADO'}")
            _safe_print(f"Limite: {report.max_seconds}s | {report.max_bytes // (1024*1024)} MB")
            if report.missing:
                _safe_print("Pendente: " + ", ".join(report.missing))
                _safe_print("Instale com: bash install_voice_termux.sh")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI voice status", exc)

    if args.cmd == "daniel-speechify-setup":
        try:
            import getpass
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            key = getpass.getpass("Speechify API key (não será exibida): ").strip()
            if not key:
                _safe_print("❌ Chave vazia; nenhuma alteração feita.")
                return 2
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            values["SPEECHIFY_API_KEY"] = key
            values.setdefault("SPEECHIFY_MODEL", "simba-3.0")
            values.setdefault("SPEECHIFY_LANGUAGE", "pt-BR")
            values.setdefault("DANIEL_AI_TTS_SPEECHIFY_ENABLED", "false")
            write_env(values)
            _safe_print("✅ Speechify API key salva no config.env persistente.")
            _safe_print("Próximo: python main.py daniel-speechify-voices")
            return 0
        except Exception as exc:
            return _bootstrap_error("Speechify setup", exc)

    if args.cmd == "daniel-speechify-status":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.speechify_provider import SpeechifyProvider
            cfg = ensure_directories(DanielSettings.from_env())
            report = SpeechifyProvider(cfg).status()
            _safe_print("🎙️ SPEECHIFY NEURAL VOICE — DANIEL AI V1.3.1")
            _safe_print(f"Estado: {'ON' if report.enabled else 'OFF'}")
            _safe_print(f"Configurado: {'SIM' if report.configured else 'NÃO'}")
            _safe_print(f"Pronto: {'SIM' if report.ready else 'NÃO'}")
            _safe_print(f"Modelo: {report.model} | idioma: {report.language}")
            _safe_print(f"Voice ID: {report.voice_id or 'NÃO SELECIONADO'}")
            _safe_print("API key: " + ("CONFIGURADA" if cfg.tts_speechify_api_key else "NÃO CONFIGURADA"))
            _safe_print("Fallback automático: Edge Neural → Supertonic → Kokoro → eSpeak")
            return 0
        except Exception as exc:
            return _bootstrap_error("Speechify status", exc)

    if args.cmd == "daniel-speechify-voices":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.speechify_provider import SpeechifyProvider
            cfg = ensure_directories(DanielSettings.from_env())
            provider = SpeechifyProvider(cfg)
            rows = provider.list_voices(locale="pt-BR", limit=50)
            _safe_print("🎧 VOZES SPEECHIFY PT-BR")
            if not rows:
                _safe_print("Nenhuma voz PT-BR retornada pela API.")
                return 1
            for row in rows:
                voice_id = str(row.get("id") or row.get("voice_id") or "").strip()
                name = str(row.get("display_name") or row.get("name") or voice_id).strip()
                locale = str(row.get("locale") or row.get("language") or "pt-BR").strip()
                if voice_id:
                    _safe_print(f"- {name} | {locale} | {voice_id}")
            _safe_print("Escolha com: python main.py daniel-speechify-use VOICE_ID")
            return 0
        except Exception as exc:
            return _bootstrap_error("Speechify voices", exc)

    if args.cmd == "daniel-speechify-use":
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            voice_id = str(args.voice_id or "").strip()
            if not voice_id or len(voice_id) > 200:
                _safe_print("❌ Voice ID inválido.")
                return 2
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            values["SPEECHIFY_VOICE_ID"] = voice_id
            values["SPEECHIFY_MODEL"] = values.get("SPEECHIFY_MODEL") or "simba-3.0"
            values["SPEECHIFY_LANGUAGE"] = values.get("SPEECHIFY_LANGUAGE") or "pt-BR"
            values["DANIEL_AI_TTS_SPEECHIFY_ENABLED"] = "true"
            values["DANIEL_AI_TTS_ENABLED"] = "true"
            values["DANIEL_AI_TTS_ENGINE"] = "auto"
            write_env(values)
            _safe_print("✅ Speechify ativada como primeira voz do modo automático.")
            _safe_print("Voice ID: " + voice_id)
            _safe_print("Fallback preservado: Edge Neural → Supertonic → Kokoro → eSpeak")
            _safe_print("Reinicie com: csm-stop && csm-start")
            return 0
        except Exception as exc:
            return _bootstrap_error("Speechify voice selection", exc)

    if args.cmd == "daniel-speechify-test":
        try:
            import shutil
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.tts import DanielSpeech
            cfg = ensure_directories(DanielSettings.from_env())
            speech = DanielSpeech(cfg)
            generated = speech.synthesize(
                "Olá. Eu sou o Daniel. Este é um teste da voz neural Speechify em português brasileiro.",
                engine="speechify",
            )
            target_dir = cfg.voice_dir / "tests"
            target_dir.mkdir(parents=True, exist_ok=True)
            target = target_dir / "daniel_speechify_test.ogg"
            shutil.copy2(generated, target)
            generated.unlink(missing_ok=True)
            _safe_print("✅ Teste Speechify gerado com sucesso.")
            _safe_print(f"Arquivo: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("Speechify test", exc)

    if args.cmd == "retool-token":
        try:
            import secrets
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            token = str(values.get("ADMIN_WEB_TOKEN") or "").strip()
            created = False
            if not token:
                token = secrets.token_urlsafe(36)
                values["ADMIN_WEB_TOKEN"] = token
                values["ADMIN_WEB_ENABLED"] = "true"
                write_env(values)
                created = True
            _safe_print("🔐 Token da API administrativa " + ("criado" if created else "já existente") + ".")
            _safe_print("Copie este valor apenas para o Resource do Retool:")
            _safe_print(token)
            _safe_print("Não envie esse token por Telegram/chat e não coloque no ZIP.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Retool admin token", exc)

    if args.cmd in {"retool-admin-start", "retool-admin-stop", "retool-admin-status"}:
        try:
            from csm.retool_server import start as retool_start, stop as retool_stop, status as retool_status
            if args.cmd == "retool-admin-start":
                result = retool_start()
            elif args.cmd == "retool-admin-stop":
                result = retool_stop()
            else:
                result = {"ok": True, **retool_status()}
            _safe_print("🌐 RETOOL ADMIN BRIDGE")
            _safe_print(f"Estado: {'ON' if result.get('running') else 'OFF'}")
            _safe_print(f"PID: {result.get('pid') or '—'}")
            _safe_print(f"Local: http://127.0.0.1:{result.get('port') or 8765}")
            _safe_print(f"Protegido: {'SIM' if result.get('protected') else 'NÃO'}")
            _safe_print(f"Log: {result.get('log') or '—'}")
            return 0 if result.get("ok", True) else 1
        except Exception as exc:
            return _bootstrap_error("Retool Admin Bridge", exc)

    if args.cmd == "daniel-speech-use":
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            voices = {
                "antonio": "pt-BR-AntonioNeural",
                "fabio": "pt-BR-FabioNeural",
                "humberto": "pt-BR-HumbertoNeural",
                "francisca": "pt-BR-FranciscaNeural",
            }
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            values["DANIEL_AI_TTS_ENABLED"] = "true"
            values["DANIEL_AI_TTS_ENGINE"] = "edge"
            values["DANIEL_AI_TTS_EDGE_VOICE"] = voices[args.voice]
            write_env(values)
            _safe_print("🗣️ Voz natural selecionada: " + voices[args.voice])
            _safe_print("Reinicie com: csm-stop && csm-start")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI natural speech voice", exc)

    if args.cmd in {"daniel-speech-on", "daniel-speech-off"}:
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            enabled = args.cmd == "daniel-speech-on"
            values["DANIEL_AI_TTS_ENABLED"] = "true" if enabled else "false"
            write_env(values)
            _safe_print("Daniel AI resposta falada: " + ("ON" if enabled else "OFF"))
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI speech config", exc)

    if args.cmd == "daniel-speech-status":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.tts import DanielSpeech
            cfg = ensure_directories(DanielSettings.from_env())
            report = DanielSpeech(cfg).status()
            _safe_print("🔊 DANIEL AI V1.3.1 — SPEECHIFY + NATURAL NEURAL FALLBACKS")
            _safe_print(f"Estado: {'ON' if report.enabled else 'OFF'}")
            _safe_print(f"Pronto: {'SIM' if report.ready else 'NÃO'}")
            _safe_print(f"Neural pronto: {'SIM' if report.neural_ready else 'NÃO'}")
            _safe_print(f"Motor selecionado: {report.selected_engine}")
            _safe_print(f"Backend: {report.backend}")
            _safe_print(f"Voz ativa: {report.voice}")
            _safe_print(f"Speechify: {'PRONTA' if report.speechify_configured else 'NÃO CONFIGURADA'} | voice {report.speechify_voice_id or '—'} | model {report.speechify_model or '—'}")
            _safe_print(f"Microsoft Edge Neural: {report.edge_bin or 'NÃO INSTALADO'} | voz {report.edge_voice}")
            _safe_print("Motores disponíveis: " + (", ".join(report.available_engines) or "nenhum"))
            _safe_print(f"Supertonic: {report.supertonic_bin or 'NÃO ENCONTRADO'} | voz {report.supertonic_voice}")
            _safe_print(f"Kokoro: {report.kokoro_model_path} | voz {report.kokoro_voice}")
            _safe_print(f"eSpeak fallback: {report.espeak_bin or 'NÃO ENCONTRADO'}")
            _safe_print(f"ffmpeg: {report.ffmpeg_bin or 'NÃO ENCONTRADO'}")
            if report.missing:
                _safe_print("Faltando: " + ", ".join(report.missing))
                _safe_print("Instale com: bash install_natural_voice_termux.sh")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI speech status", exc)

    if args.cmd == "daniel-speech-test":
        try:
            import shutil
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.tts import DanielSpeech
            cfg = ensure_directories(DanielSettings.from_env())
            speech = DanielSpeech(cfg)
            report = speech.status()
            _safe_print("🔊 Teste Natural Neural Voice")
            _safe_print(f"Motor: {report.selected_engine} | voz: {report.voice}")
            generated = speech.synthesize("Olá. Eu sou o Daniel. Esta é a minha nova voz em português brasileiro, com uma fala mais natural.", engine=report.selected_engine)
            target_dir = cfg.voice_dir / "tests"
            target_dir.mkdir(parents=True, exist_ok=True)
            target = target_dir / "daniel_natural_voice_test.ogg"
            shutil.copy2(generated, target)
            generated.unlink(missing_ok=True)
            _safe_print("✅ Áudio gerado com sucesso.")
            _safe_print(f"Arquivo: {target}")
            _safe_print("No Termux: termux-media-player play "" + str(target) + """)
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI natural speech test", exc)

    if args.cmd == "daniel-speech-compare":
        try:
            import shutil
            from dataclasses import replace
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.tts import DanielSpeech
            cfg = ensure_directories(DanielSettings.from_env())
            presets = [
                ("antonio", "pt-BR-AntonioNeural"),
                ("fabio", "pt-BR-FabioNeural"),
                ("humberto", "pt-BR-HumbertoNeural"),
            ]
            target_dir = cfg.voice_dir / "tests"
            target_dir.mkdir(parents=True, exist_ok=True)
            _safe_print("🎧 COMPARAÇÃO DE VOZES PT-BR — V1.2.3")
            for short, voice in presets:
                voice_cfg = replace(cfg, tts_engine="edge", tts_edge_voice=voice)
                speech = DanielSpeech(voice_cfg)
                generated = speech.synthesize(
                    "Olá. Eu sou o Daniel. Estou testando uma voz mais natural para conversar com você pelo Telegram.",
                    engine="edge",
                )
                target = target_dir / f"daniel_{short}.ogg"
                shutil.copy2(generated, target)
                generated.unlink(missing_ok=True)
                _safe_print(f"✅ {short}: {target}")
            _safe_print("Ouça os três arquivos e escolha com: python main.py daniel-speech-use antonio")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI speech compare", exc)

    if args.cmd in {"daniel-conversational-voice-on", "daniel-conversational-voice-off"}:
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            enabled = args.cmd == "daniel-conversational-voice-on"
            values["DANIEL_AI_CONVERSATIONAL_VOICE_ENABLED"] = "true" if enabled else "false"
            write_env(values)
            _safe_print("🗣️ Conversational Voice Intelligence: " + ("ON" if enabled else "OFF"))
            _safe_print("Reinicie com: csm-stop && csm-start")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI conversational voice config", exc)

    if args.cmd == "daniel-conversational-voice-status":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.conversational_voice import ConversationalVoice
            cfg = ensure_directories(DanielSettings.from_env())
            report = ConversationalVoice(cfg).status()
            _safe_print("🧠 DANIEL AI V1.2.4 — ADAPTIVE CONVERSATIONAL VOICE")
            _safe_print(f"Estado: {'ON' if report.enabled else 'OFF'}")
            _safe_print(f"Modo: {report.style}")
            _safe_print("Perfis automáticos: " + " | ".join(report.profiles))
            _safe_print(f"Detalhe: {report.detail}")
            _safe_print(f"Máximo falado: {report.max_chars} caracteres")
            _safe_print("Estrutura: " + " → ".join(report.structure))
            _safe_print(f"Explicador de comandos: {'ON' if report.command_explainer else 'OFF'}")
            _safe_print(f"Variação natural: {'ON' if report.natural_variation else 'OFF'}")
            _safe_print("Texto Telegram: técnico/completo | Áudio: conversa adaptativa")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI conversational voice status", exc)

    if args.cmd == "daniel-conversational-voice-test":
        try:
            import shutil
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.conversational_voice import ConversationalVoice
            from daniel_ai.tts import DanielSpeech
            cfg = ensure_directories(DanielSettings.from_env())
            cases = [
                (
                    "executivo",
                    "Daniel, me dê um resumo do status operacional",
                    "🧠 <b>Daniel AI V1.2.4 — Operational Copilot</b>\n"
                    "🌐 Providers: <b>94/100</b>\n"
                    "🔎 Scanner 24h: analisados <b>128</b> • aprovados <b>14</b> • taxa <b>10.9%</b>\n"
                    "🚫 Principal rejeição: <b>liquidez insuficiente</b> (31)\n"
                    "📈 Lifecycle: ativos <b>8</b> • deteriorando <b>2</b> • TP3 <b>3</b> • stops <b>1</b>",
                ),
                (
                    "analista",
                    "Daniel, analise o token CATE",
                    "🧠 <b>Daniel AI V1.2.4 — análise local</b>\n"
                    "🔎 <b>CATE</b> • SOLANA\n"
                    "Score final: <b>82/100</b>\n"
                    "💧 Liquidez: <b>$180.0K</b> • Vol24h: <b>$640.0K</b>\n"
                    "🟢 Pressão compradora 24h: <b>64.0%</b>\n"
                    "🛡️ GoPlus: risco <b>LOW</b>\n"
                    "🧭 Lifecycle: <b>ACTIVE</b>",
                ),
                (
                    "explicativo",
                    "Daniel, me explica como faço a atualização com esses comandos",
                    "1) csm-stop\n2) cd ~/storage/downloads\n3) unzip -o pacote.zip\n"
                    "4) bash install_termux.sh\n5) python main.py migrate\n6) python main.py selftest\n"
                    "7) csm-start\n8) csm-status",
                ),
            ]
            voice = ConversationalVoice(cfg)
            speech = DanielSpeech(cfg)
            target_dir = cfg.voice_dir / "tests"
            target_dir.mkdir(parents=True, exist_ok=True)
            _safe_print("📝 O texto técnico continua completo no Telegram.")
            for label, question, technical in cases:
                selected = voice.select_profile(question, technical)
                spoken = voice.render(question, technical)
                _safe_print(f"\n🗣️ PERFIL {label.upper()} (selecionado: {selected}):\n{spoken}")
                if speech.status().ready:
                    generated = speech.synthesize(spoken)
                    target = target_dir / f"daniel_adaptive_{label}.ogg"
                    shutil.copy2(generated, target)
                    generated.unlink(missing_ok=True)
                    _safe_print(f"✅ Áudio: {target}")
            if not speech.status().ready:
                _safe_print("⚠️ TTS não está pronto; os três roteiros adaptativos foram validados em texto.")
            else:
                _safe_print("\n✅ Três estilos adaptativos gerados para comparação.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI conversational voice test", exc)

    if args.cmd in {"daniel-smart-on", "daniel-smart-off"}:
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or '') for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            enabled = args.cmd == "daniel-smart-on"
            values["DANIEL_LOCAL_LLM_ENABLED"] = "true" if enabled else "false"
            values.setdefault("DANIEL_LOCAL_LLM_MODE", "smart")
            write_env(values)
            _safe_print("🧠 Daniel Smart local: " + ("ON" if enabled else "OFF"))
            _safe_print("Reinicie com: csm-stop && csm-start")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel Smart config", exc)

    if args.cmd == "daniel-smart-status":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.local_llm import DanielLocalLLM
            cfg = ensure_directories(DanielSettings.from_env())
            st = DanielLocalLLM(cfg).status()
            _safe_print("🧠 DANIEL AI V1.3.0 — DANIEL SMART / LOCAL GENERATIVE BRAIN")
            _safe_print(f"Estado: {'ON' if st.enabled else 'OFF'}")
            _safe_print(f"Pronto: {'SIM' if st.ready else 'NÃO'}")
            _safe_print(f"Modo: {st.mode}")
            _safe_print(f"Backend: {st.backend}")
            _safe_print(f"Modelo: {st.model_name}")
            _safe_print(f"Contexto: {st.context_size} tokens | saída máx.: {st.max_tokens} tokens | threads: {st.threads}")
            _safe_print(f"Modelo GGUF: {st.model_path}")
            _safe_print(f"llama-cli: {st.llama_bin or 'AUSENTE'}")
            if st.missing:
                _safe_print("Pendente: " + ", ".join(st.missing))
            _safe_print("OpenAI não é necessária para este modo.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel Smart status", exc)

    if args.cmd == "daniel-smart-test":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.local_llm import DanielLocalLLM
            cfg = ensure_directories(DanielSettings.from_env())
            llm = DanielLocalLLM(cfg)
            _safe_print("🧠 Testando resposta generativa local...")
            answer = llm.generate(
                "Explique em português brasileiro, de forma natural e em até três frases, por que liquidez é importante ao analisar um token.",
                history=[],
                max_tokens=120,
            )
            _safe_print(answer)
            _safe_print("✅ Daniel Smart respondeu localmente.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel Smart test", exc)

    if args.cmd == "daniel-smart-benchmark":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.local_llm import DanielLocalLLM
            cfg = ensure_directories(DanielSettings.from_env())
            report = DanielLocalLLM(cfg).benchmark()
            _safe_print("📊 DANIEL SMART — BENCHMARK LOCAL")
            _safe_print(f"Modelo: {report['model']}")
            _safe_print(f"Tempo total: {report['elapsed_seconds']}s")
            _safe_print(f"Caracteres gerados: {report['characters']}")
            _safe_print("Resposta: " + report['answer'])
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel Smart benchmark", exc)

    if args.cmd == "daniel-voice-transcribe":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.voice import DanielVoice
            cfg = ensure_directories(DanielSettings.from_env())
            transcript = DanielVoice(cfg).transcribe(args.audio_file)
            _safe_print("🎙️ TRANSCRIÇÃO LOCAL")
            _safe_print(transcript)
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI voice transcribe", exc)

    if args.cmd in {"daniel-learning-on", "daniel-learning-off"}:
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or "") for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            enabled = args.cmd == "daniel-learning-on"
            values["DANIEL_AI_LEARNING_ENABLED"] = "true" if enabled else "false"
            write_env(values)
            _safe_print(f"🧠 Daniel AI Continuous Learning: {'ATIVADO' if enabled else 'DESATIVADO'}")
            _safe_print(f"Config persistente: {PERSISTENT_ENV_FILE}")
            _safe_print("Reinicie com csm-stop e csm-start para aplicar ao bot em execução.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI learning config", exc)

    if args.cmd == "daniel-learning-status":
        try:
            from daniel_ai.engine import DanielAI
            report = DanielAI().status()
            learning = report.get("learning") or {}
            _safe_print("🧠 DANIEL AI — CONTINUOUS LEARNING")
            _safe_print(f"Estado: {'ON' if report.get('learning_enabled') else 'OFF'}")
            _safe_print(f"Web: {'ON' if report.get('web_enabled') else 'OFF'}")
            _safe_print(f"Conhecimentos: {learning.get('learned_items',0)}")
            _safe_print(f"Fila: {learning.get('pending_topics',0)} | expirados: {learning.get('expired_items',0)}")
            if learning.get('last_topic'):
                _safe_print(f"Último: {learning.get('last_topic')} | confiança {learning.get('last_confidence',0)}% | {learning.get('last_learned_at','')}")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI learning status", exc)

    if args.cmd == "daniel-learning-run":
        try:
            import sqlite3
            from csm.config import settings as csm_settings
            from daniel_ai.learning import AutoLearner
            learner = AutoLearner()
            local = {"ok": False, "reason": "csm_db_missing"}
            if csm_settings.db_file.exists():
                uri = f"file:{csm_settings.db_file.resolve().as_posix()}?mode=ro"
                conn = sqlite3.connect(uri, uri=True, timeout=5)
                conn.row_factory = sqlite3.Row
                try:
                    local = learner.learn_csm_outcomes(conn, days=30)
                finally:
                    conn.close()
            web_result = learner.step()
            _safe_print("🧠 Ciclo de aprendizado V1.0 executado.")
            _safe_print("[CSM outcomes]")
            for key, value in local.items():
                _safe_print(f"{key}: {value}")
            _safe_print("[Web/topic queue]")
            for key, value in web_result.items():
                _safe_print(f"{key}: {value}")
            # A falta temporária de web/amostra não torna o comando inválido.
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI learning run", exc)

    if args.cmd in {"daniel-web-on", "daniel-web-off"}:
        try:
            from dotenv import dotenv_values
            from csm.setup_wizard import PERSISTENT_ENV_FILE, write_env
            values = {str(k): str(v or "") for k, v in dotenv_values(PERSISTENT_ENV_FILE).items()} if PERSISTENT_ENV_FILE.exists() else {}
            enabled = args.cmd == "daniel-web-on"
            values["DANIEL_AI_WEB_ENABLED"] = "true" if enabled else "false"
            # OpenAI remains untouched; web access is an independent, free/opt-in layer.
            write_env(values)
            _safe_print(f"🌐 Daniel AI Web: {'ATIVADO' if enabled else 'DESATIVADO'}")
            _safe_print(f"Config persistente: {PERSISTENT_ENV_FILE}")
            _safe_print("Reinicie com csm-stop e csm-start para aplicar ao bot em execução.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI web config", exc)

    if args.cmd == "daniel-tools":
        try:
            from daniel_ai.engine import DanielAI
            ai = DanielAI()
            _safe_print("🧰 DANIEL AI — FERRAMENTAS READ-ONLY")
            for name in ai.tools.names():
                _safe_print(f"- {name}")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI tools", exc)

    if args.cmd == "daniel-history":
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            from daniel_ai.memory import DanielMemory
            cfg = ensure_directories(DanielSettings.from_env())
            with DanielMemory(cfg.db_file) as mem:
                rows = mem.history(0, limit=20)
            _safe_print("🧠 DANIEL AI — HISTÓRICO LOCAL")
            if not rows:
                _safe_print("Sem conversas ainda.")
            for row in rows:
                content = str(row.get("content") or "").replace("\n", " ")
                _safe_print(f"[{row.get('created_at')}] {row.get('role')}: {content[:220]}")
            return 0
        except Exception as exc:
            return _bootstrap_error("Daniel AI history", exc)

    if args.cmd == "daniel-ask":
        try:
            from daniel_ai.engine import DanielAI
            question = " ".join(args.question).strip()
            if not question:
                question = input("Daniel AI > ").strip()
            _safe_print(DanielAI().ask(question, user_id=0, source="cli"))
            return 0
        except (EOFError, KeyboardInterrupt):
            _safe_print("Cancelado.")
            return 130
        except Exception as exc:
            return _bootstrap_error("Daniel AI ask", exc)

    if args.cmd == "ui-audit":
        try:
            from phantom_v10.release import ui_audit
            report=ui_audit(); _safe_print("🧭 UI AUDIT v16.0.0")
            _safe_print(f"Rotas de callback: {report['callback_routes']}"); _safe_print(f"Botões de teclado: {report['reply_buttons']}")
            _safe_print(f"Callbacks sem rota: {len(report['missing_callbacks'])}"); _safe_print(f"Botões sem handler: {len(report['missing_reply_handlers'])}")
            _safe_print(f"Resultado: {report['result']}"); return 0 if report['result']=='APROVADO' else 1
        except Exception as exc: return _bootstrap_error("auditoria de UI v10",exc)

    if args.cmd == "config-recover":
        try:
            from phantom.config.recovery_v822 import recover_persistent_config
            report = recover_persistent_config(merge_missing=True)
            _safe_print("🔐 CONFIG RECOVERY v8.2.2")
            _safe_print(f"Ação: {report.action}")
            _safe_print(f"Origem: {report.source or 'nenhuma'}")
            _safe_print(f"Destino: {report.destination}")
            _safe_print(f"Chaves restauradas: {len(report.restored_keys)}")
            if report.restored_keys:
                _safe_print("Restauradas: " + ", ".join(report.restored_keys))
            _safe_print(f"Chaves atuais preservadas: {len(report.kept_keys)}")
            for warning in report.warnings:
                _safe_print(f"⚠️ {warning}")
            return 0
        except Exception as exc:
            return _bootstrap_error("recuperação de configuração", exc)

    if args.cmd == "foundation-audit":
        try:
            from csm.config import settings
            from phantom.architecture.dependencies import audit_architecture, save_architecture_audit
            report = audit_architecture(settings.base_dir)
            target = save_architecture_audit(settings.base_dir, settings.data_dir / "reports" / "foundation_architecture.json")
            _safe_print("🏗️ FOUNDATION • AUDITORIA DE ARQUITETURA")
            _safe_print(f"Módulos: {len(report.modules)}")
            _safe_print(f"Módulos grandes: {len(report.oversized_modules)}")
            _safe_print(f"Candidatos à limpeza: {len(report.cleanup_candidates)}")
            _safe_print("Nenhum arquivo foi removido automaticamente.")
            _safe_print(f"Relatório: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("auditoria Foundation", exc)

    if args.cmd == "foundation-health":
        try:
            from phantom.monitoring.health import build_foundation_health, save_foundation_health
            report = build_foundation_health(); target = save_foundation_health()
            _safe_print("💚 FOUNDATION • HEALTH ENGINE")
            _safe_print(f"Uptime do processo: {report.uptime_seconds}s | PID: {report.process_id}")
            _safe_print(f"Memória máxima registrada: {report.memory_max_rss}")
            _safe_print(f"Configuração: {'OK' if not report.configuration_errors else '; '.join(report.configuration_errors)}")
            _safe_print(f"Último backup: {report.latest_backup or 'não localizado'}")
            _safe_print(f"Relatório: {target}")
            return 0 if not report.configuration_errors else 1
        except Exception as exc:
            return _bootstrap_error("Health Engine Foundation", exc)

    if args.cmd == "plugins-status":
        try:
            from csm.config import settings
            from phantom.plugins.loader import discover_manifests
            manifests = discover_manifests(settings.base_dir / "plugins")
            _safe_print("🧩 FOUNDATION • PLUGIN FRAMEWORK")
            _safe_print(f"Manifestos encontrados: {len(manifests)}")
            for path in manifests:
                _safe_print(f"- {path.relative_to(settings.base_dir)}")
            if not manifests:
                _safe_print("Base pronta; nenhum plugin funcional habilitado nesta sprint.")
            return 0
        except Exception as exc:
            return _bootstrap_error("status dos plugins", exc)

    if args.cmd == "release-tests":
        try:
            import pytest
            from phantom_v10.release import write_test_receipt
            rc=pytest.main(["-q"]); target=write_test_receipt(int(rc),"pytest in-process")
            _safe_print(f"🧪 RELEASE TESTS v10: {'APROVADO' if int(rc)==0 else 'BLOQUEADO'}"); _safe_print(f"Recibo: {target}"); return int(rc)
        except Exception as exc: return _bootstrap_error("testes de release v10",exc)

    if args.cmd == "foundation-release":
        try:
            from phantom_v10.release import release_check
            r=release_check(); _safe_print("🚦 PHANTOM v10 • RELEASE ENGINE")
            _safe_print(f"✅ LTS: {r['lts']}"); _safe_print(f"{'✅' if r['database'].get('integrity')=='ok' else '❌'} Banco: {r['database'].get('integrity')} | schema={r.get('schema')}")
            _safe_print(f"{'✅' if r['tests_ok'] else '❌'} Testes: {'recibo válido' if r['tests_ok'] else 'rode pytest -q'}")
            _safe_print(f"{'✅' if r['ui']['result']=='APROVADO' else '❌'} UI: {r['ui']['result']}"); _safe_print(f"{'✅' if r['runtime']['result']=='APROVADO' else '❌'} Runtime: {r['runtime']['result']}")
            _safe_print(f"{'✅' if r['config_ok'] else '❌'} Configuração Telegram"); _safe_print(f"Resultado: {r['result']}"); return 0 if r['result']=='APROVADO' else 1
        except Exception as exc: return _bootstrap_error("Release Engine v10",exc)

    if args.cmd == "release-summary":
        try:
            from phantom_v10.release import release_check
            r=release_check(); _safe_print("📋 RELEASE SUMMARY v10"); _safe_print(f"Release: {r['version']} | LTS: {r['lts']}"); _safe_print(f"Banco: {r['database'].get('integrity')} | schema={r.get('schema')}")
            _safe_print(f"Testes: {'APROVADO' if r['tests_ok'] else 'PENDENTE'}"); _safe_print(f"UI: {r['ui']['result']} | Runtime: {r['runtime']['result']}"); _safe_print(f"Status final: {r['result']}"); return 0 if r['result']=='APROVADO' else 1
        except Exception as exc: return _bootstrap_error("resumo v10",exc)

    if args.cmd == "environment-status":
        try:
            from csm.config import settings
            _safe_print(f"Ambiente: {settings.app_environment}")
            _safe_print(f"Estado persistente: {settings.data_dir}")
            _safe_print(f"Banco: {settings.db_file}")
            _safe_print(f"Asaas: {settings.asaas_environment}")
            return 0
        except Exception as exc:
            return _bootstrap_error("status do ambiente", exc)

    if args.cmd == "staging-init":
        try:
            from csm.product_ops import initialize_staging
            result = initialize_staging(copy_config=False)
            _safe_print("✅ Ambiente de homologação criado sem banco nem segredos de produção.")
            for key, value in result.items():
                _safe_print(f"{key}: {value}")
            _safe_print("Use: sh run_staging.sh setup")
            return 0
        except Exception as exc:
            return _bootstrap_error("criação do staging", exc)

    if args.cmd == "lts-status":
        _safe_print("🔒 LTS BASE CONGELADA")
        _safe_print("Base: 6.3.0")
        _safe_print("Release de produto: 16.0.0 Customer Portal + Entitlements + Distribution + Observability + Reputation + On-Chain + Verified Performance")
        _safe_print("LTS preservada; runtime ativo v10 com HTTPS stdlib sequencial, scanner cooperativo e parada segura.")
        return 0


    if args.cmd == "intelligence-report":
        try:
            from csm.config import settings
            from csm.storage import Storage
            storage = Storage()
            try:
                users = int(storage.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0])
                active = int(storage.conn.execute("SELECT COUNT(*) FROM users WHERE plan != 'free' AND blocked=0").fetchone()[0])
                profiles_path = settings.data_dir / "user_profiles.json"
                _safe_print("🧠 CENTRO DE INTELIGÊNCIA • RELATÓRIO")
                _safe_print(f"Usuários: {users} | assinantes ativos: {active}")
                _safe_print(f"Perfis persistentes: {profiles_path}")
                _safe_print("Preferências: redes, risco, detalhe, silêncio, idioma e frequência")
                return 0
            finally:
                storage.close()
        except Exception as exc:
            return _bootstrap_error("relatório do centro de inteligência", exc)


    if args.cmd == "platform-dashboard":
        try:
            from csm.platform_ops import platform_dashboard, save_platform_dashboard
            data = platform_dashboard(); target = save_platform_dashboard()
            admin = data["admin"]; health = data["health"]
            _safe_print("🏛️ PHANTOM ALERT • PLATFORM CENTER")
            _safe_print(f"Release: {data.get('product_release', data['release'])} | LTS: {data['lts_base']} | status: {data['status']}")
            _safe_print(f"Usuários: {admin.get('users', 0)} | assinantes: {admin.get('active_subscribers', 0)} | pagamentos: {admin.get('payments', 0)}")
            _safe_print(f"Scanner: ciclos={health['scanner'].get('cycles_today', 0)} | sinais={health['scanner'].get('signals_today', 0)}")
            _safe_print(f"Project Leader: saúde={data['leader'].get('health_score', 0)}/100 | alertas={len(data['alerts'])}")
            _safe_print(f"Relatório: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("platform dashboard", exc)

    if args.cmd == "leader-simulate":
        try:
            from csm.platform_ops import leader_simulation, save_leader_simulation
            result = leader_simulation(); target = save_leader_simulation()
            _safe_print("🤖 PROJECT LEADER 3.0 • SIMULAÇÃO")
            _safe_print(f"Saúde: {result['health_score']}/100 | achados: {result['findings']}")
            for step in result['steps'][:10]:
                _safe_print(f"{step['order']}. [{step['severity']}] {step['title']} -> {step['proposed_action'] or 'somente diagnóstico'}")
            _safe_print("✅ Nenhuma alteração foi aplicada.")
            _safe_print(f"Relatório: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("simulação do Project Leader", exc)

    if args.cmd == "ops-alerts":
        try:
            from csm.platform_ops import operational_alerts, save_operational_alerts
            alerts = operational_alerts(); target = save_operational_alerts()
            _safe_print("🚨 ALERTAS OPERACIONAIS")
            if not alerts:
                _safe_print("✅ Nenhum alerta operacional ativo.")
            for item in alerts:
                _safe_print(f"[{item.severity.upper()}] {item.title}: {item.details}")
                _safe_print(f"Ação: {item.recommended_action}")
            _safe_print(f"Relatório: {target}")
            return 0 if not any(item.severity in {'critical','high'} for item in alerts) else 1
        except Exception as exc:
            return _bootstrap_error("alertas operacionais", exc)

    if args.cmd == "production-readiness":
        try:
            from csm.platform_ops import production_readiness, save_production_readiness
            result = production_readiness(); target = save_production_readiness()
            _safe_print("🚀 PRODUCTION READINESS")
            _safe_print(f"Decisão: {result['decision']} | release={result.get('product_release', result['release'])} | LTS={result['lts_base']}")
            _safe_print(f"Quality Gate: {'OK' if result['quality_gate']['passed'] else 'FALHOU'}")
            _safe_print(f"Alertas críticos/altos: {len(result['critical_alerts'])}")
            _safe_print(f"Restore dry-run: {'OK' if result['restore_dry_run'].get('valid') else 'FALHOU'}")
            _safe_print(f"Relatório: {target}")
            return 0 if result['ready'] else 1
        except Exception as exc:
            return _bootstrap_error("production readiness", exc)

    if args.cmd == "platform-lines":
        try:
            from csm.platform_lines import platform_lines
            _safe_print("🏗️ LINHAS DA PLATAFORMA")
            for item in platform_lines():
                lock = "🔒" if item["frozen"] else "🟢"
                _safe_print(f"{lock} {item['name']}: {item['status']} — {item['responsibility']}")
            return 0
        except Exception as exc:
            return _bootstrap_error("linhas da plataforma", exc)

    if args.cmd == "enterprise-dashboard":
        try:
            from csm.enterprise_ops import enterprise_snapshot, save_enterprise_snapshot
            data = enterprise_snapshot(); target = save_enterprise_snapshot()
            plans = data.get("plans", {})
            _safe_print("🏢 PHANTOM ALERT • ENTERPRISE CENTER")
            _safe_print(f"Release: {data.get('product_release', data['release'])} | LTS: {data['lts_base']} | ambiente: {data['environment']}")
            _safe_print(f"Usuários: {data['users_total']} | Plus: {plans.get('plus',0)+plans.get('plus_annual',0)} | Premium: {plans.get('premium',0)+plans.get('premium_annual',0)}")
            _safe_print(f"Renovações em 30 dias: {len(data['renewals_next_30_days'])} | sinais abertos: {data['signals_open']} | favoritos: {data['favorites']}")
            saas = data.get("saas", {})
            _safe_print(f"SaaS tenants: {saas.get('tenant_count',0)} | entitlements ativos: {saas.get('active_entitlements',0)} | requests hoje: {saas.get('requests_today',0)}")
            _safe_print(f"Customer Portal: {'ON' if saas.get('portal_enabled') else 'OFF'} | Enterprise: {'ON' if saas.get('enterprise_dashboard_enabled') else 'OFF'}")
            _safe_print(f"Relatório: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("enterprise dashboard", exc)

    if args.cmd == "audit-events":
        try:
            from csm.audit_log import recent_events
            events = recent_events(50)
            _safe_print("🧾 EVENTOS DE AUDITORIA")
            if not events:
                _safe_print("Nenhum evento registrado.")
            for item in events:
                _safe_print(f"{item.get('created_at','')} [{str(item.get('severity','info')).upper()}] {item.get('category','system')} • {item.get('event','')}")
            return 0
        except Exception as exc:
            return _bootstrap_error("eventos de auditoria", exc)

    if args.cmd == "daniel-panel":
        try:
            from csm.admin_web import serve_admin_web
            from csm.config import settings
            host = args.host or settings.admin_web_host
            port = args.port or settings.admin_web_port
            token = settings.admin_web_token if args.token is None else args.token
            suffix = f"?token={token}" if token else ""
            _safe_print(f"🧠 Daniel AI Panel: http://{host}:{port}/daniel-ai{suffix}")
            _safe_print("Painel administrativo local. Ctrl+C para encerrar.")
            serve_admin_web(host, port, token)
            return 0
        except KeyboardInterrupt:
            _safe_print("✅ Painel Daniel AI encerrado.")
            return 0
        except Exception as exc:
            return _bootstrap_error("painel Daniel AI", exc)

    if args.cmd == "admin-web":
        try:
            from csm.admin_web import serve_admin_web
            from csm.config import settings
            host = args.host or settings.admin_web_host
            port = args.port or settings.admin_web_port
            token = settings.admin_web_token if args.token is None else args.token
            _safe_print(f"🌐 Painel administrativo: http://{host}:{port}")
            _safe_print("API protegida para Retool + painel local. Ctrl+C para encerrar.")
            serve_admin_web(host, port, token)
            return 0
        except KeyboardInterrupt:
            _safe_print("✅ Painel administrativo encerrado.")
            return 0
        except Exception as exc:
            return _bootstrap_error("painel administrativo web", exc)

    if args.cmd == "release-info":
        try:
            from csm.release_ops import release_info
            info = release_info()
            _safe_print("📦 VERSIONAMENTO E GOVERNANÇA")
            _safe_print(f"Release: {info.get('product_release', info['release'])} | compat: {info['release']} | linha: {info['release_line']} | LTS: {info['lts_base']}")
            _safe_print(info['policy'])
            return 0
        except Exception as exc:
            return _bootstrap_error("informações de release", exc)

    if args.cmd == "health-dashboard":
        try:
            from csm.release_ops import health_dashboard, save_health_dashboard
            data = health_dashboard(); target = save_health_dashboard()
            db = data['database']; scanner = data['scanner']; integrations = data['integrations']
            _safe_print("🩺 PHANTOM ALERT • HEALTH DASHBOARD")
            _safe_print(f"Release: {data.get('product_release', data['release'])} | LTS: {data['lts_base']} | ambiente: {data['environment']}")
            _safe_print(f"Banco: {db['integrity']} | usuários={db['users']} | assinantes={db['active_subscribers']} | pagamentos={db['payments']}")
            _safe_print(f"Telegram={'OK' if integrations['telegram_configured'] else 'PENDENTE'} | Asaas={'OK' if integrations['asaas_configured'] else 'PENDENTE'}")
            _safe_print(f"Scanner={'ON' if scanner['enabled'] else 'OFF'} | ciclos={scanner['cycles_today']} | sinais={scanner['signals_today']} | último={scanner['last_cycle'] or 'nenhum'}")
            latest = data.get('latest_backup')
            _safe_print(f"Backup: {latest.get('path') if latest else 'não localizado'}")
            _safe_print(f"Relatório: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("health dashboard", exc)

    if args.cmd == "restore-dry-run":
        try:
            from csm.release_ops import restore_dry_run
            result = restore_dry_run()
            _safe_print("🧪 RESTORE DRY-RUN")
            _safe_print(f"Backup: {result['backup']}")
            _safe_print(f"Válido: {'sim' if result['valid'] else 'não'} | assinado: {'sim' if result['signed'] else 'não'}")
            _safe_print(f"Banco: {'sim' if result['has_database'] else 'não'} | segredos: {'sim' if result['has_secrets'] else 'não'} | itens: {result['members']}")
            _safe_print("✅ Nenhum arquivo foi alterado.")
            return 0 if result['valid'] else 1
        except Exception as exc:
            return _bootstrap_error("simulação de restauração", exc)

    if args.cmd == "quality-gate":
        try:
            from csm.release_ops import run_quality_gate, save_quality_gate
            result = run_quality_gate(); target = save_quality_gate()
            _safe_print("🏁 QUALITY GATE")
            for item in result.items:
                marker = '✅' if item.passed else ('❌' if item.critical else '⚠️')
                _safe_print(f"{marker} {item.name}: {item.details}")
            _safe_print(f"Relatório: {target}")
            _safe_print("✅ RELEASE APROVADA" if result.passed else "❌ RELEASE BLOQUEADA")
            return 0 if result.passed else 1
        except Exception as exc:
            return _bootstrap_error("quality gate", exc)

    if args.cmd == "admin-dashboard":
        try:
            from csm.professional_ops import admin_dashboard, save_admin_dashboard
            data = admin_dashboard(); target = save_admin_dashboard()
            _safe_print("🛡️ PHANTOM ALERT • ADMIN CENTER")
            _safe_print(f"Release: {data.get('product_release', data['release'])} | LTS: {data['lts_base']}")
            _safe_print(f"Ambiente: {data['environment']} | Banco: {data['database_integrity']}")
            _safe_print(f"Usuários: {data['users']} | Assinantes: {data['active_subscribers']} | Pagamentos: {data['payments']}")
            _safe_print(f"Scanner hoje: ciclos={data['scanner_cycles_today']} descobertos={data['tokens_discovered_today']} aprovados={data['tokens_approved_today']} sinais={data['signals_sent_today']}")
            _safe_print(f"Relatório: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("dashboard administrativo", exc)

    if args.cmd == "release-check":
        try:
            from csm.professional_ops import run_release_check, save_release_check
            result = run_release_check(); target = save_release_check()
            _safe_print("🚦 RELEASE CHECK")
            for item in result.checks:
                _safe_print(f"{'✅' if item['ok'] else '❌'} {item['name']}: {item['details']}")
            _safe_print(f"Relatório: {target}")
            return 0 if result.passed else 1
        except Exception as exc:
            return _bootstrap_error("release check", exc)

    if args.cmd == "leader-report":
        try:
            from csm.project_leader import ProjectLeader
            report = ProjectLeader().audit()
            _safe_print(f"🤖 PROJECT LEADER 2.0 | Saúde: {report.get('health_score', 0)}/100")
            _safe_print(f"Problemas: {len(report.get('findings', []))}")
            for item in report.get('suggestions', []):
                _safe_print(f"• {item}")
            return 0
        except Exception as exc:
            return _bootstrap_error("relatório do Project Leader", exc)

    if args.cmd == "product-report":
        try:
            from csm.product_ops import build_product_report, save_product_report
            report = build_product_report()
            path = save_product_report()
            _safe_print("📊 RELATÓRIO DO PRODUTO")
            _safe_print(f"Ambiente: {report.environment} | versão: {report.version}")
            _safe_print(f"Banco: {report.database_integrity} | usuários={report.users} | assinantes={report.active_subscribers}")
            _safe_print(f"Pagamentos={report.payments} | análises={report.analyses} | favoritos={report.favorites} | sinais abertos={report.open_signals}")
            _safe_print(f"Telegram={'OK' if report.telegram_configured else 'não configurado'} | Asaas={'OK' if report.asaas_configured else 'não configurado'} | Scanner={'ON' if report.scanner_enabled else 'OFF'}")
            _safe_print(f"Radar hoje: ciclos={report.scanner_cycles_today} | descobertos={report.tokens_discovered_today} | aprovados={report.tokens_approved_today} | sinais={report.signals_sent_today}")
            _safe_print(f"Arquivo: {path}")
            return 0 if report.database_integrity in {"ok", "missing"} else 1
        except Exception as exc:
            return _bootstrap_error("relatório do produto", exc)

    if args.cmd == "integrity-check":
        try:
            from csm.backup_manager import newest_backup, validate_backup
            from csm.security import verify_file
            backup = newest_backup()
            if backup is None:
                _safe_print("⚠️ Nenhum backup localizado para verificação.")
                return 1
            validate_backup(backup)
            result = verify_file(backup, require_signature=False)
            _safe_print(f"✅ Backup íntegro: {backup}")
            _safe_print(f"SHA-256: {result['sha256']}")
            _safe_print(f"Assinatura criptográfica local: {'sim' if result['signed'] else 'legado/ausente'}")
            return 0
        except Exception as exc:
            return _bootstrap_error("verificação de integridade", exc)



    if args.cmd == "provider-catalog":
        try:
            from csm.provider_catalog import provider_catalog
            _safe_print("🗂️ PROVIDER CATALOG")
            for row in provider_catalog():
                state = "ATIVO" if row["enabled"] else "RESERVADO"
                _safe_print(f"{row['priority']:02d} • {row['provider']} | {state} | {row['role']} | {row['note']}")
            return 0
        except Exception as exc:
            return _bootstrap_error("catálogo de providers", exc)

    if args.cmd == "provider-health":
        try:
            from csm.provider_health import load_provider_health
            data = load_provider_health()
            counts = data.get("counts", {})
            _safe_print("🛰️ PROVIDER HEALTH")
            _safe_print(f"Saúde geral: {data.get('overall_health', 0)}/100")
            _safe_print(
                f"Online={counts.get('ONLINE',0)} | Available={counts.get('AVAILABLE',0)} | "
                f"Cooldown={counts.get('COOLDOWN',0)} | Quota={counts.get('QUOTA_EXHAUSTED',0)} | "
                f"Degraded={counts.get('DEGRADED',0)} | Offline={counts.get('OFFLINE',0)}"
            )
            rows = data.get("providers", [])
            if not rows:
                _safe_print("Ainda não há telemetria. Inicie o bot ou execute um scan para gerar dados.")
                return 0
            for row in rows:
                _safe_print(
                    f"{row.get('name')} | {row.get('status')} | saúde={row.get('health_score',0)}/100 | "
                    f"sucesso={row.get('success_rate',0)}% | latência={row.get('average_latency_ms', row.get('latency_ms'))}ms | "
                    f"retry={row.get('retry_in',0)}s | cache={'sim' if row.get('cached') else 'não'}"
                )
            return 0
        except Exception as exc:
            return _bootstrap_error("saúde dos providers", exc)

    if args.cmd in {"stability-status", "runtime-status"}:
        try:
            from phantom_v10.status import runtime_status
            d=runtime_status(); _safe_print("🧩 RUNTIME STATUS v16.0.0")
            for k,v in d.items(): _safe_print(f"{k}: {v}")
            return 0
        except Exception as exc: return _bootstrap_error("runtime-status v16.0.0",exc)

    if args.cmd == "runtime-recover":
        try:
            from phantom_v10.runtime import RuntimeGuard, AlreadyRunningError
            guard=RuntimeGuard("bot")
            try:
                event=guard.recover_stale_if_needed()
            except AlreadyRunningError as exc:
                _safe_print(f"✅ Sessão ativa saudável: {exc}")
                return 0
            if event.recovered:
                _safe_print(f"♻️ Estado obsoleto arquivado automaticamente: {event.reason}")
                for item in event.archived: _safe_print(f"- {item}")
            else:
                _safe_print("✅ Nenhum lock/sessão obsoleto encontrado.")
            return 0
        except Exception as exc: return _bootstrap_error("runtime-recover v16.0.0",exc)

    if args.cmd == "signal-lifecycle":
        try:
            from csm.storage import Storage
            from csm.signal_lifecycle import lifecycle_summary
            with Storage() as storage:
                data = lifecycle_summary(storage.conn, hours=args.hours, chain=args.chain)
            _safe_print(f"📈 SIGNAL LIFECYCLE V16.3 — {data.get('hours')}h" + (f" | {args.chain.upper()}" if args.chain else ""))
            _safe_print(f"signals: {data.get('signals')}")
            for state, qty in sorted((data.get('states') or {}).items()):
                _safe_print(f"- {state}: {qty}")
            _safe_print("Eventos:")
            for event, qty in sorted((data.get('events') or {}).items()):
                _safe_print(f"- {event}: {qty}")
            det = data.get('deteriorating') or []
            if det:
                _safe_print("Deteriorando:")
                for row in det[:10]:
                    name = row.get('symbol') or row.get('name') or f"#{row.get('id')}"
                    _safe_print(f"- {name} {str(row.get('chain') or '').upper()} | retorno={float(row.get('last_return_pct') or 0):+.2f}% | risco={row.get('deterioration_score')}/100")
            _safe_print("🔒 Lifecycle observa resultados; não altera scoring/filtros.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Signal Lifecycle V16.3", exc)

    if args.cmd == "signal-lifecycle-events":
        try:
            from csm.storage import Storage
            from csm.signal_lifecycle import recent_events
            with Storage() as storage:
                rows = recent_events(storage.conn, hours=args.hours, chain=args.chain, limit=args.limit)
            _safe_print(f"📈 EVENTOS SIGNAL LIFECYCLE — {len(rows)}")
            for row in rows:
                name = row.get('symbol') or row.get('name') or f"#{row.get('signal_id')}"
                _safe_print(f"- {row.get('created_at')} | {row.get('event_type')} | {name} {str(row.get('chain') or '').upper()} | {float(row.get('return_pct') or 0):+.2f}%")
            return 0
        except Exception as exc:
            return _bootstrap_error("Eventos Signal Lifecycle V16.3", exc)

    if args.cmd == "smart-reentry":
        try:
            from csm.storage import Storage
            from csm.smart_reentry import reentry_summary
            with Storage() as storage:
                data = reentry_summary(storage.conn, hours=args.hours, plan_group=args.plan, limit=args.limit)
            _safe_print(f"🔄 SMART REENTRY V16.4 — {data.get('hours')}h" + (f" | {args.plan.upper()}" if args.plan else ""))
            _safe_print(f"deliveries: {data.get('deliveries')} | initials: {data.get('initials')} | reentries: {data.get('reentries')}")
            cds = data.get('cooldowns') or {}
            _safe_print(f"cooldown: Free={cds.get('free')}h Plus={cds.get('plus')}h Premium={cds.get('premium')}h")
            _safe_print(f"outcomes reentry: positivo={data.get('positive_rate_pct')}% TP1={data.get('tp1_rate_pct')}% stop={data.get('stop_rate_pct')}%")
            for row in data.get('recent') or []:
                name = row.get('symbol') or row.get('name') or row.get('address') or 'TOKEN'
                evidence = row.get('evidence') or {}
                reasons = evidence.get('improvement_reasons') or []
                why = reasons[0] if reasons else 'revalidado pelos filtros atuais'
                _safe_print(f"- {row.get('created_at')} | {name} {str(row.get('chain') or '').upper()} | {str(row.get('plan_group') or '').upper()} | anterior={row.get('prior_lifecycle_state') or 'N/D'} | retorno={float(row.get('last_return_pct') or 0):+.2f}% | {why}")
            _safe_print("🔒 Reentrada não bypassa scanner, GoPlus, scoring ou filtros.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Smart Reentry V16.4", exc)

    if args.cmd == "scanner-intelligence":
        try:
            from csm.storage import Storage
            from csm.scanner_intelligence import scanner_funnel, compare_approved_rejected
            with Storage() as storage:
                funnel = scanner_funnel(storage.conn, hours=args.hours, chain=args.chain)
                comparison = compare_approved_rejected(storage.conn, hours=args.hours, chain=args.chain)
            _safe_print(f"🔎 SCANNER INTELLIGENCE V16.2 — {funnel.get('hours')}h" + (f" | {args.chain.upper()}" if args.chain else ""))
            for key in ("cycles","discovered","analyzed","approved","rejected","market_unavailable","errors","approval_rate_pct","last_cycle_at"):
                _safe_print(f"{key}: {funnel.get(key)}")
            _safe_print("Motivos de rejeição:")
            for row in funnel.get("rejection_reasons") or []:
                _safe_print(f"- {row.get('label')}: {row.get('count')} ({row.get('pct')}%)")
            if not args.chain:
                _safe_print("Redes:")
                for row in funnel.get("networks") or []:
                    _safe_print(
                        f"- {str(row.get('chain') or '?').upper()}: analisados={row.get('analyzed')} "
                        f"aprovados={row.get('approved')} taxa={row.get('approval_rate_pct')}% "
                        f"top_rejeição={row.get('top_rejection_label') or '-'}"
                    )
            a = comparison.get("approved") or {}; r = comparison.get("rejected") or {}
            if a and r:
                _safe_print(
                    f"Aprovados x rejeitados | score_médio={float(a.get('avg_analytic_score') or 0):.1f} x {float(r.get('avg_analytic_score') or 0):.1f} "
                    f"| liquidez_média={float(a.get('avg_liquidity') or 0):.2f} x {float(r.get('avg_liquidity') or 0):.2f}"
                )
            _safe_print("🔒 Evidence-only: nenhum filtro/scoring foi alterado.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Scanner Intelligence V16.2", exc)

    if args.cmd == "scanner-decisions":
        try:
            from csm.storage import Storage
            from csm.scanner_intelligence import recent_decisions
            with Storage() as storage:
                rows = recent_decisions(
                    storage.conn, hours=args.hours, chain=args.chain,
                    decision=args.decision.upper() if args.decision else "", limit=args.limit,
                )
            _safe_print(f"🔎 DECISÕES DO SCANNER — {len(rows)}")
            for row in rows:
                symbol = row.get('symbol') or row.get('name') or row.get('address') or '?'
                reason = row.get('reason_label') or row.get('reason') or '-'
                _safe_print(
                    f"{row.get('created_at')} | {str(row.get('chain') or '?').upper()} | {symbol} | "
                    f"{row.get('decision')} | {reason} | score={row.get('analytic_score')}"
                )
            return 0
        except Exception as exc:
            return _bootstrap_error("Scanner decisions V16.2", exc)

    if args.cmd == "provider-coverage":
        try:
            from csm.provider_coverage import coverage_status
            report = coverage_status(minutes=args.minutes)
            _safe_print(f"🌐 PROVIDER COVERAGE V16.6.0 — {report.get('minutes')}min")
            _safe_print(f"state: {report.get('state')} | cycles={report.get('cycles')} | history={'ok' if report.get('enough_history') else 'insuficiente'}")
            if report.get("deficits"):
                _safe_print("Coverage Guard:")
                for row in report.get("deficits") or []:
                    _safe_print(f"- {str(row.get('chain')).upper()}: analisados={row.get('analyzed')} alvo={row.get('target')} gap={row.get('gap')}")
            _safe_print("Redes:")
            for row in report.get("chains") or []:
                providers = row.get("provider_unique_added") or {}
                provider_text = ",".join(f"{k}={v}" for k,v in sorted(providers.items(), key=lambda item: (-int(item[1]), item[0]))[:4]) or "-"
                _safe_print(
                    f"- {str(row.get('chain')).upper()}: analisados={row.get('analyzed')} aprovados={row.get('approved')} "
                    f"taxa={row.get('approval_rate_pct')}% fontes=[{provider_text}]"
                )
            _safe_print("🔒 Coverage evidence: nenhum filtro/scoring alterado.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Provider Coverage V16.5.9", exc)

    if args.cmd == "provider-intelligence-status":
        try:
            import json
            from csm.provider_intelligence import intelligence_status
            _safe_print("🧠 PROVIDER INTELLIGENCE V16.6.0")
            _safe_print(json.dumps(intelligence_status(), ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("Provider Intelligence V16.5.9", exc)

    if args.cmd == "scanner-provider-diagnostics":
        try:
            from csm.storage import Storage
            from csm.scanner_intelligence import provider_rejection_diagnostics
            with Storage() as storage:
                report = provider_rejection_diagnostics(storage.conn, hours=args.hours, chain=args.chain)
            _safe_print(f"🔬 SCANNER PROVIDER DIAGNOSTICS V16.6.0 — {report.get('hours')}h" + (f" | {args.chain.upper()}" if args.chain else ""))
            _safe_print("Providers de mercado:")
            for row in report.get("providers") or []:
                _safe_print(f"- {row.get('source')}: total={row.get('total')} aprovados={row.get('approved')} rejeitados={row.get('rejected')} taxa={row.get('approval_rate_pct')}%")
            _safe_print("Principais rejeições por rede/provider:")
            for row in (report.get("items") or [])[:30]:
                _safe_print(
                    f"- {str(row.get('chain')).upper()} | {row.get('source')} | {row.get('reason_label')}: {row.get('count')} "
                    f"| liq_média={float(row.get('avg_liquidity') or 0):.2f} score_médio={float(row.get('avg_score') or 0):.1f}"
                )
            _safe_print("🔒 Evidence-only: diagnóstico não altera aprovação.")
            return 0
        except Exception as exc:
            return _bootstrap_error("Scanner Provider Diagnostics V16.5.9", exc)

    if args.cmd == "scanner-report":
        try:
            from csm.storage import Storage
            with Storage() as storage:
                stats = storage.scanner_stats_today()
            _safe_print("🔭 ATIVIDADE DO RADAR HOJE")
            for key in ("cycles", "discovered", "approved", "sent", "errors", "top_score", "last_cycle"):
                _safe_print(f"{key}: {stats.get(key)}")
            return 0
        except Exception as exc:
            return _bootstrap_error("relatório do scanner", exc)

    if args.cmd == "user-export":
        try:
            import json
            from csm.config import settings
            from csm.storage import Storage
            target = settings.base_dir / "exports" / f"user_{args.user_id}_export.json"
            target.parent.mkdir(parents=True, exist_ok=True)
            with Storage() as storage:
                payload = storage.export_user_data(args.user_id)
            target.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
            _safe_print(f"✅ Exportação criada: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("exportação do usuário", exc)

    if args.cmd == "leader-audit":
        try:
            from csm.project_leader import ProjectLeader
            leader = ProjectLeader()
            report = leader.audit()
            created = leader.proposals_from_audit(report)
            summary = report["summary"]
            _safe_print(f"Auditoria: total={summary['total']} críticos={summary['critical']} altos={summary['high']} acionáveis={summary['actionable']}")
            if not created:
                _safe_print("✅ Nenhuma correção segura pendente.")
            for proposal, code in created:
                _safe_print(f"🟡 {proposal.proposal_id} | {proposal.title} | ação={proposal.action}")
                _safe_print(f"   Código de aprovação: {code}")
                _safe_print(f"   Aprovar: python main.py leader-approve {proposal.proposal_id} {code}")
            return 0
        except Exception as exc:
            return _bootstrap_error("auditoria do líder", exc)

    if args.cmd == "leader-proposals":
        try:
            from csm.project_leader import ProjectLeader
            proposals = ProjectLeader().list_proposals()
            if not proposals:
                _safe_print("Nenhuma proposta registrada.")
                return 0
            for item in proposals:
                _safe_print(f"{item.proposal_id} | {item.status} | {item.severity} | {item.title} | {item.action}")
            return 0
        except Exception as exc:
            return _bootstrap_error("listagem de propostas", exc)

    if args.cmd == "leader-status":
        try:
            from csm.project_leader import ProjectLeader
            leader = ProjectLeader()
            state = leader.maintenance()
            pending = len(leader.list_proposals("PENDING"))
            approved = len(leader.list_proposals("APPROVED"))
            _safe_print(f"Manutenção: {'ATIVA' if state.get('active') else 'inativa'}")
            if state.get('active'):
                _safe_print(f"Motivo: {state.get('reason')} | ETA: {state.get('eta_minutes')} min")
            _safe_print(f"Propostas: pendentes={pending} aprovadas={approved}")
            return 0
        except Exception as exc:
            return _bootstrap_error("status do líder", exc)

    if args.cmd == "leader-approve":
        try:
            from csm.project_leader import ProjectLeader
            proposal = ProjectLeader().approve(args.proposal_id, args.approval_code)
            _safe_print(f"✅ Proposta aprovada: {proposal.proposal_id}")
            _safe_print(f"Aplicar: python main.py leader-apply {proposal.proposal_id}")
            return 0
        except Exception as exc:
            return _bootstrap_error("aprovação da proposta", exc)

    if args.cmd == "leader-apply":
        try:
            from csm.project_leader import ProjectLeader
            proposal = ProjectLeader().apply(args.proposal_id, eta_minutes=args.eta)
            _safe_print(f"✅ Proposta aplicada: {proposal.proposal_id} | {proposal.result}")
            return 0
        except Exception as exc:
            return _bootstrap_error("aplicação da proposta", exc)

    if args.cmd == "leader-bundle":
        try:
            import shutil
            from pathlib import Path
            from csm.project_leader import ProjectLeader
            leader = ProjectLeader()
            source = Path(args.bundle_file).expanduser().resolve()
            manifest = leader.validate_update_bundle(source)
            target = leader.inbox_dir / source.name
            shutil.copy2(source, target)
            _safe_print(f"✅ Pacote registrado: {target}")
            _safe_print(f"ID: {manifest['update_id']} | versão: {manifest['version']}")
            _safe_print("Execute: python main.py leader-audit")
            return 0
        except Exception as exc:
            return _bootstrap_error("registro de pacote", exc)

    if args.cmd == "maintenance-off":
        try:
            from csm.project_leader import ProjectLeader
            ProjectLeader().set_maintenance(False, reason="Manutenção encerrada pelo administrador")
            _safe_print("✅ Modo de manutenção desativado.")
            return 0
        except Exception as exc:
            return _bootstrap_error("encerramento de manutenção", exc)

    if args.cmd == "setup":
        try:
            from csm.setup_wizard import run_setup
            return int(run_setup() or 0)
        except Exception as exc:
            return _bootstrap_error("setup", exc)

    if args.cmd == "migrate":
        try:
            from csm.backup_manager import auto_restore_previous, create_pre_migration_backup
            safety = create_pre_migration_backup()
            if safety:
                _safe_print(f"✅ Backup de segurança pré-migração: {safety}")
            source, result = auto_restore_previous(restore_secrets=True)
            if source is None:
                _safe_print("ℹ️ Nenhum backup anterior encontrado; o banco atual será criado/atualizado sem apagar dados.")
                result = {"action": "in_place_schema_upgrade", "restored": False}
            # Open Storage even on a fresh install: initialize() performs the
            # idempotent schema migration and imports compatible legacy state.
            from csm.storage import Storage
            from csm.config import settings
            from csm.persistence import database_report
            storage = Storage(settings.db_file)
            storage.close()
            report = database_report(settings.db_file)
            if report["integrity"] != "ok" or report["schema_version"] <= 0:
                raise RuntimeError("Migração não produziu um banco válido; o estado anterior foi preservado")
            origin = str(source) if source is not None else "banco atual / instalação nova"
            _safe_print(f"✅ Migração automática concluída a partir de: {origin}")
            _safe_print(f"Banco: {report['path']} | schema={report['schema_version']} | usuários={report['users']} | pagamentos={report['payments']}")
            _safe_print(f"Detalhes: {result}")
            return 0
        except Exception as exc:
            return _bootstrap_error("migração automática", exc)


    if args.cmd == "db-check":
        try:
            from csm.config import settings
            from csm.persistence import database_report
            report = database_report(settings.db_file)
            _safe_print(f"Banco persistente: {report['path']}")
            _safe_print(f"Integridade: {report['integrity']}")
            _safe_print(f"Schema: {report['schema_version']}")
            _safe_print(f"Usuários: {report['users']} | Assinantes ativos: {report['active_subscribers']}")
            _safe_print(f"Pagamentos: {report['payments']} | Assinaturas: {report['subscriptions']}")
            _safe_print(f"Duplicidades de user_id: {report['duplicates']}")
            ok = report['integrity'] == 'ok' and report['duplicates'] == 0
            _safe_print("✅ BANCO COMPATÍVEL E ÍNTEGRO" if ok else "❌ BANCO PRECISA DE REVISÃO")
            return 0 if ok else 1
        except Exception as exc:
            return _bootstrap_error("verificação do banco", exc)

    if args.cmd == "db-backup":
        try:
            from csm.config import settings
            from csm.persistence import create_database_snapshot
            path = create_database_snapshot(settings.db_file, label="manual")
            if path is None:
                _safe_print("⚠️ O banco ainda não existe; não há dados para copiar.")
                return 2
            _safe_print(f"✅ Snapshot do banco criado: {path}")
            return 0
        except Exception as exc:
            return _bootstrap_error("backup do banco", exc)

    if args.cmd == "backup-list":
        try:
            from csm.backup_manager import backup_inventory, backup_retention
            items = backup_inventory()
            _safe_print(f"Retenção configurada: {backup_retention()} backup(s) históricos")
            if not items:
                _safe_print("⚠️ Nenhum backup válido localizado.")
                return 2
            for index, item in enumerate(items, 1):
                secret = "sim" if item["includes_secrets"] else "não"
                database = "sim" if item["database_included"] else "não"
                _safe_print(f"{index}. {item['path']} | v{item['version']} | segredos={secret} | banco={database} | {item['size']} bytes")
            return 0
        except Exception as exc:
            return _bootstrap_error("listagem de backups", exc)

    if args.cmd == "backup-check":
        try:
            from csm.backup_manager import newest_backup, validate_backup
            source = newest_backup()
            if source is None:
                _safe_print("⚠️ Nenhum backup válido localizado.")
                return 2
            manifest = validate_backup(source)
            _safe_print(f"✅ Backup íntegro: {source}")
            _safe_print(f"Manifesto: {manifest}")
            return 0
        except Exception as exc:
            return _bootstrap_error("verificação de backup", exc)

    if args.cmd == "backup":
        try:
            from csm.backup_manager import create_backup
            path = create_backup(include_secrets=args.include_secrets, destination=args.output)
            from csm.backup_manager import validate_backup
            manifest = validate_backup(path)
            _safe_print(f"✅ Backup criado e validado: {path}")
            if manifest.get("includes_secrets"):
                _safe_print("⚠️ Este backup contém chaves privadas. Não compartilhe.")
            elif args.include_secrets:
                _safe_print("⚠️ Backup criado sem segredos porque nenhuma configuração válida foi localizada.")
                _safe_print("Execute 'python main.py setup' e repita o backup para incluir Telegram e Asaas.")
            return 0
        except Exception as exc:
            return _bootstrap_error("backup", exc)

    if args.cmd == "restore":
        try:
            from csm.backup_manager import choose_backup_interactive, newest_backup, restore_backup
            source = args.backup_file or (choose_backup_interactive() if args.choose else newest_backup())
            if source is None:
                _safe_print("❌ Nenhum backup válido foi localizado automaticamente.")
                _safe_print("Use python main.py migrate para tentar importar também crypto_signals.env.backup.")
                return 2
            result = restore_backup(source, restore_secrets=args.restore_secrets)
            _safe_print(f"✅ Restauração concluída de {source}: {result}")
            return 0
        except FileNotFoundError as exc:
            _safe_print(f"❌ {exc}")
            _safe_print("Use: find .. -name '*.zip' para localizar o backup real.")
            return 2
        except Exception as exc:
            return _bootstrap_error("restore", exc)

    try:
        from csm.config import mask_secret, settings
    except Exception as exc:
        return _bootstrap_error("configuração", exc)

    _safe_print(f"Crypto Signals Multichain CLEAN Comercial v{version}")

    if args.cmd == "goplus-check":
        try:
            if bool(args.chain) != bool(args.address):
                _safe_print("❌ Use --chain e --address juntos, ou nenhum dos dois para teste de cobertura.")
                return 2
            from phantom_v10.provider_diagnostics import check_goplus
            report = check_goplus(chain=args.chain or "", address=args.address or "")
            _safe_print("🛡️ GOPLUS CHECK v16.0.0")
            _safe_print(f"Configuração: {'ATIVA' if report.get('enabled') else 'DESATIVADA'} • Bearer token: {'presente' if report.get('access_token_present') else 'opcional/ausente'}")
            if report.get("ok"):
                _safe_print(f"✅ GoPlus: HTTP {report.get('status')} • {report.get('message')}")
                if report.get("supported_count") is not None:
                    _safe_print(f"🌐 Entradas de cobertura retornadas: {report.get('supported_count')}")
                if args.address:
                    _safe_print(f"🔎 Token Security: {'dados recebidos' if report.get('token_data') else 'sem dados conclusivos'} • rede={args.chain}")
                return 0
            status = report.get("status")
            prefix = f"HTTP {status}" if status is not None else "sem HTTP conclusivo"
            _safe_print(f"❌ GoPlus: {prefix} • {report.get('message')}")
            if report.get("server_detail"):
                _safe_print(f"   Servidor: {report.get('server_detail')}")
            if status == 401:
                _safe_print("➡️ Configure um GOPLUS_ACCESS_TOKEN no setup se sua conta/rota exigir autenticação Bearer.")
            elif status == 429:
                _safe_print("➡️ Aguarde o rate-limit; o scanner usa cache e fallback para não parar o runtime.")
            return 1
        except Exception as exc:
            return _bootstrap_error("goplus-check", exc)

    if args.cmd == "birdeye-key-audit":
        try:
            from csm.credential_audit import audit_birdeye_credentials
            audit = audit_birdeye_credentials()
            _safe_print("🔐 BIRDEYE KEY AUDIT")
            _safe_print(f"Fonte ativa: {audit.get('active_source')}")
            _safe_print(f"Fingerprint ativa: {audit.get('active_fingerprint') or 'nenhuma'}")
            _safe_print(f"Tamanho ativo: {audit.get('key_length', 0)} caracteres")
            _safe_print(f"Marcador de rotação: {audit.get('marker_state')} • {audit.get('marker_fingerprint') or 'sem fingerprint'}")
            copies = audit.get("copies") or []
            if not copies:
                _safe_print("Nenhuma cópia Birdeye encontrada em arquivos conhecidos.")
            else:
                _safe_print(f"Cópias localizadas: {len(copies)} • históricas/diferentes={audit.get('stale_copies', 0)}")
                for row in copies:
                    flag = "ATIVA/MESMA" if row.get("active_match") else "HISTÓRICA/DIFERENTE"
                    _safe_print(f"- {flag} • {row.get('kind')} • {row.get('fingerprint')} • {row.get('location')}")
            if audit.get("stale_copies"):
                _safe_print("ℹ️ Cópias históricas podem existir em backups, mas a v16.0.0 não as restaura automaticamente após rotação/limpeza da Birdeye.")
            return 0
        except Exception as exc:
            return _bootstrap_error("birdeye-key-audit", exc)

    if args.cmd == "birdeye-check":
        try:
            from csm.credential_audit import audit_birdeye_credentials
            from phantom_v10.provider_diagnostics import check_birdeye
            audit = audit_birdeye_credentials()
            report = check_birdeye(check_listing=True)
            _safe_print("🦅 BIRDEYE CHECK v16.0.0")
            if not report.get("key_present"):
                _safe_print("❌ BIRDEYE_API_KEY ausente. Execute: python3 main.py setup")
                return 2
            _safe_print(f"🔑 Chave ativa: {int(report.get('key_length') or 0)} caracteres • {audit.get('active_fingerprint') or 'sem fingerprint'}")
            _safe_print(f"📍 Fonte ativa: {audit.get('active_source')}")
            if audit.get("stale_copies"):
                _safe_print(f"ℹ️ Há {audit.get('stale_copies')} cópia(s) histórica(s) diferente(s); elas não são a fonte ativa.")

            auth_status = report.get("auth_status")
            if auth_status is not None:
                icon = "✅" if int(auth_status) < 400 else "⚠️"
                _safe_print(f"{icon} Coverage/Auth probe /defi/networks: HTTP {auth_status} • {report.get('auth_message')}")
                if report.get("auth_server_detail"):
                    _safe_print(f"   Servidor: {report.get('auth_server_detail')}")

            if report.get("quota_exhausted"):
                _safe_print("⚠️ Birdeye reconheceu a chave ativa, mas a cota de Compute Units (CU) está esgotada.")
                _safe_print("ℹ️ New Listing não foi repetido para evitar chamadas inúteis enquanto a cota está bloqueada.")
                _safe_print("➡️ No BDS, confira Usages/Metrics e Subscription/Package; reative CU, renove ou ajuste o pacote conforme sua conta.")
                _safe_print("✅ DexScreener, GeckoTerminal e CoinGecko continuam disponíveis como fallback.")
                return 3

            if report.get("rate_limited"):
                if report.get("credential_ok") or report.get("auth_ok"):
                    _safe_print("⚠️ Birdeye: chave reconhecida, porém New Listing está temporariamente em rate limit (HTTP 429).")
                    _safe_print("✅ Integração preservada • scanner seguirá com cooldown e providers de fallback.")
                    return 0
                _safe_print("⚠️ Birdeye: HTTP 429 no probe inicial • diagnóstico temporariamente inconclusivo.")
                _safe_print("ℹ️ A chave NÃO foi classificada como inválida. Aguarde o cooldown e teste novamente.")
                return 4

            if report.get("listing_ok") is True:
                _safe_print(f"✅ New Listing Solana: HTTP {report.get('listing_status')} • itens de teste={report.get('items')}")
                _safe_print("✅ Integração Birdeye pronta para o scanner Plus/Premium.")
                return 0

            listing_status = report.get("listing_status")
            if listing_status is not None:
                _safe_print(f"❌ New Listing Solana: HTTP {listing_status} • {report.get('listing_message')}")
                if report.get("listing_server_detail"):
                    _safe_print(f"   Servidor: {report.get('listing_server_detail')}")
            else:
                _safe_print(f"❌ Birdeye: {report.get('message')}")
            status = int(listing_status or auth_status or report.get("status") or 0)
            if status == 401:
                _safe_print("➡️ O Birdeye rejeitou a chave ativa. Substitua-a no setup e confirme a fingerprint com birdeye-key-audit.")
            elif status == 403:
                _safe_print("➡️ Verifique permissões/whitelist/blacklist da chave no BDS.")
            elif status == 400:
                _safe_print("➡️ A mensagem acima é a resposta segura do servidor; a v16.0.0 usa o contrato mínimo limit+x-chain.")
            return 1
        except Exception as exc:
            return _bootstrap_error("birdeye-check", exc)

    if args.cmd == "dexpaprika-check":
        try:
            from csm.config import settings
            from phantom_v10.transport import StdlibHttpTransport
            headers = {"Authorization": settings.dexpaprika_api_key} if settings.dexpaprika_api_key else None
            transport = StdlibHttpTransport(timeout=8.0, label="dexpaprika-check", headers=headers)
            base = settings.dexpaprika_base_url.rstrip("/")
            payload = transport.get_json(
                f"{base}/networks/solana/tokens/search",
                params={"limit": 3, "order_by": "created_at", "sort": "desc"},
                timeout=8.0,
            )
            rows = payload.get("results") if isinstance(payload, dict) else None
            if isinstance(rows, list):
                mode = "API key" if settings.dexpaprika_api_key else "keyless"
                _safe_print(f"✅ DexPaprika ONLINE ({mode}) • candidatos de teste={len(rows)}")
                _safe_print(f"Base URL: {base}")
                return 0
            _safe_print("❌ DexPaprika respondeu em formato inesperado")
            return 1
        except Exception as exc:
            return _bootstrap_error("dexpaprika-check", exc)

    if args.cmd == "honeypot-check":
        try:
            from csm.config import settings
            from phantom_v10.honeypot_security import evaluate as evaluate_honeypot
            from phantom_v10.transport import StdlibHttpTransport
            headers = {"X-API-KEY": settings.honeypot_api_key} if settings.honeypot_api_key else None
            transport = StdlibHttpTransport(timeout=8.0, label="honeypot-check", headers=headers)
            base = settings.honeypot_base_url.rstrip("/")
            # USDC on Ethereum is a stable, non-honeypot public probe target.
            payload = transport.get_json(
                f"{base}/v2/IsHoneypot",
                params={"address": "0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", "chainID": 1},
                timeout=8.0,
            )
            verdict = evaluate_honeypot("ethereum", payload)
            if verdict.get("honeypot_available"):
                mode = "API key" if settings.honeypot_api_key else "keyless"
                _safe_print(f"✅ Honeypot.is ONLINE ({mode}) • risco={verdict.get('honeypot_risk')} • holders={verdict.get('honeypot_total_holders')}")
                _safe_print(f"Base URL: {base}")
                _safe_print("ℹ️ Fallback de segurança EVM: Ethereum/BSC/Base • advisory por padrão")
                return 0
            _safe_print("❌ Honeypot.is respondeu em formato inesperado")
            return 1
        except Exception as exc:
            return _bootstrap_error("honeypot-check", exc)

    if args.cmd == "health":
        try:
            from csm.storage import Storage
            with Storage() as storage:
                integrity = storage.conn.execute("PRAGMA integrity_check").fetchone()[0]
            _safe_print(f"{'✅' if integrity == 'ok' else '❌'} Estrutura e SQLite: {integrity.upper()}")
            _safe_print("Telegram: " + ("configurado" if settings.telegram_token and settings.telegram_chat_id else "não configurado"))
            if settings.payments_ready:
                _safe_print(f"Asaas: configurado ({settings.asaas_environment}, chave {mask_secret(settings.asaas_api_key)})")
            else:
                _safe_print(f"Asaas: não configurado ({settings.asaas_environment})")
            return 0 if integrity == "ok" else 1
        except Exception as exc:
            return _bootstrap_error("health", exc)

    if args.cmd == "doctor":
        try:
            _safe_print(f"✅ Python: {sys.version.split()[0]}")
            errors=settings.configuration_errors()
            if errors:
                for error in errors:_safe_print(f"❌ Configuração: {error}")
                return 1
            from phantom_v10.transport import StdlibHttpTransport, sigint_tls_shield_available
            from phantom_v10.telegram import TelegramClient
            transport = StdlibHttpTransport(timeout=6.0, label="doctor-telegram")
            me = TelegramClient(transport=transport).get_me()
            _safe_print(f"✅ Telegram autenticado: @{me.get('username','bot')}")
            _safe_print("✅ Rede ativa: HTTPS stdlib sequencial (sem curl/subprocess)")
            _safe_print(("✅" if sigint_tls_shield_available() else "⚠️") + " Proteção Ctrl+C/TLS: " + ("SIGINT adiado até fechar SSL" if sigint_tls_shield_available() else "pthread_sigmask indisponível; fallback cooperativo"))
            if settings.payments_ready:
                from phantom_v10.payments import AsaasClient
                client = AsaasClient(transport=StdlibHttpTransport(
                    timeout=6.0,
                    label="doctor-asaas",
                    headers={"access_token": settings.asaas_api_key, "Content-Type": "application/json"},
                ))
                account = client.call("GET", "/myAccount")
                identity = account.get("name") or account.get("email") or "conta ativa"
                _safe_print(f"✅ Asaas autenticado: {identity} ({settings.asaas_environment})")
                account_status = client.account_status()
                general = str(account_status.get("general") or "UNKNOWN").upper()
                marker = "✅" if general == "APPROVED" else "⚠️"
                _safe_print(f"{marker} Asaas status API: general={general} | commercial={account_status.get('commercialInfo','?')} | bank={account_status.get('bankAccountInfo','?')} | docs={account_status.get('documentation','?')}")
            else:
                _safe_print("⚠️ Asaas desativado")
            _safe_print("✅ Multi-provider núcleo: GeckoTerminal + DexScreener")
            provider_failed = False
            provider_quota = False
            provider_rate_limited = False
            if settings.birdeye_api_key:
                from phantom_v10.provider_diagnostics import check_birdeye
                birdeye = check_birdeye(check_listing=False)
                if birdeye.get("quota_exhausted"):
                    provider_quota = True
                    _safe_print("⚠️ Birdeye: chave reconhecida, porém cota de Compute Units (CU) esgotada.")
                    if birdeye.get("auth_server_detail"):
                        _safe_print(f"   Servidor: {birdeye.get('auth_server_detail')}")
                    _safe_print("   Confira BDS Usages/Metrics e Subscription/Package. O runtime seguirá com fallback.")
                elif birdeye.get("rate_limited"):
                    provider_rate_limited = True
                    _safe_print("⚠️ Birdeye: HTTP 429 • rate limit temporário; fallback ativo.")
                    _safe_print("   O runtime não repetirá New Listing neste diagnóstico.")
                elif birdeye.get("auth_ok"):
                    _safe_print(f"✅ Birdeye autenticado: redes={len(birdeye.get('networks') or [])} (Plus/Premium)")
                else:
                    provider_failed = True
                    status = birdeye.get("status") or "?"
                    _safe_print(f"❌ Birdeye: HTTP {status} • {birdeye.get('message')}")
                    _safe_print("   Execute: python3 main.py birdeye-check")
            else:
                _safe_print("ℹ️ Birdeye: opcional, sem chave")
            _safe_print(("✅" if settings.coingecko_api_key else "ℹ️") + " CoinGecko Onchain: " + ("chave presente (Premium)" if settings.coingecko_api_key else "opcional, sem chave"))
            if settings.dexpaprika_enabled:
                dp_mode = "API key opcional presente" if settings.dexpaprika_api_key else "keyless público"
                _safe_print(f"✅ DexPaprika: {dp_mode} • teste: python3 main.py dexpaprika-check")
            else:
                _safe_print("ℹ️ DexPaprika: desativado")
            if settings.goplus_enabled:
                mode = "fail-closed" if settings.goplus_fail_closed else "fallback/fail-open"
                _safe_print(f"✅ GoPlus Security Gate: ativo • cache={settings.goplus_cache_ttl}s • score mínimo={settings.goplus_min_security_score} • {mode}")
                _safe_print("   Teste independente: python3 main.py goplus-check")
            else:
                _safe_print("ℹ️ GoPlus Security Gate: desativado")
            if settings.onchain_enabled:
                evm_ready = [chain for chain in ("ethereum","bsc","base","arbitrum","polygon","avalanche","optimism","fantom","cronos") if settings.evm_rpc_url(chain)]
                marker = "✅" if settings.helius_ready or evm_ready else "⚠️"
                _safe_print(f"{marker} On-Chain Intelligence: polling outbound • Helius={'pronto' if settings.helius_ready else 'não configurado'} • EVM RPCs={len(evm_ready)} • webhooks públicos=NÃO")
                _safe_print("   Teste independente: python3 main.py onchain-check --chain solana")
            else:
                _safe_print("ℹ️ On-Chain Intelligence: desativado")
            if settings.reputation_enabled:
                try:
                    from csm.reputation import ReputationEngine
                    from csm.storage import Storage
                    with Storage() as rep_storage:
                        rep = ReputationEngine(rep_storage)
                        rep.refresh(days=3650, limit=250)
                        rep_status = rep.status(days=3650)
                    _safe_print(f"✅ Reputation Engine v14: perfis={rep_status.get('profiles',0)} • evidências={rep_status.get('evidence',0)} • rede=0 chamadas")
                    _safe_print("   Consulte: python3 main.py reputation-status")
                except Exception as exc:
                    _safe_print(f"⚠️ Reputation Engine: {type(exc).__name__}: {exc}")
            else:
                _safe_print("ℹ️ Reputation Engine: desativado")
            if settings.observability_enabled:
                try:
                    from csm.observability import ObservabilityEngine
                    from csm.storage import Storage
                    with Storage() as ops_storage:
                        ops_status = ObservabilityEngine(ops_storage).status(days=7)
                    _safe_print(
                        f"✅ Observability v14.5: health={ops_status.get('health_score',100)}/100 "
                        f"{ops_status.get('state','HEALTHY')} • incidentes={ops_status.get('open_incidents',0)} • webhooks públicos=NÃO"
                    )
                    _safe_print("   Consulte: python3 main.py observability-status")
                except Exception as exc:
                    _safe_print(f"⚠️ Observability: {type(exc).__name__}: {exc}")
            else:
                _safe_print("ℹ️ Observability & Operations: desativada")
            if settings.distribution_enabled:
                try:
                    from csm.distribution import DistributionManager
                    from csm.storage import Storage
                    with Storage() as dist_storage:
                        dist_status = DistributionManager(dist_storage).status(days=7)
                    _safe_print(
                        f"✅ Distribution v15: destinos={dist_status.get('active_destinations',0)} • "
                        f"outbound-only • Telegram principal • webhooks públicos de entrada=NÃO"
                    )
                    _safe_print("   Consulte: python3 main.py distribution-status --days 7")
                except Exception as exc:
                    _safe_print(f"⚠️ Distribution Platform: {type(exc).__name__}: {exc}")
            else:
                _safe_print("ℹ️ Distribution Platform: desativada")
            if provider_failed:
                _safe_print("⚠️ RUNTIME operacional com fallback, porém Birdeye configurado está sem autenticação/acesso válido.")
                return 1
            if provider_quota:
                _safe_print("⚠️ RUNTIME v16.0.0 PRONTO EM FALLBACK • Birdeye pausado por cota CU, não por chave inválida.")
                return 0
            if provider_rate_limited:
                _safe_print("⚠️ RUNTIME v16.0.0 PRONTO EM FALLBACK • Birdeye temporariamente em rate limit, não por chave inválida.")
                return 0
            _safe_print("✅ RUNTIME v16.0.0 PRONTO")
            return 0
        except Exception as exc:
            if "401" in str(exc):
                _safe_print("❌ Token Telegram inválido (HTTP 401). Execute: python main.py setup")
                return 1
            return _bootstrap_error("doctor v16.0.0", exc)

    if args.cmd == "reset-plan":
        try:
            from csm.storage import Storage
            with Storage() as storage:
                changed = storage.reset_user_to_free(args.user_id)
            _safe_print("✅ Usuário voltou ao plano Grátis." if changed else "⚠️ Usuário não encontrado no banco.")
            return 0 if changed else 2
        except Exception as exc:
            return _bootstrap_error("reset-plan", exc)

    if args.cmd == "signal-test":
        app = None
        try:
            from phantom_v10.app import PhantomApp
            app = PhantomApp()
            rows = app.scanner.run_sync(limit=30, wall_timeout=55.0)
            if not rows:
                _safe_print("⚠️ Nenhum candidato disponível para teste.")
                return 2
            user = app.storage.get_user(args.user_id)
            item = rows[0]
            chain = str(item.get("chain") or "")
            address = str(item.get("address") or "")
            kb = {"inline_keyboard": [[{"text": "🔎 Analisar", "callback_data": f"refresh|{chain}|{address}"}]]}
            app.telegram.send(
                args.user_id,
                "🧪 <b>TESTE DO CANAL AUTOMÁTICO</b>\n\n" + app._signal_text(item, str(user.get("plan") or "free")),
                kb,
            )
            _safe_print("✅ Sinal de teste enviado pelo runtime v10.")
            return 0
        except Exception as exc:
            return _bootstrap_error("signal-test v16.0.0", exc)
        finally:
            if app is not None:
                app.close()

    if args.cmd == "onchain-status":
        try:
            import json
            from csm.onchain import OnChainLedger
            from csm.storage import Storage
            from csm.config import settings
            with Storage() as storage:
                status = OnChainLedger(storage).status(days=max(1, args.days))
            _safe_print("🔗 ON-CHAIN INTELLIGENCE v13.5")
            _safe_print(json.dumps(status, ensure_ascii=False, indent=2, default=str))
            _safe_print(f"Modo: polling HTTPS local • webhooks públicos: NÃO • Helius={'pronto' if settings.helius_ready else 'não configurado'}")
            return 0
        except Exception as exc:
            return _bootstrap_error("onchain status", exc)

    if args.cmd == "onchain-report":
        try:
            import json
            from csm.onchain import OnChainLedger
            from csm.storage import Storage
            with Storage() as storage:
                report = OnChainLedger(storage).report(days=max(1, args.days), limit=max(1, args.limit))
            _safe_print("📊 ON-CHAIN REPORT v13.5")
            _safe_print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("onchain report", exc)

    if args.cmd == "onchain-check":
        try:
            from csm.config import settings
            from phantom_v10.onchain_monitor import OnChainMonitor
            from phantom_v10.transport import StdlibHttpTransport
            from csm.storage import Storage
            chain = str(args.chain or "solana").lower()
            cap = OnChainMonitor.capability(chain)
            _safe_print("🔌 ON-CHAIN CONNECTIVITY CHECK v13.5")
            _safe_print(f"Rede={chain} • source={cap['source'] or 'n/a'} • polling={cap['mode']} • configurado={'sim' if cap['ready'] else 'não'}")
            _safe_print("Webhooks públicos: DESATIVADOS por arquitetura")
            if not cap['ready']:
                if chain == 'solana':
                    _safe_print("Configure HELIUS_API_KEY ou HELIUS_SECURE_RPC_URL no setup.")
                else:
                    _safe_print(f"Configure EVM_RPC_{chain.upper()} no setup/config.env.")
                return 2
            transport = StdlibHttpTransport(timeout=float(settings.onchain_request_timeout_seconds), label="onchain-check")
            if chain == 'solana':
                url = settings.helius_secure_rpc_url or ("https://mainnet.helius-rpc.com/?api-key=" + settings.helius_api_key)
                payload = transport.request_json("POST", url, json_data={"jsonrpc":"2.0","id":"check","method":"getSlot","params":[{"commitment":"confirmed"}]}).payload
                if isinstance(payload, dict) and payload.get('result') is not None:
                    _safe_print(f"✅ Helius RPC OK • slot={payload.get('result')}")
                    return 0
                _safe_print("❌ Helius respondeu sem result válido.")
                return 1
            url = settings.evm_rpc_url(chain)
            payload = transport.request_json("POST", url, json_data={"jsonrpc":"2.0","id":"check","method":"eth_chainId","params":[]}).payload
            if isinstance(payload, dict) and payload.get('result'):
                _safe_print(f"✅ EVM RPC OK • chainId={payload.get('result')}")
                return 0
            _safe_print("❌ RPC respondeu sem chainId válido.")
            return 1
        except Exception as exc:
            return _bootstrap_error("onchain check", exc)

    if args.cmd == "onchain-run-once":
        storage = None
        try:
            from csm.config import settings
            from csm.storage import Storage
            from phantom_v10.onchain_monitor import OnChainMonitor
            from phantom_v10.transport import StdlibHttpTransport
            if not settings.onchain_enabled:
                _safe_print("⚠️ On-Chain Intelligence está desativado.")
                return 2
            storage = Storage()
            transport = StdlibHttpTransport(timeout=float(settings.onchain_request_timeout_seconds), label="onchain-manual")
            monitor = OnChainMonitor(storage, transport)
            due = monitor.due_signals(limit=max(1, args.limit), minimum_gap_seconds=60)
            ok = 0
            for signal in due:
                ok += int(bool(monitor.observe_one(signal)))
            _safe_print(f"🔗 Fatia On-Chain concluída: due={len(due)} • observados={ok} • HTTPS <= 1 por sinal")
            return 0
        except Exception as exc:
            return _bootstrap_error("onchain run once", exc)
        finally:
            if storage is not None:
                storage.close()

    if args.cmd == "reputation-status":
        try:
            import json
            from csm.reputation import ReputationEngine
            from csm.storage import Storage
            with Storage() as storage:
                engine = ReputationEngine(storage)
                engine.refresh(days=max(1, args.days), limit=250)
                status = engine.status(days=max(1, args.days))
            _safe_print("🧬 WALLET/DEPLOYER REPUTATION v14")
            _safe_print(json.dumps(status, ensure_ascii=False, indent=2, default=str))
            _safe_print("Fonte canônica: evidências append-only • chamadas de rede: 0")
            return 0
        except Exception as exc:
            return _bootstrap_error("reputation status", exc)

    if args.cmd == "reputation-report":
        try:
            import json
            from csm.reputation import ReputationEngine
            from csm.storage import Storage
            with Storage() as storage:
                engine = ReputationEngine(storage)
                engine.refresh(days=max(1, args.days), limit=max(50, args.limit * 20))
                report = engine.report(days=max(1, args.days), limit=max(1, args.limit))
            _safe_print("📊 REPUTATION REPORT v14")
            _safe_print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("reputation report", exc)

    if args.cmd == "reputation-lookup":
        try:
            import json
            from csm.reputation import ReputationEngine
            from csm.storage import Storage
            with Storage() as storage:
                engine = ReputationEngine(storage)
                engine.refresh(days=3650, limit=1000)
                profile = engine.profile(args.chain, args.address)
            if not profile:
                _safe_print("ℹ️ Wallet ainda sem evidência suficiente no dataset local.")
                return 2
            _safe_print("🔎 REPUTATION LOOKUP v14")
            _safe_print(json.dumps(profile, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("reputation lookup", exc)

    if args.cmd == "reputation-refresh":
        try:
            import json
            from csm.reputation import ReputationEngine
            from csm.storage import Storage
            with Storage() as storage:
                result = ReputationEngine(storage).refresh(days=max(1, args.days), limit=max(50, args.limit), snapshot=True)
            _safe_print("🧬 Reputation consolidada sem chamadas de rede.")
            _safe_print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("reputation refresh", exc)

    if args.cmd in {"distribution-status","distribution-add","distribution-list","distribution-enable","distribution-disable","distribution-test","distribution-run-once","distribution-jobs","distribution-retry"}:
        try:
            import getpass, json
            from csm.distribution import DistributionManager
            from csm.storage import Storage
            from phantom_v10.transport import StdlibHttpTransport, global_network_bus
            with Storage() as storage:
                transport = StdlibHttpTransport(timeout=6.0, bus=global_network_bus(), label="distribution-cli")
                manager = DistributionManager(storage, transport)
                if args.cmd == "distribution-status":
                    _safe_print("📤 DISTRIBUTION PLATFORM v15")
                    _safe_print(json.dumps(manager.status(days=max(1,args.days)), ensure_ascii=False, indent=2, default=str))
                    return 0
                if args.cmd == "distribution-add":
                    target = args.target or getpass.getpass("Destino (URL HTTPS ou e-mail; não será ecoado): ").strip()
                    row = manager.add_destination(channel=args.channel,name=args.name,target=target,tenant_slug=args.tenant,plans=args.plans,events=args.events,signing_secret=args.secret)
                    _safe_print(f"✅ Destino criado id={row['id']} | canal={row['channel']} | {row['target_hint']} | planos={row['plans_csv']}")
                    if row.get("signing_secret"):
                        _safe_print("🔐 HMAC SECRET — COPIE AGORA; não é salvo no SQLite nem exibido novamente:")
                        _safe_print(row['signing_secret'])
                    return 0
                if args.cmd == "distribution-list":
                    _safe_print("📬 DESTINOS V15 (sanitizados)")
                    for row in manager.list_destinations():
                        _safe_print(f"id={row['id']} | {row['channel']} | {row['name']} | alvo={row['target_hint']} | ativo={row['enabled']} | planos={row['plans_csv']} | eventos={row['events_csv']}")
                    return 0
                if args.cmd in {"distribution-enable","distribution-disable"}:
                    enabled = args.cmd == "distribution-enable"
                    ok = manager.set_enabled(args.id, enabled)
                    _safe_print(("✅" if ok else "⚠️") + f" destino id={args.id} " + ("ativado" if enabled else "desativado"))
                    return 0 if ok else 1
                if args.cmd == "distribution-test":
                    result = manager.test_destination(args.id)
                    _safe_print("🧪 DISTRIBUTION TEST v15")
                    _safe_print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
                    return 0 if result.get("ok") else 1
                if args.cmd == "distribution-run-once":
                    done=[]
                    for _ in range(max(1,min(args.limit,50))):
                        result=manager.run_one()
                        if result is None: break
                        done.append(result)
                    _safe_print("📤 DISTRIBUTION RUN-ONCE")
                    _safe_print(json.dumps(done, ensure_ascii=False, indent=2, default=str))
                    return 0
                if args.cmd == "distribution-jobs":
                    _safe_print("📦 DISTRIBUTION JOBS")
                    _safe_print(json.dumps(manager.jobs(limit=args.limit,status=args.status), ensure_ascii=False, indent=2, default=str))
                    return 0
                if args.cmd == "distribution-retry":
                    ok=manager.retry_job(args.job_id)
                    _safe_print(("✅" if ok else "⚠️") + f" job={args.job_id} " + ("recolocado na fila" if ok else "não elegível/encontrado"))
                    return 0 if ok else 1
        except Exception as exc:
            return _bootstrap_error("distribution platform", exc)

    if args.cmd == "observability-status":
        try:
            import json
            from csm.observability import ObservabilityEngine
            from csm.storage import Storage
            with Storage() as storage:
                status = ObservabilityEngine(storage).status(days=max(1, args.days))
            _safe_print("📡 OBSERVABILITY & OPERATIONS v14.5")
            _safe_print(json.dumps(status, ensure_ascii=False, indent=2, default=str))
            _safe_print("Modo: local/cooperativo • sem webhook público • sem coletor externo obrigatório")
            return 0
        except Exception as exc:
            return _bootstrap_error("observability status", exc)

    if args.cmd == "observability-report":
        try:
            import json
            from csm.observability import ObservabilityEngine
            from csm.storage import Storage
            with Storage() as storage:
                report = ObservabilityEngine(storage).report(days=max(1, args.days), limit=max(1, args.limit))
            _safe_print("📊 OPERATIONS REPORT v14.5")
            _safe_print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("observability report", exc)

    if args.cmd == "observability-incidents":
        try:
            import json
            from csm.observability import ObservabilityEngine
            from csm.storage import Storage
            with Storage() as storage:
                rows = ObservabilityEngine(storage).incidents(open_only=bool(args.open_only), limit=max(1, args.limit))
            _safe_print("🚨 OPERATIONAL INCIDENTS v14.5")
            _safe_print(json.dumps({"count": len(rows), "items": rows}, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("observability incidents", exc)

    if args.cmd == "observability-export":
        try:
            from csm.observability import ObservabilityEngine
            from csm.storage import Storage
            suffix = ".prom" if args.format == "prometheus" else ".json"
            output = args.output or str(Path.cwd() / f"csm_observability{suffix}")
            with Storage() as storage:
                target = ObservabilityEngine(storage).export(output, days=max(1, args.days), fmt=args.format)
            _safe_print(f"✅ Observability exportada: {target}")
            return 0
        except Exception as exc:
            return _bootstrap_error("observability export", exc)

    if args.cmd == "config-integrity":
        try:
            from csm.config_integrity import ConfigIntegrityGuard

            report = ConfigIntegrityGuard().report()

            _safe_print("🛡️ CONFIGURATION INTEGRITY GUARD v16.4.6")
            _safe_print(
                f"Status: {report.get('status')} | "
                f"alterações={report.get('changed_count', 0)} | "
                f"críticos ausentes={report.get('critical_missing_count', 0)}"
            )

            for row in report.get("changes", [])[:20]:
                _safe_print(
                    f"- {row.get('key')}: {row.get('kind')}"
                )

            return 0

        except Exception as exc:
            return _bootstrap_error(
                "config integrity",
                exc,
            )

    if args.cmd == "config-integrity-accept":
        try:
            from csm.config_integrity import ConfigIntegrityGuard

            result = ConfigIntegrityGuard().mark_healthy(
                reason="manual_cli"
            )

            _safe_print(
                "✅ Configuração atual aceita como baseline saudável."
            )

            _safe_print(
                f"Chaves monitoradas: {len(result.get('keys') or {})}"
            )

            return 0

        except Exception as exc:
            return _bootstrap_error(
                "config integrity accept",
                exc,
            )

    if args.cmd == "config-change-history":
        try:
            import json
            from csm.config_change_history import history_report

            report = history_report(limit=50)

            _safe_print(
                json.dumps(
                    report,
                    ensure_ascii=False,
                    indent=2,
                )
            )

            return 0

        except Exception as exc:
            return _bootstrap_error(
                "config change history",
                exc,
            )

    if args.cmd == "runtime-resilience-status":
        try:
            import json
            from csm.runtime_resilience import overview

            _safe_print(
                json.dumps(
                    overview(),
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        except Exception as exc:
            return _bootstrap_error(
                "runtime resilience status",
                exc,
            )

    if args.cmd == "runtime-resilience-once":
        try:
            import json
            from csm.runtime_resilience import watch_once

            result = watch_once(
                recover=not bool(args.no_recover),
            )
            _safe_print(
                json.dumps(
                    result,
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        except Exception as exc:
            return _bootstrap_error(
                "runtime resilience once",
                exc,
            )

    if args.cmd == "runtime-resilience-watch":
        try:
            from csm.runtime_resilience import watch_loop

            _safe_print(
                f"🛡️ Runtime Resilience V16.5.3 ativo | intervalo={max(30, int(args.interval))}s"
            )
            watch_loop(interval_seconds=args.interval)
            return 0
        except KeyboardInterrupt:
            _safe_print("🛑 Runtime Resilience encerrado.")
            return 130
        except Exception as exc:
            return _bootstrap_error(
                "runtime resilience watch",
                exc,
            )

    if args.cmd == "evidence-attribution-report":
        try:
            import json
            from csm.admin_web import _admin_snapshot

            quality = (
                _admin_snapshot().get("signal_quality")
                or {}
            )

            report = (
                quality.get("evidence_attribution")
                or {}
            )

            _safe_print(
                json.dumps(
                    report,
                    ensure_ascii=False,
                    indent=2,
                )
            )

            return 0

        except Exception as exc:
            return _bootstrap_error(
                "evidence attribution report",
                exc,
            )

    if args.cmd == "shadow-evidence-status":
        try:
            import json
            from csm.admin_web import _admin_snapshot

            quality = (
                _admin_snapshot().get("signal_quality")
                or {}
            )

            evidence = (
                quality.get("shadow_evidence")
                or {}
            )

            _safe_print(
                json.dumps(
                    evidence,
                    ensure_ascii=False,
                    indent=2,
                )
            )

            return 0

        except Exception as exc:
            return _bootstrap_error(
                "shadow evidence status",
                exc,
            )

    if args.cmd == "signal-quality-report":
        try:
            import json
            from csm.admin_web import _admin_snapshot

            report = (
                _admin_snapshot().get("signal_quality")
                or {}
            )

            _safe_print(
                json.dumps(
                    report,
                    ensure_ascii=False,
                    indent=2,
                )
            )

            return 0

        except Exception as exc:
            return _bootstrap_error(
                "signal quality report",
                exc,
            )

    if args.cmd == "signal-learning-status":
        try:
            import json
            from csm.signal_outcome_learning import SignalOutcomeLearning
            from csm.storage import Storage
            with Storage() as storage:
                report = SignalOutcomeLearning(storage).status()
            _safe_print("🧠 SIGNAL OUTCOME LEARNING V16.6.0")
            _safe_print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
            _safe_print("🔒 EVIDENCE_ONLY: sem alteração automática de filtros, score ou entrega.")
            return 0
        except Exception as exc:
            return _bootstrap_error("signal learning status", exc)

    if args.cmd == "signal-learning-run":
        try:
            from csm.signal_outcome_learning import SignalOutcomeLearning
            from csm.storage import Storage
            with Storage() as storage:
                report = SignalOutcomeLearning(storage).run(days=max(1, args.days), persist=True)
            _safe_print("🧠 SIGNAL OUTCOME LEARNING V16.6.0 — SNAPSHOT")
            _safe_print(f"Modo={report['mode']} | sinais={report['signals_total']} | observados={report['signals_observed']} | cobertura={report['observation_coverage_pct']}%")
            _safe_print(f"Win suavizado global={report['global']['smoothed_win_rate_pct']}% | retorno médio={report['global']['average_last_return_pct']}% | stop={report['global']['stop_touch_rate_pct']}%")
            _safe_print(f"Segmentos={len(report['segments'])} | recomendações={len(report['recommendations'])}")
            _safe_print("🔒 Nenhuma recomendação foi aplicada ao scanner.")
            return 0
        except Exception as exc:
            return _bootstrap_error("signal learning run", exc)

    if args.cmd == "signal-learning-report":
        try:
            from csm.signal_outcome_learning import SignalOutcomeLearning
            from csm.storage import Storage
            with Storage() as storage:
                report = SignalOutcomeLearning(storage).build(days=max(1, args.days))
            _safe_print(f"🧠 SIGNAL OUTCOME LEARNING V16.6.0 — {report['lookback_days']}d")
            _safe_print(f"Modo={report['mode']} | sinais={report['signals_total']} | observados={report['signals_observed']} | cobertura={report['observation_coverage_pct']}%")
            _safe_print(f"Baseline: win_suavizado={report['global']['smoothed_win_rate_pct']}% | retorno={report['global']['average_last_return_pct']}% | TP1={report['global']['tp1_hit_rate_pct']}% | stop={report['global']['stop_touch_rate_pct']}%")
            for row in [r for r in report['segments'] if r.get('enough_samples')][:30]:
                _safe_print(f"- {row['dimension']}={row['segment']} | n={row['signals']} | win_s={row['smoothed_win_rate_pct']}% | retorno={row['average_last_return_pct']}% | stop={row['stop_touch_rate_pct']}% | confiança={row['confidence_pct']}%")
            _safe_print("🔒 EVIDENCE_ONLY: análise observacional; zero impacto LIVE.")
            return 0
        except Exception as exc:
            return _bootstrap_error("signal learning report", exc)

    if args.cmd == "signal-learning-recommendations":
        try:
            from csm.signal_outcome_learning import SignalOutcomeLearning
            from csm.storage import Storage
            with Storage() as storage:
                rows = SignalOutcomeLearning(storage).recommendations(days=max(1, args.days), limit=max(1, args.limit))
            _safe_print("💡 SIGNAL OUTCOME RECOMMENDATIONS V16.6.0")
            if not rows:
                _safe_print("Amostra ainda insuficiente para recomendações confiáveis.")
            for row in rows:
                _safe_print(f"- {row['action']} | {row['dimension']}={row['segment']} | n={row['signals']} | Δwin={row['delta_win_pp']:+.2f}pp | Δret={row['delta_return_pp']:+.2f}pp | Δstop={row['delta_stop_pp']:+.2f}pp | {row['reason']}")
            _safe_print("🔒 Recomendações não são aplicadas automaticamente nesta versão.")
            return 0
        except Exception as exc:
            return _bootstrap_error("signal learning recommendations", exc)

    if args.cmd == "performance-report":
        try:
            from csm.performance import PerformanceLedger
            from csm.storage import Storage
            with Storage() as storage:
                report = PerformanceLedger(storage).report(days=max(1, args.days))
            _safe_print("📈 PERFORMANCE INTELLIGENCE v11")
            _safe_print(f"Sinais: {report['signals_total']} | observados: {report['signals_observed']} | cobertura={report['observation_coverage_pct']}%")
            _safe_print(f"Win rate: {report['win_rate_pct']}% | TP1: {report['tp1_hit_rate_pct']}% | TP2: {report['tp2_hit_rate_pct']}% | stop touch: {report['stop_touch_rate_pct']}%")
            _safe_print(f"Retorno médio atual: {report['average_last_return_pct']}% | mediana: {report['median_last_return_pct']}% | pior drawdown: {report['worst_drawdown_pct']}%")
            for label, row in report['horizons'].items():
                _safe_print(f"{label}: n={row['samples']} | médio={row['average_return_pct']}% | mediana={row['median_return_pct']}% | win={row['win_rate_pct']}%")
            return 0
        except Exception as exc:
            return _bootstrap_error("performance report", exc)

    if args.cmd == "signal-quality-shadow-report":
        try:
            from csm.performance import PerformanceLedger
            from csm.storage import Storage

            with Storage() as storage:
                report = PerformanceLedger(storage).signal_quality_shadow_report(
                    days=max(1, args.days),
                    target_seconds=max(60, args.target_seconds),
                    grace_seconds=max(0, args.grace_seconds),
                )

            age_avg = report["average_shadow_age_seconds"]
            age_med = report["median_shadow_age_seconds"]

            _safe_print("🕶️ SIGNAL QUALITY SHADOW v16.4.5")
            _safe_print(
                f"Sinais={report['signals_total']} | "
                f"baseline={report['signals_with_baseline']} | "
                f"confirmados={report['shadow_confirmed']} | "
                f"faltando={report['shadow_missing']}"
            )
            _safe_print(
                f"Cobertura shadow={report['shadow_coverage_pct']}% | "
                f"alvo={report['target_seconds']}s | "
                f"tolerância=+{report['grace_seconds']}s"
            )
            _safe_print(
                f"Idade média={age_avg if age_avg is not None else 'n/a'}s | "
                f"mediana={age_med if age_med is not None else 'n/a'}s"
            )
            _safe_print(
                f"Positivos na confirmação={report['shadow_positive_rate_pct']}% | "
                f"retorno médio={report['average_shadow_return_pct']}%"
            )
            cohort = report.get("confirmed_outcomes") or {}
            delta = (
                report.get("delta_confirmed_minus_unconfirmed")
                or {}
            )

            _safe_print(
                "Coorte shadow confirmada: "
                f"n={cohort.get('signals', 0)} | "
                f"win={cohort.get('win_rate_pct', 0)}% | "
                f"TP1={cohort.get('tp1_hit_rate_pct', 0)}% | "
                f"stop={cohort.get('stop_touch_rate_pct', 0)}% | "
                f"retorno={cohort.get('average_last_return_pct', 0)}%"
            )

            _safe_print(
                "Δ confirmados - não confirmados: "
                f"win={float(delta.get('win_rate_pct') or 0):+.2f}pp | "
                f"retorno={float(delta.get('average_last_return_pct') or 0):+.2f}pp | "
                f"TP1={float(delta.get('tp1_hit_rate_pct') or 0):+.2f}pp | "
                f"stop={float(delta.get('stop_touch_rate_pct') or 0):+.2f}pp"
            )

            _safe_print(report["methodology"])
            return 0
        except Exception as exc:
            return _bootstrap_error("signal quality shadow report", exc)

    if args.cmd == "performance-backtest":
        try:
            from csm.performance import PerformanceLedger
            from csm.storage import Storage
            with Storage() as storage:
                result = PerformanceLedger(storage).replay(
                    days=max(1, args.days), min_score=max(0, args.min_score),
                    min_goplus=max(0, args.min_goplus), max_sell_tax=max(0.0, args.max_sell_tax),
                )
            _safe_print("🧪 PERFORMANCE REPLAY v11")
            _safe_print(f"Amostra={result['signals']} | win={result['win_rate_pct']}% | retorno médio={result['average_return_pct']}% | mediana={result['median_return_pct']}%")
            _safe_print(f"TP1={result['tp1_hit_rate_pct']}% | TP2={result['tp2_hit_rate_pct']}% | stop touch={result['stop_touch_rate_pct']}%")
            _safe_print(result['note'])
            return 0
        except Exception as exc:
            return _bootstrap_error("performance replay", exc)

    if args.cmd == "performance-compare":
        try:
            from csm.performance import PerformanceLedger
            from csm.storage import Storage
            with Storage() as storage:
                result = PerformanceLedger(storage).compare_strategies(
                    days=max(1, args.days),
                    strategy_a={"min_score": max(0, args.a_min_score), "min_goplus": max(0, args.a_min_goplus), "max_sell_tax": max(0.0, args.a_max_sell_tax)},
                    strategy_b={"min_score": max(0, args.b_min_score), "min_goplus": max(0, args.b_min_goplus), "max_sell_tax": max(0.0, args.b_max_sell_tax)},
                )
            _safe_print("⚖️ STRATEGY A/B REPLAY v11")
            for label in ("strategy_a", "strategy_b"):
                row = result[label]
                _safe_print(f"{label}: n={row['signals']} | win={row['win_rate_pct']}% | retorno={row['average_return_pct']}% | TP1={row['tp1_hit_rate_pct']}% | stop={row['stop_touch_rate_pct']}%")
            delta = result["delta_b_minus_a"]
            _safe_print(f"Δ B-A: n={delta['signals']:+d} | win={delta['win_rate_pct']:+.2f}pp | retorno={delta['average_return_pct']:+.2f}pp | TP1={delta['tp1_hit_rate_pct']:+.2f}pp | stop={delta['stop_touch_rate_pct']:+.2f}pp")
            _safe_print(result["note"])
            return 0
        except Exception as exc:
            return _bootstrap_error("performance compare", exc)

    if args.cmd == "proof-status":
        try:
            from csm.proof import ProofLedger
            from csm.storage import Storage
            with Storage() as storage:
                proof = ProofLedger(storage)
                proof.seal_due_roots()
                status = proof.status()
            _safe_print("🔐 PROOF OF PERFORMANCE v13")
            _safe_print(f"Sinais provados={status['signal_proofs']} | live_commit={status['live_commits']} | legacy_backfill={status['legacy_backfills']}")
            _safe_print(f"Observações provadas={status['observation_proofs']} | históricos ainda sem prova={status['unproved_legacy_signals']}")
            _safe_print(f"Raízes diárias seladas={status['sealed_daily_roots']} | anchors registrados={status['anchors_registered']}")
            today = status['today_provisional_root']
            _safe_print(f"Raiz UTC de hoje (provisória): eventos={today['event_count']} | {today['root_hash']}")
            _safe_print("live_commit = hash preparado antes do envio Telegram; legacy_backfill = histórico hashado depois, sem alegação retroativa.")
            return 0
        except Exception as exc:
            return _bootstrap_error("proof status", exc)

    if args.cmd == "proof-backfill":
        try:
            from csm.proof import ProofLedger
            from csm.storage import Storage
            with Storage() as storage:
                result = ProofLedger(storage).backfill_legacy(days=max(1, args.days))
            _safe_print("🧾 BACKFILL CRIPTOGRÁFICO v13")
            _safe_print(f"Sinais históricos incorporados={result['signals_backfilled']} | observações={result['observations_backfilled']} | já provados={result['signals_already_proved']}")
            _safe_print("⚠️ Todos os registros importados recebem commit_mode=legacy_backfill; nunca contam como prova pré-resultado.")
            return 0
        except Exception as exc:
            return _bootstrap_error("proof backfill", exc)

    if args.cmd == "proof-verify":
        try:
            import json
            from csm.proof import ProofLedger
            from csm.storage import Storage
            with Storage() as storage:
                proof = ProofLedger(storage)
                proof.seal_due_roots()
                result = proof.verify_signal(args.signal_id) if args.signal_id else proof.verify_all(days=max(1, args.days))
            _safe_print("🔎 PROOF VERIFY v13")
            _safe_print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
            return 0 if result.get("ok") else 1
        except Exception as exc:
            return _bootstrap_error("proof verify", exc)

    if args.cmd == "proof-export":
        try:
            from csm.proof import ProofLedger
            from csm.storage import Storage
            with Storage() as storage:
                proof = ProofLedger(storage)
                proof.seal_due_roots()
                target = proof.export_bundle(days=max(1, args.days), output=args.output)
            _safe_print("✅ Bundle público de Proof of Performance gerado.")
            _safe_print(f"Arquivo: {target}")
            _safe_print("Inclui proofs.json + verificador offline stdlib; não inclui usuários, tokens ou API keys.")
            return 0
        except Exception as exc:
            return _bootstrap_error("proof export", exc)

    if args.cmd == "proof-root":
        try:
            from csm.proof import ProofLedger
            from csm.storage import Storage
            with Storage() as storage:
                proof = ProofLedger(storage)
                if args.seal:
                    if not args.date:
                        _safe_print("❌ --seal exige --date YYYY-MM-DD de um dia UTC já encerrado.")
                        return 2
                    root = proof.seal_root(args.date)
                    _safe_print("🔒 Raiz diária selada e imutável.")
                else:
                    root = proof.current_root(args.date)
                    _safe_print("🌳 Raiz Merkle diária (provisória se o dia ainda não foi selado).")
            _safe_print(json.dumps(root, ensure_ascii=False, indent=2, default=str))
            return 0
        except Exception as exc:
            return _bootstrap_error("proof root", exc)

    if args.cmd == "proof-anchor-register":
        try:
            import json
            from csm.proof import ProofLedger
            from csm.storage import Storage
            with Storage() as storage:
                row = ProofLedger(storage).register_anchor(args.date, chain=args.chain, txid=args.txid, url=args.url)
            _safe_print("⚓ Referência externa registrada para a raiz selada.")
            _safe_print(json.dumps(row, ensure_ascii=False, indent=2, default=str))
            _safe_print("O CSM apenas registra a referência informada; ele não assina nem envia transações blockchain automaticamente.")
            return 0
        except Exception as exc:
            return _bootstrap_error("proof anchor register", exc)

    if args.cmd == "adaptive-report":
        try:
            from csm.performance import PerformanceLedger
            from csm.storage import Storage
            with Storage() as storage:
                report = PerformanceLedger(storage).report(days=3650)
            _safe_print("🧠 ADAPTIVE CONFIDENCE • READ-ONLY")
            _safe_print(f"Histórico observado: {report['signals_observed']} sinais")
            _safe_print(f"Amostra mínima por faixa: {__import__('csm.config', fromlist=['settings']).settings.adaptive_min_samples}")
            _safe_print("O CSM Confidence usa histórico apenas como explicação; final_score, filtros e GoPlus continuam soberanos.")
            for chain, row in sorted(report['by_chain'].items()):
                _safe_print(f"{chain}: n={row['signals']} | win={row['win_rate_pct']}% | TP1={row['tp1_hit_rate_pct']}%")
            return 0
        except Exception as exc:
            return _bootstrap_error("adaptive report", exc)

    if args.cmd == "tenant-create":
        try:
            from csm.saas import SaaSManager
            from csm.storage import Storage
            with Storage() as storage:
                row = SaaSManager(storage).create_tenant(
                    args.name, args.slug, args.brand or "", plan=args.plan, user_id=args.user_id
                )
            _safe_print(f"✅ Tenant criado: {row['slug']} • {row['name']} • plano={row.get('entitlement_plan','free')}")
            return 0
        except Exception as exc:
            return _bootstrap_error("tenant create", exc)

    if args.cmd == "tenant-list":
        try:
            from csm.saas import SaaSManager
            from csm.storage import Storage
            with Storage() as storage:
                rows = SaaSManager(storage).list_tenants()
            _safe_print("🏢 TENANTS SaaS")
            if not rows: _safe_print("Nenhum tenant criado.")
            for row in rows:
                _safe_print(f"{row['slug']} | {row['name']} | status={row['status']} | entitlement={row.get('entitlement_plan','enterprise')}/{row.get('entitlement_status','ACTIVE')} | api_keys={row['api_keys']}")
            return 0
        except Exception as exc:
            return _bootstrap_error("tenant list", exc)

    if args.cmd == "api-key-create":
        try:
            from csm.saas import SaaSManager
            from csm.storage import Storage
            with Storage() as storage:
                row = SaaSManager(storage).create_api_key(args.tenant, name=args.name, rpm=args.rpm, daily=args.daily)
            _safe_print("🔑 API KEY CRIADA — COPIE AGORA; O VALOR COMPLETO NÃO É SALVO EM TEXTO PURO")
            _safe_print(row['api_key'])
            _safe_print(f"Tenant={row['tenant']} | prefixo={row['key_prefix']} | rpm={row['rpm_limit']} | daily={row['daily_limit']}")
            return 0
        except Exception as exc:
            return _bootstrap_error("api key create", exc)

    if args.cmd == "api-key-list":
        try:
            from csm.saas import SaaSManager
            from csm.storage import Storage
            with Storage() as storage:
                rows = SaaSManager(storage).safe_keys(args.tenant)
            _safe_print("🔐 API KEYS (somente prefixos)")
            for row in rows:
                _safe_print(f"{row['tenant']} | {row['name']} | {row['key_prefix']} | ativo={row['active']} | rpm={row['rpm_limit']} | daily={row['daily_limit']} | last={row['last_used_at'] or 'nunca'}")
            return 0
        except Exception as exc:
            return _bootstrap_error("api key list", exc)

    if args.cmd == "api-key-revoke":
        try:
            from csm.saas import SaaSManager
            from csm.storage import Storage
            with Storage() as storage:
                ok = SaaSManager(storage).revoke_key(args.prefix)
            _safe_print("✅ API key revogada." if ok else "⚠️ Prefixo não encontrado.")
            return 0 if ok else 2
        except Exception as exc:
            return _bootstrap_error("api key revoke", exc)

    if args.cmd == "entitlement-set":
        try:
            import json
            from csm.entitlements import EntitlementManager
            from csm.storage import Storage
            with Storage() as storage:
                row = EntitlementManager(storage).set_entitlement(
                    args.tenant, plan=args.plan, status=args.status,
                    expires_at=args.expires_at, grace_until=args.grace_until, source="cli",
                )
            _safe_print(json.dumps(row, ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("entitlement set", exc)

    if args.cmd == "entitlement-status":
        try:
            import json
            from csm.entitlements import EntitlementManager
            from csm.storage import Storage
            with Storage() as storage:
                manager = EntitlementManager(storage)
                row = manager.effective(args.tenant)
                history = manager.history(args.tenant, limit=10)
            if not row:
                _safe_print("⚠️ Tenant não encontrado.")
                return 2
            _safe_print(json.dumps({"entitlement": row, "recent_events": history}, ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("entitlement status", exc)

    if args.cmd == "entitlement-sync":
        try:
            import json
            from csm.entitlements import EntitlementManager
            from csm.storage import Storage
            with Storage() as storage:
                rows = EntitlementManager(storage).sync_from_users(args.tenant)
            _safe_print(json.dumps({"updated": len(rows), "items": rows}, ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("entitlement sync", exc)

    if args.cmd == "tenant-link-user":
        try:
            import json
            from csm.entitlements import EntitlementManager
            from csm.storage import Storage
            with Storage() as storage:
                manager = EntitlementManager(storage)
                manager.link_user(args.tenant, args.user_id)
                rows = manager.sync_from_users(args.tenant)
                row = manager.effective(args.tenant)
            _safe_print(json.dumps({"tenant": row, "synced": bool(rows)}, ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("tenant link user", exc)

    if args.cmd == "portal-info":
        try:
            import json
            from csm.config import settings
            from csm.entitlements import EntitlementManager
            from csm.storage import Storage
            with Storage() as storage:
                entitlement = EntitlementManager(storage).effective(args.tenant)
            _safe_print(json.dumps({
                "enabled": bool(settings.customer_portal_enabled),
                "local_url": f"http://{settings.saas_api_host}:{settings.saas_api_port}/portal",
                "tenant": args.tenant, "entitlement": entitlement,
                "authentication": "Bearer API key; não use chave na URL",
                "note": "saas-api precisa estar em execução",
            }, ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("portal info", exc)

    if args.cmd == "brand-show":
        try:
            import json
            from csm.branding import load_branding
            _safe_print(json.dumps(load_branding(), ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("brand show", exc)

    if args.cmd == "brand-set":
        try:
            import json
            from csm.branding import save_branding
            mapping = {
                'product_name': args.product_name, 'short_name': args.short_name, 'platform_name': args.platform_name,
                'telegram_title': args.telegram_title, 'logo_emoji': args.logo_emoji, 'support_contact': args.support_contact,
                'legal_disclaimer': args.legal_disclaimer,
            }
            updates = {k:v for k,v in mapping.items() if v is not None}
            if not updates:
                _safe_print("Nenhuma alteração informada."); return 2
            _safe_print(json.dumps(save_branding(updates), ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            return _bootstrap_error("brand set", exc)

    if args.cmd == "saas-api":
        try:
            from csm.saas_api import serve_saas_api
            serve_saas_api(args.host, args.port)
            return 0
        except KeyboardInterrupt:
            _safe_print("✅ SaaS API encerrada."); return 0
        except Exception as exc:
            return _bootstrap_error("SaaS API", exc)

    if args.cmd == "acquisition-readiness":
        try:
            from csm.acquisition import acquisition_readiness
            from csm.storage import Storage
            with Storage() as storage:
                report = acquisition_readiness(storage)
            _safe_print("🏆 ACQUISITION READINESS v16.0")
            _safe_print(f"Score: {report['score']}/100 • {report['rating']}")
            for key, value in report['components'].items(): _safe_print(f"{key}: +{value}")
            _safe_print(f"Performance observado: {report['performance']['signals_observed']} sinais")
            _safe_print(f"Security clean: {'sim' if report['security']['clean'] else 'NÃO'}")
            return 0
        except Exception as exc:
            return _bootstrap_error("acquisition readiness", exc)

    if args.cmd == "sale-pack":
        try:
            from csm.acquisition import generate_sale_pack
            from csm.storage import Storage
            with Storage() as storage:
                target = generate_sale_pack(storage, args.output)
            _safe_print(f"📦 Buyer Data Room criado: {target}")
            _safe_print("✅ Sem banco de produção, PII ou credenciais.")
            return 0
        except Exception as exc:
            return _bootstrap_error("sale pack", exc)

    if args.cmd == "scan":
        try:
            from phantom_v10.scanner import ScannerEngine
            sc=ScannerEngine(); rows=sc.run_sync(args.limit,args.chains); _safe_print(f"Descobertos={sc.last_stats['discovered']} analisados={sc.last_stats['analyzed']} aprovados={sc.last_stats['approved']} erros={sc.last_stats['errors']}")
            for i,x in enumerate(rows,1): _safe_print(f"{i:02d}. {x.get('symbol') or x.get('name')} | {x.get('chain')} | score {x.get('opportunity_score') or x.get('score')} | {x.get('address')}")
            return 0
        except Exception as exc: return _bootstrap_error("scan v10",exc)

    if args.cmd == "analyze":
        try:
            from csm.chains import normalize_chain,detect_chain
            from csm.formatting import report
            from phantom_v10.market import MarketService
            chain=normalize_chain(args.chain) if args.chain else detect_chain(args.address)
            if not chain: _safe_print("Rede não reconhecida."); return 2
            market=MarketService().fetch(chain,args.address); text,_=report(market,args.plan)
            for tag in ("<b>","</b>","<i>","</i>","<code>","</code>"): text=text.replace(tag,"")
            _safe_print(text); return 0
        except Exception as exc: return _bootstrap_error("analyze v10",exc)

    if args.cmd == "bot":
        guard = None
        app = None
        clean_stop = False
        try:
            from phantom_v10.runtime import AlreadyRunningError, RuntimeGuard
            from phantom_v10.app import PhantomApp
            guard = RuntimeGuard("bot")
            event = guard.acquire()
            if event.recovered:
                _safe_print(f"♻️ Runtime recuperou sessão obsoleta automaticamente: {event.reason}")
            app = PhantomApp()
            app.run(guard=guard)
            clean_stop = True
            return 0
        except AlreadyRunningError as exc:
            _safe_print(f"⚠️ {exc}")
            return 3
        except KeyboardInterrupt:
            # Last-resort path if the interrupt lands outside PhantomApp.run.
            # Do not re-raise through the embedded a-Shell interpreter.
            if app is not None:
                app.request_shutdown("Ctrl+C externo")
            _safe_print("🛑 Ctrl+C recebido; encerrando sem propagar KeyboardInterrupt.")
            clean_stop = True
            return 130
        except Exception as exc:
            if "401" in str(exc):
                _safe_print("❌ Token Telegram inválido (HTTP 401). Execute: python main.py setup")
                return 1
            return _bootstrap_error("bot v16.0.0", exc)
        finally:
            if app is not None:
                app.close()
            if guard is not None:
                guard.release(state="stopped" if clean_stop else "crashed")

    return 0


# Legacy audit markers retained so historical v9 regression tests remain meaningful:
# phantom_v9.app_v902 phantom_v9.runtime_v902
# from phantom_v9.runtime_v902 import RuntimeGuardV902, AlreadyRunningError
# guard=RuntimeGuardV902("bot")

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        _safe_print("Encerrado.")
        raise SystemExit(130)
