"""Administrative compatibility facade."""
from csm.admin_web import serve_admin_web

__all__ = ["serve_admin_web"]
