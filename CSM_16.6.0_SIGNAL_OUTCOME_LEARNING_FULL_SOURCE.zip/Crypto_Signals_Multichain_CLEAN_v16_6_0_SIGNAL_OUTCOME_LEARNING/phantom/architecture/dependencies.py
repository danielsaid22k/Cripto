from __future__ import annotations

import ast
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class ModuleDependency:
    module: str
    imports: tuple[str, ...]
    lines: int


@dataclass(frozen=True)
class ArchitectureAudit:
    modules: tuple[ModuleDependency, ...]
    duplicate_basenames: tuple[str, ...]
    oversized_modules: tuple[str, ...]
    cleanup_candidates: tuple[str, ...]

    def to_dict(self) -> dict:
        return {
            "modules": [asdict(item) for item in self.modules],
            "duplicate_basenames": list(self.duplicate_basenames),
            "oversized_modules": list(self.oversized_modules),
            "cleanup_candidates": list(self.cleanup_candidates),
        }


def _python_files(base_dir: Path) -> Iterable[Path]:
    for root in (base_dir / "csm", base_dir / "phantom"):
        if root.exists():
            yield from sorted(root.rglob("*.py"))
    for path in (base_dir / "main.py", base_dir / "launcher.py", base_dir / "validate.py"):
        if path.exists():
            yield path


def audit_architecture(base_dir: Path) -> ArchitectureAudit:
    modules: list[ModuleDependency] = []
    basenames: dict[str, list[str]] = {}
    cleanup: list[str] = []
    oversized: list[str] = []

    for path in _python_files(base_dir):
        relative = path.relative_to(base_dir).as_posix()
        source = path.read_text(encoding="utf-8", errors="replace")
        line_count = source.count("\n") + 1
        if line_count > 900:
            oversized.append(relative)
        imports: set[str] = set()
        try:
            tree = ast.parse(source, filename=relative)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports.update(alias.name for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imports.add(node.module)
        except SyntaxError:
            cleanup.append(f"syntax-error:{relative}")
        modules.append(ModuleDependency(relative, tuple(sorted(imports)), line_count))
        basenames.setdefault(path.name, []).append(relative)

    duplicate_basenames = tuple(
        f"{name}: {', '.join(paths)}"
        for name, paths in sorted(basenames.items())
        if len(paths) > 1 and name != "__init__.py"
    )

    for pattern in ("*.pyc", "*.pyo", "*.log", "*.tmp", "*.bak"):
        cleanup.extend(path.relative_to(base_dir).as_posix() for path in base_dir.rglob(pattern))
    cleanup.extend(path.relative_to(base_dir).as_posix() for path in base_dir.rglob("__pycache__"))
    cleanup.extend(path.relative_to(base_dir).as_posix() for path in base_dir.rglob(".pytest_cache"))

    return ArchitectureAudit(
        modules=tuple(modules),
        duplicate_basenames=duplicate_basenames,
        oversized_modules=tuple(sorted(oversized)),
        cleanup_candidates=tuple(sorted(set(cleanup))),
    )


def save_architecture_audit(base_dir: Path, target: Path) -> Path:
    audit = audit_architecture(base_dir)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(audit.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return target
