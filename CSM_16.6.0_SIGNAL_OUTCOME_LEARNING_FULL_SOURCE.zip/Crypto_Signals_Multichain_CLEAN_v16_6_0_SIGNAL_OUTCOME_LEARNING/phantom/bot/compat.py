"""Telegram compatibility facade; no callback behavior is changed in RC1."""
from csm.telegram import Telegram

__all__ = ["Telegram"]
