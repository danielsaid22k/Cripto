from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from csm.config import settings


@dataclass(frozen=True)
class ConfigurationSnapshot:
    environment: str
    data_dir: str
    database: str
    telegram_configured: bool
    telegram_chat_configured: bool
    asaas_enabled: bool
    asaas_configured: bool
    monthly_duration_days: int
    annual_duration_days: int
    scanner_intervals: dict[str, int]
    persistent_config: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ConfigurationManager:
    """Read-only facade over the proven LTS configuration layer.

    The manager deliberately does not migrate secrets to new JSON files. The
    persistent ``config.env`` remains the source of truth, so upgrades preserve
    Telegram, APIs, wallets and other existing settings.
    """

    def snapshot(self) -> ConfigurationSnapshot:
        persistent_config = Path(settings.data_dir) / "config.env"
        return ConfigurationSnapshot(
            environment=str(settings.app_environment),
            data_dir=str(settings.data_dir),
            database=str(settings.db_file),
            telegram_configured=bool(settings.telegram_token),
            telegram_chat_configured=bool(settings.telegram_chat_id),
            asaas_enabled=bool(settings.asaas_enabled),
            asaas_configured=bool(settings.payments_ready),
            monthly_duration_days=int(settings.plan_monthly_duration_days),
            annual_duration_days=int(settings.plan_annual_duration_days),
            scanner_intervals={
                "free": int(settings.auto_scan_interval_free),
                "plus": int(settings.auto_scan_interval_plus),
                "premium": int(settings.auto_scan_interval_premium),
            },
            persistent_config=str(persistent_config),
        )

    def validate(self) -> list[str]:
        errors: list[str] = []
        snap = self.snapshot()
        if snap.monthly_duration_days <= 0:
            errors.append("duração mensal inválida")
        if snap.annual_duration_days <= 0:
            errors.append("duração anual inválida")
        if any(value <= 0 for value in snap.scanner_intervals.values()):
            errors.append("intervalo do scanner inválido")
        if snap.asaas_enabled and not snap.asaas_configured:
            errors.append("Asaas habilitado com configuração incompleta")
        return errors


configuration_manager = ConfigurationManager()
