from __future__ import annotations

import json
import os
import shutil
import tempfile
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class RecoveryReport:
    source: str | None
    destination: str
    action: str
    restored_keys: tuple[str, ...]
    kept_keys: tuple[str, ...]
    warnings: tuple[str, ...]

    def to_dict(self) -> dict:
        return asdict(self)


def _parse_env_text(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key:
            values[key] = value.strip()
    return values


def _serialize_env(values: dict[str, str]) -> str:
    return "".join(f"{key}={value}\n" for key, value in values.items())


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _state_dir() -> Path:
    base = _project_root()
    raw = os.getenv("CSM_STATE_DIR", "").strip()
    if raw:
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = base.parent / candidate
        return candidate.resolve()
    return (base.parent / "Crypto_Signals_Multichain_State").resolve()



def _backup_has_usable_secrets(values: dict[str, str]) -> bool:
    """Reject release/test backups that were flagged as secret but contain no real credentials."""
    telegram = values.get("TELEGRAM_BOT_TOKEN", "").strip()
    asaas = values.get("ASAAS_API_KEY", "").strip()
    if not telegram and not asaas:
        return False
    if asaas:
        env = values.get("ASAAS_ENVIRONMENT", "sandbox").strip().lower() or "sandbox"
        enabled = values.get("ASAAS_ENABLED", "false").strip().lower() in {"1","true","yes","on","sim"}
        if enabled and env not in {"sandbox", "production"}:
            return False
    return True

def _candidate_backups() -> Iterable[Path]:
    base = _project_root()
    roots = [base / "backups", base.parent]
    seen: set[Path] = set()
    patterns = (
        "ultimo_backup.zip",
        "CryptoSignals_*_backup_*.zip",
        "Crypto_Signals_Multichain_CLEAN_v*/backups/ultimo_backup.zip",
        "Crypto_Signals_Multichain_CLEAN_v*/backups/CryptoSignals_*_backup_*.zip",
    )
    for root in roots:
        for pattern in patterns:
            try:
                items = root.glob(pattern)
            except OSError:
                continue
            for item in items:
                try:
                    resolved = item.resolve()
                    if resolved in seen or not resolved.is_file():
                        continue
                    seen.add(resolved)
                    with zipfile.ZipFile(resolved, "r") as archive:
                        if "state/config.env" not in archive.namelist():
                            continue
                        if archive.testzip() is not None:
                            continue
                        manifest = json.loads(archive.read("backup_manifest.json").decode("utf-8"))
                        if not manifest.get("includes_secrets"):
                            continue
                        values = _parse_env_text(archive.read("state/config.env").decode("utf-8"))
                        if not _backup_has_usable_secrets(values):
                            continue
                    yield resolved
                except Exception:
                    continue


def _newest_secret_backup() -> Path | None:
    candidates = list(_candidate_backups())
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def _read_backup_env(path: Path) -> dict[str, str]:
    with zipfile.ZipFile(path, "r") as archive:
        return _parse_env_text(archive.read("state/config.env").decode("utf-8"))


def recover_persistent_config(*, merge_missing: bool = True) -> RecoveryReport:
    """Recupera configurações sem sobrescrever valores atuais válidos.

    - Se config.env não existir, restaura do backup mais recente com segredos.
    - Se existir, apenas preenche chaves ausentes/vazias quando merge_missing=True.
    - Nunca substitui uma chave atual não vazia.
    """
    state = _state_dir()
    destination = state / "config.env"
    destination.parent.mkdir(parents=True, exist_ok=True)

    current: dict[str, str] = {}
    if destination.is_file():
        try:
            current = _parse_env_text(destination.read_text(encoding="utf-8"))
        except OSError:
            current = {}

    source = _newest_secret_backup()
    if source is None:
        return RecoveryReport(None, str(destination), "nenhum-backup-com-segredos", (), tuple(sorted(current)), ("nenhum backup com state/config.env localizado",))

    backup_values = _read_backup_env(source)
    merged = dict(current)
    restored: list[str] = []
    kept: list[str] = []
    warnings: list[str] = []
    for key, value in backup_values.items():
        if key in merged and merged[key].strip():
            kept.append(key)
            continue
        if not merge_missing and current:
            continue
        if value.strip():
            if key == "BIRDEYE_API_KEY":
                try:
                    from csm.credential_audit import recovery_secret_allowed
                    allowed, reason = recovery_secret_allowed(key, value, state)
                except Exception:
                    allowed, reason = True, "credential-governance-unavailable"
                if not allowed:
                    warnings.append(f"BIRDEYE_API_KEY histórica não restaurada automaticamente ({reason})")
                    continue
            merged[key] = value
            restored.append(key)

    if not current:
        action = "restaurado"
    elif restored:
        action = "mesclado-sem-sobrescrever"
    else:
        action = "configuração-atual-preservada"

    if restored or not destination.exists():
        fd, temp_name = tempfile.mkstemp(prefix="config_v822_", suffix=".env", dir=str(destination.parent))
        os.close(fd)
        temp = Path(temp_name)
        try:
            temp.write_text(_serialize_env(merged), encoding="utf-8")
            os.replace(temp, destination)
            try:
                os.chmod(destination, 0o600)
            except OSError:
                pass
        finally:
            temp.unlink(missing_ok=True)

    # cópia local é apenas compatibilidade; também não sobrescreve um .env atual.
    local = _project_root() / ".env"
    if destination.is_file() and not local.exists():
        shutil.copy2(destination, local)
        try:
            os.chmod(local, 0o600)
        except OSError:
            pass

    return RecoveryReport(str(source), str(destination), action, tuple(sorted(restored)), tuple(sorted(kept)), tuple(warnings))
