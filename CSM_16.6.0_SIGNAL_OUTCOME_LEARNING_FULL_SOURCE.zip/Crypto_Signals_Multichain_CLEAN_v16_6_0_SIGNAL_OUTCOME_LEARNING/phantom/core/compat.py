"""Compatibility facade for the frozen LTS core.

New platform modules import services through this file instead of moving or
renaming proven ``csm`` modules during the Foundation sprint.
"""
from csm.config import settings
from csm.scanner import MultichainScanner
from csm.storage import Storage

__all__ = ["settings", "MultichainScanner", "Storage"]
