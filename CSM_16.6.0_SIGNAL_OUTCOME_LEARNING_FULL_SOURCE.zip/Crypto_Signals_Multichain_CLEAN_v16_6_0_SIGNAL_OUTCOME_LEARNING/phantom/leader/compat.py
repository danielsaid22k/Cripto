"""Project Leader compatibility facade."""
from csm.project_leader import ProjectLeader

__all__ = ["ProjectLeader"]
