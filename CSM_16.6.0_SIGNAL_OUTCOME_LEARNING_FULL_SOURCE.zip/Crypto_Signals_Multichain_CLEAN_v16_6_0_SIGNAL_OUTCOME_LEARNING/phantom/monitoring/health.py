from __future__ import annotations

import json
import os
import resource
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csm.backup_manager import newest_backup
from csm.config import settings
from csm.release_ops import health_dashboard

from phantom.config.manager import configuration_manager

_STARTED_AT = time.monotonic()


@dataclass(frozen=True)
class FoundationHealth:
    generated_at: str
    uptime_seconds: int
    memory_max_rss: int
    process_id: int
    configuration_errors: tuple[str, ...]
    runtime: dict[str, Any]
    latest_backup: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_foundation_health() -> FoundationHealth:
    runtime = health_dashboard()
    backup = newest_backup()
    return FoundationHealth(
        generated_at=datetime.now(timezone.utc).isoformat(),
        uptime_seconds=max(0, int(time.monotonic() - _STARTED_AT)),
        memory_max_rss=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
        process_id=os.getpid(),
        configuration_errors=tuple(configuration_manager.validate()),
        runtime=runtime,
        latest_backup=str(backup) if backup else None,
    )


def save_foundation_health(target: Path | None = None) -> Path:
    target = target or (settings.data_dir / "reports" / "foundation_health.json")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(build_foundation_health().to_dict(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return target
