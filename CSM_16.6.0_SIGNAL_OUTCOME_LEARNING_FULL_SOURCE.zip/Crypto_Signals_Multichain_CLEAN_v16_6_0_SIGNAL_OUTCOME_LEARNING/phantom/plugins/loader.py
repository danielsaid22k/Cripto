from __future__ import annotations

import json
from pathlib import Path

from .registry import PluginManifest, PluginRegistry, plugin_registry


def discover_manifests(directory: Path) -> tuple[Path, ...]:
    if not directory.exists():
        return ()
    return tuple(sorted(directory.glob("*/plugin.json")))


def load_manifests(directory: Path, registry: PluginRegistry = plugin_registry) -> tuple[PluginManifest, ...]:
    loaded: list[PluginManifest] = []
    for path in discover_manifests(directory):
        payload = json.loads(path.read_text(encoding="utf-8"))
        manifest = PluginManifest(
            name=str(payload["name"]),
            version=str(payload["version"]),
            entrypoint=str(payload["entrypoint"]),
            enabled=bool(payload.get("enabled", False)),
            description=str(payload.get("description", "")),
        )
        registry.register(manifest)
        loaded.append(manifest)
    return tuple(loaded)
