from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class PluginManifest:
    name: str
    version: str
    entrypoint: str
    enabled: bool = False
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class PluginRegistry:
    def __init__(self) -> None:
        self._manifests: dict[str, PluginManifest] = {}
        self._factories: dict[str, Callable[[], Any]] = {}

    def register(self, manifest: PluginManifest, factory: Callable[[], Any] | None = None) -> None:
        if not manifest.name or not manifest.version or not manifest.entrypoint:
            raise ValueError("manifesto de plugin incompleto")
        if manifest.name in self._manifests:
            raise ValueError(f"plugin duplicado: {manifest.name}")
        self._manifests[manifest.name] = manifest
        if factory is not None:
            self._factories[manifest.name] = factory

    def manifests(self) -> tuple[PluginManifest, ...]:
        return tuple(self._manifests[name] for name in sorted(self._manifests))

    def enabled(self) -> tuple[PluginManifest, ...]:
        return tuple(item for item in self.manifests() if item.enabled)

    def create(self, name: str) -> Any:
        manifest = self._manifests.get(name)
        if manifest is None:
            raise KeyError(name)
        if not manifest.enabled:
            raise RuntimeError(f"plugin desativado: {name}")
        factory = self._factories.get(name)
        if factory is None:
            raise RuntimeError(f"plugin sem factory: {name}")
        return factory()


plugin_registry = PluginRegistry()
