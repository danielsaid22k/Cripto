from __future__ import annotations

import compileall
import json
import shutil
import sqlite3
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csm import __version__
from csm.backup_manager import newest_backup, validate_backup
from csm.config import settings
from csm.release_ops import run_quality_gate
from csm.security import verify_file

from phantom.architecture.dependencies import audit_architecture
from phantom.config.manager import configuration_manager

LTS_BASE = "6.3.0"


@dataclass(frozen=True)
class ReleaseCheck:
    name: str
    passed: bool
    details: str


@dataclass(frozen=True)
class FoundationReleaseReport:
    generated_at: str
    version: str
    lts_base: str
    passed: bool
    checks: tuple[ReleaseCheck, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "version": self.version,
            "lts_base": self.lts_base,
            "passed": self.passed,
            "checks": [asdict(check) for check in self.checks],
        }


@dataclass(frozen=True)
class CleanupReport:
    removed: tuple[str, ...]

    @property
    def count(self) -> int:
        return len(self.removed)


def _check(name: str, passed: bool, details: str) -> ReleaseCheck:
    return ReleaseCheck(name, bool(passed), str(details))


def clean_build_artifacts(base_dir: Path | None = None) -> CleanupReport:
    """Remove somente artefatos descartáveis de build/teste.

    Nunca toca em banco, config.env, .env, backups, logs operacionais ou dados
    persistentes. É seguro executar antes/depois do pipeline de release.
    """
    base = (base_dir or settings.base_dir).resolve()
    removed: list[str] = []
    dir_names = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "htmlcov"}
    file_names = {".coverage", "coverage.xml"}

    for path in sorted(base.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        try:
            rel = path.relative_to(base).as_posix()
        except ValueError:
            continue
        if path.is_dir() and path.name in dir_names:
            shutil.rmtree(path, ignore_errors=True)
            removed.append(rel)
        elif path.is_file() and (path.name in file_names or path.suffix in {".pyc", ".pyo"}):
            try:
                path.unlink()
                removed.append(rel)
            except FileNotFoundError:
                pass
    return CleanupReport(tuple(sorted(set(removed))))


def _quality_gate_details(report) -> str:
    failed = [item for item in report.items if item.critical and not item.passed]
    if not failed:
        return f"itens={len(report.items)}; aprovado"
    details = "; ".join(f"{item.name}: {item.details}" for item in failed[:4])
    return f"itens={len(report.items)}; bloqueios={details}"


def run_foundation_release(*, run_tests: bool = False) -> FoundationReleaseReport:
    checks: list[ReleaseCheck] = []
    cleanup_before = clean_build_artifacts()
    checks.append(_check("Limpeza pré-release", True, f"artefatos removidos={cleanup_before.count}"))

    compiled = compileall.compile_dir(str(settings.base_dir), quiet=1)
    checks.append(_check("Compilação", compiled, "compileall"))
    # compileall gera __pycache__; eles não pertencem ao pacote validado.
    clean_build_artifacts()

    lts_file = settings.base_dir / "LTS_FREEZE.json"
    lts_ok = False
    lts_details = "ausente"
    if lts_file.exists():
        try:
            payload = json.loads(lts_file.read_text(encoding="utf-8"))
            encoded = json.dumps(payload, ensure_ascii=False)
            lts_ok = LTS_BASE in encoded
            lts_details = f"base={LTS_BASE}; manifesto={lts_file.name}"
        except Exception as exc:
            lts_details = f"inválido: {exc}"
    checks.append(_check("Contrato LTS", lts_ok, lts_details))

    config_errors = configuration_manager.validate()
    checks.append(_check("Configuração", not config_errors, "; ".join(config_errors) or "ok"))

    architecture = audit_architecture(settings.base_dir)
    checks.append(_check(
        "Arquitetura analisável",
        not any(item.startswith("syntax-error:") for item in architecture.cleanup_candidates),
        f"módulos={len(architecture.modules)}; grandes={len(architecture.oversized_modules)}",
    ))

    legacy_gate = run_quality_gate(compile_code=False)
    checks.append(_check("Quality Gate existente", legacy_gate.passed, _quality_gate_details(legacy_gate)))

    if run_tests:
        completed = subprocess.run(
            [sys.executable, "-m", "pytest", "-q"],
            cwd=settings.base_dir,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
        output = (completed.stdout + completed.stderr).strip().splitlines()
        tail = next((line for line in reversed(output) if "passed" in line or "failed" in line or "error" in line.lower()), output[-1] if output else "sem saída")
        checks.append(_check("Testes", completed.returncode == 0, tail))
        # pytest cria .pytest_cache; a release não deve exigir limpeza manual.
        cleanup_after = clean_build_artifacts()
        checks.append(_check("Limpeza pós-testes", True, f"artefatos removidos={cleanup_after.count}"))

    passed = all(item.passed for item in checks)
    return FoundationReleaseReport(
        generated_at=datetime.now(timezone.utc).isoformat(),
        version=__version__,
        lts_base=LTS_BASE,
        passed=passed,
        checks=tuple(checks),
    )


def save_foundation_release(
    target: Path | None = None,
    *,
    run_tests: bool = False,
    report: FoundationReleaseReport | None = None,
) -> Path:
    target = target or (settings.data_dir / "reports" / "foundation_release.json")
    target.parent.mkdir(parents=True, exist_ok=True)
    final_report = report or run_foundation_release(run_tests=run_tests)
    target.write_text(json.dumps(final_report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def _database_summary() -> dict[str, Any]:
    db = settings.db_file
    if not db.exists():
        return {"integrity": "ausente", "schema": 0, "path": str(db)}
    try:
        with sqlite3.connect(db) as conn:
            integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0])
            schema = int(conn.execute("PRAGMA user_version").fetchone()[0])
        return {"integrity": integrity, "schema": schema, "path": str(db)}
    except sqlite3.Error as exc:
        return {"integrity": f"erro: {exc}", "schema": 0, "path": str(db)}


def _backup_summary() -> dict[str, Any]:
    backup = newest_backup()
    if backup is None:
        return {"status": "não localizado", "path": None}
    try:
        manifest = validate_backup(backup)
        verification = verify_file(backup, require_signature=False)
        ok = bool(verification.get("ok"))
        return {
            "status": "válido" if ok else "inválido",
            "path": str(backup),
            "signed": bool(verification.get("signed")),
            "database_included": bool(manifest.get("database_included")),
            "includes_secrets": bool(manifest.get("includes_secrets")),
        }
    except Exception as exc:
        return {"status": f"erro: {exc}", "path": str(backup)}


def build_release_summary() -> dict[str, Any]:
    clean_build_artifacts()
    foundation_file = settings.data_dir / "reports" / "foundation_release.json"
    foundation: dict[str, Any] = {}
    if foundation_file.exists():
        try:
            foundation = json.loads(foundation_file.read_text(encoding="utf-8"))
        except Exception:
            foundation = {}

    test_check = next((item for item in foundation.get("checks", []) if item.get("name") == "Testes"), None)
    foundation_ok = bool(foundation.get("passed"))
    db = _database_summary()
    backup = _backup_summary()
    db_ok = db.get("integrity") == "ok" and int(db.get("schema", 0)) > 0
    tests_ok = bool(test_check and test_check.get("passed"))
    # Backup é recomendado; sua ausência não invalida uma instalação nova.
    backup_ok = backup.get("status") in {"válido", "não localizado"}
    final_ok = foundation_ok and db_ok and tests_ok and backup_ok
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "version": __version__,
        "lts_base": LTS_BASE,
        "database": db,
        "backup": backup,
        "tests": {
            "status": "APROVADO" if tests_ok else "PENDENTE/BLOQUEADO",
            "details": str(test_check.get("details")) if test_check else "nenhum resultado de testes salvo",
        },
        "foundation_release": {
            "status": "APROVADO" if foundation_ok else "PENDENTE/BLOQUEADO",
            "report": str(foundation_file),
        },
        "status": "APROVADO" if final_ok else "BLOQUEADO",
    }


def save_release_summary(payload: dict[str, Any] | None = None, target: Path | None = None) -> Path:
    target = target or (settings.data_dir / "reports" / "release_summary.json")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload or build_release_summary(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return target
