from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from csm.config import settings
from .engine_v822 import (
    FoundationReleaseReport, ReleaseCheck, build_release_summary as _build_summary,
    clean_build_artifacts, run_foundation_release as _run_v822,
    save_foundation_release, save_release_summary,
)

RECEIPT = settings.data_dir / "reports" / "test_receipt_v823.json"


def _fingerprint() -> str:
    digest = hashlib.sha256()
    roots = [settings.base_dir / "csm", settings.base_dir / "phantom", settings.base_dir / "tests", settings.base_dir / "main.py"]
    files: list[Path] = []
    for root in roots:
        if root.is_file():
            files.append(root)
        elif root.exists():
            files.extend(p for p in root.rglob("*.py") if "__pycache__" not in p.parts)
    for path in sorted(files, key=lambda p: str(p.relative_to(settings.base_dir))):
        digest.update(str(path.relative_to(settings.base_dir)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def run_release_tests() -> dict[str, Any]:
    """Executa a mesma suíte direta e grava recibo vinculado ao código atual."""
    import contextlib
    import io
    import os
    import pytest

    clean_build_artifacts()
    previous = Path.cwd()
    stream = io.StringIO()
    try:
        os.chdir(settings.base_dir)
        with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
            code = int(pytest.main(["-q", str(settings.base_dir / "tests")]))
    finally:
        os.chdir(previous)
    output = stream.getvalue().strip()
    lines = output.splitlines()
    summary = next((line.strip() for line in reversed(lines) if " passed" in line or " failed" in line or " error" in line.lower()), lines[-1].strip() if lines else "sem saída")
    receipt = {"ok": code == 0, "summary": summary, "fingerprint": _fingerprint(), "output": output}
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    clean_build_artifacts()
    return receipt


def run_foundation_release(*, run_tests: bool = True) -> FoundationReleaseReport:
    """Release Engine v8.2.3 com recibo determinístico de testes.

    Evita divergência entre uma execução manual aprovada e uma segunda execução
    interna em estado diferente. Se o código mudou, o fingerprint invalida o recibo
    e a suíte é executada novamente.
    """
    receipt: dict[str, Any] | None = None
    try:
        if RECEIPT.exists():
            candidate = json.loads(RECEIPT.read_text(encoding="utf-8"))
            if candidate.get("fingerprint") == _fingerprint() and candidate.get("ok"):
                receipt = candidate
    except Exception:
        receipt = None
    if run_tests and receipt is None:
        receipt = run_release_tests()

    report = _run_v822(run_tests=False)
    checks = list(report.checks)
    if run_tests:
        checks.append(ReleaseCheck("Testes", bool(receipt and receipt.get("ok")), str((receipt or {}).get("summary") or "sem recibo")))
        checks.append(ReleaseCheck("Recibo de testes", bool(receipt and receipt.get("fingerprint") == _fingerprint()), "fingerprint do código validado"))
    passed = all(item.passed for item in checks)
    return FoundationReleaseReport(
        generated_at=report.generated_at,
        version=report.version,
        lts_base=report.lts_base,
        passed=passed,
        checks=tuple(checks),
        test_output=str((receipt or {}).get("output") or ""),
    )


def build_release_summary() -> dict[str, Any]:
    return _build_summary()
