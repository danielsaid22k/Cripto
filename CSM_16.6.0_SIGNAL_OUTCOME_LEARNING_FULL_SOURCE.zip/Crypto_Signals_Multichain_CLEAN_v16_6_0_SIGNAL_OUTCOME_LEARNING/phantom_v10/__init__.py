"""Phantom Alert v10 coherent runtime.

The v10 runtime intentionally keeps persistence/domain compatibility in ``csm``
while replacing the operational network, Telegram, scanner, scheduler and
runtime layers with one explicit dependency graph.
"""

__version__ = "16.6.0-retool-admin-speechify"
