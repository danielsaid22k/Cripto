from __future__ import annotations

import json
import signal
import time
from datetime import datetime, timezone
from html import escape

from csm.chains import CHAINS
from csm.config import settings
from csm.formatting import compact_address, score_market
from csm.plans import PLANS, base_plan
from csm.storage import Storage
from csm.user_profiles import UserProfileStore

from .auto_delivery import AutomaticSignalDelivery
from .errors import TelegramAPIError, TransientNetworkError
from .market import MarketService
from .payments import AsaasClient, PaymentService
from .performance_monitor import PerformanceMonitor
from .onchain_monitor import OnChainMonitor
from .providers import ProviderGateway
from .presentation import (
    BRAND_DIVIDER,
    buy_pressure,
    format_price,
    history_time,
    market_report,
    position_alert,
    risk_profile,
    token_identity,
)
from .runtime import RuntimeGuard
from .scanner import ScannerEngine
from .scheduler import Scheduler
from .telegram import TelegramClient
from .transport import StdlibHttpTransport, global_network_bus
from .ui import screens as ui


class PhantomApp:
    """Top-level v10 composition root.

    This is the only module that wires concrete implementations together. The
    router owns interactions, scheduler owns timing, scanner owns discovery,
    market owns provider normalization, and transport owns HTTPS.
    """

    def __init__(self, storage=None, telegram=None, base_transport=None):
        self.storage = storage or Storage()
        self.observability = None
        if settings.observability_enabled:
            try:
                from csm.observability import ObservabilityEngine
                self.observability = ObservabilityEngine(self.storage)
            except Exception as exc:
                print(f"⚠️ observability indisponível: {type(exc).__name__}: {exc}", flush=True)
        self.network_bus = global_network_bus()
        self.base_transport = base_transport or StdlibHttpTransport(timeout=6.0, bus=self.network_bus, label="base")
        self.telegram_transport = self.base_transport.clone(label="telegram", timeout=6.0)
        self.market_transport = self.base_transport.clone(label="market", timeout=3.0)
        self.scanner_transport = self.base_transport.clone(label="scanner", timeout=2.5)
        self._telegram_injected = telegram is not None
        self.telegram = telegram or (TelegramClient(transport=self.telegram_transport) if settings.telegram_token else None)
        self.providers = ProviderGateway()
        self.market = MarketService(transport=self.market_transport, providers=self.providers)
        self.scanner = ScannerEngine(transport=self.scanner_transport, providers=self.providers)
        self.reputation_engine = None
        if settings.reputation_enabled:
            try:
                from csm.reputation import ReputationEngine
                self.reputation_engine = ReputationEngine(self.storage)
                # Small bounded local consolidation at startup; no network I/O.
                self.reputation_engine.refresh(days=3650, limit=min(250, int(settings.reputation_refresh_limit)))
                self.scanner.reputation_engine = self.reputation_engine
            except Exception as exc:
                self.log_warning(f"reputation engine indisponível: {type(exc).__name__}: {exc}")
        if settings.adaptive_confidence_enabled:
            try:
                from csm.performance import HistoricalConfidenceModel
                self.scanner.confidence_model = HistoricalConfidenceModel(self.storage)
            except Exception as exc:
                self.log_warning(f"historical confidence indisponível: {type(exc).__name__}: {exc}")
        self.performance_monitor = PerformanceMonitor(self.storage, self.base_transport, self.providers) if settings.performance_ledger_enabled else None
        self.onchain_monitor = OnChainMonitor(self.storage, self.base_transport) if settings.onchain_enabled else None
        self.distribution = None
        if settings.distribution_enabled:
            try:
                from csm.distribution import DistributionManager
                self.distribution = DistributionManager(self.storage, self.base_transport, self.observability)
            except Exception as exc:
                self.log_warning(f"distribution platform indisponível: {type(exc).__name__}: {exc}")
        self.user_profiles = UserProfileStore()
        self.auto_delivery = AutomaticSignalDelivery(
            storage=self.storage,
            telegram=self.telegram,
            user_profiles=self.user_profiles,
            warning_logger=self.log_warning,
            distribution=self.distribution,
        )
        self.payments = None
        if settings.payments_ready:
            try:
                asaas_transport = self.base_transport.clone(
                    label="asaas",
                    timeout=6.0,
                    headers={"access_token": settings.asaas_api_key, "Content-Type": "application/json"},
                )
                self.payments = PaymentService(self.storage, client=AsaasClient(transport=asaas_transport))
            except Exception as exc:
                self.log_warning(f"Asaas não inicializado: {type(exc).__name__}: {exc}")
        self.pending_payment: dict[int, dict] = {}
        self.scanner_sessions: dict[int, list[dict]] = {}
        self.started_at = datetime.now(timezone.utc)
        self.scheduler = Scheduler(self)
        from .router import InteractionRouter
        self.router = InteractionRouter(self)
        self._last_network_notice = 0.0
        self.shutdown_requested = False
        self.shutdown_reason = ""
        self._closed = False
        # Telegram only confirms an update after a later getUpdates call uses
        # an offset greater than that update_id. Persist the next offset so a
        # shutdown command cannot replay on the next a-Shell process.
        self.telegram_offset_file = self.storage.path.parent / "runtime" / "v10" / ".telegram.offset.json"

    @staticmethod
    def log_warning(message: str) -> None:
        print(f"⚠️ {message}", flush=True)

    def request_shutdown(self, reason: str = "requested") -> None:
        """Ask the cooperative event loop to stop at the next safe boundary."""
        if self.shutdown_requested:
            return
        self.shutdown_requested = True
        self.shutdown_reason = str(reason or "requested")[:120]

    def notify_operational_incidents(self) -> int:
        """Best-effort admin alert for HIGH/CRITICAL local incidents.

        The existing Telegram channel is reused; no webhook/public listener is
        introduced. Alerts are cooldown-protected and only emitted from a safe
        cooperative point after scanner work has completed.
        """
        if not settings.observability_admin_alerts or self.observability is None or self.telegram is None:
            return 0
        try:
            rows = self.observability.notification_candidates(
                cooldown_seconds=settings.observability_admin_alert_cooldown, limit=5
            )
        except Exception:
            return 0
        if not rows:
            return 0
        recipients = set(settings.admin_ids or set())
        try:
            configured = int(str(settings.telegram_chat_id).strip())
            if configured > 0:
                recipients.add(configured)
        except Exception:
            pass
        if not recipients:
            return 0
        lines = ["🚨 <b>CSM OPERATIONS • V14.5</b>", ""]
        for row in rows:
            sev = escape(str(row.get("severity") or "HIGH"))
            component = escape(str(row.get("component") or "system").upper())
            summary = escape(str(row.get("summary") or "incidente operacional"))
            lines.append(f"• <b>{sev}</b> [{component}] {summary}")
        lines += ["", "ℹ️ Diagnóstico local; sem webhook público. Use <code>observability-status</code> e <code>observability-incidents</code> para detalhes."]
        text = "\n".join(lines)
        sent = 0
        for uid in sorted(recipients):
            try:
                self.telegram.send(int(uid), text)
                sent += 1
            except Exception as exc:
                self.log_warning(f"alerta operacional não entregue admin={uid}: {type(exc).__name__}: {exc}")
        if sent:
            try:
                self.observability.mark_notified([int(row["id"]) for row in rows])
            except Exception:
                pass
        return sent

    def notify_operational_recoveries(self) -> int:
        """Best-effort single recovery notice for previously alerted providers."""
        if not settings.observability_admin_alerts or self.observability is None or self.telegram is None:
            return 0
        try:
            rows = self.observability.recovery_candidates(limit=5)
        except Exception:
            return 0
        if not rows:
            return 0
        recipients = set(settings.admin_ids or set())
        try:
            configured = int(str(settings.telegram_chat_id).strip())
            if configured > 0:
                recipients.add(configured)
        except Exception:
            pass
        if not recipients:
            return 0
        # Deduplicate provider summaries in case multiple high-severity incident
        # keys closed in the same capture cycle.
        summaries = []
        for row in rows:
            summary = str(row.get("summary") or "provider recuperado")
            if summary not in summaries:
                summaries.append(summary)
        lines = ["✅ <b>CSM PROVIDERS • RECUPERAÇÃO</b>", ""]
        for summary in summaries[:5]:
            clean = escape(summary)
            clean = clean.replace("Limite/cota do provider ", "Provider ").replace(" detectado", " normalizado")
            lines.append(f"• {clean}")
        lines += ["", "🔄 O provider voltou à rotação; fallback automático permanece disponível."]
        sent = 0
        text = "\n".join(lines)
        for uid in sorted(recipients):
            try:
                self.telegram.send(int(uid), text)
                sent += 1
            except Exception as exc:
                self.log_warning(f"recuperação operacional não entregue admin={uid}: {type(exc).__name__}: {exc}")
        if sent:
            try:
                self.observability.mark_recovery_notified([int(row["id"]) for row in rows])
            except Exception:
                pass
        return sent

    def notify_onchain_snapshot(self, signal_row: dict, snapshot: dict) -> int:
        """Send paid-plan deterioration alerts from polling-only on-chain evidence.

        This is advisory post-signal monitoring. It never changes the original
        approval and uses the existing alert-delivery ledger for deduplication.
        """
        if not self.telegram or not snapshot:
            return 0
        risk = str(snapshot.get("risk_level") or "LOW").upper()
        liq_change = float(snapshot.get("liquidity_change_pct") or 0.0)
        if risk not in {"HIGH", "CRITICAL"} and liq_change > -abs(float(settings.onchain_liquidity_warn_drop_pct)):
            return 0
        chain = str(signal_row.get("chain") or "").lower()
        address = str(signal_row.get("address") or "")
        symbol = str(signal_row.get("symbol") or "TOKEN")[:32]
        reputation_line = ""
        if self.reputation_engine is not None:
            try:
                self.reputation_engine.refresh(days=3650, limit=100)
                deployer = str(signal_row.get("goplus_creator_address") or signal_row.get("goplus_owner_address") or "").strip()
                profile = self.reputation_engine.profile(chain, deployer) if deployer else None
                if profile:
                    reputation_line = (
                        f"🧬 Deployer Reputation: <b>{int(profile.get('reputation_score') or 0)}/100</b> • "
                        f"confiança <b>{int(profile.get('confidence_score') or 0)}/100</b> • "
                        f"{escape(str(profile.get('rating') or 'UNPROVEN'))}\n"
                    )
            except Exception:
                reputation_line = ""
        rows = self.storage.conn.execute(
            """SELECT DISTINCT d.user_id,u.plan FROM alert_deliveries d
               JOIN users u ON u.user_id=d.user_id
               WHERE d.chain=? AND lower(d.address)=lower(?) AND d.alert_type='entry'
                 AND d.confirmed=1 AND u.blocked=0""",
            (chain, address),
        ).fetchall()
        sent = 0
        for row in rows:
            user_id = int(row["user_id"])
            plan = base_plan(row["plan"])
            if plan not in {"plus", "premium"}:
                continue
            alert_type = "onchain_risk"
            new_score = int(snapshot.get("onchain_score") or 0)
            recent = self.storage.conn.execute(
                """SELECT score FROM alert_deliveries
                   WHERE user_id=? AND chain=? AND address=? AND alert_type=? AND confirmed=1
                     AND created_at >= datetime('now', ?) LIMIT 1""",
                (user_id, chain, address, alert_type, f"-{int(settings.onchain_alert_cooldown)} seconds"),
            ).fetchone()
            # Respect the cooldown unless risk has materially deteriorated.
            if recent and new_score > int(recent["score"] or 0) - 15:
                continue
            top10 = snapshot.get("top10_holders_pct")
            whale_count = int(snapshot.get("whale_transfer_count") or 0)
            whale_usd = float(snapshot.get("whale_volume_usd") or 0.0)
            text = (
                f"⚠️ <b>ON-CHAIN INTELLIGENCE • {escape(symbol)}</b>\n\n"
                f"🔗 Rede: <b>{escape(chain.upper())}</b>\n"
                f"🧠 On-Chain Score: <b>{int(snapshot.get('onchain_score') or 0)}/100</b> • risco <b>{escape(risk)}</b>\n"
                f"💧 Liquidez vs. sinal: <b>{liq_change:+.1f}%</b>\n"
                + (f"👥 Top 10 holders: <b>{float(top10):.1f}%</b>\n" if top10 is not None else "")
                + (f"🐋 Grandes transferências: <b>{whale_count}</b> • ~US$ {whale_usd:,.0f}\n" if whale_count else "")
                + reputation_line
                + "\nℹ️ Inteligência pós-sinal; reputação é histórica e não sobrescreve a análise GoPlus."
            )
            try:
                self.telegram.send(user_id, text)
                self.storage.mark_alert_delivery(user_id, chain, address, alert_type, int(snapshot.get("onchain_score") or 0))
                sent += 1
            except Exception as exc:
                self.log_warning(f"alerta on-chain não entregue user={user_id}: {type(exc).__name__}: {exc}")
        return sent

    def notify_signal_lifecycle(self, signal_row: dict, event: dict) -> int:
        """Notify paid users about material lifecycle transitions only.

        Events are created from post-signal observations. This path never edits
        the original approval/scoring and intentionally avoids per-observation
        chatter: only TP/STOP/deterioration/recovery/expiry transitions notify.
        """
        if not self.telegram or not signal_row or not event:
            return 0
        chain = str(signal_row.get("chain") or "").lower()
        address = str(signal_row.get("address") or "")
        symbol = str(signal_row.get("symbol") or signal_row.get("name") or "TOKEN")[:32]
        event_type = str(event.get("event_type") or "UPDATE").upper()
        ret = float(event.get("return_pct") or 0.0)
        price = float(event.get("price") or 0.0)
        score = int(event.get("deterioration_score") or 0)
        reasons = list(event.get("reasons") or [])
        details = dict(event.get("details") or {})
        titles = {
            "TP1": "✅ TP1 ATINGIDO", "TP2": "🚀 TP2 ATINGIDO", "TP3": "🏆 TP3 ATINGIDO",
            "STOP": "🛑 STOP TOCADO", "DETERIORATION": "⚠️ DETERIORAÇÃO",
            "RECOVERED": "🟢 SINAL RECUPERADO", "EXPIRED": "⏱️ SINAL EXPIRADO",
        }
        title = titles.get(event_type, "📈 ATUALIZAÇÃO DE SINAL")
        lines = [f"{title} • <b>{escape(symbol)}</b>", "", f"🔗 Rede: <b>{escape(chain.upper())}</b>"]
        if price > 0:
            lines.append(f"💵 Preço observado: <b>{price:.10g}</b>")
        lines.append(f"📊 Retorno desde a entrada: <b>{ret:+.2f}%</b>")
        if details.get("liquidity_change_pct") is not None:
            lines.append(f"💧 Liquidez vs. entrada: <b>{float(details.get('liquidity_change_pct') or 0):+.1f}%</b>")
        if details.get("buy_pressure_pct") is not None:
            lines.append(f"🟢 Pressão compradora: <b>{float(details.get('buy_pressure_pct')):.1f}%</b>")
        if event_type == "DETERIORATION":
            lines.append(f"🧠 Deterioração: <b>{score}/100</b>")
            if reasons:
                lines.append("\nMotivos observados:")
                for reason in reasons[:5]:
                    lines.append(f"• {escape(str(reason)[:180])}")
        if event_type in {"TP1", "TP2"}:
            lines.append("\nℹ️ O acompanhamento continua com frequência adaptativa.")
        elif event_type in {"TP3", "STOP", "EXPIRED"}:
            lines.append("\nℹ️ Ciclo encerrado; novas consultas automáticas deste sinal são suspensas.")
        else:
            lines.append("\nℹ️ Inteligência pós-sinal; não altera a análise original.")
        text = "\n".join(lines)
        rows = self.storage.conn.execute(
            """SELECT DISTINCT d.user_id,u.plan FROM alert_deliveries d
               JOIN users u ON u.user_id=d.user_id
               WHERE d.chain=? AND lower(d.address)=lower(?) AND d.alert_type='entry'
                 AND d.confirmed=1 AND u.blocked=0""",
            (chain, address),
        ).fetchall()
        sent = 0
        for row in rows:
            if base_plan(row["plan"]) not in {"plus", "premium"}:
                continue
            try:
                self.telegram.send(int(row["user_id"]), text)
                sent += 1
            except Exception as exc:
                self.log_warning(f"lifecycle não entregue user={row['user_id']}: {type(exc).__name__}: {exc}")
        return sent

    def lifecycle_message_is_stale(self, msg: dict) -> bool:
        """Ignore lifecycle commands that predate this bot process.

        Telegram message dates have one-second resolution, so a two-second
        grace avoids rejecting a command sent during startup while still
        neutralizing an unconfirmed /encerrar replayed from a previous run.
        """
        try:
            message_time = float(msg.get("date"))
        except (TypeError, ValueError):
            return False
        return message_time < (self.started_at.timestamp() - 2.0)

    def _load_telegram_offset(self, bot_id) -> int | None:
        try:
            payload = json.loads(self.telegram_offset_file.read_text(encoding="utf-8"))
            if str(payload.get("bot_id")) != str(bot_id):
                return None
            offset = int(payload.get("offset"))
            return offset if offset >= 0 else None
        except Exception:
            return None

    def _save_telegram_offset(self, offset: int, bot_id) -> None:
        try:
            value = int(offset)
            if value < 0:
                return
            path = self.telegram_offset_file
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_name(path.name + ".tmp")
            tmp.write_text(
                json.dumps(
                    {"bot_id": str(bot_id), "offset": value, "updated_at": time.time()},
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            tmp.replace(path)
        except Exception as exc:
            self.log_warning(f"checkpoint Telegram não persistido: {type(exc).__name__}: {exc}")

    def is_admin(self, user_id: int) -> bool:
        try:
            uid = int(user_id)
        except Exception:
            return False
        if uid in (settings.admin_ids or set()):
            return True
        # In a private Telegram chat TELEGRAM_CHAT_ID is normally the same id
        # as the operator. This gives setup-only installations a safe stop path
        # even before ADMIN_USER_IDS is filled.
        try:
            return uid == int(str(settings.telegram_chat_id).strip())
        except Exception:
            return False

    def close(self) -> None:
        """Release local resources after the loop has stopped doing network I/O."""
        if self._closed:
            return
        self._closed = True
        try:
            self.scheduler.stop()
        except BaseException as exc:
            self.log_warning(f"scheduler shutdown: {type(exc).__name__}: {exc}")
        try:
            if self.telegram and hasattr(self.telegram, "close"):
                self.telegram.close()
        except BaseException as exc:
            self.log_warning(f"telegram shutdown: {type(exc).__name__}: {exc}")
        try:
            self.storage.close()
        except BaseException as exc:
            self.log_warning(f"storage shutdown: {type(exc).__name__}: {exc}")
        # No transport pools exist in v10. Reset only the process-local ownership
        # marker now that the event loop is fully stopped.
        try:
            self.network_bus.reset()
        except Exception:
            pass

    def scheduler_status(self, user_id: int | None = None):
        return self.scheduler.status(user_id)

    def history_screen(self, user_id: int, page: int = 0):
        user = self.storage.get_user(user_id)
        allowed = PLANS[user["plan"]]["history"]
        size = settings.history_page_size
        total = min(self.storage.history_count(user_id), allowed)
        max_page = max(0, (total - 1) // size)
        page = max(0, min(page, max_page))
        rows = self.storage.history(user_id, size, page * size)
        lines = [
            BRAND_DIVIDER,
            "🧾 <b>HISTÓRICO DE ANÁLISES</b>",
            BRAND_DIVIDER,
            f"📚 Registros disponíveis no plano: <b>{total}/{allowed}</b>",
            "",
        ]
        keyboard_rows = []
        if not rows:
            lines.append("Nenhuma análise registrada.")
        for index, row in enumerate(rows, start=page * size + 1):
            chain = CHAINS.get(row["chain"], {"emoji": "🌐", "label": row["chain"]})
            symbol, _ = token_identity(row)
            score = int(row.get("score") or 0)
            score_icon = "🟢" if score >= 88 else "✅" if score >= 78 else "🟡" if score >= 60 else "🔴"
            lines += [
                f"{score_icon} <b>{index}. {escape(symbol)}</b> • <b>{score}/100</b>",
                f"{chain['emoji']} {escape(str(chain['label']))} • {escape(str(row.get('source') or 'fonte n/d'))}",
                f"🕒 {history_time(row.get('created_at'))}",
                f"📄 <code>{escape(compact_address(row['address']))}</code>",
                "",
            ]
            keyboard_rows.append([
                {
                    "text": f"🔎 {index}. {symbol[:18]}",
                    "callback_data": f"refresh|{row['chain']}|{row['address']}",
                }
            ])
        lines.append(f"\nPágina <b>{page + 1}/{max_page + 1}</b>")
        nav = []
        if page > 0:
            nav.append({"text": "⬅️ Anterior", "callback_data": f"history|{page - 1}"})
        if page < max_page:
            nav.append({"text": "Próxima ➡️", "callback_data": f"history|{page + 1}"})
        keyboard = {
            "inline_keyboard": keyboard_rows
            + ([nav] if nav else [])
            + [[{"text": "🏠 Menu", "callback_data": "menu"}]]
        }
        return "\n".join(lines), keyboard

    def favorites_screen(self, user_id: int):
        rows = self.storage.favorites(user_id, limit=100)
        lines = ["⭐ <b>FAVORITOS</b>", ""]
        keyboard = []
        if not rows:
            lines.append("Nenhum token favoritado.")
        for row in rows[:20]:
            name, _ = token_identity(row)
            chain = row["chain"]
            address = row["address"]
            lines.append(
                f"• <b>{escape(str(name))}</b> • {escape(chain)}\n"
                f"<code>{escape(compact_address(address))}</code>"
            )
            keyboard.append([
                {"text": f"🔎 {str(name)[:16]}", "callback_data": f"refresh|{chain}|{address}"},
                {"text": "🗑", "callback_data": f"unfavorite|{chain}|{address}"},
            ])
        keyboard.append([{"text": "🏠 Menu", "callback_data": "menu"}])
        return "\n\n".join(lines), {"inline_keyboard": keyboard}

    def scanner_screen(self, user_id: int, page: int = 0):
        user = self.storage.get_user(user_id)
        group = PLANS[user["plan"]]["base"]
        results = self.scanner_sessions.get(user_id, self.scanner.last_results)
        stats = self.scanner.last_stats
        page_size = 3
        total = max(1, (len(results) + page_size - 1) // page_size)
        page = max(0, min(page, total - 1))
        current = results[page * page_size : (page + 1) * page_size]
        lines = [
            "🚀 <b>SCANNER MULTICHAIN</b>",
            "",
            f"Descobertos: <b>{stats.get('discovered', 0)}</b> • Analisados: <b>{stats.get('analyzed', 0)}</b> • Aprovados: <b>{stats.get('approved', 0)}</b>",
        ]
        if settings.goplus_enabled:
            lines.append(
                f"🛡️ GoPlus: verificados <b>{stats.get('security_verified', 0)}</b> • "
                f"bloqueados <b>{stats.get('security_blocked', 0)}</b> • "
                f"indisponíveis <b>{stats.get('security_unavailable', 0)}</b>"
            )
        keyboard = []
        if not current:
            lines += ["", "Nenhuma oportunidade em cache. Use Novo ciclo; a execução seguirá pelo scheduler."]
        for idx, item in enumerate(current, start=page * page_size + 1):
            score = int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or 0)
            raw_symbol, _ = token_identity(item)
            symbol = escape(raw_symbol)
            lines += [
                "",
                f"🟢 <b>{idx}. {symbol}</b> • {escape(str(item.get('chain') or '?'))}",
                f"⭐ {score}/100 • 💲 {format_price(item.get('price'))} • 📊 {float(item.get('change24h') or 0):+.1f}% em 24h",
            ]
            if item.get("goplus_checked") and isinstance(item.get("goplus_score"), (int, float)):
                lines.append(f"🛡️ GoPlus {int(item.get('goplus_score'))}/100 • {escape(str(item.get('goplus_risk_level') or 'N/D'))}")
            if group in {"plus", "premium"}:
                lines.append(
                    f"💧 {self._compact_usd(item.get('liquidity'))} • 📈 {self._compact_usd(item.get('volume24h'))}"
                )
            if group == "premium":
                pressure = buy_pressure(item)
                lines.append(
                    f"🟢 Pressão compradora: {f'{pressure:.1f}%' if pressure is not None else 'n/d'} • "
                    f"🏦 MC {self._compact_usd(item.get('marketcap'))}"
                )
            keyboard.append([{"text": f"🔎 Detalhes {idx}", "callback_data": f"scanner_detail|{idx - 1}"}])
        nav = []
        if page > 0:
            nav.append({"text": "⬅️", "callback_data": f"scanner_page|{page - 1}"})
        if page + 1 < total:
            nav.append({"text": "➡️", "callback_data": f"scanner_page|{page + 1}"})
        if nav:
            keyboard.append(nav)
        keyboard += [
            [{"text": "🔄 Novo ciclo", "callback_data": "scanner_force"}],
            [{"text": "🏠 Menu", "callback_data": "menu"}],
        ]
        return "\n".join(lines), {"inline_keyboard": keyboard}

    def payment_keyboard(self, plan: str):
        rows = []
        methods = set(settings.asaas_payment_methods)
        if "PIX" in methods:
            rows.append([{"text": "⚡ PIX", "callback_data": f"paymethod|{plan}|PIX"}])
        if "CREDIT_CARD" in methods:
            rows.append([{"text": "💳 Cartão", "callback_data": f"paymethod|{plan}|CREDIT_CARD"}])
        rows.append([{"text": "⬅️ Planos", "callback_data": "plans"}])
        return {"inline_keyboard": rows}

    @staticmethod
    def _analysis_keyboard(chain: str, address: str, market: dict, *, back: str = "menu") -> dict:
        rows = [
            [
                {"text": "🔄 Atualizar", "callback_data": f"refresh|{chain}|{address}"},
                {"text": "⭐ Favoritar", "callback_data": f"favorite|{chain}|{address}"},
            ]
        ]
        chart_url = str(market.get("url") or "").strip()
        if chart_url.startswith("https://"):
            rows.append([{"text": "📊 Abrir gráfico da fonte", "url": chart_url}])
        rows += [
            [{"text": "📋 Copiar contrato", "callback_data": f"copy|{chain}|{address}"}],
            [{"text": "⬅️ Scanner" if back == "scanner" else "🏠 Menu", "callback_data": back}],
        ]
        return {"inline_keyboard": rows}

    def analyze(self, user_id: int, chain: str, address: str, force: bool = False):
        user = self.storage.get_user(user_id)
        plan = PLANS[user["plan"]]
        if user.get("blocked"):
            return "⛔ Conta bloqueada.", ui.user_keyboard(user)
        if plan["chains"] != "all" and chain not in plan["chains"]:
            return "⛔ Esta rede exige plano pago.", ui.sales_keyboard(bool(self.payments))
        if plan["limit"] is not None and self.storage.count_today(user_id) >= plan["limit"]:
            return "⛔ Limite diário atingido.", ui.user_keyboard(user)
        market = self.market.fetch(chain, address, force=force)
        text, score = market_report(market, user["plan"])
        self.storage.save_analysis(user_id, chain, address, score, market)
        keyboard = self._analysis_keyboard(chain, address, market)
        return text, keyboard

    def scanner_detail(self, user_id: int, item: dict):
        user = self.storage.get_user(user_id)
        text, _ = market_report(item, user["plan"])
        chain = str(item.get("chain") or "")
        address = str(item.get("address") or "")
        return text, self._analysis_keyboard(chain, address, item, back="scanner")

    @staticmethod
    def _compact_usd(value) -> str:
        value = float(value or 0)
        if abs(value) >= 1_000_000:
            return f"US$ {value / 1_000_000:.2f} mi"
        if abs(value) >= 1000:
            return f"US$ {value / 1000:.1f} mil"
        return f"US$ {value:,.0f}"

    def deliver_signals(self, group: str, results: list[dict]):
        # Compatibility entry point used by Scheduler. The delivery engine is a
        # separate component so scanner logic and Telegram distribution cannot
        # silently drift together again.
        self.auto_delivery.storage = self.storage
        self.auto_delivery.telegram = self.telegram
        self.auto_delivery.user_profiles = self.user_profiles
        return self.auto_delivery.deliver(group, results)

    def _cached_market_for_position(self, position: dict):
        chain = str(position.get("chain") or "")
        address = str(position.get("address") or "").lower()
        for item in self.scanner.last_results:
            if str(item.get("chain") or "") == chain and str(item.get("address") or "").lower() == address:
                return item
        return None

    @staticmethod
    def _risk_rank_for_market(market: dict, score: int) -> int:
        _icon, label, _flags = risk_profile(market, score)
        return {"CONTROLADO PELOS FILTROS": 1, "ELEVADO": 2, "ALTO": 3, "MUITO ALTO": 4}.get(label, 0)

    def _smart_realert(self, position: dict, market: dict, plan: str | None, peak: float) -> tuple[list[str], dict]:
        """Detect meaningful paid-plan changes without turning monitoring into spam."""
        group = base_plan(plan)
        if group == "free" or not settings.signal_smart_realert_enabled:
            return [], {}

        score = int(market.get("opportunity_score") or market.get("score") or score_market(market))
        volume = float(market.get("volume24h") or 0)
        risk_rank = self._risk_rank_for_market(market, score)
        base_score = int(position.get("context_score") or 0)
        base_volume = float(position.get("context_volume") or 0)
        base_peak = float(position.get("context_peak_price") or position.get("entry_price") or 0)
        base_risk = int(position.get("context_risk_rank") or 0)

        # Open positions created before this release get a silent baseline first.
        if base_score <= 0 or base_peak <= 0:
            return [], {
                "context_score": score,
                "context_volume": volume,
                "context_peak_price": max(peak, float(position.get("entry_price") or 0)),
                "context_risk_rank": risk_rank,
            }

        if group == "premium":
            score_step = settings.signal_smart_premium_score_step
            volume_ratio = settings.signal_smart_premium_volume_ratio
            peak_step = settings.signal_smart_premium_peak_step_pct
        else:
            score_step = settings.signal_smart_plus_score_step
            volume_ratio = settings.signal_smart_plus_volume_ratio
            peak_step = settings.signal_smart_plus_peak_step_pct

        reasons: list[str] = []
        if score - base_score >= score_step:
            reasons.append(f"score subiu de {base_score} para {score}")
        if base_volume > 0 and volume >= base_volume * volume_ratio:
            reasons.append(f"volume 24h acelerou para {volume / base_volume:.1f}x da referência anterior")
        if base_peak > 0 and peak >= base_peak * (1 + peak_step / 100):
            reasons.append(f"nova máxima relevante: +{((peak / base_peak) - 1) * 100:.1f}% sobre a máxima do último alerta")
        if base_risk > 0 and risk_rank > base_risk:
            reasons.append("classificação de risco piorou desde a última atualização")

        if not reasons:
            return [], {}
        return reasons, {
            "context_score": score,
            "context_volume": volume or base_volume,
            "context_peak_price": max(peak, base_peak),
            "context_risk_rank": risk_rank or base_risk,
            "context_alerts": int(position.get("context_alerts") or 0) + 1,
            "last_context_event": "; ".join(reasons)[:120],
        }

    def process_cached_position(self, position: dict) -> None:
        market = self._cached_market_for_position(position)
        if not market:
            return
        price = float(market.get("price") or 0)
        entry = float(position["entry_price"] or 0)
        if not price or not entry:
            return
        change = ((price / entry) - 1) * 100
        peak = max(float(position.get("peak_price") or 0), price)
        user_id = int(position["user_id"])
        user = self.storage.get_user(user_id)
        plan = user.get("plan")
        event = None
        updates = {}
        smart_reasons: list[str] = []

        # TP/stop always have priority over informational intelligent updates.
        if not position["stop_sent"] and price <= float(position["stop_price"]):
            event = "STOP"
            updates = {"stop_sent": True, "status": "CLOSED", "last_price": price, "peak_price": peak, "result_pct": change, "outcome": "STOP"}
        elif not position["target2_sent"] and price >= float(position["target2_price"]):
            event = "TARGET2"
            updates = {"target1_sent": True, "target2_sent": True, "status": "CLOSED", "last_price": price, "peak_price": peak, "result_pct": change, "outcome": "TARGET2"}
        elif not position["target1_sent"] and price >= float(position["target1_price"]):
            event = "TARGET1"
            updates = {"target1_sent": True, "last_price": price, "peak_price": peak, "result_pct": change, "outcome": "TARGET1"}
        else:
            smart_reasons, smart_updates = self._smart_realert(position, market, plan, peak)
            if smart_reasons:
                event = "SMART"
                updates = {"last_price": price, "peak_price": peak, "result_pct": change, **smart_updates}
            elif smart_updates:
                self.storage.update_signal_position(
                    int(position["id"]), last_price=price, peak_price=peak, result_pct=change, **smart_updates
                )
                return

        if event:
            text = position_alert(position, market, event, change, peak, plan, smart_reasons=smart_reasons)
            chain = str(position.get("chain") or market.get("chain") or "")
            address = str(position.get("address") or market.get("address") or "")
            rows = [[
                {"text": "🔎 Analisar agora", "callback_data": f"refresh|{chain}|{address}"},
                {"text": "🏠 Menu", "callback_data": "menu"},
            ]]
            chart_url = str(market.get("url") or "").strip()
            if chart_url.startswith("https://"):
                rows.append([{"text": "📊 Abrir gráfico", "url": chart_url}])
            self.telegram.send(user_id, text, {"inline_keyboard": rows})
            self.storage.update_signal_position(int(position["id"]), **updates)
        else:
            self.storage.update_signal_position(int(position["id"]), last_price=price, peak_price=peak, result_pct=change)

    def _bootstrap_telegram(self, guard: RuntimeGuard | None = None):
        attempt = 0
        while True:
            attempt += 1
            if guard:
                guard.service_lease()
                guard.progress("telegram:bootstrap", extra={"attempt": attempt, "network": self.network_bus.snapshot()})
            try:
                me = self.telegram.bootstrap(attempts=3)
                return me
            except TelegramAPIError:
                raise
            except TransientNetworkError as exc:
                wait_seconds = min(10, 2 + attempt)
                print(
                    f"⚠️ Telegram temporariamente indisponível ({exc}). Nova tentativa em {wait_seconds}s; bot não será encerrado.",
                    flush=True,
                )
                if guard:
                    guard.beat(extra={"telegram_wait": wait_seconds, "network": self.network_bus.snapshot()})
                    guard.service_lease()
                time.sleep(wait_seconds)
                if guard:
                    guard.service_lease()

    def run(self, guard: RuntimeGuard | None = None):
        if self.telegram is None or (not self._telegram_injected and not settings.telegram_chat_id):
            raise RuntimeError("Configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID.")

        # v12.0.2: prefer a cooperative SIGINT on a-Shell.  The default Python
        # handler raises KeyboardInterrupt at an arbitrary bytecode boundary;
        # if that lands inside ssl.read() some a-Shell builds can tear down the
        # embedded TLS stack poorly.  The custom handler only flips the local
        # shutdown flag and lets the current short HTTPS operation unwind.
        previous_sigint = None
        sigint_installed = False
        sigint_announced = False

        def _cooperative_sigint(_signum, _frame):
            nonlocal sigint_announced
            self.request_shutdown("Ctrl+C/SIGINT")
            if guard:
                try:
                    guard.beat(state="stopping", extra={"shutdown_reason": "Ctrl+C/SIGINT"})
                except Exception:
                    pass
            if not sigint_announced:
                print("🛑 Ctrl+C recebido; parada cooperativa solicitada...", flush=True)
                sigint_announced = True

        try:
            previous_sigint = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, _cooperative_sigint)
            sigint_installed = True
        except Exception:
            # Some embedded interpreters do not expose signal ownership.  The
            # existing KeyboardInterrupt path remains the safe fallback.
            pass

        me = self._bootstrap_telegram(guard)
        print(f"✅ Telegram conectado como @{me.get('username', 'bot')}", flush=True)
        for warning in self.telegram.prepare():
            self.log_warning(f"Telegram prepare não crítico: {warning}")
        print("✅ BOT ONLINE — /encerrar no Telegram = parada segura; Ctrl+C = emergência", flush=True)
        print("✅ Runtime v16.0.0: 1 Python • Proof + On-Chain + Reputation + Observability + Distribution + Entitlements", flush=True)
        # TELEGRAM_CHAT_ID is an operator/admin notification destination, not a
        # commercial subscriber. Never auto-create it in ``users``: placeholder
        # or stale ids would otherwise enter Free automatic-signal delivery. A
        # real Telegram user is registered only by an actual inbound interaction.

        self.scheduler.start()
        bot_id = me.get("id") or "unknown"
        offset = self._load_telegram_offset(bot_id)
        if offset is not None:
            print(f"✅ Checkpoint Telegram carregado: offset={offset}", flush=True)
        try:
            while not self.shutdown_requested:
                try:
                    if guard:
                        guard.service_lease()
                        guard.beat(
                            extra={
                                "scanner_active": self.scanner.active,
                                "scanner_phase": self.scanner.phase,
                                "network": self.network_bus.snapshot(),
                            }
                        )
                    # Long polling and scanner share one network bus. While the
                    # scanner is active, use a non-blocking Telegram poll so the
                    # scan does not spend ~1 second waiting before every step.
                    poll_seconds = 0 if self.scanner.active else 1
                    updates = self.telegram.updates(offset, poll_seconds=poll_seconds)
                    if guard:
                        guard.service_lease()
                    for update in updates:
                        next_offset = int(update["update_id"]) + 1
                        if update.get("message"):
                            self.router.message(update["message"])
                        elif update.get("callback_query"):
                            self.router.callback(update["callback_query"])
                        # Save only after routing succeeded. This makes every
                        # processed update durable across a-Shell restarts.
                        offset = next_offset
                        self._save_telegram_offset(offset, bot_id)
                        if self.shutdown_requested:
                            # Best effort: tell Telegram the shutdown update is
                            # confirmed before leaving. The local checkpoint is
                            # still authoritative if this network call fails.
                            try:
                                self.telegram.confirm_offset(offset)
                            except Exception as exc:
                                self.log_warning(f"ACK final de offset adiado: {type(exc).__name__}: {exc}")
                            break
                    if self.shutdown_requested:
                        break
                    self.scheduler.step()
                    if guard:
                        guard.service_lease()
                except KeyboardInterrupt:
                    # Transport finally-blocks have already closed HTTPResponse
                    # and HTTPSConnection before the interrupt arrives here. Do
                    # not re-raise through the embedded a-Shell interpreter.
                    self.request_shutdown("Ctrl+C")
                    if guard:
                        guard.beat(state="stopping", extra={"shutdown_reason": "Ctrl+C"})
                    print("🛑 Encerramento solicitado; finalizando recursos locais...", flush=True)
                except TransientNetworkError as exc:
                    if self.observability is not None:
                        try:
                            self.observability.record_loop_error(type(exc).__name__, str(exc), component="network")
                        except Exception:
                            pass
                    now = time.monotonic()
                    if now - self._last_network_notice > 15:
                        self.log_warning(f"rede transitória: {exc}; bot continua online")
                        self._last_network_notice = now
                    time.sleep(0.25)
                except TelegramAPIError as exc:
                    if self.observability is not None:
                        try:
                            self.observability.record_loop_error(type(exc).__name__, str(exc), component="telegram")
                        except Exception:
                            pass
                    if exc.error_code == 401:
                        raise
                    self.log_warning(f"Telegram API: {exc}; continuando")
                    time.sleep(0.25)
                except Exception as exc:
                    if self.observability is not None:
                        try:
                            self.observability.record_loop_error(type(exc).__name__, str(exc), component="runtime")
                        except Exception:
                            pass
                    self.log_warning(f"erro isolado {type(exc).__name__}: {exc}; continuando")
                    time.sleep(0.25)
        finally:
            self.scheduler.stop()
            if sigint_installed:
                try:
                    signal.signal(signal.SIGINT, previous_sigint)
                except Exception:
                    pass
        print(f"✅ Bot encerrado com segurança ({self.shutdown_reason or 'fim do loop'}).", flush=True)
