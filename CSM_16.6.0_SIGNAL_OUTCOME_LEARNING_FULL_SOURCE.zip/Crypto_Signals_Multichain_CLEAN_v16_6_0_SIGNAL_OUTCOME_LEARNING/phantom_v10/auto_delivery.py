from __future__ import annotations

import json
import time
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Callable

from csm.config import settings
from csm.formatting import score_market
from csm.plans import base_plan, normalize_plan
from csm.performance import PerformanceLedger
from csm.smart_reentry import SmartReentry

from .errors import TelegramAPIError, TransientNetworkError
from .presentation import risk_profile, signal_card, token_identity


@dataclass(frozen=True)
class DeliveryPolicy:
    group: str
    max_signals: int


class AutomaticSignalDelivery:
    """Automatic Telegram delivery for scanner-approved opportunities.

    The scanner decides what is approved. This service decides who should
    receive it, avoids confirmed duplicates, fills each plan quota with new
    opportunities, sends through Telegram, and only then persists delivery.
    """

    GROUPS = {"free", "plus", "premium"}

    def __init__(
        self,
        *,
        storage,
        telegram,
        user_profiles,
        warning_logger: Callable[[str], None] | None = None,
        distribution=None,
    ) -> None:
        self.storage = storage
        self.telegram = telegram
        self.user_profiles = user_profiles
        self.warning_logger = warning_logger or (lambda _message: None)
        self.distribution = distribution
        self.performance = PerformanceLedger(storage) if settings.performance_ledger_enabled else None
        self.smart_reentry = SmartReentry(storage, self.performance)
        self._unreachable_file = Path(settings.data_dir) / "runtime" / "v10" / "telegram_unreachable.json"
        self._unreachable_users: set[int] = set()
        self._load_unreachable_users()

    def _load_unreachable_users(self) -> None:
        try:
            payload = json.loads(self._unreachable_file.read_text(encoding="utf-8"))
            rows = payload.get("users") if isinstance(payload, dict) else []
            self._unreachable_users = {int(x) for x in (rows or []) if int(x) > 0}
        except Exception:
            self._unreachable_users = set()

    def _save_unreachable_users(self) -> None:
        try:
            self._unreachable_file.parent.mkdir(parents=True, exist_ok=True)
            temp = self._unreachable_file.with_suffix(".tmp")
            temp.write_text(json.dumps({"users": sorted(self._unreachable_users)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            temp.replace(self._unreachable_file)
        except Exception:
            pass

    def mark_reachable(self, user_id: int) -> None:
        uid = int(user_id)
        if uid in self._unreachable_users:
            self._unreachable_users.discard(uid)
            self._save_unreachable_users()

    def _mark_unreachable(self, user_id: int) -> None:
        uid = int(user_id)
        if uid > 0 and uid not in self._unreachable_users:
            self._unreachable_users.add(uid)
            self._save_unreachable_users()

    @staticmethod
    def _score(item: dict[str, Any]) -> int:
        try:
            return int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or 0)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _canonical_chain(value: Any) -> str:
        return str(value or "").strip().lower()

    @staticmethod
    def _canonical_address(value: Any) -> str:
        return str(value or "").strip()

    @classmethod
    def _candidate_key(cls, item: dict[str, Any]) -> tuple[str, str]:
        return cls._canonical_chain(item.get("chain")), cls._canonical_address(item.get("address"))

    @staticmethod
    def _plan_limit(group: str) -> int:
        if group == "free":
            return max(1, int(getattr(settings, "auto_signal_limit_free", 1)))
        if group == "plus":
            return max(1, int(getattr(settings, "auto_signal_limit_plus", 2)))
        return max(1, int(getattr(settings, "auto_signal_limit_premium", 3)))

    @classmethod
    def policy(cls, group: str) -> DeliveryPolicy:
        normalized = str(group or "").strip().lower()
        if normalized not in cls.GROUPS:
            raise ValueError(f"Grupo de sinais inválido: {group!r}")
        return DeliveryPolicy(normalized, cls._plan_limit(normalized))

    @classmethod
    def _ranked_candidates(cls, results: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
        unique: dict[tuple[str, str], dict[str, Any]] = {}
        invalid = 0
        for raw in results or []:
            if not isinstance(raw, dict):
                invalid += 1
                continue
            item = dict(raw)
            chain, address = cls._candidate_key(item)
            if not chain or not address:
                invalid += 1
                continue
            item["chain"] = chain
            item["address"] = address
            key = (chain, address.lower())
            previous = unique.get(key)
            if previous is None or cls._score(item) > cls._score(previous):
                unique[key] = item

        ranked = sorted(
            unique.values(),
            key=lambda item: (
                cls._score(item),
                float(item.get("volume24h") or 0),
                float(item.get("liquidity") or 0),
            ),
            reverse=True,
        )
        return ranked, invalid

    @staticmethod
    def _keyboard(item: dict[str, Any]) -> dict[str, Any]:
        chain = str(item.get("chain") or "")
        address = str(item.get("address") or "")
        rows: list[list[dict[str, str]]] = [[
            {"text": "🔎 Analisar", "callback_data": f"refresh|{chain}|{address}"},
            {"text": "⭐ Favoritar", "callback_data": f"favorite|{chain}|{address}"},
        ]]
        chart_url = str(item.get("url") or "").strip()
        if chart_url.startswith("https://"):
            rows.append([{"text": "📊 Abrir gráfico", "url": chart_url}])
        rows.append([{"text": "🏠 Menu", "callback_data": "menu"}])
        return {"inline_keyboard": rows}

    def _send_with_retry(self, user_id: int, text: str, keyboard: dict[str, Any], attempts: int = 3):
        if self.telegram is None:
            raise RuntimeError("Telegram não inicializado.")
        attempts = max(1, int(attempts))
        last_error: Exception | None = None
        for attempt in range(1, attempts + 1):
            delay = 0.0
            try:
                return self.telegram.send(user_id, text, keyboard)
            except TransientNetworkError as exc:
                last_error = exc
                delay = min(3.0, 0.5 * (2 ** (attempt - 1)))
            except TelegramAPIError as exc:
                last_error = exc
                retryable = exc.error_code == 429 or bool(exc.error_code and exc.error_code >= 500)
                if not retryable:
                    raise
                if exc.error_code == 429:
                    cap = max(1, int(getattr(settings, "telegram_retry_after_max_seconds", 15)))
                    delay = min(cap, max(1, int(getattr(exc, "retry_after", 0) or 1)))
                else:
                    delay = min(3.0, 0.5 * (2 ** (attempt - 1)))
            if attempt < attempts and delay > 0:
                time.sleep(delay)
        if last_error is not None:
            raise last_error
        raise RuntimeError("Falha de envio sem erro informado.")

    def _matching_for_user(self, ranked: list[dict[str, Any]], profile: dict[str, Any]) -> list[dict[str, Any]]:
        preferred = {
            self._canonical_chain(value)
            for value in (profile.get("preferred_chains") or [])
            if self._canonical_chain(value)
        }
        matching = [item for item in ranked if not preferred or item.get("chain") in preferred]

        # Scanner approval is authoritative. AUTO_SIGNAL_MIN_SCORE remains a
        # priority boundary, not a second rejection gate. Candidates above the
        # boundary are tried first; approved candidates below it can still fill
        # a plan quota when the stronger ones are already delivered.
        threshold = int(getattr(settings, "auto_signal_min_score", 0) or 0)
        strong = [item for item in matching if self._score(item) >= threshold]
        remaining = [item for item in matching if self._score(item) < threshold]
        return strong + remaining

    @staticmethod
    def _risk_rank(item: dict[str, Any]) -> int:
        score = int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or score_market(item))
        _icon, label, _flags = risk_profile(item, score)
        return {"CONTROLADO PELOS FILTROS": 1, "ELEVADO": 2, "ALTO": 3, "MUITO ALTO": 4}.get(label, 0)

    def _record_position(self, user_id: int, item: dict[str, Any]) -> None:
        price = float(item.get("price") or 0)
        if price <= 0:
            return
        chain, address = self._candidate_key(item)
        symbol, _ = token_identity(item)
        score = int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or score_market(item))
        self.storage.create_signal_position(
            user_id=user_id,
            chain=chain,
            address=address,
            symbol=symbol,
            entry_price=price,
            target1_price=price * (1 + settings.signal_target1_pct / 100),
            target2_price=price * (1 + settings.signal_target2_pct / 100),
            stop_price=price * (1 - settings.signal_stop_pct / 100),
            entry_score=score,
            entry_volume=float(item.get("volume24h") or 0),
            entry_risk_rank=self._risk_rank(item),
        )

    def deliver(self, group: str, results: list[dict[str, Any]]) -> dict[str, Any]:
        policy = self.policy(group)
        ranked, invalid = self._ranked_candidates(results)
        summary: dict[str, Any] = {
            "users": 0,
            "active_users": 0,
            "sent": 0,
            "candidates": len(results or []),
            "approved": len(results or []),
            "unique_candidates": len(ranked),
            "eligible": 0,
            "duplicates": 0,
            "reentries": 0,
            "reentry_cooldown_blocks": 0,
            "reentry_improvement_blocks": 0,
            "disabled": 0,
            "quiet": 0,
            "filtered": 0,
            "invalid": invalid,
            "errors": 0,
            "rate_limit_errors": 0,
            "transient_errors": 0,
            "recipient_unreachable": 0,
            "recipient_unreachable_skipped": 0,
            "other_errors": 0,
            "persistence_errors": 0,
            "distribution_jobs": 0,
            "quota": policy.max_signals,
            "top_score": max((self._score(item) for item in ranked), default=0),
            "reason": "",
            "reentry_reason": "",
        }

        try:
            self.storage.prune_alert_deliveries(settings.signal_alert_cooldown_hours)
        except Exception as exc:
            self.warning_logger(f"limpeza de deduplicação ignorada: {type(exc).__name__}: {exc}")

        recipients = self.storage.signal_users(policy.group)
        summary["users"] = len(recipients)

        for user in recipients:
            user_id = int(user["user_id"])
            if user_id in self._unreachable_users:
                summary["recipient_unreachable_skipped"] += 1
                continue
            prefs = self.storage.user_preferences(user_id)
            if not prefs.get("auto_signals", True):
                summary["disabled"] += 1
                continue

            profile = self.user_profiles.get(user_id)
            if self.user_profiles.is_quiet(profile):
                summary["quiet"] += 1
                continue

            summary["active_users"] += 1
            plan = normalize_plan(user.get("plan"))
            if base_plan(plan) != policy.group:
                # Defensive guard: signal_users() is already expected to enforce
                # this. Never cross-deliver if a future storage change regresses.
                self.warning_logger(
                    f"destinatário fora do grupo ignorado user={user_id} plan={plan} group={policy.group}"
                )
                continue

            candidates = self._matching_for_user(ranked, profile)
            summary["filtered"] += max(0, len(ranked) - len(candidates))
            sent_for_user = 0

            # Walk the full approved ranking until the user's quota is actually
            # filled. Duplicates and failed sends never consume a plan slot.
            for item in candidates:
                if sent_for_user >= policy.max_signals:
                    break

                chain, address = self._candidate_key(item)
                score = self._score(item)
                reentry = self.smart_reentry.evaluate(
                    user_id=user_id, plan_group=policy.group, item=item
                )
                if not reentry.allowed:
                    summary["duplicates"] += 1
                    if "cooldown" in reentry.block_reason.casefold():
                        summary["reentry_cooldown_blocks"] += 1
                    else:
                        summary["reentry_improvement_blocks"] += 1
                    continue

                summary["eligible"] += 1
                delivery_item = {**item, "smart_reentry": reentry.public_dict()}
                proof_preview = None
                rendered_item = delivery_item
                if self.performance is not None:
                    try:
                        # V13: prepare the tamper-evident commit before Telegram
                        # delivery so the message can carry the same proof hash.
                        proof_preview = self.performance.prepare_signal_proof(delivery_item)
                        if proof_preview is not None:
                            rendered_item = {**delivery_item, **proof_preview.public_fields()}
                    except Exception as exc:
                        summary["persistence_errors"] += 1
                        self.warning_logger(
                            f"proof pré-envio indisponível chain={chain}: {type(exc).__name__}: {exc}"
                        )
                try:
                    self._send_with_retry(
                        user_id,
                        signal_card(rendered_item, plan),
                        self._keyboard(delivery_item),
                    )
                except Exception as exc:
                    if isinstance(exc, TelegramAPIError) and getattr(self.telegram, "is_unreachable_error", lambda _e: False)(exc):
                        summary["recipient_unreachable"] += 1
                        if bool(getattr(settings, "telegram_auto_suppress_unreachable", True)):
                            self._mark_unreachable(user_id)
                        self.warning_logger(
                            f"destinatário Telegram suprimido user={user_id} plan={plan} "
                            f"chain={chain}: {exc.description} (HTTP {exc.error_code})"
                        )
                        continue
                    summary["errors"] += 1
                    if isinstance(exc, TelegramAPIError) and exc.error_code == 429:
                        summary["rate_limit_errors"] += 1
                    elif isinstance(exc, TransientNetworkError) or (isinstance(exc, TelegramAPIError) and bool(exc.error_code and exc.error_code >= 500)):
                        summary["transient_errors"] += 1
                    else:
                        summary["other_errors"] += 1
                    self.warning_logger(
                        f"sinal automático não entregue user={user_id} plan={plan} "
                        f"chain={chain}: {type(exc).__name__}: {exc}"
                    )
                    continue

                # A confirmed Telegram send is the only event that creates the
                # deduplication marker. A failed send remains retryable.
                try:
                    self.storage.mark_alert_delivery(user_id, chain, address, "entry", score)
                except Exception as exc:
                    summary["persistence_errors"] += 1
                    self.warning_logger(
                        f"deduplicação pós-envio não persistida user={user_id} chain={chain}: "
                        f"{type(exc).__name__}: {exc}"
                    )

                summary["sent"] += 1
                sent_for_user += 1
                if reentry.is_reentry:
                    summary["reentries"] += 1
                distribution_proof_fields: dict[str, Any] = {}
                signal_id = None
                if self.performance is not None:
                    try:
                        # Record only after Telegram confirmed delivery. Multiple
                        # users/plans merge into one immutable market event while
                        # delivered_count keeps the commercial distribution fact.
                        signal_id = self.performance.record_signal(
                            delivery_item, policy.group,
                            now=proof_preview.occurred_at if proof_preview is not None else None,
                            proof_preview=proof_preview,
                        )
                        if proof_preview is not None:
                            distribution_proof_fields = proof_preview.public_fields()
                    except Exception as exc:
                        summary["persistence_errors"] += 1
                        self.warning_logger(
                            f"performance ledger pós-envio não persistido chain={chain}: "
                            f"{type(exc).__name__}: {exc}"
                        )
                try:
                    self.smart_reentry.record_confirmed_delivery(
                        user_id=user_id, item=delivery_item, decision=reentry,
                        signal_id=signal_id, score=score,
                        now=proof_preview.occurred_at if proof_preview is not None else None,
                    )
                except Exception as exc:
                    summary["persistence_errors"] += 1
                    self.warning_logger(
                        f"histórico de reentrada não persistido user={user_id} chain={chain}: "
                        f"{type(exc).__name__}: {exc}"
                    )
                if self.distribution is not None:
                    try:
                        # Queue only after the local ledger/proof attempt. If proof
                        # persistence failed, the external event is still delivered
                        # but carries no unverifiable proof claim.
                        queued = self.distribution.enqueue_signal(delivery_item, policy.group, distribution_proof_fields)
                        if queued:
                            summary["distribution_jobs"] = int(summary.get("distribution_jobs", 0)) + int(queued)
                    except Exception as exc:
                        summary["persistence_errors"] += 1
                        self.warning_logger(
                            f"distribution job não persistido chain={chain}: {type(exc).__name__}: {exc}"
                        )
                try:
                    self._record_position(user_id, delivery_item)
                except Exception as exc:
                    summary["persistence_errors"] += 1
                    self.warning_logger(
                        f"posição pós-envio não registrada user={user_id} chain={chain}: "
                        f"{type(exc).__name__}: {exc}"
                    )

        if summary["sent"] > 0:
            summary["reason"] = "entregue"
        elif summary["users"] == 0:
            summary["reason"] = "sem destinatário ativo no plano"
        elif summary["active_users"] == 0:
            summary["reason"] = "destinatários com sinais pausados/horário silencioso"
        elif not ranked:
            summary["reason"] = "sem candidato válido"
        elif summary["duplicates"] > 0 and summary["eligible"] == 0:
            summary["reason"] = "aprovados já enviados aos destinatários"
            if summary["reentry_cooldown_blocks"] > 0:
                summary["reentry_reason"] = "reentrada aguardando cooldown do plano"
            elif summary["reentry_improvement_blocks"] > 0:
                summary["reentry_reason"] = "outcome anterior exige melhora material"
        elif summary["filtered"] > 0 and summary["eligible"] == 0:
            summary["reason"] = "preferências de rede filtraram os candidatos"
        elif summary["errors"] > 0:
            summary["reason"] = "falha de entrega Telegram"
        else:
            summary["reason"] = "sem nova oportunidade elegível"
        return summary
