from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from csm.config import settings


@dataclass(frozen=True)
class RuntimeConfig:
    version: str = "16.4.0-smart-reentry"
    lts: str = "6.3.0"
    schema: int = 600  # compatibility floor inherited from LTS 6.3.0
    active_schema: int = 660
    telegram_poll_seconds: int = 1
    network_timeout_seconds: float = 6.0
    market_timeout_seconds: float = 3.0
    scanner_cycle_timeout_seconds: float = 120.0
    stale_runtime_seconds: float = 60.0

    @property
    def state_dir(self) -> Path:
        return settings.data_dir

    @property
    def db_file(self) -> Path:
        return settings.db_file


runtime_config = RuntimeConfig()
