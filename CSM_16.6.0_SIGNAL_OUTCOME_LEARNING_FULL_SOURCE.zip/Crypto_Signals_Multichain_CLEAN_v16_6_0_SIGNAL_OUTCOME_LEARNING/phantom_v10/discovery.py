from __future__ import annotations

"""Multi-provider discovery layer for the cooperative v10 scanner.

The scanner owns cadence/budget; this module owns *where* candidates come from.
Providers are intentionally adapters with no background workers.  Every source
is one HTTPS request and all requests still use the shared sequential network
bus from :mod:`phantom_v10.transport`.
"""

from dataclasses import dataclass, field
import json
from pathlib import Path
import time
from typing import Any, Callable, Iterable

from csm.config import settings
from csm.provider_coverage import priority_chains
from csm.provider_intelligence import BirdeyeCredentialProbeState, ProviderQualityRouter, RecoveryProbeState

CHAIN_MAP = {
    "solana": "solana",
    "sol": "solana",
    "eth": "ethereum",
    "ethereum": "ethereum",
    "bsc": "bsc",
    "bnb": "bsc",
    "base": "base",
    "arbitrum": "arbitrum",
    "polygon_pos": "polygon",
    "polygon": "polygon",
    "avax": "avalanche",
    "avalanche": "avalanche",
    "optimism": "optimism",
    "fantom": "fantom",
    "cronos": "cronos",
}

# CoinGecko/GeckoTerminal network IDs are not identical to our internal IDs.
COINGECKO_NETWORKS = {
    "solana": "solana",
    "ethereum": "eth",
    "bsc": "bsc",
    "base": "base",
    "arbitrum": "arbitrum",
    "polygon": "polygon_pos",
    "avalanche": "avax",
    "optimism": "optimism",
    "fantom": "fantom",
    "cronos": "cronos",
}

BIRDEYE_CHAINS = {
    "solana": "solana",
    "ethereum": "ethereum",
    "bsc": "bsc",
    "base": "base",
    "arbitrum": "arbitrum",
    "polygon": "polygon",
    "avalanche": "avalanche",
    "optimism": "optimism",
}

# DexPaprika uses stable network slugs that match our internal names for the
# current CSM chains. Keeping the map explicit makes unsupported additions
# fail closed instead of accidentally querying the wrong network.
DEXPAPRIKA_NETWORKS = {
    "solana": "solana",
    "ethereum": "ethereum",
    "bsc": "bsc",
    "base": "base",
    "arbitrum": "arbitrum",
    "polygon": "polygon",
    "avalanche": "avalanche",
    "optimism": "optimism",
    "fantom": "fantom",
    "cronos": "cronos",
}

TIER_RANK = {"free": 0, "plus": 1, "premium": 2}


def birdeye_new_listing_params(chain: str) -> dict[str, Any]:
    """Return the minimal cross-package query accepted by New Listing.

    Optional filters are intentionally omitted. The scanner already applies its
    own quality/risk filters after discovery, so keeping Birdeye discovery at the
    smallest documented contract (``limit`` + ``x-chain`` header) reduces HTTP
    400 risk across BDS package revisions and preserves broad discovery.
    """
    _ = str(chain or "").strip().lower()
    return {"limit": 20}


@dataclass(frozen=True)
class DiscoverySource:
    name: str
    provider: str
    url: str
    parser: Callable[[Any], list[tuple[str, str]]]
    tier: str = "free"
    params: dict[str, Any] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    cache_ttl: int = 30
    chain: str | None = None
    probe_only: bool = False
    probe_kind: str = ""


def _dedupe(rows: Iterable[tuple[str, str]]) -> list[tuple[str, str]]:
    output: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for chain, address in rows:
        chain = CHAIN_MAP.get(str(chain).lower(), str(chain).lower())
        address = str(address or "").strip()
        key = (chain, address)
        if chain and address and key not in seen:
            seen.add(key)
            output.append(key)
    return output


def dex_rows(payload: Any) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for item in payload if isinstance(payload, list) else []:
        chain = CHAIN_MAP.get(str(item.get("chainId") or "").lower())
        address = str(item.get("tokenAddress") or item.get("address") or "").strip()
        if chain and address:
            rows.append((chain, address))
    return _dedupe(rows)


def gecko_rows(payload: Any) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for item in payload.get("data", []) if isinstance(payload, dict) else []:
        attrs = item.get("attributes") or {}
        rel = item.get("relationships") or {}
        network_rel = ((rel.get("network") or {}).get("data") or {}).get("id", "")
        network = str(network_rel or attrs.get("network") or item.get("id", "").split("_")[0]).lower()
        chain = CHAIN_MAP.get(network)
        token = ((rel.get("base_token") or {}).get("data") or {}).get("id", "")
        address = str(token).split("_", 1)[-1].strip()
        if chain and address:
            rows.append((chain, address))
    return _dedupe(rows)


def coingecko_rows(payload: Any) -> list[tuple[str, str]]:
    # CoinGecko Onchain uses the same JSON:API relationship shape as
    # GeckoTerminal, so the tolerant parser is intentionally shared.
    return gecko_rows(payload)


def dexpaprika_rows(payload: Any, default_chain: str = "") -> list[tuple[str, str]]:
    """Normalize DexPaprika advanced token-search results.

    The public endpoint returns ``results`` with an explicit chain/address, so
    no pool-token guessing is required. This adapter deliberately returns only
    candidate identity; all CSM liquidity/volume/score/security gates remain in
    the normal scanner path.
    """
    if not isinstance(payload, dict):
        return []
    rows: list[tuple[str, str]] = []
    for item in payload.get("results") or []:
        if not isinstance(item, dict):
            continue
        chain = str(item.get("chain") or default_chain or "").strip().lower()
        address = str(item.get("address") or "").strip()
        normalized_chain = CHAIN_MAP.get(chain, chain)
        if normalized_chain and address:
            rows.append((normalized_chain, address))
    return _dedupe(rows)


def birdeye_rows(payload: Any, default_chain: str = "") -> list[tuple[str, str]]:
    """Parse Birdeye new-listing responses defensively across API revisions.

    Birdeye commonly omits the chain from each ``data.items`` entry because
    the requested chain is already carried by the ``x-chain`` header.
    ``default_chain`` preserves that request context so valid addresses are
    not discarded as chainless during normalization/deduplication.
    """
    if not isinstance(payload, dict):
        return []
    root = payload.get("data")
    if isinstance(root, dict):
        items = root.get("items") or root.get("tokens") or root.get("list") or root.get("data") or []
    elif isinstance(root, list):
        items = root
    else:
        items = payload.get("items") or []
    rows: list[tuple[str, str]] = []
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        address = str(
            item.get("address")
            or item.get("token_address")
            or item.get("tokenAddress")
            or item.get("mint")
            or ""
        ).strip()
        chain = str(
            item.get("chain")
            or item.get("network")
            or item.get("chainId")
            or default_chain
            or ""
        ).lower()
        normalized_chain = CHAIN_MAP.get(chain, chain)
        if address and normalized_chain:
            rows.append((normalized_chain, address))
    return _dedupe(rows)


class MultiProviderDiscovery:
    """Build a bounded source queue according to the subscriber tier.

    Free remains inexpensive. Plus adds authenticated discovery when keys are
    configured. Premium adds a wider rotating set of chain-specific sources.
    Missing paid-provider keys simply disable those adapters; they never break
    the existing GeckoTerminal/DexScreener path.
    """

    def __init__(self):
        self.rotation = 0
        # Temporary provider+chain capability quarantine. A 404 from a
        # chain-specific provider endpoint means that *that provider route*
        # is not currently available; it must never remove the chain from the
        # scanner globally. Entries expire automatically and are also cleared
        # by a process restart, so support can be rediscovered later.
        self._unsupported_until: dict[tuple[str, str], float] = {}
        self._unsupported_reason: dict[tuple[str, str], str] = {}
        # Provider-wide pause is used for authentication/access failures.
        # An invalid key must not consume one request per chain every minute.
        self._provider_paused_until: dict[str, float] = {}
        self._provider_pause_reason: dict[str, str] = {}
        data_dir = getattr(settings, "data_dir", None)
        self._provider_pause_file = (Path(data_dir) / "runtime" / "v10" / "provider_cooldowns.json") if data_dir is not None else None
        self._load_provider_pauses()
        self._birdeye_probe = BirdeyeCredentialProbeState()
        self._recovery_probe = RecoveryProbeState()
        self.last_skipped_unsupported: dict[str, list[str]] = {}
        self.last_paused_providers: dict[str, str] = {}

    def _load_provider_pauses(self) -> None:
        """Restore provider-wide cooldowns across process restarts."""
        if self._provider_pause_file is None:
            return
        try:
            payload = json.loads(self._provider_pause_file.read_text(encoding="utf-8"))
            now = time.time()
            for provider, row in (payload.get("providers") or {}).items():
                if not isinstance(row, dict):
                    continue
                until = float(row.get("until") or 0.0)
                if until > now:
                    key = str(provider).lower().strip()
                    self._provider_paused_until[key] = until
                    self._provider_pause_reason[key] = str(row.get("reason") or "temporariamente indisponível")[:100]
        except Exception:
            return

    def _save_provider_pauses(self) -> None:
        if self._provider_pause_file is None:
            return
        try:
            now = time.time()
            # Persist only meaningful long cooldowns. Short 5-minute auth/
            # capability pauses stay process-local and do not pollute test/dev
            # state or survive a deliberate quick retry.
            rows = {}
            for provider, until in self._provider_paused_until.items():
                remaining = float(until or 0.0) - now
                reason = str(self._provider_pause_reason.get(provider, "") or "")
                # V16.5.9 persists even the first 5-minute HTTP 429 backoff so a
                # restart cannot bypass provider protection. Short auth/capability
                # probes remain process-local unless they are >=10 minutes.
                if remaining >= 600 or (remaining > 60 and ("429" in reason or "cota" in reason.casefold())):
                    rows[provider] = {"until": float(until), "reason": reason}
            self._provider_pause_file.parent.mkdir(parents=True, exist_ok=True)
            temp = self._provider_pause_file.with_suffix(".tmp")
            temp.write_text(json.dumps({"providers": rows}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            temp.replace(self._provider_pause_file)
        except Exception:
            return

    def mark_temporarily_unsupported(
        self, provider: str, chain: str, *, reason: str = "HTTP 404", ttl_seconds: int = 300
    ) -> None:
        provider = str(provider or "").lower().strip()
        chain = str(chain or "").lower().strip()
        if not provider or not chain:
            return
        key = (provider, chain)
        self._unsupported_until[key] = time.monotonic() + max(300, int(ttl_seconds))
        self._unsupported_reason[key] = str(reason or "não suportada")[:60]

    def _is_temporarily_unsupported(self, provider: str, chain: str) -> bool:
        key = (str(provider).lower(), str(chain).lower())
        until = float(self._unsupported_until.get(key, 0.0) or 0.0)
        if until <= 0:
            return False
        if time.monotonic() >= until:
            self._unsupported_until.pop(key, None)
            self._unsupported_reason.pop(key, None)
            return False
        return True

    def _record_skipped(self, provider: str, chain: str) -> None:
        rows = self.last_skipped_unsupported.setdefault(str(provider).lower(), [])
        label = f"{chain}: não suportada (revalidação ≤5min)"
        if label not in rows:
            rows.append(label)

    def pause_provider(self, provider: str, *, reason: str, ttl_seconds: int = 300) -> None:
        provider = str(provider or "").lower().strip()
        if not provider:
            return
        self._provider_paused_until[provider] = time.time() + max(60, int(ttl_seconds))
        self._provider_pause_reason[provider] = str(reason or "temporariamente indisponível")[:100]
        self._save_provider_pauses()

    def _provider_pause(self, provider: str) -> str | None:
        provider = str(provider or "").lower().strip()
        until = float(self._provider_paused_until.get(provider, 0.0) or 0.0)
        if until <= 0:
            return None
        if time.time() >= until:
            self._provider_paused_until.pop(provider, None)
            self._provider_pause_reason.pop(provider, None)
            self._save_provider_pauses()
            return None
        return self._provider_pause_reason.get(provider) or "temporariamente indisponível"

    def clear_provider_pause(self, provider: str) -> None:
        provider = str(provider or "").lower().strip()
        self._provider_paused_until.pop(provider, None)
        self._provider_pause_reason.pop(provider, None)
        self._save_provider_pauses()

    def mark_probe_result(self, provider: str, kind: str, *, ok: bool, detail: str = "") -> None:
        provider = str(provider or "").lower().strip()
        kind = str(kind or "").strip().lower()
        if provider == "birdeye" and kind == "credential":
            self._birdeye_probe.mark("OK" if ok else "FAILED", detail=detail)
        if kind == "recovery":
            self._recovery_probe.mark(provider)
        if ok:
            self.clear_provider_pause(provider)

    def _recovery_probe_source(self, provider: str) -> DiscoverySource | None:
        provider = str(provider or "").lower().strip()
        if not self._recovery_probe.due(provider):
            return None
        if provider == "geckoterminal":
            return DiscoverySource(
                "GeckoTerminal recovery probe", "geckoterminal",
                "https://api.geckoterminal.com/api/v2/networks", lambda payload: [],
                cache_ttl=0, probe_only=True, probe_kind="recovery",
            )
        return None

    @staticmethod
    def _tier_allows(current: str, required: str) -> bool:
        return TIER_RANK.get(current, 0) >= TIER_RANK.get(required, 0)

    @staticmethod
    def _core_sources() -> list[DiscoverySource]:
        return [
            DiscoverySource(
                "GeckoTerminal tendências globais",
                "geckoterminal",
                "https://api.geckoterminal.com/api/v2/networks/trending_pools",
                gecko_rows,
                params={"include": "base_token"},
                cache_ttl=max(30, int(settings.scan_discovery_ttl)),
            ),
            DiscoverySource(
                "GeckoTerminal novos globais",
                "geckoterminal",
                "https://api.geckoterminal.com/api/v2/networks/new_pools",
                gecko_rows,
                params={"include": "base_token"},
                cache_ttl=max(30, int(settings.scan_discovery_ttl)),
            ),
            DiscoverySource(
                "DexScreener perfis",
                "dexscreener",
                "https://api.dexscreener.com/token-profiles/latest/v1",
                dex_rows,
                cache_ttl=max(30, int(settings.scan_discovery_ttl)),
            ),
            DiscoverySource(
                "DexScreener boosts",
                "dexscreener",
                "https://api.dexscreener.com/token-boosts/top/v1",
                dex_rows,
                cache_ttl=max(30, int(settings.scan_discovery_ttl)),
            ),
        ]

    def _rotated(self, chains: list[str], count: int) -> list[str]:
        if not chains or count <= 0:
            return []
        start = self.rotation % len(chains)
        rows = [chains[(start + i) % len(chains)] for i in range(min(count, len(chains)))]
        self.rotation = (start + len(rows)) % len(chains)
        return rows

    def sources(self, tier: str, allowed_chains: Iterable[str]) -> list[DiscoverySource]:
        self.last_skipped_unsupported = {}
        self.last_paused_providers = {}
        tier = str(tier or "free").lower()
        allowed = [str(c).lower() for c in allowed_chains if str(c).lower() in CHAIN_MAP.values()]
        result: list[DiscoverySource] = []
        probed_families: set[str] = set()
        for source in self._core_sources():
            pause_reason = self._provider_pause(source.provider)
            if pause_reason:
                self.last_paused_providers[source.provider] = pause_reason
                if source.provider not in probed_families:
                    probe = self._recovery_probe_source(source.provider)
                    if probe is not None:
                        result.append(probe)
                        probed_families.add(source.provider)
                continue
            result.append(source)
        if not settings.multi_provider_enabled or tier == "free":
            return ProviderQualityRouter().order_sources(result)

        # Birdeye: credential changes bypass an old quota cooldown exactly once
        # with a probe-only New Listing request. The probe never yields candidates
        # and therefore can never emit a client signal.
        if settings.birdeye_api_key and self._tier_allows(tier, "plus"):
            if self._birdeye_probe.needs_probe():
                result.append(
                    DiscoverySource(
                        "Birdeye credential probe", "birdeye",
                        "https://public-api.birdeye.so/defi/v2/tokens/new_listing", lambda payload: [],
                        tier="plus", params={"limit": 1},
                        headers={"X-API-KEY": settings.birdeye_api_key, "x-chain": "solana"},
                        cache_ttl=0, chain="solana", probe_only=True, probe_kind="credential",
                    )
                )
                self.last_paused_providers["birdeye"] = "nova credencial detectada • probe seguro pendente"
            else:
                pause_reason = self._provider_pause("birdeye")
                if pause_reason:
                    self.last_paused_providers["birdeye"] = pause_reason
                else:
                    birdeye_candidates = [c for c in allowed if c in BIRDEYE_CHAINS]
                    count = settings.multi_provider_plus_chain_sources if tier == "plus" else settings.multi_provider_premium_chain_sources
                    for chain in self._rotated(birdeye_candidates, count):
                        result.append(
                            DiscoverySource(
                                f"Birdeye novos {chain}",
                                "birdeye",
                                "https://public-api.birdeye.so/defi/v2/tokens/new_listing",
                                (lambda payload, source_chain=chain: birdeye_rows(payload, source_chain)),
                                tier="plus",
                                params=birdeye_new_listing_params(chain),
                                headers={"X-API-KEY": settings.birdeye_api_key, "x-chain": BIRDEYE_CHAINS[chain]},
                                cache_ttl=max(30, int(settings.multi_provider_discovery_ttl)),
                                chain=chain,
                            )
                        )

        # DexPaprika: public/keyless DEX discovery. One rotating chain request
        # per cycle keeps the keyless/public request budget conservative while adding
        # an independent source for non-Solana chains. Current public API
        # responses are cursor/search based and rows live under ``results``.
        if bool(getattr(settings, "dexpaprika_enabled", True)) and self._tier_allows(tier, "plus"):
            pause_reason = self._provider_pause("dexpaprika")
            if pause_reason:
                self.last_paused_providers["dexpaprika"] = pause_reason
            elif str(getattr(settings, "dexpaprika_base_url", "https://api.dexpaprika.com")).startswith("https://"):
                dp_candidates = []
                for chain in (c for c in allowed if c in DEXPAPRIKA_NETWORKS):
                    if self._is_temporarily_unsupported("dexpaprika", chain):
                        self._record_skipped("dexpaprika", chain)
                        continue
                    dp_candidates.append(chain)
                guard_priority = [c for c in priority_chains(limit=3) if c in dp_candidates]
                dp_key = str(getattr(settings, "dexpaprika_api_key", "") or "")
                headers = {"Authorization": dp_key} if dp_key else {}
                normal_count = int(getattr(settings, "dexpaprika_chain_sources", 1))
                extra = int(getattr(settings, "coverage_guard_extra_chain_sources", 1)) if guard_priority else 0
                rotated = self._rotated([c for c in dp_candidates if c not in guard_priority], normal_count)
                selected = (guard_priority[:extra] + rotated)[: max(1, normal_count + extra)]
                for chain in selected:
                    result.append(
                        DiscoverySource(
                            f"DexPaprika novos {chain}",
                            "dexpaprika",
                            f"{str(getattr(settings, 'dexpaprika_base_url', 'https://api.dexpaprika.com')).rstrip('/')}/networks/{DEXPAPRIKA_NETWORKS[chain]}/tokens/search",
                            (lambda payload, source_chain=chain: dexpaprika_rows(payload, source_chain)),
                            tier="plus",
                            params={
                                "limit": min(100, int(getattr(settings, "dexpaprika_discovery_limit", 30))),
                                "order_by": "created_at",
                                "sort": "desc",
                            },
                            headers=headers,
                            cache_ttl=max(60, int(settings.multi_provider_discovery_ttl)),
                            chain=chain,
                        )
                    )

        # CoinGecko Onchain keyed API is an additional channel with independent
        # quotas/authentication.  To protect the mobile 1-minute budget, only
        # Premium uses it by default and only for a rotating subset of chains.
        if settings.coingecko_api_key and self._tier_allows(tier, "premium"):
            pause_reason = self._provider_pause("coingecko")
            if pause_reason:
                self.last_paused_providers["coingecko"] = pause_reason
            else:
                cg_candidates = []
                for chain in (c for c in allowed if c in COINGECKO_NETWORKS):
                    if self._is_temporarily_unsupported("coingecko", chain):
                        self._record_skipped("coingecko", chain)
                        continue
                    cg_candidates.append(chain)
                for chain in self._rotated(cg_candidates, settings.multi_provider_premium_chain_sources):
                    result.append(
                        DiscoverySource(
                            f"CoinGecko Onchain novos {chain}",
                            "coingecko",
                            f"https://api.coingecko.com/api/v3/onchain/networks/{COINGECKO_NETWORKS[chain]}/new_pools",
                            coingecko_rows,
                            tier="premium",
                            params={"include": "base_token"},
                            headers={"x-cg-demo-api-key": settings.coingecko_api_key},
                            cache_ttl=max(30, int(settings.multi_provider_discovery_ttl)),
                            chain=chain,
                        )
                    )
        return ProviderQualityRouter().order_sources(result)
