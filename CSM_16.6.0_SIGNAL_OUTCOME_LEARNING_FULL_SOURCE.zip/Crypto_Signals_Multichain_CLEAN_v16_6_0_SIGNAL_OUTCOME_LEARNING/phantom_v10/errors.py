from __future__ import annotations

from typing import Any
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


class PhantomV10Error(RuntimeError):
    """Base runtime error for the v10 operational layer."""


class NetworkBusyError(PhantomV10Error):
    pass


class TransientNetworkError(PhantomV10Error):
    """Transient HTTPS failure with optional rate-limit metadata.

    ``retry_after`` is intentionally metadata-only. Callers remain responsible
    for deciding whether/when to retry, so existing behavior is preserved for
    all non-rate-limit failures.
    """

    def __init__(self, message: str, *, status: int | None = None, retry_after: int | None = None):
        self.status = int(status or 0)
        try:
            self.retry_after = max(0, int(retry_after or 0))
        except (TypeError, ValueError):
            self.retry_after = 0
        super().__init__(str(message or "Falha HTTPS transitória"))


_SENSITIVE_QUERY_KEYS = {
    "token", "access_token", "api_key", "api-key", "apikey", "key", "secret",
    "x-api-key", "x_cg_demo_api_key", "x-cg-demo-api-key",
}


def sanitize_url(url: str) -> str:
    """Remove credentials before a URL enters exceptions, logs or reports."""
    raw = str(url or "")
    # Telegram embeds the bot token in the path: /bot<TOKEN>/method.
    raw = re.sub(r"/bot[^/]+/", "/bot***REDACTED***/", raw, flags=re.I)
    try:
        parts = urlsplit(raw)
        path = parts.path
        # Common hosted EVM RPC URLs put the credential in /v2/<key> or /v3/<key>.
        # Redact those path tokens before an exception can expose them.
        host = (parts.hostname or "").lower()
        if "alchemy.com" in host or "infura.io" in host:
            path = re.sub(r"/(v[23])/[^/?#]+", r"/\1/***REDACTED***", path, flags=re.I)
        if not parts.query:
            return urlunsplit((parts.scheme, parts.netloc, path, "", parts.fragment))
        query = []
        for key, value in parse_qsl(parts.query, keep_blank_values=True):
            query.append((key, "***REDACTED***" if key.lower() in _SENSITIVE_QUERY_KEYS else value))
        return urlunsplit((parts.scheme, parts.netloc, path, urlencode(query), parts.fragment))
    except Exception:
        return raw


class NetworkHTTPError(PhantomV10Error):
    def __init__(self, status: int, payload: Any, url: str):
        self.status = int(status)
        self.payload = payload
        self.url = sanitize_url(url)
        super().__init__(f"HTTP {self.status} em {self.url}")


class TelegramAPIError(PhantomV10Error):
    def __init__(self, description: str, error_code: int | None = None, *, retry_after: int | None = None):
        self.description = str(description or "Erro Telegram")
        self.error_code = int(error_code) if error_code is not None else None
        try:
            self.retry_after = max(0, int(retry_after or 0))
        except (TypeError, ValueError):
            self.retry_after = 0
        suffix = f" (HTTP {self.error_code})" if self.error_code else ""
        if self.retry_after:
            suffix += f" retry_after={self.retry_after}s"
        super().__init__(self.description + suffix)
