from __future__ import annotations

from typing import Any


GOPLUS_EVM_CHAIN_IDS: dict[str, str] = {
    "ethereum": "1",
    "optimism": "10",
    "cronos": "25",
    "bsc": "56",
    "polygon": "137",
    "fantom": "250",
    "arbitrum": "42161",
    "avalanche": "43114",
    "base": "8453",
}
GOPLUS_SUPPORTED_CHAINS = frozenset({"solana", *GOPLUS_EVM_CHAIN_IDS})


def request_spec(chain: str, address: str, access_token: str = "") -> tuple[str, dict[str, str], dict[str, str]] | None:
    chain_key = str(chain or "").strip().lower()
    address_value = str(address or "").strip()
    if not address_value or chain_key not in GOPLUS_SUPPORTED_CHAINS:
        return None
    if chain_key == "solana":
        url = "https://api.gopluslabs.io/api/v1/solana/token_security"
    else:
        url = f"https://api.gopluslabs.io/api/v1/token_security/{GOPLUS_EVM_CHAIN_IDS[chain_key]}"
    headers: dict[str, str] = {}
    token = str(access_token or "").strip()
    if token:
        headers["Authorization"] = token if token.lower().startswith("bearer ") else f"Bearer {token}"
    return url, {"contract_addresses": address_value}, headers


def _truthy(value: Any) -> bool:
    if isinstance(value, dict):
        value = value.get("status", value.get("value"))
    return str(value if value is not None else "").strip().lower() in {"1", "true", "yes"}


def _number(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _percent_fraction(value: Any) -> float | None:
    number = _number(value)
    if number is None:
        return None
    # GoPlus EVM percentages are documented as fractions where 1 == 100%.
    return max(0.0, number * 100.0)


def _top_holders_percent(rows: Any) -> float | None:
    if not isinstance(rows, list):
        return None
    total = 0.0
    seen = False
    for row in rows[:10]:
        if not isinstance(row, dict):
            continue
        tag = str(row.get("tag") or "").lower()
        # Burn/black-hole balances are not economically controlled supply.
        if "burn" in tag or "black hole" in tag or "dead" in tag:
            continue
        raw = _number(row.get("percent"))
        if raw is None:
            continue
        seen = True
        total += raw * 100.0 if raw <= 1.0 else raw
    return round(total, 2) if seen else None


def extract_result(payload: Any, address: str) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    result = payload.get("result")
    if not isinstance(result, dict) or not result:
        return None
    wanted = str(address or "").strip().lower()
    for key, value in result.items():
        if str(key).strip().lower() == wanted and isinstance(value, dict):
            return value
    # Defensive fallback for APIs that return the queried token as the only row.
    if len(result) == 1:
        only = next(iter(result.values()))
        if isinstance(only, dict):
            return only
    return None


def _base_verdict(chain: str) -> dict[str, Any]:
    return {
        "goplus_checked": True,
        "goplus_available": True,
        "goplus_supported": True,
        "goplus_status": "verified",
        "goplus_score": 100,
        "goplus_risk_level": "BAIXO",
        "goplus_blocked": False,
        "goplus_block_reason": "",
        "goplus_risks": [],
        "goplus_chain": str(chain or "").lower(),
        "goplus_buy_tax_pct": None,
        "goplus_sell_tax_pct": None,
        "goplus_transfer_tax_pct": None,
        "goplus_scheduled_transfer_fee_pct": None,
        "goplus_top10_holders_pct": None,
        "goplus_lp_locked_pct": None,
        "goplus_owner_address": "",
        "goplus_creator_address": "",
    }


def _finish(verdict: dict[str, Any], score: int, risks: list[str], blockers: list[str]) -> dict[str, Any]:
    score = max(0, min(100, int(score)))
    if blockers:
        score = min(score, 25)
    verdict["goplus_score"] = score
    verdict["goplus_risks"] = risks[:8]
    verdict["goplus_blocked"] = bool(blockers)
    verdict["goplus_block_reason"] = blockers[0] if blockers else ""
    if blockers:
        verdict["goplus_status"] = "blocked"
        verdict["goplus_risk_level"] = "CRÍTICO"
    elif score >= 85:
        verdict["goplus_risk_level"] = "BAIXO"
    elif score >= 70:
        verdict["goplus_risk_level"] = "MODERADO"
    elif score >= 50:
        verdict["goplus_risk_level"] = "ELEVADO"
    else:
        verdict["goplus_risk_level"] = "ALTO"
    return verdict


def evaluate_evm(data: dict[str, Any], *, max_buy_tax_pct: float = 25.0, max_sell_tax_pct: float = 25.0) -> dict[str, Any]:
    verdict = _base_verdict("evm")
    score = 100
    risks: list[str] = []
    blockers: list[str] = []
    verdict["goplus_owner_address"] = str(data.get("owner_address") or "").strip()[:128]
    verdict["goplus_creator_address"] = str(data.get("creator_address") or "").strip()[:128]

    hard_flags = (
        ("is_honeypot", "honeypot detectado"),
        ("cannot_buy", "compra bloqueada"),
        ("owner_change_balance", "owner pode alterar saldo dos holders"),
        ("selfdestruct", "contrato pode se autodestruir"),
        ("gas_abuse", "abuso de gas detectado"),
        ("is_airdrop_scam", "airdrop scam detectado"),
    )
    for field, label in hard_flags:
        if _truthy(data.get(field)):
            blockers.append(label)
            risks.append(label)

    fake = data.get("fake_token")
    if isinstance(fake, dict) and _truthy(fake.get("value")):
        blockers.append("token falso/imitador detectado")
        risks.append("token falso/imitador detectado")

    buy_tax = _percent_fraction(data.get("buy_tax"))
    sell_tax = _percent_fraction(data.get("sell_tax"))
    transfer_tax = _percent_fraction(data.get("transfer_tax"))
    verdict["goplus_buy_tax_pct"] = round(buy_tax, 2) if buy_tax is not None else None
    verdict["goplus_sell_tax_pct"] = round(sell_tax, 2) if sell_tax is not None else None
    verdict["goplus_transfer_tax_pct"] = round(transfer_tax, 2) if transfer_tax is not None else None
    if buy_tax is not None and buy_tax >= max_buy_tax_pct:
        blockers.append(f"buy tax {buy_tax:.1f}% acima do limite")
        risks.append(f"buy tax elevado ({buy_tax:.1f}%)")
    elif buy_tax is not None and buy_tax >= 10:
        score -= 8
        risks.append(f"buy tax relevante ({buy_tax:.1f}%)")
    if sell_tax is not None and sell_tax >= max_sell_tax_pct:
        blockers.append(f"sell tax {sell_tax:.1f}% acima do limite")
        risks.append(f"sell tax elevado ({sell_tax:.1f}%)")
    elif sell_tax is not None and sell_tax >= 10:
        score -= 10
        risks.append(f"sell tax relevante ({sell_tax:.1f}%)")
    if transfer_tax is not None and transfer_tax >= max_sell_tax_pct:
        blockers.append(f"transfer tax {transfer_tax:.1f}% acima do limite")
        risks.append(f"transfer tax elevada ({transfer_tax:.1f}%)")
    elif transfer_tax is not None and transfer_tax >= 10:
        score -= 8
        risks.append(f"transfer tax relevante ({transfer_tax:.1f}%)")

    weighted_flags = (
        ("is_open_source", "0", 22, "contrato não verificado/open-source"),
        ("is_proxy", "1", 12, "contrato proxy/modificável"),
        ("is_mintable", "1", 15, "função de mint ativa"),
        ("can_take_back_ownership", "1", 16, "ownership pode ser recuperada"),
        ("hidden_owner", "1", 20, "owner oculto"),
        ("transfer_pausable", "1", 14, "transferências podem ser pausadas"),
        ("is_blacklisted", "1", 13, "função de blacklist"),
        ("is_whitelisted", "1", 5, "função de whitelist"),
        ("slippage_modifiable", "1", 15, "taxa/slippage modificável"),
        ("personal_slippage_modifiable", "1", 18, "taxa individual modificável"),
        ("anti_whale_modifiable", "1", 8, "anti-whale modificável"),
        ("trading_cooldown", "1", 5, "cooldown de negociação"),
        ("cannot_sell_all", "1", 15, "não permite vender 100% da posição"),
    )
    for field, bad, penalty, label in weighted_flags:
        value = str(data.get(field) if data.get(field) is not None else "").strip()
        if value == bad:
            score -= penalty
            risks.append(label)

    other_risk = str(data.get("other_potential_risks") or "").strip()
    if other_risk:
        score -= 8
        risks.append("risco adicional GoPlus: " + other_risk[:100])

    top10 = _top_holders_percent(data.get("holders"))
    verdict["goplus_top10_holders_pct"] = top10
    if top10 is not None:
        if top10 >= 80:
            score -= 20
            risks.append(f"concentração top10 muito alta ({top10:.1f}%)")
        elif top10 >= 55:
            score -= 12
            risks.append(f"concentração top10 alta ({top10:.1f}%)")

    owner = _percent_fraction(data.get("owner_percent"))
    creator = _percent_fraction(data.get("creator_percent"))
    controlling = max([value for value in (owner, creator) if value is not None], default=None)
    if controlling is not None and controlling >= 25:
        score -= 15
        risks.append(f"owner/criador concentra {controlling:.1f}%")

    lp_rows = data.get("lp_holders")
    if isinstance(lp_rows, list) and lp_rows:
        locked = 0.0
        seen = False
        for row in lp_rows[:10]:
            if not isinstance(row, dict):
                continue
            if _truthy(row.get("is_locked")):
                percent = _number(row.get("percent"))
                if percent is not None:
                    seen = True
                    locked += percent * 100.0 if percent <= 1 else percent
        if seen:
            verdict["goplus_lp_locked_pct"] = round(min(100.0, locked), 2)

    return _finish(verdict, score, risks, blockers)


def _sol_flag(data: dict[str, Any], field: str) -> bool:
    value = data.get(field)
    return _truthy(value)


def _has_malicious_nested(value: Any) -> bool:
    if isinstance(value, dict):
        if _truthy(value.get("malicious_address")):
            return True
        return any(_has_malicious_nested(item) for item in value.values())
    if isinstance(value, list):
        return any(_has_malicious_nested(item) for item in value)
    return False


def evaluate_solana(data: dict[str, Any], *, max_transfer_fee_pct: float = 25.0) -> dict[str, Any]:
    verdict = _base_verdict("solana")
    score = 100
    risks: list[str] = []
    blockers: list[str] = []

    if str(data.get("default_account_state") or "").strip() == "2":
        blockers.append("novas contas de token nascem congeladas")
        risks.append("default account state = Frozen")
    if _truthy(data.get("non_transferable")):
        blockers.append("token não transferível")
        risks.append("token não transferível")
    if _sol_flag(data, "balance_mutable_authority"):
        blockers.append("autoridade pode alterar saldo dos holders")
        risks.append("balance mutable authority ativa")

    creators = data.get("creator")
    if isinstance(creators, list):
        creator_rows = creators
    elif isinstance(creators, dict):
        creator_rows = [creators]
    else:
        creator_rows = []
    for row in creator_rows:
        if not isinstance(row, dict):
            continue
        candidate = str(row.get("address") or row.get("creator_address") or row.get("owner") or "").strip()
        if candidate:
            verdict["goplus_creator_address"] = candidate[:128]
            break
    if any(_truthy(row.get("malicious_address")) for row in creator_rows if isinstance(row, dict)):
        blockers.append("criador marcado como malicioso")
        risks.append("criador malicioso")

    hook = data.get("transfer_hook")
    if isinstance(hook, dict) and _truthy(hook.get("malicious_address")):
        blockers.append("transfer hook malicioso")
        risks.append("transfer hook malicioso")

    weighted = (
        ("mintable", 12, "mint authority ativa"),
        ("freezable", 16, "freeze authority ativa"),
        ("closable", 20, "programa/token pode ser fechado"),
        ("transfer_fee_upgradable", 10, "transfer fee atualizável"),
        ("default_account_state_upgradable", 14, "estado padrão das contas atualizável"),
        ("transfer_hook_upgradable", 14, "transfer hook atualizável"),
        ("metadata_mutable", 4, "metadata mutável"),
    )
    for field, penalty, label in weighted:
        value = data.get(field)
        if _sol_flag(data, field):
            score -= penalty
            risks.append(label)
        if _has_malicious_nested(value):
            blockers.append(f"autoridade maliciosa em {field}")
            risks.append(f"autoridade maliciosa em {field}")

    fee = data.get("transfer_fee")
    if isinstance(fee, dict):
        current = fee.get("current_fee_rate")
        scheduled = fee.get("scheduled_fee_rate")
        raw_rate = _number(current.get("fee_rate")) if isinstance(current, dict) else _number(current)
        scheduled_raw = _number(scheduled.get("fee_rate")) if isinstance(scheduled, dict) else _number(scheduled)
        # Solana GoPlus documents fee_rate in parts per ten-thousand.
        current_pct = max(0.0, raw_rate / 100.0) if raw_rate is not None else None
        scheduled_pct = max(0.0, scheduled_raw / 100.0) if scheduled_raw is not None else None
        verdict["goplus_sell_tax_pct"] = round(current_pct, 2) if current_pct is not None else None
        verdict["goplus_transfer_tax_pct"] = verdict["goplus_sell_tax_pct"]
        verdict["goplus_scheduled_transfer_fee_pct"] = round(scheduled_pct, 2) if scheduled_pct is not None else None
        effective_pct = max([v for v in (current_pct, scheduled_pct) if v is not None], default=None)
        if effective_pct is not None:
            if effective_pct >= max_transfer_fee_pct:
                label = "transfer fee agendada" if scheduled_pct is not None and scheduled_pct == effective_pct and scheduled_pct != current_pct else "transfer fee"
                blockers.append(f"{label} {effective_pct:.1f}% acima do limite")
                risks.append(f"{label} elevada ({effective_pct:.1f}%)")
            elif effective_pct >= 10:
                score -= 10
                risks.append(f"transfer fee relevante ({effective_pct:.1f}%)")

    top10 = _top_holders_percent(data.get("holders"))
    verdict["goplus_top10_holders_pct"] = top10
    if top10 is not None:
        if top10 >= 80:
            score -= 20
            risks.append(f"concentração top10 muito alta ({top10:.1f}%)")
        elif top10 >= 55:
            score -= 12
            risks.append(f"concentração top10 alta ({top10:.1f}%)")

    lp_rows = data.get("lp_holders")
    if isinstance(lp_rows, list) and lp_rows:
        locked = 0.0
        seen = False
        for row in lp_rows[:10]:
            if not isinstance(row, dict):
                continue
            if _truthy(row.get("is_locked")):
                percent = _number(row.get("percent"))
                if percent is not None:
                    seen = True
                    locked += percent * 100.0 if percent <= 1 else percent
        if seen:
            verdict["goplus_lp_locked_pct"] = round(min(100.0, locked), 2)

    return _finish(verdict, score, risks, blockers)


def evaluate(chain: str, data: dict[str, Any], *, max_buy_tax_pct: float = 25.0, max_sell_tax_pct: float = 25.0) -> dict[str, Any]:
    chain_key = str(chain or "").strip().lower()
    if chain_key == "solana":
        return evaluate_solana(data, max_transfer_fee_pct=max_sell_tax_pct)
    return evaluate_evm(data, max_buy_tax_pct=max_buy_tax_pct, max_sell_tax_pct=max_sell_tax_pct)


def unavailable(chain: str, reason: str = "provider indisponível") -> dict[str, Any]:
    return {
        **_base_verdict(chain),
        "goplus_checked": False,
        "goplus_available": False,
        "goplus_status": "unavailable",
        "goplus_score": None,
        "goplus_risk_level": "NÃO VERIFICADO",
        "goplus_risks": [str(reason or "provider indisponível")[:120]],
    }


def unsupported(chain: str) -> dict[str, Any]:
    return {
        **_base_verdict(chain),
        "goplus_checked": False,
        "goplus_available": False,
        "goplus_supported": False,
        "goplus_status": "unsupported",
        "goplus_score": None,
        "goplus_risk_level": "NÃO SUPORTADO",
        "goplus_risks": [],
    }
