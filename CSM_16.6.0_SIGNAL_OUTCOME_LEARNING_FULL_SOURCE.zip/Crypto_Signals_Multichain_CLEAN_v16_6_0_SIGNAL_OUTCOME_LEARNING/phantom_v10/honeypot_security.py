from __future__ import annotations

"""Keyless EVM security fallback backed by Honeypot.is.

This adapter is intentionally *not* a discovery source.  It is used only when
GoPlus is unavailable or returns no token data, preserving the existing live
scanner gates by default.  ``HONEYPOT_ENFORCE_BLOCKS`` can be enabled explicitly
later after local evidence has been reviewed.
"""

from typing import Any

HONEYPOT_CHAIN_IDS: dict[str, int] = {
    "ethereum": 1,
    "bsc": 56,
    "base": 8453,
}
HONEYPOT_SUPPORTED_CHAINS = frozenset(HONEYPOT_CHAIN_IDS)


def request_spec(chain: str, address: str, base_url: str, api_key: str = "") -> tuple[str, dict[str, Any], dict[str, str]] | None:
    chain_key = str(chain or "").strip().lower()
    address_value = str(address or "").strip()
    base = str(base_url or "").strip().rstrip("/")
    if chain_key not in HONEYPOT_SUPPORTED_CHAINS or not address_value or not base.startswith("https://"):
        return None
    headers: dict[str, str] = {}
    if str(api_key or "").strip():
        headers["X-API-KEY"] = str(api_key).strip()
    return f"{base}/v2/IsHoneypot", {"address": address_value, "chainID": HONEYPOT_CHAIN_IDS[chain_key]}, headers


def _number(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _base(chain: str) -> dict[str, Any]:
    return {
        "honeypot_checked": True,
        "honeypot_available": True,
        "honeypot_supported": True,
        "honeypot_status": "verified",
        "honeypot_score": None,
        "honeypot_risk": "unknown",
        "honeypot_risk_level": None,
        "honeypot_detected": False,
        "honeypot_reason": "",
        "honeypot_buy_tax_pct": None,
        "honeypot_sell_tax_pct": None,
        "honeypot_transfer_tax_pct": None,
        "honeypot_total_holders": None,
        "honeypot_pair_liquidity_usd": None,
        "honeypot_pair_created_at": None,
        "honeypot_open_source": None,
        "honeypot_is_proxy": None,
        "honeypot_flags": [],
        "honeypot_chain": str(chain or "").strip().lower(),
        "security_provider": "Honeypot.is",
        "security_score": None,
    }


def evaluate(chain: str, payload: Any, *, max_buy_tax_pct: float = 25.0, max_sell_tax_pct: float = 25.0) -> dict[str, Any]:
    verdict = _base(chain)
    if not isinstance(payload, dict):
        return unavailable(chain, "resposta inválida")

    summary = payload.get("summary") or {}
    hp = payload.get("honeypotResult") or {}
    sim = payload.get("simulationResult") or {}
    token = payload.get("token") or {}
    pair = payload.get("pair") or {}
    pair_inner = pair.get("pair") or {}
    code = payload.get("contractCode") or {}

    risk = str(summary.get("risk") or "unknown").strip().lower()
    risk_level = _number(summary.get("riskLevel"))
    detected = bool(hp.get("isHoneypot") is True or risk == "honeypot")
    reason = str(hp.get("honeypotReason") or "").strip()[:160]
    buy_tax = _number(sim.get("buyTax"))
    sell_tax = _number(sim.get("sellTax"))
    transfer_tax = _number(sim.get("transferTax"))

    flags: list[str] = []
    for raw in summary.get("flags") or payload.get("flags") or []:
        if isinstance(raw, dict):
            label = raw.get("flag") or raw.get("description")
        else:
            label = raw
        if label and str(label) not in flags:
            flags.append(str(label)[:80])

    verdict.update({
        "honeypot_risk": risk,
        "honeypot_risk_level": int(risk_level) if risk_level is not None else None,
        "honeypot_detected": detected,
        "honeypot_reason": reason,
        "honeypot_buy_tax_pct": round(buy_tax, 2) if buy_tax is not None else None,
        "honeypot_sell_tax_pct": round(sell_tax, 2) if sell_tax is not None else None,
        "honeypot_transfer_tax_pct": round(transfer_tax, 2) if transfer_tax is not None else None,
        "honeypot_total_holders": int(_number(token.get("totalHolders")) or 0) if token.get("totalHolders") is not None else None,
        "honeypot_pair_liquidity_usd": _number(pair.get("liquidity")),
        "honeypot_pair_created_at": str(pair.get("createdAtTimestamp") or "")[:32] or None,
        "honeypot_open_source": code.get("openSource") if isinstance(code.get("openSource"), bool) else None,
        "honeypot_is_proxy": code.get("isProxy") if isinstance(code.get("isProxy"), bool) else None,
        "honeypot_flags": flags[:8],
    })

    # Honeypot.is riskLevel is 0..100 where higher is riskier. Convert to the
    # CSM security convention where higher is safer. Unknown remains None and
    # therefore cannot inflate/penalize a live score.
    if risk_level is not None:
        score = max(0, min(100, int(round(100.0 - risk_level))))
        verdict["honeypot_score"] = score
        verdict["security_score"] = score
    if detected:
        verdict["honeypot_score"] = 0
        verdict["security_score"] = 0
        verdict["honeypot_status"] = "honeypot"
    elif (buy_tax is not None and buy_tax >= max_buy_tax_pct) or (sell_tax is not None and sell_tax >= max_sell_tax_pct):
        verdict["honeypot_status"] = "high_tax"
        if verdict["security_score"] is not None:
            verdict["security_score"] = min(int(verdict["security_score"]), 35)
            verdict["honeypot_score"] = verdict["security_score"]
    return verdict


def unavailable(chain: str, reason: str = "provider indisponível") -> dict[str, Any]:
    return {
        **_base(chain),
        "honeypot_checked": False,
        "honeypot_available": False,
        "honeypot_status": "unavailable",
        "honeypot_flags": [str(reason or "provider indisponível")[:120]],
    }


def unsupported(chain: str) -> dict[str, Any]:
    return {
        **_base(chain),
        "honeypot_checked": False,
        "honeypot_available": False,
        "honeypot_supported": False,
        "honeypot_status": "unsupported",
        "honeypot_flags": [],
    }
