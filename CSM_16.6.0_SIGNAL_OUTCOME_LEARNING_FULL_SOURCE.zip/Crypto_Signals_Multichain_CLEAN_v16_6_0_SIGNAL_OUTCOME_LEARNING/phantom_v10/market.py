from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

from csm.chains import CHAINS
from csm.config import settings

from .providers import ProviderGateway
from .discovery import DEXPAPRIKA_NETWORKS
from .transport import StdlibHttpTransport


class MarketService:
    def __init__(self, transport: StdlibHttpTransport | None = None, providers: ProviderGateway | None = None):
        self.transport = transport or StdlibHttpTransport(timeout=3.0, label="market")
        self.providers = providers or ProviderGateway()
        self.cache: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}

    def fetch(self, chain: str, address: str, *, force: bool = False) -> dict[str, Any]:
        key = (str(chain), str(address))
        cached = self.cache.get(key)
        if not force and cached and time.time() - cached[0] <= settings.cache_ttl:
            row = dict(cached[1])
            row["cached"] = True
            return row

        gecko_network = (CHAINS.get(chain) or {}).get("gecko")
        if gecko_network:
            payload = self.providers.fetch(
                "GeckoTerminal market",
                lambda: self.transport.get_json(
                    f"https://api.geckoterminal.com/api/v2/networks/{gecko_network}/tokens/{address}/pools",
                    {"page": "1", "include": "base_token,quote_token,dex"},
                    timeout=3.0,
                ),
                cache_key=f"gecko:{chain}:{address}",
                cache_ttl=30,
                stale_ttl=900,
                force=force,
            )
            if isinstance(payload, dict) and payload.get("data"):
                result = self.normalize_gecko(
                    payload["data"][0],
                    chain,
                    address,
                    included=payload.get("included") or [],
                )
                self.cache[key] = (time.time(), result)
                return dict(result)

        payload = self.providers.fetch(
            "DexScreener market",
            lambda: self.transport.get_json(
                f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}",
                timeout=3.0,
            ),
            cache_key=f"dex:{chain}:{address}",
            cache_ttl=30,
            stale_ttl=900,
            force=force,
        )
        if isinstance(payload, list) and payload:
            best = max(payload, key=lambda p: float((p.get("liquidity") or {}).get("usd") or 0))
            result = self.normalize_dex(best)
            self.cache[key] = (time.time(), result)
            return dict(result)

        if settings.dexpaprika_enabled and settings.dexpaprika_market_fallback and chain in DEXPAPRIKA_NETWORKS and settings.dexpaprika_base_url.startswith("https://"):
            dp_headers = {"Authorization": settings.dexpaprika_api_key} if settings.dexpaprika_api_key else None
            dp_transport = self.transport.clone(label="market:DexPaprika", headers=dp_headers) if dp_headers else self.transport
            payload = self.providers.fetch(
                "DexPaprika market",
                lambda: dp_transport.get_json(
                    f"{settings.dexpaprika_base_url}/networks/{DEXPAPRIKA_NETWORKS[chain]}/tokens/{address}",
                    timeout=3.0,
                ),
                cache_key=f"dexpaprika:{chain}:{address}",
                cache_ttl=60,
                stale_ttl=900,
                force=force,
            )
            if isinstance(payload, dict) and (payload.get("summary") or payload.get("price_usd")):
                result = self.normalize_dexpaprika(payload, chain, address)
                self.cache[key] = (time.time(), result)
                return dict(result)

        if cached:
            row = dict(cached[1])
            row["cached"] = True
            row["stale_cache"] = True
            return row
        raise RuntimeError("Fontes de mercado indisponíveis neste momento.")

    @staticmethod
    def normalize_dex(pair: dict[str, Any]) -> dict[str, Any]:
        created = pair.get("pairCreatedAt")
        age_days = None
        if created:
            age_days = max(0.0, (datetime.now(timezone.utc).timestamp() - float(created) / 1000) / 86400)
        txns = pair.get("txns") or {}
        volume = pair.get("volume") or {}
        changes = pair.get("priceChange") or {}
        token = pair.get("baseToken") or {}
        quote = pair.get("quoteToken") or {}
        info = pair.get("info") or {}
        boosts = pair.get("boosts") or {}
        return {
            "source": "DexScreener",
            "chain": pair.get("chainId"),
            "name": token.get("name", "Token"),
            "symbol": token.get("symbol", "?"),
            "address": token.get("address", ""),
            "price": float(pair.get("priceUsd") or 0),
            "liquidity": float((pair.get("liquidity") or {}).get("usd") or 0),
            "volume24h": float(volume.get("h24") or 0),
            "volume6h": float(volume.get("h6") or 0),
            "volume1h": float(volume.get("h1") or 0),
            "volume5m": float(volume.get("m5") or 0),
            "marketcap": float(pair.get("marketCap") or 0),
            "fdv": float(pair.get("fdv") or 0),
            "change24h": float(changes.get("h24") or 0),
            "change6h": float(changes.get("h6") or 0),
            "change1h": float(changes.get("h1") or 0),
            "change5m": float(changes.get("m5") or 0),
            "buys24h": int((txns.get("h24") or {}).get("buys") or 0),
            "sells24h": int((txns.get("h24") or {}).get("sells") or 0),
            "buys6h": int((txns.get("h6") or {}).get("buys") or 0),
            "sells6h": int((txns.get("h6") or {}).get("sells") or 0),
            "buys1h": int((txns.get("h1") or {}).get("buys") or 0),
            "sells1h": int((txns.get("h1") or {}).get("sells") or 0),
            "buys5m": int((txns.get("m5") or {}).get("buys") or 0),
            "sells5m": int((txns.get("m5") or {}).get("sells") or 0),
            "buyers24h": None,
            "sellers24h": None,
            "buyers1h": None,
            "sellers1h": None,
            "age_days": age_days,
            "dex": pair.get("dexId", ""),
            "pair": pair.get("pairAddress", ""),
            "pair_name": f"{token.get('symbol') or '?'} / {quote.get('symbol') or '?'}",
            "quote_symbol": quote.get("symbol", ""),
            "url": pair.get("url", ""),
            "image_url": info.get("imageUrl", ""),
            "websites": list(info.get("websites") or []),
            "socials": list(info.get("socials") or []),
            "boosts_active": int(boosts.get("active") or 0),
            "labels": list(pair.get("labels") or []),
            "sentiment_positive": None,
            "sentiment_negative": None,
            "community_sus_report": None,
            "last_trade_timestamp": None,
            "holders": None,
            "cached": False,
        }

    @classmethod
    def normalize_dexpaprika(cls, item: dict[str, Any], chain: str, address: str) -> dict[str, Any]:
        summary = item.get("summary") or {}
        h24 = summary.get("24h") or item.get("24h") or {}
        h6 = summary.get("6h") or item.get("6h") or {}
        h1 = summary.get("1h") or item.get("1h") or {}
        m5 = summary.get("5m") or item.get("5m") or {}
        fdv = float(summary.get("fdv") or item.get("fdv_usd") or 0)
        return {
            "source": "DexPaprika", "chain": chain,
            "name": str(item.get("name") or item.get("symbol") or "Token"),
            "symbol": str(item.get("symbol") or "?"), "address": address,
            "price": float(summary.get("price_usd") or item.get("price_usd") or 0),
            "liquidity": float(summary.get("liquidity_usd") or item.get("liquidity_usd") or 0),
            "volume24h": float(h24.get("volume_usd") or item.get("volume_usd_24h") or 0),
            "volume6h": float(h6.get("volume_usd") or 0), "volume1h": float(h1.get("volume_usd") or 0),
            "volume5m": float(m5.get("volume_usd") or 0),
            "marketcap": fdv, "fdv": fdv,
            "change24h": float(item.get("price_change_percentage_24h") or h24.get("last_price_usd_change") or 0),
            "change6h": float(h6.get("last_price_usd_change") or 0),
            "change1h": float(h1.get("last_price_usd_change") or 0),
            "change5m": float(m5.get("last_price_usd_change") or 0),
            "buys24h": int(h24.get("buys") or 0), "sells24h": int(h24.get("sells") or 0),
            "buys6h": int(h6.get("buys") or 0), "sells6h": int(h6.get("sells") or 0),
            "buys1h": int(h1.get("buys") or 0), "sells1h": int(h1.get("sells") or 0),
            "buys5m": int(m5.get("buys") or 0), "sells5m": int(m5.get("sells") or 0),
            "buyers24h": None, "sellers24h": None, "buyers1h": None, "sellers1h": None,
            "age_days": cls._age_from_iso(item.get("added_at") or item.get("created_at")),
            "dex": "DexPaprika aggregate", "pair": "", "pair_name": "", "quote_symbol": "",
            "url": "", "image_url": "", "websites": [], "socials": [], "boosts_active": 0,
            "labels": [], "sentiment_positive": None, "sentiment_negative": None,
            "community_sus_report": None, "last_trade_timestamp": item.get("last_updated"),
            "holders": None, "cached": False,
        }

    @staticmethod
    def _same_address(left: Any, right: Any) -> bool:
        left_text = str(left or "").strip()
        right_text = str(right or "").strip()
        if left_text.startswith("0x") or right_text.startswith("0x"):
            return left_text.lower() == right_text.lower()
        return left_text == right_text

    @staticmethod
    def _relationship_matches(resource_id: Any, address: str) -> bool:
        resource = str(resource_id or "").strip()
        if resource.startswith("0x") or str(address).startswith("0x"):
            return resource.lower() == str(address).lower() or resource.lower().endswith("_" + str(address).lower())
        return resource == str(address) or resource.endswith("_" + str(address))

    @staticmethod
    def _age_from_iso(value: Any) -> float | None:
        if not value:
            return None
        try:
            created = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            return max(0.0, (datetime.now(timezone.utc) - created.astimezone(timezone.utc)).total_seconds() / 86400)
        except (TypeError, ValueError):
            return None

    @classmethod
    def normalize_gecko(
        cls,
        item: dict[str, Any],
        chain: str,
        address: str,
        *,
        included: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        attrs = item.get("attributes") or {}
        txns = attrs.get("transactions") or {}
        volume = attrs.get("volume_usd") or {}
        changes = attrs.get("price_change_percentage") or {}
        relationships = item.get("relationships") or {}
        included_rows = included or []
        resources = {str(row.get("id") or ""): row for row in included_rows if isinstance(row, dict)}

        base_ref = ((relationships.get("base_token") or {}).get("data") or {}).get("id", "")
        quote_ref = ((relationships.get("quote_token") or {}).get("data") or {}).get("id", "")
        dex_ref = ((relationships.get("dex") or {}).get("data") or {}).get("id", "")
        base_row = resources.get(str(base_ref)) or {}
        quote_row = resources.get(str(quote_ref)) or {}
        dex_row = resources.get(str(dex_ref)) or {}
        base_meta = base_row.get("attributes") or {}
        quote_meta = quote_row.get("attributes") or {}
        dex_meta = dex_row.get("attributes") or {}

        requested_meta: dict[str, Any] = {}
        requested_side = "base"
        for row in included_rows:
            if not isinstance(row, dict) or row.get("type") != "token":
                continue
            meta = row.get("attributes") or {}
            if cls._same_address(meta.get("address"), address):
                requested_meta = meta
                requested_side = "quote" if str(row.get("id") or "") == str(quote_ref) else "base"
                break
        if not requested_meta:
            if cls._relationship_matches(quote_ref, address):
                requested_meta = quote_meta
                requested_side = "quote"
            elif cls._relationship_matches(base_ref, address):
                requested_meta = base_meta

        pool_name = str(attrs.get("name") or "").strip()
        pool_parts = [part.strip() for part in pool_name.split("/") if part.strip()]
        fallback_symbol = pool_parts[1] if requested_side == "quote" and len(pool_parts) > 1 else (pool_parts[0] if pool_parts else "")
        symbol = str(requested_meta.get("symbol") or fallback_symbol or "TOKEN").strip()
        name = str(requested_meta.get("name") or symbol).strip()
        other_meta = base_meta if requested_side == "quote" else quote_meta
        other_fallback = pool_parts[0] if requested_side == "quote" and pool_parts else (pool_parts[1] if len(pool_parts) > 1 else "")
        quote_symbol = str(other_meta.get("symbol") or other_fallback or "").strip()
        pair_address = str(attrs.get("address") or "").strip()
        gecko_network = (CHAINS.get(chain) or {}).get("gecko") or chain
        dex_name = str(dex_meta.get("name") or dex_ref or "").strip()
        age_days = cls._age_from_iso(attrs.get("pool_created_at"))

        return {
            "source": "GeckoTerminal",
            "chain": chain,
            "name": name,
            "symbol": symbol,
            "address": address,
            "price": float(
                attrs.get("token_price_usd")
                or (attrs.get("quote_token_price_usd") if requested_side == "quote" else attrs.get("base_token_price_usd"))
                or 0
            ),
            "liquidity": float(attrs.get("reserve_in_usd") or 0),
            "volume24h": float(volume.get("h24") or 0),
            "volume6h": float(volume.get("h6") or 0),
            "volume1h": float(volume.get("h1") or 0),
            "volume5m": float(volume.get("m5") or 0),
            "marketcap": float(attrs.get("market_cap_usd") or 0),
            "fdv": float(attrs.get("fdv_usd") or 0),
            "change24h": float(changes.get("h24") or 0),
            "change6h": float(changes.get("h6") or 0),
            "change1h": float(changes.get("h1") or 0),
            "change5m": float(changes.get("m5") or 0),
            "buys24h": int((txns.get("h24") or {}).get("buys") or 0),
            "sells24h": int((txns.get("h24") or {}).get("sells") or 0),
            "buys6h": int((txns.get("h6") or {}).get("buys") or 0),
            "sells6h": int((txns.get("h6") or {}).get("sells") or 0),
            "buys1h": int((txns.get("h1") or {}).get("buys") or 0),
            "sells1h": int((txns.get("h1") or {}).get("sells") or 0),
            "buys5m": int((txns.get("m5") or {}).get("buys") or 0),
            "sells5m": int((txns.get("m5") or {}).get("sells") or 0),
            "buyers24h": (txns.get("h24") or {}).get("buyers"),
            "sellers24h": (txns.get("h24") or {}).get("sellers"),
            "buyers1h": (txns.get("h1") or {}).get("buyers"),
            "sellers1h": (txns.get("h1") or {}).get("sellers"),
            "age_days": age_days,
            "dex": dex_name,
            "pair": pair_address or item.get("id", ""),
            "pair_name": pool_name,
            "quote_symbol": quote_symbol,
            "url": f"https://www.geckoterminal.com/{gecko_network}/pools/{pair_address}" if pair_address else "",
            "image_url": requested_meta.get("image_url", ""),
            "websites": [],
            "socials": [],
            "boosts_active": 0,
            "labels": [],
            "sentiment_positive": attrs.get("sentiment_vote_positive_percentage"),
            "sentiment_negative": attrs.get("sentiment_vote_negative_percentage"),
            "community_sus_report": attrs.get("community_sus_report"),
            "last_trade_timestamp": attrs.get("last_trade_timestamp"),
            "holders": None,
            "cached": False,
        }
