from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from csm.config import settings
from csm.onchain import OnChainLedger

from .errors import NetworkHTTPError, TransientNetworkError
from .transport import StdlibHttpTransport

TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
ZERO_EVM = "0x" + "0" * 40
EVM_CHAINS = frozenset({"ethereum", "bsc", "base", "arbitrum", "polygon", "avalanche", "optimism", "fantom", "cronos"})


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _i(value: Any, default: int = 0) -> int:
    try:
        if isinstance(value, str) and value.startswith("0x"):
            return int(value, 16)
        return int(value)
    except (TypeError, ValueError):
        return default


def _evm_addr(topic: Any) -> str:
    text = str(topic or "").lower().replace("0x", "")
    return "0x" + text[-40:].rjust(40, "0") if text else ""


def _safe_error(exc: Exception) -> str:
    if isinstance(exc, NetworkHTTPError):
        return f"HTTP {exc.status}"
    text = str(exc or "").lower()
    if "429" in text or "too many" in text:
        return "rate-limit"
    if "timeout" in text:
        return "timeout"
    if "ssl" in text or "tls" in text:
        return "TLS"
    if "busy" in text or "ocupada" in text:
        return "network-busy"
    return type(exc).__name__


def _jsonrpc_map(payload: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(payload, list):
        return {}
    return {str(row.get("id")): row for row in payload if isinstance(row, dict)}


def _sol_ui_amount(row: dict[str, Any]) -> float:
    ui = row.get("uiTokenAmount") if isinstance(row, dict) else None
    if isinstance(ui, dict):
        return _f(ui.get("uiAmountString") or ui.get("uiAmount"))
    return _f(row.get("uiAmountString") or row.get("uiAmount")) if isinstance(row, dict) else 0.0


def _sol_token_deltas(tx: dict[str, Any], mint: str) -> dict[str, float]:
    """Return owner-level SPL balance changes for one transaction."""
    meta = tx.get("meta") if isinstance(tx, dict) else None
    if not isinstance(meta, dict):
        return {}
    pre = meta.get("preTokenBalances") or []
    post = meta.get("postTokenBalances") or []
    balances: dict[str, list[float]] = {}
    for side, rows in ((0, pre), (1, post)):
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict) or str(row.get("mint") or "") != mint:
                continue
            owner = str(row.get("owner") or f"accountIndex:{row.get('accountIndex', '?')}")
            pair = balances.setdefault(owner, [0.0, 0.0])
            pair[side] += _sol_ui_amount(row)
    return {owner: post_v - pre_v for owner, (pre_v, post_v) in balances.items() if abs(post_v - pre_v) > 1e-18}


class OnChainMonitor:
    """Portable polling-only post-signal intelligence.

    Each ``observe_one`` makes at most one HTTPS request. Solana uses a bounded
    Helius JSON-RPC batch and EVM uses a bounded JSON-RPC batch. There are no
    webhooks, inbound listeners, subprocesses, background threads or websocket
    clients, keeping the same runtime contract on a-Shell/iOS and Termux/Android.
    """

    def __init__(self, storage, transport: StdlibHttpTransport):
        self.storage = storage
        self.ledger = OnChainLedger(storage)
        self.transport = transport.clone(label="onchain", timeout=float(settings.onchain_request_timeout_seconds))

    @staticmethod
    def capability(chain: str) -> dict[str, Any]:
        chain = str(chain or "").lower()
        if chain == "solana":
            return {"supported": True, "ready": settings.helius_ready, "source": "Helius RPC", "mode": "polling"}
        if chain in EVM_CHAINS:
            return {"supported": True, "ready": bool(settings.evm_rpc_url(chain)), "source": "EVM JSON-RPC", "mode": "polling"}
        return {"supported": False, "ready": False, "source": "", "mode": "polling"}

    def due_signals(self, *, limit: int = 10, minimum_gap_seconds: int | None = None) -> list[dict[str, Any]]:
        # Fetch a little wider, then keep only chains whose polling source is
        # actually configured. Unsupported/unconfigured chains never consume
        # scheduler slots.
        rows = self.ledger.due_signals(limit=max(1, int(limit)) * 4, minimum_gap_seconds=minimum_gap_seconds)
        ready = [row for row in rows if self.capability(str(row.get("chain") or "")).get("ready")]
        return ready[: max(1, int(limit))]

    def _rpc(self, url: str, body: Any) -> Any:
        return self.transport.request_json(
            "POST", url, json_data=body, timeout=float(settings.onchain_request_timeout_seconds)
        ).payload

    @staticmethod
    def _helius_url() -> str:
        secure = str(settings.helius_secure_rpc_url or "").strip()
        if secure:
            return secure
        return "https://mainnet.helius-rpc.com/?api-key=" + str(settings.helius_api_key or "").strip()

    @staticmethod
    def _new_signatures(rows: Any, previous: str) -> tuple[list[str], str]:
        if not isinstance(rows, list):
            return [], previous
        newest = str(rows[0].get("signature") or "") if rows and isinstance(rows[0], dict) else previous
        if not previous:
            # First observation establishes a baseline; it does not relabel old
            # transactions as post-signal activity.
            return [], newest
        out: list[str] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            sig = str(row.get("signature") or "")
            if not sig or sig == previous:
                break
            out.append(sig)
        return out, newest

    def _observe_solana(self, signal: dict[str, Any]) -> dict[str, Any] | None:
        if not settings.helius_ready:
            return None
        signal_id = _i(signal.get("id"))
        mint = str(signal.get("address") or "").strip()
        if not signal_id or not mint:
            return None

        source = "helius-solana"
        cursor = self.ledger.cursor(signal_id, source)
        state = dict(cursor.get("state") or {})
        deployer = str(signal.get("goplus_creator_address") or signal.get("goplus_owner_address") or "").strip()
        top_accounts = [str(x) for x in (state.get("top_token_accounts") or []) if x][: max(1, settings.onchain_solana_top_accounts)]
        prior_largest_accounts = [str(x) for x in (state.get("largest_token_accounts") or []) if x][:20]
        pending = [str(x) for x in (state.get("pending_signatures") or []) if x]
        tx_batch = pending[: max(1, settings.onchain_solana_tx_per_poll)]

        requests: list[dict[str, Any]] = [
            {"jsonrpc": "2.0", "id": "supply", "method": "getTokenSupply", "params": [mint, {"commitment": "confirmed"}]},
            {"jsonrpc": "2.0", "id": "largest", "method": "getTokenLargestAccounts", "params": [mint, {"commitment": "confirmed"}]},
        ]
        if prior_largest_accounts:
            requests.append({
                "jsonrpc": "2.0", "id": "owners", "method": "getMultipleAccounts",
                "params": [prior_largest_accounts, {"encoding": "jsonParsed", "commitment": "confirmed"}],
            })
        # Track the largest token accounts with standard RPC. Transfers normally
        # touch those token accounts, so this is more useful than polling the mint
        # address itself and remains available without a public webhook.
        for idx, account in enumerate(top_accounts):
            requests.append({
                "jsonrpc": "2.0", "id": f"acct:{idx}", "method": "getSignaturesForAddress",
                "params": [account, {"limit": 10, "commitment": "confirmed"}],
            })
        if deployer:
            requests.append({
                "jsonrpc": "2.0", "id": "deployer", "method": "getSignaturesForAddress",
                "params": [deployer, {"limit": 10, "commitment": "confirmed"}],
            })
        # Details for signatures discovered on the previous poll are fetched in
        # the same bounded batch. Helius permits getTransaction batching; the
        # total request is kept <= 10 items for conservative mobile operation.
        room = max(0, 10 - len(requests))
        tx_batch = tx_batch[:room]
        for idx, sig in enumerate(tx_batch):
            requests.append({
                "jsonrpc": "2.0", "id": f"tx:{idx}", "method": "getTransaction",
                "params": [sig, {"encoding": "jsonParsed", "commitment": "confirmed", "maxSupportedTransactionVersion": 0}],
            })

        try:
            payload = self._rpc(self._helius_url(), requests)
        except (NetworkHTTPError, TransientNetworkError, OSError, ValueError) as exc:
            self.ledger.set_cursor(signal_id, source, str(cursor.get("cursor_value") or ""), state=state, error=_safe_error(exc))
            return None
        by_id = _jsonrpc_map(payload)
        if not by_id:
            self.ledger.set_cursor(signal_id, source, str(cursor.get("cursor_value") or ""), state=state, error="invalid-json-rpc-batch")
            return None

        supply_value = (((by_id.get("supply") or {}).get("result") or {}).get("value") or {})
        supply = _f(supply_value.get("uiAmountString") or supply_value.get("uiAmount"))
        largest_rows = (((by_id.get("largest") or {}).get("result") or {}).get("value") or [])
        largest_rows = largest_rows if isinstance(largest_rows, list) else []
        top_amounts = [_f(row.get("uiAmountString") or row.get("uiAmount")) for row in largest_rows[:10] if isinstance(row, dict)]
        top10 = (sum(top_amounts) / supply * 100.0) if supply > 0 else None
        new_top_accounts = [str(row.get("address") or "") for row in largest_rows if isinstance(row, dict) and row.get("address")]
        state["top_token_accounts"] = new_top_accounts[: max(1, settings.onchain_solana_top_accounts)]
        state["largest_token_accounts"] = new_top_accounts[:20]

        # Resolve token-account owners in one standard RPC call and aggregate the
        # 20 largest token accounts into unique owners. This makes the Top-10
        # concentration materially closer to holder concentration without extra
        # HTTPS round-trips. If resolution is unavailable, keep the conservative
        # token-account approximation.
        owners_payload = (((by_id.get("owners") or {}).get("result") or {}).get("value") or [])
        if isinstance(owners_payload, list) and prior_largest_accounts:
            amount_by_account = {
                str(row.get("address") or ""): _f(row.get("uiAmountString") or row.get("uiAmount"))
                for row in largest_rows if isinstance(row, dict)
            }
            owner_totals: dict[str, float] = {}
            resolved = 0
            for account, info in zip(prior_largest_accounts, owners_payload):
                if not isinstance(info, dict):
                    continue
                data = info.get("data") or {}
                parsed = data.get("parsed") if isinstance(data, dict) else None
                detail = parsed.get("info") if isinstance(parsed, dict) else None
                owner = str((detail or {}).get("owner") or "") if isinstance(detail, dict) else ""
                if owner and account in amount_by_account:
                    owner_totals[owner] = owner_totals.get(owner, 0.0) + amount_by_account[account]
                    resolved += 1
            if resolved >= 5 and supply > 0:
                top10 = sum(sorted(owner_totals.values(), reverse=True)[:10]) / supply * 100.0

        discovered: list[str] = []
        last_map = dict(state.get("account_last_signatures") or {})
        for idx, account in enumerate(top_accounts):
            rows = (by_id.get(f"acct:{idx}") or {}).get("result") or []
            new_sigs, newest = self._new_signatures(rows, str(last_map.get(account) or ""))
            discovered.extend(new_sigs)
            if newest:
                last_map[account] = newest
        state["account_last_signatures"] = last_map

        if deployer:
            drows = (by_id.get("deployer") or {}).get("result") or []
            new_sigs, newest = self._new_signatures(drows, str(state.get("deployer_last_signature") or ""))
            discovered.extend(new_sigs)
            if newest:
                state["deployer_last_signature"] = newest

        price = self.ledger.latest_market_snapshot(
            signal_id, fallback_price=_f(signal.get("entry_price")), fallback_liquidity=_f(signal.get("liquidity"))
        )["price"]
        threshold = float(settings.onchain_whale_min_usd)
        wallets: set[str] = set()
        whale_count = 0
        whale_volume = 0.0
        deployer_risky = 0
        transfer_count = 0
        processed: set[str] = set()

        for idx, sig in enumerate(tx_batch):
            row = by_id.get(f"tx:{idx}") or {}
            if "result" not in row:
                continue
            processed.add(sig)
            tx = row.get("result")
            if not isinstance(tx, dict):
                continue
            deltas = _sol_token_deltas(tx, mint)
            if not deltas:
                continue
            transfer_count += 1
            wallets.update(owner for owner in deltas if not owner.startswith("accountIndex:"))
            positives = [(owner, delta) for owner, delta in deltas.items() if delta > 0]
            negatives = [(owner, -delta) for owner, delta in deltas.items() if delta < 0]
            moved = max(sum(v for _, v in positives), sum(v for _, v in negatives))
            amount_usd = moved * price if price > 0 else 0.0
            sender = max(negatives, key=lambda x: x[1])[0] if negatives else ""
            recipient = max(positives, key=lambda x: x[1])[0] if positives else ""
            block_ref = str(tx.get("slot") or "")
            block_time = _i(tx.get("blockTime"))
            occurred = datetime.fromtimestamp(block_time, timezone.utc) if block_time > 0 else None

            dep_delta = _f(deltas.get(deployer)) if deployer else 0.0
            if deployer and dep_delta < 0:
                sev = "HIGH" if abs(dep_delta) * price >= threshold and price > 0 else "MODERATE"
                self.ledger.record_event(
                    signal, event_type="deployer_outflow", txid=sig, severity=sev, wallet_address=deployer,
                    counterparty=recipient, block_ref=block_ref, amount_token=abs(dep_delta),
                    amount_usd=abs(dep_delta) * price if price > 0 else 0.0,
                    details={"source": "token-balance-delta", "owners_changed": len(deltas)}, occurred_at=occurred,
                )
                if sev == "HIGH":
                    deployer_risky += 1
            elif deployer and dep_delta > 0:
                self.ledger.record_event(
                    signal, event_type="deployer_inflow", txid=sig, severity="INFO", wallet_address=deployer,
                    counterparty=sender, block_ref=block_ref, amount_token=dep_delta,
                    amount_usd=dep_delta * price if price > 0 else 0.0,
                    details={"source": "token-balance-delta", "owners_changed": len(deltas)}, occurred_at=occurred,
                )

            if amount_usd >= threshold:
                whale_count += 1
                whale_volume += amount_usd
                self.ledger.record_event(
                    signal, event_type="whale_transfer", txid=sig, severity="MODERATE",
                    wallet_address=sender, counterparty=recipient, block_ref=block_ref,
                    amount_token=moved, amount_usd=amount_usd,
                    details={"source": "token-balance-delta", "owners_changed": len(deltas)}, occurred_at=occurred,
                )

        # Supply changes are independently observable and can flag mint/burn-like
        # expansion/contraction without guessing transaction intent.
        previous_supply = _f(state.get("supply"))
        mint_events = 0
        burn_events = 0
        if previous_supply > 0 and supply > 0 and abs(supply - previous_supply) > max(1e-12, previous_supply * 1e-8):
            pct = (supply / previous_supply - 1.0) * 100.0
            if pct > 0:
                mint_events = 1
                self.ledger.record_event(
                    signal, event_type="supply_increase", txid=f"supply:{supply:.12g}",
                    severity="HIGH" if pct >= 1.0 else "MODERATE", amount_token=supply - previous_supply,
                    amount_usd=(supply - previous_supply) * price if price > 0 else 0.0,
                    details={"previous_supply": previous_supply, "new_supply": supply, "change_pct": round(pct, 6)},
                )
            else:
                burn_events = 1
                self.ledger.record_event(
                    signal, event_type="supply_decrease", txid=f"supply:{supply:.12g}", severity="INFO",
                    amount_token=previous_supply - supply,
                    details={"previous_supply": previous_supply, "new_supply": supply, "change_pct": round(pct, 6)},
                )
        state["supply"] = supply

        pending_next = [sig for sig in pending if sig not in processed]
        for sig in discovered:
            if sig not in pending_next and sig not in processed:
                pending_next.append(sig)
        state["pending_signatures"] = pending_next[:30]

        metrics = {
            "source": "Helius RPC polling",
            "top10_holders_pct": round(top10, 2) if top10 is not None else None,
            "activity_count": len(discovered),
            "transfer_count": transfer_count,
            "unique_wallets": len(wallets),
            "whale_transfer_count": whale_count,
            "whale_volume_usd": round(whale_volume, 2),
            "mint_events": mint_events,
            "burn_events": burn_events,
            "deployer_risky_events": deployer_risky,
        }
        self.ledger.record_snapshot(signal, metrics)
        snapshot = self.ledger.latest_snapshot(signal_id)
        self.ledger.set_cursor(signal_id, source, state.get("deployer_last_signature", ""), state=state)
        return snapshot

    @staticmethod
    def _cursor_is_stale(cursor: dict[str, Any]) -> bool:
        raw = str(cursor.get("last_checked_at") or "")
        if not raw:
            return False
        try:
            dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return (datetime.now(timezone.utc) - dt.astimezone(timezone.utc)).total_seconds() > settings.onchain_evm_rebase_after_seconds
        except Exception:
            return False

    def _observe_evm(self, signal: dict[str, Any]) -> dict[str, Any] | None:
        chain = str(signal.get("chain") or "").lower()
        url = str(settings.evm_rpc_url(chain) or "").strip()
        if not url:
            return None
        signal_id = _i(signal.get("id"))
        token = str(signal.get("address") or "").strip()
        if not signal_id or not token.startswith("0x"):
            return None
        source = f"evm-{chain}"
        cursor = self.ledger.cursor(signal_id, source)
        state = dict(cursor.get("state") or {})
        last_block = _i(state.get("last_block"))
        if last_block > 0 and self._cursor_is_stale(cursor):
            # After a long mobile pause, re-baseline instead of requesting an
            # unbounded historical eth_getLogs range from a public RPC.
            last_block = 0
            state.pop("last_block", None)
        deployer = str(signal.get("goplus_creator_address") or signal.get("goplus_owner_address") or "").lower()

        if last_block <= 0:
            body = [
                {"jsonrpc": "2.0", "id": "block", "method": "eth_blockNumber", "params": []},
                {"jsonrpc": "2.0", "id": "decimals", "method": "eth_call", "params": [{"to": token, "data": "0x313ce567"}, "latest"]},
            ]
        else:
            body = [
                {"jsonrpc": "2.0", "id": "block", "method": "eth_blockNumber", "params": []},
                {"jsonrpc": "2.0", "id": "logs", "method": "eth_getLogs", "params": [{"fromBlock": hex(last_block + 1), "toBlock": "latest", "address": token, "topics": [TRANSFER_TOPIC]}]},
            ]
            if "decimals" not in state:
                body.append({"jsonrpc": "2.0", "id": "decimals", "method": "eth_call", "params": [{"to": token, "data": "0x313ce567"}, "latest"]})
        try:
            payload = self._rpc(url, body)
        except (NetworkHTTPError, TransientNetworkError, OSError, ValueError) as exc:
            self.ledger.set_cursor(signal_id, source, str(last_block or ""), state=state, error=_safe_error(exc))
            return None
        by_id = _jsonrpc_map(payload)
        if not by_id:
            self.ledger.set_cursor(signal_id, source, str(last_block or ""), state=state, error="invalid-json-rpc-batch")
            return None
        latest_block = _i((by_id.get("block") or {}).get("result"), last_block)
        dec_raw = (by_id.get("decimals") or {}).get("result")
        if dec_raw not in (None, "0x"):
            state["decimals"] = max(0, min(36, _i(dec_raw, 18)))
        decimals = _i(state.get("decimals"), 18)
        logs = (by_id.get("logs") or {}).get("result") or []
        logs = logs if isinstance(logs, list) else []
        wallets: set[str] = set()
        whale_count = 0
        whale_volume = 0.0
        mint_events = 0
        burn_events = 0
        deployer_risky = 0
        market = self.ledger.latest_market_snapshot(
            signal_id, fallback_price=_f(signal.get("entry_price")), fallback_liquidity=_f(signal.get("liquidity"))
        )
        price = market["price"]
        threshold = float(settings.onchain_whale_min_usd)

        for row in logs:
            if not isinstance(row, dict):
                continue
            topics = row.get("topics") or []
            if not isinstance(topics, list) or len(topics) < 3:
                continue
            sender = _evm_addr(topics[1])
            recipient = _evm_addr(topics[2])
            wallets.update(v for v in (sender, recipient) if v and v != ZERO_EVM)
            raw_amount = _i(row.get("data"))
            amount = raw_amount / (10 ** decimals) if decimals >= 0 else 0.0
            amount_usd = amount * price if price > 0 else 0.0
            txid = str(row.get("transactionHash") or "")
            ordinal = str(row.get("logIndex") or "")
            block_ref = str(_i(row.get("blockNumber")))
            event_type = "transfer"
            severity = "INFO"
            wallet_address = ""
            counterparty = ""
            if sender == ZERO_EVM:
                event_type = "mint_event"; mint_events += 1; severity = "MODERATE"
            elif recipient == ZERO_EVM:
                event_type = "burn_event"; burn_events += 1
            if amount_usd >= threshold:
                event_type = "whale_transfer" if event_type == "transfer" else event_type
                whale_count += 1
                whale_volume += amount_usd
                severity = "MODERATE"
                wallet_address = sender if sender != ZERO_EVM else recipient
                counterparty = recipient if sender != ZERO_EVM else sender
            if deployer and sender == deployer:
                event_type = "deployer_outflow"
                wallet_address = deployer
                counterparty = recipient
                severity = "HIGH" if amount_usd >= threshold else "MODERATE"
                deployer_risky += int(severity == "HIGH")
            elif deployer and recipient == deployer:
                event_type = "deployer_inflow"
                wallet_address = deployer
                counterparty = sender
            self.ledger.record_event(
                signal, event_type=event_type, txid=txid, ordinal=ordinal, severity=severity,
                wallet_address=wallet_address, counterparty=counterparty, block_ref=block_ref,
                amount_token=amount, amount_usd=amount_usd,
                details={"from": sender, "to": recipient, "decimals": decimals},
            )

        metrics = {
            "source": f"{chain} JSON-RPC polling",
            "transfer_count": len(logs),
            "unique_wallets": len(wallets),
            "whale_transfer_count": whale_count,
            "whale_volume_usd": round(whale_volume, 2),
            "mint_events": mint_events,
            "burn_events": burn_events,
            "deployer_risky_events": deployer_risky,
        }
        self.ledger.record_snapshot(signal, metrics)
        snapshot = self.ledger.latest_snapshot(signal_id)
        if latest_block > 0:
            state["last_block"] = latest_block
        self.ledger.set_cursor(signal_id, source, str(latest_block or last_block or ""), state=state)
        return snapshot

    def observe_one(self, signal: dict[str, Any]) -> dict[str, Any] | None:
        chain = str(signal.get("chain") or "").lower()
        if chain == "solana":
            return self._observe_solana(signal)
        if chain in EVM_CHAINS:
            return self._observe_evm(signal)
        return None
