from __future__ import annotations

import re
from datetime import date, timedelta

from csm.config import settings
from csm.branding import load_branding
from csm.plans import PLANS, normalize_plan

from .errors import NetworkHTTPError, TransientNetworkError
from .transport import StdlibHttpTransport

PAID_STATUSES = {"RECEIVED", "CONFIRMED", "RECEIVED_IN_CASH"}
TERMINAL_STATUSES = {
    "REFUNDED",
    "REFUND_REQUESTED",
    "CHARGEBACK_REQUESTED",
    "CHARGEBACK_DISPUTE",
    "AWAITING_CHARGEBACK_REVERSAL",
    "DUNNING_REQUESTED",
    "DUNNING_RECEIVED",
    "DELETED",
}


def only_digits(value: str) -> str:
    return re.sub(r"\D", "", value or "")


def valid_cpf(value: str) -> bool:
    cpf = only_digits(value)
    if len(cpf) != 11 or cpf == cpf[0] * 11:
        return False
    for size in (9, 10):
        total = sum(int(cpf[i]) * (size + 1 - i) for i in range(size))
        digit = (total * 10) % 11
        digit = 0 if digit == 10 else digit
        if digit != int(cpf[size]):
            return False
    return True


def valid_cnpj(value: str) -> bool:
    cnpj = only_digits(value)
    if len(cnpj) != 14 or cnpj == cnpj[0] * 14:
        return False

    def calc(base, weights):
        rem = sum(int(n) * w for n, w in zip(base, weights)) % 11
        return 0 if rem < 2 else 11 - rem

    return calc(cnpj[:12], [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) == int(cnpj[12]) and calc(
        cnpj[:13], [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    ) == int(cnpj[13])


def valid_document(value: str) -> bool:
    digits = only_digits(value)
    return valid_cpf(digits) if len(digits) == 11 else valid_cnpj(digits) if len(digits) == 14 else False


class AsaasClient:
    def __init__(self, transport: StdlibHttpTransport | None = None):
        errors = settings.asaas_validation_errors()
        if errors:
            raise RuntimeError("Configuração Asaas inválida: " + "; ".join(errors))
        self.transport = transport or StdlibHttpTransport(timeout=6.0, label="asaas")
        self.transport.headers.update({"access_token": settings.asaas_api_key, "Content-Type": "application/json"})
        self.base = settings.asaas_base_url

    def call(self, method, path, *, params=None, json_data=None):
        try:
            result = self.transport.request_json(
                method,
                f"{self.base}{path}",
                params=params,
                json_data=json_data,
                timeout=6.0,
            ).payload
        except NetworkHTTPError as exc:
            if isinstance(exc.payload, dict) and exc.payload.get("errors"):
                descriptions = [
                    str(item.get("description") or item.get("code") or "Erro Asaas")
                    for item in exc.payload["errors"]
                    if isinstance(item, dict)
                ]
                raise RuntimeError("; ".join(descriptions)) from exc
            raise RuntimeError(f"Asaas HTTP {exc.status}") from exc
        except TransientNetworkError as exc:
            raise RuntimeError("Asaas temporariamente indisponível.") from exc
        return result

    def account_status(self):
        payload = self.call("GET", "/myAccount/status/")
        return payload if isinstance(payload, dict) else {}

    def approve_sandbox_account(self):
        if settings.asaas_environment != "sandbox":
            raise RuntimeError("Aprovação automática só é permitida no Sandbox.")
        payload = self.call("POST", "/sandbox/myAccount/approve")
        return payload if isinstance(payload, dict) else {}

    def ensure_sandbox_account_ready(self):
        """Garante que a conta de teste esteja aprovada antes de emitir PIX.

        O endpoint de aprovação existe exclusivamente no Sandbox. Em produção
        nunca tentamos alterar o status cadastral automaticamente.
        """
        if settings.asaas_environment != "sandbox":
            return {}
        status = self.account_status()
        if str(status.get("general") or "").upper() == "APPROVED":
            return status
        self.approve_sandbox_account()
        status = self.account_status()
        if str(status.get("general") or "").upper() != "APPROVED":
            raise RuntimeError(
                "Conta Sandbox ainda não está aprovada pela API do Asaas "
                f"(general={status.get('general') or 'UNKNOWN'})."
            )
        return status

    def customers_by_reference(self, ref):
        payload = self.call("GET", "/customers", params={"externalReference": ref, "limit": 100})
        return list(payload.get("data", [])) if isinstance(payload, dict) else []

    def customer(self, customer_id):
        payload = self.call("GET", f"/customers/{customer_id}")
        return payload if isinstance(payload, dict) else {}

    def create_customer(self, *, name, cpf_cnpj, reference):
        return self.call(
            "POST",
            "/customers",
            json_data={
                "name": name.strip()[:100],
                "cpfCnpj": cpf_cnpj,
                "externalReference": reference,
                "notificationDisabled": True,
            },
        )

    def create_payment(self, *, customer_id, user_id, plan, billing_type):
        meta = PLANS[normalize_plan(plan)]
        billing_type = str(billing_type or "").upper()
        if billing_type == "PIX" and settings.asaas_environment == "sandbox":
            self.ensure_sandbox_account_ready()
        payload = {
            "customer": customer_id,
            "billingType": billing_type,
            "value": round(meta["value"], 2),
            "dueDate": (date.today() + timedelta(days=settings.asaas_due_days)).isoformat(),
            "description": f"{load_branding().get('product_name', 'Crypto Signals Multichain')} - {meta['label']} por {meta['days']} dias",
            "externalReference": f"csm:{user_id}:{plan}",
        }
        try:
            return self.call("POST", "/payments", json_data=payload)
        except RuntimeError as exc:
            message = str(exc).lower()
            approval_error = "pix" in message and ("aprov" in message or "approve" in message)
            if billing_type == "PIX" and settings.asaas_environment == "sandbox" and approval_error:
                self.approve_sandbox_account()
                return self.call("POST", "/payments", json_data=payload)
            raise

    def payment_status(self, payment_id):
        payload = self.call("GET", f"/payments/{payment_id}/status")
        return str(payload.get("status") or "UNKNOWN").upper() if isinstance(payload, dict) else "UNKNOWN"

    def pix_qr_code(self, payment_id):
        payload = self.call("GET", f"/payments/{payment_id}/pixQrCode")
        return payload if isinstance(payload, dict) else {}


class PaymentService:
    def __init__(self, storage, client: AsaasClient | None = None):
        self.storage = storage
        self.client = client or AsaasClient()

    def _customer(self, user_id, name, document):
        user = self.storage.get_user(user_id)
        saved = str(user.get("asaas_customer_id") or "")
        if saved:
            try:
                remote = self.client.customer(saved)
                if str(remote.get("id") or "") == saved:
                    return saved
            except Exception:
                # Chave/conta Sandbox pode ter mudado entre instalações. Um ID
                # de cliente da conta anterior não deve impedir nova cobrança.
                pass
            try:
                self.storage.set_asaas_customer(user_id, "")
            except Exception:
                pass
        ref = f"csm-user:{user_id}"
        rows = self.client.customers_by_reference(ref)
        row = rows[0] if rows else self.client.create_customer(
            name=name or f"Cliente Telegram {user_id}",
            cpf_cnpj=only_digits(document),
            reference=ref,
        )
        customer_id = str(row.get("id") or "")
        if not customer_id:
            raise RuntimeError("Asaas não retornou ID do cliente.")
        self.storage.set_asaas_customer(user_id, customer_id)
        return customer_id

    def create_payment(self, *, user_id, plan, name, cpf_cnpj, billing_type):
        plan = normalize_plan(plan)
        billing_type = str(billing_type).upper()
        if plan == "free" or billing_type not in settings.asaas_payment_methods or not valid_document(cpf_cnpj):
            raise ValueError("Dados de pagamento inválidos.")
        existing = self.storage.latest_open_payment(user_id, plan, billing_type)
        if existing and existing.get("invoice_url"):
            return existing
        customer_id = self._customer(user_id, name, cpf_cnpj)
        remote = self.client.create_payment(
            customer_id=customer_id,
            user_id=user_id,
            plan=plan,
            billing_type=billing_type,
        )
        payment_id = str(remote.get("id") or "")
        invoice_url = str(remote.get("invoiceUrl") or remote.get("bankSlipUrl") or "")
        status = str(remote.get("status") or "PENDING").upper()
        if not payment_id or not invoice_url:
            raise RuntimeError("Asaas não retornou cobrança válida.")
        self.storage.save_payment(
            payment_id=payment_id,
            user_id=user_id,
            plan=plan,
            invoice_url=invoice_url,
            external_reference=f"csm:{user_id}:{plan}:{billing_type.lower()}",
            status=status,
            billing_type=billing_type,
        )
        row = self.storage.get_payment(payment_id) or {}
        if billing_type == "PIX":
            try:
                row["pix_payload"] = str(self.client.pix_qr_code(payment_id).get("payload") or "")
            except Exception:
                pass
        return row

    def verify_payment(self, payment_id):
        row = self.storage.get_payment(payment_id)
        if not row:
            raise RuntimeError("Cobrança não encontrada.")
        local_status = str(row.get("status") or "").upper()
        if row.get("activated_at") and local_status in PAID_STATUSES:
            return {
                "state": "active", "status": local_status, "plan": row["plan"],
                "payment_id": payment_id, "user_id": int(row["user_id"]),
            }
        # Recover a payment that was persisted as paid immediately before an
        # app/phone interruption, without needing another Asaas request.
        if local_status in PAID_STATUSES and not row.get("activated_at"):
            self.storage.activate_payment(payment_id, days=PLANS[normalize_plan(row["plan"])]["days"])
            return {
                "state": "activated", "status": local_status, "plan": row["plan"],
                "payment_id": payment_id, "user_id": int(row["user_id"]), "recovered": True,
            }
        status = self.client.payment_status(payment_id)
        self.storage.update_payment_status(payment_id, status)
        if status in PAID_STATUSES:
            self.storage.activate_payment(payment_id, days=PLANS[normalize_plan(row["plan"])]["days"])
            return {
                "state": "activated", "status": status, "plan": row["plan"],
                "payment_id": payment_id, "user_id": int(row["user_id"]),
            }
        return {
            "state": "failed" if status in TERMINAL_STATUSES else "pending",
            "status": status,
            "plan": row["plan"],
            "payment_id": payment_id,
            "user_id": int(row["user_id"]),
        }

    def verify_user(self, user_id):
        results = []
        for row in self.storage.open_payments(user_id=user_id, limit=20):
            try:
                results.append(self.verify_payment(row["payment_id"]))
            except Exception as exc:
                results.append({
                    "state": "error", "status": str(row.get("status") or "UNKNOWN"),
                    "plan": row.get("plan", "free"), "payment_id": row.get("payment_id", ""),
                    "user_id": int(user_id), "error": str(exc),
                })
        if results and all(item.get("state") == "error" for item in results):
            raise RuntimeError(str(results[0].get("error") or "Falha ao verificar cobrança."))
        return results
