from __future__ import annotations

from typing import Any

from csm.config import settings
from csm.performance import PerformanceLedger

from .market import MarketService
from .providers import ProviderGateway
from .transport import StdlibHttpTransport


class PerformanceMonitor:
    """One-request-at-a-time signal performance observer.

    The live path intentionally uses one DexScreener request and never falls
    through multiple providers inside the same scheduler step.  That preserves
    the a-Shell sequential network contract while building an auditable ledger.
    """

    def __init__(self, storage, transport: StdlibHttpTransport, providers: ProviderGateway):
        self.storage = storage
        self.ledger = PerformanceLedger(storage)
        self.transport = transport.clone(label="performance", timeout=float(settings.performance_request_timeout_seconds))
        self.providers = providers

    @staticmethod
    def _same_address(left: Any, right: Any) -> bool:
        a, b = str(left or "").strip(), str(right or "").strip()
        if a.startswith("0x") or b.startswith("0x"):
            return a.lower() == b.lower()
        return a == b

    def observe_cached_results(self, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        by_key = {
            (str(row.get("chain") or "").lower(), str(row.get("address") or "").lower()): row
            for row in rows if row.get("chain") and row.get("address") and float(row.get("price") or 0) > 0
        }
        updated = 0
        for signal in self.ledger.due_signals(limit=100, minimum_gap_seconds=60):
            market = by_key.get((str(signal.get("chain") or "").lower(), str(signal.get("address") or "").lower()))
            if market and self.ledger.record_observation(int(signal["id"]), market):
                updated += 1
        return updated

    def observe_one(self, signal: dict[str, Any]) -> bool:
        chain = str(signal.get("chain") or "").strip().lower()
        address = str(signal.get("address") or "").strip()
        if not chain or not address:
            return False
        payload = self.providers.fetch(
            "DexScreener performance",
            lambda: self.transport.get_json(
                f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}",
                timeout=float(settings.performance_request_timeout_seconds),
            ),
            cache_key=f"performance:dex:{chain}:{address}",
            cache_ttl=max(30, int(settings.performance_market_cache_ttl)),
            stale_ttl=max(300, int(settings.performance_market_stale_ttl)),
        )
        if not isinstance(payload, list) or not payload:
            return False
        matching = [
            pair for pair in payload
            if self._same_address((pair.get("baseToken") or {}).get("address"), address)
        ]
        if not matching:
            # Avoid recording a quote-token price as if it belonged to the
            # tracked token.  Missing data is better than false performance.
            return False
        best = max(matching, key=lambda pair: float((pair.get("liquidity") or {}).get("usd") or 0))
        market = MarketService.normalize_dex(best)
        market["chain"] = chain
        market["address"] = address
        return self.ledger.record_observation(int(signal["id"]), market)

    def observe_shadow_one(self, signal: dict[str, Any]) -> bool:
        """Capture one evidence-only quote without advancing lifecycle state."""
        chain = str(signal.get("chain") or "").strip().lower()
        address = str(signal.get("address") or "").strip()
        if not chain or not address:
            return False
        payload = self.providers.fetch(
            "DexScreener shadow performance",
            lambda: self.transport.get_json(
                f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}",
                timeout=float(settings.performance_request_timeout_seconds),
            ),
            cache_key=f"performance:dex:{chain}:{address}",
            cache_ttl=max(30, int(settings.performance_market_cache_ttl)),
            stale_ttl=max(300, int(settings.performance_market_stale_ttl)),
        )
        if not isinstance(payload, list) or not payload:
            return False
        matching = [
            pair for pair in payload
            if self._same_address((pair.get("baseToken") or {}).get("address"), address)
        ]
        if not matching:
            return False
        best = max(matching, key=lambda pair: float((pair.get("liquidity") or {}).get("usd") or 0))
        market = MarketService.normalize_dex(best)
        market["chain"] = chain
        market["address"] = address
        return self.ledger.record_shadow_observation(int(signal["id"]), market)
