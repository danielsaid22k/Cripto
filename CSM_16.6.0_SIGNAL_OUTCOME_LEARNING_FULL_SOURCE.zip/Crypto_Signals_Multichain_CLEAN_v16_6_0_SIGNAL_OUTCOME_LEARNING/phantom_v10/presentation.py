from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from typing import Any

from csm.chains import CHAINS
from csm.branding import load_branding
from csm.config import settings
from csm.experience import BRAND_DIVIDER, interval_label, opportunity_profile, project_stage, signal_reasons
from csm.formatting import compact_address, score_breakdown, score_market
from csm.plans import base_plan


UNKNOWN_LABELS = {"", "?", "-", "n/a", "na", "none", "null", "token", "unknown", "desconhecido"}


def _float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _known(value: Any) -> bool:
    return str(value or "").strip().lower() not in UNKNOWN_LABELS


def _pair_part(value: str) -> str:
    text = str(value or "").strip()
    for separator in (" / ", "/", " - "):
        if separator in text:
            text = text.split(separator, 1)[0].strip()
            break
    return text


def token_identity(item: dict[str, Any]) -> tuple[str, str]:
    """Return a readable symbol/name even for legacy rows saved as ``?``."""
    raw_symbol = str(item.get("symbol") or item.get("token_symbol") or "").strip()
    raw_name = str(item.get("name") or item.get("token_name") or "").strip()
    address = str(item.get("address") or "").strip()

    symbol = raw_symbol if _known(raw_symbol) else _pair_part(raw_name)
    if not _known(symbol):
        short = compact_address(address, 4) if address else "SEM ID"
        symbol = f"TOKEN {short}"

    name = raw_name if _known(raw_name) else symbol
    if "/" in name or " / " in name:
        name = symbol
    return symbol[:32], name[:80]


def format_price(value: Any) -> str:
    number = _float(value)
    if number <= 0:
        return "n/d"
    if number >= 1_000:
        return f"US$ {number:,.2f}"
    if number >= 1:
        return f"US$ {number:,.6f}".rstrip("0").rstrip(".")
    if number >= 0.01:
        return f"US$ {number:.8f}".rstrip("0").rstrip(".")
    rendered = f"{number:.12f}".rstrip("0").rstrip(".")
    return f"US$ {rendered}" if rendered and rendered != "0" else f"US$ {number:.6g}"


def compact_usd(value: Any, *, zero_is_missing: bool = True) -> str:
    number = _float(value)
    if number == 0 and zero_is_missing:
        return "n/d"
    absolute = abs(number)
    if absolute >= 1_000_000_000:
        return f"US$ {number / 1_000_000_000:.2f} bi"
    if absolute >= 1_000_000:
        return f"US$ {number / 1_000_000:.2f} mi"
    if absolute >= 1_000:
        return f"US$ {number / 1_000:.1f} mil"
    return f"US$ {number:,.2f}"


def format_age(value: Any) -> str:
    if value is None:
        return "n/d"
    days = max(0.0, _float(value))
    if days < 1 / 24:
        return f"{max(1, int(days * 1440))} min"
    if days < 1:
        return f"{days * 24:.1f} h"
    return f"{days:.1f} dias"


def _score_label(score: int) -> tuple[str, str]:
    if score >= 88:
        return "🟢", "MUITO FORTE"
    if score >= 78:
        return "✅", "FORTE"
    if score >= 60:
        return "🟡", "MODERADO"
    return "🔴", "FRACO"


def buy_pressure(item: dict[str, Any], horizon: str = "24h") -> float | None:
    buys = _int(item.get(f"buys{horizon}"))
    sells = _int(item.get(f"sells{horizon}"))
    total = buys + sells
    return (buys / total * 100) if total else None


def risk_profile(item: dict[str, Any], score: int | None = None) -> tuple[str, str, list[str]]:
    score = score_market(item) if score is None else int(score)
    liquidity = _float(item.get("liquidity"))
    change1h = abs(_float(item.get("change1h")))
    change24h = abs(_float(item.get("change24h")))
    age = item.get("age_days")
    pressure = buy_pressure(item)
    points = 0
    flags: list[str] = []

    if liquidity < 10_000:
        points += 3
        flags.append("liquidez muito baixa; slippage pode ser elevado")
    elif liquidity < 25_000:
        points += 2
        flags.append("liquidez abaixo de US$ 25 mil")
    if age is None:
        points += 1
        flags.append("idade do pool não confirmada")
    elif _float(age) < 1:
        points += 2
        flags.append("pool com menos de 24 horas")
    if change1h >= 15 or change24h >= 80:
        points += 2
        flags.append("volatilidade elevada no período")
    if pressure is not None and pressure < 45:
        points += 1
        flags.append("pressão vendedora superior à compradora")
    if not _known(item.get("symbol")):
        points += 1
        flags.append("metadado do símbolo incompleto")
    if score < 60:
        points += 2
    elif score < 78:
        points += 1

    if points >= 5:
        return "🔴", "MUITO ALTO", flags
    if points >= 3:
        return "🟠", "ALTO", flags
    if points >= 1:
        return "🟡", "ELEVADO", flags
    return "🟢", "CONTROLADO PELOS FILTROS", flags


def trade_plan(item: dict[str, Any]) -> dict[str, float] | None:
    price = _float(item.get("price"))
    if price <= 0:
        return None
    stop_pct = max(0.1, _float(settings.signal_stop_pct, 12.0))
    target1_pct = max(0.1, _float(settings.signal_target1_pct, 25.0))
    target2_pct = max(target1_pct, _float(settings.signal_target2_pct, 50.0))
    return {
        "entry": price,
        "entry_low": price * 0.98,
        "entry_high": price * 1.01,
        "stop": price * (1 - stop_pct / 100),
        "target1": price * (1 + target1_pct / 100),
        "target2": price * (1 + target2_pct / 100),
        "stop_pct": stop_pct,
        "target1_pct": target1_pct,
        "target2_pct": target2_pct,
        "rr1": target1_pct / stop_pct,
        "rr2": target2_pct / stop_pct,
    }


def data_quality(item: dict[str, Any]) -> tuple[int, str]:
    checks = (
        _known(item.get("symbol")),
        _float(item.get("price")) > 0,
        _float(item.get("liquidity")) > 0,
        _float(item.get("volume24h")) > 0,
        _float(item.get("marketcap")) > 0,
        _float(item.get("fdv")) > 0,
        (_int(item.get("buys24h")) + _int(item.get("sells24h"))) > 0,
        item.get("age_days") is not None,
        bool(item.get("dex")),
        bool(item.get("pair")),
    )
    percentage = round(sum(bool(value) for value in checks) / len(checks) * 100)
    label = "ALTA" if percentage >= 80 else "MÉDIA" if percentage >= 60 else "LIMITADA"
    return percentage, label


def _source_line(item: dict[str, Any]) -> str:
    source = escape(str(item.get("source") or "fonte pública"))
    cache = " • cache" if item.get("cached") else ""
    stale = " • dado anterior" if item.get("stale_cache") else ""
    timestamp = datetime.now().astimezone().strftime("%d/%m %H:%M")
    return f"🔎 Fonte: <b>{source}</b>{cache}{stale} • {timestamp}"


def _identity_lines(item: dict[str, Any]) -> list[str]:
    symbol, name = token_identity(item)
    chain_key = str(item.get("chain") or "")
    chain = CHAINS.get(chain_key, {"emoji": "🌐", "label": chain_key or "Rede n/d"})
    address = escape(str(item.get("address") or "n/d"))
    token_line = f"🪙 <b>{escape(symbol)}</b>"
    if name.lower() != symbol.lower():
        token_line += f" — {escape(name)}"
    return [
        token_line,
        f"{chain['emoji']} <b>{escape(str(chain['label']))}</b>",
        f"📄 <code>{address}</code>",
    ]


def _trade_plan_lines(item: dict[str, Any], *, premium: bool, show_rr: bool = True) -> list[str]:
    plan = trade_plan(item)
    if not plan:
        return ["🎯 <b>PLANO TÉCNICO</b>", "• Indisponível: preço de referência não informado pela fonte."]
    lines = [
        "🎯 <b>PLANO TÉCNICO EDUCACIONAL</b>",
        f"💲 Entrada de referência: <code>{format_price(plan['entry'])}</code>",
    ]
    if premium:
        lines.append(
            f"↔️ Faixa observada: <code>{format_price(plan['entry_low'])}</code> a <code>{format_price(plan['entry_high'])}</code>"
        )
    lines += [
        f"🛑 Stop loss: <code>{format_price(plan['stop'])}</code> (-{plan['stop_pct']:.1f}%)",
        f"🎯 Take profit 1: <code>{format_price(plan['target1'])}</code> (+{plan['target1_pct']:.1f}%)",
        f"🏆 Take profit 2: <code>{format_price(plan['target2'])}</code> (+{plan['target2_pct']:.1f}%)",
    ]
    if show_rr:
        lines.append(f"⚖️ Risco/retorno: <b>1:{plan['rr1']:.2f}</b> no TP1 • <b>1:{plan['rr2']:.2f}</b> no TP2")
    if premium:
        lines.append("🧩 Invalidação: perda do stop de referência; execução real pode sofrer slippage.")
    return lines


def _goplus_lines(item: dict[str, Any], group: str) -> list[str]:
    if not settings.goplus_enabled:
        return []
    status = str(item.get("goplus_status") or "").strip().lower()
    if status == "unsupported":
        return ["🛡️ GoPlus: <b>rede sem cobertura deste gate</b>"]
    if status == "unavailable" or not item.get("goplus_checked"):
        return ["⚠️ GoPlus: <b>não verificado nesta rodada</b> — scanner manteve fallback seguro"]

    score = item.get("goplus_score")
    level = str(item.get("goplus_risk_level") or "N/D")
    icon = "✅" if isinstance(score, (int, float)) and float(score) >= 85 else "🟡" if isinstance(score, (int, float)) and float(score) >= 70 else "⚠️"
    rendered = int(score) if isinstance(score, (int, float)) else "n/d"
    lines = [f"{icon} GoPlus Security: <b>{rendered}/100 • {escape(level)}</b>"]
    if group in {"plus", "premium"}:
        buy_tax = item.get("goplus_buy_tax_pct")
        sell_tax = item.get("goplus_sell_tax_pct")
        transfer_tax = item.get("goplus_transfer_tax_pct")
        scheduled_fee = item.get("goplus_scheduled_transfer_fee_pct")
        taxes = []
        if isinstance(buy_tax, (int, float)):
            taxes.append(f"compra {float(buy_tax):.1f}%")
        if isinstance(sell_tax, (int, float)):
            taxes.append(f"venda {float(sell_tax):.1f}%")
        if isinstance(transfer_tax, (int, float)) and transfer_tax != sell_tax:
            taxes.append(f"transferência {float(transfer_tax):.1f}%")
        if group == "premium" and isinstance(scheduled_fee, (int, float)):
            taxes.append(f"agendada {float(scheduled_fee):.1f}%")
        if taxes:
            lines.append("💸 Taxas GoPlus: <b>" + " • ".join(taxes) + "</b>")
    if group == "premium":
        top10 = item.get("goplus_top10_holders_pct")
        locked = item.get("goplus_lp_locked_pct")
        if isinstance(top10, (int, float)):
            lines.append(f"👥 Concentração top10: <b>{float(top10):.1f}%</b>")
        if isinstance(locked, (int, float)):
            lines.append(f"🔒 LP top10 identificada como bloqueada: <b>{float(locked):.1f}%</b>")
        risks = [str(value).strip() for value in (item.get("goplus_risks") or []) if str(value).strip()]
        if risks:
            lines.append("🧬 <b>Riscos contratuais observados</b>")
            lines.extend(f"• {escape(value)}" for value in risks[:5])
        else:
            lines.append("🧬 Nenhum risco contratual relevante retornado pela GoPlus nos campos avaliados.")
    return lines


def _reputation_lines(item: dict[str, Any], group: str) -> list[str]:
    score = item.get("deployer_reputation_score")
    confidence = item.get("deployer_reputation_confidence")
    if not isinstance(score, (int, float)) or not isinstance(confidence, (int, float)):
        return []
    rating = str(item.get("deployer_reputation_rating") or "UNPROVEN")
    evidence = int(item.get("deployer_reputation_evidence") or 0)
    signals = int(item.get("deployer_reputation_signals") or 0)
    icon = "🟢" if float(score) >= 80 and float(confidence) >= 25 else "🟡" if float(score) >= 40 else "🔴"
    lines = [f"{icon} Deployer Reputation: <b>{int(score)}/100</b> • {escape(rating)} • confiança <b>{int(confidence)}/100</b>"]
    if group == "premium":
        lines.append(f"🧾 Evidências locais: <b>{evidence}</b> • sinais vinculados: <b>{signals}</b>")
        penalty = int(item.get("deployer_reputation_penalty") or 0)
        if penalty > 0:
            lines.append(f"⚠️ Histórico de risco reduziu apenas o CSM Confidence em <b>{penalty} ponto(s)</b>.")
        factors = list(item.get("deployer_reputation_factors") or [])
        for factor in factors[:3]:
            try:
                lines.append(f"• {escape(str(factor.get('type') or 'evidence'))}: {float(factor.get('weight') or 0):+.0f}")
            except Exception:
                pass
        lines.append("🔒 Reputação é evidência histórica; não substitui GoPlus nem filtros atuais.")
    return lines


def market_report(item: dict[str, Any], plan: str | None) -> tuple[str, int]:
    group = base_plan(plan)
    score = int(item.get("final_score") or item.get("opportunity_score") or item.get("score") or score_market(item))
    badge, signal = _score_label(score)
    risk_icon, risk, flags = risk_profile(item, score)
    profile = opportunity_profile({**item, "score": score})
    stage_icon, stage = project_stage(item)
    reasons = signal_reasons(item, 5 if group == "premium" else 3)
    identity = _identity_lines(item)
    price = format_price(item.get("price"))
    liquidity = compact_usd(item.get("liquidity"))
    volume24h = compact_usd(item.get("volume24h"))
    marketcap = compact_usd(item.get("marketcap"))
    fdv = compact_usd(item.get("fdv"))
    change5m = _float(item.get("change5m"))
    change1h = _float(item.get("change1h"))
    change6h = _float(item.get("change6h"))
    change24h = _float(item.get("change24h"))
    buys5m = _int(item.get("buys5m"))
    sells5m = _int(item.get("sells5m"))
    buys1h = _int(item.get("buys1h"))
    sells1h = _int(item.get("sells1h"))
    buys24h = _int(item.get("buys24h"))
    sells24h = _int(item.get("sells24h"))
    pressure1h = buy_pressure(item, "1h")
    pressure24h = buy_pressure(item, "24h")
    header = "🆓 <b>SINAL ESSENCIAL</b>" if group == "free" else "💠 <b>SINAL PLUS</b>" if group == "plus" else "👑 <b>RAIO-X PREMIUM</b>"
    brand = load_branding()

    lines = [
        BRAND_DIVIDER,
        f"{escape(str(brand.get('logo_emoji') or '🌐'))} <b>{escape(str(brand.get('telegram_title') or brand.get('product_name') or 'Crypto Signals Multichain'))}</b>",
        header,
        BRAND_DIVIDER,
        f"🔄 <b>Verificação de novas oportunidades: a cada {escape(interval_label(plan))}</b>",
        "",
        *identity,
        "",
    ]
    lines += [
        f"{badge} Sinal: <b>{signal}</b> • ⭐ <b>{score}/100</b>",
        f"{risk_icon} Risco técnico: <b>{risk}</b>",
        "",
        "💹 <b>RESUMO DO MERCADO</b>",
        f"💲 Preço: <b>{price}</b>",
        f"💧 Liquidez: <b>{liquidity}</b>",
        f"📈 Volume 24h: <b>{volume24h}</b>",
        f"📊 Variação 24h: <b>{change24h:+.2f}%</b>",
    ]
    security_lines = _goplus_lines(item, group)
    if security_lines:
        lines += ["", "🛡️ <b>SEGURANÇA DO CONTRATO</b>", *security_lines]

    reputation_lines = _reputation_lines(item, group)
    if reputation_lines and group in {"plus", "premium"}:
        lines += ["", "🧬 <b>REPUTAÇÃO DO DEPLOYER</b>", *reputation_lines]

    if group == "free":
        # Free is intentionally concise. The scanner may detect the same
        # opportunity as paid plans, but the commercial experience must not
        # expose the complete technical plan or advanced context.
        lines += [
            "",
            "🎯 <b>ACOMPANHAMENTO ESSENCIAL</b>",
            "• Entrada/stop/alvos completos ficam disponíveis no Plus e Premium.",
            "• O plano Grátis recebe avisos resumidos quando um marco monitorado é atingido.",
            "",
            _source_line(item),
            "",
            "💠 <b>Plus:</b> níveis completos, motivos do sinal e risco/retorno.",
            "👑 <b>Premium:</b> raio-X de mercado, score detalhado e acompanhamento avançado.",
        ]
    else:
        lines += [
            f"🏦 Market cap: <b>{marketcap}</b>",
            f"🔄 Compras/Vendas 24h: <b>{buys24h}/{sells24h}</b>",
            "",
            "🧠 <b>LEITURA DO SINAL</b>",
            f"{stage_icon} Estágio: <b>{escape(stage)}</b>",
            f"🎯 Confiança dos filtros: <b>{escape(str(profile['confidence']).upper())}</b>",
        ]
        historical = item.get("historical_probability_score")
        if isinstance(historical, (int, float)):
            lines.append(
                f"🧠 CSM Confidence: <b>{int(item.get('csm_confidence_score') or score)}/100</b> • "
                f"histórico TP1 <b>{float(item.get('historical_tp1_rate_pct') or historical):.1f}%</b> "
                f"(n={int(item.get('historical_sample_size') or 0)})"
            )
            hist_w = item.get("historical_weight_pct")
            if isinstance(hist_w, (int, float)):
                lines.append(f"⚖️ Peso adaptativo: sinal atual <b>{100-float(hist_w):.1f}%</b> • histórico <b>{float(hist_w):.1f}%</b>.")
            lines.append("🔒 Histórico é explicativo e <b>não substitui</b> filtros/GoPlus do sinal atual.")
        lines.extend(f"✓ {escape(reason)}" for reason in reasons)
        lines += ["", *_trade_plan_lines(item, premium=group == "premium")]

    if group == "premium":
        turnover = _float(item.get("volume24h")) / _float(item.get("liquidity")) if _float(item.get("liquidity")) else None
        fdv_mc = _float(item.get("fdv")) / _float(item.get("marketcap")) if _float(item.get("marketcap")) else None
        breakdown = score_breakdown(item)
        quality_pct, quality = data_quality(item)
        buyers24h = item.get("buyers24h")
        sellers24h = item.get("sellers24h")
        sentiment_positive = item.get("sentiment_positive")
        sentiment_negative = item.get("sentiment_negative")
        suspicious_reports = item.get("community_sus_report")
        websites = list(item.get("websites") or [])
        socials = list(item.get("socials") or [])
        labels = [str(value) for value in (item.get("labels") or []) if str(value).strip()]
        holders = item.get("holders")
        pair = str(item.get("pair") or "")
        lines += [
            "",
            "🔬 <b>PESQUISA DE MERCADO PREMIUM</b>",
            f"⏱ Variações: <b>5m {change5m:+.2f}%</b> • <b>1h {change1h:+.2f}%</b> • <b>6h {change6h:+.2f}%</b> • <b>24h {change24h:+.2f}%</b>",
            f"📊 Volumes: <b>5m {compact_usd(item.get('volume5m'))}</b> • <b>1h {compact_usd(item.get('volume1h'))}</b> • <b>6h {compact_usd(item.get('volume6h'))}</b>",
            f"🔁 C/V 5m: <b>{buys5m}/{sells5m}</b> • C/V 1h: <b>{buys1h}/{sells1h}</b> • C/V 24h: <b>{buys24h}/{sells24h}</b>",
            f"🟢 Pressão compradora: <b>{f'{pressure1h:.1f}%' if pressure1h is not None else 'n/d'} em 1h</b> • <b>{f'{pressure24h:.1f}%' if pressure24h is not None else 'n/d'} em 24h</b>",
            f"🏦 Market cap: <b>{marketcap}</b> • FDV: <b>{fdv}</b>",
            f"🧮 Volume/Liquidez: <b>{f'{turnover:.2f}x' if turnover is not None else 'n/d'}</b> • FDV/MC: <b>{f'{fdv_mc:.2f}x' if fdv_mc is not None else 'n/d'}</b>",
            f"🕒 Idade do pool: <b>{format_age(item.get('age_days'))}</b>",
            f"🏛 DEX: <b>{escape(str(item.get('dex') or 'n/d'))}</b> • Par: <b>{escape(str(item.get('quote_symbol') or 'n/d'))}</b>",
            f"⚡ Última negociação informada: <b>{market_timestamp(item.get('last_trade_timestamp'))}</b>",
        ]
        if pair:
            lines.append(f"🔗 Pool: <code>{escape(compact_address(pair, 7))}</code>")
        if holders is not None:
            lines.append(f"👛 Holders informados: <b>{_int(holders):,}</b>")
        if websites or socials:
            lines.append(f"🌐 Presença pública: <b>{len(websites)} site(s) • {len(socials)} rede(s) social(is)</b>")
        if labels:
            lines.append(f"🏷 Rótulos da fonte: <b>{escape(', '.join(labels[:5]))}</b>")
        if buyers24h is not None or sellers24h is not None:
            lines.append(f"👥 Traders únicos 24h: <b>{_int(buyers24h)} compradores/{_int(sellers24h)} vendedores</b>")
        if sentiment_positive is not None or sentiment_negative is not None:
            lines.append(
                f"🗳 Sentimento público: <b>{_float(sentiment_positive):.0f}% positivo/{_float(sentiment_negative):.0f}% negativo</b>"
            )
        if suspicious_reports is not None:
            lines.append(f"🚩 Relatos comunitários de suspeita: <b>{_int(suspicious_reports)}</b>")
        if _int(item.get("boosts_active")) > 0:
            lines.append(f"📣 Boosts promocionais ativos: <b>{_int(item.get('boosts_active'))}</b> — não elevam o score técnico")
        lines += [
            "",
            "🧮 <b>COMPOSIÇÃO DO SCORE</b>",
            f"• Liquidez {breakdown['liquidez']}/25 • Volume {breakdown['volume']}/25",
            f"• Market cap {breakdown['marketcap']}/15 • Atividade {breakdown['atividade']}/15",
            f"• Momentum {breakdown['momentum']}/10 • Idade {breakdown['idade']}/10",
            "",
            f"📡 <b>QUALIDADE DOS DADOS: {quality} ({quality_pct}%)</b>",
        ]
        if flags:
            lines += ["", "⚠️ <b>PONTOS DE ATENÇÃO</b>"]
            lines.extend(f"• {escape(flag)}" for flag in flags[:5])
        else:
            lines.append("• Nenhum alerta adicional nos campos disponíveis.")
        lines += ["", _source_line(item)]

    proof_id = str(item.get("proof_id") or "").strip()
    proof_hash = str(item.get("proof_hash") or "").strip()
    if proof_id and proof_hash:
        lines += [
            "",
            f"🔐 Proof V13: <code>{escape(proof_id)}</code>",
            f"🧾 Commit pré-envio: <code>{escape(proof_hash[:20])}…</code>",
        ]
        if group == "premium":
            lines.append("🕒 O commit contém somente os fatos do sinal; resultados posteriores entram numa cadeia append-only separada.")
    lines += ["", "⚠️ <i>Cenário educacional, não é recomendação financeira. Em cripto, stop e alvo podem executar com diferença por volatilidade e slippage.</i>"]
    return "\n".join(lines), score


def signal_card(item: dict[str, Any], plan: str | None) -> str:
    text, _ = market_report(item, plan)
    decision = item.get("smart_reentry") or {}
    if isinstance(decision, dict) and decision.get("is_reentry") and decision.get("allowed"):
        state = str(decision.get("prior_lifecycle_state") or "").upper() or "N/D"
        reasons = [str(v).strip() for v in (decision.get("improvement_reasons") or []) if str(v).strip()]
        evidence = "; ".join(reasons[:3]) or "reencontrado e aprovado novamente pelos filtros atuais"
        banner = (
            "🔄 <b>REENTRADA INTELIGENTE V16.4</b>\n"
            f"Plano: <b>{escape(base_plan(plan).upper())}</b> • estado anterior: <b>{escape(state)}</b>\n"
            f"✅ {escape(evidence)}\n\n"
        )
        return banner + text
    return text


def position_alert(
    position: dict[str, Any],
    market: dict[str, Any],
    event: str,
    change: float,
    peak: float,
    plan: str | None = None,
    smart_reasons: list[str] | None = None,
) -> str:
    merged = dict(market or {})
    if not _known(merged.get("symbol")):
        merged["symbol"] = position.get("symbol")
    if not _known(merged.get("name")):
        merged["name"] = position.get("symbol")
    merged.setdefault("address", position.get("address"))
    symbol, _ = token_identity(merged)
    chain_key = str(position.get("chain") or merged.get("chain") or "")
    chain = CHAINS.get(chain_key, {"emoji": "🌐", "label": chain_key or "Rede n/d"})
    current = _float(market.get("price"))
    entry = _float(position.get("entry_price"))
    stop = _float(position.get("stop_price"))
    target1 = _float(position.get("target1_price"))
    target2 = _float(position.get("target2_price"))
    peak_change = ((peak / entry) - 1) * 100 if peak > 0 and entry > 0 else change
    group = base_plan(plan)

    if event == "STOP":
        title = "🛑 <b>STOP LOSS DE REFERÊNCIA ATINGIDO</b>"
        status = "Cenário invalidado; o acompanhamento desta posição foi encerrado."
    elif event == "TARGET2":
        title = "🏆 <b>TAKE PROFIT 2 ATINGIDO</b>"
        status = "Alvo final atingido; o acompanhamento desta posição foi encerrado."
    elif event == "SMART":
        title = "📡 <b>ATUALIZAÇÃO INTELIGENTE DO SINAL</b>"
        status = "O sinal continua em acompanhamento; houve mudança relevante desde a última atualização."
    else:
        title = "🎯 <b>TAKE PROFIT 1 ATINGIDO</b>"
        status = "Primeiro alvo atingido; o monitoramento continua até TP2 ou stop."

    identity = (
        f"🪙 <b>{escape(symbol)}</b> • {chain['emoji']} {escape(str(chain['label']))}\n"
        f"📄 <code>{escape(str(position.get('address') or 'n/d'))}</code>"
    )
    header = (
        f"{BRAND_DIVIDER}\n{title}\n{BRAND_DIVIDER}\n"
        f"🔄 <b>Busca de novas oportunidades: a cada {escape(interval_label(plan))}</b>\n"
        "ℹ️ <i>Esse intervalo é de busca; não é promessa de um novo sinal a cada ciclo.</i>\n\n"
        f"{identity}\n\n"
    )

    smart_block = ""
    if event == "SMART":
        reasons = [str(item).strip() for item in (smart_reasons or []) if str(item).strip()]
        smart_block = "🧠 <b>O QUE MUDOU</b>\n" + "\n".join(f"• {escape(reason)}" for reason in reasons[:4]) + "\n\n"

    if group == "free":
        # Deliberately short: event + result only. Exact technical levels remain
        # internal for monitoring, but are part of the paid-plan experience.
        return (
            header
            + f"📊 Resultado observado: <b>{change:+.2f}%</b>\n"
            + f"💹 Preço observado: <code>{format_price(current)}</code>\n\n"
            + f"✅ {status}\n\n"
            + "💠 <b>Plus:</b> veja entrada, stop, TP1, TP2 e risco/retorno.\n"
            + "👑 <b>Premium:</b> inclui máxima, contexto de mercado e leitura avançada.\n\n"
            + "⚠️ <i>Alerta educacional. O preço efetivo de execução pode variar por slippage e liquidez.</i>"
        )

    common = (
        header
        + smart_block
        + f"📊 Resultado observado: <b>{change:+.2f}%</b>\n"
        + f"💲 Entrada: <code>{format_price(entry)}</code>\n"
        + f"💹 Preço atual: <code>{format_price(current)}</code>\n"
        + f"🛑 Stop inicial: <code>{format_price(stop)}</code>\n"
        + f"🎯 TP1: <code>{format_price(target1)}</code>\n"
        + f"🏆 TP2: <code>{format_price(target2)}</code>\n"
    )

    if group == "plus":
        rr1 = ((target1 / entry) - 1) / max(1e-9, 1 - (stop / entry)) if entry > 0 and stop > 0 else 0
        rr2 = ((target2 / entry) - 1) / max(1e-9, 1 - (stop / entry)) if entry > 0 and stop > 0 else 0
        return (
            common
            + (f"⚖️ Risco/retorno original: <b>1:{rr1:.2f}</b> TP1 • <b>1:{rr2:.2f}</b> TP2\n" if rr1 > 0 and rr2 > 0 else "")
            + f"\n✅ {status}\n\n"
            + "👑 Premium acrescenta máxima acompanhada e contexto de mercado do momento.\n\n"
            + "⚠️ <i>Alerta educacional. O preço efetivo de execução pode variar por slippage e liquidez.</i>"
        )

    # Premium: complete position levels + peak + live market context where the
    # provider supplied the data. This is intentionally the richest alert.
    liquidity = compact_usd(market.get("liquidity"))
    volume24h = compact_usd(market.get("volume24h"))
    marketcap = compact_usd(market.get("marketcap"))
    pressure = buy_pressure(market, "24h")
    dex = escape(str(market.get("dex") or "n/d"))
    return (
        common
        + f"🚀 Máxima acompanhada: <b>{peak_change:+.2f}%</b>\n\n"
        + "🔬 <b>CONTEXTO PREMIUM NO ALERTA</b>\n"
        + f"💧 Liquidez: <b>{liquidity}</b>\n"
        + f"📈 Volume 24h: <b>{volume24h}</b>\n"
        + f"🏦 Market cap: <b>{marketcap}</b>\n"
        + f"🟢 Pressão compradora 24h: <b>{f'{pressure:.1f}%' if pressure is not None else 'n/d'}</b>\n"
        + f"🏛 DEX: <b>{dex}</b>\n\n"
        + f"✅ {status}\n\n"
        + "⚠️ <i>Alerta educacional. O preço efetivo de execução pode variar por slippage e liquidez.</i>"
    )


def history_time(value: Any) -> str:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone().strftime("%d/%m • %H:%M")
    except (TypeError, ValueError):
        return "horário n/d"


def market_timestamp(value: Any) -> str:
    try:
        raw = float(value)
        if raw > 10_000_000_000:
            raw /= 1000
        return datetime.fromtimestamp(raw, tz=timezone.utc).astimezone().strftime("%d/%m %H:%M:%S")
    except (TypeError, ValueError, OSError, OverflowError):
        return "n/d"
