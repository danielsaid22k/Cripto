from __future__ import annotations

"""Safe live diagnostics for authenticated discovery providers.

No API secret is ever returned, printed, or placed in a URL. These probes use
exactly the same stdlib HTTPS transport as the production runtime so they are
useful on a-Shell/Termux without shell-specific curl/heredoc behavior.
"""

import re
from typing import Any

from csm.config import settings

from .errors import NetworkHTTPError, TransientNetworkError
from .transport import StdlibHttpTransport


def _safe_server_detail(payload: Any, secret: str = "") -> str:
    """Extract a short actionable Birdeye message without exposing credentials."""
    candidates: list[str] = []
    if isinstance(payload, dict):
        for key in ("message", "error", "detail", "description", "code"):
            value = payload.get(key)
            if value is not None and str(value).strip():
                candidates.append(f"{key}={value}")
        data = payload.get("data")
        if isinstance(data, dict):
            for key in ("message", "error", "code"):
                value = data.get(key)
                if value is not None and str(value).strip():
                    candidates.append(f"{key}={value}")
    elif payload is not None:
        candidates.append(str(payload))
    text = " • ".join(candidates).strip()[:500]
    if secret:
        text = text.replace(secret, "***REDACTED***")
    text = re.sub(r"(?i)(x-api-key|api[_ -]?key|token)\s*[:=]\s*[^\s,;]+", r"\1=***REDACTED***", text)
    return text


def _http_failure(exc: NetworkHTTPError, secret: str = "") -> dict[str, Any]:
    status = int(exc.status)
    detail = _safe_server_detail(getattr(exc, "payload", None), secret)
    lowered = detail.lower()
    quota_exhausted = (
        "compute units usage limit exceeded" in lowered
        or ("compute unit" in lowered and "limit" in lowered and ("exceed" in lowered or "reached" in lowered))
    )
    if quota_exhausted:
        message = "cota de Compute Units (CU) esgotada"
        kind = "quota_exhausted"
    elif status == 401:
        message = "chave ausente, inválida, expirada ou revogada"
        kind = "authentication"
    elif status == 403:
        message = "chave sem acesso ou requisição bloqueada por whitelist/blacklist"
        kind = "access"
    elif status == 400:
        message = "requisição rejeitada pelo contrato do endpoint"
        kind = "bad_request"
    elif status == 429:
        message = "limite de requisições por tempo atingido"
        kind = "rate_limit"
    else:
        message = f"HTTP {status}"
        kind = "http"
    return {
        "ok": False,
        "status": status,
        "message": message,
        "server_detail": detail,
        "kind": kind,
        "quota_exhausted": quota_exhausted,
    }


def check_birdeye(*, check_listing: bool = True, transport: StdlibHttpTransport | None = None, api_key: str | None = None) -> dict[str, Any]:
    """Validate the active Birdeye key and the exact New Listing route used by the scanner.

    ``/defi/networks`` remains a lightweight coverage probe. A HTTP 400 there is
    not treated as definitive authentication failure: the checker continues with
    the actual New Listing Solana request. HTTP 401/403, however, are definitive
    access failures and stop the probe immediately.
    """
    key = str(settings.birdeye_api_key if api_key is None else api_key).strip()
    report: dict[str, Any] = {
        "provider": "birdeye",
        "key_present": bool(key),
        "key_length": len(key),
        "auth_ok": False,
        "credential_ok": False,
        "quota_exhausted": False,
        "rate_limited": False,
        "failure_kind": "",
        "auth_status": None,
        "auth_message": "",
        "auth_server_detail": "",
        "listing_ok": None,
        "listing_status": None,
        "listing_message": "",
        "listing_server_detail": "",
        "networks": [],
        "items": None,
        # Backward-compatible summary fields.
        "status": None,
        "message": "",
    }
    if not key:
        report["message"] = "BIRDEYE_API_KEY não configurada"
        return report

    base = transport or StdlibHttpTransport(timeout=8.0, label="birdeye-check")
    auth_transport = base.clone(
        label="birdeye-check-auth",
        headers={"X-API-KEY": key},
        timeout=8.0,
    )
    auth_failed_hard = False
    try:
        auth = auth_transport.request_json(
            "GET",
            "https://public-api.birdeye.so/defi/networks",
            timeout=8.0,
        )
        payload = auth.payload if isinstance(auth.payload, dict) else {}
        networks = payload.get("data") if isinstance(payload, dict) else []
        if not isinstance(networks, list):
            networks = []
        report["auth_ok"] = True
        report["credential_ok"] = True
        report["auth_status"] = int(auth.status)
        report["auth_message"] = "autenticação/coverage probe OK"
        report["networks"] = [str(item) for item in networks if item]
    except NetworkHTTPError as exc:
        failure = _http_failure(exc, key)
        report["auth_status"] = failure["status"]
        report["auth_message"] = failure["message"]
        report["auth_server_detail"] = failure["server_detail"]
        report["failure_kind"] = failure.get("kind") or ""
        if failure.get("kind") == "rate_limit":
            report["rate_limited"] = True
        if failure.get("quota_exhausted"):
            # The server resolved the key/account and rejected usage because the
            # subscribed CU allowance is exhausted. This is not an auth failure.
            report["credential_ok"] = True
            report["quota_exhausted"] = True
        auth_failed_hard = int(failure["status"]) in {401, 403}
    except TransientNetworkError as exc:
        transient_text = str(exc or "")
        report["auth_message"] = f"falha temporária de rede: {transient_text}"
        if "429" in transient_text or "rate limit" in transient_text.lower():
            report["rate_limited"] = True
            report["failure_kind"] = "rate_limit"
            report["auth_status"] = 429
    except Exception as exc:
        report["auth_message"] = f"falha de transporte: {type(exc).__name__}"

    if auth_failed_hard or report.get("quota_exhausted") or report.get("rate_limited") or not check_listing:
        report["status"] = report["auth_status"]
        report["message"] = report["auth_message"]
        if report["auth_server_detail"]:
            report["message"] += f" • servidor: {report['auth_server_detail']}"
        if report.get("quota_exhausted"):
            report["listing_ok"] = False
            report["listing_message"] = "não testado para preservar CU enquanto a cota está esgotada"
        elif report.get("rate_limited"):
            report["listing_ok"] = False
            report["listing_message"] = "não testado enquanto a Birdeye está em rate limit"
        return report

    # Minimal query on purpose: only `limit` plus x-chain. Optional filters are
    # deliberately excluded to maximize compatibility with BDS package/contract revisions.
    listing_transport = base.clone(
        label="birdeye-check-listing",
        headers={"X-API-KEY": key, "x-chain": "solana"},
        timeout=8.0,
    )
    try:
        listing = listing_transport.request_json(
            "GET",
            "https://public-api.birdeye.so/defi/v2/tokens/new_listing",
            params={"limit": 1},
            timeout=8.0,
        )
        listing_payload = listing.payload if isinstance(listing.payload, dict) else {}
        data = listing_payload.get("data") if isinstance(listing_payload, dict) else None
        if isinstance(data, dict):
            items = data.get("items") or data.get("tokens") or data.get("list") or []
        elif isinstance(data, list):
            items = data
        else:
            items = listing_payload.get("items") or [] if isinstance(listing_payload, dict) else []
        if not isinstance(items, list):
            items = []
        report["listing_ok"] = True
        report["credential_ok"] = True
        report["listing_status"] = int(listing.status)
        report["listing_message"] = "New Listing OK"
        report["items"] = len(items)
        # A successful authenticated provider route proves the key works even if
        # the separate /defi/networks probe returned a package-specific 400.
        report["auth_ok"] = True
    except NetworkHTTPError as exc:
        failure = _http_failure(exc, key)
        report["listing_ok"] = False
        report["listing_status"] = failure["status"]
        report["listing_message"] = failure["message"]
        report["listing_server_detail"] = failure["server_detail"]
        report["failure_kind"] = failure.get("kind") or report.get("failure_kind") or ""
        if failure.get("kind") == "rate_limit":
            report["rate_limited"] = True
        if failure.get("quota_exhausted"):
            report["credential_ok"] = True
            report["quota_exhausted"] = True
        if int(failure["status"]) in {401, 403}:
            report["auth_ok"] = False
            report["credential_ok"] = False
    except TransientNetworkError as exc:
        transient_text = str(exc or "")
        report["listing_ok"] = False
        report["listing_message"] = f"falha temporária de rede: {transient_text}"
        if "429" in transient_text or "rate limit" in transient_text.lower():
            report["rate_limited"] = True
            report["failure_kind"] = "rate_limit"
            report["listing_status"] = 429
    except Exception as exc:
        report["listing_ok"] = False
        report["listing_message"] = f"falha de transporte: {type(exc).__name__}"

    report["status"] = report["listing_status"] if report["listing_status"] is not None else report["auth_status"]
    if report["listing_ok"] is True:
        if report["auth_status"] and int(report["auth_status"]) >= 400:
            report["message"] = f"New Listing OK; coverage probe HTTP {report['auth_status']}"
        else:
            report["message"] = "autenticação e New Listing OK"
    else:
        parts = []
        if report["auth_status"] is not None:
            parts.append(f"coverage HTTP {report['auth_status']}: {report['auth_message']}")
            if report["auth_server_detail"]:
                parts.append(f"coverage servidor: {report['auth_server_detail']}")
        if report["listing_status"] is not None or report["listing_message"]:
            prefix = f"New Listing HTTP {report['listing_status']}" if report["listing_status"] is not None else "New Listing"
            parts.append(f"{prefix}: {report['listing_message']}")
            if report["listing_server_detail"]:
                parts.append(f"New Listing servidor: {report['listing_server_detail']}")
        report["message"] = " • ".join(parts) or "diagnóstico Birdeye inconclusivo"
    return report


def check_goplus(
    *,
    chain: str = "",
    address: str = "",
    transport: StdlibHttpTransport | None = None,
) -> dict[str, Any]:
    """Probe GoPlus with the same stdlib transport used by the scanner.

    With no token address this calls ``/supported_chains``. With ``chain`` and
    ``address`` it calls the exact Token Security route used by the security
    gate. The optional GOPLUS_ACCESS_TOKEN is sent only as an Authorization
    header and is never returned by this function.
    """
    from .goplus_security import extract_result, request_spec

    token = str(settings.goplus_access_token or "").strip()
    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = token if token.lower().startswith("bearer ") else f"Bearer {token}"
    base = transport or StdlibHttpTransport(timeout=8.0, label="goplus-check")
    report: dict[str, Any] = {
        "provider": "goplus",
        "enabled": bool(settings.goplus_enabled),
        "access_token_present": bool(token),
        "ok": False,
        "status": None,
        "message": "",
        "server_detail": "",
        "chain": str(chain or "").strip().lower(),
        "address_present": bool(str(address or "").strip()),
        "supported_count": None,
        "token_data": False,
    }
    if not settings.goplus_enabled:
        report["message"] = "GoPlus desativado na configuração"
        return report

    if chain and address:
        spec = request_spec(chain, address, token)
        if spec is None:
            report["message"] = "rede não suportada pelo gate GoPlus local"
            return report
        url, params, spec_headers = spec
        headers.update(spec_headers)
    else:
        url = "https://api.gopluslabs.io/api/v1/supported_chains"
        params = None

    probe = base.clone(label="goplus-check", headers=headers or None, timeout=8.0)
    try:
        result = probe.request_json("GET", url, params=params, timeout=8.0)
        report["status"] = int(result.status)
        report["ok"] = True
        if chain and address:
            row = extract_result(result.payload, address)
            report["token_data"] = bool(row)
            report["message"] = "Token Security OK" if row else "HTTP 200, mas sem dados para o token consultado"
        else:
            payload = result.payload if isinstance(result.payload, dict) else {}
            rows = payload.get("result") or payload.get("data") or []
            if isinstance(rows, dict):
                rows = list(rows.values())
            report["supported_count"] = len(rows) if isinstance(rows, list) else None
            report["message"] = "GoPlus API acessível"
        return report
    except NetworkHTTPError as exc:
        failure = _http_failure(exc, token)
        report["status"] = failure["status"]
        report["message"] = failure["message"]
        report["server_detail"] = failure["server_detail"]
        return report
    except TransientNetworkError as exc:
        report["message"] = f"falha temporária de rede: {exc}"
        return report
    except Exception as exc:
        report["message"] = f"falha de transporte: {type(exc).__name__}: {exc}"[:300]
        return report
