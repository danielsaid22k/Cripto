from __future__ import annotations

import time
from dataclasses import asdict, dataclass
from typing import Any, Callable
from csm.config import settings


@dataclass
class ProviderState:
    name: str
    status: str = "ONLINE"
    failures: int = 0
    successes: int = 0
    misses: int = 0
    last_error: str = ""
    last_success: float = 0.0
    next_retry: float = 0.0
    latency_ms: float = 0.0
    # V16.1 resilience telemetry. These fields are additive and safe for old
    # consumers that only read the legacy keys above.
    circuit_reason: str = ""
    rate_limit_events: int = 0
    consecutive_rate_limits: int = 0
    quota_exhaustions: int = 0
    recovered_at: float = 0.0
    recovery_grace_until: float = 0.0
    last_retry_after: int = 0


class ProviderGateway:
    """Circuit breaker + cache shared by manual analysis and scanner.

    V16.1 distinguishes ordinary transient failures from HTTP 429 rate limits
    and account/package quota exhaustion. Rate limits open a longer COOLDOWN
    circuit so the scanner immediately falls back to other providers instead
    of hammering the same endpoint. A successful probe closes the circuit and
    leaves a short recovery-grace marker for health dashboards.
    """

    def __init__(
        self,
        max_backoff: int = 900,
        *,
        rate_limit_base: int = 300,
        recovery_grace: int = 600,
    ):
        self.max_backoff = max(30, int(max_backoff))
        self.rate_limit_base = max(60, int(rate_limit_base))
        self.recovery_grace = max(60, int(recovery_grace))
        self.states: dict[str, ProviderState] = {}
        self.cache: dict[str, tuple[float, Any]] = {}

    def state(self, name: str) -> ProviderState:
        return self.states.setdefault(name, ProviderState(name=name))

    @staticmethod
    def _http_status(exc: Exception) -> int:
        for attr in ("status", "status_code", "code"):
            try:
                value = int(getattr(exc, attr, 0) or 0)
            except (TypeError, ValueError):
                value = 0
            if value:
                return value
        text = str(exc or "")
        import re
        match = re.search(r"\bHTTP\s*(\d{3})\b", text, flags=re.I)
        return int(match.group(1)) if match else 0

    @staticmethod
    def _safe_payload_message(exc: Exception) -> str:
        payload = getattr(exc, "payload", None)
        if isinstance(payload, dict):
            for key in ("message", "error", "detail", "description"):
                value = payload.get(key)
                if value is not None and str(value).strip():
                    return str(value).strip()[:180]
        return str(exc or "").strip()[:180]

    def _rate_limit_delay(self, state: ProviderState, *, retry_after: int = 0) -> int:
        """Return an adaptive bounded cooldown for HTTP 429.

        V16.5.9 treats GeckoTerminal differently from account-wide quota faults:
        the first 429 waits the server ``Retry-After`` when supplied, otherwise
        5 minutes; repeated 429s escalate 5m -> 10m -> 20m -> 30m. Other
        providers retain the established generic breaker.
        """
        name = str(state.name or "").casefold()
        if "geckoterminal" in name:
            schedule = (
                max(60, int(getattr(settings, "geckoterminal_rate_limit_initial_seconds", 300))),
                max(60, int(getattr(settings, "geckoterminal_rate_limit_second_seconds", 600))),
                max(60, int(getattr(settings, "geckoterminal_rate_limit_third_seconds", 1200))),
                max(60, int(getattr(settings, "geckoterminal_rate_limit_max_seconds", 1800))),
            )
            idx = min(max(0, int(state.consecutive_rate_limits) - 1), len(schedule) - 1)
            delay = int(schedule[idx])
            if int(retry_after or 0) > 0:
                # Honor the server hint without letting a malformed header lock
                # the public fallback out indefinitely.
                delay = max(60, min(int(schedule[-1]), int(retry_after)))
            return delay
        exponent = min(max(0, state.consecutive_rate_limits - 1), 2)
        raw = self.rate_limit_base * (2 ** exponent)
        base = min(self.max_backoff, raw)
        jitter = sum(ord(ch) for ch in state.name) % 23
        return min(self.max_backoff, base + jitter)

    def fetch(
        self,
        name: str,
        request: Callable[[], Any],
        *,
        cache_key: str | None = None,
        cache_ttl: int = 60,
        stale_ttl: int = 1800,
        force: bool = False,
    ):
        now = time.time()
        state = self.state(name)
        resolved_cache_key = str(cache_key or name)
        cached = self.cache.get(resolved_cache_key)
        if not force and cached and now - cached[0] <= cache_ttl:
            return cached[1]
        # Even force=True must respect an open circuit. "force" means bypass
        # fresh cache, not bypass provider protection.
        if state.next_retry > now:
            if cached and now - cached[0] <= stale_ttl:
                return cached[1]
            return None
        started = time.monotonic()
        previous_status = state.status
        try:
            payload = request()
            state.status = "ONLINE"
            state.failures = 0
            state.successes += 1
            state.last_error = ""
            state.last_success = now
            state.next_retry = 0
            state.latency_ms = round((time.monotonic() - started) * 1000, 2)
            state.circuit_reason = ""
            state.consecutive_rate_limits = 0
            state.last_retry_after = 0
            if previous_status not in {"ONLINE", "AVAILABLE"}:
                state.recovered_at = now
                state.recovery_grace_until = now + self.recovery_grace
            self.cache[resolved_cache_key] = (now, payload)
            return payload
        except Exception as exc:
            http_status = self._http_status(exc)
            safe_message = self._safe_payload_message(exc)
            lowered_message = safe_message.lower()
            cu_exhausted = (
                "compute units usage limit exceeded" in lowered_message
                or ("compute unit" in lowered_message and "limit" in lowered_message and ("exceed" in lowered_message or "reached" in lowered_message))
            )
            is_rate_limit = (
                http_status == 429
                or "http 429" in lowered_message
                or "too many requests" in lowered_message
                or "rate limit" in lowered_message
            )

            if cu_exhausted:
                state.last_error = f"NetworkHTTPError: HTTP {http_status or 400} (Compute Units usage limit exceeded)"
                state.failures += 1
                state.quota_exhaustions += 1
                state.status = "QUOTA_EXHAUSTED"
                state.circuit_reason = "quota"
                # Birdeye Compute Units are account-wide. Six hours avoids the
                # previous fall/recover loop while public fallbacks keep scanning.
                quota_wait = int(getattr(settings, "birdeye_quota_cooldown_seconds", 21600)) if "birdeye" in str(name).lower() else 1800
                state.next_retry = now + max(quota_wait, self.max_backoff)
                state.latency_ms = round((time.monotonic() - started) * 1000, 2)
                return None

            if http_status == 402:
                state.last_error = "NetworkHTTPError: HTTP 402 (quota/credits exhausted)"
                state.failures += 1
                state.quota_exhaustions += 1
                state.status = "QUOTA_EXHAUSTED"
                state.circuit_reason = "quota"
                wait = int(getattr(settings, "dexpaprika_quota_cooldown_seconds", 21600))
                state.next_retry = now + max(wait, self.max_backoff)
                state.latency_ms = round((time.monotonic() - started) * 1000, 2)
                return None

            if is_rate_limit:
                state.failures += 1
                state.rate_limit_events += 1
                state.consecutive_rate_limits += 1
                state.status = "COOLDOWN"
                state.circuit_reason = "rate_limit"
                retry_after = max(0, int(getattr(exc, "retry_after", 0) or 0))
                state.last_retry_after = retry_after
                delay = self._rate_limit_delay(state, retry_after=retry_after)
                state.next_retry = now + delay
                state.last_error = f"TransientNetworkError: Serviço temporariamente indisponível (HTTP 429). Cooldown {delay}s"
                state.latency_ms = round((time.monotonic() - started) * 1000, 2)
                if cached and now - cached[0] <= stale_ttl:
                    return cached[1]
                return None

            state.consecutive_rate_limits = 0
            state.last_retry_after = 0
            if safe_message:
                state.last_error = f"{type(exc).__name__}: {safe_message}"[:300]
            else:
                state.last_error = f"{type(exc).__name__}: {exc}"[:300]

            # Authentication/access failures must never be disguised by stale
            # cache. Returning old provider data after a 401/403 makes the
            # operator believe the configured key is healthy.
            if http_status in {401, 403}:
                state.failures += 1
                state.status = "OFFLINE"
                state.circuit_reason = "auth"
                state.next_retry = now + min(self.max_backoff, 300)
                state.latency_ms = round((time.monotonic() - started) * 1000, 2)
                return None

            # A resource-level 404 means capability/data miss, not provider
            # outage. It must not trip the shared circuit breaker.
            if http_status == 404:
                state.failures = 0
                state.misses += 1
                state.status = "ONLINE" if state.successes else "AVAILABLE"
                state.circuit_reason = ""
                state.next_retry = 0
                state.latency_ms = round((time.monotonic() - started) * 1000, 2)
                if cached and now - cached[0] <= stale_ttl:
                    return cached[1]
                return None

            state.failures += 1
            state.status = "DEGRADED" if state.failures < 4 else "OFFLINE"
            state.circuit_reason = "transient" if state.status == "DEGRADED" else "failure"
            state.next_retry = now + min(self.max_backoff, 15 * (2 ** min(state.failures - 1, 4)))
            if cached and now - cached[0] <= stale_ttl:
                return cached[1]
            return None


    def clear_family_circuit(self, family: str) -> int:
        """Close process-local circuits for one provider family after a safe probe."""
        family = str(family or "").casefold().replace(" ", "")
        changed = 0
        for state in self.states.values():
            normalized = str(state.name or "").casefold().replace(" ", "")
            if family and family in normalized:
                state.status = "ONLINE" if state.successes else "AVAILABLE"
                state.failures = 0
                state.next_retry = 0.0
                state.circuit_reason = ""
                state.consecutive_rate_limits = 0
                state.last_retry_after = 0
                changed += 1
        return changed

    def snapshot(self) -> list[dict[str, Any]]:
        now = time.time()
        rows = []
        for state in sorted(self.states.values(), key=lambda item: item.name.lower()):
            row = asdict(state)
            row["diagnostic_only"] = " probe" in str(state.name or "").casefold()
            row["retry_in"] = max(0, int(state.next_retry - now))
            total = state.successes + state.failures
            row["success_rate"] = round(state.successes / total * 100, 1) if total else 100.0
            row["recently_recovered"] = bool(state.recovery_grace_until > now)
            row["recovery_in"] = max(0, int(state.recovery_grace_until - now))
            rows.append(row)
        return rows
