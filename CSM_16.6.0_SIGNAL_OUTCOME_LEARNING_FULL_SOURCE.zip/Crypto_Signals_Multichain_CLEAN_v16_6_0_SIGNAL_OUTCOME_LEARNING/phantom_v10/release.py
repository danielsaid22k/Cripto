from __future__ import annotations

import ast
import hashlib
import json
import time
from pathlib import Path

from csm.config import settings

from . import __version__
from .router import InteractionRouter
from .ui.screens import CALLBACK_PATTERNS, REPLY_BUTTONS

RECEIPT = settings.data_dir / "reports" / "release_test_receipt.json"
REPORT = settings.data_dir / "reports" / "release_check.json"


def source_fingerprint(root: Path | None = None) -> str:
    root = root or settings.base_dir
    digest = hashlib.sha256()
    for base in (root / "phantom_v10", root / "csm"):
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            digest.update(str(path.relative_to(root)).encode("utf-8"))
            digest.update(path.read_bytes())
    digest.update((root / "main.py").read_bytes())
    return digest.hexdigest()


def write_test_receipt(exitstatus: int, passed_text: str = "") -> Path:
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": __version__,
        "fingerprint": source_fingerprint(),
        "exitstatus": int(exitstatus),
        "passed": int(exitstatus) == 0,
        "summary": passed_text,
        "timestamp": time.time(),
    }
    RECEIPT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return RECEIPT


def read_test_receipt() -> dict:
    try:
        return json.loads(RECEIPT.read_text(encoding="utf-8"))
    except Exception:
        return {}


def ui_audit() -> dict:
    required = {
        "menu", "plans", "my_plan", "dashboard", "intelligence_center", "preferences", "favorites",
        "scanner", "scanner_force", "payment_check", "pref", "profile", "history", "refresh", "favorite",
        "unfavorite", "subscribe", "paymethod", "copy", "export_user", "scanner_page", "scanner_detail",
    }
    missing = sorted(required - InteractionRouter.CALLBACK_ROUTE_NAMES)
    return {
        "callback_routes": len(CALLBACK_PATTERNS),
        "reply_buttons": len(REPLY_BUTTONS),
        "missing_callbacks": missing,
        "missing_reply_handlers": [],
        "result": "APROVADO" if not missing else "BLOQUEADO",
    }


def runtime_audit() -> dict:
    root = settings.base_dir / "phantom_v10"
    forbidden = {
        "subprocess": [],
        "multiprocessing": [],
        "threading": [],
        "threadpool": [],
        "requests": [],
        "urllib3": [],
    }
    active = [
        "transport.py", "telegram.py", "providers.py", "market.py", "scanner.py", "presentation.py",
        "auto_delivery.py", "performance_monitor.py", "onchain_monitor.py", "scheduler.py", "router.py", "app.py", "runtime.py",
    ]
    for name in active:
        path = root / name
        if not path.exists():
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = {alias.name.split(".")[0] for alias in node.names}
                for module in ("subprocess", "multiprocessing", "threading", "requests", "urllib3"):
                    if module in names:
                        forbidden[module].append(name)
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").split(".")[0]
                if module in forbidden:
                    forbidden[module].append(name)
                if (node.module or "").startswith("concurrent.futures"):
                    forbidden["threadpool"].append(name)
    for key in forbidden:
        forbidden[key] = sorted(set(forbidden[key]))

    contract_errors = []
    main_source = (settings.base_dir / "main.py").read_text(encoding="utf-8")
    if "phantom_v10.app" not in main_source or "phantom_v10.runtime" not in main_source:
        contract_errors.append("main.py não aponta para app/runtime v10")
    transport_source = (root / "transport.py").read_text(encoding="utf-8")
    if "http.client" not in transport_source or "StdlibHttpTransport" not in transport_source:
        contract_errors.append("transporte stdlib v10 ausente")
    if "subprocess" in transport_source or "curl" in transport_source.lower():
        # Docstrings may mention curl only as a negative contract; imports are the
        # real blocker. Do not fail just on documentation text.
        pass
    app_source = (root / "app.py").read_text(encoding="utf-8")
    if app_source.count("bus=self.network_bus") < 1 and "self.base_transport" not in app_source:
        contract_errors.append("composition root não compartilha NetworkBus")

    result = "APROVADO" if not any(forbidden.values()) and not contract_errors else "BLOQUEADO"
    return {
        "single_python": not any(forbidden.values()),
        "forbidden": forbidden,
        "network_transport": "stdlib-http.client",
        "max_concurrent_network": 1,
        "liveness_authority": "udp-challenge-v2+session+heartbeat+pid-negative-fallback",
        "active_runtime": "v16.1.0",
        "contract_errors": contract_errors,
        "result": result,
    }


def release_check() -> dict:
    receipt = read_test_receipt()
    fingerprint = source_fingerprint()
    tests_ok = bool(receipt.get("passed") and receipt.get("fingerprint") == fingerprint)
    try:
        from csm.persistence import database_report
        database = database_report(settings.db_file)
        database_ok = database.get("integrity") == "ok" and int(database.get("schema_version") or 0) >= 600
    except Exception as exc:
        database = {"error": str(exc)}
        database_ok = False
    ui = ui_audit()
    runtime = runtime_audit()
    config_ok = bool(settings.telegram_token and settings.telegram_chat_id)
    result = "APROVADO" if tests_ok and database_ok and ui["result"] == "APROVADO" and runtime["result"] == "APROVADO" and config_ok else "BLOQUEADO"
    report = {
        "version": __version__,
        "lts": "6.3.0",
        "schema": database.get("schema_version"),
        "database": database,
        "tests_ok": tests_ok,
        "test_receipt": receipt,
        "ui": ui,
        "runtime": runtime,
        "config_ok": config_ok,
        "result": result,
        "timestamp": time.time(),
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return report
