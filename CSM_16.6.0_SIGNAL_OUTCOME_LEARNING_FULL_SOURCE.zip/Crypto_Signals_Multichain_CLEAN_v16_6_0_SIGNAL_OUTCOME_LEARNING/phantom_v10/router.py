from __future__ import annotations

from html import escape

from csm.chains import detect_chain, normalize_chain
from csm.plans import PLANS

from .payments import only_digits, valid_document
from .ui import screens as ui


class InteractionRouter:
    """All Telegram callback/message routing in one place.

    Local UI routes never touch market providers. Explicit analysis and payment
    actions are the only user interactions allowed to call external services.
    """

    CALLBACK_ROUTE_NAMES = {
        "enter_app", "menu", "plans", "my_plan", "dashboard", "intelligence_center", "preferences",
        "pref", "profile", "history", "favorites", "export_user", "scanner", "scanner_force",
        "scanner_page", "scanner_detail", "copy", "favorite", "unfavorite", "refresh",
        "subscribe", "paymethod", "payment_check",
    }

    def __init__(self, app):
        self.app = app

    @property
    def telegram(self):
        return self.app.telegram

    @property
    def storage(self):
        return self.app.storage

    def callback(self, cb: dict):
        callback_id = cb.get("id", "")
        data = str(cb.get("data") or "")
        message = cb.get("message") or {}
        chat_id = (message.get("chat") or {}).get("id")
        message_id = message.get("message_id")
        sender = cb.get("from") or {}
        user_id = int(sender.get("id") or chat_id)
        self.telegram.answer_callback(callback_id)
        try:
            self.app.auto_delivery.mark_reachable(user_id)
        except Exception:
            pass
        user = self.storage.upsert_user(user_id, sender.get("username", ""), sender.get("first_name", ""))
        try:
            if data in {"enter_app", "menu"}:
                return self.telegram.edit_or_send(chat_id, message_id, ui.main_menu(user, sender.get("first_name", "")), ui.user_keyboard(user))
            if data == "plans":
                return self.telegram.edit_or_send(chat_id, message_id, ui.plans_text(), ui.sales_keyboard(bool(self.app.payments)))
            if data == "my_plan":
                return self.telegram.edit_or_send(
                    chat_id,
                    message_id,
                    ui.subscription_text(self.storage, user),
                    {"inline_keyboard": [[{"text": "💎 Planos", "callback_data": "plans"}], [{"text": "🏠 Menu", "callback_data": "menu"}]]},
                )
            if data == "dashboard":
                text, keyboard = ui.dashboard_screen(self.app, user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data == "intelligence_center":
                text, keyboard = ui.central_screen(self.app, user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data == "preferences":
                text, keyboard = ui.preferences_screen(self.app, user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data.startswith("pref|"):
                name = data.split("|", 1)[1]
                if name in {"auto_signals", "favorite_alerts", "expiry_alerts"}:
                    self.storage.toggle_user_preference(user_id, name)
                text, keyboard = ui.preferences_screen(self.app, user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data.startswith("profile|"):
                action = data.split("|", 1)[1]
                fn = {
                    "risk": self.app.user_profiles.cycle_risk_profile,
                    "chains": self.app.user_profiles.cycle_chains,
                    "detail": self.app.user_profiles.cycle_detail_mode,
                    "frequency": self.app.user_profiles.cycle_notification_frequency,
                    "quiet": self.app.user_profiles.cycle_quiet_hours,
                    "language": self.app.user_profiles.cycle_language,
                }.get(action)
                if fn:
                    fn(user_id)
                text, keyboard = ui.preferences_screen(self.app, user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data.startswith("history|"):
                text, keyboard = self.app.history_screen(user_id, int(data.split("|", 1)[1]))
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data == "favorites":
                text, keyboard = self.app.favorites_screen(user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data == "export_user":
                return self.telegram.edit_or_send(
                    chat_id,
                    message_id,
                    ui.export_text(self.storage.export_user_data(user_id)),
                    {"inline_keyboard": [[{"text": "🏠 Menu", "callback_data": "menu"}]]},
                )
            if data in {"scanner", "scanner_noop"}:
                text, keyboard = self.app.scanner_screen(user_id)
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data == "scanner_force":
                self.app.scheduler.request_manual_scan(user_id)
                return self.telegram.edit_or_send(
                    chat_id,
                    message_id,
                    "⏳ <b>Novo ciclo agendado.</b>\nO scheduler executará uma etapa por vez; o bot continua respondendo.",
                    {"inline_keyboard": [[{"text": "🏠 Menu", "callback_data": "menu"}]]},
                )
            if data.startswith("scanner_page|"):
                text, keyboard = self.app.scanner_screen(user_id, int(data.split("|", 1)[1]))
                return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
            if data.startswith("scanner_detail|"):
                idx = int(data.split("|", 1)[1])
                rows = self.app.scanner_sessions.get(user_id, self.app.scanner.last_results)
                if 0 <= idx < len(rows):
                    item = rows[idx]
                    text, keyboard = self.app.scanner_detail(user_id, item)
                    return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
                return self.telegram.edit_or_send(chat_id, message_id, "ℹ️ Resultado não encontrado.")
            if data.startswith(("copy|", "favorite|", "unfavorite|", "refresh|")):
                action, chain, address = data.split("|", 2)
                if action == "copy":
                    return self.telegram.edit_or_send(chat_id, message_id, f"📋 Contrato:\n<code>{escape(address)}</code>")
                if action == "favorite":
                    market = self.app.market.cache.get((chain, address), (0, {"chain": chain, "address": address, "name": "Token", "symbol": "?", "price": 0}))[1]
                    try:
                        self.storage.add_favorite(user_id, chain, address, market)
                        note = "⭐ Favorito salvo."
                    except Exception as exc:
                        note = f"⚠️ Não foi possível favoritar: {escape(str(exc))}"
                    return self.telegram.send(chat_id, note, ui.user_keyboard(user))
                if action == "unfavorite":
                    self.storage.remove_favorite(user_id, chain, address)
                    text, keyboard = self.app.favorites_screen(user_id)
                    return self.telegram.edit_or_send(chat_id, message_id, text, keyboard)
                self.telegram.edit_or_send(chat_id, message_id, "⏳ Consultando mercado...")
                text, keyboard = self.app.analyze(user_id, chain, address, force=True)
                return self.telegram.send(chat_id, text, keyboard)
            if data.startswith("subscribe|"):
                plan = data.split("|", 1)[1]
                if not self.app.payments:
                    return self.telegram.edit_or_send(chat_id, message_id, "⚠️ Pagamentos automáticos não configurados.", ui.sales_keyboard(False))
                meta = PLANS.get(plan)
                if not meta:
                    return self.telegram.edit_or_send(chat_id, message_id, "⚠️ Plano inválido.")
                return self.telegram.edit_or_send(
                    chat_id,
                    message_id,
                    f"💳 <b>{meta['label']}</b>\nValor: <b>R$ {meta['value']:.2f}</b>\nAcesso: <b>{meta['days']} dias</b>",
                    self.app.payment_keyboard(plan),
                )
            if data.startswith("paymethod|"):
                _, plan, method = data.split("|", 2)
                full_name = " ".join(part for part in [sender.get("first_name", ""), sender.get("last_name", "")] if part).strip()
                self.app.pending_payment[user_id] = {
                    "plan": plan,
                    "name": full_name or f"Cliente Telegram {user_id}",
                    "billing_type": method,
                }
                return self.telegram.edit_or_send(chat_id, message_id, "🪪 Envie somente seu <b>CPF ou CNPJ</b>. Para cancelar, /cancelar.")
            if data == "payment_check":
                return self.verify_payment(chat_id, user_id)
            return self.telegram.send(chat_id, "⚠️ Ação não reconhecida. Abra o menu novamente.", ui.user_keyboard(user))
        except Exception as exc:
            self.app.log_warning(f"callback isolado {type(exc).__name__}: {exc}")
            try:
                return self.telegram.send(chat_id, "⚠️ Esta tela encontrou um erro isolado. O bot continua online.", ui.user_keyboard(user))
            except Exception:
                return None

    def message(self, msg: dict):
        chat = msg.get("chat") or {}
        sender = msg.get("from") or {}
        user_id = int(sender.get("id") or chat.get("id"))
        chat_id = chat.get("id")
        text = (msg.get("text") or "").strip()
        lower = text.lower()
        try:
            self.app.auto_delivery.mark_reachable(user_id)
        except Exception:
            pass
        user = self.storage.upsert_user(user_id, sender.get("username", ""), sender.get("first_name", ""))

        # Daniel AI V1.2 Dual Response: Telegram voice/audio is downloaded with
        # a hard cap, transcribed locally, then routed only through DanielAI.ask.
        # It never becomes a general Telegram command parser, so spoken text
        # cannot bypass the same read-only/critical-action boundaries as /daniel.
        voice_payload = msg.get("voice") or msg.get("audio")
        if isinstance(voice_payload, dict) and voice_payload.get("file_id"):
            return self.voice_message(msg, user, voice_payload)

        # Emergency/safe lifecycle commands must bypass conversational states
        # such as pending CPF/CNPJ collection. Otherwise an admin in the middle
        # of a payment flow could be unable to stop the bot safely.
        if lower in {"/encerrar", "/shutdown", "/stopbot"}:
            if not self.app.is_admin(user_id):
                return self.telegram.send(chat_id, "⛔ Comando restrito ao administrador.", ui.user_keyboard(user))
            if self.app.lifecycle_message_is_stale(msg):
                self.app.log_warning("comando de encerramento antigo ignorado; checkpoint Telegram será avançado")
                return None
            result = self.telegram.send(
                chat_id,
                "🛑 Encerramento seguro solicitado. Aguarde a confirmação no a-Shell.",
                ui.user_keyboard(user),
            )
            self.app.request_shutdown("Telegram /encerrar")
            return result

        # Daniel AI is part of the active Phantom v10 runtime. Keep this route
        # before conversational/payment states so an admin command is never
        # mistaken for CPF/CNPJ input. The legacy csm.app route is not used by
        # `python main.py bot`, which boots phantom_v10.app.PhantomApp.
        command = lower.split(maxsplit=1)[0] if lower else ""
        command_base = command.split("@", 1)[0]
        if command_base in {"/admin_block", "/admin_unblock"}:
            if not self.app.is_admin(user_id):
                return self.telegram.send(chat_id, "⛔ Comando restrito ao administrador.", ui.user_keyboard(user))
            parts = text.split()
            if len(parts) < 2:
                return self.telegram.send(chat_id, f"Uso: <code>{command_base} USER_ID</code>", ui.user_keyboard(user))
            try:
                target = int(parts[1])
            except (TypeError, ValueError):
                return self.telegram.send(chat_id, "❌ USER_ID inválido.", ui.user_keyboard(user))
            blocked = command_base == "/admin_block"
            self.storage.set_blocked(target, blocked)
            if not blocked:
                try:
                    self.app.auto_delivery.mark_reachable(target)
                except Exception:
                    pass
            action = "bloqueado" if blocked else "desbloqueado"
            return self.telegram.send(chat_id, f"✅ Usuário <code>{target}</code> {action}.", ui.user_keyboard(user))

        if command_base in {"/daniel", "/ai"}:
            try:
                from daniel_ai.config import DanielSettings
                cfg = DanielSettings.from_env()
                if cfg.admin_only and not self.app.is_admin(user_id):
                    return self.telegram.send(
                        chat_id,
                        "⛔ Daniel AI está disponível somente para o administrador.",
                        ui.user_keyboard(user),
                    )
                from daniel_ai.engine import DanielAI
                parts = text.split(maxsplit=1)
                if len(parts) == 1:
                    answer = DanielAI(cfg).help_text()
                else:
                    answer = DanielAI(cfg).ask(parts[1], user_id=user_id, source="telegram")
                return self.telegram.send(chat_id, answer, ui.user_keyboard(user))
            except Exception as exc:
                self.app.log_warning(f"Daniel AI isolado {type(exc).__name__}: {exc}")
                return self.telegram.send(
                    chat_id,
                    f"⚠️ Daniel AI indisponível: {escape(str(exc))}",
                    ui.user_keyboard(user),
                )

        if user_id in self.app.pending_payment:
            if lower == "/cancelar":
                self.app.pending_payment.pop(user_id, None)
                return self.telegram.send(chat_id, "✅ Cobrança cancelada.", ui.user_keyboard(user))
            if not valid_document(text):
                return self.telegram.send(chat_id, "❌ CPF/CNPJ inválido. Envie novamente ou /cancelar.", ui.user_keyboard(user))
            pending = self.app.pending_payment.pop(user_id)
            try:
                row = self.app.payments.create_payment(
                    user_id=user_id,
                    plan=pending["plan"],
                    name=pending["name"],
                    cpf_cnpj=only_digits(text),
                    billing_type=pending["billing_type"],
                )
                keyboard = {"inline_keyboard": [[{"text": "Abrir pagamento", "url": row.get("invoice_url")}], [{"text": "✅ Já paguei", "callback_data": "payment_check"}]]}
                extra = f"\n\nPIX: <code>{escape(str(row.get('pix_payload') or ''))}</code>" if row.get("pix_payload") else ""
                return self.telegram.send(chat_id, "✅ Cobrança criada." + extra, keyboard)
            except Exception as exc:
                return self.telegram.send(chat_id, f"❌ Falha ao criar cobrança: {escape(str(exc))}", ui.sales_keyboard(bool(self.app.payments)))

        if lower == "/start":
            text_out, keyboard = ui.welcome(user, sender.get("first_name", ""))
            return self.telegram.send(chat_id, text_out, keyboard)
        if lower in {"💎 planos", "👑 conhecer premium", "/planos"}:
            return self.telegram.send(chat_id, ui.plans_text(), ui.sales_keyboard(bool(self.app.payments)))
        if lower in {"👤 meu plano", "👤 minha assinatura", "/meuplano"}:
            return self.telegram.send(chat_id, ui.subscription_text(self.storage, user), ui.user_keyboard(user))
        if lower in {"🟢 status", "/status"}:
            return self.telegram.send(chat_id, ui.status_text(user, self.app.scheduler_status(user_id)), ui.user_keyboard(user))
        if lower in {"📡 sinais automáticos", "🚀 scanner", "/scanner"}:
            return self.telegram.send(chat_id, ui.auto_signals_text(user, self.app.scheduler_status(user_id)), ui.user_keyboard(user))
        if lower in {"🧠 minha central", "/central", "/minhaconta"}:
            text_out, keyboard = ui.central_screen(self.app, user_id)
            return self.telegram.send(chat_id, text_out, keyboard)
        if lower in {"👑 central premium", "⚙️ painel", "/painel"}:
            text_out, keyboard = ui.dashboard_screen(self.app, user_id)
            return self.telegram.send(chat_id, text_out, keyboard)
        if lower in {"🎛️ preferências", "⚙️ preferências", "/preferencias"}:
            text_out, keyboard = ui.preferences_screen(self.app, user_id)
            return self.telegram.send(chat_id, text_out, keyboard)
        if lower in {"🧾 histórico", "/historico"}:
            text_out, keyboard = self.app.history_screen(user_id, 0)
            return self.telegram.send(chat_id, text_out, keyboard)
        if lower in {"⭐ favoritos", "/favoritos"}:
            text_out, keyboard = self.app.favorites_screen(user_id)
            return self.telegram.send(chat_id, text_out, keyboard)
        if lower in {"🌐 redes", "/redes"}:
            return self.telegram.send(chat_id, ui.networks_text(), ui.user_keyboard(user))
        if lower in {"🔍 analisar", "/analisar"}:
            return self.telegram.send(chat_id, "🔍 Envie o contrato. A rede será detectada automaticamente.", ui.user_keyboard(user))
        if lower.startswith("/analisar "):
            parts = text.split()
            address = parts[-1]
            chain = normalize_chain(parts[1]) if len(parts) > 2 else detect_chain(address)
            if not chain:
                return self.telegram.send(chat_id, "❌ Rede não reconhecida.", ui.user_keyboard(user))
            return self.send_analysis(chat_id, user_id, chain, address)
        detected = detect_chain(text)
        if detected:
            return self.send_analysis(chat_id, user_id, detected, text)
        return self.telegram.send(chat_id, "Comando desconhecido. Use /start.", ui.user_keyboard(user))

    def voice_message(self, msg: dict, user: dict, voice_payload: dict):
        chat = msg.get("chat") or {}
        sender = msg.get("from") or {}
        chat_id = chat.get("id")
        user_id = int(sender.get("id") or chat_id)
        try:
            from daniel_ai.config import DanielSettings, ensure_directories
            cfg = ensure_directories(DanielSettings.from_env())
            if cfg.admin_only and not self.app.is_admin(user_id):
                return self.telegram.send(
                    chat_id,
                    "⛔ Daniel AI Voice está disponível somente para o administrador.",
                    ui.user_keyboard(user),
                )
            from daniel_ai.voice import DanielVoice, VoiceError, VoiceNotReadyError
            voice = DanielVoice(cfg)
            try:
                voice.validate_message(voice_payload)
            except VoiceNotReadyError as exc:
                return self.telegram.send(
                    chat_id,
                    f"🎙️ <b>Daniel AI Voice</b>\n\n{escape(str(exc))}\n\nNo Termux, execute <code>bash install_voice_termux.sh</code> e depois reinicie o CSM.",
                    ui.user_keyboard(user),
                )
            except VoiceError as exc:
                return self.telegram.send(chat_id, f"⚠️ Áudio recusado: {escape(str(exc))}", ui.user_keyboard(user))

            self.telegram.send(chat_id, "🎙️ <b>Áudio recebido.</b> Transcrevendo localmente no Android…")
            unique = str(voice_payload.get("file_unique_id") or voice_payload.get("file_id") or msg.get("message_id") or "voice")
            safe_unique = "".join(ch for ch in unique if ch.isalnum() or ch in "_-.")[:80] or "voice"
            source_path = voice.inbox_dir / f"{user_id}_{safe_unique}.ogg"
            try:
                self.telegram.download_file(
                    str(voice_payload.get("file_id")),
                    source_path,
                    max_bytes=cfg.voice_max_bytes,
                )
                transcript = voice.transcribe(source_path)
                from daniel_ai.engine import DanielAI
                answer = DanielAI(cfg).ask(transcript, user_id=user_id, source="telegram_voice")
                shown = escape(transcript[:700])
                body = f"🎙️ <b>Entendi:</b> {shown}\n\n{answer}"
                # Keep a safe margin below Telegram's message limit. Daniel's
                # full exchange is still stored by its own bounded memory path.
                if len(body) > 3900:
                    body = body[:3890] + "…"
                text_result = self.telegram.send(chat_id, body, ui.user_keyboard(user))

                # V1.2 Dual Response: text is authoritative and is always sent
                # first. Spoken output is best-effort and can never make a
                # successful Daniel response fail.
                audio_path = None
                try:
                    from daniel_ai.tts import DanielSpeech
                    speech = DanielSpeech(cfg)
                    if speech.status().ready:
                        # V1.2.4: the screen keeps the authoritative technical
                        # answer. Only the spoken copy is reorganized locally so
                        # it sounds like an analyst briefing instead of a report
                        # being read line by line.
                        spoken_answer = answer
                        try:
                            from daniel_ai.conversational_voice import ConversationalVoice
                            spoken_answer = ConversationalVoice(cfg).render(transcript, answer)
                        except Exception as narrative_exc:
                            self.app.log_warning(f"Daniel Conversational Voice isolado {type(narrative_exc).__name__}: {narrative_exc}")
                        audio_path = speech.synthesize(spoken_answer)
                        send_voice = getattr(self.telegram, "send_voice", None)
                        if callable(send_voice):
                            send_voice(chat_id, audio_path)
                except Exception as speech_exc:
                    self.app.log_warning(f"Daniel Speech isolado {type(speech_exc).__name__}: {speech_exc}")
                finally:
                    if audio_path is not None:
                        try:
                            audio_path.unlink(missing_ok=True)
                        except Exception:
                            pass
                return text_result
            finally:
                try:
                    source_path.unlink(missing_ok=True)
                except Exception:
                    pass
        except Exception as exc:
            self.app.log_warning(f"Daniel Voice isolado {type(exc).__name__}: {exc}")
            return self.telegram.send(
                chat_id,
                f"⚠️ Daniel AI Voice indisponível: {escape(str(exc))}",
                ui.user_keyboard(user),
            )

    def send_analysis(self, chat_id, user_id, chain, address):
        try:
            self.telegram.send(chat_id, "⏳ Analisando mercado...")
            text, keyboard = self.app.analyze(user_id, chain, address)
            return self.telegram.send(chat_id, text, keyboard)
        except Exception as exc:
            return self.telegram.send(
                chat_id,
                f"⚠️ Análise temporariamente indisponível: {escape(str(exc))}",
                ui.user_keyboard(self.storage.get_user(user_id)),
            )

    def verify_payment(self, chat_id, user_id):
        if not self.app.payments:
            return self.telegram.send(chat_id, "⚠️ Asaas não configurado.", ui.user_keyboard(self.storage.get_user(user_id)))
        try:
            results = self.app.payments.verify_user(user_id)
            user = self.storage.get_user(user_id)
            if user["plan"] != "free":
                from csm.experience import activated_text
                return self.telegram.send(chat_id, activated_text(user), ui.user_keyboard(user))
            if any(item["state"] == "pending" for item in results):
                return self.telegram.send(chat_id, "⏳ Pagamento ainda pendente.", ui.sales_keyboard(True))
            return self.telegram.send(chat_id, "ℹ️ Nenhum pagamento confirmado.", ui.sales_keyboard(True))
        except Exception as exc:
            return self.telegram.send(chat_id, f"⚠️ Falha na verificação: {escape(str(exc))}", ui.user_keyboard(self.storage.get_user(user_id)))
