from __future__ import annotations

import errno
import json
import os
import socket
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from csm.config import STATE_DIR


class AlreadyRunningError(RuntimeError):
    pass


@dataclass(frozen=True)
class RecoveryEvent:
    recovered: bool
    reason: str = ""
    archived: tuple[str, ...] = ()


class RuntimeGuard:
    """Session/heartbeat runtime guard for a-Shell/iOS.

    Liveness requires matching lock/session ids, a recent heartbeat and, for
    v12.0.1+ sessions, an OS-backed UDP loopback lease plus an application-level challenge/response.
    The challenge is the strongest authority on a-Shell: some embedded-Python
    crashes can return to the shell while leaving the host process (and a raw
    socket descriptor) alive. A leaked descriptor cannot answer the challenge,
    so it can no longer masquerade as a live bot. PID remains a negative-only
    compatibility fallback for older sessions.
    """

    def __init__(self, name: str = "bot", stale_after: float = 60.0):
        self.runtime_dir = STATE_DIR / "runtime" / "v10"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.lock_file = self.runtime_dir / f".{name}.lock.json"
        self.session_file = self.runtime_dir / f".{name}.session.json"
        self.stale_after = max(30.0, float(stale_after))
        self.session = uuid.uuid4().hex[:16]
        self.started_at = time.time()
        self.last_progress_at = self.started_at
        self.last_phase = "starting"
        self.sequence = 0
        self.acquired = False
        self.recovery_event = RecoveryEvent(False)
        # v12.0.1: a-Shell/iOS may keep/reuse a process identity after an
        # embedded Python command exits.  PID therefore cannot prove that the
        # previous *Python runtime* still exists.  A loopback UDP socket is an
        # OS-owned lease: when the interpreter/process dies, the descriptor is
        # released immediately and the port becomes bindable again.
        self._lease_socket: socket.socket | None = None
        self.lease_host = "127.0.0.1"
        self.lease_port = 0
        self.lease_protocol = 2

    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _atomic_write(path: Path, payload: dict[str, Any]) -> None:
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def _recent(self, data: dict[str, Any], now: float | None = None) -> bool:
        now = time.time() if now is None else now
        try:
            heartbeat = float(data.get("heartbeat_at") or 0)
        except Exception:
            return False
        return heartbeat > 0 and (now - heartbeat) <= self.stale_after

    @staticmethod
    def _running(data: dict[str, Any]) -> bool:
        return str(data.get("state") or "").lower() in {"starting", "running", "stopping"}

    @staticmethod
    def _lease_status(data: dict[str, Any]) -> bool | None:
        """Return whether the recorded runtime lease is still held.

        ``True`` means another live runtime still owns the UDP loopback port.
        ``False`` means the port can be bound now, which is definitive evidence
        that the old Python runtime released its lease.  ``None`` keeps backward
        compatibility with sessions created before v12.0.1 or platforms where
        socket probing is unavailable.
        """
        lease = data.get("lease") if isinstance(data, dict) else None
        if not isinstance(lease, dict):
            return None
        if str(lease.get("kind") or "") not in {"udp-loopback", "udp-challenge-v2"}:
            return None
        host = str(lease.get("host") or "127.0.0.1")
        try:
            port = int(lease.get("port") or 0)
        except (TypeError, ValueError):
            return None
        if not (1024 <= port <= 65535):
            return None
        probe = None
        try:
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            probe.bind((host, port))
            # Binding succeeded: nobody owns the old lease anymore.
            return False
        except OSError as exc:
            if getattr(exc, "errno", None) in {errno.EADDRINUSE, 48, 98, 10048}:
                return True
            return None
        except Exception:
            return None
        finally:
            if probe is not None:
                try:
                    probe.close()
                except Exception:
                    pass

    @staticmethod
    def _lease_info(data: dict[str, Any]) -> tuple[str, str, int, int] | None:
        lease = data.get("lease") if isinstance(data, dict) else None
        if not isinstance(lease, dict):
            return None
        kind = str(lease.get("kind") or "")
        host = str(lease.get("host") or "127.0.0.1")
        try:
            port = int(lease.get("port") or 0)
            protocol = int(lease.get("protocol") or (2 if kind == "udp-challenge-v2" else 1))
        except (TypeError, ValueError):
            return None
        if not (1024 <= port <= 65535):
            return None
        return kind, host, port, protocol

    @classmethod
    def _lease_challenge(cls, data: dict[str, Any], timeout: float = 0.35) -> bool | None:
        """Ask the recorded runtime to prove that Python code is still alive.

        A bind-only UDP lease was insufficient on a-Shell: after a native crash
        the host application can keep a leaked descriptor alive.  A live bot
        must therefore receive a nonce and echo it back with its session id.
        A leaked socket cannot do that.
        """
        info = cls._lease_info(data)
        if not info:
            return None
        kind, host, port, protocol = info
        if kind != "udp-challenge-v2" or protocol < 2:
            return None
        sid = str(data.get("session") or "")
        if not sid:
            return None
        nonce = uuid.uuid4().hex[:16]
        ping = f"CSM_PING|{sid}|{nonce}".encode("ascii", errors="ignore")
        expected = f"CSM_PONG|{sid}|{nonce}".encode("ascii", errors="ignore")
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(max(0.05, min(float(timeout), 1.0)))
            sock.sendto(ping, (host, port))
            raw, _addr = sock.recvfrom(512)
            return raw == expected
        except socket.timeout:
            return False
        except OSError:
            return None
        except Exception:
            return None
        finally:
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass

    def service_lease(self, max_packets: int = 8) -> int:
        """Answer pending local liveness challenges without threads/workers."""
        sock = self._lease_socket
        if sock is None or not self.acquired:
            return 0
        answered = 0
        for _ in range(max(1, min(int(max_packets), 32))):
            try:
                raw, addr = sock.recvfrom(512)
            except (BlockingIOError, InterruptedError):
                break
            except OSError:
                break
            try:
                text = raw.decode("ascii", errors="ignore")
                prefix, sid, nonce = text.split("|", 2)
            except Exception:
                continue
            if prefix != "CSM_PING" or sid != self.session or not nonce:
                continue
            try:
                sock.sendto(f"CSM_PONG|{sid}|{nonce}".encode("ascii"), addr)
                answered += 1
            except OSError:
                break
        return answered

    @staticmethod
    def _heartbeat_age(data: dict[str, Any], now: float | None = None) -> float:
        now = time.time() if now is None else now
        try:
            stamp = float(data.get("heartbeat_at") or 0)
        except Exception:
            return 10**9
        return max(0.0, now - stamp) if stamp > 0 else 10**9

    def _challenge_with_grace(self, data: dict[str, Any]) -> bool | None:
        """Prove a v2 owner while avoiding false recovery during short HTTPS I/O."""
        first = self._lease_challenge(data, timeout=0.35)
        if first is True or first is None:
            return first
        # A healthy bot may be inside a short sequential HTTPS call and cannot
        # service its loopback queue until that call returns. Only very fresh
        # heartbeats get a bounded grace window; stale heartbeats are recovered
        # immediately after the failed challenge.
        if self._heartbeat_age(data) > 5.0:
            return False
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            time.sleep(0.20)
            probe = self._lease_challenge(data, timeout=0.25)
            if probe is True:
                return True
            if probe is None:
                return None
        return False

    def _open_lease(self) -> None:
        """Acquire an OS-backed per-runtime lease without spawning helpers."""
        if self._lease_socket is not None:
            return
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind((self.lease_host, 0))
            sock.setblocking(False)
            self.lease_port = int(sock.getsockname()[1])
            self._lease_socket = sock
        except Exception:
            self.lease_port = 0
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass

    def _close_lease(self) -> None:
        sock, self._lease_socket = self._lease_socket, None
        self.lease_port = 0
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass

    @staticmethod
    def _pid_alive(data: dict[str, Any]) -> bool | None:
        """Return definitive PID liveness when the platform can prove it.

        a-Shell/iOS can leave a very recent heartbeat behind after a native SSL
        crash.  Heartbeat freshness alone therefore cannot prove that the owner
        process still exists.  ``kill(pid, 0)`` is used only as a *negative*
        authority: ESRCH means the process is gone and the session can be
        recovered immediately.  Permission/unsupported cases fall back to the
        existing heartbeat contract.
        """
        try:
            pid = int(data.get("pid") or 0)
        except (TypeError, ValueError):
            return None
        if pid <= 0:
            return None
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError as exc:
            if getattr(exc, "errno", None) == errno.ESRCH:
                return False
            if getattr(exc, "errno", None) == errno.EPERM:
                return True
            return None
        except Exception:
            return None

    def _healthy_pair(self, lock: dict[str, Any], session: dict[str, Any]) -> bool:
        if not lock or not session:
            return False
        sid = str(lock.get("session") or "")
        if not sid or sid != str(session.get("session") or ""):
            return False
        try:
            lock_pid = int(lock.get("pid") or 0)
            session_pid = int(session.get("pid") or 0)
        except (TypeError, ValueError):
            lock_pid = session_pid = 0
        if lock_pid and session_pid and lock_pid != session_pid:
            return False
        source = lock or session
        now = time.time()
        if not (self._running(lock) and self._running(session) and self._recent(lock, now) and self._recent(session, now)):
            return False
        info = self._lease_info(source)
        if info and info[0] == "udp-challenge-v2":
            responsive = self._lease_challenge(source, timeout=0.12)
            if responsive is True:
                return True
            # runtime_state/diagnostics should not wait several seconds. A very
            # fresh heartbeat plus an occupied port is reported provisionally
            # healthy; acquire() uses the stronger grace+challenge proof below.
            return self._heartbeat_age(source, now) <= 2.0 and self._lease_status(source) is True
        lease_alive = self._lease_status(source)
        if lease_alive is False:
            return False
        if lease_alive is None:
            pid_alive = self._pid_alive(source)
            if pid_alive is False:
                return False
        return True

    def _archive(self, path: Path, reason: str) -> str | None:
        if not path.exists():
            return None
        data = self._read_json(path)
        sid = str(data.get("session") or "unknown")[:16]
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in reason)[:32]
        target = path.with_name(f"{path.name}.stale.{stamp}.{sid}.{safe}")
        counter = 1
        while target.exists():
            target = path.with_name(f"{path.name}.stale.{stamp}.{sid}.{safe}.{counter}")
            counter += 1
        try:
            path.replace(target)
            return str(target)
        except FileNotFoundError:
            return None

    def recover_stale_if_needed(self) -> RecoveryEvent:
        lock = self._read_json(self.lock_file) if self.lock_file.exists() else {}
        session = self._read_json(self.session_file) if self.session_file.exists() else {}
        if not (lock or session or self.lock_file.exists() or self.session_file.exists()):
            self.recovery_event = RecoveryEvent(False)
            return self.recovery_event

        source = lock or session
        sid_match = bool(lock and session and str(lock.get("session") or "") == str(session.get("session") or ""))
        running_recent = bool(
            sid_match
            and self._running(lock)
            and self._running(session)
            and self._recent(lock)
            and self._recent(session)
        )

        if running_recent:
            info = self._lease_info(source)
            if info and info[0] == "udp-challenge-v2":
                owner_alive = self._challenge_with_grace(source)
                if owner_alive is True:
                    age = self._heartbeat_age(source)
                    raise AlreadyRunningError(
                        f"Já existe uma sessão saudável do bot (sessão {str(lock.get('session'))[:8]}, heartbeat há {age:.1f}s, lease responsiva)."
                    )
                if owner_alive is False:
                    reason = "lease_sem_resposta"
                else:
                    # Platform could not perform a loopback challenge. Preserve
                    # the conservative legacy contract rather than risking two
                    # active runtimes.
                    if self._pid_alive(source) is False:
                        reason = "processo_ausente"
                    else:
                        age = self._heartbeat_age(source)
                        raise AlreadyRunningError(
                            f"Sessão possivelmente ativa (sessão {str(lock.get('session'))[:8]}, heartbeat há {age:.1f}s; lease sem diagnóstico)."
                        )
            else:
                # Migration recovery for v12.0.1 bind-only leases. A native
                # a-Shell crash can leak that descriptor in the host process,
                # so a busy port cannot be trusted forever. A truly active
                # legacy runtime refreshes heartbeat frequently; after 8s it is
                # safer to recover than to strand the operator for 60s.
                lease_alive = self._lease_status(source)
                age = self._heartbeat_age(source)
                if lease_alive is True and age <= 8.0:
                    raise AlreadyRunningError(
                        f"Já existe uma sessão saudável do bot (sessão {str(lock.get('session'))[:8]}, heartbeat há {age:.1f}s; lease legada)."
                    )
                if lease_alive is False:
                    reason = "lease_liberada"
                elif lease_alive is True:
                    reason = "lease_legada_sem_resposta"
                elif self._pid_alive(source) is False:
                    reason = "processo_ausente"
                else:
                    reason = "heartbeat_expirado"
        elif lock and session and str(lock.get("session") or "") != str(session.get("session") or ""):
            reason = "sessao_inconsistente"
        elif (lock and not session) or (session and not lock):
            reason = "estado_incompleto"
        elif self._pid_alive(source) is False:
            reason = "processo_ausente"
        elif not self._running(source):
            reason = "sessao_finalizada"
        else:
            reason = "heartbeat_expirado"

        archived = tuple(
            item
            for item in (self._archive(self.lock_file, reason), self._archive(self.session_file, reason))
            if item
        )
        self.recovery_event = RecoveryEvent(bool(archived), reason, archived)
        return self.recovery_event

    def acquire(self) -> RecoveryEvent:
        self.recover_stale_if_needed()
        self._open_lease()
        self.acquired = True
        self.progress("starting")
        return self.recovery_event

    def _payload(self, state: str, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        self.sequence += 1
        payload: dict[str, Any] = {
            "pid": os.getpid(),
            "pid_authority": "negative-only",
            "session": self.session,
            "started_at": self.started_at,
            "heartbeat_at": time.time(),
            "last_progress_at": self.last_progress_at,
            "sequence": self.sequence,
            "state": state,
            "phase": self.last_phase,
            "version": "16.4.0-smart-reentry",
            "liveness_authority": "udp-challenge-v2+session+heartbeat+pid-negative-fallback",
            "lease": ({
                "kind": "udp-challenge-v2",
                "protocol": self.lease_protocol,
                "host": self.lease_host,
                "port": self.lease_port,
            } if self.lease_port else None),
        }
        if extra:
            payload.update(extra)
        return payload

    def beat(self, *, state: str = "running", extra: dict[str, Any] | None = None) -> None:
        if not self.acquired:
            return
        self.service_lease()
        payload = self._payload(state, extra)
        self._atomic_write(self.lock_file, payload)
        self._atomic_write(self.session_file, payload)

    def progress(self, phase: str, *, extra: dict[str, Any] | None = None) -> None:
        self.last_phase = str(phase or "unknown")
        self.last_progress_at = time.time()
        self.beat(state="starting" if self.last_phase == "starting" else "running", extra=extra)

    def release(self, *, state: str = "stopped") -> None:
        if not self.acquired:
            return
        try:
            if state == "stopped":
                current = self._read_json(self.lock_file)
                if current.get("session") == self.session:
                    self.lock_file.unlink(missing_ok=True)
                current_session = self._read_json(self.session_file)
                if current_session.get("session") == self.session:
                    self.session_file.unlink(missing_ok=True)
            else:
                self.lock_file.unlink(missing_ok=True)
                self._atomic_write(self.session_file, self._payload(state, {"ended_at": time.time()}))
        finally:
            self._close_lease()
            self.acquired = False

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release(state="crashed" if exc_type else "stopped")


def runtime_state(name: str = "bot", stale_after: float = 60.0) -> dict[str, Any]:
    runtime_dir = STATE_DIR / "runtime" / "v10"
    lock_file = runtime_dir / f".{name}.lock.json"
    session_file = runtime_dir / f".{name}.session.json"
    lock = RuntimeGuard._read_json(lock_file) if lock_file.exists() else {}
    session = RuntimeGuard._read_json(session_file) if session_file.exists() else {}
    guard = RuntimeGuard(name, stale_after=stale_after)
    healthy = guard._healthy_pair(lock, session)
    source = lock or session
    try:
        age = max(0.0, time.time() - float(source.get("heartbeat_at") or 0)) if source else None
    except Exception:
        age = None
    return {
        "healthy": healthy,
        "session": source.get("session") if source else None,
        "state": source.get("state") if source else "absent",
        "phase": source.get("phase") if source else None,
        "heartbeat_age_seconds": round(age, 1) if age is not None else None,
        "lock_exists": lock_file.exists(),
        "session_exists": session_file.exists(),
        "pid_diagnostic_only": source.get("pid") if source else None,
        "pid_alive": RuntimeGuard._pid_alive(source) if source else None,
        "lease_alive": RuntimeGuard._lease_status(source) if source else None,
        "lease_port": ((source.get("lease") or {}).get("port") if isinstance(source.get("lease"), dict) else None) if source else None,
        "liveness_authority": "udp-challenge-v2+session+heartbeat+pid-negative-fallback",
    }
