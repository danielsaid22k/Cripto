from __future__ import annotations

import time
from typing import Any

from csm.chains import CHAINS
from csm.config import settings
from csm.experience import opportunity_profile, signal_reasons
from csm.formatting import score_market
from csm.provider_intelligence import ProviderQualityRouter

from .market import MarketService
from .providers import ProviderGateway
from .discovery import DEXPAPRIKA_NETWORKS, MultiProviderDiscovery, DiscoverySource
from .transport import StdlibHttpTransport
from .goplus_security import (
    GOPLUS_SUPPORTED_CHAINS,
    evaluate as evaluate_goplus,
    extract_result as extract_goplus_result,
    request_spec as goplus_request_spec,
    unavailable as goplus_unavailable,
    unsupported as goplus_unsupported,
)
from .honeypot_security import (
    HONEYPOT_SUPPORTED_CHAINS,
    evaluate as evaluate_honeypot,
    request_spec as honeypot_request_spec,
    unavailable as honeypot_unavailable,
)

class ScannerEngine:
    """Sequential cooperative scanner.

    One ``step`` performs at most one external HTTPS request. There are no
    subprocesses, workers, futures or threads. Between steps control always
    returns to the Telegram event loop.
    """

    def __init__(
        self,
        transport: StdlibHttpTransport | None = None,
        providers: ProviderGateway | None = None,
        *,
        cycle_timeout: float | None = None,
        cycle_budget: float | None = None,
    ):
        request_timeout = float(settings.scan_request_timeout_seconds)
        self.transport = transport or StdlibHttpTransport(timeout=request_timeout, label="scanner")
        self.providers = providers or ProviderGateway()
        self.discovery = MultiProviderDiscovery()
        self.discovery_tier = "free"
        self._sources: list[DiscoverySource] = []
        self.active = False
        self.phase = "idle"
        self.results: list[dict[str, Any]] = []
        self.last_results: list[dict[str, Any]] = []
        self.last_stats = self._stats()
        self.last_stats["cycle_key"] = f"scan-{time.time_ns()}"
        self.last_error = ""
        self.request_timeout = request_timeout
        timeout_value = settings.scan_cycle_hard_timeout_seconds if cycle_timeout is None else cycle_timeout
        budget_value = settings.scan_cycle_budget_seconds if cycle_budget is None else cycle_budget
        self.cycle_timeout = max(30.0, float(timeout_value))
        # The automatic Premium cadence is one minute. A sequential mobile
        # scanner cannot honestly promise to analyze 200 candidates inside that
        # window, so each cycle is a bounded slice. Reaching the slice budget is
        # a normal partial completion, not a degraded/error state.
        self.cycle_budget = max(10.0, min(float(budget_value), self.cycle_timeout - 5.0))
        # ``time.monotonic()`` keeps advancing while iOS suspends a-Shell in
        # the background.  The old watchdog measured that wall-clock gap as
        # scanner work and could therefore report a false hard timeout when
        # the operator briefly opened Telegram.  The cooperative clock below
        # counts normal step-to-step time but excludes long suspension gaps.
        self.suspension_gap_seconds = max(8.0, min(20.0, self.request_timeout * 3.0))
        self.last_progress_monotonic = 0.0
        self._started = 0.0
        self._cycle_clock_last = 0.0
        self._cycle_active_seconds = 0.0
        self._cycle_suspended_seconds = 0.0
        self._source_index = 0
        self._candidate_index = 0
        self._candidates: list[tuple[str, str]] = []
        self._seen: set[tuple[str, str]] = set()
        self._allowed: set[str] = set()
        self._target = 0
        self._current_candidate: tuple[str, str] | None = None
        self._market_stage = ""
        self._market_sequence: list[str] = []
        self._market_sequence_index = 0
        self._pending_market: dict[str, Any] | None = None
        self._pending_security: dict[str, Any] | None = None
        self._candidate_rotation = 0
        self._rotation_applied = False
        # Injected by the composition root when historical evidence exists.
        # It is advisory only and never participates in approval/security gates.
        self.confidence_model = None
        # v14 evidence-based deployer reputation; advisory only.
        self.reputation_engine = None

    @staticmethod
    def _stats() -> dict[str, Any]:
        return {
            "discovered": 0,
            "analyzed": 0,
            "approved": 0,
            "rejected": 0,
            "errors": 0,
            "market_unavailable": 0,
            "normalization_errors": 0,
            "security_checked": 0,
            "security_verified": 0,
            "security_blocked": 0,
            "security_unavailable": 0,
            "security_unsupported": 0,
            "security_cache_or_api_misses": 0,
            "rejection_reasons": {},
            "chain_stats": {},
            "decisions": [],
            "decisions_truncated": 0,
            "cycle_key": "",
            "discovery_tier": "",
            "candidate_rotation_start": 0,
            "next_candidate_rotation": 0,
            "sources_ok": 0,
            "sources_failed": 0,
            "providers_used": [],
            "provider_candidates": {},
            "provider_unique_added": {},
            "provider_chain_candidates": {},
            "provider_chain_unique_added": {},
            "provider_probes": {},
            "provider_router_order": [],
            "provider_sources_ok": {},
            "provider_sources_failed": {},
            "provider_error_details": {},
            "provider_unsupported": {},
            "provider_skipped_unsupported": {},
            "provider_paused": {},
            "sources_total": 0,
            "timeouts": 0,
            "aborted": 0,
            "partial": 0,
            "cancelled": 0,
            "suspensions": 0,
            "suspended_seconds": 0.0,
            "mode": "v16.4.0-smart-reentry",
        }

    def _active_cycle_age(self, now: float | None = None) -> float:
        """Return scanner-active time without charging iOS suspension gaps.

        While a-Shell remains in the foreground, consecutive scanner steps are
        separated by only the short Telegram poll plus one bounded HTTPS
        operation.  A substantially larger gap means the embedded interpreter
        was paused or the device was suspended.  Such a gap is recorded for
        diagnostics but must not turn a healthy scan into a watchdog error.
        """
        now = time.monotonic() if now is None else float(now)
        if not self._cycle_clock_last:
            self._cycle_clock_last = now
            return self._cycle_active_seconds
        elapsed = max(0.0, now - self._cycle_clock_last)
        self._cycle_clock_last = now
        if elapsed > self.suspension_gap_seconds:
            self._cycle_suspended_seconds += elapsed
            self.last_stats["suspensions"] += 1
            self.last_stats["suspended_seconds"] = round(self._cycle_suspended_seconds, 2)
            return self._cycle_active_seconds
        self._cycle_active_seconds += elapsed
        return self._cycle_active_seconds

    def _progress(self, phase: str | None = None) -> None:
        if phase is not None:
            self.phase = phase
        self.last_progress_monotonic = time.monotonic()

    def start(self, limit=None, chains=None, *, tier: str = "free") -> bool:
        if self.active:
            return False
        self.active = True
        self.phase = "discover"
        self.results = []
        self.last_stats = self._stats()
        self.last_error = ""
        self._started = time.monotonic()
        self._cycle_clock_last = self._started
        self._cycle_active_seconds = 0.0
        self._cycle_suspended_seconds = 0.0
        self.last_progress_monotonic = self._started
        self._source_index = 0
        self._candidate_index = 0
        self._candidates = []
        self._rotation_applied = False
        self.last_stats["candidate_rotation_start"] = int(self._candidate_rotation)
        self._seen = set()
        self._allowed = set(chains or settings.scan_chains)
        self.discovery_tier = str(tier or "free").lower()
        self.last_stats["discovery_tier"] = self.discovery_tier
        self._sources = self.discovery.sources(self.discovery_tier, self._allowed)
        self.last_stats["sources_total"] = len(self._sources)
        self.last_stats["provider_router_order"] = [source.name for source in self._sources]
        self.last_stats["provider_skipped_unsupported"] = {
            provider: list(rows)
            for provider, rows in self.discovery.last_skipped_unsupported.items()
        }
        self.last_stats["provider_paused"] = dict(self.discovery.last_paused_providers)
        self._target = min(max(int(limit or settings.scan_limit), 10), settings.scan_max_candidates)
        self._current_candidate = None
        self._market_stage = ""
        self._market_sequence = []
        self._market_sequence_index = 0
        self._pending_market = None
        self._pending_security = None
        return True

    def _finish(self, *, note: str = "", partial: bool = False) -> list[dict[str, Any]]:
        if partial:
            self.last_stats["partial"] += 1
            self.last_error = str(note)[:300]
        self.last_stats["discovered"] = max(self.last_stats.get("discovered", 0), len(self._candidates))
        if self._candidates:
            advance = int(self.last_stats.get("analyzed", 0) or 0)
            if partial and advance <= 0:
                advance = 1
            if advance > 0:
                self._candidate_rotation = (self._candidate_rotation + advance) % len(self._candidates)
        self.last_stats["next_candidate_rotation"] = int(self._candidate_rotation)
        # V14.5 observability: persist cooperative scanner work time without
        # charging iOS suspension gaps.
        try:
            self.last_stats["active_seconds"] = round(float(self._active_cycle_age()), 3)
        except Exception:
            self.last_stats["active_seconds"] = round(float(self._cycle_active_seconds or 0.0), 3)
        self.last_results = [dict(row) for row in self.results]
        self.active = False
        self.phase = "idle"
        self._progress("idle")
        return [dict(row) for row in self.last_results]

    def _apply_candidate_rotation(self) -> None:
        """Advance through a stable discovery list across bounded scan slices."""
        if self._rotation_applied or not self._candidates:
            return
        start = int(self._candidate_rotation) % len(self._candidates)
        self.last_stats["candidate_rotation_start"] = start
        if start:
            self._candidates = self._candidates[start:] + self._candidates[:start]
        self._rotation_applied = True

    def abort(self, reason: str) -> list[dict[str, Any]]:
        self.last_error = str(reason)[:300]
        self.last_stats["aborted"] += 1
        self.last_stats["errors"] += 1
        return self._finish()

    def cancel(self, reason: str = "shutdown") -> list[dict[str, Any]]:
        """Stop a cooperative cycle without turning shutdown into an error."""
        if not self.active:
            return [dict(row) for row in self.last_results]
        self.last_error = str(reason)[:300]
        self.last_stats["cancelled"] += 1
        return self._finish()

    @staticmethod
    def _filter_rejection_reason(market: dict[str, Any]) -> str | None:
        liq = float(market.get("liquidity") or 0)
        vol = float(market.get("volume24h") or 0)
        cap = float(market.get("marketcap") or 0)
        change = float(market.get("change24h") or 0)
        buys = int(market.get("buys24h") or 0)
        sells = int(market.get("sells24h") or 0)
        age = market.get("age_days")
        if liq < settings.scan_min_liquidity:
            return "liquidity_below_min"
        if settings.scan_max_liquidity and liq > settings.scan_max_liquidity:
            return "liquidity_above_max"
        if vol < settings.scan_min_volume24h:
            return "volume_below_min"
        if settings.scan_max_volume24h and vol > settings.scan_max_volume24h:
            return "volume_above_max"
        if settings.scan_min_marketcap and cap < settings.scan_min_marketcap:
            return "marketcap_below_min"
        if settings.scan_max_marketcap and cap > settings.scan_max_marketcap:
            return "marketcap_above_max"
        if age is not None and float(age) < settings.scan_min_age_days:
            return "age_below_min"
        if age is not None and settings.scan_max_age_days and float(age) > settings.scan_max_age_days:
            return "age_above_max"
        if change < settings.scan_min_change24h:
            return "change_below_min"
        if settings.scan_max_change24h and change > settings.scan_max_change24h:
            return "change_above_max"
        if buys + sells < settings.scan_min_txns24h:
            return "txns_below_min"
        if sells > 0 and buys / sells < settings.scan_min_buy_sell_ratio:
            return "buy_sell_ratio_below_min"
        return None

    @staticmethod
    def _passes(market: dict[str, Any]) -> bool:
        return ScannerEngine._filter_rejection_reason(market) is None

    def _provider_request(
        self,
        name: str,
        url: str,
        *,
        params=None,
        cache_key: str | None = None,
        cache_ttl=30,
        stale_ttl=900,
        force=False,
        headers=None,
    ):
        transport = self.transport.clone(label=f"scanner:{name}", headers=headers) if headers else self.transport
        return self.providers.fetch(
            name,
            lambda: transport.get_json(url, params=params, timeout=self.request_timeout),
            cache_key=cache_key or url,
            cache_ttl=cache_ttl,
            stale_ttl=stale_ttl,
            force=force,
        )

    def _chain_bucket(self, chain: str) -> dict[str, Any]:
        chain = str(chain or "unknown").strip().lower() or "unknown"
        rows = self.last_stats.setdefault("chain_stats", {})
        if chain not in rows:
            rows[chain] = {"analyzed": 0, "approved": 0, "rejected": 0, "unavailable": 0, "rejection_reasons": {}}
        return rows[chain]

    def _record_analyzed(self, market: dict[str, Any]) -> None:
        chain = str(market.get("chain") or (self._current_candidate or ("unknown", ""))[0]).strip().lower()
        self._chain_bucket(chain)["analyzed"] += 1

    def _record_decision(self, market: dict[str, Any] | None, decision: str, reason: str = "") -> None:
        if not bool(getattr(settings, "scanner_intelligence_enabled", True)):
            return
        source = dict(market or {})
        chain = str(source.get("chain") or (self._current_candidate or ("unknown", ""))[0]).strip().lower() or "unknown"
        address = str(source.get("address") or (self._current_candidate or ("", ""))[1]).strip()
        bucket = self._chain_bucket(chain)
        decision = str(decision or "UNKNOWN").upper()
        if decision == "APPROVED":
            bucket["approved"] += 1
        elif decision == "REJECTED":
            bucket["rejected"] += 1
            by_reason = bucket.setdefault("rejection_reasons", {})
            by_reason[reason] = int(by_reason.get(reason, 0)) + 1
        elif decision == "UNAVAILABLE":
            bucket["unavailable"] += 1

        try:
            analytic_score = int(score_market(source)) if source else 0
        except Exception:
            analytic_score = 0
        row = {
            "chain": chain, "address": address,
            "symbol": str(source.get("symbol") or "")[:80],
            "name": str(source.get("name") or "")[:160],
            "decision": decision, "reason": str(reason or "")[:80],
            "analytic_score": analytic_score,
            "final_score": int(source.get("final_score") or source.get("opportunity_score") or source.get("score") or 0),
            "liquidity": float(source.get("liquidity") or 0),
            "volume24h": float(source.get("volume24h") or 0),
            "marketcap": float(source.get("marketcap") or 0),
            "change24h": float(source.get("change24h") or 0),
            "buys24h": int(source.get("buys24h") or 0),
            "sells24h": int(source.get("sells24h") or 0),
            "source": str(source.get("source") or "")[:100],
        }
        rows = self.last_stats.setdefault("decisions", [])
        cap = max(10, int(getattr(settings, "scanner_intelligence_max_decisions_per_cycle", 1000)))
        if len(rows) < cap:
            rows.append(row)
        else:
            self.last_stats["decisions_truncated"] = int(self.last_stats.get("decisions_truncated", 0)) + 1

    def _record_rejection(self, reason: str, market: dict[str, Any] | None = None) -> None:
        self.last_stats["rejected"] += 1
        reasons = self.last_stats.setdefault("rejection_reasons", {})
        reasons[reason] = int(reasons.get(reason, 0)) + 1
        self._record_decision(market or self._pending_market, "REJECTED", reason)

    def _clear_candidate(self) -> None:
        self._current_candidate = None
        self._pending_market = None
        self._pending_security = None
        self._market_stage = ""
        self._progress("analyze")

    def _finalize_approved_market(self, market: dict[str, Any], security: dict[str, Any] | None = None) -> None:
        item = dict(market)
        item["score"] = score_market(item)
        item.update(opportunity_profile(item))
        base_score = int(item.get("opportunity_score") or item.get("score") or 0)
        item["market_opportunity_score"] = base_score
        if security:
            item.update(security)
            sec_score = security.get("security_score")
            if not isinstance(sec_score, (int, float)):
                sec_score = security.get("goplus_score")
            if isinstance(sec_score, (int, float)):
                weight = max(0, min(100, int(settings.goplus_score_weight_pct)))
                blended = round((base_score * (100 - weight) + float(sec_score) * weight) / 100)
                # Security can penalize a market score, but does not inflate it.
                item["final_score"] = max(0, min(base_score, int(blended)))
            else:
                item["final_score"] = base_score
        else:
            item["final_score"] = base_score

        # Explainability is stored with the immutable signal event.  Historical
        # confidence is separate from final_score so past performance can never
        # override present-day market filters or GoPlus safety blocks.
        item["approval_reasons"] = signal_reasons(item, 6)
        item["csm_confidence_score"] = int(item["final_score"])
        if self.confidence_model is not None and settings.adaptive_confidence_enabled:
            try:
                estimate = self.confidence_model.estimate(item)
                item["historical_sample_size"] = int(estimate.samples)
                item["historical_scope"] = estimate.scope
                if estimate.available and estimate.score is not None:
                    item["historical_probability_score"] = int(estimate.score)
                    item["historical_tp1_rate_pct"] = estimate.tp1_rate_pct
                    # Evidence-aware blending: history starts with a small
                    # influence at the minimum sample and grows gradually,
                    # capped at 30%. It can change only CSM Confidence; the
                    # safety/market final_score remains untouched.
                    min_n = max(5, int(settings.adaptive_min_samples))
                    progress = max(0.0, min(1.0, (int(estimate.samples) - min_n) / max(1, 200 - min_n)))
                    history_weight = 0.15 + (0.15 * progress)
                    current_weight = 1.0 - history_weight
                    item["historical_weight_pct"] = round(history_weight * 100, 1)
                    item["current_signal_weight_pct"] = round(current_weight * 100, 1)
                    item["csm_confidence_score"] = max(0, min(100, round(int(item["final_score"]) * current_weight + int(estimate.score) * history_weight)))
            except Exception:
                # Analytics must never block scanning.
                pass
        if self.reputation_engine is not None and settings.reputation_enabled:
            try:
                self.reputation_engine.enrich_candidate(
                    item,
                    min_confidence=int(settings.reputation_min_confidence),
                    max_penalty=int(settings.reputation_csm_max_penalty),
                )
            except Exception:
                # Reputation is advisory and must never block a signal.
                pass
        self.results.append(item)
        self.last_stats["approved"] += 1
        self._record_decision(item, "APPROVED")
        self._clear_candidate()

    def _accept_market(self, market: dict[str, Any]) -> None:
        self.last_stats["analyzed"] += 1
        self._record_analyzed(market)
        rejection_reason = self._filter_rejection_reason(market)
        if rejection_reason is not None:
            self._record_rejection(rejection_reason, market)
            self._clear_candidate()
            return

        chain = str(market.get("chain") or (self._current_candidate or ("", ""))[0]).strip().lower()
        if not settings.goplus_enabled:
            self._finalize_approved_market(market)
            return
        if chain not in GOPLUS_SUPPORTED_CHAINS:
            self.last_stats["security_unsupported"] += 1
            self._finalize_approved_market(market, goplus_unsupported(chain))
            return

        # Security is one additional cooperative HTTPS step. This preserves the
        # a-Shell contract: no threads and at most one network call per step.
        self._pending_market = dict(market)
        self._market_stage = "goplus"
        self._progress("analyze")

    def _start_honeypot_fallback(self, chain: str, market: dict[str, Any], goplus_verdict: dict[str, Any]) -> bool:
        """Schedule one keyless EVM security fallback step when GoPlus misses."""
        if not bool(getattr(settings, "honeypot_enabled", True)) or chain not in HONEYPOT_SUPPORTED_CHAINS:
            return False
        self._pending_market = dict(market)
        self._pending_security = dict(goplus_verdict)
        self._market_stage = "honeypot"
        self._progress("analyze")
        return True

    def _honeypot_step(self, chain: str, address: str) -> None:
        market = dict(self._pending_market or {})
        base_security = dict(self._pending_security or {})
        if not market:
            self._clear_candidate()
            return
        spec = honeypot_request_spec(chain, address, settings.honeypot_base_url, settings.honeypot_api_key)
        if spec is None:
            self._finalize_approved_market(market, {**base_security, **honeypot_unavailable(chain, "rede não suportada")})
            return
        url, params, headers = spec
        payload = self._provider_request(
            "Honeypot.is security", url, params=params, headers=headers or None,
            cache_key=f"honeypot:{chain}:{address.lower()}",
            cache_ttl=settings.honeypot_cache_ttl, stale_ttl=settings.honeypot_stale_ttl, force=False,
        )
        self.last_stats["honeypot_checked"] = int(self.last_stats.get("honeypot_checked", 0)) + 1
        if payload is None:
            state = self.providers.state("Honeypot.is security")
            reason = self._compact_provider_error(state.last_error)
            self.last_stats["honeypot_unavailable"] = int(self.last_stats.get("honeypot_unavailable", 0)) + 1
            self._finalize_approved_market(market, {**base_security, **honeypot_unavailable(chain, reason)})
            return
        verdict = evaluate_honeypot(
            chain, payload,
            max_buy_tax_pct=settings.honeypot_max_buy_tax_pct,
            max_sell_tax_pct=settings.honeypot_max_sell_tax_pct,
        )
        self.last_stats["honeypot_verified"] = int(self.last_stats.get("honeypot_verified", 0)) + 1
        enforce = bool(getattr(settings, "honeypot_enforce_blocks", False))
        # Advisory is the regression-zero default: retain Honeypot telemetry but
        # do not let it alter final_score or block a live signal until explicitly enabled.
        if not enforce:
            verdict.pop("security_score", None)
        combined = {**base_security, **verdict}
        if enforce:
            if verdict.get("honeypot_detected"):
                self.last_stats["honeypot_blocked"] = int(self.last_stats.get("honeypot_blocked", 0)) + 1
                self._record_rejection("honeypot_detected", market)
                self._clear_candidate()
                return
            buy_tax = verdict.get("honeypot_buy_tax_pct")
            sell_tax = verdict.get("honeypot_sell_tax_pct")
            if (isinstance(buy_tax, (int, float)) and float(buy_tax) >= settings.honeypot_max_buy_tax_pct) or (isinstance(sell_tax, (int, float)) and float(sell_tax) >= settings.honeypot_max_sell_tax_pct):
                self.last_stats["honeypot_blocked"] = int(self.last_stats.get("honeypot_blocked", 0)) + 1
                self._record_rejection("honeypot_tax_above_max", market)
                self._clear_candidate()
                return
        self._finalize_approved_market(market, combined)

    def _goplus_step(self, chain: str, address: str) -> None:
        market = dict(self._pending_market or {})
        if not market:
            self._clear_candidate()
            return
        spec = goplus_request_spec(chain, address, settings.goplus_access_token)
        if spec is None:
            self.last_stats["security_unsupported"] += 1
            self._finalize_approved_market(market, goplus_unsupported(chain))
            return
        url, params, headers = spec
        payload = self._provider_request(
            "GoPlus security",
            url,
            params=params,
            headers=headers or None,
            cache_key=f"goplus:{chain}:{address.lower()}",
            cache_ttl=settings.goplus_cache_ttl,
            stale_ttl=settings.goplus_stale_ttl,
            force=False,
        )
        self.last_stats["security_checked"] += 1
        if payload is None:
            state = self.providers.state("GoPlus security")
            reason = self._compact_provider_error(state.last_error)
            self.last_stats["security_unavailable"] += 1
            verdict = goplus_unavailable(chain, reason)
            if settings.goplus_fail_closed:
                self.last_stats["security_blocked"] += 1
                self._record_rejection("goplus_unavailable")
                self._clear_candidate()
            elif not self._start_honeypot_fallback(chain, market, verdict):
                self._finalize_approved_market(market, verdict)
            return

        data = extract_goplus_result(payload, address)
        if not data:
            self.last_stats["security_cache_or_api_misses"] += 1
            verdict = goplus_unavailable(chain, "sem dados GoPlus para este token")
            if settings.goplus_fail_closed:
                self.last_stats["security_blocked"] += 1
                self._record_rejection("goplus_no_data")
                self._clear_candidate()
            elif not self._start_honeypot_fallback(chain, market, verdict):
                self._finalize_approved_market(market, verdict)
            return

        verdict = evaluate_goplus(
            chain,
            data,
            max_buy_tax_pct=settings.goplus_max_buy_tax_pct,
            max_sell_tax_pct=settings.goplus_max_sell_tax_pct,
        )
        self.last_stats["security_verified"] += 1
        security_score = verdict.get("goplus_score")
        if verdict.get("goplus_blocked"):
            self.last_stats["security_blocked"] += 1
            self._record_rejection("goplus_critical_risk")
            self._clear_candidate()
            return
        if isinstance(security_score, (int, float)) and int(security_score) < int(settings.goplus_min_security_score):
            self.last_stats["security_blocked"] += 1
            self._record_rejection("goplus_score_below_min")
            self._clear_candidate()
            return
        self._finalize_approved_market(market, verdict)

    @staticmethod
    def _compact_provider_error(raw: str) -> str:
        """Return a short operator-facing cause without credentials or URLs."""
        text = str(raw or "falha temporária").strip()
        lowered = text.lower()
        import re
        if "compute units usage limit exceeded" in lowered or ("compute unit" in lowered and "limit" in lowered and ("exceed" in lowered or "reached" in lowered)):
            return "CU esgotada"
        match = re.search(r"http\s+(\d{3})", text, flags=re.I)
        if match:
            status = int(match.group(1))
            if status == 401:
                return "HTTP 401 (chave ausente/inválida)"
            if status == 403:
                return "HTTP 403 (acesso/whitelist)"
            return f"HTTP {status}"
        if "timeout" in lowered:
            return "timeout"
        if "tls" in lowered or "ssl" in lowered:
            return "TLS"
        if "json" in lowered:
            return "JSON inválido"
        if "rede ocupada" in lowered or "networkbusy" in lowered:
            return "rede ocupada"
        if "dns" in lowered or "name or service" in lowered or "gaierror" in lowered:
            return "DNS"
        if "https" in lowered or "network" in lowered or "rede" in lowered:
            return "erro de rede"
        # Never surface raw provider payloads/URLs or long exception text.
        kind = text.split(":", 1)[0].strip()
        return kind[:40] if kind else "falha temporária"

    def _discover_step(self) -> None:
        if self._source_index >= len(self._sources) or len(self._candidates) >= self._target:
            self.last_stats["discovered"] = len(self._candidates)
            self._apply_candidate_rotation()
            self._progress("analyze")
            return
        source = self._sources[self._source_index]
        self._source_index += 1
        payload = self._provider_request(
            source.name, source.url, params=source.params, headers=source.headers,
            cache_key=f"discover:{source.provider}:{source.chain or 'all'}:{source.url}",
            cache_ttl=source.cache_ttl,
        )
        if payload is None:
            state = self.providers.state(source.name)
            reason = self._compact_provider_error(state.last_error)
            chain_label = str(source.chain or "all")

            if bool(getattr(source, "probe_only", False)):
                kind = str(getattr(source, "probe_kind", "") or "probe")
                # Probe failures never count as scanner delivery/filter errors and
                # never create candidates. They only maintain the provider circuit.
                if source.provider == "birdeye" and reason == "CU esgotada":
                    cooldown = int(settings.birdeye_quota_cooldown_seconds)
                    self.discovery.pause_provider("birdeye", reason="cota CU esgotada", ttl_seconds=cooldown)
                elif source.provider == "birdeye" and (reason.startswith("HTTP 401") or reason.startswith("HTTP 403")):
                    self.discovery.pause_provider("birdeye", reason=reason, ttl_seconds=300)
                elif reason == "HTTP 429":
                    retry_seconds = max(60, int(max(0.0, float(state.next_retry or 0.0) - time.time())))
                    self.discovery.pause_provider(source.provider, reason=f"HTTP 429 • cooldown {retry_seconds}s", ttl_seconds=retry_seconds)
                elif source.provider == "birdeye" and kind == "credential":
                    self.discovery.pause_provider("birdeye", reason=f"credential probe: {reason}", ttl_seconds=300)
                self.discovery.mark_probe_result(source.provider, kind, ok=False, detail=reason)
                probes = self.last_stats.setdefault("provider_probes", {})
                probes[source.provider] = f"{kind}:FAILED:{reason}"[:120]
                self._progress("discover")
                return

            # V16.1: a provider-wide HTTP 429 opens a discovery cooldown.
            # Remove the remaining routes for that provider from this same
            # cycle so DexScreener/Birdeye/CoinGecko can take over immediately.
            if reason == "HTTP 429" and source.provider in {"geckoterminal", "dexscreener", "birdeye", "coingecko", "dexpaprika"}:
                retry_seconds = max(300, int(max(0.0, float(state.next_retry or 0.0) - time.time())))
                pause_reason = f"HTTP 429 • cooldown {retry_seconds}s"
                self.discovery.pause_provider(source.provider, reason=pause_reason, ttl_seconds=retry_seconds)
                self.last_stats.setdefault("provider_paused", {})[source.provider] = pause_reason
                self._sources = self._sources[:self._source_index] + [
                    item for item in self._sources[self._source_index:] if item.provider != source.provider
                ]

            # Birdeye can encode account Compute Unit exhaustion as HTTP 400.
            # It is provider/account-wide, not a bad chain request and not an
            # authentication failure. Pause Birdeye for 30 minutes and remove
            # remaining Birdeye routes from the current cycle; public providers
            # continue normally.
            if source.provider == "birdeye" and reason == "CU esgotada":
                cooldown = int(settings.birdeye_quota_cooldown_seconds)
                pause_reason = f"cota CU esgotada • cooldown {cooldown // 3600}h"
                self.discovery.pause_provider("birdeye", reason="cota CU esgotada", ttl_seconds=cooldown)
                self.last_stats.setdefault("provider_paused", {})["birdeye"] = pause_reason
                self.last_stats["birdeye_quota_exhausted"] = 1
                self._sources = self._sources[:self._source_index] + [
                    item for item in self._sources[self._source_index:] if item.provider != "birdeye"
                ]

            # DexPaprika may expose quota/credit exhaustion as HTTP 402. Rate limiting
            # via HTTP 429 is already handled above. Pause only this provider
            # and keep every existing source active; retry hours later.
            if source.provider == "dexpaprika" and reason == "HTTP 402":
                cooldown = int(settings.dexpaprika_quota_cooldown_seconds)
                pause_reason = f"cota DexPaprika esgotada • cooldown {cooldown // 3600}h"
                self.discovery.pause_provider("dexpaprika", reason="cota/créditos esgotados", ttl_seconds=cooldown)
                self.last_stats.setdefault("provider_paused", {})["dexpaprika"] = pause_reason
                self.last_stats["dexpaprika_quota_exhausted"] = 1
                self._sources = self._sources[:self._source_index] + [
                    item for item in self._sources[self._source_index:] if item.provider != "dexpaprika"
                ]

            # Authentication/access failures are provider-wide, not chain
            # failures. Pause Birdeye briefly so an invalid/expired key does not
            # burn one failed request per chain every scanner cycle. Other
            # discovery providers continue normally.
            if source.provider == "birdeye" and (reason.startswith("HTTP 401") or reason.startswith("HTTP 403")):
                self.discovery.pause_provider("birdeye", reason=reason, ttl_seconds=300)
                self.last_stats.setdefault("provider_paused", {})["birdeye"] = reason + " • revalidação ≤5min"
                # The current source list was built before this auth failure.
                # Remove the remaining Birdeye routes from this same cycle so
                # we do not repeat the same rejected key on another chain.
                self._sources = self._sources[:self._source_index] + [
                    item for item in self._sources[self._source_index:] if item.provider != "birdeye"
                ]

            # A chain-specific 404 is a capability mismatch, not a scanner
            # failure. Quarantine only provider+chain for 5 minutes; other providers
            # continue scanning the same chain normally.
            if reason == "HTTP 404" and source.chain and source.provider in {"coingecko", "birdeye", "dexpaprika"}:
                self.discovery.mark_temporarily_unsupported(
                    source.provider, source.chain, reason=reason, ttl_seconds=300
                )
                unsupported = self.last_stats.setdefault("provider_unsupported", {})
                rows = list(unsupported.get(source.provider) or [])
                entry = f"{chain_label}: não suportada (revalidação ≤5min)"
                if entry not in rows:
                    rows.append(entry)
                unsupported[source.provider] = rows[-5:]
                self._progress("discover")
                return

            self.last_stats["sources_failed"] += 1
            failed = self.last_stats.setdefault("provider_sources_failed", {})
            failed[source.provider] = int(failed.get(source.provider, 0)) + 1
            details = self.last_stats.setdefault("provider_error_details", {})
            current = list(details.get(source.provider) or [])
            entry = f"{chain_label}: {reason}"
            if entry not in current:
                current.append(entry)
            details[source.provider] = current[-3:]
            self.last_stats["errors"] += 1
            self._progress("discover")
            return
        if bool(getattr(source, "probe_only", False)):
            kind = str(getattr(source, "probe_kind", "") or "probe")
            self.discovery.mark_probe_result(source.provider, kind, ok=True, detail="probe OK")
            self.providers.clear_family_circuit(source.provider)
            probes = self.last_stats.setdefault("provider_probes", {})
            probes[source.provider] = f"{kind}:OK"
            self._progress("discover")
            return

        try:
            rows = source.parser(payload)
            chain_counts = self.last_stats.setdefault("provider_chain_candidates", {}).setdefault(source.provider, {})
            for row_chain, _row_address in rows:
                row_chain = str(row_chain or "unknown").lower()
                chain_counts[row_chain] = int(chain_counts.get(row_chain, 0)) + 1
            self.last_stats["sources_ok"] += 1
            ok = self.last_stats.setdefault("provider_sources_ok", {})
            ok[source.provider] = int(ok.get(source.provider, 0)) + 1
            candidates = self.last_stats.setdefault("provider_candidates", {})
            candidates[source.provider] = int(candidates.get(source.provider, 0)) + len(rows)
            used = self.last_stats.setdefault("providers_used", [])
            if source.provider not in used:
                used.append(source.provider)
            added = 0
            added_by_chain = self.last_stats.setdefault("provider_chain_unique_added", {}).setdefault(source.provider, {})
            for chain, address in rows:
                key = (chain, address)
                if chain in self._allowed and key not in self._seen:
                    self._seen.add(key)
                    self._candidates.append(key)
                    added += 1
                    chain_key = str(chain or "unknown").lower()
                    added_by_chain[chain_key] = int(added_by_chain.get(chain_key, 0)) + 1
                    if len(self._candidates) >= self._target:
                        break
            unique = self.last_stats.setdefault("provider_unique_added", {})
            unique[source.provider] = int(unique.get(source.provider, 0)) + added
        except Exception as exc:
            self.last_stats["sources_failed"] += 1
            failed = self.last_stats.setdefault("provider_sources_failed", {})
            failed[source.provider] = int(failed.get(source.provider, 0)) + 1
            self.last_stats["errors"] += 1
            self.last_error = f"parser {source.name}: {type(exc).__name__}: {exc}"[:300]
        self._progress("discover")

    def _market_sequence_for_chain(self, chain: str) -> list[str]:
        mapping = {"geckoterminal": "gecko", "dexscreener": "dex", "dexpaprika": "dexpaprika"}
        order = ProviderQualityRouter().market_order(chain)
        stages = [mapping[name] for name in order if name in mapping]
        return stages or ["gecko", "dex", "dexpaprika"]

    def _advance_market_stage(self) -> bool:
        self._market_sequence_index += 1
        if self._market_sequence_index < len(self._market_sequence):
            self._market_stage = self._market_sequence[self._market_sequence_index]
            self._progress("analyze")
            return True
        self._market_stage = ""
        return False

    def _market_unavailable(self, chain: str, address: str) -> None:
        self.last_stats["market_unavailable"] += 1
        self._record_decision({"chain": chain, "address": address}, "UNAVAILABLE", "market_unavailable")
        self._clear_candidate()

    def _analyze_step(self) -> None:
        if self._current_candidate is None:
            if self._candidate_index >= len(self._candidates):
                self._progress("done")
                return
            self._current_candidate = self._candidates[self._candidate_index]
            self._candidate_index += 1
            chain = self._current_candidate[0]
            self._market_sequence = self._market_sequence_for_chain(chain)
            self._market_sequence_index = 0
            self._market_stage = self._market_sequence[0]
            self._progress("analyze")
            return

        chain, address = self._current_candidate
        if self._market_stage == "goplus":
            self._goplus_step(chain, address)
            return
        if self._market_stage == "honeypot":
            self._honeypot_step(chain, address)
            return
        if self._market_stage == "gecko":
            gecko = (CHAINS.get(chain) or {}).get("gecko")
            if not gecko:
                if not self._advance_market_stage():
                    self._market_unavailable(chain, address)
                return
            payload = self._provider_request(
                "GeckoTerminal market",
                f"https://api.geckoterminal.com/api/v2/networks/{gecko}/tokens/{address}/pools",
                params={"page": "1", "include": "base_token,quote_token,dex"},
                cache_key=f"gecko:{chain}:{address}",
                force=True,
                cache_ttl=0,
            )
            if isinstance(payload, dict) and payload.get("data"):
                try:
                    self._accept_market(
                        MarketService.normalize_gecko(
                            payload["data"][0],
                            chain,
                            address,
                            included=payload.get("included") or [],
                        )
                    )
                    return
                except Exception as exc:
                    self.last_stats["normalization_errors"] += 1
                    self.last_error = f"Gecko normalize: {type(exc).__name__}: {exc}"[:300]
            if not self._advance_market_stage():
                self._market_unavailable(chain, address)
            return

        if self._market_stage == "dex":
            payload = self._provider_request(
                "DexScreener market",
                f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}",
                cache_key=f"dex:{chain}:{address}",
                force=True,
                cache_ttl=0,
            )
            if isinstance(payload, list) and payload:
                try:
                    best = max(payload, key=lambda p: float((p.get("liquidity") or {}).get("usd") or 0))
                    self._accept_market(MarketService.normalize_dex(best))
                    return
                except Exception as exc:
                    self.last_stats["normalization_errors"] += 1
                    self.last_error = f"Dex normalize: {type(exc).__name__}: {exc}"[:300]
            if self._advance_market_stage():
                return
            self._market_unavailable(chain, address)
            return

        if self._market_stage == "dexpaprika":
            if not (settings.dexpaprika_enabled and settings.dexpaprika_market_fallback and chain in DEXPAPRIKA_NETWORKS and settings.dexpaprika_base_url.startswith("https://")):
                if not self._advance_market_stage():
                    self._market_unavailable(chain, address)
                return
            headers = {"Authorization": settings.dexpaprika_api_key} if settings.dexpaprika_api_key else None
            payload = self._provider_request(
                "DexPaprika market",
                f"{settings.dexpaprika_base_url}/networks/{DEXPAPRIKA_NETWORKS[chain]}/tokens/{address}",
                cache_key=f"dexpaprika:{chain}:{address}",
                headers=headers,
                force=True,
                cache_ttl=0,
            )
            if isinstance(payload, dict) and (payload.get("summary") or payload.get("price_usd")):
                try:
                    self._accept_market(MarketService.normalize_dexpaprika(payload, chain, address))
                    return
                except Exception as exc:
                    self.last_stats["normalization_errors"] += 1
                    self.last_error = f"DexPaprika normalize: {type(exc).__name__}: {exc}"[:300]
            if self._advance_market_stage():
                return
            self._market_unavailable(chain, address)
            return

    def step(self) -> list[dict[str, Any]] | None:
        if not self.active:
            return None
        active_age = self._active_cycle_age()
        if active_age > self.cycle_timeout:
            self.last_stats["timeouts"] += 1
            return self.abort("watchdog: tempo ativo máximo do ciclo excedido")
        if active_age >= self.cycle_budget:
            return self._finish(
                note=f"orçamento cooperativo de {self.cycle_budget:.0f}s atingido",
                partial=True,
            )
        if self.phase == "discover":
            self._discover_step()
            return None
        if self.phase == "analyze":
            self._analyze_step()
            return None
        if self.phase == "done":
            return self._finish()
        return None

    def health_snapshot(self) -> dict[str, Any]:
        now = time.monotonic()
        return {
            "active": self.active,
            "phase": self.phase,
            "last_progress_age_seconds": round(max(0.0, now - self.last_progress_monotonic), 2)
            if self.last_progress_monotonic
            else None,
            "cycle_age_seconds": round(max(0.0, now - self._started), 2) if self.active else 0.0,
            "cycle_active_seconds": round(self._cycle_active_seconds, 2) if self.active else 0.0,
            "cycle_suspended_seconds": round(self._cycle_suspended_seconds, 2),
            "discovery_tier": self.discovery_tier,
            "discovery_sources": [source.name for source in self._sources],
            "last_error": self.last_error,
            "stats": dict(self.last_stats),
        }

    def run_sync(self, limit=None, chains=None, *, wall_timeout: float = 180.0, tier: str = "free") -> list[dict[str, Any]]:
        if not self.start(limit, chains, tier=tier):
            return [dict(row) for row in self.last_results]
        deadline = time.monotonic() + max(20.0, float(wall_timeout))
        result = None
        while result is None and time.monotonic() < deadline:
            result = self.step()
        if result is None:
            return self.abort("run_sync excedeu wall_timeout")
        return result
