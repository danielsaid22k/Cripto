from __future__ import annotations

import time
from collections import deque
from typing import Any

from csm.config import settings
from csm.experience import plan_group


class Scheduler:
    """Single-threaded scheduler for scanner and cache-only monitoring."""

    def __init__(self, app):
        self.app = app
        self.scanner = app.scanner
        self.next_cycle = {"premium": 0.0, "plus": 0.0, "free": 0.0}
        self.pending_groups: list[tuple[str, int]] = []
        self.manual_scan_users: set[int] = set()
        self.position_queue = deque()
        self.performance_queue = deque()
        self.shadow_performance_queue = deque()
        self.onchain_queue = deque()
        self.payment_queue = deque()
        self.last_position_reload = 0.0
        self.last_performance_reload = 0.0
        self.last_shadow_performance_poll = 0.0
        self.last_onchain_reload = 0.0
        self.last_reputation_refresh = 0.0
        self.last_observability_heartbeat = 0.0
        self.last_distribution_step = 0.0
        self.last_signal_outcome_learning = 0.0
        self.last_learning_step = 0.0
        self._daniel_learner = None
        self.next_payment_check = 0.0
        self.next_expiry_check = 0.0
        self._last_degraded_notice = 0.0

    def start(self) -> None:
        now = time.monotonic()
        self.next_cycle = {"premium": now + 5, "plus": now + 5, "free": now + 5}
        self.next_payment_check = now + 10
        self.next_expiry_check = now + 10
        try:
            from daniel_ai.config import DanielSettings
            interval = max(10, int(DanielSettings.from_env().learning_interval_minutes)) * 60
            # Primeiro ciclo ~2 minutos após o boot; depois respeita o intervalo.
            self.last_learning_step = now - max(0, interval - 120)
        except Exception:
            self.last_learning_step = now

    def stop(self) -> None:
        """Stop local scheduler work without performing any network I/O."""
        if self.scanner.active:
            self.scanner.cancel("shutdown seguro")
        self.pending_groups.clear()
        self.manual_scan_users.clear()
        self.position_queue.clear()
        self.performance_queue.clear()
        self.shadow_performance_queue.clear()
        self.onchain_queue.clear()
        self.payment_queue.clear()

    def _reload_shadow_performance_queue(self) -> int:
        """Load due ~5 minute shadow confirmations without changing live decisions."""
        monitor = getattr(self.app, "performance_monitor", None)
        if monitor is None:
            return 0

        rows = monitor.ledger.shadow_due_signals(
            limit=int(getattr(settings, "performance_monitor_batch", 25)),
            target_seconds=int(getattr(settings, "signal_quality_shadow_target_seconds", 300)),
            grace_seconds=int(getattr(settings, "signal_quality_shadow_grace_seconds", 180)),
        )

        self.shadow_performance_queue.extend(rows)
        try:
            from csm.shadow_evidence_runtime import persist_queue_status
            persist_queue_status(self.shadow_performance_queue)
        except Exception:
            pass
        return len(rows)

    def _run_shadow_performance_step(self) -> bool:
        """Process at most one due shadow confirmation in one idle step."""
        monitor = getattr(self.app, "performance_monitor", None)
        if monitor is None:
            return False

        if not self.shadow_performance_queue:
            loaded = self._reload_shadow_performance_queue()
            if loaded <= 0:
                return False

        signal = self.shadow_performance_queue.popleft()
        try:
            from csm.shadow_evidence_runtime import persist_queue_status
            persist_queue_status(self.shadow_performance_queue)
        except Exception:
            pass

        try:
            observer = getattr(monitor, "observe_shadow_one", None)
            if callable(observer):
                observer(signal)
            else:
                monitor.observe_one(signal)
            # A tentativa já consumiu o passo cooperativo, mesmo quando
            # nenhum registro de observação pôde ser produzido.
            return True
        except Exception as exc:
            self.app.log_warning(
                f"shadow performance adiado signal={signal.get('id')}: "
                f"{type(exc).__name__}: {exc}"
            )
            # Também evita outra operação de rede no mesmo passo após falha.
            return True

    def _run_shadow_if_due(self, now: float | None = None) -> bool:
        """Run at most one shadow confirmation when its polling window is due."""
        # SHADOW_EVIDENCE_ACCELERATOR_V1650
        # Apenas priorização da fila Shadow; não altera sinais LIVE.
        try:
            from csm.shadow_evidence_runtime import prepare_shadow_queue
            _shadow_queue = getattr(
                self,
                'shadow_performance_queue',
                None,
            )
            if _shadow_queue is not None:
                self.shadow_performance_queue = prepare_shadow_queue(
                    _shadow_queue
                )
        except Exception:
            pass

        if not bool(getattr(settings, "signal_quality_shadow_enabled", False)):
            return False

        now = time.monotonic() if now is None else float(now)

        # Se já existem confirmações carregadas, processa uma imediatamente
        # para não perder a janela de ~5 minutos.
        if self.shadow_performance_queue:
            return self._run_shadow_performance_step()

        interval = max(
            60,
            int(getattr(settings, "signal_quality_shadow_poll_interval", 60)),
        )

        if now - self.last_shadow_performance_poll < interval:
            return False

        # Marca a consulta antes da possível tentativa de rede.
        self.last_shadow_performance_poll = now

        return self._run_shadow_performance_step()

    def status(self, user_id: int | None = None) -> dict[str, Any]:
        now = time.monotonic()
        user = self.app.storage.get_user(user_id) if user_id else {"plan": "free"}
        group = plan_group(user.get("plan"))
        due = self.next_cycle.get(group, 0.0)
        seconds = max(0, int(due - now)) if due else 0
        return {
            "scanner_active": self.scanner.active,
            "next_cycle_text": "agora" if seconds <= 0 else f"{seconds}s",
            "prefs": self.app.storage.user_preferences(user_id) if user_id else {},
        }

    def request_manual_scan(self, user_id: int) -> None:
        self.manual_scan_users.add(int(user_id))
        if not self.scanner.active:
            user = self.app.storage.get_user(int(user_id)) or {"plan": "free"}
            self.scanner.start(tier=plan_group(user.get("plan")))

    def _scan_complete(self, results: list[dict[str, Any]]) -> None:
        for user_id in list(self.manual_scan_users):
            self.app.scanner_sessions[user_id] = [dict(row) for row in results]
            text, keyboard = self.app.scanner_screen(user_id)
            try:
                self.app.telegram.send(user_id, text, keyboard)
            except Exception as exc:
                self.app.log_warning(f"envio scanner manual falhou: {type(exc).__name__}: {exc}")
        self.manual_scan_users.clear()

        groups = list(self.pending_groups)
        self.pending_groups.clear()
        delivery_summaries: list[tuple[str, dict[str, Any]]] = []
        for group, interval in groups:
            summary = self.app.deliver_signals(group, results)
            delivery_summaries.append((group, dict(summary)))
            self.app.storage.record_scanner_cycle(group, summary)
            self.next_cycle[group] = time.monotonic() + interval
            diagnostic = (
                f" usuários={summary.get('users', 0)} elegíveis={summary.get('eligible', 0)}"
                f" duplicados={summary.get('duplicates', 0)}"
            )
            reason = str(summary.get("reason") or "").strip()
            suffix = f" motivo={reason}" if summary.get("sent", 0) == 0 and reason else ""
            print(
                f"🚀 Scanner {group}: aprovados={summary['approved']} enviados={summary['sent']} "
                f"erros={summary['errors']}{diagnostic} próximo={interval // 60}min{suffix}",
                flush=True,
            )
        # v16.2 Scanner Intelligence: persist the exact scanner funnel and
        # bounded per-candidate decisions. Evidence only; no thresholds change.
        try:
            from csm.scanner_intelligence import ScannerIntelligenceStore
            captured = ScannerIntelligenceStore(self.app.storage).capture_cycle(self.scanner.last_stats)
            if captured.get("decisions"):
                print(
                    f"🔎 Scanner Intelligence: decisões={captured.get('decisions',0)} "
                    f"podadas={captured.get('pruned',0)}",
                    flush=True,
                )
        except Exception as exc:
            self.app.log_warning(f"scanner intelligence pós-scan adiada: {type(exc).__name__}: {exc}")

        # V16.5.9: compact rolling coverage evidence by chain/provider. This
        # powers the Coverage Guard and Quality Router without changing gates.
        try:
            if bool(getattr(settings, "provider_coverage_enabled", True)):
                from csm.provider_coverage import capture_cycle
                capture_cycle(self.scanner.last_stats)
        except Exception as exc:
            self.app.log_warning(f"provider coverage pós-scan adiada: {type(exc).__name__}: {exc}")

        if self.app.performance_monitor is not None:
            try:
                captured = self.app.performance_monitor.observe_cached_results(results)
                if captured:
                    print(f"📈 Performance Ledger: {captured} observação(ões) reaproveitadas do scanner sem nova chamada HTTPS.", flush=True)
            except Exception as exc:
                self.app.log_warning(f"performance cache pós-scan ignorado: {type(exc).__name__}: {exc}")

        # V16.6.0 Signal Outcome Learning: local DB-only snapshot. This layer
        # is evidence-only and has no code path to alter live filters/scoring.
        try:
            now_learning = time.monotonic()
            interval = max(300, int(getattr(settings, "signal_outcome_learning_interval_seconds", 1800)))
            if (
                bool(getattr(settings, "signal_outcome_learning_enabled", True))
                and now_learning - self.last_signal_outcome_learning >= interval
            ):
                from csm.signal_outcome_learning import SignalOutcomeLearning
                learning = SignalOutcomeLearning(self.app.storage).run(
                    days=max(1, int(getattr(settings, "signal_outcome_learning_lookback_days", 30)))
                )
                self.last_signal_outcome_learning = now_learning
                print(
                    f"🧠 Signal Outcome Learning: modo={learning.get('mode')} "
                    f"observados={learning.get('signals_observed', 0)} "
                    f"recomendações={len(learning.get('recommendations') or [])} "
                    "live_impact=FALSE",
                    flush=True,
                )
        except Exception as exc:
            self.last_signal_outcome_learning = time.monotonic()
            self.app.log_warning(f"signal outcome learning adiado: {type(exc).__name__}: {exc}")

        # V0.7: sinais aprovados alimentam a fila de aprendizado como temas,
        # sem qualquer mudança no score/sinal. O learner pesquisa depois, em
        # baixa prioridade e com limite de fontes.
        try:
            from daniel_ai.config import DanielSettings
            dcfg = DanielSettings.from_env()
            if dcfg.learning_enabled:
                from daniel_ai.memory import DanielMemory
                with DanielMemory(dcfg.db_file) as dmem:
                    ranked = sorted(
                        [dict(row) for row in results if isinstance(row, dict)],
                        key=lambda row: int(row.get("final_score") or row.get("score") or 0),
                        reverse=True,
                    )
                    queued = 0
                    for row in ranked:
                        symbol = str(row.get("symbol") or row.get("name") or "").strip()[:40]
                        chain = str(row.get("chain") or "").strip()[:30]
                        if not symbol:
                            continue
                        dmem.enqueue_learning_topic(f"{symbol} {chain} crypto token".strip(), source="csm_signal", priority=30)
                        queued += 1
                        if queued >= 2:
                            break
        except Exception as exc:
            self.app.log_warning(f"fila Daniel learning pós-scan adiada: {type(exc).__name__}: {exc}")
        print(self._provider_metrics_line(self.scanner.last_stats), flush=True)
        # V16.1: persist the snapshot from the *active* phantom_v10 runtime.
        # Daniel AI and the web panel read this report; without this bridge they
        # could display a stale 100/100 generated by an older scanner path.
        try:
            from csm.provider_health import save_provider_health
            save_provider_health(self.scanner.providers.snapshot())
        except Exception as exc:
            self.app.log_warning(f"provider health snapshot adiado: {type(exc).__name__}: {exc}")
        if getattr(self.app, "observability", None) is not None:
            try:
                self.app.observability.capture_scanner_cycle(
                    self.scanner.last_stats,
                    delivery_summaries=delivery_summaries,
                    provider_rows=self.scanner.providers.snapshot(),
                    network_snapshot=self.app.network_bus.snapshot(),
                )
                ops = self.app.observability.status(days=7)
                print(
                    f"📡 Operations V14.5: health={ops['health_score']}/100 {ops['state']} "
                    f"incidentes_abertos={ops['open_incidents']}",
                    flush=True,
                )
                self.app.notify_operational_incidents()
                self.app.notify_operational_recoveries()
            except Exception as exc:
                self.app.log_warning(f"observability pós-scan adiada: {type(exc).__name__}: {exc}")
        if self.scanner.last_stats.get("aborted"):
            print(f"⚠️ Scanner degradado: {self.scanner.last_error}. Telegram permanece online.", flush=True)
        elif self.scanner.last_stats.get("partial"):
            print(
                f"ℹ️ Scanner concluiu fatia cooperativa: {self.scanner.last_error}; "
                "próxima fatia seguirá pelo scheduler.",
                flush=True,
            )


    @staticmethod
    def _provider_metrics_line(stats: dict[str, Any]) -> str:
        labels = {
            "dexscreener": "DexScreener",
            "geckoterminal": "GeckoTerminal",
            "birdeye": "Birdeye",
            "coingecko": "CoinGecko",
        }
        counts = stats.get("provider_candidates") or {}
        unique = stats.get("provider_unique_added") or {}
        ok = stats.get("provider_sources_ok") or {}
        failed = stats.get("provider_sources_failed") or {}
        error_details = stats.get("provider_error_details") or {}
        unsupported = stats.get("provider_unsupported") or {}
        skipped_unsupported = stats.get("provider_skipped_unsupported") or {}
        paused = stats.get("provider_paused") or {}
        providers = []
        ordered = ["dexscreener", "geckoterminal", "birdeye", "coingecko"]
        extras = sorted((set(counts) | set(unique) | set(ok) | set(failed) | set(paused)) - set(ordered))
        for provider in ordered + extras:
            if provider not in counts and provider not in unique and provider not in ok and provider not in failed and provider not in paused:
                continue
            label = labels.get(provider, provider)
            total = int(counts.get(provider, 0))
            added = int(unique.get(provider, 0))
            source_failed = int(failed.get(provider, 0))
            status = f"{label}={total}(+{added})"
            if source_failed:
                status += f" ⚠️{source_failed}"
                details = list(error_details.get(provider) or [])
                if details:
                    status += "[" + "; ".join(str(item)[:60] for item in details[-2:]) + "]"
            pause_reason = str(paused.get(provider) or "").strip()
            if pause_reason:
                status += f" 🔐[{pause_reason[:90]}]"
            capability_rows = list(unsupported.get(provider) or []) + list(skipped_unsupported.get(provider) or [])
            if capability_rows:
                # Deduplicate while preserving order so the operator sees a
                # capability note, not a misleading provider error.
                clean = []
                for item in capability_rows:
                    item = str(item)[:72]
                    if item not in clean:
                        clean.append(item)
                status += " ⏭️[" + "; ".join(clean[-2:]) + "]"
            providers.append(status)
        if not providers:
            providers.append("nenhuma fonte concluiu nesta fatia")
        reasons = stats.get("rejection_reasons") or {}
        top_reasons = sorted(reasons.items(), key=lambda item: (-int(item[1]), str(item[0])))[:3]
        reason_text = ",".join(f"{name}={count}" for name, count in top_reasons)
        suffix = f" filtros=[{reason_text}]" if reason_text else ""
        security = ""
        if settings.goplus_enabled:
            security = (
                f" | 🛡️GoPlus verificados={int(stats.get('security_verified', 0))}"
                f" bloqueados={int(stats.get('security_blocked', 0))}"
                f" indisponíveis={int(stats.get('security_unavailable', 0))}"
            )
        return (
            "🌐 Multi-Provider: " + " | ".join(providers)
            + f" | únicos={int(stats.get('discovered', 0))}"
            + f" analisados={int(stats.get('analyzed', 0))}"
            + f" aprovados={int(stats.get('approved', 0))}"
            + f" rejeitados={int(stats.get('rejected', 0))}"
            + f" indisponíveis={int(stats.get('market_unavailable', 0))}"
            + security
            + suffix
        )

    def step(self) -> None:
        now = time.monotonic()
        if self.scanner.active:
            result = self.scanner.step()
            if result is not None:
                self._scan_complete(result)
            return

        if settings.auto_signals_enabled:
            due: list[tuple[str, int]] = []
            for group, interval in (
                ("premium", settings.auto_scan_interval_premium),
                ("plus", settings.auto_scan_interval_plus),
                ("free", settings.auto_scan_interval_free),
            ):
                if now >= self.next_cycle[group]:
                    due.append((group, interval))
            if due:
                # Build discovery depth from the highest tier due in this shared
                # cooperative cycle. Lower tiers may receive a subset of the same
                # approved pool, while Premium/Plus fund the broader discovery.
                rank = {"free": 0, "plus": 1, "premium": 2}
                discovery_tier = max((group for group, _ in due), key=lambda g: rank.get(g, 0))
                if self.scanner.start(tier=discovery_tier):
                    self.pending_groups = due
                else:
                    for group, _ in due:
                        self.next_cycle[group] = now + 15
                return

        # Automatic Asaas reconciliation for new subscribers. This stays on
        # the same single-threaded scheduler/network bus and processes one
        # payment per step, so scanner/Telegram responsiveness is preserved.
        if self.app.payments and settings.payment_auto_check:
            if not self.payment_queue and now >= self.next_payment_check:
                rows = self.app.storage.open_payments(limit=settings.payment_check_batch)
                self.payment_queue.extend(str(row["payment_id"]) for row in rows if row.get("payment_id"))
                self.next_payment_check = now + settings.payment_check_interval
            if self.payment_queue:
                payment_id = self.payment_queue.popleft()
                try:
                    result = self.app.payments.verify_payment(payment_id)
                    if result.get("state") == "activated":
                        user_id = int(result.get("user_id") or 0)
                        plan = str(result.get("plan") or "free")
                        print(f"✅ Assinatura ativada automaticamente: user={user_id} plano={plan}", flush=True)
                        if user_id > 0:
                            try:
                                self.app.telegram.send(
                                    user_id,
                                    f"✅ <b>Pagamento confirmado.</b> Seu plano <b>{plan}</b> já está ativo.",
                                )
                            except Exception as exc:
                                self.app.log_warning(
                                    f"plano ativado, mas aviso Telegram falhou user={user_id}: "
                                    f"{type(exc).__name__}: {exc}"
                                )
                except Exception as exc:
                    self.app.log_warning(
                        f"sincronização automática de pagamento falhou payment={payment_id}: "
                        f"{type(exc).__name__}: {exc}"
                    )
                return

        # v15 outbound Distribution Platform. Telegram has already confirmed
        # these signals; process at most one external delivery per idle scheduler
        # step so scanner/Telegram keep priority on mobile.
        if settings.distribution_enabled and getattr(self.app, "distribution", None) is not None:
            if now - self.last_distribution_step >= settings.distribution_scheduler_interval:
                self.last_distribution_step = now
                try:
                    result = self.app.distribution.run_one()
                    if result is not None:
                        icon = "✅" if result.get("state") == "SENT" else ("⚠️" if result.get("state") == "RETRY" else "❌")
                        print(
                            f"{icon} Distribution {result.get('channel')}: job={result.get('job_id')} "
                            f"state={result.get('state')} tentativa={result.get('attempt')}",
                            flush=True,
                        )
                        return
                except Exception as exc:
                    self.app.log_warning(f"distribution step adiado: {type(exc).__name__}: {exc}")

        if settings.signal_monitor_enabled and not self.position_queue and now - self.last_position_reload >= settings.signal_monitor_interval:
            self.position_queue.extend(self.app.storage.open_signal_positions(limit=100))
            self.last_position_reload = now
        if self.position_queue:
            position = self.position_queue.popleft()
            try:
                self.app.process_cached_position(position)
            except Exception as exc:
                self.app.log_warning(f"monitor cache-only ignorou posição: {type(exc).__name__}: {exc}")
            return

        # v16.4.5 Signal Quality Shadow Gate.
        # Executa somente em passo ocioso, após scanner/pagamentos/distribuição/
        # posições, e consome no máximo uma tentativa de rede por step.
        # Evidence-only: não altera score, aprovação ou entrega do sinal.
        if self._run_shadow_if_due(now):
            return

        # v11 Performance Intelligence. One due signal consumes at most one
        # DexScreener HTTPS request in this scheduler step. The bot/scanner
        # continue to own network priority; performance work only runs while the
        # cooperative scanner is idle.
        if settings.performance_monitor_enabled and self.app.performance_monitor is not None:
            if not self.performance_queue and now - self.last_performance_reload >= settings.performance_monitor_interval:
                try:
                    due = self.app.performance_monitor.ledger.due_signals(
                        limit=settings.performance_monitor_batch,
                        minimum_gap_seconds=settings.performance_monitor_interval,
                    )
                    self.performance_queue.extend(due)
                except Exception as exc:
                    self.app.log_warning(f"fila Performance Ledger não carregada: {type(exc).__name__}: {exc}")
                self.last_performance_reload = now
            if self.performance_queue:
                signal = self.performance_queue.popleft()
                try:
                    updated = self.app.performance_monitor.observe_one(signal)
                    if updated and bool(getattr(settings, "signal_lifecycle_enabled", True)):
                        event = self.app.performance_monitor.ledger.pending_lifecycle_event(int(signal.get("id") or 0))
                        if event:
                            try:
                                sent = self.app.notify_signal_lifecycle(signal, event)
                                if sent:
                                    print(f"📈 Signal Lifecycle: {event.get('event_type')} enviado para {sent} usuário(s).", flush=True)
                            finally:
                                # Event deduplication is local and deterministic. Even when no
                                # eligible recipient exists, do not retry the same transition forever.
                                self.app.performance_monitor.ledger.mark_lifecycle_event_notified(int(event.get("id") or 0))
                except Exception as exc:
                    self.app.log_warning(
                        f"observação performance adiada signal={signal.get('id')}: {type(exc).__name__}: {exc}"
                    )
                return

        # v13.5 On-Chain Intelligence. This stays behind scanner, payments,
        # position monitoring and Performance Ledger. One signal consumes at
        # most one HTTPS request per scheduler step; no public webhooks exist.
        if settings.onchain_enabled and self.app.onchain_monitor is not None:
            if not self.onchain_queue and now - self.last_onchain_reload >= settings.onchain_monitor_interval:
                try:
                    due = self.app.onchain_monitor.due_signals(
                        limit=settings.onchain_monitor_batch,
                        minimum_gap_seconds=settings.onchain_monitor_interval,
                    )
                    self.onchain_queue.extend(due)
                except Exception as exc:
                    self.app.log_warning(f"fila On-Chain não carregada: {type(exc).__name__}: {exc}")
                self.last_onchain_reload = now
            if self.onchain_queue:
                signal = self.onchain_queue.popleft()
                try:
                    snapshot = self.app.onchain_monitor.observe_one(signal)
                    if snapshot:
                        alerted = self.app.notify_onchain_snapshot(signal, snapshot)
                        if alerted:
                            print(f"⚠️ On-Chain: {alerted} alerta(s) de deterioração enviados.", flush=True)
                except Exception as exc:
                    self.app.log_warning(
                        f"observação on-chain adiada signal={signal.get('id')}: {type(exc).__name__}: {exc}"
                    )
                return

        # Daniel AI V0.9 Outcome Intelligence. Executa somente quando todas as
        # filas operacionais prioritárias estão ociosas. Um tema por intervalo;
        # nunca altera signals.db nem configuração do CSM.
        try:
            from daniel_ai.config import DanielSettings
            dcfg = DanielSettings.from_env()
            if dcfg.learning_enabled and now - self.last_learning_step >= max(10, int(dcfg.learning_interval_minutes)) * 60:
                self.last_learning_step = now
                if self._daniel_learner is None:
                    from daniel_ai.learning import AutoLearner
                    self._daniel_learner = AutoLearner(dcfg)
                # First learn from the local Performance Ledger. This works even
                # when public web research is OFF and cannot modify signals.db.
                local_result = self._daniel_learner.learn_csm_outcomes(self.app.storage.conn, days=30)
                if local_result.get("ok"):
                    print(
                        f"🧠 Daniel Outcome Learning: amostra={local_result.get('samples',0)} "
                        f"confiança={local_result.get('confidence',0)}%",
                        flush=True,
                    )
                result = self._daniel_learner.step()
                if result.get("ok") and result.get("topic"):
                    print(
                        f"🧠 Daniel Web Learning: {result.get('topic')} • fontes={result.get('source_count',0)} "
                        f"confiança={result.get('confidence',0)}%",
                        flush=True,
                    )
                elif result.get("reason") not in {"nothing_due", "disabled", "web_off"}:
                    self.app.log_warning(f"Daniel learning adiado: {result.get('reason')}")
                return
        except Exception as exc:
            self.last_learning_step = now
            self.app.log_warning(f"Daniel learning adiado: {type(exc).__name__}: {exc}")

        # v14 reputation consolidation is local SQLite-only and bounded. It is
        # deliberately scheduled after network work so mobile scanning wins.
        if settings.reputation_enabled and getattr(self.app, "reputation_engine", None) is not None:
            if now - self.last_reputation_refresh >= settings.reputation_refresh_interval:
                try:
                    self.app.reputation_engine.refresh(days=3650, limit=settings.reputation_refresh_limit)
                except Exception as exc:
                    self.app.log_warning(f"reputation refresh adiado: {type(exc).__name__}: {exc}")
                self.last_reputation_refresh = now

        if getattr(self.app, "observability", None) is not None and now - self.last_observability_heartbeat >= settings.observability_runtime_interval:
            try:
                self.app.observability.heartbeat(
                    network_snapshot=self.app.network_bus.snapshot(),
                    scanner_active=self.scanner.active,
                )
            except Exception as exc:
                self.app.log_warning(f"heartbeat observability adiado: {type(exc).__name__}: {exc}")
            self.last_observability_heartbeat = now

        if now >= self.next_expiry_check:
            self.app.storage.expire_plans()
            self.next_expiry_check = now + 300
