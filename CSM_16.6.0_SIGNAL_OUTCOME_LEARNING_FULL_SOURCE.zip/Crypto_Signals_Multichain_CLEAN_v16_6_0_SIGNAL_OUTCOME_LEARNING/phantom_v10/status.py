from __future__ import annotations

import os
import sys

from csm.config import settings

from .runtime import runtime_state
from .transport import global_network_bus
from . import __version__


def runtime_status():
    state = runtime_state("bot")
    return {
        "version": __version__,
        "pid_diagnostico": os.getpid(),
        "python": sys.executable,
        "single_python": True,
        "multiprocessing": False,
        "thread_pool": False,
        "subprocess": False,
        "curl": False,
        "http_stack": "http.client + ssl (stdlib)",
        "network_policy": "ONE_SHARED_SEQUENTIAL_NETWORK_BUS",
        "max_concurrent_network": 1,
        "network_bus": global_network_bus().snapshot(),
        "liveness_authority": "UDP lease + sessão/heartbeat + PID negativo fallback",
        "state_dir": str(settings.data_dir),
        "db": str(settings.db_file),
        **{f"runtime_{key}": value for key, value in state.items()},
    }
