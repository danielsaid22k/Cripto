from __future__ import annotations

import json
import logging
import time
from typing import Any

from csm.config import settings

from .errors import NetworkHTTPError, TelegramAPIError, TransientNetworkError
from .transport import StdlibHttpTransport

logger = logging.getLogger(__name__)


class TelegramClient:
    """Telegram API adapter for v10.

    All calls use the shared standard-library HTTPS transport. Startup network
    failures are treated as transient and can be retried by the application
    without terminating the Python process.
    """

    def __init__(self, token: str | None = None, transport: StdlibHttpTransport | None = None):
        self.token = (token or settings.telegram_token).strip()
        self.transport = transport or StdlibHttpTransport(
            timeout=6.0, label="telegram", preserve_http_statuses={429}
        )
        self.base = f"https://api.telegram.org/bot{self.token}"
        self._last_global_send = 0.0
        self._last_chat_send: dict[str, float] = {}

    def call(self, method: str, data=None, *, timeout: float | None = None):
        try:
            payload = self.transport.post_json(f"{self.base}/{method}", data=data or {}, timeout=timeout)
        except NetworkHTTPError as exc:
            description = "Erro Telegram"
            retry_after = 0
            if isinstance(exc.payload, dict):
                description = str(exc.payload.get("description") or description)
                params = exc.payload.get("parameters") or {}
                if isinstance(params, dict):
                    try:
                        retry_after = int(params.get("retry_after") or 0)
                    except (TypeError, ValueError):
                        retry_after = 0
            raise TelegramAPIError(description, exc.status, retry_after=retry_after) from exc
        if not isinstance(payload, dict) or not payload.get("ok"):
            description = payload.get("description", "Erro Telegram") if isinstance(payload, dict) else "Erro Telegram"
            code = payload.get("error_code") if isinstance(payload, dict) else None
            raise TelegramAPIError(str(description), code)
        return payload.get("result")


    def get_file(self, file_id: str):
        file_id = str(file_id or "").strip()
        if not file_id:
            raise TelegramAPIError("file_id ausente")
        return self.call("getFile", {"file_id": file_id}, timeout=6.0)

    def download_file(self, file_id: str, destination, *, max_bytes: int = 12 * 1024 * 1024):
        """Download one Telegram file to a local path with a hard size cap."""
        from pathlib import Path

        meta = self.get_file(file_id)
        if not isinstance(meta, dict) or not meta.get("file_path"):
            raise TelegramAPIError("Telegram não retornou file_path")
        remote_size = int(meta.get("file_size") or 0)
        if remote_size and remote_size > int(max_bytes):
            raise TelegramAPIError("Arquivo do Telegram acima do limite local", 413)
        rel = str(meta["file_path"]).lstrip("/")
        url = f"https://api.telegram.org/file/bot{self.token}/{rel}"
        raw = self.transport.get_bytes(url, timeout=12.0, max_bytes=max_bytes)
        path = Path(destination)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        return {"path": str(path), "bytes": len(raw), "file_path": rel}

    def get_me(self):
        return self.call("getMe", timeout=8.0)

    def bootstrap(self, attempts: int = 4):
        attempts = max(1, int(attempts))
        last_error: Exception | None = None
        for index in range(attempts):
            try:
                return self.get_me()
            except TelegramAPIError:
                raise
            except TransientNetworkError as exc:
                last_error = exc
                if index + 1 < attempts:
                    time.sleep(min(4.0, 0.75 * (2 ** index)))
        if last_error:
            raise last_error
        raise TransientNetworkError("Telegram indisponível.")

    def _pace(self, chat_id) -> None:
        """Cooperative Telegram rate guard; no threads or background queues."""
        now = time.monotonic()
        chat_key = str(chat_id)
        global_gap = max(0.0, float(getattr(settings, "telegram_min_global_interval_seconds", 0.05)))
        chat_gap = max(global_gap, float(getattr(settings, "telegram_min_chat_interval_seconds", 1.05)))
        wait_global = global_gap - (now - self._last_global_send) if self._last_global_send else 0.0
        last_chat = float(self._last_chat_send.get(chat_key, 0.0) or 0.0)
        wait_chat = chat_gap - (now - last_chat) if last_chat else 0.0
        wait = max(0.0, wait_global, wait_chat)
        if wait > 0:
            time.sleep(min(wait, max(chat_gap, 2.0)))
        stamp = time.monotonic()
        self._last_global_send = stamp
        self._last_chat_send[chat_key] = stamp

    @staticmethod
    def is_unreachable_error(exc: Exception) -> bool:
        if not isinstance(exc, TelegramAPIError):
            return False
        text = exc.description.casefold()
        return exc.error_code in {400, 403} and any(
            marker in text for marker in (
                "chat not found", "bot was blocked", "user is deactivated",
                "forbidden: bot was blocked", "bot can't initiate conversation",
            )
        )

    def send(self, chat_id, text: str, reply_markup=None):
        self._pace(chat_id)
        data = {
            "chat_id": str(chat_id),
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true",
        }
        if reply_markup:
            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        return self.call("sendMessage", data, timeout=6.0)

    def send_voice(self, chat_id, voice_path, caption: str = ""):
        self._pace(chat_id)
        from pathlib import Path

        path = Path(voice_path)
        if not path.is_file():
            raise TelegramAPIError("Arquivo de voz local não encontrado")
        raw = path.read_bytes()
        if len(raw) > 8 * 1024 * 1024:
            raise TelegramAPIError("Resposta de voz acima do limite local", 413)
        fields = {"chat_id": str(chat_id)}
        if caption:
            fields["caption"] = str(caption)[:900]
        try:
            payload = self.transport.post_multipart(
                f"{self.base}/sendVoice",
                fields=fields,
                file_field="voice",
                filename=path.name,
                file_bytes=raw,
                content_type="audio/ogg",
                timeout=15.0,
            )
        except NetworkHTTPError as exc:
            description = str((exc.payload or {}).get("description") or "Erro Telegram") if isinstance(exc.payload, dict) else "Erro Telegram"
            params = (exc.payload or {}).get("parameters") if isinstance(exc.payload, dict) else {}
            try:
                retry_after = int((params or {}).get("retry_after") or 0) if isinstance(params, dict) else 0
            except (TypeError, ValueError):
                retry_after = 0
            raise TelegramAPIError(description, exc.status, retry_after=retry_after) from exc
        if not isinstance(payload, dict) or not payload.get("ok"):
            description = payload.get("description", "Erro Telegram") if isinstance(payload, dict) else "Erro Telegram"
            code = payload.get("error_code") if isinstance(payload, dict) else None
            raise TelegramAPIError(str(description), code)
        return payload.get("result")

    def edit(self, chat_id, message_id, text: str, reply_markup=None):
        self._pace(chat_id)
        data = {
            "chat_id": str(chat_id),
            "message_id": str(message_id),
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true",
        }
        if reply_markup:
            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        return self.call("editMessageText", data, timeout=6.0)

    def edit_or_send(self, chat_id, message_id, text: str, reply_markup=None):
        try:
            return self.edit(chat_id, message_id, text, reply_markup)
        except TransientNetworkError:
            raise
        except TelegramAPIError as exc:
            if "message is not modified" in exc.description.lower():
                return None
            return self.send(chat_id, text, reply_markup)

    def answer_callback(self, callback_id: str, text: str = "") -> bool:
        if not callback_id:
            return False
        data = {"callback_query_id": callback_id, "cache_time": "0"}
        if text:
            data["text"] = text[:180]
        try:
            self.call("answerCallbackQuery", data, timeout=4.0)
            return True
        except Exception as exc:
            logger.warning("ACK de callback ignorado: %s", exc)
            return False

    def updates(self, offset=None, *, poll_seconds: int = 1):
        # During a scanner cycle we use short polling (0 s). With a single
        # sequential network bus, a one-second Telegram long poll before every
        # scanner step used to consume most of the scanner time budget.
        poll_seconds = max(0, min(int(poll_seconds), 2))
        data: dict[str, Any] = {
            "timeout": str(poll_seconds),
            "allowed_updates": '["message","callback_query"]',
        }
        if offset is not None:
            data["offset"] = str(offset)
        try:
            socket_timeout = 2.0 if poll_seconds == 0 else max(3.0, float(poll_seconds) + 2.0)
            return self.call("getUpdates", data, timeout=socket_timeout) or []
        except TransientNetworkError:
            return []
        except TelegramAPIError as exc:
            if exc.error_code == 429 or (exc.error_code and exc.error_code >= 500):
                return []
            raise

    def confirm_offset(self, offset: int) -> None:
        """Best-effort confirmation of already processed Telegram updates.

        Telegram considers updates below ``offset`` confirmed only after a
        subsequent getUpdates request carries that offset. Returning newer
        updates here is harmless: they remain pending because we do not advance
        past their ids in this confirmation call.
        """
        data: dict[str, Any] = {
            "offset": str(int(offset)),
            "limit": "1",
            "timeout": "0",
            "allowed_updates": '["message","callback_query"]',
        }
        self.call("getUpdates", data, timeout=2.0)

    def close(self) -> None:
        """Compatibility hook for the application shutdown sequence.

        The v10 transport does not pool connections, so there is no persistent
        Telegram socket to tear down here. Keeping an explicit hook makes the
        shutdown ownership unambiguous and testable.
        """
        return None

    def prepare(self) -> list[str]:
        """Best-effort noncritical Telegram setup.

        Failure to delete a webhook or publish slash commands must never take
        the bot offline after authentication succeeded.
        """
        warnings: list[str] = []
        commands = [
            {"command": "start", "description": "Abrir menu principal"},
            {"command": "analisar", "description": "Analisar um contrato"},
            {"command": "planos", "description": "Comparar planos"},
            {"command": "meuplano", "description": "Consultar assinatura"},
            {"command": "historico", "description": "Últimas análises"},
            {"command": "favoritos", "description": "Tokens favoritos"},
            {"command": "status", "description": "Status do serviço"},
        ]
        for method, data in (
            ("deleteWebhook", {"drop_pending_updates": "false"}),
            ("setMyCommands", {"commands": json.dumps(commands, ensure_ascii=False)}),
        ):
            try:
                self.call(method, data, timeout=6.0)
            except Exception as exc:
                warnings.append(f"{method}: {type(exc).__name__}: {exc}")
        return warnings
