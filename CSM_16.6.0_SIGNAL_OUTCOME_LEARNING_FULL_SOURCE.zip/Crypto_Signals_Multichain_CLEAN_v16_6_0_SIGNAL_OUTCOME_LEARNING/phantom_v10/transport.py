from __future__ import annotations

import http.client
import json
import signal
import socket
import ssl
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode, urlsplit, urlunsplit, parse_qsl

from .errors import NetworkBusyError, NetworkHTTPError, TransientNetworkError


def _block_sigint_during_tls():
    """Defer Ctrl+C until after the HTTPS socket is fully closed.

    a-Shell embeds Python in iOS and some builds can crash natively when SIGINT
    interrupts ``ssl.read``.  POSIX signal masking lets the request finish (or
    timeout), closes HTTPResponse/HTTPSConnection, releases the network bus and
    only then delivers the pending Ctrl+C to Python.
    """
    fn = getattr(signal, "pthread_sigmask", None)
    if fn is None:
        return None
    try:
        return fn(signal.SIG_BLOCK, {signal.SIGINT})
    except Exception:
        return None


def sigint_tls_shield_available() -> bool:
    return callable(getattr(signal, "pthread_sigmask", None))


def _restore_sigint_mask(previous) -> None:
    if previous is None:
        return
    fn = getattr(signal, "pthread_sigmask", None)
    if fn is None:
        return
    fn(signal.SIG_SETMASK, previous)



@dataclass(frozen=True)
class HttpResult:
    payload: Any
    status: int
    elapsed_ms: float
    url: str


class NetworkBus:
    """Process-local serialization gate.

    v10 does not spawn curl, threads or Python workers. The bus still enforces
    one network operation at a time so every service shares the same contract.
    """

    def __init__(self):
        self.busy = False
        self.owner: str | None = None
        self.kind: str | None = None
        self.started_at = 0.0
        self.total_acquired = 0
        self.busy_rejections = 0
        self.last_owner: str | None = None

    def acquire(self, owner: str, kind: str) -> None:
        if self.busy:
            self.busy_rejections += 1
            raise NetworkBusyError(f"rede ocupada por {self.owner or 'outro serviço'}")
        self.busy = True
        self.owner = owner
        self.kind = kind
        self.started_at = time.monotonic()
        self.total_acquired += 1
        self.last_owner = owner

    def release(self, owner: str) -> None:
        if not self.busy:
            return
        if self.owner != owner:
            return
        self.busy = False
        self.owner = None
        self.kind = None
        self.started_at = 0.0

    def reset(self) -> None:
        """Clear process-local ownership after a fully completed shutdown.

        This never interrupts an in-flight request. Callers only use it after
        the application loop has stopped and every transport request returned.
        """
        self.busy = False
        self.owner = None
        self.kind = None
        self.started_at = 0.0

    def snapshot(self) -> dict[str, Any]:
        age = max(0.0, time.monotonic() - self.started_at) if self.busy and self.started_at else 0.0
        return {
            "busy": self.busy,
            "owner": self.owner,
            "kind": self.kind,
            "age_seconds": round(age, 2),
            "total_acquired": self.total_acquired,
            "busy_rejections": self.busy_rejections,
            "last_owner": self.last_owner,
        }


_GLOBAL_BUS = NetworkBus()


def global_network_bus() -> NetworkBus:
    return _GLOBAL_BUS


def _ssl_context() -> ssl.SSLContext:
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


class StdlibHttpTransport:
    """Small HTTPS JSON client built only on Python's standard library.

    This deliberately avoids requests, urllib3, subprocess and curl. Each
    request opens and closes its own HTTPS connection, has a hard socket timeout
    and is serialized through ``NetworkBus``.
    """

    def __init__(
        self,
        *,
        timeout: float = 6.0,
        headers: dict[str, str] | None = None,
        bus: NetworkBus | None = None,
        label: str = "http",
        connection_factory=None,
        preserve_http_statuses: set[int] | None = None,
    ):
        self.timeout = max(1.0, min(float(timeout), 15.0))
        self.headers = {
            "Accept": "application/json",
            "User-Agent": "PhantomAlert/10.0",
            # a-Shell embeds Python inside the iOS app. Explicitly closing the
            # HTTP side avoids leaving a TLS stream around when the command is
            # stopped and the embedded interpreter is reconfigured.
            "Connection": "close",
        }
        if headers:
            self.headers.update({str(k): str(v) for k, v in headers.items()})
        self.bus = bus or global_network_bus()
        self.label = str(label or "http")
        self.connection_factory = connection_factory
        self.preserve_http_statuses = {int(x) for x in (preserve_http_statuses or set())}
        self._seq = 0

    def clone(self, *, label: str | None = None, headers: dict[str, str] | None = None, timeout: float | None = None):
        merged = dict(self.headers)
        if headers:
            merged.update(headers)
        return StdlibHttpTransport(
            timeout=self.timeout if timeout is None else timeout,
            headers=merged,
            bus=self.bus,
            label=label or self.label,
            connection_factory=self.connection_factory,
            preserve_http_statuses=set(self.preserve_http_statuses),
        )

    def _connection(self, host: str, port: int | None, timeout: float):
        if self.connection_factory is not None:
            return self.connection_factory(host, port or 443, timeout)
        return http.client.HTTPSConnection(host, port=port or 443, timeout=timeout, context=_ssl_context())

    @staticmethod
    def _url_with_params(url: str, params: dict[str, Any] | None) -> str:
        if not params:
            return url
        parsed = urlsplit(url)
        query = list(parse_qsl(parsed.query, keep_blank_values=True))
        for key, value in params.items():
            if isinstance(value, (list, tuple)):
                query.extend((str(key), str(item)) for item in value)
            elif value is not None:
                query.append((str(key), str(value)))
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))

    def request_json(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        json_data: Any = None,
        timeout: float | None = None,
    ) -> HttpResult:
        effective = max(1.0, min(float(timeout or self.timeout), 15.0))
        final_url = self._url_with_params(url, params)
        parsed = urlsplit(final_url)
        if parsed.scheme != "https" or not parsed.hostname:
            raise ValueError("v10 aceita apenas URLs HTTPS válidas")
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query

        headers = dict(self.headers)
        body: str | bytes | None = None
        if json_data is not None:
            body = json.dumps(json_data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        elif data is not None:
            body = urlencode({str(k): str(v) for k, v in data.items() if v is not None}).encode("utf-8")
            headers["Content-Type"] = "application/x-www-form-urlencoded"

        self._seq += 1
        owner = f"{self.label}:{self._seq}"
        self.bus.acquire(owner, self.label)
        started = time.monotonic()
        conn = None
        response = None
        sigint_mask = _block_sigint_during_tls()
        try:
            conn = self._connection(parsed.hostname, parsed.port, effective)
            conn.request(method.upper(), path, body=body, headers=headers)
            response = conn.getresponse()
            raw = response.read(4 * 1024 * 1024)
            elapsed = (time.monotonic() - started) * 1000
            text = raw.decode("utf-8", errors="replace") if raw else ""
            if text:
                try:
                    payload = json.loads(text)
                except json.JSONDecodeError as exc:
                    if 200 <= int(response.status) < 300:
                        raise TransientNetworkError("Resposta HTTPS não JSON.") from exc
                    payload = {"raw": text[:1000]}
            else:
                payload = {}
            status = int(response.status)
            if status in {408, 425, 429, 500, 502, 503, 504} and status not in self.preserve_http_statuses:
                retry_after = 0
                if status == 429:
                    try:
                        retry_after = max(0, int(str(response.getheader("Retry-After") or "0").strip()))
                    except (TypeError, ValueError):
                        retry_after = 0
                raise TransientNetworkError(
                    f"Serviço temporariamente indisponível (HTTP {status}).",
                    status=status,
                    retry_after=retry_after,
                )
            if status >= 400:
                raise NetworkHTTPError(status, payload, final_url)
            return HttpResult(payload=payload, status=status, elapsed_ms=elapsed, url=final_url)
        except NetworkHTTPError:
            raise
        except TransientNetworkError:
            raise
        except (socket.timeout, TimeoutError) as exc:
            raise TransientNetworkError("Timeout de rede/TLS.") from exc
        except ssl.SSLError as exc:
            raise TransientNetworkError(f"Falha TLS transitória: {exc}") from exc
        except (OSError, http.client.HTTPException) as exc:
            raise TransientNetworkError(f"Falha HTTPS transitória: {type(exc).__name__}: {exc}") from exc
        finally:
            # HTTPResponse owns a buffered socket file in addition to the
            # HTTPSConnection object. Closing both explicitly is important on
            # a-Shell/iOS: a KeyboardInterrupt while ssl.read() is active must
            # not leave that wrapper alive for the next embedded-Python run.
            # Cleanup itself must be interruption-proof: a second Ctrl+C while
            # closing cannot be allowed to skip the connection/bus release.
            try:
                if response is not None:
                    try:
                        response.close()
                    except BaseException:
                        pass
            finally:
                try:
                    if conn is not None:
                        try:
                            conn.close()
                        except BaseException:
                            pass
                finally:
                    self.bus.release(owner)
                    # Restore only after every TLS/HTTP resource has been closed.
                    # A pending Ctrl+C may run the cooperative handler here, at
                    # a safe Python boundary instead of inside ssl.read().
                    _restore_sigint_mask(sigint_mask)

    def get_bytes(self, url: str, *, timeout: float | None = None, max_bytes: int = 12 * 1024 * 1024) -> bytes:
        """Bounded HTTPS binary download using the same serialized network bus.

        Used by Daniel AI Voice to fetch Telegram voice files. The method never
        follows redirects and caps the body before it can grow in memory.
        """
        effective = max(1.0, min(float(timeout or self.timeout), 15.0))
        parsed = urlsplit(url)
        if parsed.scheme != "https" or not parsed.hostname:
            raise ValueError("v10 aceita apenas URLs HTTPS válidas")
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        limit = max(1024, min(int(max_bytes), 32 * 1024 * 1024))
        headers = dict(self.headers)
        headers["Accept"] = "*/*"
        self._seq += 1
        owner = f"{self.label}:{self._seq}"
        self.bus.acquire(owner, self.label)
        conn = None
        response = None
        sigint_mask = _block_sigint_during_tls()
        try:
            conn = self._connection(parsed.hostname, parsed.port, effective)
            conn.request("GET", path, headers=headers)
            response = conn.getresponse()
            status = int(response.status)
            if status in {408, 425, 429, 500, 502, 503, 504} and status not in self.preserve_http_statuses:
                retry_after = 0
                if status == 429:
                    try:
                        retry_after = max(0, int(str(response.getheader("Retry-After") or "0").strip()))
                    except (TypeError, ValueError):
                        retry_after = 0
                raise TransientNetworkError(
                    f"Serviço temporariamente indisponível (HTTP {status}).",
                    status=status,
                    retry_after=retry_after,
                )
            if status >= 400:
                raise NetworkHTTPError(status, {}, url)
            length = response.getheader("Content-Length")
            if length:
                try:
                    if int(length) > limit:
                        raise NetworkHTTPError(413, {"error": "arquivo acima do limite"}, url)
                except ValueError:
                    pass
            raw = response.read(limit + 1)
            if len(raw) > limit:
                raise NetworkHTTPError(413, {"error": "arquivo acima do limite"}, url)
            return bytes(raw)
        except NetworkHTTPError:
            raise
        except TransientNetworkError:
            raise
        except (socket.timeout, TimeoutError) as exc:
            raise TransientNetworkError("Timeout de rede/TLS.") from exc
        except ssl.SSLError as exc:
            raise TransientNetworkError(f"Falha TLS transitória: {exc}") from exc
        except (OSError, http.client.HTTPException) as exc:
            raise TransientNetworkError(f"Falha HTTPS transitória: {type(exc).__name__}: {exc}") from exc
        finally:
            try:
                if response is not None:
                    try:
                        response.close()
                    except BaseException:
                        pass
            finally:
                try:
                    if conn is not None:
                        try:
                            conn.close()
                        except BaseException:
                            pass
                finally:
                    self.bus.release(owner)
                    _restore_sigint_mask(sigint_mask)

    def post_multipart(self, url: str, *, fields: dict[str, Any] | None = None, file_field: str,
                       filename: str, file_bytes: bytes, content_type: str = "application/octet-stream",
                       timeout: float | None = None, max_response_bytes: int = 4 * 1024 * 1024) -> Any:
        """Bounded multipart/form-data POST on the shared serialized network bus."""
        import secrets
        effective = max(1.0, min(float(timeout or self.timeout), 30.0))
        parsed = urlsplit(url)
        if parsed.scheme != "https" or not parsed.hostname:
            raise ValueError("v10 aceita apenas URLs HTTPS válidas")
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        boundary = "----CSM" + secrets.token_hex(12)
        chunks: list[bytes] = []
        for key, value in (fields or {}).items():
            chunks.append((f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n{value}\r\n").encode("utf-8"))
        safe_name = str(filename or "audio.ogg").replace('"', "")
        chunks.append((f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; filename=\"{safe_name}\"\r\nContent-Type: {content_type}\r\n\r\n").encode("utf-8"))
        chunks.append(bytes(file_bytes))
        chunks.append(f"\r\n--{boundary}--\r\n".encode("ascii"))
        body = b"".join(chunks)
        headers = dict(self.headers)
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
        headers["Content-Length"] = str(len(body))
        self._seq += 1
        owner = f"{self.label}:{self._seq}"
        self.bus.acquire(owner, self.label)
        conn = None
        response = None
        sigint_mask = _block_sigint_during_tls()
        try:
            conn = self._connection(parsed.hostname, parsed.port, effective)
            conn.request("POST", path, body=body, headers=headers)
            response = conn.getresponse()
            raw = response.read(max_response_bytes)
            status = int(response.status)
            text = raw.decode("utf-8", errors="replace") if raw else ""
            try:
                payload = json.loads(text) if text else {}
            except json.JSONDecodeError:
                payload = {"raw": text[:1000]}
            if status in {408, 425, 429, 500, 502, 503, 504} and status not in self.preserve_http_statuses:
                retry_after = 0
                if status == 429:
                    try:
                        retry_after = max(0, int(str(response.getheader("Retry-After") or "0").strip()))
                    except (TypeError, ValueError):
                        retry_after = 0
                raise TransientNetworkError(
                    f"Serviço temporariamente indisponível (HTTP {status}).",
                    status=status,
                    retry_after=retry_after,
                )
            if status >= 400:
                raise NetworkHTTPError(status, payload, url)
            return payload
        except NetworkHTTPError:
            raise
        except TransientNetworkError:
            raise
        except (socket.timeout, TimeoutError) as exc:
            raise TransientNetworkError("Timeout de rede/TLS.") from exc
        except ssl.SSLError as exc:
            raise TransientNetworkError(f"Falha TLS transitória: {exc}") from exc
        except (OSError, http.client.HTTPException) as exc:
            raise TransientNetworkError(f"Falha HTTPS transitória: {type(exc).__name__}: {exc}") from exc
        finally:
            try:
                if response is not None:
                    try:
                        response.close()
                    except BaseException:
                        pass
            finally:
                try:
                    if conn is not None:
                        try:
                            conn.close()
                        except BaseException:
                            pass
                finally:
                    self.bus.release(owner)
                    _restore_sigint_mask(sigint_mask)

    def get_json(self, url: str, params=None, timeout: float | None = None) -> Any:
        return self.request_json("GET", url, params=params, timeout=timeout).payload

    def post_json(self, url: str, data=None, timeout: float | None = None) -> Any:
        return self.request_json("POST", url, data=data, timeout=timeout).payload
