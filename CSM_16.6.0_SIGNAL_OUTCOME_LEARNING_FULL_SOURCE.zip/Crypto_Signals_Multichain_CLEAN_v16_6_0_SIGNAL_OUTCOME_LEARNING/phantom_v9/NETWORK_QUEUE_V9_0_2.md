# Phantom Alert v9.0.2 — Network Queue

Hotfix específico para a-Shell/iOS após a limitação "Only one curl command at a time".

## Contrato ativo

- um único interpretador Python;
- no máximo **1 processo curl ativo** em todo o bot;
- Telegram, market, Asaas e scanner compartilham a mesma fila global;
- o scanner usa curl cooperativo e mantém a lease até o filho encerrar;
- enquanto o scanner possui a lease, `getUpdates` não inicia outro curl e devolve o controle ao scheduler;
- transportes por serviço mantêm headers separados, mas usam o mesmo árbitro;
- monitor de posições permanece cache-only no a-Shell;
- PID continua apenas diagnóstico; vida do runtime é sessão + heartbeat.

O objetivo é eliminar concorrência de curl sem voltar a multiprocessing, threads ou HTTP nativo instável no iOS.
