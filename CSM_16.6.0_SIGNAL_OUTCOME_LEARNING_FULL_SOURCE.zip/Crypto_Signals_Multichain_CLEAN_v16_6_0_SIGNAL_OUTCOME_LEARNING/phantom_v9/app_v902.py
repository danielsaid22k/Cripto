from __future__ import annotations

import time
from collections import deque
from datetime import datetime, timezone
from html import escape

from csm.chains import CHAINS, detect_chain, normalize_chain
from csm.config import settings
from csm.experience import BRAND_DIVIDER, activated_text, interval_label, opportunity_profile, plan_group, project_stage, signal_reasons
from csm.formatting import compact_address, report
from csm.logging_setup import logger
from csm.plans import PLANS
from csm.storage import Storage
from csm.user_profiles import UserProfileStore

from .market import MarketService
from .network import TransientNetworkError
from .network_v902 import QueuedCurlTransportV902, CooperativeCurlTransportV902, global_curl_queue, NetworkBusyError
from .payments import PaymentServiceV9, AsaasClientV9, only_digits, valid_document
from .runtime_v902 import RuntimeGuardV902
from .scanner_v902 import ScannerEngineV902
from .telegram_v902 import TelegramClientV902
from . import ui


class PhantomAppV902:
    """Clean orchestration layer with one global a-Shell curl queue.

    Runtime rule: UI handlers are local and fast. Network work is only performed
    by explicit analysis/payment actions or by the cooperative scheduler. The
    scanner is never started from the "Sinais automáticos" button.
    """

    def __init__(self, storage=None, transport=None, telegram=None):
        self.storage=storage or Storage()
        self.network_queue=global_curl_queue()
        # Every active curl client uses the SAME process-global queue. Separate
        # transport objects keep service-specific headers isolated while the
        # queue guarantees a-Shell never sees concurrent curl commands.
        self.transport=transport or QueuedCurlTransportV902(timeout=4,connect_timeout=2,queue=self.network_queue,label="telegram")
        self.telegram=telegram or (TelegramClientV902(transport=self.transport) if settings.telegram_token else None)
        market_transport=transport or QueuedCurlTransportV902(timeout=4,connect_timeout=2,queue=self.network_queue,label="market")
        self.market=MarketService(transport=market_transport)
        scanner_transport=CooperativeCurlTransportV902(timeout=3.0,connect_timeout=1.5,queue=self.network_queue)
        self.scanner=ScannerEngineV902(transport=scanner_transport,providers=self.market.providers)
        self.user_profiles=UserProfileStore()
        self.payments=None
        if settings.payments_ready:
            try:
                asaas_transport=QueuedCurlTransportV902(timeout=5,connect_timeout=2,queue=self.network_queue,label="asaas")
                self.payments=PaymentServiceV9(self.storage,client=AsaasClientV9(transport=asaas_transport))
            except Exception as exc: logger.warning("Asaas não inicializado: %s",exc)
        self.pending_chain:dict[int,str|None]={}; self.pending_payment:dict[int,dict]={}; self.scanner_sessions:dict[int,list[dict]]={}
        self.manual_scan_users:set[int]=set(); self.pending_groups:list[tuple[str,int]]=[]
        self.started_at=datetime.now(timezone.utc); self.next_cycle={"premium":0.0,"plus":0.0,"free":0.0}
        self.position_queue=deque(); self.favorite_queue=deque(); self.last_position_reload=0.0; self.last_favorite_reload=0.0
        self.next_payment_check=0.0; self.next_expiry_check=0.0; self.next_reminder_check=0.0
        self._last_scanner_progress_seen=0.0; self._last_degraded_notice=0.0
        self.background_network_policy="scanner_lane_only"

    # ---------- screens ----------
    def scheduler_status(self,user_id:int|None=None)->dict:
        now=time.monotonic(); user=self.storage.get_user(user_id) if user_id else {"plan":"free"}; group=plan_group(user.get("plan")); due=self.next_cycle.get(group,0.0)
        sec=max(0,int(due-now)) if due else 0
        return {"scanner_active":self.scanner.active,"next_cycle_text":("agora" if sec<=0 else f"{sec}s"),"prefs":self.storage.user_preferences(user_id) if user_id else {}}

    def history_screen(self,user_id:int,page:int=0):
        user=self.storage.get_user(user_id); allowed=PLANS[user["plan"]]["history"]; size=settings.history_page_size; total=min(self.storage.history_count(user_id),allowed); max_page=max(0,(total-1)//size); page=max(0,min(page,max_page)); rows=self.storage.history(user_id,size,page*size)
        lines=["🧾 <b>HISTÓRICO DE ANÁLISES</b>",""]
        if not rows: lines.append("Nenhuma análise registrada.")
        for row in rows:
            chain=CHAINS.get(row["chain"],{"emoji":"🌐","label":row["chain"]}); name=row.get("token_symbol") or row.get("token_name") or "Token"
            lines.append(f"{chain['emoji']} <b>{escape(str(name))}</b> • {row['score']}/100\n<code>{escape(compact_address(row['address']))}</code>")
        lines.append(f"\nPágina <b>{page+1}/{max_page+1}</b>")
        nav=[]
        if page>0: nav.append({"text":"⬅️ Anterior","callback_data":f"history|{page-1}"})
        if page<max_page: nav.append({"text":"Próxima ➡️","callback_data":f"history|{page+1}"})
        kb={"inline_keyboard":([nav] if nav else [])+[[{"text":"🏠 Menu","callback_data":"menu"}]]}
        return "\n\n".join(lines),kb

    def favorites_screen(self,user_id:int):
        rows=self.storage.favorites(user_id,limit=100); lines=["⭐ <b>FAVORITOS</b>",""]
        kb=[]
        if not rows: lines.append("Nenhum token favoritado.")
        for row in rows[:20]:
            name=row.get("token_symbol") or row.get("token_name") or "Token"; chain=row["chain"]; address=row["address"]
            lines.append(f"• <b>{escape(str(name))}</b> • {escape(chain)}\n<code>{escape(compact_address(address))}</code>")
            kb.append([{"text":f"🔎 {str(name)[:16]}","callback_data":f"refresh|{chain}|{address}"},{"text":"🗑","callback_data":f"unfavorite|{chain}|{address}"}])
        kb.append([{"text":"🏠 Menu","callback_data":"menu"}])
        return "\n\n".join(lines),{"inline_keyboard":kb}

    def scanner_screen(self,user_id:int,page:int=0):
        results=self.scanner_sessions.get(user_id,self.scanner.last_results); stats=self.scanner.last_stats; page_size=3; total=max(1,(len(results)+page_size-1)//page_size); page=max(0,min(page,total-1)); current=results[page*page_size:(page+1)*page_size]
        lines=["🚀 <b>SCANNER MULTICHAIN</b>","",f"Descobertos: <b>{stats.get('discovered',0)}</b> • Analisados: <b>{stats.get('analyzed',0)}</b> • Aprovados: <b>{stats.get('approved',0)}</b>"]
        kb=[]
        if not current: lines += ["","Nenhuma oportunidade em cache. Use Novo ciclo; a execução continuará em segundo plano."]
        for idx,item in enumerate(current,start=page*page_size+1):
            score=int(item.get("opportunity_score") or item.get("score") or 0); sym=escape(str(item.get("symbol") or item.get("name") or "Token")); lines += ["",f"🟢 <b>{idx}. {sym}</b> • {escape(str(item.get('chain') or '?'))}",f"⭐ {score}/100 • 💧 US$ {float(item.get('liquidity') or 0):,.0f} • 📈 US$ {float(item.get('volume24h') or 0):,.0f}"]
            kb.append([{"text":f"🔎 Detalhes {idx}","callback_data":f"scanner_detail|{idx-1}"}])
        nav=[]
        if page>0:nav.append({"text":"⬅️","callback_data":f"scanner_page|{page-1}"})
        if page+1<total:nav.append({"text":"➡️","callback_data":f"scanner_page|{page+1}"})
        if nav:kb.append(nav)
        kb += [[{"text":"🔄 Novo ciclo","callback_data":"scanner_force"}],[{"text":"🏠 Menu","callback_data":"menu"}]]
        return "\n".join(lines),{"inline_keyboard":kb}

    # ---------- payment ----------
    def payment_keyboard(self,plan):
        rows=[]; methods=set(settings.asaas_payment_methods)
        if "PIX" in methods:rows.append([{"text":"⚡ PIX","callback_data":f"paymethod|{plan}|PIX"}])
        if "CREDIT_CARD" in methods:rows.append([{"text":"💳 Cartão","callback_data":f"paymethod|{plan}|CREDIT_CARD"}])
        rows.append([{"text":"⬅️ Planos","callback_data":"plans"}]); return {"inline_keyboard":rows}

    # ---------- analysis ----------
    def analyze(self,user_id:int,chain:str,address:str,force=False):
        user=self.storage.get_user(user_id); plan=PLANS[user["plan"]]
        if user.get("blocked"): return "⛔ Conta bloqueada.",ui.user_keyboard(user)
        if plan["chains"]!="all" and chain not in plan["chains"]: return "⛔ Esta rede exige plano pago.",ui.sales_keyboard(bool(self.payments))
        if plan["limit"] is not None and self.storage.count_today(user_id)>=plan["limit"]: return "⛔ Limite diário atingido.",ui.user_keyboard(user)
        market=self.market.fetch(chain,address,force=force); text,score=report(market,user["plan"]); self.storage.save_analysis(user_id,chain,address,score,market)
        kb={"inline_keyboard":[[{"text":"🔄 Atualizar","callback_data":f"refresh|{chain}|{address}"},{"text":"⭐ Favoritar","callback_data":f"favorite|{chain}|{address}"}],[{"text":"📋 Copiar contrato","callback_data":f"copy|{chain}|{address}"}],[{"text":"🏠 Menu","callback_data":"menu"}]]}
        return text,kb

    # ---------- callbacks ----------
    def callback(self,cb:dict):
        cid=cb.get("id",""); data=str(cb.get("data") or ""); msg=cb.get("message") or {}; chat_id=(msg.get("chat") or {}).get("id"); message_id=msg.get("message_id"); sender=cb.get("from") or {}; user_id=int(sender.get("id") or chat_id)
        self.telegram.answer_callback(cid)
        user=self.storage.upsert_user(user_id,sender.get("username",""),sender.get("first_name",""))
        try:
            if data in {"enter_app","menu"}: return self.telegram.edit_or_send(chat_id,message_id,ui.main_menu(user,sender.get("first_name","")),ui.user_keyboard(user))
            if data=="plans": return self.telegram.edit_or_send(chat_id,message_id,ui.plans_text(),ui.sales_keyboard(bool(self.payments)))
            if data=="my_plan": return self.telegram.edit_or_send(chat_id,message_id,ui.subscription_text(self.storage,user),{"inline_keyboard":[[{"text":"💎 Planos","callback_data":"plans"}],[{"text":"🏠 Menu","callback_data":"menu"}]]})
            if data=="dashboard":
                text,kb=ui.dashboard_screen(self,user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data=="intelligence_center":
                text,kb=ui.central_screen(self,user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data=="preferences":
                text,kb=ui.preferences_screen(self,user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data.startswith("pref|"):
                name=data.split("|",1)[1]
                if name in {"auto_signals","favorite_alerts","expiry_alerts"}: self.storage.toggle_user_preference(user_id,name)
                text,kb=ui.preferences_screen(self,user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data.startswith("profile|"):
                action=data.split("|",1)[1]; fn={"risk":self.user_profiles.cycle_risk_profile,"chains":self.user_profiles.cycle_chains,"detail":self.user_profiles.cycle_detail_mode,"frequency":self.user_profiles.cycle_notification_frequency,"quiet":self.user_profiles.cycle_quiet_hours,"language":self.user_profiles.cycle_language}.get(action)
                if fn:fn(user_id)
                text,kb=ui.preferences_screen(self,user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data.startswith("history|"):
                text,kb=self.history_screen(user_id,int(data.split("|",1)[1])); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data=="favorites":
                text,kb=self.favorites_screen(user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data=="export_user": return self.telegram.edit_or_send(chat_id,message_id,ui.export_text(self.storage.export_user_data(user_id)),{"inline_keyboard":[[{"text":"🏠 Menu","callback_data":"menu"}]]})
            if data in {"scanner","scanner_noop"}:
                text,kb=self.scanner_screen(user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data=="scanner_force":
                self.manual_scan_users.add(user_id)
                if not self.scanner.active:self.scanner.start()
                return self.telegram.edit_or_send(chat_id,message_id,"⏳ <b>Novo ciclo agendado.</b>\nO bot continua respondendo; o resultado será enviado ao concluir.",{"inline_keyboard":[[{"text":"🏠 Menu","callback_data":"menu"}]]})
            if data.startswith("scanner_page|"):
                text,kb=self.scanner_screen(user_id,int(data.split("|",1)[1])); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
            if data.startswith("scanner_detail|"):
                idx=int(data.split("|",1)[1]); rows=self.scanner_sessions.get(user_id,self.scanner.last_results)
                if 0<=idx<len(rows):
                    item=rows[idx]; return self.telegram.edit_or_send(chat_id,message_id,f"🔎 <b>{escape(str(item.get('symbol') or item.get('name') or 'Token'))}</b>\nScore: <b>{int(item.get('opportunity_score') or item.get('score') or 0)}/100</b>\nContrato: <code>{escape(str(item.get('address') or ''))}</code>",{"inline_keyboard":[[{"text":"🔍 Analisar","callback_data":f"refresh|{item.get('chain')}|{item.get('address')}"}],[{"text":"⬅️ Scanner","callback_data":"scanner"}]]})
            if data.startswith(("copy|","favorite|","unfavorite|","refresh|")):
                action,chain,address=data.split("|",2)
                if action=="copy": return self.telegram.edit_or_send(chat_id,message_id,f"📋 Contrato:\n<code>{escape(address)}</code>",{"inline_keyboard":[[{"text":"🏠 Menu","callback_data":"menu"}]]})
                if action=="favorite":
                    try:m=self.market.cache.get((chain,address),(0,{"chain":chain,"address":address,"name":"Token","symbol":"?","price":0}))[1]; self.storage.add_favorite(user_id,chain,address,m); note="⭐ Favorito salvo."
                    except Exception as exc: note=f"⚠️ Não foi possível favoritar: {escape(str(exc))}"
                    return self.telegram.send(chat_id,note,ui.user_keyboard(user))
                if action=="unfavorite": self.storage.remove_favorite(user_id,chain,address); text,kb=self.favorites_screen(user_id); return self.telegram.edit_or_send(chat_id,message_id,text,kb)
                try:
                    self.telegram.edit_or_send(chat_id,message_id,"⏳ Consultando mercado...")
                    text,kb=self.analyze(user_id,chain,address,force=True); return self.telegram.send(chat_id,text,kb)
                except Exception as exc:return self.telegram.send(chat_id,f"⚠️ Análise indisponível: {escape(str(exc))}",ui.user_keyboard(user))
            if data.startswith("subscribe|"):
                plan=data.split("|",1)[1]
                if not self.payments:return self.telegram.edit_or_send(chat_id,message_id,"⚠️ Pagamentos automáticos não configurados.",ui.sales_keyboard(False))
                meta=PLANS.get(plan)
                if not meta:return None
                return self.telegram.edit_or_send(chat_id,message_id,f"💳 <b>{meta['label']}</b>\nValor: <b>R$ {meta['value']:.2f}</b>\nAcesso: <b>{meta['days']} dias</b>",self.payment_keyboard(plan))
            if data.startswith("paymethod|"):
                _,plan,method=data.split("|",2); full=" ".join(x for x in [sender.get("first_name",""),sender.get("last_name","")] if x).strip(); self.pending_payment[user_id]={"plan":plan,"name":full or f"Cliente Telegram {user_id}","billing_type":method}
                return self.telegram.edit_or_send(chat_id,message_id,"🪪 Envie somente seu <b>CPF ou CNPJ</b>. Para cancelar, /cancelar.")
            if data=="payment_check": return self.verify_payment(chat_id,user_id)
            return self.telegram.send(chat_id,"⚠️ Ação não reconhecida. Abra o menu novamente.",ui.user_keyboard(user))
        except Exception as exc:
            logger.exception("Callback v9 falhou")
            return self.telegram.send(chat_id,f"⚠️ Esta tela encontrou um erro isolado: {escape(type(exc).__name__)}. O bot continua online.",ui.user_keyboard(user))

    # ---------- messages ----------
    def message(self,msg:dict):
        chat=msg.get("chat") or {}; sender=msg.get("from") or {}; user_id=int(sender.get("id") or chat.get("id")); chat_id=chat.get("id"); text=(msg.get("text") or "").strip(); lower=text.lower(); user=self.storage.upsert_user(user_id,sender.get("username",""),sender.get("first_name",""))
        if user_id in self.pending_payment:
            if lower=="/cancelar":self.pending_payment.pop(user_id,None); return self.telegram.send(chat_id,"✅ Cobrança cancelada.",ui.user_keyboard(user))
            if not valid_document(text):return self.telegram.send(chat_id,"❌ CPF/CNPJ inválido. Envie novamente ou /cancelar.",ui.user_keyboard(user))
            pending=self.pending_payment.pop(user_id)
            try:
                row=self.payments.create_payment(user_id=user_id,plan=pending["plan"],name=pending["name"],cpf_cnpj=only_digits(text),billing_type=pending["billing_type"]); kb={"inline_keyboard":[[{"text":"Abrir pagamento","url":row.get("invoice_url")}],[{"text":"✅ Já paguei","callback_data":"payment_check"}]]}; extra=f"\n\nPIX: <code>{escape(str(row.get('pix_payload') or ''))}</code>" if row.get("pix_payload") else ""; return self.telegram.send(chat_id,"✅ Cobrança criada."+extra,kb)
            except Exception as exc:return self.telegram.send(chat_id,f"❌ Falha ao criar cobrança: {escape(str(exc))}",ui.sales_keyboard(bool(self.payments)))
        if lower=="/start":
            t,k=ui.welcome(user,sender.get("first_name","")); return self.telegram.send(chat_id,t,k)
        if lower in {"💎 planos","👑 conhecer premium","/planos"}:return self.telegram.send(chat_id,ui.plans_text(),ui.sales_keyboard(bool(self.payments)))
        if lower in {"👤 meu plano","👤 minha assinatura","/meuplano"}:return self.telegram.send(chat_id,ui.subscription_text(self.storage,user),ui.user_keyboard(user))
        if lower in {"🟢 status","/status"}:return self.telegram.send(chat_id,ui.status_text(user,self.scheduler_status(user_id)),ui.user_keyboard(user))
        if lower in {"📡 sinais automáticos","🚀 scanner","/scanner"}:
            return self.telegram.send(chat_id,ui.auto_signals_text(user,self.scheduler_status(user_id)),ui.user_keyboard(user))
        if lower in {"🧠 minha central","/central","/minhaconta"}:t,k=ui.central_screen(self,user_id); return self.telegram.send(chat_id,t,k)
        if lower in {"👑 central premium","⚙️ painel","/painel"}:t,k=ui.dashboard_screen(self,user_id); return self.telegram.send(chat_id,t,k)
        if lower in {"🎛️ preferências","⚙️ preferências","/preferencias"}:t,k=ui.preferences_screen(self,user_id); return self.telegram.send(chat_id,t,k)
        if lower in {"🧾 histórico","/historico"}:t,k=self.history_screen(user_id,0); return self.telegram.send(chat_id,t,k)
        if lower in {"⭐ favoritos","/favoritos"}:t,k=self.favorites_screen(user_id); return self.telegram.send(chat_id,t,k)
        if lower in {"🌐 redes","/redes"}:return self.telegram.send(chat_id,ui.networks_text(),ui.user_keyboard(user))
        if lower in {"🔍 analisar","/analisar"}:self.pending_chain[user_id]=None; return self.telegram.send(chat_id,"🔍 Envie o contrato. A rede será detectada automaticamente.",ui.user_keyboard(user))
        if lower.startswith("/analisar "):
            parts=text.split(); address=parts[-1]; chain=normalize_chain(parts[1]) if len(parts)>2 else detect_chain(address)
            if not chain:return self.telegram.send(chat_id,"❌ Rede não reconhecida.",ui.user_keyboard(user))
            return self._send_analysis(chat_id,user_id,chain,address)
        detected=detect_chain(text)
        if detected:return self._send_analysis(chat_id,user_id,detected,text)
        return self.telegram.send(chat_id,"Comando desconhecido. Use /start.",ui.user_keyboard(user))

    def _send_analysis(self,chat_id,user_id,chain,address):
        try:
            self.telegram.send(chat_id,"⏳ Analisando mercado...")
            text,kb=self.analyze(user_id,chain,address); return self.telegram.send(chat_id,text,kb)
        except Exception as exc:return self.telegram.send(chat_id,f"⚠️ Análise temporariamente indisponível: {escape(str(exc))}",ui.user_keyboard(self.storage.get_user(user_id)))

    def verify_payment(self,chat_id,user_id):
        if not self.payments:return self.telegram.send(chat_id,"⚠️ Asaas não configurado.",ui.user_keyboard(self.storage.get_user(user_id)))
        try:
            results=self.payments.verify_user(user_id); user=self.storage.get_user(user_id)
            if user["plan"]!="free":return self.telegram.send(chat_id,activated_text(user),ui.user_keyboard(user))
            if any(x["state"]=="pending" for x in results):return self.telegram.send(chat_id,"⏳ Pagamento ainda pendente.",ui.sales_keyboard(True))
            return self.telegram.send(chat_id,"ℹ️ Nenhum pagamento confirmado.",ui.sales_keyboard(True))
        except Exception as exc:return self.telegram.send(chat_id,f"⚠️ Falha na verificação: {escape(str(exc))}",ui.user_keyboard(self.storage.get_user(user_id)))

    # ---------- scheduler ----------
    @staticmethod
    def _compact_usd(v):
        v=float(v or 0)
        return f"US$ {v/1_000_000:.2f} mi" if abs(v)>=1_000_000 else f"US$ {v/1000:.1f} mil" if abs(v)>=1000 else f"US$ {v:,.0f}"

    def _signal_text(self,item,plan):
        profile=opportunity_profile(item); score=int(profile["opportunity_score"]); symbol=escape(str(item.get("symbol") or item.get("name") or "Token")); chain=escape(str(item.get("chain") or "?")); address=escape(str(item.get("address") or "")); price=float(item.get("price") or 0); reasons="\n".join("✓ "+escape(x) for x in signal_reasons(item,3)); stage_emoji,stage=project_stage(item)
        return (f"{BRAND_DIVIDER}\n🚀 <b>PHANTOM ALERT • SINAL</b>\n{BRAND_DIVIDER}\n\n🪙 <b>{symbol}</b> • {chain}\n⭐ Score: <b>{score}/100</b>\n{stage_emoji} Estágio: <b>{escape(stage)}</b>\n💧 Liquidez: <b>{self._compact_usd(item.get('liquidity'))}</b>\n📈 Volume 24h: <b>{self._compact_usd(item.get('volume24h'))}</b>\n\n🧠 <b>POR QUE APARECEU</b>\n{reasons}\n\n💲 Entrada observada: <code>{price:.12g}</code>\n📄 Contrato: <code>{address}</code>\n\n⚠️ <i>Sinal educacional; não constitui recomendação.</i>")

    def deliver_signals(self,group:str,results:list[dict]):
        summary={"users":0,"sent":0,"candidates":len(results),"approved":len(results),"eligible":0,"duplicates":0,"errors":0,"top_score":max((int(x.get("opportunity_score") or x.get("score") or 0) for x in results),default=0)}
        self.storage.prune_alert_deliveries(settings.signal_alert_cooldown_hours)
        for user in self.storage.signal_users(group):
            prefs=self.storage.user_preferences(int(user["user_id"])); profile=self.user_profiles.get(int(user["user_id"]))
            if not prefs.get("auto_signals",True) or self.user_profiles.is_quiet(profile):continue
            preferred=set(profile.get("preferred_chains") or []); selected=[x for x in results if (not preferred or x.get("chain") in preferred) and int(x.get("opportunity_score") or x.get("score") or 0)>=settings.auto_signal_min_score][:settings.auto_signal_limit]; summary["eligible"]+=len(selected); summary["users"]+=1
            for item in selected:
                chain=str(item.get("chain") or ""); address=str(item.get("address") or "")
                if not chain or not address:continue
                if not self.storage.mark_alert_delivery(int(user["user_id"]),chain,address,"entry",int(item.get("opportunity_score") or item.get("score") or 0)):summary["duplicates"]+=1;continue
                try:
                    kb={"inline_keyboard":[[{"text":"🔎 Analisar","callback_data":f"refresh|{chain}|{address}"},{"text":"⭐ Favoritar","callback_data":f"favorite|{chain}|{address}"}]]}
                    self.telegram.send(int(user["user_id"]),self._signal_text(item,str(user.get("plan") or "free")),kb); price=float(item.get("price") or 0)
                    if price>0:self.storage.create_signal_position(user_id=int(user["user_id"]),chain=chain,address=address,symbol=str(item.get("symbol") or item.get("name") or "Token"),entry_price=price,target1_price=price*(1+settings.signal_target1_pct/100),target2_price=price*(1+settings.signal_target2_pct/100),stop_price=price*(1-settings.signal_stop_pct/100))
                    summary["sent"]+=1
                except Exception:summary["errors"]+=1
        return summary

    def _cached_market_for_position(self, position: dict):
        chain=str(position.get("chain") or ""); address=str(position.get("address") or "").lower()
        for item in self.scanner.last_results:
            if str(item.get("chain") or "") == chain and str(item.get("address") or "").lower() == address:
                return item
        return None

    def _process_cached_position(self, p: dict) -> None:
        market=self._cached_market_for_position(p)
        if not market:
            return
        price=float(market.get("price") or 0); entry=float(p["entry_price"] or 0)
        if not price or not entry:
            return
        change=((price/entry)-1)*100; peak=max(float(p.get("peak_price") or 0),price); text=None; updates={}
        if not p["stop_sent"] and price<=float(p["stop_price"]):
            text=f"🛑 <b>ALERTA DE SAÍDA</b>\n{escape(p['symbol'])}: {change:+.1f}%"; updates={"stop_sent":True,"status":"CLOSED","last_price":price,"peak_price":peak,"result_pct":change,"outcome":"STOP"}
        elif not p["target2_sent"] and price>=float(p["target2_price"]):
            text=f"🏆 <b>ALVO 2</b>\n{escape(p['symbol'])}: {change:+.1f}%"; updates={"target1_sent":True,"target2_sent":True,"status":"CLOSED","last_price":price,"peak_price":peak,"result_pct":change,"outcome":"TARGET2"}
        elif not p["target1_sent"] and price>=float(p["target1_price"]):
            text=f"🎯 <b>ALVO 1</b>\n{escape(p['symbol'])}: {change:+.1f}%"; updates={"target1_sent":True,"last_price":price,"peak_price":peak,"result_pct":change,"outcome":"TARGET1"}
        if text:
            self.telegram.send(int(p["user_id"]),text,ui.MAIN_KEYBOARD); self.storage.update_signal_position(int(p["id"]),**updates)
        else:
            self.storage.update_signal_position(int(p["id"]),last_price=price,peak_price=peak,result_pct=change)

    def _scheduler_step(self):
        now=time.monotonic()
        if self.scanner.active:
            result=self.scanner.step()
            if result is not None:
                for uid in list(self.manual_scan_users):
                    self.scanner_sessions[uid]=[dict(x) for x in result]
                    t,k=self.scanner_screen(uid); self.telegram.send(uid,t,k)
                self.manual_scan_users.clear()
                groups=list(self.pending_groups); self.pending_groups.clear()
                for group,interval in groups:
                    summary=self.deliver_signals(group,result); self.storage.record_scanner_cycle(group,summary); self.next_cycle[group]=time.monotonic()+interval
                    print(f"🚀 Scanner {group}: aprovados={summary['approved']} enviados={summary['sent']} erros={summary['errors']} próximo={interval//60}min",flush=True)
                if self.scanner.last_stats.get("aborted"):
                    print(f"⚠️ Scanner degradado: {self.scanner.last_error}. Telegram permanece online.",flush=True)
            return

        if settings.auto_signals_enabled:
            due=[]
            for group,interval in (("premium",settings.auto_scan_interval_premium),("plus",settings.auto_scan_interval_plus),("free",settings.auto_scan_interval_free)):
                if now>=self.next_cycle[group]: due.append((group,interval))
            if due:
                if self.scanner.start():
                    self.pending_groups=due
                else:
                    for group,_ in due: self.next_cycle[group]=now+15
                    if now-self._last_degraded_notice>30:
                        print(f"⚠️ Scanner aguardando recuperação da lane de rede: {self.scanner.last_error or 'ocupada'}",flush=True)
                        self._last_degraded_notice=now
                return

        # v9.0.2: background position monitoring is cache-only. The a-Shell
        # event loop never performs a second blocking market fetch here.
        if settings.signal_monitor_enabled and not self.position_queue and now-self.last_position_reload>=settings.signal_monitor_interval:
            self.position_queue.extend(self.storage.open_signal_positions(limit=100)); self.last_position_reload=now
        if self.position_queue:
            p=self.position_queue.popleft()
            try: self._process_cached_position(p)
            except Exception: logger.exception("Monitor cache-only ignorou posição inválida")
            return

        # Automatic Asaas polling is deferred on the main a-Shell loop. Manual
        # verification remains available from the payment UI.
        if self.payments and settings.payment_auto_check and now>=self.next_payment_check:
            self.next_payment_check=now+max(60,settings.payment_check_interval)
            return

        if now>=self.next_expiry_check:
            self.storage.expire_plans(); self.next_expiry_check=now+300

    def run(self,guard:RuntimeGuardV902|None=None):
        if not settings.telegram_token or not settings.telegram_chat_id:raise RuntimeError("Configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID.")
        me=self.telegram.get_me(); print(f"✅ Telegram conectado como @{me.get('username','bot')}",flush=True); self.telegram.prepare(); print("✅ BOT ONLINE — Ctrl+C para parar",flush=True)
        now=time.monotonic(); self.next_cycle={"premium":now+5,"plus":now+5,"free":now+5}; self.next_payment_check=now+60; self.next_expiry_check=now+10
        print("✅ Runtime v9.0.2: fila global de curl • sessão+heartbeat • UI local",flush=True)
        if guard and guard.recovery_event.recovered:
            print(f"♻️ Sessão anterior obsoleta recuperada automaticamente: {guard.recovery_event.reason}",flush=True)
        offset=None
        while True:
            try:
                health=self.scanner.health_snapshot(); progress=float(self.scanner.last_progress_monotonic or 0.0)
                extra={"scanner_active":self.scanner.active,"scanner_phase":self.scanner.phase,"scanner_last_error":self.scanner.last_error,"scanner_progress_age":health.get("last_progress_age_seconds"),"network_lane":health.get("transport")}
                if guard:
                    if progress and progress != self._last_scanner_progress_seen:
                        self._last_scanner_progress_seen=progress; guard.progress(f"scanner:{self.scanner.phase}",extra=extra)
                    else: guard.beat(extra=extra)
                for update in self.telegram.updates(offset):
                    offset=update["update_id"]+1
                    if update.get("message"):self.message(update["message"])
                    elif update.get("callback_query"):self.callback(update["callback_query"])
                self._scheduler_step()
            except KeyboardInterrupt:print("Bot finalizado.",flush=True);return
            except TransientNetworkError:time.sleep(0.25)
            except Exception as exc:logger.exception("Loop v9.0.2 recuperou de erro");print(f"⚠️ Erro isolado {type(exc).__name__}; continuando...",flush=True);time.sleep(0.25)
