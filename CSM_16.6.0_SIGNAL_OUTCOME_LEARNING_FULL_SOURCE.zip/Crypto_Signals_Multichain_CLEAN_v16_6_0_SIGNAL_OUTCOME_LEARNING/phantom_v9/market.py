from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

from csm.chains import CHAINS
from csm.config import settings
from .network import CurlTransport
from .providers import ProviderGateway


class MarketService:
    def __init__(self, transport=None, providers=None):
        self.transport = transport or CurlTransport(timeout=4, connect_timeout=2)
        self.providers = providers or ProviderGateway()
        self.cache: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}

    def fetch(self, chain: str, address: str, *, force: bool = False) -> dict[str, Any]:
        key = (chain, address)
        cached = self.cache.get(key)
        if not force and cached and time.time() - cached[0] <= settings.cache_ttl:
            row = dict(cached[1]); row["cached"] = True; return row

        gecko_network = (CHAINS.get(chain) or {}).get("gecko")
        if gecko_network:
            payload = self.providers.fetch(
                "GeckoTerminal market",
                lambda: self.transport.get_json(
                    f"https://api.geckoterminal.com/api/v2/networks/{gecko_network}/tokens/{address}/pools",
                    {"page": "1"}, timeout=4,
                ),
                cache_ttl=30, stale_ttl=900, force=force,
            )
            if isinstance(payload, dict) and payload.get("data"):
                result = self._normalize_gecko(payload["data"][0], chain, address)
                self.cache[key] = (time.time(), result)
                return dict(result)

        payload = self.providers.fetch(
            "DexScreener market",
            lambda: self.transport.get_json(f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}", timeout=4),
            cache_ttl=30, stale_ttl=900, force=force,
        )
        if isinstance(payload, list) and payload:
            best = max(payload, key=lambda p: float((p.get("liquidity") or {}).get("usd") or 0))
            result = self._normalize_dex(best)
            self.cache[key] = (time.time(), result)
            return dict(result)

        if cached:
            row = dict(cached[1]); row["cached"] = True; row["stale_cache"] = True; return row
        raise RuntimeError("Fontes de mercado indisponíveis neste momento.")

    @staticmethod
    def _normalize_dex(pair: dict) -> dict[str, Any]:
        created = pair.get("pairCreatedAt"); age_days = None
        if created:
            age_days = max(0.0, (datetime.now(timezone.utc).timestamp() - float(created) / 1000) / 86400)
        txns = pair.get("txns") or {}; volume = pair.get("volume") or {}; changes = pair.get("priceChange") or {}; token = pair.get("baseToken") or {}
        return {
            "source":"DexScreener","chain":pair.get("chainId"),"name":token.get("name","Token"),"symbol":token.get("symbol","?"),
            "address":token.get("address",""),"price":float(pair.get("priceUsd") or 0),"liquidity":float((pair.get("liquidity") or {}).get("usd") or 0),
            "volume24h":float(volume.get("h24") or 0),"volume6h":float(volume.get("h6") or 0),"volume1h":float(volume.get("h1") or 0),
            "marketcap":float(pair.get("marketCap") or 0),"fdv":float(pair.get("fdv") or 0),"change24h":float(changes.get("h24") or 0),
            "change6h":float(changes.get("h6") or 0),"change1h":float(changes.get("h1") or 0),
            "buys24h":int((txns.get("h24") or {}).get("buys") or 0),"sells24h":int((txns.get("h24") or {}).get("sells") or 0),
            "buys6h":int((txns.get("h6") or {}).get("buys") or 0),"sells6h":int((txns.get("h6") or {}).get("sells") or 0),
            "buys1h":int((txns.get("h1") or {}).get("buys") or 0),"sells1h":int((txns.get("h1") or {}).get("sells") or 0),
            "age_days":age_days,"dex":pair.get("dexId", ""),"pair":pair.get("pairAddress", ""),"url":pair.get("url", ""),"holders":None,"cached":False,
        }

    @staticmethod
    def _normalize_gecko(item: dict, chain: str, address: str) -> dict[str, Any]:
        attrs = item.get("attributes") or {}; txns = attrs.get("transactions") or {}; volume = attrs.get("volume_usd") or {}; changes = attrs.get("price_change_percentage") or {}
        return {
            "source":"GeckoTerminal","chain":chain,"name":attrs.get("name","Token"),"symbol":"?","address":address,
            "price":float(attrs.get("base_token_price_usd") or 0),"liquidity":float(attrs.get("reserve_in_usd") or 0),
            "volume24h":float(volume.get("h24") or 0),"volume6h":float(volume.get("h6") or 0),"volume1h":float(volume.get("h1") or 0),
            "marketcap":float(attrs.get("market_cap_usd") or 0),"fdv":float(attrs.get("fdv_usd") or 0),
            "change24h":float(changes.get("h24") or 0),"change6h":float(changes.get("h6") or 0),"change1h":float(changes.get("h1") or 0),
            "buys24h":int((txns.get("h24") or {}).get("buys") or 0),"sells24h":int((txns.get("h24") or {}).get("sells") or 0),
            "buys6h":int((txns.get("h6") or {}).get("buys") or 0),"sells6h":int((txns.get("h6") or {}).get("sells") or 0),
            "buys1h":int((txns.get("h1") or {}).get("buys") or 0),"sells1h":int((txns.get("h1") or {}).get("sells") or 0),
            "age_days":None,"dex":"","pair":item.get("id", ""),"url":"","holders":None,"cached":False,
        }
