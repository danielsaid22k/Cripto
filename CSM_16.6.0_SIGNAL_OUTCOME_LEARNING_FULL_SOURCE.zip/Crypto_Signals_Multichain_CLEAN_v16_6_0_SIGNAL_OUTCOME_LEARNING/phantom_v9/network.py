from __future__ import annotations

import json
import shutil
import subprocess
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode


class NetworkError(RuntimeError):
    pass


class TransientNetworkError(NetworkError):
    pass


class NetworkHTTPError(NetworkError):
    def __init__(self, status: int, payload: Any, url: str):
        self.status = int(status)
        self.payload = payload
        self.url = url
        super().__init__(f"HTTP {status} ao acessar {url}")


@dataclass(frozen=True)
class NetworkResult:
    payload: Any
    status: int
    elapsed_ms: float


class CurlTransport:
    """Single-request transport for a-Shell.

    It never opens another Python interpreter. Every network operation uses one
    short-lived curl child, waited and reaped synchronously before the next
    operation begins. Therefore at most one external request exists at a time.
    """

    def __init__(self, timeout: float = 4.0, connect_timeout: float = 2.0, binary: str | None = None, runner=None):
        self.binary = binary or shutil.which("curl")
        self.timeout = max(1.0, min(float(timeout), 8.0))
        self.connect_timeout = max(1.0, min(float(connect_timeout), self.timeout))
        self.runner = runner or subprocess.run
        self.headers = {"Accept": "application/json", "User-Agent": "PhantomAlert/9.0"}

    def available(self) -> bool:
        return bool(self.binary)

    def request_json(self, method: str, url: str, *, params=None, data=None, json_data=None, timeout: float | None = None) -> NetworkResult:
        if not self.binary:
            raise TransientNetworkError("curl não está disponível no ambiente.")
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params, doseq=True)
        effective = max(1.0, min(float(timeout or self.timeout), 10.0))
        cmd = [
            self.binary, "--silent", "--show-error", "--location",
            "--connect-timeout", str(self.connect_timeout), "--max-time", str(effective),
            "--request", method.upper(),
        ]
        for key, value in self.headers.items():
            cmd += ["--header", f"{key}: {value}"]
        body = None
        if json_data is not None:
            body = json.dumps(json_data, ensure_ascii=False)
            cmd += ["--header", "Content-Type: application/json"]
        elif data is not None:
            body = urlencode(data, doseq=True)
            cmd += ["--header", "Content-Type: application/x-www-form-urlencoded"]
        if body is not None:
            cmd += ["--data", body]
        cmd += ["--write-out", "\n__PHANTOM_STATUS__:%{http_code}", url]
        started = time.monotonic()
        try:
            proc = self.runner(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                timeout=effective + 1.5, check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise TransientNetworkError("Timeout de rede.") from exc
        except OSError as exc:
            raise TransientNetworkError(f"Falha ao executar curl: {exc}") from exc
        elapsed = (time.monotonic() - started) * 1000
        output = proc.stdout or ""
        marker = "\n__PHANTOM_STATUS__:"
        if marker in output:
            body_text, status_text = output.rsplit(marker, 1)
            try:
                status = int(status_text.strip().splitlines()[0])
            except Exception:
                status = 0
        else:
            body_text, status = output, 0
        if proc.returncode != 0:
            detail = (proc.stderr or "").strip()[:240]
            raise TransientNetworkError(f"curl falhou ({proc.returncode}): {detail or 'rede indisponível'}")
        raw = body_text.strip()
        if not raw:
            payload: Any = {}
        else:
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise TransientNetworkError("Resposta não JSON recebida.") from exc
        if status in {0, 408, 425, 429, 500, 502, 503, 504}:
            raise TransientNetworkError(f"Serviço temporariamente indisponível (HTTP {status or 'desconhecido'}).")
        if status >= 400:
            raise NetworkHTTPError(status, payload, url)
        return NetworkResult(payload, status, elapsed)

    def get_json(self, url: str, params=None, timeout: float | None = None) -> Any:
        return self.request_json("GET", url, params=params, timeout=timeout).payload

    def post_json(self, url: str, data=None, timeout: float | None = None) -> Any:
        return self.request_json("POST", url, data=data, timeout=timeout).payload
