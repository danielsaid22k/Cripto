from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from csm.config import STATE_DIR


class CooperativeNetworkError(RuntimeError):
    pass


@dataclass
class CurlJob:
    job_id: str
    method: str
    url: str
    proc: subprocess.Popen
    stdout_path: Path
    stderr_path: Path
    stdout_handle: Any
    stderr_handle: Any
    started_at: float
    deadline: float
    kill_deadline: float | None = None
    timed_out: bool = False
    finished: bool = False


@dataclass(frozen=True)
class JobResult:
    state: str  # pending | ok | error | timeout | blocked
    payload: Any = None
    status: int = 0
    error: str = ""
    elapsed_ms: float = 0.0


class CooperativeCurlTransportV901:
    """Non-blocking curl lane for scanner/provider traffic.

    The Python runtime never waits in ``subprocess.run`` or ``communicate``.
    stdout/stderr go to small temporary files and the main event loop polls the
    child. A hard deadline stops the scan step without blocking Telegram.
    At most one scanner curl child can exist at a time.
    """

    def __init__(self, timeout: float = 3.0, connect_timeout: float = 1.5, binary: str | None = None):
        self.binary = binary or shutil.which("curl")
        self.timeout = max(1.0, min(float(timeout), 5.0))
        self.connect_timeout = max(1.0, min(float(connect_timeout), self.timeout))
        self.headers = {"Accept": "application/json", "User-Agent": "PhantomAlert/9.0.1"}
        self.runtime_dir = STATE_DIR / "runtime" / "v9" / "curl"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.current: CurlJob | None = None
        self.blocked_reason = ""

    def available(self) -> bool:
        return bool(self.binary)

    def _cleanup_files(self, job: CurlJob) -> None:
        for handle in (job.stdout_handle, job.stderr_handle):
            try:
                handle.close()
            except Exception:
                pass
        for path in (job.stdout_path, job.stderr_path):
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass

    def _release_if_done(self) -> None:
        job = self.current
        if not job:
            return
        try:
            rc = job.proc.poll()
        except Exception:
            rc = None
        if rc is not None and job.finished:
            self._cleanup_files(job)
            self.current = None
            self.blocked_reason = ""

    def start_json(self, method: str, url: str, *, params=None, data=None, json_data=None, timeout: float | None = None) -> CurlJob | None:
        self._release_if_done()
        if self.current is not None:
            return None
        if not self.binary:
            self.blocked_reason = "curl não disponível"
            return None
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params, doseq=True)
        effective = max(1.0, min(float(timeout or self.timeout), 5.0))
        cmd = [
            self.binary, "--silent", "--show-error", "--location",
            "--connect-timeout", str(self.connect_timeout), "--max-time", str(effective),
            "--request", method.upper(),
        ]
        for key, value in self.headers.items():
            cmd += ["--header", f"{key}: {value}"]
        body = None
        if json_data is not None:
            body = json.dumps(json_data, ensure_ascii=False)
            cmd += ["--header", "Content-Type: application/json"]
        elif data is not None:
            body = urlencode(data, doseq=True)
            cmd += ["--header", "Content-Type: application/x-www-form-urlencoded"]
        if body is not None:
            cmd += ["--data", body]
        cmd += ["--write-out", "\n__PHANTOM_STATUS__:%{http_code}", url]
        job_id = uuid.uuid4().hex[:12]
        out_path = self.runtime_dir / f"{job_id}.out"
        err_path = self.runtime_dir / f"{job_id}.err"
        out_handle = out_path.open("wb")
        err_handle = err_path.open("wb")
        started = time.monotonic()
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=out_handle,
                stderr=err_handle,
                stdin=subprocess.DEVNULL,
                close_fds=True,
            )
        except Exception as exc:
            out_handle.close(); err_handle.close()
            out_path.unlink(missing_ok=True); err_path.unlink(missing_ok=True)
            self.blocked_reason = f"falha ao iniciar curl: {type(exc).__name__}: {exc}"
            return None
        job = CurlJob(job_id, method.upper(), url, proc, out_path, err_path, out_handle, err_handle, started, started + effective + 1.0)
        self.current = job
        return job

    @staticmethod
    def _parse_output(text: str) -> tuple[Any, int]:
        marker = "\n__PHANTOM_STATUS__:"
        if marker in text:
            body_text, status_text = text.rsplit(marker, 1)
            try:
                status = int(status_text.strip().splitlines()[0])
            except Exception:
                status = 0
        else:
            body_text, status = text, 0
        raw = body_text.strip()
        if not raw:
            payload: Any = {}
        else:
            payload = json.loads(raw)
        return payload, status

    def poll(self, job: CurlJob) -> JobResult:
        if self.current is not job:
            return JobResult("blocked", error="job não é mais o job ativo")
        now = time.monotonic()
        try:
            rc = job.proc.poll()
        except Exception as exc:
            self.blocked_reason = f"poll falhou: {type(exc).__name__}: {exc}"
            return JobResult("error", error=self.blocked_reason, elapsed_ms=(now-job.started_at)*1000)
        if rc is None:
            if now <= job.deadline:
                return JobResult("pending", elapsed_ms=(now-job.started_at)*1000)
            job.timed_out = True
            if job.kill_deadline is None:
                try:
                    job.proc.terminate()
                except Exception:
                    pass
                job.kill_deadline = now + 0.35
                return JobResult("pending", elapsed_ms=(now-job.started_at)*1000)
            if now <= job.kill_deadline:
                return JobResult("pending", elapsed_ms=(now-job.started_at)*1000)
            try:
                job.proc.kill()
            except Exception:
                pass
            # Never wait here. Mark scanner lane blocked until poll eventually
            # observes the child gone. Telegram loop remains alive.
            self.blocked_reason = "curl excedeu o limite rígido; ciclo abortado"
            return JobResult("timeout", error=self.blocked_reason, elapsed_ms=(now-job.started_at)*1000)

        # Child ended; plain file reads are bounded by curl response size.
        try:
            job.stdout_handle.flush(); job.stderr_handle.flush()
        except Exception:
            pass
        try:
            job.stdout_handle.close(); job.stderr_handle.close()
        except Exception:
            pass
        try:
            output = job.stdout_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            output = ""
        try:
            error_text = job.stderr_path.read_text(encoding="utf-8", errors="replace").strip()[:240]
        except Exception:
            error_text = ""
        elapsed = (now - job.started_at) * 1000
        job.finished = True
        try:
            payload, status = self._parse_output(output)
        except Exception as exc:
            result = JobResult("error", error=f"resposta inválida: {type(exc).__name__}", elapsed_ms=elapsed)
        else:
            if rc != 0:
                result = JobResult("timeout" if job.timed_out else "error", status=status, error=error_text or f"curl rc={rc}", elapsed_ms=elapsed)
            elif status in {0, 408, 425, 429, 500, 502, 503, 504}:
                result = JobResult("error", status=status, error=f"HTTP transitório {status or 'desconhecido'}", elapsed_ms=elapsed)
            elif status >= 400:
                result = JobResult("error", payload=payload, status=status, error=f"HTTP {status}", elapsed_ms=elapsed)
            else:
                result = JobResult("ok", payload=payload, status=status, elapsed_ms=elapsed)
        self._cleanup_files(job)
        self.current = None
        self.blocked_reason = ""
        return result

    def health(self) -> dict[str, Any]:
        self._release_if_done()
        job = self.current
        return {
            "available": self.available(),
            "busy": job is not None,
            "job_id": job.job_id if job else None,
            "job_age_seconds": round(time.monotonic()-job.started_at, 2) if job else 0.0,
            "blocked_reason": self.blocked_reason,
        }
