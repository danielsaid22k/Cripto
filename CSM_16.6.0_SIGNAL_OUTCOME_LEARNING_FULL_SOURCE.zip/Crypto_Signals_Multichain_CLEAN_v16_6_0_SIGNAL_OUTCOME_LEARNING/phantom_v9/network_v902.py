from __future__ import annotations

import json
import shutil
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from csm.config import STATE_DIR
from .network import NetworkHTTPError, NetworkResult, TransientNetworkError


class NetworkBusyError(TransientNetworkError):
    """The single a-Shell curl lane is occupied by another request."""


@dataclass
class QueueState:
    owner: str | None = None
    kind: str | None = None
    acquired_at: float = 0.0
    total_acquired: int = 0
    busy_rejections: int = 0
    last_owner: str | None = None
    last_release_at: float = 0.0


class CurlQueueV902:
    """Process-global arbiter for every curl invocation in the active bot.

    a-Shell only tolerates one curl command at a time. All active v9.0.2
    network clients share this exact queue instance. Scanner jobs keep the
    lease while their child is alive; synchronous Telegram/market/payment
    requests acquire/release the same lease around subprocess.run.
    """

    def __init__(self):
        self.state = QueueState()

    def acquire(self, owner: str, kind: str) -> bool:
        if self.state.owner is not None:
            self.state.busy_rejections += 1
            return False
        self.state.owner = owner
        self.state.kind = kind
        self.state.acquired_at = time.monotonic()
        self.state.total_acquired += 1
        self.state.last_owner = owner
        return True

    def release(self, owner: str) -> bool:
        if self.state.owner != owner:
            return False
        self.state.owner = None
        self.state.kind = None
        self.state.acquired_at = 0.0
        self.state.last_release_at = time.monotonic()
        return True

    def busy(self) -> bool:
        return self.state.owner is not None

    def snapshot(self) -> dict[str, Any]:
        age = max(0.0, time.monotonic() - self.state.acquired_at) if self.state.owner else 0.0
        return {
            "busy": self.busy(),
            "owner": self.state.owner,
            "kind": self.state.kind,
            "age_seconds": round(age, 2),
            "total_acquired": self.state.total_acquired,
            "busy_rejections": self.state.busy_rejections,
            "last_owner": self.state.last_owner,
        }


_GLOBAL_QUEUE = CurlQueueV902()


def global_curl_queue() -> CurlQueueV902:
    return _GLOBAL_QUEUE


def _build_cmd(binary: str, headers: dict[str, str], connect_timeout: float, method: str, url: str, *, params=None, data=None, json_data=None, timeout: float) -> tuple[list[str], str]:
    if params:
        url += ("&" if "?" in url else "?") + urlencode(params, doseq=True)
    cmd = [
        binary, "--silent", "--show-error", "--location",
        "--connect-timeout", str(connect_timeout), "--max-time", str(timeout),
        "--request", method.upper(),
    ]
    for key, value in headers.items():
        cmd += ["--header", f"{key}: {value}"]
    body = None
    if json_data is not None:
        body = json.dumps(json_data, ensure_ascii=False)
        cmd += ["--header", "Content-Type: application/json"]
    elif data is not None:
        body = urlencode(data, doseq=True)
        cmd += ["--header", "Content-Type: application/x-www-form-urlencoded"]
    if body is not None:
        cmd += ["--data", body]
    cmd += ["--write-out", "\n__PHANTOM_STATUS__:%{http_code}", url]
    return cmd, url


def _parse_output(output: str) -> tuple[Any, int]:
    marker = "\n__PHANTOM_STATUS__:"
    if marker in output:
        body_text, status_text = output.rsplit(marker, 1)
        try:
            status = int(status_text.strip().splitlines()[0])
        except Exception:
            status = 0
    else:
        body_text, status = output, 0
    raw = body_text.strip()
    payload: Any = {} if not raw else json.loads(raw)
    return payload, status


class QueuedCurlTransportV902:
    """Synchronous curl adapter sharing the one global a-Shell lane."""

    def __init__(self, timeout: float = 4.0, connect_timeout: float = 2.0, binary: str | None = None, runner=None, queue: CurlQueueV902 | None = None, label: str = "sync"):
        self.binary = binary or shutil.which("curl")
        self.timeout = max(1.0, min(float(timeout), 8.0))
        self.connect_timeout = max(1.0, min(float(connect_timeout), self.timeout))
        self.runner = runner or subprocess.run
        self.headers = {"Accept": "application/json", "User-Agent": "PhantomAlert/9.0.2"}
        self.queue = queue or global_curl_queue()
        self.label = label

    def available(self) -> bool:
        return bool(self.binary)

    def queue_busy(self) -> bool:
        return self.queue.busy()

    def request_json(self, method: str, url: str, *, params=None, data=None, json_data=None, timeout: float | None = None) -> NetworkResult:
        if not self.binary:
            raise TransientNetworkError("curl não está disponível no ambiente.")
        effective = max(1.0, min(float(timeout or self.timeout), 10.0))
        owner = f"{self.label}:{uuid.uuid4().hex[:10]}"
        if not self.queue.acquire(owner, "sync"):
            raise NetworkBusyError("fila global de curl ocupada")
        try:
            cmd, final_url = _build_cmd(self.binary, self.headers, self.connect_timeout, method, url, params=params, data=data, json_data=json_data, timeout=effective)
            started = time.monotonic()
            try:
                proc = self.runner(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=effective + 1.5, check=False)
            except subprocess.TimeoutExpired as exc:
                raise TransientNetworkError("Timeout de rede.") from exc
            except OSError as exc:
                raise TransientNetworkError(f"Falha ao executar curl: {exc}") from exc
            elapsed = (time.monotonic() - started) * 1000
            output = proc.stdout or ""
            try:
                payload, status = _parse_output(output)
            except json.JSONDecodeError as exc:
                raise TransientNetworkError("Resposta não JSON recebida.") from exc
            if proc.returncode != 0:
                detail = (proc.stderr or "").strip()[:240]
                raise TransientNetworkError(f"curl falhou ({proc.returncode}): {detail or 'rede indisponível'}")
            if status in {0, 408, 425, 429, 500, 502, 503, 504}:
                raise TransientNetworkError(f"Serviço temporariamente indisponível (HTTP {status or 'desconhecido'}).")
            if status >= 400:
                raise NetworkHTTPError(status, payload, final_url)
            return NetworkResult(payload, status, elapsed)
        finally:
            self.queue.release(owner)

    def get_json(self, url: str, params=None, timeout: float | None = None) -> Any:
        return self.request_json("GET", url, params=params, timeout=timeout).payload

    def post_json(self, url: str, data=None, timeout: float | None = None) -> Any:
        return self.request_json("POST", url, data=data, timeout=timeout).payload


@dataclass
class CurlJobV902:
    job_id: str
    owner: str
    method: str
    url: str
    proc: subprocess.Popen
    stdout_path: Path
    stderr_path: Path
    stdout_handle: Any
    stderr_handle: Any
    started_at: float
    deadline: float
    kill_deadline: float | None = None
    timed_out: bool = False
    finished: bool = False


@dataclass(frozen=True)
class JobResultV902:
    state: str
    payload: Any = None
    status: int = 0
    error: str = ""
    elapsed_ms: float = 0.0


class CooperativeCurlTransportV902:
    """Scanner-side nonblocking adapter using the same global curl queue."""

    def __init__(self, timeout: float = 3.0, connect_timeout: float = 1.5, binary: str | None = None, queue: CurlQueueV902 | None = None):
        self.binary = binary or shutil.which("curl")
        self.timeout = max(1.0, min(float(timeout), 5.0))
        self.connect_timeout = max(1.0, min(float(connect_timeout), self.timeout))
        self.headers = {"Accept": "application/json", "User-Agent": "PhantomAlert/9.0.2"}
        self.runtime_dir = STATE_DIR / "runtime" / "v9" / "curl"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.queue = queue or global_curl_queue()
        self.current: CurlJobV902 | None = None
        self.blocked_reason = ""

    def available(self) -> bool:
        return bool(self.binary)

    def _cleanup_files(self, job: CurlJobV902) -> None:
        for handle in (job.stdout_handle, job.stderr_handle):
            try: handle.close()
            except Exception: pass
        for path in (job.stdout_path, job.stderr_path):
            try: path.unlink(missing_ok=True)
            except Exception: pass

    def _finish_release(self, job: CurlJobV902) -> None:
        self._cleanup_files(job)
        self.queue.release(job.owner)
        if self.current is job:
            self.current = None
        self.blocked_reason = ""

    def _release_if_done(self) -> None:
        job = self.current
        if not job: return
        try: rc = job.proc.poll()
        except Exception: rc = None
        if rc is not None and job.finished:
            self._finish_release(job)

    def start_json(self, method: str, url: str, *, params=None, data=None, json_data=None, timeout: float | None = None) -> CurlJobV902 | None:
        self._release_if_done()
        if self.current is not None:
            self.blocked_reason = "scanner já possui curl ativo"
            return None
        if not self.binary:
            self.blocked_reason = "curl não disponível"
            return None
        effective = max(1.0, min(float(timeout or self.timeout), 5.0))
        job_id = uuid.uuid4().hex[:12]
        owner = f"scanner:{job_id}"
        if not self.queue.acquire(owner, "scanner"):
            self.blocked_reason = "fila global de curl ocupada"
            return None
        cmd, final_url = _build_cmd(self.binary, self.headers, self.connect_timeout, method, url, params=params, data=data, json_data=json_data, timeout=effective)
        out_path = self.runtime_dir / f"{job_id}.out"; err_path = self.runtime_dir / f"{job_id}.err"
        out_handle = out_path.open("wb"); err_handle = err_path.open("wb")
        started = time.monotonic()
        try:
            proc = subprocess.Popen(cmd, stdout=out_handle, stderr=err_handle, stdin=subprocess.DEVNULL, close_fds=True)
        except Exception as exc:
            out_handle.close(); err_handle.close(); out_path.unlink(missing_ok=True); err_path.unlink(missing_ok=True)
            self.queue.release(owner)
            self.blocked_reason = f"falha ao iniciar curl: {type(exc).__name__}: {exc}"
            return None
        job = CurlJobV902(job_id, owner, method.upper(), final_url, proc, out_path, err_path, out_handle, err_handle, started, started + effective + 1.0)
        self.current = job
        return job

    def poll(self, job: CurlJobV902) -> JobResultV902:
        if self.current is not job:
            return JobResultV902("blocked", error="job não é mais o job ativo")
        now = time.monotonic()
        try: rc = job.proc.poll()
        except Exception as exc:
            self.blocked_reason = f"poll falhou: {type(exc).__name__}: {exc}"
            return JobResultV902("error", error=self.blocked_reason, elapsed_ms=(now-job.started_at)*1000)
        if rc is None:
            if now <= job.deadline:
                return JobResultV902("pending", elapsed_ms=(now-job.started_at)*1000)
            job.timed_out = True
            if job.kill_deadline is None:
                try: job.proc.terminate()
                except Exception: pass
                job.kill_deadline = now + 0.35
                return JobResultV902("pending", elapsed_ms=(now-job.started_at)*1000)
            if now <= job.kill_deadline:
                return JobResultV902("pending", elapsed_ms=(now-job.started_at)*1000)
            try: job.proc.kill()
            except Exception: pass
            self.blocked_reason = "curl excedeu o limite rígido; aguardando encerramento físico"
            return JobResultV902("timeout", error=self.blocked_reason, elapsed_ms=(now-job.started_at)*1000)

        try: job.stdout_handle.flush(); job.stderr_handle.flush()
        except Exception: pass
        try: job.stdout_handle.close(); job.stderr_handle.close()
        except Exception: pass
        try: output = job.stdout_path.read_text(encoding="utf-8", errors="replace")
        except Exception: output = ""
        try: error_text = job.stderr_path.read_text(encoding="utf-8", errors="replace").strip()[:240]
        except Exception: error_text = ""
        elapsed = (now-job.started_at)*1000; job.finished=True
        try:
            payload, status = _parse_output(output)
        except Exception as exc:
            result = JobResultV902("error", error=f"resposta inválida: {type(exc).__name__}", elapsed_ms=elapsed)
        else:
            if rc != 0:
                result = JobResultV902("timeout" if job.timed_out else "error", status=status, error=error_text or f"curl rc={rc}", elapsed_ms=elapsed)
            elif status in {0,408,425,429,500,502,503,504}:
                result = JobResultV902("error", status=status, error=f"HTTP transitório {status or 'desconhecido'}", elapsed_ms=elapsed)
            elif status >= 400:
                result = JobResultV902("error", payload=payload, status=status, error=f"HTTP {status}", elapsed_ms=elapsed)
            else:
                result = JobResultV902("ok", payload=payload, status=status, elapsed_ms=elapsed)
        self._finish_release(job)
        return result

    def health(self) -> dict[str, Any]:
        self._release_if_done()
        job=self.current
        return {
            "available":self.available(), "busy":job is not None,
            "job_id":job.job_id if job else None,
            "job_age_seconds":round(time.monotonic()-job.started_at,2) if job else 0.0,
            "blocked_reason":self.blocked_reason,
            "global_queue":self.queue.snapshot(),
        }
