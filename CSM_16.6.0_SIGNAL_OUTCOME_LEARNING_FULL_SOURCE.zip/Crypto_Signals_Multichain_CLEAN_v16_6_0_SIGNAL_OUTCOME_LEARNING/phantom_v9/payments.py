from __future__ import annotations

import re
from datetime import date, timedelta
from typing import Any

from csm.config import settings
from csm.plans import PLANS, normalize_plan
from .network import CurlTransport, NetworkHTTPError, TransientNetworkError

PAID_STATUSES={"RECEIVED","CONFIRMED","RECEIVED_IN_CASH"}
TERMINAL_STATUSES={"REFUNDED","REFUND_REQUESTED","CHARGEBACK_REQUESTED","CHARGEBACK_DISPUTE","AWAITING_CHARGEBACK_REVERSAL","DUNNING_REQUESTED","DUNNING_RECEIVED","DELETED"}

def only_digits(value:str)->str: return re.sub(r"\D","",value or "")
def valid_cpf(value:str)->bool:
    cpf=only_digits(value)
    if len(cpf)!=11 or cpf==cpf[0]*11:return False
    for size in (9,10):
        total=sum(int(cpf[i])*(size+1-i) for i in range(size)); digit=(total*10)%11; digit=0 if digit==10 else digit
        if digit!=int(cpf[size]):return False
    return True
def valid_cnpj(value:str)->bool:
    cnpj=only_digits(value)
    if len(cnpj)!=14 or cnpj==cnpj[0]*14:return False
    def calc(base,weights):
        rem=sum(int(n)*w for n,w in zip(base,weights))%11; return 0 if rem<2 else 11-rem
    return calc(cnpj[:12],[5,4,3,2,9,8,7,6,5,4,3,2])==int(cnpj[12]) and calc(cnpj[:13],[6,5,4,3,2,9,8,7,6,5,4,3,2])==int(cnpj[13])
def valid_document(value:str)->bool:
    d=only_digits(value); return valid_cpf(d) if len(d)==11 else valid_cnpj(d) if len(d)==14 else False

class AsaasClientV9:
    def __init__(self, transport=None):
        errors=settings.asaas_validation_errors()
        if errors: raise RuntimeError("Configuração Asaas inválida: "+"; ".join(errors))
        self.transport=transport or CurlTransport(timeout=5,connect_timeout=2)
        self.base=settings.asaas_base_url
        self.transport.headers.update({"access_token":settings.asaas_api_key,"Content-Type":"application/json"})
    def call(self,method,path,*,params=None,json_data=None):
        try:
            result=self.transport.request_json(method,f"{self.base}{path}",params=params,json_data=json_data,timeout=5).payload
        except NetworkHTTPError as exc:
            payload=exc.payload
            if isinstance(payload,dict) and payload.get("errors"):
                raise RuntimeError("; ".join(str(x.get("description") or x.get("code") or "Erro Asaas") for x in payload["errors"] if isinstance(x,dict))) from exc
            raise RuntimeError(f"Asaas HTTP {exc.status}") from exc
        except TransientNetworkError as exc: raise RuntimeError("Asaas temporariamente indisponível.") from exc
        if isinstance(result,dict) and result.get("errors"):
            raise RuntimeError("; ".join(str(x.get("description") or x.get("code") or "Erro Asaas") for x in result["errors"] if isinstance(x,dict)))
        return result
    def customers_by_reference(self,ref):
        p=self.call("GET","/customers",params={"externalReference":ref,"limit":100}); return list(p.get("data",[])) if isinstance(p,dict) else []
    def create_customer(self,*,name,cpf_cnpj,reference): return self.call("POST","/customers",json_data={"name":name.strip()[:100],"cpfCnpj":cpf_cnpj,"externalReference":reference,"notificationDisabled":True})
    def create_payment(self,*,customer_id,user_id,plan,billing_type):
        meta=PLANS[normalize_plan(plan)]; payload={"customer":customer_id,"billingType":billing_type,"value":round(meta["value"],2),"dueDate":(date.today()+timedelta(days=settings.asaas_due_days)).isoformat(),"description":f"Phantom Alert - {meta['label']} por {meta['days']} dias","externalReference":f"csm:{user_id}:{plan}"}
        return self.call("POST","/payments",json_data=payload)
    def payment_status(self,payment_id):
        p=self.call("GET",f"/payments/{payment_id}/status"); return str(p.get("status") or "UNKNOWN").upper() if isinstance(p,dict) else "UNKNOWN"
    def pix_qr_code(self,payment_id):
        p=self.call("GET",f"/payments/{payment_id}/pixQrCode"); return p if isinstance(p,dict) else {}

class PaymentServiceV9:
    def __init__(self,storage,client=None): self.storage=storage; self.client=client or AsaasClientV9()
    def _customer(self,user_id,name,document):
        user=self.storage.get_user(user_id); saved=str(user.get("asaas_customer_id") or "")
        if saved:return saved
        ref=f"csm-user:{user_id}"; rows=self.client.customers_by_reference(ref); row=rows[0] if rows else self.client.create_customer(name=name or f"Cliente Telegram {user_id}",cpf_cnpj=only_digits(document),reference=ref)
        cid=str(row.get("id") or "")
        if not cid: raise RuntimeError("Asaas não retornou ID do cliente.")
        self.storage.set_asaas_customer(user_id,cid); return cid
    def create_payment(self,*,user_id,plan,name,cpf_cnpj,billing_type):
        plan=normalize_plan(plan); billing_type=str(billing_type).upper()
        if plan=="free" or billing_type not in settings.asaas_payment_methods or not valid_document(cpf_cnpj): raise ValueError("Dados de pagamento inválidos.")
        existing=self.storage.latest_open_payment(user_id,plan,billing_type)
        if existing and existing.get("invoice_url"): return existing
        cid=self._customer(user_id,name,cpf_cnpj); remote=self.client.create_payment(customer_id=cid,user_id=user_id,plan=plan,billing_type=billing_type)
        pid=str(remote.get("id") or ""); url=str(remote.get("invoiceUrl") or remote.get("bankSlipUrl") or ""); status=str(remote.get("status") or "PENDING").upper()
        if not pid or not url: raise RuntimeError("Asaas não retornou cobrança válida.")
        self.storage.save_payment(payment_id=pid,user_id=user_id,plan=plan,invoice_url=url,external_reference=f"csm:{user_id}:{plan}:{billing_type.lower()}",status=status,billing_type=billing_type)
        row=self.storage.get_payment(pid) or {}
        if billing_type=="PIX":
            try: row["pix_payload"]=str(self.client.pix_qr_code(pid).get("payload") or "")
            except Exception: pass
        return row
    def verify_payment(self,payment_id):
        row=self.storage.get_payment(payment_id)
        if not row: raise RuntimeError("Cobrança não encontrada.")
        status=self.client.payment_status(payment_id); self.storage.update_payment_status(payment_id,status)
        if status in PAID_STATUSES:
            self.storage.activate_payment(payment_id,days=PLANS[normalize_plan(row["plan"])]["days"]); return {"state":"activated","status":status,"plan":row["plan"]}
        return {"state":"failed" if status in TERMINAL_STATUSES else "pending","status":status,"plan":row["plan"]}
    def verify_user(self,user_id):
        return [self.verify_payment(r["payment_id"]) for r in self.storage.open_payments(user_id=user_id,limit=20)]
    def sync_one(self):
        rows=self.storage.open_payments(limit=1)
        if not rows:return {"checked":0,"activated":0,"errors":0,"activations":[]}
        row=rows[0]
        try:
            result=self.verify_payment(row["payment_id"]); activated=int(result["state"]=="activated")
            return {"checked":1,"activated":activated,"errors":0,"activations":[{"user_id":int(row["user_id"]),"plan":row["plan"]}] if activated else []}
        except Exception:return {"checked":0,"activated":0,"errors":1,"activations":[]}
