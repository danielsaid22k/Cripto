from __future__ import annotations

import time
from dataclasses import dataclass, asdict
from typing import Any, Callable


@dataclass
class ProviderState:
    name: str
    status: str = "ONLINE"
    failures: int = 0
    successes: int = 0
    last_error: str = ""
    last_success: float = 0.0
    next_retry: float = 0.0
    latency_ms: float = 0.0


class ProviderGateway:
    def __init__(self, max_backoff: int = 300):
        self.max_backoff = max(30, int(max_backoff))
        self.states: dict[str, ProviderState] = {}
        self.cache: dict[str, tuple[float, Any]] = {}

    def state(self, name: str) -> ProviderState:
        return self.states.setdefault(name, ProviderState(name=name))

    def fetch(self, name: str, request: Callable[[], Any], *, cache_ttl: int = 60, stale_ttl: int = 1800, force: bool = False):
        now = time.time(); state = self.state(name); cached = self.cache.get(name)
        if not force and cached and now - cached[0] <= cache_ttl:
            return cached[1]
        if state.next_retry > now:
            if cached and now - cached[0] <= stale_ttl:
                return cached[1]
            return None
        started = time.monotonic()
        try:
            payload = request()
            state.status = "ONLINE"; state.failures = 0; state.successes += 1
            state.last_error = ""; state.last_success = now; state.next_retry = 0
            state.latency_ms = round((time.monotonic() - started) * 1000, 2)
            self.cache[name] = (now, payload)
            return payload
        except Exception as exc:
            state.failures += 1
            state.last_error = f"{type(exc).__name__}: {exc}"
            state.status = "DEGRADED" if state.failures < 4 else "OFFLINE"
            backoff = min(self.max_backoff, 15 * (2 ** min(state.failures - 1, 4)))
            state.next_retry = now + backoff
            if cached and now - cached[0] <= stale_ttl:
                return cached[1]
            return None

    def snapshot(self) -> list[dict]:
        now = time.time(); out = []
        for state in sorted(self.states.values(), key=lambda s: s.name.lower()):
            row = asdict(state)
            row["retry_in"] = max(0, int(state.next_retry - now))
            total = state.successes + state.failures
            row["success_rate"] = round(state.successes / total * 100, 1) if total else 100.0
            out.append(row)
        return out
