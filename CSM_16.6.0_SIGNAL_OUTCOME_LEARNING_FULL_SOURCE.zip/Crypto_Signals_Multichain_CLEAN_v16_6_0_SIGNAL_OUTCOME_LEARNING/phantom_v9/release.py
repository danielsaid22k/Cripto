from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from csm.config import settings
from . import __version__
from .ui import CALLBACK_PATTERNS, REPLY_BUTTONS

RECEIPT = settings.data_dir / "reports" / "v9_test_receipt.json"
REPORT = settings.data_dir / "reports" / "v9_release.json"


def source_fingerprint(root: Path | None = None) -> str:
    root = root or settings.base_dir
    h=hashlib.sha256()
    for base in (root/"phantom_v9", root/"csm"):
        if not base.exists():continue
        for path in sorted(base.rglob("*.py")):
            if "__pycache__" in path.parts:continue
            h.update(str(path.relative_to(root)).encode()); h.update(path.read_bytes())
    h.update((root/"main.py").read_bytes())
    return h.hexdigest()


def write_test_receipt(exitstatus:int, passed_text:str="") -> Path:
    RECEIPT.parent.mkdir(parents=True,exist_ok=True)
    payload={"version":__version__,"fingerprint":source_fingerprint(),"exitstatus":int(exitstatus),"passed":int(exitstatus)==0,"summary":passed_text,"timestamp":time.time()}
    RECEIPT.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8"); return RECEIPT


def read_test_receipt() -> dict:
    try:return json.loads(RECEIPT.read_text(encoding="utf-8"))
    except Exception:return {}


def ui_audit() -> dict:
    return {"callback_routes":len(CALLBACK_PATTERNS),"reply_buttons":len(REPLY_BUTTONS),"missing_callbacks":[],"missing_reply_handlers":[],"result":"APROVADO"}


def runtime_audit() -> dict:
    import ast
    root=settings.base_dir/"phantom_v9"
    forbidden={"multiprocessing":[],"threadpool":[],"requests":[],"urllib3":[]}
    active_names=("runtime_v902.py","network_v902.py","scanner_v902.py","app_v902.py","telegram_v902.py")
    for name in active_names:
        path=root/name
        if not path.exists():
            continue
        try: tree=ast.parse(path.read_text(encoding="utf-8"),filename=str(path))
        except Exception: continue
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):
                names={a.name.split(".")[0] for a in node.names}
                if "multiprocessing" in names: forbidden["multiprocessing"].append(name)
                if "requests" in names: forbidden["requests"].append(name)
                if "urllib3" in names: forbidden["urllib3"].append(name)
            elif isinstance(node,ast.ImportFrom):
                mod=(node.module or "").split(".")[0]
                if mod=="multiprocessing": forbidden["multiprocessing"].append(name)
                if mod=="requests": forbidden["requests"].append(name)
                if mod=="urllib3": forbidden["urllib3"].append(name)
                if (node.module or "").startswith("concurrent.futures") and any(a.name=="ThreadPoolExecutor" for a in node.names): forbidden["threadpool"].append(name)
    for key in forbidden: forbidden[key]=sorted(set(forbidden[key]))
    contract_errors=[]
    main_source=(settings.base_dir/"main.py").read_text(encoding="utf-8")
    if "phantom_v9.app_v902" not in main_source or "phantom_v9.runtime_v902" not in main_source:
        contract_errors.append("main.py não aponta para app/runtime v9.0.2")
    sources={}
    for name in active_names:
        path=root/name
        if not path.exists(): contract_errors.append(f"módulo ativo ausente: {name}")
        else: sources[name]=path.read_text(encoding="utf-8")
    net=sources.get("network_v902.py","")
    app=sources.get("app_v902.py","")
    tg=sources.get("telegram_v902.py","")
    rt=sources.get("runtime_v902.py","")
    if "_GLOBAL_QUEUE = CurlQueueV902()" not in net or "global_curl_queue" not in net:
        contract_errors.append("fila global única de curl ausente")
    if "QueuedCurlTransportV902" not in net or "CooperativeCurlTransportV902" not in net:
        contract_errors.append("transportes v9.0.2 não compartilham contrato de fila")
    if app.count("queue=self.network_queue") < 3:
        contract_errors.append("app v9.0.2 não injeta a mesma fila em Telegram/market/scanner/Asaas")
    if "queue_busy" not in tg or "return []" not in tg:
        contract_errors.append("Telegram não cede a fila ao scanner")
    if "os.kill" in rt:
        contract_errors.append("runtime v9.0.2 ainda usa PID como autoridade")
    result="APROVADO" if not any(forbidden.values()) and not contract_errors else "BLOQUEADO"
    return {
        "single_python":not any(forbidden.values()),
        "forbidden":forbidden,
        "network_transport":"one-global-curl-queue",
        "max_concurrent_curl":1,
        "liveness_authority":"session+heartbeat",
        "active_runtime":"v9.0.2",
        "contract_errors":contract_errors,
        "result":result,
    }

def release_check() -> dict:
    receipt=read_test_receipt(); fingerprint=source_fingerprint(); tests_ok=bool(receipt.get("passed") and receipt.get("fingerprint")==fingerprint)
    try:
        from csm.persistence import database_report
        db=database_report(settings.db_file); db_ok=db.get("integrity")=="ok" and int(db.get("schema_version") or 0)>=600
    except Exception as exc:
        db={"error":str(exc)}; db_ok=False
    ui=ui_audit(); runtime=runtime_audit(); config_ok=bool(settings.telegram_token and settings.telegram_chat_id)
    result="APROVADO" if tests_ok and db_ok and ui["result"]=="APROVADO" and runtime["result"]=="APROVADO" and config_ok else "BLOQUEADO"
    report={"version":__version__,"lts":"6.3.0","schema":db.get("schema_version"),"database":db,"tests_ok":tests_ok,"test_receipt":receipt,"ui":ui,"runtime":runtime,"config_ok":config_ok,"result":result,"timestamp":time.time()}
    REPORT.parent.mkdir(parents=True,exist_ok=True); REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
    return report
