from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from csm.config import STATE_DIR


class AlreadyRunningError(RuntimeError):
    pass


@dataclass
class RuntimeSnapshot:
    pid: int
    session: str
    started_at: float
    heartbeat_at: float


class RuntimeGuard:
    """Single-runtime guard with cooperative heartbeat.

    No background thread is created. The event loop calls ``beat``. A lock is
    considered live only while both the PID exists and the heartbeat is recent.
    This avoids permanent orphan locks after a native crash on iOS/a-Shell.
    """

    def __init__(self, name: str = "bot", stale_after: float = 45.0):
        self.runtime_dir = STATE_DIR / "runtime" / "v9"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.lock_file = self.runtime_dir / f".{name}.lock.json"
        self.session_file = self.runtime_dir / f".{name}.session.json"
        self.stale_after = max(15.0, float(stale_after))
        self.session = uuid.uuid4().hex[:16]
        self.started_at = time.time()
        self.acquired = False

    @staticmethod
    def _pid_exists(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError:
            return False

    def _read(self) -> dict:
        try:
            return json.loads(self.lock_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _is_live(self, data: dict) -> bool:
        try:
            pid = int(data.get("pid") or 0)
            heartbeat = float(data.get("heartbeat_at") or 0)
        except Exception:
            return False
        return self._pid_exists(pid) and (time.time() - heartbeat) <= self.stale_after

    def acquire(self) -> None:
        if self.lock_file.exists():
            data = self._read()
            if self._is_live(data):
                raise AlreadyRunningError(
                    f"Já existe uma instância saudável do bot (PID {data.get('pid')}). "
                    "Pare-a antes de iniciar outra."
                )
            try:
                self.lock_file.unlink()
            except FileNotFoundError:
                pass
        self.acquired = True
        self.beat(state="starting")

    def beat(self, *, state: str = "running", extra: dict | None = None) -> None:
        if not self.acquired:
            return
        payload = {
            "pid": os.getpid(),
            "session": self.session,
            "started_at": self.started_at,
            "heartbeat_at": time.time(),
            "state": state,
            "version": "9.0.0-clean-rebuild",
        }
        if extra:
            payload.update(extra)
        tmp = self.lock_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.lock_file)
        try:
            self.session_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def release(self) -> None:
        if not self.acquired:
            return
        try:
            data = self._read()
            if data.get("session") == self.session:
                self.lock_file.unlink(missing_ok=True)
        finally:
            self.acquired = False

    def __enter__(self):
        self.acquire(); return self

    def __exit__(self, exc_type, exc, tb):
        self.release()
