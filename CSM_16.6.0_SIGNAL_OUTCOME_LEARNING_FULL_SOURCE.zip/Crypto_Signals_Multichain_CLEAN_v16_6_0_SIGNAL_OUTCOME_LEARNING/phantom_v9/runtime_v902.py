from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from csm.config import STATE_DIR


class AlreadyRunningError(RuntimeError):
    pass


@dataclass(frozen=True)
class RecoveryEvent:
    recovered: bool
    reason: str = ""
    archived: tuple[str, ...] = ()


class RuntimeGuardV902:
    """a-Shell runtime guard based on session + heartbeat, never PID alone.

    iOS/a-Shell can retain or reuse a PID after a Python command has stopped.
    Therefore PID probing is intentionally not used as a liveness
    authority. A runtime is considered healthy only when lock and session files
    agree on the same session and both carry a recent heartbeat.

    Stale or inconsistent state is archived automatically instead of deleted.
    """

    def __init__(self, name: str = "bot", stale_after: float = 12.0):
        self.runtime_dir = STATE_DIR / "runtime" / "v9"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.lock_file = self.runtime_dir / f".{name}.lock.json"
        self.session_file = self.runtime_dir / f".{name}.session.json"
        self.stale_after = max(8.0, float(stale_after))
        self.session = uuid.uuid4().hex[:16]
        self.started_at = time.time()
        self.acquired = False
        self.last_progress_at = self.started_at
        self.last_phase = "starting"
        self.recovery_event = RecoveryEvent(False)

    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _state_is_running(data: dict[str, Any]) -> bool:
        return str(data.get("state") or "").lower() in {"starting", "running"}

    def _recent(self, data: dict[str, Any], now: float | None = None) -> bool:
        now = time.time() if now is None else now
        try:
            heartbeat = float(data.get("heartbeat_at") or 0)
        except Exception:
            return False
        return heartbeat > 0 and (now - heartbeat) <= self.stale_after

    def _healthy_pair(self, lock: dict[str, Any], session: dict[str, Any]) -> bool:
        if not lock or not session:
            return False
        sid = str(lock.get("session") or "")
        if not sid or sid != str(session.get("session") or ""):
            return False
        if not self._state_is_running(lock) or not self._state_is_running(session):
            return False
        now = time.time()
        return self._recent(lock, now) and self._recent(session, now)

    def _archive_path(self, path: Path, reason: str) -> str | None:
        if not path.exists():
            return None
        data = self._read_json(path)
        session = str(data.get("session") or "unknown")[:16]
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
        safe_reason = "".join(c if c.isalnum() or c in "-_" else "_" for c in reason)[:32]
        target = path.with_name(f"{path.name}.stale.{stamp}.{session}.{safe_reason}")
        counter = 1
        while target.exists():
            target = path.with_name(f"{path.name}.stale.{stamp}.{session}.{safe_reason}.{counter}")
            counter += 1
        try:
            path.replace(target)
            return str(target)
        except FileNotFoundError:
            return None

    def _recover_stale(self, reason: str) -> RecoveryEvent:
        archived: list[str] = []
        for path in (self.lock_file, self.session_file):
            saved = self._archive_path(path, reason)
            if saved:
                archived.append(saved)
        event = RecoveryEvent(bool(archived), reason, tuple(archived))
        self.recovery_event = event
        return event

    def recover_stale_if_needed(self) -> RecoveryEvent:
        lock = self._read_json(self.lock_file) if self.lock_file.exists() else {}
        session = self._read_json(self.session_file) if self.session_file.exists() else {}
        if self._healthy_pair(lock, session):
            age = max(0.0, time.time() - float(lock.get("heartbeat_at") or time.time()))
            raise AlreadyRunningError(
                f"Já existe uma sessão saudável do bot (sessão {str(lock.get('session'))[:8]}, "
                f"heartbeat há {age:.1f}s). Pare-a antes de iniciar outra."
            )
        if lock or session or self.lock_file.exists() or self.session_file.exists():
            reason = "heartbeat_expirado"
            if lock and session and str(lock.get("session") or "") != str(session.get("session") or ""):
                reason = "sessao_inconsistente"
            elif (lock and not session) or (session and not lock):
                reason = "estado_incompleto"
            elif not self._state_is_running(lock or session):
                reason = "sessao_finalizada"
            return self._recover_stale(reason)
        self.recovery_event = RecoveryEvent(False)
        return self.recovery_event

    def acquire(self) -> RecoveryEvent:
        self.recover_stale_if_needed()
        self.acquired = True
        self.progress("starting")
        return self.recovery_event

    def _payload(self, *, state: str, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        now = time.time()
        payload: dict[str, Any] = {
            "pid": os.getpid(),  # diagnostic only; never used alone for liveness
            "session": self.session,
            "started_at": self.started_at,
            "heartbeat_at": now,
            "last_progress_at": self.last_progress_at,
            "state": state,
            "phase": self.last_phase,
            "version": "9.0.2-network-queue",
            "liveness_authority": "session+heartbeat",
        }
        if extra:
            payload.update(extra)
        return payload

    @staticmethod
    def _atomic_write(path: Path, payload: dict[str, Any]) -> None:
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def beat(self, *, state: str = "running", extra: dict[str, Any] | None = None) -> None:
        if not self.acquired:
            return
        payload = self._payload(state=state, extra=extra)
        self._atomic_write(self.lock_file, payload)
        self._atomic_write(self.session_file, payload)

    def progress(self, phase: str, *, extra: dict[str, Any] | None = None) -> None:
        self.last_phase = str(phase or "unknown")
        self.last_progress_at = time.time()
        self.beat(state="running" if self.last_phase != "starting" else "starting", extra=extra)

    def release(self, *, state: str = "stopped") -> None:
        if not self.acquired:
            return
        try:
            current = self._read_json(self.lock_file)
            if current.get("session") == self.session:
                self.lock_file.unlink(missing_ok=True)
            payload = self._payload(state=state, extra={"ended_at": time.time()})
            self._atomic_write(self.session_file, payload)
        finally:
            self.acquired = False

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release(state="crashed" if exc_type else "stopped")


def runtime_state(name: str = "bot", stale_after: float = 12.0) -> dict[str, Any]:
    runtime_dir = STATE_DIR / "runtime" / "v9"
    lock_file = runtime_dir / f".{name}.lock.json"
    session_file = runtime_dir / f".{name}.session.json"
    lock = RuntimeGuardV902._read_json(lock_file) if lock_file.exists() else {}
    session = RuntimeGuardV902._read_json(session_file) if session_file.exists() else {}
    guard = RuntimeGuardV902(name, stale_after=stale_after)
    healthy = guard._healthy_pair(lock, session)
    source = lock or session
    try:
        age = max(0.0, time.time() - float(source.get("heartbeat_at") or 0)) if source else None
    except Exception:
        age = None
    return {
        "healthy": healthy,
        "session": source.get("session") if source else None,
        "state": source.get("state") if source else "absent",
        "phase": source.get("scanner_phase") or source.get("phase") if source else None,
        "heartbeat_age_seconds": round(age, 1) if age is not None else None,
        "lock_exists": lock_file.exists(),
        "session_exists": session_file.exists(),
        "pid_diagnostic_only": source.get("pid") if source else None,
        "liveness_authority": "session+heartbeat",
    }
