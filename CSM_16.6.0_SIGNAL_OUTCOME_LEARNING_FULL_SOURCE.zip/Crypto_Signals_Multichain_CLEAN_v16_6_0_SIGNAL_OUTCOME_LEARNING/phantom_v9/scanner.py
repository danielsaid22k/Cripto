from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from csm.config import settings
from csm.formatting import score_market
from csm.experience import opportunity_profile
from .market import MarketService
from .network import CurlTransport
from .providers import ProviderGateway

CHAIN_MAP = {
    "solana":"solana","eth":"ethereum","ethereum":"ethereum","bsc":"bsc","base":"base","arbitrum":"arbitrum",
    "polygon_pos":"polygon","polygon":"polygon","avax":"avalanche","avalanche":"avalanche","optimism":"optimism","fantom":"fantom","cronos":"cronos",
}

@dataclass(frozen=True)
class DiscoverySource:
    name: str
    url: str
    parser: Callable[[Any], list[tuple[str,str]]]


def _dex_rows(payload: Any) -> list[tuple[str,str]]:
    rows=[]
    for item in payload if isinstance(payload,list) else []:
        chain = CHAIN_MAP.get(str(item.get("chainId") or "").lower())
        address = str(item.get("tokenAddress") or item.get("address") or "").strip()
        if chain and address: rows.append((chain,address))
    return rows


def _gecko_rows(payload: Any) -> list[tuple[str,str]]:
    rows=[]
    for item in payload.get("data",[]) if isinstance(payload,dict) else []:
        attrs=item.get("attributes") or {}; rel=item.get("relationships") or {}
        network=str(attrs.get("network") or item.get("id","").split("_")[0]).lower(); chain=CHAIN_MAP.get(network)
        token=((rel.get("base_token") or {}).get("data") or {}).get("id","")
        address=str(token).split("_",1)[-1].strip()
        if chain and address: rows.append((chain,address))
    return rows

SOURCES = (
    DiscoverySource("GeckoTerminal trending","https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?include=base_token",_gecko_rows),
    DiscoverySource("GeckoTerminal novos","https://api.geckoterminal.com/api/v2/networks/solana/new_pools?include=base_token",_gecko_rows),
    DiscoverySource("DexScreener perfis","https://api.dexscreener.com/token-profiles/latest/v1",_dex_rows),
    DiscoverySource("DexScreener boosts","https://api.dexscreener.com/token-boosts/top/v1",_dex_rows),
)

class ScannerEngine:
    """Cooperative scanner. Exactly one network request is made per ``step``."""
    def __init__(self, transport=None, market=None, providers=None):
        self.transport=transport or CurlTransport(timeout=4,connect_timeout=2)
        self.providers=providers or ProviderGateway()
        self.market=market or MarketService(transport=self.transport,providers=self.providers)
        self.active=False; self.phase="idle"; self.results=[]; self.last_results=[]; self.last_stats=self._stats()
        self._source_index=0; self._candidate_index=0; self._candidates=[]; self._seen=set(); self._allowed=set(); self._target=0; self._started=0.0

    @staticmethod
    def _stats():
        return {"discovered":0,"analyzed":0,"approved":0,"rejected":0,"errors":0,"sources_ok":0,"sources_failed":0,"mode":"v9-cooperative-single-runtime"}

    def start(self, limit=None, chains=None) -> bool:
        if self.active: return False
        self.active=True; self.phase="discover"; self.results=[]; self.last_stats=self._stats(); self._source_index=0; self._candidate_index=0; self._candidates=[]; self._seen=set(); self._started=time.monotonic()
        self._allowed=set(chains or settings.scan_chains); self._target=min(max(int(limit or settings.scan_limit),10),settings.scan_max_candidates)
        return True

    @staticmethod
    def _passes(m):
        liq=float(m.get("liquidity") or 0); vol=float(m.get("volume24h") or 0); cap=float(m.get("marketcap") or 0); change=float(m.get("change24h") or 0)
        buys=int(m.get("buys24h") or 0); sells=int(m.get("sells24h") or 0); age=m.get("age_days")
        if liq < settings.scan_min_liquidity or (settings.scan_max_liquidity and liq > settings.scan_max_liquidity): return False
        if vol < settings.scan_min_volume24h or (settings.scan_max_volume24h and vol > settings.scan_max_volume24h): return False
        if settings.scan_min_marketcap and cap < settings.scan_min_marketcap: return False
        if settings.scan_max_marketcap and cap > settings.scan_max_marketcap: return False
        if age is not None and (float(age)<settings.scan_min_age_days or (settings.scan_max_age_days and float(age)>settings.scan_max_age_days)): return False
        if change < settings.scan_min_change24h or (settings.scan_max_change24h and change > settings.scan_max_change24h): return False
        if buys+sells < settings.scan_min_txns24h: return False
        if sells>0 and buys/sells < settings.scan_min_buy_sell_ratio: return False
        return True

    def step(self):
        if not self.active: return None
        if self.phase=="discover":
            if self._source_index >= len(SOURCES) or len(self._candidates)>=self._target:
                self.last_stats["discovered"]=len(self._candidates); self.phase="analyze"; return None
            source=SOURCES[self._source_index]; self._source_index+=1
            payload=self.providers.fetch(source.name,lambda:self.transport.get_json(source.url,timeout=4),cache_ttl=30,stale_ttl=900)
            if payload is None: self.last_stats["sources_failed"]+=1; return None
            try:
                rows=source.parser(payload); self.last_stats["sources_ok"]+=1
                for chain,address in rows:
                    key=(chain,address)
                    if chain in self._allowed and key not in self._seen:
                        self._seen.add(key); self._candidates.append(key)
                        if len(self._candidates)>=self._target: break
            except Exception: self.last_stats["sources_failed"]+=1
            return None
        if self.phase=="analyze":
            if self._candidate_index>=len(self._candidates): self.phase="done"
            else:
                chain,address=self._candidates[self._candidate_index]; self._candidate_index+=1
                try:
                    market=self.market.fetch(chain,address,force=True); self.last_stats["analyzed"]+=1
                    if self._passes(market):
                        item=dict(market); item["score"]=score_market(item); item.update(opportunity_profile(item)); self.results.append(item); self.last_stats["approved"]+=1
                    else: self.last_stats["rejected"]+=1
                except Exception: self.last_stats["errors"]+=1
                return None
        if self.phase=="done":
            self.results.sort(key=lambda x:(float(x.get("opportunity_score") or x.get("score") or 0),float(x.get("volume24h") or 0),float(x.get("liquidity") or 0)),reverse=True)
            self.last_results=[dict(x) for x in self.results[:settings.scan_result_limit]]
            self.last_stats["elapsed_ms"]=round((time.monotonic()-self._started)*1000,2); self.last_stats["providers"]=self.providers.snapshot()
            self.active=False; self.phase="idle"; return [dict(x) for x in self.last_results]
        return None

    def run_sync(self, limit=None, chains=None):
        if not self.active: self.start(limit=limit,chains=chains)
        result=None
        while result is None: result=self.step()
        return result
