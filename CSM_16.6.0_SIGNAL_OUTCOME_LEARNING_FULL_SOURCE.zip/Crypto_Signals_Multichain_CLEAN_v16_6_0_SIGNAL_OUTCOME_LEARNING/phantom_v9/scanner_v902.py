from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from csm.chains import CHAINS
from csm.config import settings
from csm.experience import opportunity_profile
from csm.formatting import score_market

from .market import MarketService
from .network_v902 import CooperativeCurlTransportV902, CurlJobV902 as CurlJob, JobResultV902 as JobResult
from .providers import ProviderGateway


CHAIN_MAP = {
    "solana":"solana","eth":"ethereum","ethereum":"ethereum","bsc":"bsc","base":"base","arbitrum":"arbitrum",
    "polygon_pos":"polygon","polygon":"polygon","avax":"avalanche","avalanche":"avalanche","optimism":"optimism","fantom":"fantom","cronos":"cronos",
}


@dataclass(frozen=True)
class DiscoverySource:
    name: str
    url: str
    parser: Callable[[Any], list[tuple[str, str]]]


def _dex_rows(payload: Any) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for item in payload if isinstance(payload, list) else []:
        chain = CHAIN_MAP.get(str(item.get("chainId") or "").lower())
        address = str(item.get("tokenAddress") or item.get("address") or "").strip()
        if chain and address:
            rows.append((chain, address))
    return rows


def _gecko_rows(payload: Any) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for item in payload.get("data", []) if isinstance(payload, dict) else []:
        attrs = item.get("attributes") or {}
        rel = item.get("relationships") or {}
        network = str(attrs.get("network") or item.get("id", "").split("_")[0]).lower()
        chain = CHAIN_MAP.get(network)
        token = ((rel.get("base_token") or {}).get("data") or {}).get("id", "")
        address = str(token).split("_", 1)[-1].strip()
        if chain and address:
            rows.append((chain, address))
    return rows


SOURCES = (
    DiscoverySource("GeckoTerminal trending", "https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?include=base_token", _gecko_rows),
    DiscoverySource("GeckoTerminal novos", "https://api.geckoterminal.com/api/v2/networks/solana/new_pools?include=base_token", _gecko_rows),
    DiscoverySource("DexScreener perfis", "https://api.dexscreener.com/token-profiles/latest/v1", _dex_rows),
    DiscoverySource("DexScreener boosts", "https://api.dexscreener.com/token-boosts/top/v1", _dex_rows),
)


class ScannerEngineV902:
    """Globally serialized non-blocking scanner for a-Shell.

    ``step`` only starts or polls one curl child. It never waits for network I/O.
    Scanner progress therefore cannot freeze Telegram heartbeats. If a request
    exceeds the hard deadline, the current cycle is aborted and the scheduler
    can continue serving UI traffic.
    """

    def __init__(self, transport=None, providers=None, *, cycle_timeout: float = 90.0, phase_timeout: float = 30.0):
        self.transport = transport or CooperativeCurlTransportV902(timeout=3.0, connect_timeout=1.5)
        self.providers = providers or ProviderGateway()
        self.active = False
        self.phase = "idle"
        self.results: list[dict[str, Any]] = []
        self.last_results: list[dict[str, Any]] = []
        self.last_stats = self._stats()
        self.last_error = ""
        self.cycle_timeout = max(20.0, float(cycle_timeout))
        self.phase_timeout = max(10.0, float(phase_timeout))
        self._source_index = 0
        self._candidate_index = 0
        self._candidates: list[tuple[str, str]] = []
        self._seen: set[tuple[str, str]] = set()
        self._allowed: set[str] = set()
        self._target = 0
        self._started = 0.0
        self._phase_started = 0.0
        self.last_progress_monotonic = 0.0
        self._job: CurlJob | None = None
        self._job_kind = ""
        self._job_provider = ""
        self._job_meta: dict[str, Any] = {}
        self._market_stage = ""
        self._current_candidate: tuple[str, str] | None = None

    @staticmethod
    def _stats() -> dict[str, Any]:
        return {
            "discovered":0,"analyzed":0,"approved":0,"rejected":0,"errors":0,
            "sources_ok":0,"sources_failed":0,"timeouts":0,"aborted":0,
            "mode":"v9.0.2-global-curl-queue",
        }

    def _progress(self, phase: str | None = None) -> None:
        now = time.monotonic()
        if phase is not None and phase != self.phase:
            self.phase = phase
            self._phase_started = now
        self.last_progress_monotonic = now

    def start(self, limit=None, chains=None) -> bool:
        if self.active:
            return False
        # If an earlier curl child is still physically alive after a hard
        # timeout, do not create another. The bot remains online and retries on
        # a later scheduler cycle.
        health = self.transport.health()
        if health.get("busy"):
            self.last_error = health.get("blocked_reason") or "lane de rede ainda ocupada"
            return False
        self.active = True
        self.phase = "discover"
        self.results = []
        self.last_stats = self._stats()
        self.last_error = ""
        self._source_index = 0
        self._candidate_index = 0
        self._candidates = []
        self._seen = set()
        self._started = time.monotonic()
        self._phase_started = self._started
        self.last_progress_monotonic = self._started
        self._allowed = set(chains or settings.scan_chains)
        self._target = min(max(int(limit or settings.scan_limit), 10), settings.scan_max_candidates)
        self._job = None
        self._job_kind = ""
        self._job_provider = ""
        self._job_meta = {}
        self._market_stage = ""
        self._current_candidate = None
        return True

    def abort(self, reason: str) -> list[dict[str, Any]]:
        self.last_error = str(reason)[:300]
        self.last_stats["aborted"] += 1
        self.last_stats["errors"] += 1
        self.active = False
        self.phase = "idle"
        self._job = None
        self._job_kind = ""
        self._job_provider = ""
        self._job_meta = {}
        # Keep only results already fully analyzed. A partial cycle is still
        # useful as a degraded result, but no further network work is done.
        self.last_results = [dict(x) for x in self.results]
        return [dict(x) for x in self.results]

    def _watchdog(self) -> list[dict[str, Any]] | None:
        if not self.active:
            return None
        now = time.monotonic()
        if now - self._started > self.cycle_timeout:
            self.last_stats["timeouts"] += 1
            return self.abort("watchdog: tempo máximo do ciclo excedido")
        # A live async curl job is allowed to occupy a phase; its own transport
        # deadline handles the request. Without a job, lack of progress means a
        # state-machine bug, so abort instead of freezing the bot.
        if self._job is None and self._phase_started and now - self._phase_started > self.phase_timeout:
            self.last_stats["timeouts"] += 1
            return self.abort(f"watchdog: fase {self.phase} sem progresso")
        return None

    @staticmethod
    def _passes(m: dict[str, Any]) -> bool:
        liq=float(m.get("liquidity") or 0); vol=float(m.get("volume24h") or 0); cap=float(m.get("marketcap") or 0); change=float(m.get("change24h") or 0)
        buys=int(m.get("buys24h") or 0); sells=int(m.get("sells24h") or 0); age=m.get("age_days")
        if liq < settings.scan_min_liquidity or (settings.scan_max_liquidity and liq > settings.scan_max_liquidity): return False
        if vol < settings.scan_min_volume24h or (settings.scan_max_volume24h and vol > settings.scan_max_volume24h): return False
        if settings.scan_min_marketcap and cap < settings.scan_min_marketcap: return False
        if settings.scan_max_marketcap and cap > settings.scan_max_marketcap: return False
        if age is not None and (float(age)<settings.scan_min_age_days or (settings.scan_max_age_days and float(age)>settings.scan_max_age_days)): return False
        if change < settings.scan_min_change24h or (settings.scan_max_change24h and change > settings.scan_max_change24h): return False
        if buys+sells < settings.scan_min_txns24h: return False
        if sells>0 and buys/sells < settings.scan_min_buy_sell_ratio: return False
        return True

    def _cached_or_backoff(self, provider: str, *, cache_ttl: int, stale_ttl: int, force: bool = False) -> tuple[bool, Any]:
        now = time.time()
        state = self.providers.state(provider)
        cached = self.providers.cache.get(provider)
        if not force and cached and now - cached[0] <= cache_ttl:
            return True, cached[1]
        if state.next_retry > now:
            if cached and now - cached[0] <= stale_ttl:
                return True, cached[1]
            return True, None
        return False, None

    def _provider_success(self, provider: str, payload: Any, elapsed_ms: float) -> None:
        now = time.time(); state = self.providers.state(provider)
        state.status="ONLINE"; state.failures=0; state.successes+=1; state.last_error=""; state.last_success=now; state.next_retry=0; state.latency_ms=round(elapsed_ms,2)
        self.providers.cache[provider]=(now,payload)

    def _provider_failure(self, provider: str, error: str, *, stale_ttl: int) -> Any:
        now=time.time(); state=self.providers.state(provider); state.failures+=1; state.last_error=str(error)[:240]; state.status="DEGRADED" if state.failures<4 else "OFFLINE"
        state.next_retry=now+min(self.providers.max_backoff,15*(2**min(state.failures-1,4)))
        cached=self.providers.cache.get(provider)
        if cached and now-cached[0] <= stale_ttl:
            return cached[1]
        return None

    def _start_job(self, kind: str, provider: str, url: str, *, params=None, timeout: float = 3.0, meta: dict[str, Any] | None = None) -> bool:
        job = self.transport.start_json("GET", url, params=params, timeout=timeout)
        if job is None:
            return False
        self._job=job; self._job_kind=kind; self._job_provider=provider; self._job_meta=dict(meta or {})
        self._progress()
        return True

    def _finish_source_payload(self, source: DiscoverySource, payload: Any) -> None:
        if payload is None:
            self.last_stats["sources_failed"] += 1
            return
        try:
            rows=source.parser(payload); self.last_stats["sources_ok"] += 1
            for chain,address in rows:
                key=(chain,address)
                if chain in self._allowed and key not in self._seen:
                    self._seen.add(key); self._candidates.append(key)
                    if len(self._candidates)>=self._target:
                        break
        except Exception as exc:
            self.last_stats["sources_failed"] += 1
            self.last_error=f"parser {source.name}: {type(exc).__name__}: {exc}"

    def _finish_market_payload(self, chain: str, address: str, stage: str, payload: Any) -> dict[str, Any] | None:
        try:
            if stage == "gecko" and isinstance(payload,dict) and payload.get("data"):
                return MarketService._normalize_gecko(payload["data"][0],chain,address)
            if stage == "dex" and isinstance(payload,list) and payload:
                best=max(payload,key=lambda p:float((p.get("liquidity") or {}).get("usd") or 0))
                return MarketService._normalize_dex(best)
        except Exception as exc:
            self.last_error=f"normalize {stage}: {type(exc).__name__}: {exc}"
        return None

    def _accept_market(self, market: dict[str, Any]) -> None:
        self.last_stats["analyzed"] += 1
        if self._passes(market):
            item=dict(market); item["score"]=score_market(item); item.update(opportunity_profile(item)); self.results.append(item); self.last_stats["approved"] += 1
        else:
            self.last_stats["rejected"] += 1
        self._current_candidate=None; self._market_stage=""; self._progress()

    def _market_failed(self) -> None:
        # Gecko failure falls back to Dex. Dex failure skips the candidate.
        if self._market_stage == "gecko":
            self._market_stage = "dex"
            self._progress()
        else:
            self.last_stats["errors"] += 1
            self._current_candidate=None; self._market_stage=""; self._progress()

    def _handle_job_result(self, result: JobResult) -> list[dict[str, Any]] | None:
        if result.state == "pending":
            return None
        provider=self._job_provider; kind=self._job_kind; meta=dict(self._job_meta)
        self._job=None; self._job_provider=""; self._job_kind=""; self._job_meta={}
        if result.state == "ok":
            self._provider_success(provider,result.payload,result.elapsed_ms)
            payload=result.payload
        else:
            if result.state == "timeout": self.last_stats["timeouts"] += 1
            payload=self._provider_failure(provider,result.error or result.state,stale_ttl=900)
            if result.state == "timeout" and self.transport.health().get("busy"):
                # The child did not exit by the hard deadline. Do not start any
                # further scan request in this cycle.
                return self.abort("curl não encerrou no limite rígido; scanner isolado e ciclo abortado")
        if kind == "discover":
            source=SOURCES[int(meta["source_index"])]
            self._finish_source_payload(source,payload)
            self._progress()
            return None
        if kind == "market":
            chain=str(meta["chain"]); address=str(meta["address"]); stage=str(meta["stage"])
            market=self._finish_market_payload(chain,address,stage,payload)
            if market is not None:
                self._accept_market(market)
            else:
                self._market_failed()
            return None
        return None

    def step(self) -> list[dict[str, Any]] | None:
        if not self.active:
            return None
        watchdog=self._watchdog()
        if watchdog is not None:
            return watchdog
        if self._job is not None:
            return self._handle_job_result(self.transport.poll(self._job))

        if self.phase == "discover":
            if self._source_index >= len(SOURCES) or len(self._candidates) >= self._target:
                self.last_stats["discovered"] = len(self._candidates)
                self._progress("analyze")
                return None
            idx=self._source_index; source=SOURCES[idx]; self._source_index += 1
            resolved,payload=self._cached_or_backoff(source.name,cache_ttl=30,stale_ttl=900)
            if resolved:
                self._finish_source_payload(source,payload); self._progress(); return None
            if not self._start_job("discover",source.name,source.url,timeout=3.0,meta={"source_index":idx}):
                self.last_stats["sources_failed"] += 1; self.last_stats["errors"] += 1; self.last_error=self.transport.health().get("blocked_reason") or "não foi possível iniciar provider"; self._progress()
            return None

        if self.phase == "analyze":
            if self._current_candidate is None:
                if self._candidate_index >= len(self._candidates):
                    self._progress("done")
                else:
                    self._current_candidate=self._candidates[self._candidate_index]; self._candidate_index += 1; self._market_stage="gecko"; self._progress()
                    return None
            if self.phase == "done":
                pass
            elif self._current_candidate is not None:
                chain,address=self._current_candidate
                if self._market_stage == "gecko":
                    gecko=(CHAINS.get(chain) or {}).get("gecko")
                    if not gecko:
                        self._market_stage="dex"; self._progress(); return None
                    provider="GeckoTerminal market"
                    resolved,payload=self._cached_or_backoff(provider,cache_ttl=0,stale_ttl=900,force=True)
                    # force=True means fresh provider request unless provider is in backoff.
                    if resolved:
                        market=self._finish_market_payload(chain,address,"gecko",payload)
                        if market is not None:self._accept_market(market)
                        else:self._market_failed()
                        return None
                    url=f"https://api.geckoterminal.com/api/v2/networks/{gecko}/tokens/{address}/pools"
                    if not self._start_job("market",provider,url,params={"page":"1"},timeout=3.0,meta={"chain":chain,"address":address,"stage":"gecko"}):
                        self._market_failed()
                    return None
                provider="DexScreener market"
                resolved,payload=self._cached_or_backoff(provider,cache_ttl=0,stale_ttl=900,force=True)
                if resolved:
                    market=self._finish_market_payload(chain,address,"dex",payload)
                    if market is not None:self._accept_market(market)
                    else:self._market_failed()
                    return None
                url=f"https://api.dexscreener.com/token-pairs/v1/{chain}/{address}"
                if not self._start_job("market",provider,url,timeout=3.0,meta={"chain":chain,"address":address,"stage":"dex"}):
                    self._market_failed()
                return None

        if self.phase == "done":
            self.last_results=[dict(x) for x in self.results]
            self.active=False; self.phase="idle"; self._progress()
            return [dict(x) for x in self.results]
        return None

    def health_snapshot(self) -> dict[str, Any]:
        now=time.monotonic()
        return {
            "active":self.active,
            "phase":self.phase,
            "last_progress_age_seconds":round(max(0.0,now-self.last_progress_monotonic),2) if self.last_progress_monotonic else None,
            "cycle_age_seconds":round(max(0.0,now-self._started),2) if self.active else 0.0,
            "last_error":self.last_error,
            "transport":self.transport.health(),
            "stats":dict(self.last_stats),
        }

    def run_sync(self, limit=None, chains=None, *, wall_timeout: float = 120.0) -> list[dict[str, Any]]:
        if not self.start(limit,chains):
            return [dict(x) for x in self.last_results]
        deadline=time.monotonic()+max(10.0,float(wall_timeout))
        result=None
        while result is None and time.monotonic()<deadline:
            result=self.step()
            if result is None:
                time.sleep(0.03)
        if result is None:
            return self.abort("run_sync excedeu wall_timeout")
        return result
