from __future__ import annotations
import os, shutil, sys
from csm.config import settings

def runtime_status():
    return {"version":"9.0.0-clean-rebuild","pid":os.getpid(),"python":sys.executable,"curl":shutil.which("curl"),"single_python":True,"multiprocessing":False,"thread_pool":False,"state_dir":str(settings.data_dir),"db":str(settings.db_file),"network":"curl only in active v9 runtime"}
