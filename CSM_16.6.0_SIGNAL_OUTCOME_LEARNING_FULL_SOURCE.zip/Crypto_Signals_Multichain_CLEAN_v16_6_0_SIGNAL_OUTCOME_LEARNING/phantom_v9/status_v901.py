from __future__ import annotations

import os
import shutil
import sys

from csm.config import settings
from .runtime_v901 import runtime_state


def runtime_status_v901():
    state=runtime_state("bot")
    return {
        "version":"9.0.1-runtime-recovery",
        "pid_diagnostico":os.getpid(),
        "python":sys.executable,
        "curl":shutil.which("curl"),
        "single_python":True,
        "multiprocessing":False,
        "thread_pool":False,
        "liveness_authority":"session+heartbeat (PID apenas diagnóstico)",
        "background_network":"scanner lane não bloqueante; monitor cache-only",
        "state_dir":str(settings.data_dir),
        "db":str(settings.db_file),
        **{f"runtime_{k}":v for k,v in state.items()},
    }
