from __future__ import annotations

import os
import shutil
import sys

from csm.config import settings
from .runtime_v902 import runtime_state
from .network_v902 import global_curl_queue


def runtime_status_v902():
    state=runtime_state("bot")
    return {
        "version":"9.0.3-timezone-metrics-hotfix",
        "runtime_core":"9.0.2-network-queue",
        "pid_diagnostico":os.getpid(),
        "python":sys.executable,
        "curl":shutil.which("curl"),
        "single_python":True,
        "multiprocessing":False,
        "thread_pool":False,
        "liveness_authority":"session+heartbeat (PID apenas diagnóstico)",
        "network_policy":"ONE_GLOBAL_CURL_QUEUE",
        "max_concurrent_curl":1,
        "network_queue":global_curl_queue().snapshot(),
        "background_network":"scanner cooperativo; Telegram cede a fila enquanto scanner usa curl; monitor cache-only",
        "state_dir":str(settings.data_dir),
        "db":str(settings.db_file),
        **{f"runtime_{k}":v for k,v in state.items()},
    }
