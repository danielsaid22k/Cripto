from __future__ import annotations

import json
import logging
from typing import Any

from csm.config import settings
from .network import NetworkHTTPError, TransientNetworkError
from .network_v902 import NetworkBusyError, QueuedCurlTransportV902

logger = logging.getLogger(__name__)


class TelegramClientV902:
    def __init__(self, token: str | None = None, transport=None):
        self.token=(token or settings.telegram_token).strip()
        self.transport=transport or QueuedCurlTransportV902(timeout=4.0,connect_timeout=2.0,label="telegram")
        self.base=f"https://api.telegram.org/bot{self.token}"

    def call(self, method: str, data=None, *, timeout: float | None=None):
        payload=self.transport.post_json(f"{self.base}/{method}",data=data or {},timeout=timeout)
        if not isinstance(payload,dict) or not payload.get("ok"):
            description=payload.get("description","Erro Telegram") if isinstance(payload,dict) else "Erro Telegram"
            raise RuntimeError(description)
        return payload.get("result")

    def get_me(self): return self.call("getMe",timeout=4)

    def send(self,chat_id,text:str,reply_markup=None):
        data={"chat_id":str(chat_id),"text":text,"parse_mode":"HTML","disable_web_page_preview":"true"}
        if reply_markup:data["reply_markup"]=json.dumps(reply_markup,ensure_ascii=False)
        return self.call("sendMessage",data,timeout=5)

    def edit(self,chat_id,message_id,text:str,reply_markup=None):
        data={"chat_id":str(chat_id),"message_id":str(message_id),"text":text,"parse_mode":"HTML","disable_web_page_preview":"true"}
        if reply_markup:data["reply_markup"]=json.dumps(reply_markup,ensure_ascii=False)
        return self.call("editMessageText",data,timeout=5)

    def edit_or_send(self,chat_id,message_id,text:str,reply_markup=None):
        try:return self.edit(chat_id,message_id,text,reply_markup)
        except NetworkBusyError: raise
        except Exception:return self.send(chat_id,text,reply_markup)

    def answer_callback(self,callback_id:str,text:str="")->bool:
        if not callback_id:return False
        data={"callback_query_id":callback_id,"cache_time":"0"}
        if text:data["text"]=text[:180]
        try:self.call("answerCallbackQuery",data,timeout=3);return True
        except NetworkBusyError:return False
        except Exception as exc:logger.warning("ACK de callback falhou: %s",exc);return False

    def updates(self,offset=None):
        # Crucial a-Shell rule: if scanner owns curl, do not even attempt to
        # launch Telegram curl. Return control immediately so scanner can poll.
        if getattr(self.transport,"queue_busy",lambda:False)():
            return []
        data:dict[str,Any]={"timeout":"1","allowed_updates":'["message","callback_query"]'}
        if offset is not None:data["offset"]=str(offset)
        try:return self.call("getUpdates",data,timeout=3) or []
        except NetworkBusyError:return []
        except TransientNetworkError:return []
        except NetworkHTTPError as exc:
            if exc.status==429 or exc.status>=500:return []
            raise

    def prepare(self):
        self.call("deleteWebhook",{"drop_pending_updates":"false"},timeout=4)
        commands=[
            {"command":"start","description":"Abrir menu principal"},
            {"command":"analisar","description":"Analisar um contrato"},
            {"command":"planos","description":"Comparar planos"},
            {"command":"meuplano","description":"Consultar assinatura"},
            {"command":"historico","description":"Últimas análises"},
            {"command":"favoritos","description":"Tokens favoritos"},
            {"command":"status","description":"Status do serviço"},
        ]
        self.call("setMyCommands",{"commands":json.dumps(commands,ensure_ascii=False)},timeout=4)
