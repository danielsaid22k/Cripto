from __future__ import annotations

import json
import re
from html import escape
from typing import Any

from csm.chains import CHAINS
from csm.config import settings
from csm.experience import BRAND_DIVIDER, interval_label, plan_group, subscription_timing, keyboard_for_plan, home_text, welcome_text, start_keyboard
from csm.plans import PLANS

MAIN_KEYBOARD = keyboard_for_plan("free")

CALLBACK_PATTERNS = (
    r"^enter_app$", r"^menu$", r"^plans$", r"^preferences$", r"^pref\|[^|]+$", r"^profile\|[^|]+$",
    r"^intelligence_center$", r"^dashboard$", r"^my_plan$", r"^favorites$", r"^export_user$",
    r"^scanner(?:_force|_noop)?$", r"^scanner_page\|\d+$", r"^scanner_detail\|\d+$",
    r"^subscribe\|[^|]+$", r"^paymethod\|[^|]+\|[^|]+$", r"^payment_check$", r"^history\|\d+$",
    r"^(copy|refresh|favorite|unfavorite)\|[^|]+\|.+$",
)
COMPILED_CALLBACKS = tuple(re.compile(x) for x in CALLBACK_PATTERNS)
REPLY_BUTTONS = {
    "🔍 Analisar", "🚀 Scanner", "🌐 Redes", "🧾 Histórico", "👤 Meu plano", "💎 Planos",
    "🧠 Minha Central", "🎛️ Preferências", "🟢 Status", "📡 Sinais automáticos", "⭐ Favoritos",
    "👑 Conhecer Premium", "👑 Central Premium", "👤 Minha assinatura",
}

def callback_supported(data: str) -> bool:
    return any(rx.match(str(data or "")) for rx in COMPILED_CALLBACKS)

def user_keyboard(user: dict) -> dict:
    return keyboard_for_plan(user.get("plan"))

def main_menu(user: dict, first_name: str = "") -> str:
    return home_text(user, first_name)

def welcome(user: dict, first_name: str = ""):
    return welcome_text(user, first_name), start_keyboard()

def networks_text() -> str:
    return "🌐 <b>REDES DISPONÍVEIS</b>\n\n" + "\n".join(f"{v['emoji']} <b>{v['label']}</b> — <code>{k}</code>" for k,v in CHAINS.items())

def plans_text() -> str:
    return (
        "💎 <b>PLANOS E EXPERIÊNCIAS</b>\n" + BRAND_DIVIDER + "\n\n"
        f"🆓 <b>GRÁTIS</b> — scanner a cada 15 min\n\n"
        f"💠 <b>PLUS MENSAL</b> — R$ {settings.asaas_plus_value:.2f}\n"
        f"💠 <b>PLUS ANUAL</b> — R$ {settings.asaas_plus_annual_value:.2f}\n"
        "Scanner a cada 5 min, favoritos e histórico ampliados.\n\n"
        f"👑 <b>PREMIUM MENSAL</b> — R$ {settings.asaas_premium_value:.2f}\n"
        f"👑 <b>PREMIUM ANUAL</b> — R$ {settings.asaas_premium_annual_value:.2f}\n"
        "Radar a cada 1 min e painel Premium.\n\n"
        "✅ PIX/cartão quando Asaas estiver configurado.\n"
        "⚠️ <i>Conteúdo educacional; não há garantia de retorno.</i>"
    )

def sales_keyboard(payments_ready: bool):
    rows=[]
    if payments_ready:
        rows += [
            [{"text":"💠 Plus mensal","callback_data":"subscribe|plus"},{"text":"👑 Premium mensal","callback_data":"subscribe|premium"}],
            [{"text":"💠 Plus anual","callback_data":"subscribe|plus_annual"},{"text":"👑 Premium anual","callback_data":"subscribe|premium_annual"}],
            [{"text":"🔄 Verificar pagamento","callback_data":"payment_check"}],
        ]
    else:
        rows.append([{"text":"📩 Falar com atendimento","url":f"https://t.me/{settings.sales_contact.lstrip('@')}"}])
    rows.append([{"text":"🏠 Menu principal","callback_data":"menu"}])
    return {"inline_keyboard":rows}

def subscription_text(storage, user: dict) -> str:
    plan=PLANS[user["plan"]]; used=storage.count_today(user["user_id"]); limit=plan["limit"]; usage=f"{used}/∞" if limit is None else f"{used}/{limit}"
    due,days,_=subscription_timing(user); group=plan_group(user.get("plan")); renewal="Automática" if group!="free" and settings.asaas_auto_renew else "Manual"
    return (
        f"{BRAND_DIVIDER}\n👤 <b>PHANTOM ALERT • MINHA ASSINATURA</b>\n{BRAND_DIVIDER}\n\n"
        f"Plano: <b>{plan['emoji']} {plan['label']}</b>\nStatus: <b>🟢 Ativo</b>\nScanner: <b>{interval_label(user.get('plan'))}</b>\n\n"
        f"Análises hoje: <b>{usage}</b>\nFavoritos: <b>{storage.favorite_count(user['user_id'])}/{plan['favorites']}</b>\n\n"
        f"Vencimento: <b>{due}</b>\nRestante: <b>{days}</b>\nRenovação: <b>{renewal}</b>"
    )

def status_text(user: dict, scheduler_status: dict) -> str:
    plan=PLANS[user["plan"]]
    return (
        "🟢 <b>SERVIÇO ONLINE</b>\n"
        f"Plano: <b>{plan['emoji']} {plan['label']}</b>\n"
        "Runtime: <b>v9 single-runtime</b>\n"
        f"Scanner: <b>{'em ciclo' if scheduler_status.get('scanner_active') else 'aguardando'}</b>\n"
        f"Próximo ciclo: <b>{scheduler_status.get('next_cycle_text','—')}</b>\n"
        "Rede externa: <b>curl isolado</b>"
    )

def auto_signals_text(user: dict, scheduler_status: dict) -> str:
    prefs=scheduler_status.get("prefs") or {}; enabled=prefs.get("auto_signals",True)
    return (
        "📡 <b>SINAIS AUTOMÁTICOS</b>\n\n"
        f"Estado: <b>{'🟢 Ativos' if enabled else '⏸ Pausados'}</b>\n"
        f"Frequência do plano: <b>{interval_label(user.get('plan'))}</b>\n"
        f"Scanner agora: <b>{'processando' if scheduler_status.get('scanner_active') else 'aguardando'}</b>\n"
        f"Próximo ciclo: <b>{scheduler_status.get('next_cycle_text','—')}</b>\n\n"
        "Este botão apenas consulta o estado. O scanner é controlado pelo scheduler e não é iniciado pelo callback."
    )

def preferences_screen(app, user_id: int):
    profile=app.user_profiles.get(user_id); stored=app.storage.user_preferences(user_id); chains=", ".join(profile.get("preferred_chains") or []) or "Todas"
    labels={"conservative":"Conservador","moderate":"Moderado","aggressive":"Agressivo"}; detail={"compact":"Compacto","standard":"Equilibrado","detailed":"Detalhado"}; freq={"plan":"Padrão do plano","reduced":"Reduzida","priority":"Prioritária"}; quiet={"off":"Desativado","22-07":"22h às 07h","00-07":"00h às 07h"}
    text=(f"{BRAND_DIVIDER}\n🎛️ <b>PREFERÊNCIAS</b>\n{BRAND_DIVIDER}\n\n"
          f"Risco: <b>{labels.get(profile.get('risk_profile'),'Moderado')}</b>\nRedes: <b>{escape(chains)}</b>\nMensagens: <b>{detail.get(profile.get('detail_mode'),'Equilibrado')}</b>\n"
          f"Frequência: <b>{freq.get(profile.get('notification_frequency'),'Padrão do plano')}</b>\nHorário silencioso: <b>{quiet.get(profile.get('quiet_hours'),'Desativado')}</b>\nIdioma: <b>{escape(str(profile.get('language') or 'pt-BR'))}</b>\n\n"
          f"Sinais automáticos: <b>{'Ativos' if stored.get('auto_signals',True) else 'Pausados'}</b>\nFavoritos: <b>{'Ativos' if stored.get('favorite_alerts',True) else 'Pausados'}</b>\nVencimento: <b>{'Ativos' if stored.get('expiry_alerts',True) else 'Pausados'}</b>")
    kb={"inline_keyboard":[
        [{"text":"🎯 Perfil de risco","callback_data":"profile|risk"},{"text":"🌐 Redes","callback_data":"profile|chains"}],
        [{"text":"📝 Mensagens","callback_data":"profile|detail"},{"text":"⏱ Frequência","callback_data":"profile|frequency"}],
        [{"text":"🌙 Horário silencioso","callback_data":"profile|quiet"},{"text":"🌎 Idioma","callback_data":"profile|language"}],
        [{"text":"📡 Sinais automáticos","callback_data":"pref|auto_signals"}],
        [{"text":"⭐ Alertas dos favoritos","callback_data":"pref|favorite_alerts"}],
        [{"text":"📅 Avisos de vencimento","callback_data":"pref|expiry_alerts"}],
        [{"text":"🧠 Minha Central","callback_data":"intelligence_center"}], [{"text":"🏠 Menu","callback_data":"menu"}],
    ]}
    return text,kb

def central_screen(app,user_id:int):
    user=app.storage.get_user(user_id); plan=PLANS[user["plan"]]; profile=app.user_profiles.get(user_id); stats=app.storage.user_signal_stats(user_id); recent=app.storage.recent_signal_results(user_id,4)
    due,days,_=subscription_timing(user); lines=[]
    for row in recent[:4]: lines.append(f"• {escape(str(row.get('symbol') or 'Token'))}: <b>{escape(str(row.get('outcome') or row.get('status') or '—'))}</b> {float(row.get('result_pct') or 0):+.1f}%")
    if not lines: lines=["• Nenhum sinal acompanhado ainda"]
    text=(f"{BRAND_DIVIDER}\n🧠 <b>PHANTOM ALERT • MINHA CENTRAL</b>\n{BRAND_DIVIDER}\n\n"
          f"Plano: <b>{plan['emoji']} {plan['label']}</b>\nVencimento: <b>{due}</b>\nDias restantes: <b>{days}</b>\n"
          f"Sinais acompanhados: <b>{int(stats.get('total',0) or 0)}</b>\nFavoritos: <b>{app.storage.favorite_count(user_id)}</b>\nAnálises hoje: <b>{app.storage.count_today(user_id)}</b>\n\n"
          "📈 <b>HISTÓRICO RECENTE</b>\n"+"\n".join(lines)+"\n\n🛡️ Tela 100% local; nenhum provider é consultado aqui.")
    kb={"inline_keyboard":[[{"text":"🧾 Histórico","callback_data":"history|0"},{"text":"⭐ Favoritos","callback_data":"favorites"}],[{"text":"🎛️ Preferências","callback_data":"preferences"}],[{"text":"👤 Assinatura","callback_data":"my_plan"}],[{"text":"📤 Exportar meus dados","callback_data":"export_user"}],[{"text":"🏠 Menu","callback_data":"menu"}]]}
    return text,kb

def dashboard_screen(app,user_id:int):
    user=app.storage.get_user(user_id); stats=app.storage.user_signal_stats(user_id); scan=app.storage.scanner_stats_today()
    text=(f"{BRAND_DIVIDER}\n👑 <b>PHANTOM ALERT • CENTRAL PREMIUM</b>\n{BRAND_DIVIDER}\n\n"
          f"Plano: <b>{PLANS[user['plan']]['label']}</b>\nScanner: <b>{interval_label(user.get('plan'))}</b>\n"
          f"Ciclos hoje: <b>{scan.get('cycles',0)}</b>\nSinais entregues: <b>{scan.get('sent',0)}</b>\n"
          f"Sinais acompanhados: <b>{stats.get('total',0)}</b>\n\n🛡️ Painel local; abrir esta tela não dispara scanner nem chamada externa.")
    kb={"inline_keyboard":[[{"text":"👤 Minha assinatura","callback_data":"my_plan"}],[{"text":"⭐ Favoritos","callback_data":"favorites"},{"text":"🧾 Histórico","callback_data":"history|0"}],[{"text":"🎛️ Preferências","callback_data":"preferences"}],[{"text":"📤 Exportar meus dados","callback_data":"export_user"}],[{"text":"💎 Planos","callback_data":"plans"}],[{"text":"🏠 Menu","callback_data":"menu"}]]}
    return text,kb

def export_text(data: dict) -> str:
    raw=json.dumps(data,ensure_ascii=False,indent=2,default=str)
    if len(raw)>3500: raw=raw[:3500]+"\n..."
    return "📤 <b>EXPORTAÇÃO DA CONTA</b>\n\n<code>"+escape(raw)+"</code>"
