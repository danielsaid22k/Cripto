# CSM Retool Admin Center — blueprint

## Resource

Crie um Resource REST/OpenAPI apontando para o endpoint HTTPS do CSM. Use autenticação Bearer com o valor criado por `python main.py retool-token`. Nunca salve a Speechify API key no Retool.

## Página 1 — Visão geral

Use `GET /api/retool/overview` como consulta principal. Cards sugeridos: CSM online/offline, PID, scanner, sinais observados, win rate, provider health, Daniel AI, motor de voz ativo e Speechify configurada.

Botões operacionais, com confirmação antes da execução:

- Iniciar: `POST /api/actions/runtime/start`
- Parar: `POST /api/actions/runtime/stop`
- Reiniciar: `POST /api/actions/runtime/restart`
- Doctor: `POST /api/actions/doctor`
- Backup: `POST /api/actions/backup`
- Selftest: `POST /api/actions/selftest`

Depois de cada botão, rode novamente `GET /api/retool/overview`.

## Página 2 — Sinais e performance

Tabela: `GET /api/signals`. Métricas: `GET /api/performance`. Para detalhe de segurança/on-chain, use `/api/security`, `/api/onchain`, `/api/reputation` e `/api/observability`.

## Página 3 — Clientes e assinaturas

Tabelas somente leitura: `GET /api/users` e `GET /api/subscriptions`. Nesta primeira versão não há endpoint do Retool para alterar plano, cobrança ou wallet. Isso evita que um clique administrativo bypassasse as regras atuais do CSM/Asaas.

## Página 4 — Daniel AI

Status: `GET /api/daniel-ai`. Campo de pergunta + botão que chama `POST /api/daniel-ai/ask` com JSON `{ "question": "...", "user_id": 0 }`.

## Página 5 — Operações e auditoria

Eventos: `GET /api/events`. Saúde: `GET /api/observability`. Exiba os resultados de Doctor/Selftest em uma caixa de texto ou modal.

## Segurança

O Admin Bridge fica ligado em `127.0.0.1:8765` e exige `ADMIN_WEB_TOKEN`. O Retool deve chegar nele por HTTPS. Não exponha a porta 8765 diretamente na Internet. Use um túnel HTTPS autenticado/gerenciado. O token deve ficar no Resource/secret do Retool, nunca em componentes visíveis do app.

## Update Center — Finalizar atualização (v16.5.5)

Depois que `POST /api/update/apply` retornar `APPLIED`, use um botão **Finalizar atualização** ligado a `POST /api/update/finalize`. O endpoint inicia o finalizador em processo separado e retorna HTTP 202 rapidamente, permitindo que o próprio Admin Bridge seja reiniciado com segurança no fim do fluxo.

Crie também uma query de acompanhamento em `GET /api/update/finalize/status`. Enquanto `running=true`, faça polling periódico. O resultado final esperado é `report.status = APPROVED`. Se `report.status = BLOCKED` ou `FAILED`, mostre `report.blocked_by` e as etapas; o Runtime/Admin Bridge não são reiniciados quando uma validação prévia falha.

Ordem interna do Finalizer:

- migrate
- db-check
- selftest
- release-check
- version
- config-integrity preflight
- restart Runtime via Supervisor
- validação de saúde do Bot + SaaS API
- restart Admin Bridge

Na primeira atualização que instala a v16.5.5, finalize uma única vez pelo Termux com `python main.py post-update`, pois o Admin Bridge anterior ainda não conhece o novo endpoint até ser reiniciado. A partir daí, versões futuras podem ser finalizadas diretamente pelo botão do Retool.

## v16.5.6 — comportamento do Finalizar atualização

O endpoint existente `POST /api/update/finalize` mantém a mesma interface. O backend agora usa migração in-place sem auto-restore de backup anterior e aguarda Bot + SaaS API `/healthz` por até 60 segundos após restart. Nenhuma mudança de botão/query é necessária no Retool.


## v16.5.7 — Provider Coverage & Stability

- DexPaprika entra automaticamente como fonte pública/keyless adicional.
- Setup Center pode editar `DEXPAPRIKA_ENABLED`, `DEXPAPRIKA_BASE_URL`, chave opcional e limites de uso.
- Birdeye Compute Units recebe cooldown longo; providers públicos continuam ativos.
- Nenhum controle existente do Retool foi removido.
