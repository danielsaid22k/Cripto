#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONUNBUFFERED=1
exec python3 -u launcher.py bot
