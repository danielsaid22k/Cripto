#!/bin/sh
export CSM_STATE_DIR='/mnt/data/work_v630/Crypto_Signals_Multichain_Staging_State'
export APP_ENVIRONMENT=staging
python main.py "$@"
