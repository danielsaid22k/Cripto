#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")"
echo "=== 1. STATUS DO MOTOR ==="
python main.py daniel-speech-status || exit 1
echo
echo "=== 2. GERAÇÃO DE ÁUDIO ==="
python main.py daniel-speech-test || exit 1
echo
echo "=== 3. TESTE DO BOT ==="
echo "Reinicie o CSM e mande uma nota de voz no Telegram."
echo "Esperado: transcrição → resposta em texto → resposta em áudio neural."
