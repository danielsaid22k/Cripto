"""Test bootstrap shared by a-Shell, desktop Python and CI.

pytest launched as an executable on iOS may omit the project root from
``sys.path``.  Add it explicitly so imports match ``python main.py`` without
requiring users to set PYTHONPATH manually.
"""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
root = str(PROJECT_ROOT)
if root not in sys.path:
    sys.path.insert(0, root)


def pytest_sessionfinish(session, exitstatus):
    """Direct pytest runs create v10 and compatibility v9 release receipts.

    This keeps foundation-release from starting a second Python/pytest process on
    a-Shell, which was the source of divergent results in the 8.x line.
    """
    for module_name in ("phantom_v10.release", "phantom_v9.release"):
        try:
            module = __import__(module_name, fromlist=["write_test_receipt"])
            module.write_test_receipt(int(exitstatus), "pytest direct session")
        except Exception:
            pass
