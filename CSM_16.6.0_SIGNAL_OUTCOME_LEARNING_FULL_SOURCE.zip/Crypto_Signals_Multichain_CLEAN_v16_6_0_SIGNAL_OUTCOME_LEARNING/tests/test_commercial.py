from pathlib import Path
import tempfile

from csm.chains import normalize_chain, detect_chain
from csm.formatting import report, score_market, compact_address
from csm.market import MarketClient
from csm.plans import normalize_plan
from csm.storage import Storage


class FakeHTTP:
    def get_json(self, url, params=None):
        return [{
            "chainId": "solana",
            "dexId": "pump",
            "url": "https://dexscreener.com/solana/example",
            "pairAddress": "pair",
            "baseToken": {"address": "abc", "name": "Teste", "symbol": "TST"},
            "priceUsd": "0.01",
            "liquidity": {"usd": 200000},
            "volume": {"h24": 700000, "h6": 200000, "h1": 50000},
            "marketCap": 1000000,
            "fdv": 1200000,
            "priceChange": {"h24": 3, "h6": 2, "h1": 1},
            "txns": {
                "h24": {"buys": 100, "sells": 50},
                "h6": {"buys": 40, "sells": 20},
                "h1": {"buys": 10, "sells": 5},
            },
            "pairCreatedAt": 1700000000000,
        }]


def make_storage():
    temp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    temp.close()
    return Storage(Path(temp.name))


def test_chains():
    assert normalize_chain("SOL") == "solana"
    assert normalize_chain("bnb") == "bsc"
    assert detect_chain("0x" + "a" * 40) == "ethereum"


def test_plan():
    assert normalize_plan("vip") == "plus"


def test_market_and_report():
    market = MarketClient(FakeHTTP()).fetch("solana", "abc")
    text, score = report(market, "premium")
    assert score >= 75
    assert "PAINEL PREMIUM" in text
    assert "COMPOSIÇÃO DO SCORE" in text


def test_address_compaction():
    assert "…" in compact_address("123456789012345678901234567890")


def test_storage_favorites_and_history():
    storage = make_storage()
    storage.upsert_user(1, "teste", "Teste")
    market = {"name": "Token", "symbol": "TST", "source": "Fake"}
    storage.save_analysis(1, "solana", "abc", 80, market)
    assert storage.history_count(1) == 1
    assert storage.add_favorite(1, "solana", "abc", market)
    assert not storage.add_favorite(1, "solana", "abc", market)
    assert storage.favorite_count(1) == 1
    assert storage.remove_favorite(1, "solana", "abc")


def test_admin_plan_and_block():
    storage = make_storage()
    storage.set_plan(2, "premium", 30)
    assert storage.get_user(2)["plan"] == "premium"
    storage.set_blocked(2, True)
    assert storage.get_user(2)["blocked"] == 1


def test_secret_redaction():
    from csm.logging_setup import redact
    token = "987654321:" + "A" * 35
    key = "$aact_prod_" + "b" * 36
    text = redact(f"TELEGRAM_BOT_TOKEN={token} access_token: {key}")
    assert token not in text
    assert key not in text
    assert "REDACTED" in text


def test_telegram_poll_timeout_is_recoverable(monkeypatch):
    from csm.http_client import HTTPTransientError
    from csm.telegram import Telegram

    class TimeoutHTTP:
        def post_json(self, url, data=None, json_data=None, timeout=None):
            raise HTTPTransientError("timeout temporário")

    monkeypatch.setattr("csm.telegram.time.sleep", lambda _seconds: None)
    telegram = Telegram(http=TimeoutHTTP())
    assert telegram.updates() == []



def test_telegram_transient_timeout_is_recoverable(monkeypatch):
    from csm.http_client import HTTPTransientError
    from csm.telegram import Telegram

    class TimeoutHTTP:
        def post_json(self, url, data=None, json_data=None, timeout=None):
            raise HTTPTransientError("timeout direto")

    monkeypatch.setattr("csm.telegram.time.sleep", lambda _seconds: None)
    telegram = Telegram(http=TimeoutHTTP())
    assert telegram.updates() == []

def test_intelligent_scanner_filters_and_cache(monkeypatch):
    from csm.scanner import MultichainScanner

    class DiscoveryHTTP:
        def get_json(self, url, params=None):
            return [
                {"chainId": "solana", "tokenAddress": "good"},
                {"chainId": "solana", "tokenAddress": "bad"},
                {"chainId": "unknown", "tokenAddress": "skip"},
            ]

    class FakeMarket:
        calls = 0
        def fetch(self, chain, address, force=False):
            self.calls += 1
            base = {
                "chain": chain, "address": address, "symbol": address.upper(),
                "liquidity": 200000, "volume24h": 500000, "marketcap": 1000000,
                "age_days": 10, "change24h": 5, "buys24h": 100, "sells24h": 50,
            }
            if address == "bad":
                base["liquidity"] = 10
            return base

    scanner = MultichainScanner(market=FakeMarket(), http=DiscoveryHTTP())
    first = scanner.scan(limit=20, chains=["solana"])
    second = scanner.scan(limit=20, chains=["solana"])
    assert [item["address"] for item in first] == ["good"]
    assert second[0]["scanner_cached"] is True
    assert scanner.last_stats["approved"] == 1
    assert scanner.last_stats["rejected"] == 1


def test_scanner_presentation_is_paginated():
    from csm.app import App

    class DummyScanner:
        last_stats = {"discovered": 9, "analyzed": 9, "approved": 7, "errors": 0}
        def scan(self, force=False):
            return [
                {
                    "symbol": f"TOK{i}", "chain": "solana", "score": 90 - i,
                    "liquidity": 150000 + i, "volume24h": 5500000 + i,
                    "age_days": 10 + i, "address": f"address{i}",
                }
                for i in range(7)
            ]

    app = App.__new__(App)
    app.scanner = DummyScanner()
    app.scanner_sessions = {}
    text, keyboard = app.scanner_text(123, page=0)
    assert "página 1/3" in text
    assert "US$ 5.50 mi" in text
    assert "scanner_page|1" in str(keyboard)
    assert "scanner_detail|0" in str(keyboard)


def test_setup_wizard_writes_env_without_hidden_input(tmp_path, monkeypatch):
    import csm.setup_wizard as wizard

    example = tmp_path / ".env.example"
    env_file = tmp_path / ".env"
    example.write_text(
        "ENABLE_TELEGRAM=true\nTELEGRAM_BOT_TOKEN=\nTELEGRAM_CHAT_ID=\nADMIN_USER_IDS=\n"
        "ASAAS_ENABLED=false\nASAAS_ENVIRONMENT=sandbox\nASAAS_API_KEY=\n"
        "ASAAS_PAYMENT_METHODS=PIX,CREDIT_CARD\n"
        "SCAN_LIMIT=200\nSCAN_WORKERS=2\nSCAN_MIN_LIQUIDITY=10000\nSCAN_MIN_VOLUME24H=25000\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(wizard, "EXAMPLE_FILE", example)
    monkeypatch.setattr(wizard, "ENV_FILE", env_file)
    answers = iter([
        "5",  # configuração completa
        "987654321:" + "A" * 35,  # token visível no a-Shell
        "123456789",  # chat id
        "123456789",  # admin id
        "n",  # Asaas desativado neste teste
        "2",  # scanner balanceado
    ])
    monkeypatch.setattr("builtins.input", lambda _prompt="": next(answers))
    assert wizard.run_setup() == 0
    content = env_file.read_text(encoding="utf-8")
    assert "TELEGRAM_CHAT_ID=123456789" in content
    assert "SCAN_LIMIT=100" in content
    assert "SCAN_WORKERS=2" in content
    assert "ASAAS_ENABLED=false" in content
