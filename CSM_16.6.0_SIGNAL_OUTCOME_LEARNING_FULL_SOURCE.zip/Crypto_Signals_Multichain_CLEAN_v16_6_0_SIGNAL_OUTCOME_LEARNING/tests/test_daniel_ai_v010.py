from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.memory import DanielMemory
from daniel_ai.openai_provider import OpenAIDisabled, OpenAIProvider
from daniel_ai.tools import DanielTools


def _cfg(tmp_path: Path, monkeypatch, **env):
    monkeypatch.setenv("CSM_STATE_DIR", str(tmp_path / "state"))
    monkeypatch.setenv("DANIEL_AI_ENABLED", env.get("DANIEL_AI_ENABLED", "true"))
    monkeypatch.setenv("OPENAI_ENABLED", env.get("OPENAI_ENABLED", "false"))
    monkeypatch.setenv("OPENAI_API_KEY", env.get("OPENAI_API_KEY", ""))
    monkeypatch.setenv("DANIEL_AI_DOCUMENTS_DIR", str(tmp_path / "docs"))
    # DanielSettings uses csm.STATE_DIR resolved at import time in the test process,
    # so override resulting paths explicitly for isolated unit tests.
    base = DanielSettings.from_env()
    return DanielSettings(
        enabled=base.enabled, admin_only=base.admin_only, memory_enabled=base.memory_enabled,
        history_limit=base.history_limit, max_question_chars=base.max_question_chars,
        openai_enabled=base.openai_enabled, openai_api_key=base.openai_api_key,
        openai_model=base.openai_model, web_enabled=base.web_enabled,
        documents_enabled=base.documents_enabled, documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel", db_file=tmp_path / "daniel" / "daniel_ai.db",
    )


def _make_csm_db(path: Path):
    conn = sqlite3.connect(path)
    conn.executescript("""
    CREATE TABLE signal_ledger(
      id INTEGER PRIMARY KEY,chain TEXT,address TEXT,symbol TEXT,name TEXT,final_score INTEGER,
      liquidity REAL,volume24h REAL,marketcap REAL,change24h REAL,buys24h INTEGER,sells24h INTEGER,
      goplus_score INTEGER,goplus_risk TEXT,last_return_pct REAL,max_return_pct REAL,status TEXT,source TEXT,
      observations INTEGER DEFAULT 0,first_tp1_at TEXT,first_stop_at TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE scanner_cycles(
      id INTEGER PRIMARY KEY,plan_group TEXT,discovered INTEGER,approved INTEGER,eligible INTEGER,sent INTEGER,
      errors INTEGER,top_score INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE users(user_id INTEGER PRIMARY KEY,plan TEXT);
    """)
    conn.execute("INSERT INTO signal_ledger VALUES(1,'solana','abc','ABC','Alpha',91,120000,450000,1000000,18.5,100,40,82,'LOW',12.0,35.0,'ACTIVE','dex',2,'2026-08-19',NULL,CURRENT_TIMESTAMP)")
    conn.execute("INSERT INTO scanner_cycles VALUES(1,'premium',40,5,4,3,0,91,CURRENT_TIMESTAMP)")
    conn.execute("INSERT INTO users VALUES(1,'premium')")
    conn.execute("INSERT INTO users VALUES(2,'free')")
    conn.commit(); conn.close()


def test_openai_is_off_by_default(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch, OPENAI_ENABLED="false", OPENAI_API_KEY="sk-test")
    assert cfg.openai_enabled is False
    assert cfg.openai_ready is False
    try:
        OpenAIProvider(cfg).generate("teste")
    except OpenAIDisabled as exc:
        assert "OPENAI_ENABLED=false" in str(exc)
    else:
        raise AssertionError("provider deveria permanecer desligado")


def test_memory_persists(tmp_path):
    path = tmp_path / "daniel.db"
    with DanielMemory(path) as mem:
        mem.add_message(7, "user", "olá")
        mem.remember("perfil", "admin", 7)
    with DanielMemory(path) as mem:
        assert mem.history(7)[0]["content"] == "olá"
        assert mem.recall("perfil", 7) == "admin"


def test_tools_are_read_only_and_query_csm(tmp_path, monkeypatch):
    db = tmp_path / "signals.db"
    _make_csm_db(db)
    cfg = _cfg(tmp_path, monkeypatch)
    tools = DanielTools(cfg, csm_db=db)
    assert tools.top_signals(days=1, limit=5).data[0]["symbol"] == "ABC"
    assert tools.scanner_status().data[0]["sent"] == 3
    assert tools.user_plan_summary().data["premium"] == 1


def test_engine_answers_from_real_csm_data(tmp_path, monkeypatch):
    db = tmp_path / "signals.db"
    _make_csm_db(db)
    cfg = _cfg(tmp_path, monkeypatch)
    mem = DanielMemory(cfg.db_file)
    ai = DanielAI(cfg, tools=DanielTools(cfg, csm_db=db), memory=mem)
    answer = ai.ask("quais os melhores sinais de 1 dia?", user_id=1)
    assert "ABC" in answer
    assert "91/100" in answer
    assert "Modo local" in answer
    mem.close()


def test_documents_reject_path_escape(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch)
    cfg.documents_dir.mkdir(parents=True, exist_ok=True)
    (cfg.documents_dir / "ok.md").write_text("conteúdo seguro", encoding="utf-8")
    tools = DanielTools(cfg, csm_db=tmp_path / "missing.db")
    assert tools.read_document("ok.md").ok is True
    assert tools.read_document("../segredo.txt").ok is False


def test_status_never_exposes_openai_key(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch, OPENAI_ENABLED="false", OPENAI_API_KEY="sk-super-secret")
    ai = DanielAI(cfg, tools=DanielTools(cfg, csm_db=tmp_path / "missing.db"))
    text = repr(ai.status())
    assert "sk-super-secret" not in text
    assert ai.status()["openai_enabled"] is False


def test_main_parser_exposes_daniel_commands():
    import main
    parser = main.build_parser()
    for argv in (["daniel-status"], ["daniel-tools"], ["daniel-history"], ["daniel-ask", "status"]):
        parsed = parser.parse_args(argv)
        assert parsed.cmd.startswith("daniel-")
