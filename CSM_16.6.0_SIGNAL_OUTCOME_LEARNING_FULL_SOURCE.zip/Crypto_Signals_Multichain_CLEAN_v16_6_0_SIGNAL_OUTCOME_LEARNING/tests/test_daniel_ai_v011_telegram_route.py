from __future__ import annotations


class _Storage:
    def upsert_user(self, user_id, username, first_name):
        return {"user_id": user_id, "plan": "premium", "status": "active"}


class _Telegram:
    def __init__(self):
        self.sent = []

    def send(self, chat_id, text, keyboard=None):
        self.sent.append((chat_id, text, keyboard))
        return {"ok": True}


class _App:
    def __init__(self, admin=True):
        self.telegram = _Telegram()
        self.storage = _Storage()
        self.pending_payment = {}
        self._admin = admin
        self.warnings = []

    def is_admin(self, user_id):
        return self._admin

    def log_warning(self, text):
        self.warnings.append(text)


def test_active_phantom_router_handles_daniel_status(monkeypatch, tmp_path):
    monkeypatch.setenv("DANIEL_AI_ENABLED", "true")
    monkeypatch.setenv("DANIEL_AI_ADMIN_ONLY", "true")
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    app = _App(admin=True)

    # Keep the route test isolated from the production CSM database.
    from daniel_ai.engine import DanielAI
    monkeypatch.setattr(DanielAI, "ask", lambda self, q, user_id=0, source="local": "DANIEL_ROUTE_OK")

    from phantom_v10.router import InteractionRouter
    result = InteractionRouter(app).message({
        "chat": {"id": 123},
        "from": {"id": 123, "username": "admin", "first_name": "Admin"},
        "text": "/daniel status do sistema",
    })
    assert result == {"ok": True}
    assert app.telegram.sent[-1][1] == "DANIEL_ROUTE_OK"


def test_active_phantom_router_accepts_ai_alias(monkeypatch):
    monkeypatch.setenv("DANIEL_AI_ADMIN_ONLY", "true")
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    app = _App(admin=True)
    from daniel_ai.engine import DanielAI
    monkeypatch.setattr(DanielAI, "ask", lambda self, q, user_id=0, source="local": "AI_ALIAS_OK")
    from phantom_v10.router import InteractionRouter
    InteractionRouter(app).message({"chat":{"id":1},"from":{"id":1},"text":"/ai scanner"})
    assert app.telegram.sent[-1][1] == "AI_ALIAS_OK"


def test_active_phantom_router_keeps_admin_only(monkeypatch):
    monkeypatch.setenv("DANIEL_AI_ADMIN_ONLY", "true")
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    app = _App(admin=False)
    from phantom_v10.router import InteractionRouter
    InteractionRouter(app).message({"chat":{"id":2},"from":{"id":2},"text":"/daniel status"})
    assert "somente para o administrador" in app.telegram.sent[-1][1]


def test_daniel_command_bypasses_pending_payment_state(monkeypatch):
    monkeypatch.setenv("DANIEL_AI_ADMIN_ONLY", "true")
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    app = _App(admin=True)
    app.pending_payment[3] = {"plan":"premium","name":"X","billing_type":"PIX"}
    from daniel_ai.engine import DanielAI
    monkeypatch.setattr(DanielAI, "ask", lambda self, q, user_id=0, source="local": "PENDING_OK")
    from phantom_v10.router import InteractionRouter
    InteractionRouter(app).message({"chat":{"id":3},"from":{"id":3},"text":"/daniel status"})
    assert app.telegram.sent[-1][1] == "PENDING_OK"
    assert 3 in app.pending_payment
