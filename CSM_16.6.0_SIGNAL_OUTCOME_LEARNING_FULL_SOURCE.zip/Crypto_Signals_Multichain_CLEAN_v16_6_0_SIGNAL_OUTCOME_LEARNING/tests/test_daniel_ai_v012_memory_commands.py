from __future__ import annotations

from pathlib import Path

from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools


def _cfg(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("DANIEL_AI_ENABLED", "true")
    monkeypatch.setenv("DANIEL_AI_MEMORY_ENABLED", "true")
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    base = DanielSettings.from_env()
    return DanielSettings(
        enabled=base.enabled,
        admin_only=base.admin_only,
        memory_enabled=True,
        history_limit=base.history_limit,
        max_question_chars=base.max_question_chars,
        openai_enabled=False,
        openai_api_key="",
        openai_model=base.openai_model,
        web_enabled=base.web_enabled,
        documents_enabled=base.documents_enabled,
        documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel",
        db_file=tmp_path / "daniel" / "daniel_ai.db",
    )


def _ai(tmp_path: Path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch)
    mem = DanielMemory(cfg.db_file)
    return DanielAI(cfg, tools=DanielTools(cfg, csm_db=tmp_path / "missing.db"), memory=mem), mem


def test_natural_remember_and_recall(tmp_path, monkeypatch):
    ai, mem = _ai(tmp_path, monkeypatch)
    saved = ai.ask("lembre que meu teste favorito é CATE", user_id=77, source="telegram")
    assert "Memória salva" in saved
    assert mem.recall("teste favorito", 77) == "CATE"
    recalled = ai.ask("qual é meu teste favorito?", user_id=77, source="telegram")
    assert "CATE" in recalled
    mem.close()


def test_memories_are_isolated_per_user(tmp_path, monkeypatch):
    ai, mem = _ai(tmp_path, monkeypatch)
    ai.ask("lembre que minha rede favorita é Solana", user_id=1)
    assert "Solana" in ai.ask("qual é minha rede favorita?", user_id=1)
    assert "não encontrei" in ai.ask("qual é minha rede favorita?", user_id=2).casefold()
    mem.close()


def test_list_and_forget_memory(tmp_path, monkeypatch):
    ai, mem = _ai(tmp_path, monkeypatch)
    ai.ask("lembre que meu teste favorito é CATE", user_id=5)
    listing = ai.ask("quais são minhas memórias salvas?", user_id=5)
    assert "teste favorito" in listing
    removed = ai.ask("esqueça teste favorito", user_id=5)
    assert "Memória removida" in removed
    assert mem.recall("teste favorito", 5) is None
    mem.close()


def test_memory_commands_keep_openai_off(tmp_path, monkeypatch):
    ai, mem = _ai(tmp_path, monkeypatch)
    ai.ask("lembre que meu teste favorito é CATE", user_id=9)
    assert ai.status()["openai_enabled"] is False
    mem.close()
