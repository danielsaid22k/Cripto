from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from daniel_ai import __version__
from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools


def _cfg(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("DANIEL_AI_ENABLED", "true")
    monkeypatch.setenv("DANIEL_AI_MEMORY_ENABLED", "true")
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    base = DanielSettings.from_env()
    return DanielSettings(
        enabled=True,
        admin_only=True,
        memory_enabled=True,
        history_limit=50,
        max_question_chars=4000,
        openai_enabled=False,
        openai_api_key="",
        openai_model=base.openai_model,
        web_enabled=False,
        documents_enabled=True,
        documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel",
        db_file=tmp_path / "daniel" / "daniel_ai.db",
    )


def _db(path: Path):
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE signal_ledger(
          id INTEGER PRIMARY KEY,event_key TEXT,chain TEXT,address TEXT,symbol TEXT,name TEXT,plan_groups TEXT,
          entry_price REAL,market_score INTEGER,final_score INTEGER,goplus_score INTEGER,goplus_risk TEXT,
          goplus_buy_tax_pct REAL,goplus_sell_tax_pct REAL,goplus_top10_holders_pct REAL,
          deployer_reputation_score INTEGER,deployer_reputation_confidence INTEGER,deployer_reputation_rating TEXT,
          liquidity REAL,volume24h REAL,marketcap REAL,change24h REAL,buys24h INTEGER,sells24h INTEGER,source TEXT,
          providers_json TEXT,approval_reasons_json TEXT,target1_pct REAL,target2_pct REAL,stop_pct REAL,
          delivered_count INTEGER,observations INTEGER,last_price REAL,last_return_pct REAL,max_return_pct REAL,
          max_drawdown_pct REAL,first_tp1_at TEXT,first_tp2_at TEXT,first_stop_at TEXT,status TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE signal_observations(
          id INTEGER PRIMARY KEY,signal_id INTEGER,captured_at TEXT,age_seconds REAL,price REAL,return_pct REAL,
          liquidity REAL,volume24h REAL,marketcap REAL,score INTEGER
        );
        CREATE TABLE onchain_snapshots(
          id INTEGER PRIMARY KEY,signal_id INTEGER,captured_at TEXT,chain TEXT,address TEXT,source TEXT,
          onchain_score INTEGER,risk_level TEXT,top10_holders_pct REAL,transfer_count INTEGER,unique_wallets INTEGER,
          whale_transfer_count INTEGER,whale_volume_usd REAL,mint_events INTEGER,burn_events INTEGER,liquidity REAL,
          liquidity_change_pct REAL,deployer_address TEXT,deployer_score INTEGER,activity_count INTEGER,notes_json TEXT
        );
        CREATE TABLE scanner_cycles(
          id INTEGER PRIMARY KEY,plan_group TEXT,discovered INTEGER,approved INTEGER,eligible INTEGER,sent INTEGER,
          errors INTEGER,top_score INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE ops_metrics(
          id INTEGER PRIMARY KEY,component TEXT,metric_name TEXT,value REAL,unit TEXT,status TEXT,labels_json TEXT,
          occurred_at TEXT DEFAULT CURRENT_TIMESTAMP,created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE ops_incidents(
          id INTEGER PRIMARY KEY,incident_key TEXT,component TEXT,severity TEXT,status TEXT,summary TEXT,details_json TEXT,
          first_seen TEXT,last_seen TEXT,occurrences INTEGER,resolved_at TEXT
        );
        CREATE TABLE users(user_id INTEGER PRIMARY KEY,plan TEXT);
        """
    )
    reasons = json.dumps(["liquidez acima do mínimo", "momentum aprovado"], ensure_ascii=False)
    conn.execute(
        """INSERT INTO signal_ledger(
             id,event_key,chain,address,symbol,name,plan_groups,entry_price,market_score,final_score,goplus_score,goplus_risk,
             goplus_top10_holders_pct,deployer_reputation_score,deployer_reputation_rating,liquidity,volume24h,marketcap,
             change24h,buys24h,sells24h,source,providers_json,approval_reasons_json,target1_pct,target2_pct,stop_pct,
             delivered_count,observations,last_price,last_return_pct,max_return_pct,max_drawdown_pct,status,created_at,updated_at
           ) VALUES(1,'e1','solana','addr-cate','CATE','Cate Token','premium',1,94,100,88,'LOW',18,82,'GOOD',
                    852400,2240000,13950000,21.03,120,80,'dexscreener','[\"dexscreener\",\"geckoterminal\"]',?,25,50,12,
                    1,5,1.21,21,35,-8,'ACTIVE',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)""",
        (reasons,),
    )
    conn.execute(
        """INSERT INTO signal_ledger(
             id,event_key,chain,address,symbol,name,plan_groups,entry_price,market_score,final_score,goplus_score,goplus_risk,
             goplus_top10_holders_pct,deployer_reputation_score,deployer_reputation_rating,liquidity,volume24h,marketcap,
             change24h,buys24h,sells24h,source,providers_json,approval_reasons_json,target1_pct,target2_pct,stop_pct,
             delivered_count,observations,last_price,last_return_pct,max_return_pct,max_drawdown_pct,status,created_at,updated_at
           ) VALUES(2,'e2','solana','addr-gore','GORE','Gore Token','premium',1,75,81,65,'MEDIUM',55,50,'NEUTRAL',
                    34700,160100,900000,199.46,40,60,'geckoterminal','[\"geckoterminal\"]','[]',25,50,12,
                    1,3,1.05,5,12,-20,'ACTIVE',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)"""
    )
    conn.execute(
        "INSERT INTO onchain_snapshots VALUES(1,1,CURRENT_TIMESTAMP,'solana','addr-cate','local',92,'LOW',19,100,80,2,125000,0,1,840000,-1.4,'dep',78,10,'[]')"
    )
    conn.execute("INSERT INTO signal_observations VALUES(1,1,CURRENT_TIMESTAMP,60,1.21,21,840000,2300000,14000000,98)")
    conn.execute("INSERT INTO scanner_cycles VALUES(1,'premium',100,8,7,5,1,100,CURRENT_TIMESTAMP)")
    conn.execute("INSERT INTO scanner_cycles VALUES(2,'plus',80,6,5,4,0,91,CURRENT_TIMESTAMP)")
    for metric, value in (("analyzed", 170), ("rejected", 156), ("suspensions", 0)):
        conn.execute(
            "INSERT INTO ops_metrics(component,metric_name,value,unit,status,labels_json,occurred_at) VALUES('scanner',?,?, 'count','OK','{}',CURRENT_TIMESTAMP)",
            (metric, value),
        )
    conn.execute(
        """INSERT INTO ops_incidents VALUES(1,'provider:test:latency','provider','HIGH','OPEN',
             'Latência elevada em provider de teste','{\"latency_ms\":3000}',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,2,NULL)"""
    )
    conn.execute("INSERT INTO users VALUES(1,'premium')")
    conn.commit()
    conn.close()


def _ai(tmp_path: Path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch)
    db = tmp_path / "signals.db"
    _db(db)
    tools = DanielTools(cfg, csm_db=db)
    mem = DanielMemory(cfg.db_file)
    return DanielAI(cfg, tools=tools, memory=mem), tools, mem, db


def test_v020_version_and_new_tools(tmp_path, monkeypatch):
    ai, tools, mem, _ = _ai(tmp_path, monkeypatch)
    assert tuple(int(part) for part in __version__.split(".")) >= (0, 2, 0)
    for name in ("signal_detail", "compare_signals", "scanner_summary", "network_summary", "operations_incidents"):
        assert name in tools.names()
    assert ai.status()["openai_enabled"] is False
    mem.close()


def test_natural_signal_analysis_uses_persisted_facts(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    text = ai.ask("analise CATE", user_id=1, source="telegram")
    assert "CATE" in text
    assert "100/100" in text
    assert "$852.4K" in text
    assert "60.0%" in text
    assert "On-chain" in text
    assert "liquidez acima do mínimo" in text
    assert "não é recomendação financeira" in text
    mem.close()


def test_score_explanation_uses_recorded_reasons_not_fake_points(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    text = ai.ask("por que CATE recebeu esse score?", user_id=1)
    assert "Score final registrado" in text
    assert "liquidez acima do mínimo" in text
    assert "não invento pesos" in text
    mem.close()


def test_compare_signals_is_factual(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    text = ai.ask("compare CATE e GORE", user_id=1)
    assert "CATE x GORE" in text
    assert "maior score: CATE" in text
    assert "maior liquidez: CATE" in text
    assert "não escolhe automaticamente" in text
    mem.close()


def test_diagnostics_report_scanner_and_open_incident(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    text = ai.ask("diagnóstico do scanner nas últimas 2 horas", user_id=1)
    assert "diagnóstico administrativo" in text
    assert "descobertos" in text
    assert "180" in text
    assert "Incidentes abertos" in text
    assert "Latência elevada" in text
    assert "somente leitura" in text
    mem.close()


def test_network_diagnostic_refuses_to_invent_rejection_reason(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    text = ai.ask("por que estamos encontrando poucos sinais na Solana nas últimas 24 horas?", user_id=1)
    assert "SOLANA" in text
    assert "Ainda não há decisões V16.2" in text
    assert "Nenhum filtro foi alterado" in text
    mem.close()


def test_history_is_available_in_natural_language(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    ai.ask("status do sistema", user_id=7)
    text = ai.ask("histórico da conversa", user_id=7)
    assert "Histórico recente" in text
    assert "status do sistema" in text
    mem.close()


def test_v020_tools_keep_csm_database_read_only(tmp_path, monkeypatch):
    ai, tools, mem, db = _ai(tmp_path, monkeypatch)
    before = sqlite3.connect(db).execute("SELECT COUNT(*) FROM signal_ledger").fetchone()[0]
    assert tools.signal_detail("CATE").ok
    assert tools.compare_signals("CATE", "GORE").ok
    assert tools.scanner_summary(2).ok
    assert tools.operations_incidents().ok
    ai.ask("analise CATE", user_id=1)
    after = sqlite3.connect(db).execute("SELECT COUNT(*) FROM signal_ledger").fetchone()[0]
    assert before == after == 2
    mem.close()


def test_openai_remains_off_for_admin_intelligence(tmp_path, monkeypatch):
    ai, _, mem, _ = _ai(tmp_path, monkeypatch)
    for question in ("analise CATE", "compare CATE e GORE", "diagnóstico do scanner"):
        ai.ask(question, user_id=1)
        assert ai.status()["openai_enabled"] is False
        assert ai.status()["mode"] == "local"
    mem.close()
