from __future__ import annotations

import sqlite3
import zipfile
from pathlib import Path

from daniel_ai import __version__
from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools


def _cfg(tmp_path: Path, monkeypatch) -> DanielSettings:
    monkeypatch.setenv("OPENAI_ENABLED", "false")
    return DanielSettings(
        enabled=True,
        admin_only=True,
        memory_enabled=True,
        history_limit=50,
        max_question_chars=4000,
        openai_enabled=False,
        openai_api_key="",
        openai_model="",
        web_enabled=False,
        documents_enabled=True,
        documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel",
        db_file=tmp_path / "daniel" / "daniel_ai.db",
        documents_max_file_mb=8,
        knowledge_max_results=5,
    )


def _db(path: Path) -> None:
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE ops_incidents(
          id INTEGER PRIMARY KEY,incident_key TEXT,component TEXT,severity TEXT,status TEXT,summary TEXT,details_json TEXT,
          first_seen TEXT,last_seen TEXT,occurrences INTEGER,resolved_at TEXT
        );
        CREATE TABLE users(user_id INTEGER PRIMARY KEY,plan TEXT);
        """
    )
    conn.execute(
        "INSERT INTO ops_incidents VALUES(1,'old','provider','MEDIUM','RESOLVED','Falha antiga','{}','2026-08-19 09:00:00','2026-08-19 10:00:00',1,'2026-08-19 10:05:00')"
    )
    conn.execute(
        "INSERT INTO ops_incidents VALUES(2,'new','provider','HIGH','OPEN','Falha mais recente','{}','2026-08-19 10:30:00','2026-08-19 11:00:00',3,NULL)"
    )
    conn.execute("INSERT INTO users VALUES(1,'premium')")
    conn.commit()
    conn.close()


def _ai(tmp_path: Path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch)
    cfg.documents_dir.mkdir(parents=True, exist_ok=True)
    db = tmp_path / "signals.db"
    _db(db)
    tools = DanielTools(cfg, csm_db=db)
    mem = DanielMemory(cfg.db_file)
    return DanielAI(cfg, tools=tools, memory=mem), tools, mem


def test_v030_version_openai_off_and_tools(tmp_path, monkeypatch):
    ai, tools, mem = _ai(tmp_path, monkeypatch)
    assert tuple(int(part) for part in __version__.split(".")) >= (0, 3, 0)
    assert ai.status()["openai_enabled"] is False
    assert ai.status()["mode"] == "local"
    assert "recent_operational_errors" in tools.names()
    mem.close()


def test_history_strips_saved_telegram_html_and_compacts(tmp_path, monkeypatch):
    ai, _, mem = _ai(tmp_path, monkeypatch)
    mem.add_message(7, "user", "analise CATE")
    mem.add_message(7, "assistant", "🧠 <b>Daniel AI</b> " + ("resposta muito longa " * 40))
    text = ai.ask("histórico da conversa", user_id=7)
    assert "Histórico recente" in text
    assert "&lt;b&gt;" not in text
    assert "<b>Daniel AI</b>" not in text
    assert "Daniel AI" in text
    assert "…" in text
    assert "Histórico compacto" in text
    mem.close()


def test_ultimos_erros_has_dedicated_chronological_answer(tmp_path, monkeypatch):
    ai, _, mem = _ai(tmp_path, monkeypatch)
    text = ai.ask("últimos erros", user_id=1)
    assert "ordem cronológica" in text
    assert "Falha mais recente" in text
    assert "Falha antiga" in text
    assert text.index("Falha mais recente") < text.index("Falha antiga")
    assert "diagnóstico administrativo" not in text
    mem.close()


def test_local_knowledge_indexes_and_searches_text(tmp_path, monkeypatch):
    ai, _, mem = _ai(tmp_path, monkeypatch)
    (ai.cfg.documents_dir / "manual.md").write_text(
        "Política do scanner\nA liquidez mínima operacional deste exemplo é 100 mil dólares.\nO score deve ser validado.",
        encoding="utf-8",
    )
    text = ai.ask("procure nos documentos liquidez mínima", user_id=1)
    assert "Base de conhecimento local" in text
    assert "manual.md" in text
    assert "liquidez mínima" in text
    counts = mem.counts()
    assert counts["knowledge_documents"] == 1
    assert counts["knowledge_chunks"] >= 1
    assert ai.status()["openai_enabled"] is False
    mem.close()


def test_document_listing_syncs_index_automatically(tmp_path, monkeypatch):
    ai, _, mem = _ai(tmp_path, monkeypatch)
    (ai.cfg.documents_dir / "notas.txt").write_text("Provider GeckoTerminal tem política de cota.", encoding="utf-8")
    text = ai.ask("documentos", user_id=1)
    assert "notas.txt" in text
    assert "✅" in text
    assert mem.counts()["knowledge_documents"] == 1
    mem.close()


def test_docx_read_without_external_docx_library(tmp_path, monkeypatch):
    ai, tools, mem = _ai(tmp_path, monkeypatch)
    docx = ai.cfg.documents_dir / "manual.docx"
    xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>
    <w:p><w:r><w:t>Manual interno do Daniel AI</w:t></w:r></w:p>
    <w:p><w:r><w:t>Conhecimento local persistente.</w:t></w:r></w:p>
    </w:body></w:document>'''
    with zipfile.ZipFile(docx, "w") as zf:
        zf.writestr("word/document.xml", xml)
    result = tools.read_document("manual.docx")
    assert result.ok
    assert "Manual interno" in result.data["text"]
    text = ai.ask('leia "manual.docx"', user_id=1)
    assert "Manual interno" in text
    mem.close()


def test_document_path_traversal_stays_blocked(tmp_path, monkeypatch):
    _, tools, mem = _ai(tmp_path, monkeypatch)
    outside = tmp_path / "segredo.txt"
    outside.write_text("não pode ler", encoding="utf-8")
    result = tools.read_document("../segredo.txt")
    assert not result.ok
    assert "fora" in result.summary or "inexistente" in result.summary
    mem.close()


def test_removed_document_is_removed_from_knowledge_index(tmp_path, monkeypatch):
    ai, _, mem = _ai(tmp_path, monkeypatch)
    path = ai.cfg.documents_dir / "temporario.txt"
    path.write_text("conteúdo temporário xyzunico", encoding="utf-8")
    assert "temporario.txt" in ai.ask("procure nos documentos xyzunico", user_id=1)
    path.unlink()
    text = ai.ask("procure nos documentos xyzunico", user_id=1)
    assert "Não encontrei" in text
    assert mem.counts()["knowledge_documents"] == 0
    mem.close()
