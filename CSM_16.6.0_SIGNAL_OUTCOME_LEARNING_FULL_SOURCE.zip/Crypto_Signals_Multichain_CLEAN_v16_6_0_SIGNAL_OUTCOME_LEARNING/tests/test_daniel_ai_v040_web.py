from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from daniel_ai import __version__
from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools
from daniel_ai.web import WebPage, WebSearchResult, WebSecurityError, validate_public_url


def _cfg(tmp_path: Path, *, web: bool) -> DanielSettings:
    return DanielSettings(
        enabled=True,
        admin_only=True,
        memory_enabled=True,
        history_limit=50,
        max_question_chars=4000,
        openai_enabled=False,
        openai_api_key="",
        openai_model="",
        web_enabled=web,
        documents_enabled=True,
        documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel",
        db_file=tmp_path / "daniel" / "daniel_ai.db",
    )


def _db(path: Path) -> None:
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE users(user_id INTEGER PRIMARY KEY,plan TEXT)")
    conn.execute("INSERT INTO users VALUES(1,'premium')")
    conn.commit()
    conn.close()


class FakeWeb:
    def search(self, query: str):
        return [
            WebSearchResult("Fonte oficial Alpha", "https://example.org/alpha", "Resumo público sobre " + query),
            WebSearchResult("Fonte Beta", "https://news.example.net/beta", "Segundo resultado"),
        ]

    def fetch(self, url: str):
        if "127.0.0.1" in url:
            raise WebSecurityError("endereço IP privado/reservado bloqueado")
        return WebPage(
            url="https://example.org/manual",
            title="Manual público",
            text="Conteúdo público de teste. O Daniel apenas lê a página e não executa scripts.",
            content_type="text/html",
            bytes_read=1234,
        )


def _ai(tmp_path: Path, *, web: bool):
    cfg = _cfg(tmp_path, web=web)
    cfg.documents_dir.mkdir(parents=True, exist_ok=True)
    db = tmp_path / "signals.db"
    _db(db)
    tools = DanielTools(cfg, csm_db=db)
    mem = DanielMemory(cfg.db_file)
    return DanielAI(cfg, tools=tools, memory=mem, web_client=FakeWeb()), mem


def test_v040_version_openai_off_web_opt_in(tmp_path):
    ai, mem = _ai(tmp_path, web=False)
    assert __version__ == "1.3.1"
    status = ai.status()
    assert status["openai_enabled"] is False
    assert status["web_enabled"] is False
    text = ai.ask("pesquise na internet bitcoin", user_id=1)
    assert "Pesquisa web desativada" in text
    assert "OpenAI" in text
    mem.close()


def test_web_search_returns_explicit_sources_without_openai(tmp_path):
    ai, mem = _ai(tmp_path, web=True)
    text = ai.ask("pesquise na internet bitcoin ETF", user_id=1)
    assert "Pesquisa web" in text
    assert "Fonte oficial Alpha" in text
    assert "example.org/alpha" in text
    assert "Resultados externos" in text
    assert ai.status()["openai_enabled"] is False
    mem.close()


def test_web_open_is_read_only_and_formats_page(tmp_path):
    ai, mem = _ai(tmp_path, web=True)
    text = ai.ask("abra https://example.org/manual", user_id=1)
    assert "Manual público" in text
    assert "Conteúdo público" in text
    assert "somente leitura" in text
    mem.close()


def test_web_security_blocks_private_and_non_http_urls():
    with pytest.raises(WebSecurityError):
        validate_public_url("http://127.0.0.1:8787/private")
    with pytest.raises(WebSecurityError):
        validate_public_url("http://10.0.0.2/admin")
    with pytest.raises(WebSecurityError):
        validate_public_url("file:///data/data/private")


def test_web_status_explains_no_openai_cost(tmp_path):
    ai, mem = _ai(tmp_path, web=True)
    text = ai.ask("web status", user_id=1)
    assert "Internet: <b>ON</b>" in text
    assert "OpenAI: <b>OFF</b>" in text
    assert "não exige chave OpenAI" in text
    mem.close()
