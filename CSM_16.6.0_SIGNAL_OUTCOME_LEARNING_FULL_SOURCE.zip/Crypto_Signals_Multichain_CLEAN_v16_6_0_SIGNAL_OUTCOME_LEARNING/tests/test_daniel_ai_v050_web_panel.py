from __future__ import annotations

import json

from daniel_ai import __version__
from daniel_ai.web import WebClient


def test_v050_version():
    assert __version__ == "1.3.1"


def test_search_falls_back_across_public_sources(monkeypatch):
    client = WebClient(max_results=3)

    def fake_validate(url: str) -> str:
        return url

    monkeypatch.setattr("daniel_ai.web.validate_public_url", fake_validate)

    def fake_get(url: str, *, accept=None):
        if "bing.com/search" in url:
            return url, "application/rss+xml", b"<rss><channel></channel></rss>"
        if "duckduckgo.com" in url:
            return url, "text/html", b"<html><body>No results</body></html>"
        if "wikipedia.org" in url:
            payload = ["bitcoin ETF", ["ETF de Bitcoin"], ["Artigo sobre fundos negociados em bolsa."], ["https://pt.wikipedia.org/wiki/ETF_de_Bitcoin"]]
            return url, "application/json", json.dumps(payload).encode()
        return url, "application/rss+xml", b"<rss><channel></channel></rss>"

    monkeypatch.setattr(client, "_get", fake_get)
    rows = client.search("bitcoin ETF")
    assert rows
    assert rows[0].source == "Wikipedia"
    assert "ETF" in rows[0].title
    providers = [d["provider"] for d in client.last_search_diagnostics]
    assert providers[:3] == ["Bing RSS", "DuckDuckGo", "Wikipedia"]


def test_news_query_prioritizes_google_news(monkeypatch):
    client = WebClient(max_results=2)
    monkeypatch.setattr("daniel_ai.web.validate_public_url", lambda url: url)
    rss = b"""<?xml version='1.0'?><rss><channel><item><title>Solana avanca</title><link>https://news.example.org/solana</link><description>Resumo da noticia</description></item></channel></rss>"""

    def fake_get(url: str, *, accept=None):
        if "news.google.com" in url:
            return url, "application/rss+xml", rss
        return url, "application/rss+xml", b"<rss><channel></channel></rss>"

    monkeypatch.setattr(client, "_get", fake_get)
    rows = client.search("noticias sobre Solana")
    assert rows[0].source == "Google News"
    assert client.last_search_diagnostics[0]["provider"] == "Google News"


def test_admin_daniel_panel_is_interactive_and_escapes_answer(monkeypatch):
    from csm import admin_web

    monkeypatch.setattr(admin_web, "_daniel_panel_snapshot", lambda user_id=0: {
        "status": {
            "version": "1.0.0", "enabled": True, "openai_enabled": False,
            "web_enabled": True, "counts": {"conversations": 4, "memories": 1, "knowledge_documents": 2},
        },
        "history": [{"role": "user", "content": "status"}, {"role": "assistant", "content": "<b>OK</b>"}],
        "memories": [{"key": "teste", "value": "CATE"}],
        "documents": [{"name": "manual.pdf", "format": "pdf", "chunks": 3}],
        "user_id": user_id,
    })
    body = admin_web._daniel_panel_page(token="abc", user_id=7, question="teste", answer="<script>alert(1)</script><b>Seguro</b>").decode()
    assert "Daniel AI V1.0.0" in body
    assert "Perguntar ao Daniel" in body
    assert "token=abc" in body
    assert "manual.pdf" in body
    assert "<script>alert(1)</script>" not in body
    assert "Seguro" in body
