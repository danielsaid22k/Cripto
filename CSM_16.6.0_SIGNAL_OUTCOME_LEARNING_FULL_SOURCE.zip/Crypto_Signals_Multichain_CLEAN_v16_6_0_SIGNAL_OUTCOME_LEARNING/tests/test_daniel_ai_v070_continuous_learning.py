from __future__ import annotations

import sqlite3
from pathlib import Path

from daniel_ai import __version__
from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.learning import AutoLearner
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools
from daniel_ai.web import WebSearchResult


def cfg(tmp_path: Path, *, web: bool = True, learning: bool = True) -> DanielSettings:
    return DanielSettings(
        enabled=True, admin_only=True, memory_enabled=True, history_limit=50,
        max_question_chars=4000, openai_enabled=False, openai_api_key="", openai_model="",
        web_enabled=web, documents_enabled=True, documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel", db_file=tmp_path / "daniel" / "daniel_ai.db",
        learning_enabled=learning, learning_interval_minutes=60, learning_max_sources_per_topic=3,
        learning_ttl_hours=168, learning_max_items=50, learning_web_timeout_seconds=2,
        learned_dir=tmp_path / "daniel" / "learned",
    )


def csm_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE users(user_id INTEGER PRIMARY KEY,plan TEXT)")
    conn.execute("INSERT INTO users VALUES(1,'premium')")
    conn.commit(); conn.close()


class FakeWeb:
    last_search_diagnostics = [{"provider": "fake", "status": "ok", "results": 3}]
    def search(self, query: str):
        return [
            WebSearchResult(f"{query} fonte A", "https://a.example.org/a", "Evidência A", "Fonte A"),
            WebSearchResult(f"{query} fonte B", "https://b.example.net/b", "Evidência B", "Fonte B"),
            WebSearchResult(f"{query} fonte C", "https://c.example.com/c", "Evidência C", "Fonte C"),
        ]


def test_v070_version_and_learning_defaults(tmp_path):
    c = cfg(tmp_path)
    assert __version__ == "1.3.1"
    assert c.learning_enabled is True
    assert c.openai_enabled is False


def test_learning_persists_sources_confidence_and_note(tmp_path):
    c = cfg(tmp_path)
    mem = DanielMemory(c.db_file)
    learner = AutoLearner(c, memory=mem, web_client=FakeWeb())
    result = learner.research_topic("Bitcoin ETF", source="test")
    assert result["ok"] is True
    assert result["source_count"] == 3
    assert result["confidence"] >= 80
    rows = mem.search_learned("Bitcoin ETF")
    assert rows and rows[0]["topic"] == "Bitcoin ETF"
    assert (c.learned_dir / "Bitcoin_ETF.md").exists()
    mem.close()


def test_question_is_enqueued_for_background_learning(tmp_path):
    c = cfg(tmp_path)
    db = tmp_path / "signals.db"; csm_db(db)
    mem = DanielMemory(c.db_file)
    ai = DanielAI(c, tools=DanielTools(c, csm_db=db), memory=mem, web_client=FakeWeb())
    ai.ask("o que pode mudar no mercado de Solana este ano?", user_id=1)
    stats = mem.learning_stats()
    assert stats["pending_topics"] >= 1
    mem.close()


def test_manual_learn_and_recall_without_openai(tmp_path):
    c = cfg(tmp_path)
    db = tmp_path / "signals.db"; csm_db(db)
    mem = DanielMemory(c.db_file)
    ai = DanielAI(c, tools=DanielTools(c, csm_db=db), memory=mem, web_client=FakeWeb())
    learned = ai.ask("aprenda sobre ETFs de Bitcoin", user_id=1)
    assert "Aprendizado concluído" in learned
    answer = ai.ask("o que você sabe sobre ETFs de Bitcoin?", user_id=1)
    assert "Conhecimento aprendido" in answer
    assert "ETF" in answer
    assert ai.status()["openai_enabled"] is False
    mem.close()


def test_learning_off_prevents_research(tmp_path):
    c = cfg(tmp_path, learning=False)
    mem = DanielMemory(c.db_file)
    result = AutoLearner(c, memory=mem, web_client=FakeWeb()).research_topic("Solana")
    assert result["reason"] == "learning_disabled"
    mem.close()


def test_personal_generic_question_is_not_sent_to_learning_queue(tmp_path):
    c = cfg(tmp_path)
    db = tmp_path / "signals.db"; csm_db(db)
    mem = DanielMemory(c.db_file)
    ai = DanielAI(c, tools=DanielTools(c, csm_db=db), memory=mem, web_client=FakeWeb())
    ai.ask("qual foi a anotação pessoal que eu fiz ontem?", user_id=1)
    assert mem.learning_stats()["pending_topics"] == 0
    mem.close()
