from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.voice import DanielVoice, VoiceError


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        voice_enabled=True,
        voice_model="tiny",
        voice_model_path="",
        voice_whisper_bin="",
        voice_ffmpeg_bin="ffmpeg",
    )
    return ensure_directories(replace(cfg, **changes))


def test_voice_defaults_enabled_and_bounded(tmp_path):
    cfg = _cfg(tmp_path)
    assert cfg.voice_enabled is True
    assert cfg.voice_max_seconds >= 10
    assert cfg.voice_max_bytes >= 1024 * 1024
    assert cfg.voice_dir.name == "voice"


def test_voice_rejects_duration_before_backend(tmp_path):
    cfg = _cfg(tmp_path, voice_max_seconds=30)
    voice = DanielVoice(cfg)
    with pytest.raises(VoiceError, match="30s"):
        voice.validate_message({"file_id": "abc", "duration": 31, "file_size": 100})


def test_voice_local_transcription_pipeline(monkeypatch, tmp_path):
    voice_dir = tmp_path / "state" / "voice"
    whisper = voice_dir / "whisper.cpp" / "build" / "bin" / "whisper-cli"
    model = voice_dir / "whisper.cpp" / "models" / "ggml-tiny.bin"
    whisper.parent.mkdir(parents=True, exist_ok=True)
    model.parent.mkdir(parents=True, exist_ok=True)
    whisper.write_text("#!/bin/sh\n", encoding="utf-8")
    whisper.chmod(0o755)
    model.write_bytes(b"x" * (1024 * 1024 + 1))
    fake_ffmpeg = tmp_path / "ffmpeg"
    fake_ffmpeg.write_text("#!/bin/sh\n", encoding="utf-8")
    fake_ffmpeg.chmod(0o755)
    cfg = _cfg(tmp_path, voice_ffmpeg_bin=str(fake_ffmpeg))
    source = tmp_path / "voice.ogg"
    source.write_bytes(b"ogg")

    class R:
        returncode = 0
        stdout = ""
        stderr = ""

    def fake_run(cmd, **kwargs):
        if str(cmd[0]) == str(fake_ffmpeg):
            Path(cmd[-1]).write_bytes(b"wav")
        else:
            prefix = Path(cmd[cmd.index("-of") + 1])
            Path(str(prefix) + ".txt").write_text("Daniel, status operacional", encoding="utf-8")
        return R()

    monkeypatch.setattr("daniel_ai.voice.subprocess.run", fake_run)
    assert DanielVoice(cfg).transcribe(source) == "status operacional"


class _Storage:
    def upsert_user(self, user_id, username, first_name):
        return {"user_id": user_id, "plan": "premium", "status": "active"}


class _Telegram:
    def __init__(self, tmp_path):
        self.sent = []
        self.tmp_path = tmp_path

    def send(self, chat_id, text, keyboard=None):
        self.sent.append((chat_id, text, keyboard))
        return {"ok": True}

    def download_file(self, file_id, destination, max_bytes=0):
        Path(destination).write_bytes(b"voice")
        return {"path": str(destination), "bytes": 5}


class _App:
    def __init__(self, tmp_path, admin=True):
        self.telegram = _Telegram(tmp_path)
        self.storage = _Storage()
        self.pending_payment = {}
        self._admin = admin
        self.warnings = []

    def is_admin(self, user_id):
        return self._admin

    def log_warning(self, text):
        self.warnings.append(text)


def test_router_voice_transcribes_then_asks_daniel(monkeypatch, tmp_path):
    monkeypatch.setenv("DANIEL_AI_ADMIN_ONLY", "true")
    monkeypatch.setenv("DANIEL_AI_VOICE_ENABLED", "true")
    app = _App(tmp_path, admin=True)
    from daniel_ai.voice import DanielVoice
    from daniel_ai.engine import DanielAI
    monkeypatch.setattr(DanielVoice, "validate_message", lambda self, voice: None)
    monkeypatch.setattr(DanielVoice, "transcribe", lambda self, path: "status operacional")
    monkeypatch.setattr(DanielAI, "ask", lambda self, q, user_id=0, source="local": "VOICE_OK")
    from phantom_v10.router import InteractionRouter
    result = InteractionRouter(app).message({
        "chat": {"id": 7},
        "from": {"id": 7, "username": "admin", "first_name": "Admin"},
        "message_id": 10,
        "voice": {"file_id": "f1", "file_unique_id": "u1", "duration": 3, "file_size": 100},
    })
    assert result == {"ok": True}
    assert "Entendi" in app.telegram.sent[-1][1]
    assert "status operacional" in app.telegram.sent[-1][1]
    assert "VOICE_OK" in app.telegram.sent[-1][1]


def test_router_voice_keeps_admin_only(monkeypatch, tmp_path):
    monkeypatch.setenv("DANIEL_AI_ADMIN_ONLY", "true")
    app = _App(tmp_path, admin=False)
    from phantom_v10.router import InteractionRouter
    InteractionRouter(app).message({
        "chat": {"id": 8},
        "from": {"id": 8},
        "voice": {"file_id": "f2", "duration": 2, "file_size": 100},
    })
    assert "somente para o administrador" in app.telegram.sent[-1][1]
