from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.tts import DanielSpeech, SpeechError


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        tts_enabled=True,
        tts_voice="pt-br",
        tts_speed=155,
        tts_max_chars=1400,
        tts_espeak_bin="espeak-ng",
        tts_ffmpeg_bin="ffmpeg",
    )
    return ensure_directories(replace(cfg, **changes))


def test_tts_defaults_are_local_and_enabled(tmp_path):
    cfg = _cfg(tmp_path)
    assert cfg.tts_enabled is True
    assert cfg.tts_voice == "pt-br"
    assert cfg.tts_max_chars >= 200


def test_tts_plain_text_removes_html_and_links():
    plain = DanielSpeech._plain_text("<b>Olá</b> veja https://example.com <code>BTC</code>")
    assert "<b>" not in plain
    assert "https://" not in plain
    assert "Olá" in plain
    assert "BTC" in plain


def test_tts_local_pipeline_generates_ogg(monkeypatch, tmp_path):
    espeak = tmp_path / "espeak-ng"
    ffmpeg = tmp_path / "ffmpeg"
    espeak.write_text("#!/bin/sh\n", encoding="utf-8")
    ffmpeg.write_text("#!/bin/sh\n", encoding="utf-8")
    espeak.chmod(0o755)
    ffmpeg.chmod(0o755)
    cfg = _cfg(tmp_path, tts_espeak_bin=str(espeak), tts_ffmpeg_bin=str(ffmpeg))

    class R:
        returncode = 0
        stdout = ""
        stderr = ""

    def fake_run(cmd, **kwargs):
        if str(cmd[0]) == str(espeak):
            wav = Path(cmd[cmd.index("-w") + 1])
            wav.write_bytes(b"RIFF" + b"x" * 100)
        else:
            Path(cmd[-1]).write_bytes(b"OggS" + b"x" * 100)
        return R()

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", fake_run)
    path = DanielSpeech(cfg).synthesize("Resposta do Daniel")
    try:
        assert path.suffix == ".ogg"
        assert path.read_bytes().startswith(b"OggS")
    finally:
        path.unlink(missing_ok=True)


class _Storage:
    def upsert_user(self, user_id, username, first_name):
        return {"user_id": user_id, "plan": "premium", "status": "active"}


class _Telegram:
    def __init__(self):
        self.sent = []
        self.voices = []

    def send(self, chat_id, text, keyboard=None):
        self.sent.append((chat_id, text, keyboard))
        return {"kind": "text", "ok": True}

    def send_voice(self, chat_id, path, caption=""):
        self.voices.append((chat_id, Path(path).read_bytes(), caption))
        return {"kind": "voice", "ok": True}

    def download_file(self, file_id, destination, max_bytes=0):
        Path(destination).write_bytes(b"voice")
        return {"path": str(destination), "bytes": 5}


class _App:
    def __init__(self):
        self.telegram = _Telegram()
        self.storage = _Storage()
        self.pending_payment = {}
        self.warnings = []

    def is_admin(self, user_id):
        return True

    def log_warning(self, text):
        self.warnings.append(text)


def _voice_update():
    return {
        "chat": {"id": 77},
        "from": {"id": 77, "username": "admin", "first_name": "Admin"},
        "message_id": 1,
        "voice": {"file_id": "f1", "file_unique_id": "u1", "duration": 2, "file_size": 100},
    }


def test_router_sends_text_then_audio(monkeypatch, tmp_path):
    app = _App()
    from daniel_ai.voice import DanielVoice
    from daniel_ai.engine import DanielAI
    from daniel_ai.tts import DanielSpeech

    monkeypatch.setattr(DanielVoice, "validate_message", lambda self, voice: None)
    monkeypatch.setattr(DanielVoice, "transcribe", lambda self, path: "status operacional")
    monkeypatch.setattr(DanielAI, "ask", lambda self, q, user_id=0, source="local": "<b>Tudo certo</b>")

    class Status:
        ready = True

    monkeypatch.setattr(DanielSpeech, "status", lambda self: Status())

    def fake_synth(self, text):
        path = tmp_path / "answer.ogg"
        path.write_bytes(b"OggSvoice")
        return path

    monkeypatch.setattr(DanielSpeech, "synthesize", fake_synth)
    from phantom_v10.router import InteractionRouter

    result = InteractionRouter(app).message(_voice_update())
    assert result == {"kind": "text", "ok": True}
    assert "Tudo certo" in app.telegram.sent[-1][1]
    assert app.telegram.voices and app.telegram.voices[-1][1].startswith(b"OggS")


def test_tts_failure_never_cancels_text(monkeypatch):
    app = _App()
    from daniel_ai.voice import DanielVoice
    from daniel_ai.engine import DanielAI
    from daniel_ai.tts import DanielSpeech

    monkeypatch.setattr(DanielVoice, "validate_message", lambda self, voice: None)
    monkeypatch.setattr(DanielVoice, "transcribe", lambda self, path: "status operacional")
    monkeypatch.setattr(DanielAI, "ask", lambda self, q, user_id=0, source="local": "Resposta preservada")

    class Status:
        ready = True

    monkeypatch.setattr(DanielSpeech, "status", lambda self: Status())
    monkeypatch.setattr(DanielSpeech, "synthesize", lambda self, text: (_ for _ in ()).throw(SpeechError("falhou")))
    from phantom_v10.router import InteractionRouter

    result = InteractionRouter(app).message(_voice_update())
    assert result == {"kind": "text", "ok": True}
    assert "Resposta preservada" in app.telegram.sent[-1][1]
    assert not app.telegram.voices
    assert any("Daniel Speech isolado" in w for w in app.warnings)


def test_telegram_send_voice_uses_multipart(tmp_path):
    class Transport:
        def __init__(self):
            self.call = None

        def post_multipart(self, url, **kwargs):
            self.call = (url, kwargs)
            return {"ok": True, "result": {"message_id": 42}}

    from phantom_v10.telegram import TelegramClient
    transport = Transport()
    client = TelegramClient(token="123:test", transport=transport)
    voice = tmp_path / "answer.ogg"
    voice.write_bytes(b"OggS" + b"x" * 200)
    result = client.send_voice(77, voice)
    assert result["message_id"] == 42
    assert transport.call[0].endswith("/sendVoice")
    assert transport.call[1]["file_field"] == "voice"
    assert transport.call[1]["fields"]["chat_id"] == "77"
    assert transport.call[1]["file_bytes"].startswith(b"OggS")
