from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.tts import DanielSpeech


def _exe(path: Path) -> Path:
    path.write_text("#!/bin/sh\n", encoding="utf-8")
    path.chmod(0o755)
    return path


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        tts_enabled=True,
        tts_engine="auto",
        tts_speechify_enabled=False,
        tts_speechify_api_key="",
        tts_speechify_voice_id="",
        tts_edge_bin="__missing_edge__",
        tts_supertonic_bin="__missing_supertonic__",
        tts_kokoro_python="__missing_python__",
        tts_kokoro_model_path=str(tmp_path / "no-model.onnx"),
        tts_kokoro_voices_path=str(tmp_path / "no-voices.bin"),
        tts_espeak_bin="__missing_espeak__",
        tts_ffmpeg_bin="__missing_ffmpeg__",
    )
    return ensure_directories(replace(cfg, **changes))


def test_supertonic_is_primary_when_available(monkeypatch, tmp_path):
    supertonic = _exe(tmp_path / "supertonic")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(tmp_path, tts_supertonic_bin=str(supertonic), tts_ffmpeg_bin=str(ffmpeg))
    status = DanielSpeech(cfg).status()
    assert status.ready is True
    assert status.neural_ready is True
    assert status.selected_engine == "supertonic"
    assert status.backend.startswith("Supertonic 3")


def test_supertonic_pipeline_generates_telegram_ogg(monkeypatch, tmp_path):
    supertonic = _exe(tmp_path / "supertonic")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(tmp_path, tts_supertonic_bin=str(supertonic), tts_ffmpeg_bin=str(ffmpeg))
    calls = []

    class R:
        returncode = 0
        stdout = ""
        stderr = ""

    def fake_run(cmd, **kwargs):
        calls.append(list(cmd))
        if str(cmd[0]) == str(supertonic):
            out = Path(cmd[cmd.index("-o") + 1])
            out.write_bytes(b"RIFF" + b"x" * 120)
        else:
            Path(cmd[-1]).write_bytes(b"OggS" + b"x" * 120)
        return R()

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", fake_run)
    out = DanielSpeech(cfg).synthesize("Olá, teste neural")
    try:
        assert out.read_bytes().startswith(b"OggS")
        assert calls[0][0] == str(supertonic)
        assert "--voice" in calls[0] and "M1" in calls[0]
        assert "--lang" in calls[0] and "pt" in calls[0]
    finally:
        out.unlink(missing_ok=True)


def test_supertonic_failure_falls_back_to_espeak(monkeypatch, tmp_path):
    supertonic = _exe(tmp_path / "supertonic")
    espeak = _exe(tmp_path / "espeak")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(
        tmp_path,
        tts_supertonic_bin=str(supertonic),
        tts_espeak_bin=str(espeak),
        tts_ffmpeg_bin=str(ffmpeg),
    )
    sequence = []

    class R:
        stdout = ""
        stderr = ""
        returncode = 0

    def fake_run(cmd, **kwargs):
        sequence.append(str(cmd[0]))
        r = R()
        if str(cmd[0]) == str(supertonic):
            r.returncode = 1
            r.stderr = "neural failure"
        elif str(cmd[0]) == str(espeak):
            Path(cmd[cmd.index("-w") + 1]).write_bytes(b"RIFF" + b"x" * 100)
        else:
            Path(cmd[-1]).write_bytes(b"OggS" + b"x" * 100)
        return r

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", fake_run)
    out = DanielSpeech(cfg).synthesize("fallback seguro")
    try:
        assert out.read_bytes().startswith(b"OggS")
        assert sequence[0] == str(supertonic)
        assert str(espeak) in sequence
    finally:
        out.unlink(missing_ok=True)


def test_kokoro_is_neural_fallback(monkeypatch, tmp_path):
    python_bin = _exe(tmp_path / "python")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    model = tmp_path / "kokoro-v1.0.int8.onnx"
    voices = tmp_path / "voices-v1.0.bin"
    model.write_bytes(b"x" * (1024 * 1024 + 10))
    voices.write_bytes(b"x" * 2048)
    cfg = _cfg(
        tmp_path,
        tts_kokoro_python=str(python_bin),
        tts_kokoro_model_path=str(model),
        tts_kokoro_voices_path=str(voices),
        tts_ffmpeg_bin=str(ffmpeg),
    )
    status = DanielSpeech(cfg).status()
    assert status.selected_engine == "kokoro"
    assert status.neural_ready is True

    class R:
        returncode = 0
        stdout = ""
        stderr = ""

    def fake_run(cmd, **kwargs):
        if str(cmd[0]) == str(python_bin):
            Path(cmd[cmd.index("--output") + 1]).write_bytes(b"RIFF" + b"x" * 100)
        else:
            Path(cmd[-1]).write_bytes(b"OggS" + b"x" * 100)
        return R()

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", fake_run)
    out = DanielSpeech(cfg).synthesize("teste kokoro")
    try:
        assert out.read_bytes().startswith(b"OggS")
    finally:
        out.unlink(missing_ok=True)


def test_termux_installers_use_real_espeak_package():
    root = Path(__file__).resolve().parents[1]
    neural = (root / "install_neural_voice_termux.sh").read_text(encoding="utf-8")
    native = (root / "install_voice_termux.sh").read_text(encoding="utf-8")
    assert "pkg install -y ffmpeg espeak" in neural
    assert "pkg install -y ffmpeg git cmake clang make wget espeak" in native
    assert "pkg install -y espeak-ng" not in neural
