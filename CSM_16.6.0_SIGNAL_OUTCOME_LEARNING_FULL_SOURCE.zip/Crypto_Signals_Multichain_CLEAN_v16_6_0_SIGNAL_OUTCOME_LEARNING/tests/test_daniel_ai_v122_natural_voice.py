from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from daniel_ai import __version__
from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.tts import DanielSpeech, SpeechError


def _exe(path: Path) -> Path:
    path.write_text("#!/bin/sh\n", encoding="utf-8")
    path.chmod(0o755)
    return path


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        tts_enabled=True,
        tts_engine="auto",
        tts_speechify_enabled=False,
        tts_speechify_api_key="",
        tts_speechify_voice_id="",
        tts_edge_bin="__missing_edge__",
        tts_supertonic_bin="__missing_supertonic__",
        tts_kokoro_python="__missing_python__",
        tts_kokoro_model_path=str(tmp_path / "no-model.onnx"),
        tts_kokoro_voices_path=str(tmp_path / "no-voices.bin"),
        tts_espeak_bin="__missing_espeak__",
        tts_ffmpeg_bin="__missing_ffmpeg__",
    )
    return ensure_directories(replace(cfg, **changes))


def test_daniel_version_is_v122():
    assert __version__ == "1.3.1"


def test_edge_neural_is_primary_when_available(tmp_path):
    edge = _exe(tmp_path / "edge-tts")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(tmp_path, tts_edge_bin=str(edge), tts_ffmpeg_bin=str(ffmpeg))
    status = DanielSpeech(cfg).status()
    assert status.ready is True
    assert status.neural_ready is True
    assert status.online_neural_ready is True
    assert status.selected_engine == "edge"
    assert status.voice == "pt-BR-AntonioNeural"
    assert status.backend.startswith("Microsoft Edge Neural")


def test_edge_pipeline_writes_mp3_then_telegram_ogg(monkeypatch, tmp_path):
    edge = _exe(tmp_path / "edge-tts")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(
        tmp_path,
        tts_engine="edge",
        tts_edge_bin=str(edge),
        tts_edge_voice="pt-BR-FabioNeural",
        tts_edge_rate="-4%",
        tts_ffmpeg_bin=str(ffmpeg),
    )
    calls = []

    class R:
        returncode = 0
        stdout = ""
        stderr = ""

    def fake_run(cmd, **kwargs):
        calls.append(list(cmd))
        if str(cmd[0]) == str(edge):
            out = Path(cmd[cmd.index("--write-media") + 1])
            out.write_bytes(b"ID3" + b"x" * 300)
        else:
            Path(cmd[-1]).write_bytes(b"OggS" + b"x" * 200)
        return R()

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", fake_run)
    out = DanielSpeech(cfg).synthesize("Olá, teste natural", engine="edge")
    try:
        assert out.read_bytes().startswith(b"OggS")
        assert calls[0][0] == str(edge)
        assert "pt-BR-FabioNeural" in calls[0]
        assert "--rate=-4%" in calls[0]
        assert calls[1][0] == str(ffmpeg)
        assert str(calls[1][calls[1].index("-i") + 1]).endswith(".mp3")
    finally:
        out.unlink(missing_ok=True)


def test_edge_failure_falls_back_to_supertonic(monkeypatch, tmp_path):
    edge = _exe(tmp_path / "edge-tts")
    supertonic = _exe(tmp_path / "supertonic")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(
        tmp_path,
        tts_edge_bin=str(edge),
        tts_supertonic_bin=str(supertonic),
        tts_ffmpeg_bin=str(ffmpeg),
    )
    sequence = []

    class R:
        returncode = 0
        stdout = ""
        stderr = ""

    def fake_run(cmd, **kwargs):
        sequence.append(str(cmd[0]))
        r = R()
        if str(cmd[0]) == str(edge):
            r.returncode = 1
            r.stderr = "offline"
        elif str(cmd[0]) == str(supertonic):
            Path(cmd[cmd.index("-o") + 1]).write_bytes(b"RIFF" + b"x" * 200)
        else:
            Path(cmd[-1]).write_bytes(b"OggS" + b"x" * 200)
        return r

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", fake_run)
    out = DanielSpeech(cfg).synthesize("fallback local")
    try:
        assert out.read_bytes().startswith(b"OggS")
        assert sequence[0] == str(edge)
        assert str(supertonic) in sequence
    finally:
        out.unlink(missing_ok=True)


def test_strict_edge_test_does_not_hide_online_failure(monkeypatch, tmp_path):
    edge = _exe(tmp_path / "edge-tts")
    supertonic = _exe(tmp_path / "supertonic")
    ffmpeg = _exe(tmp_path / "ffmpeg")
    cfg = _cfg(
        tmp_path,
        tts_edge_bin=str(edge),
        tts_supertonic_bin=str(supertonic),
        tts_ffmpeg_bin=str(ffmpeg),
    )

    class R:
        returncode = 1
        stdout = ""
        stderr = "network unavailable"

    monkeypatch.setattr("daniel_ai.tts.subprocess.run", lambda *a, **k: R())
    with pytest.raises(SpeechError):
        DanielSpeech(cfg).synthesize("teste estrito", engine="edge")


def test_natural_voice_installer_keeps_local_fallbacks():
    root = Path(__file__).resolve().parents[1]
    installer = (root / "install_natural_voice_termux.sh").read_text(encoding="utf-8")
    assert "pip install --upgrade edge-tts" in installer
    assert "DANIEL_AI_TTS_ENGINE']='edge'" in installer
    assert "Supertonic" in installer and "Kokoro" in installer and "eSpeak" in installer


def test_main_exposes_voice_compare_and_selection_commands():
    root = Path(__file__).resolve().parents[1]
    main = (root / "main.py").read_text(encoding="utf-8")
    assert '"daniel-speech-compare"' in main
    assert 'sub.add_parser("daniel-speech-use"' in main
    assert "pt-BR-AntonioNeural" in main
    assert "pt-BR-FabioNeural" in main
    assert "pt-BR-HumbertoNeural" in main
