from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from daniel_ai import __version__
from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.conversational_voice import ConversationalVoice


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        conversational_voice_enabled=True,
        conversational_voice_style="executive",
        conversational_voice_detail="balanced",
        conversational_voice_max_chars=1150,
    )
    return ensure_directories(replace(cfg, **changes))


def test_daniel_version_keeps_v123_compatibility_on_v124():
    assert __version__ == "1.3.1"


def test_status_exposes_conversational_structure(tmp_path):
    status = ConversationalVoice(_cfg(tmp_path)).status()
    assert status.enabled is True
    assert status.style == "executive"
    assert status.detail == "balanced"
    assert status.structure == ("prioridade", "contexto", "significado", "próximo passo")


def test_operational_answer_becomes_spoken_briefing_not_line_reader(tmp_path):
    technical = (
        "🧠 <b>Daniel AI V1.2.3 — Operational Copilot</b>\n"
        "🌐 Providers: <b>94/100</b>\n"
        "🔎 Scanner 24h: analisados <b>128</b> • aprovados <b>14</b> • taxa <b>10.9%</b>\n"
        "🚫 Principal rejeição: <b>liquidez insuficiente</b> (31)\n"
        "📈 Lifecycle: ativos <b>8</b> • deteriorando <b>2</b> • TP3 <b>3</b> • stops <b>1</b>\n"
        "🔄 Smart Reentry: <b>2</b> reentrada(s) • positivo observado <b>50.0%</b>\n"
        "🔒 Copilot operacional somente leitura."
    )
    spoken = ConversationalVoice(_cfg(tmp_path)).render("Daniel, status operacional", technical)
    assert "128" in spoken and "14" in spoken
    assert "deteriora" in spoken
    assert "linha por linha" not in spoken.lower()
    assert "<b>" not in spoken and "•" not in spoken
    assert spoken != technical


def test_signal_analysis_explains_meaning_not_just_metrics(tmp_path):
    technical = (
        "🧠 <b>Daniel AI V1.2.3 — análise local</b>\n"
        "🔎 <b>CATE</b> • SOLANA\n"
        "Score final: <b>82/100</b> • mercado 80/100\n"
        "💧 Liquidez: <b>$180.0K</b> • Vol24h: <b>$640.0K</b>\n"
        "🏦 Market cap: <b>$2.1M</b> • 24h: <b>+18.4%</b>\n"
        "🟢 Pressão compradora 24h: <b>64.0%</b> (160 compras / 90 vendas)\n"
        "🛡️ GoPlus: score <b>91/100</b> • risco <b>LOW</b>\n"
        "🧭 Lifecycle: <b>ACTIVE</b>"
    )
    spoken = ConversationalVoice(_cfg(tmp_path)).render("analise CATE", technical)
    assert "82 de 100" in spoken
    assert "favorece compradores" in spoken
    assert "direção" in spoken or "conjunto" in spoken
    assert "<b>" not in spoken and "•" not in spoken


def test_disabled_mode_returns_clean_answer_without_reframing(tmp_path):
    cfg = _cfg(tmp_path, conversational_voice_enabled=False)
    spoken = ConversationalVoice(cfg).render("teste", "✅ <b>Status</b>: OK")
    assert spoken == "Status: OK"


def test_router_synthesizes_spoken_answer_but_keeps_text_answer():
    root = Path(__file__).resolve().parents[1]
    router = (root / "phantom_v10" / "router.py").read_text(encoding="utf-8")
    assert "spoken_answer = ConversationalVoice(cfg).render(transcript, answer)" in router
    assert "audio_path = speech.synthesize(spoken_answer)" in router
    assert "body = f\"🎙️ <b>Entendi:</b> {shown}\\n\\n{answer}\"" in router


def test_main_exposes_conversational_voice_diagnostics():
    root = Path(__file__).resolve().parents[1]
    main = (root / "main.py").read_text(encoding="utf-8")
    assert '"daniel-conversational-voice-status"' in main
    assert '"daniel-conversational-voice-test"' in main
    assert '"daniel-conversational-voice-on"' in main
    assert '"daniel-conversational-voice-off"' in main
