from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from daniel_ai import __version__
from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.conversational_voice import ConversationalVoice


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        conversational_voice_enabled=True,
        conversational_voice_style="adaptive",
        conversational_voice_detail="balanced",
        conversational_voice_max_chars=1250,
        conversational_voice_command_explainer=True,
        conversational_voice_natural_variation=True,
    )
    return ensure_directories(replace(cfg, **changes))


def test_version_is_v124():
    assert __version__ == "1.3.1"


def test_status_reports_three_adaptive_profiles(tmp_path):
    status = ConversationalVoice(_cfg(tmp_path)).status()
    assert status.style == "adaptive"
    assert status.profiles == ("executivo", "analista", "explicativo")
    assert status.command_explainer is True
    assert status.natural_variation is True
    assert status.structure == ("prioridade", "contexto", "significado", "próximo passo")


def test_profile_selector_chooses_executive_for_status(tmp_path):
    voice = ConversationalVoice(_cfg(tmp_path))
    assert voice.select_profile("Daniel, me dê um resumo do status operacional") == "executive"


def test_profile_selector_chooses_analyst_for_token(tmp_path):
    voice = ConversationalVoice(_cfg(tmp_path))
    assert voice.select_profile("Daniel, analise o token CATE e o score") == "analyst"


def test_profile_selector_chooses_explanatory_for_why_and_commands(tmp_path):
    voice = ConversationalVoice(_cfg(tmp_path))
    assert voice.select_profile("Daniel, me explica por que isso aconteceu") == "explanatory"
    assert voice.select_profile("Daniel, como faço a instalação com esses comandos") == "explanatory"


def test_command_sequence_is_explained_instead_of_read_verbatim(tmp_path):
    technical = (
        "1) csm-stop\n"
        "2) cd ~/storage/downloads\n"
        "3) unzip -o pacote.zip\n"
        "4) bash install_termux.sh\n"
        "5) python main.py migrate\n"
        "6) python main.py selftest\n"
        "7) csm-start\n"
        "8) csm-status"
    )
    spoken = ConversationalVoice(_cfg(tmp_path)).render(
        "Daniel, me explica como faço a atualização com esses comandos", technical
    )
    assert "comandos exatos ficam no texto" in spoken.lower() or "comandos completos na mensagem" in spoken.lower()
    assert "parar o serviço" in spoken
    assert "extrair o pacote" in spoken
    assert "rodar o autoteste" in spoken
    assert "python main.py" not in spoken
    assert "~/storage/downloads" not in spoken


def test_explanatory_profile_uses_cause_and_consequence_language(tmp_path):
    technical = (
        "Resultado: o provider entrou em cooldown após HTTP 429.\n"
        "Fallback ativo: DexScreener continuou cobrindo a consulta.\n"
        "Impacto: scanner permaneceu operacional.\n"
        "Próximo passo: aguardar recuperação automática."
    )
    spoken = ConversationalVoice(_cfg(tmp_path)).render(
        "Daniel, me explica por que o provider entrou em cooldown", technical
    )
    low = spoken.lower()
    assert "ponto central" in low or "forma mais simples" in low or "na prática" in low
    assert "isso importa porque" in low
    assert "como consequência" in low
    assert "erro 429 de limite de requisições" in low


def test_analyst_profile_prioritizes_interpretation_over_metric_dump(tmp_path):
    technical = (
        "🧠 <b>Daniel AI V1.2.4 — análise local</b>\n"
        "🔎 <b>CATE</b> • SOLANA\n"
        "Score final: <b>82/100</b>\n"
        "💧 Liquidez: <b>$180.0K</b> • Vol24h: <b>$640.0K</b>\n"
        "🟢 Pressão compradora 24h: <b>64.0%</b>\n"
        "🛡️ GoPlus: risco <b>LOW</b>\n"
        "🧭 Lifecycle: <b>ACTIVE</b>"
    )
    spoken = ConversationalVoice(_cfg(tmp_path)).render("Daniel, analise CATE", technical)
    assert "82 de 100" in spoken
    assert "favorece compradores" in spoken
    assert "observaria" in spoken or "ponto decisivo" in spoken or "acompanharia" in spoken
    assert "•" not in spoken and "<b>" not in spoken


def test_natural_variation_is_deterministic_for_same_question(tmp_path):
    voice = ConversationalVoice(_cfg(tmp_path))
    answer = "Status: tudo normal. Scanner ativo. Sem alertas críticos."
    first = voice.render("Daniel, resumo do sistema", answer)
    second = voice.render("Daniel, resumo do sistema", answer)
    assert first == second


def test_router_keeps_text_answer_authoritative_and_tts_uses_spoken_copy():
    root = Path(__file__).resolve().parents[1]
    router = (root / "phantom_v10" / "router.py").read_text(encoding="utf-8")
    assert "spoken_answer = ConversationalVoice(cfg).render(transcript, answer)" in router
    assert "audio_path = speech.synthesize(spoken_answer)" in router
    assert 'body = f"🎙️ <b>Entendi:</b> {shown}\\n\\n{answer}"' in router
