from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

from daniel_ai import __version__
from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.engine import DanielAI
from daniel_ai.local_llm import DanielLocalLLM


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        local_llm_enabled=True,
        local_llm_mode="smart",
        local_llm_context_size=4096,
        local_llm_max_tokens=320,
        local_llm_threads=4,
        local_llm_timeout_seconds=180,
    )
    return ensure_directories(replace(cfg, **changes))


def test_version_is_v130():
    assert __version__ == "1.3.1"


def test_smart_status_is_pending_without_model(tmp_path):
    st = DanielLocalLLM(_cfg(tmp_path, local_llm_model_path=str(tmp_path / "missing.gguf"), local_llm_bin=str(tmp_path / "missing-cli"))).status()
    assert st.enabled is True
    assert st.ready is False
    assert "modelo GGUF" in st.missing
    assert "llama.cpp/llama-cli" in st.missing


def test_smart_status_ready_with_local_files(tmp_path):
    binary = tmp_path / "llama-cli"
    binary.write_text("#!/bin/sh\n", encoding="utf-8")
    model = tmp_path / "model.gguf"
    with model.open("wb") as fh:
        fh.truncate(100_000_001)
    st = DanielLocalLLM(_cfg(tmp_path, local_llm_model_path=str(model), local_llm_bin=str(binary))).status()
    assert st.ready is True
    assert st.mode == "smart"
    assert st.context_size == 4096


def test_prompt_requests_natural_ptbr_and_no_paid_model_talk(tmp_path):
    llm = DanielLocalLLM(_cfg(tmp_path))
    prompt = llm._build_prompt("Como você está?", [])
    low = prompt.lower()
    assert "português brasileiro" in low
    assert "não diga que precisa de um modelo pago" in low
    assert "/no_think" in prompt


def test_generate_strips_thinking_and_runtime_noise(tmp_path, monkeypatch):
    binary = tmp_path / "llama-cli"
    binary.write_text("x", encoding="utf-8")
    model = tmp_path / "model.gguf"
    with model.open("wb") as fh:
        fh.truncate(100_000_001)
    cfg = _cfg(tmp_path, local_llm_model_path=str(model), local_llm_bin=str(binary))

    def fake_run(*args, **kwargs):
        return SimpleNamespace(returncode=0, stdout="<think>segredo</think>\nA liquidez reduz o risco de slippage e facilita entradas e saídas.\n", stderr="")

    monkeypatch.setattr("daniel_ai.local_llm.subprocess.run", fake_run)
    answer = DanielLocalLLM(cfg).generate("Por que liquidez importa?", history=[])
    assert "segredo" not in answer
    assert "liquidez" in answer.lower()


def test_engine_free_form_uses_smart_fallback(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    monkeypatch.setattr("daniel_ai.engine.DanielAI._local_llm_answer", lambda self, user_id, question: "Resposta generativa local natural.")
    ai = DanielAI(cfg)
    answer = ai.ask("Explique por que o céu muda de cor no pôr do sol", user_id=1)
    assert answer == "Resposta generativa local natural."


def test_engine_fallback_never_repeats_paid_model_phrase(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, local_llm_enabled=False)
    monkeypatch.setattr("daniel_ai.engine.DanielAI._local_llm_answer", lambda self, user_id, question: None)
    answer = DanielAI(cfg).ask("pergunta totalmente livre", user_id=1)
    assert "modelo generativo pago" not in answer.lower()
    assert "daniel smart" in answer.lower()
