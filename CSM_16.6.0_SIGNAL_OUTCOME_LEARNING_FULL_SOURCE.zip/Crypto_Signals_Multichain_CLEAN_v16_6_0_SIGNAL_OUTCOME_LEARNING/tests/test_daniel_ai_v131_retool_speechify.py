from __future__ import annotations

import base64
import json
import threading
from dataclasses import replace
from pathlib import Path
from urllib.request import Request, urlopen

from daniel_ai import __version__
from daniel_ai.config import DanielSettings, ensure_directories
from daniel_ai.speechify_provider import SpeechifyProvider
from daniel_ai.tts import DanielSpeech
from csm.admin_web import AdminHandler
from csm.retool_control import RetoolControlError, run_local_command
from http.server import ThreadingHTTPServer


def _cfg(tmp_path: Path, **changes):
    base = DanielSettings.from_env()
    cfg = replace(
        base,
        state_dir=tmp_path / "state",
        db_file=tmp_path / "state" / "daniel_ai.db",
        documents_dir=tmp_path / "state" / "documents",
        learned_dir=tmp_path / "state" / "learned",
        voice_dir=tmp_path / "state" / "voice",
        tts_speechify_enabled=False,
        tts_speechify_api_key="",
        tts_speechify_voice_id="",
        tts_edge_bin="__missing_edge__",
        tts_supertonic_bin="__missing_supertonic__",
        tts_kokoro_python="__missing_python__",
        tts_kokoro_model_path=str(tmp_path / "missing-model"),
        tts_kokoro_voices_path=str(tmp_path / "missing-voices"),
        tts_espeak_bin="__missing_espeak__",
        tts_ffmpeg_bin="__missing_ffmpeg__",
    )
    return ensure_directories(replace(cfg, **changes))


def test_version_is_v131():
    assert __version__ == "1.3.1"


def test_speechify_is_opt_in_and_does_not_break_existing_fallbacks(tmp_path):
    cfg = _cfg(tmp_path, tts_speechify_enabled=False, tts_speechify_api_key="secret", tts_speechify_voice_id="voice")
    st = SpeechifyProvider(cfg).status()
    assert st.configured is True
    assert st.ready is False
    assert "speechify" not in DanielSpeech(cfg).status().available_engines


def test_speechify_becomes_primary_when_configured(tmp_path):
    ffmpeg = tmp_path / "ffmpeg"
    ffmpeg.write_text("#!/bin/sh\n", encoding="utf-8")
    ffmpeg.chmod(0o755)
    cfg = _cfg(
        tmp_path,
        tts_speechify_enabled=True,
        tts_speechify_api_key="secret",
        tts_speechify_voice_id="pt_voice",
        tts_speechify_model="simba-3.0",
        tts_speechify_language="pt-BR",
        tts_ffmpeg_bin=str(ffmpeg),
    )
    st = DanielSpeech(cfg).status()
    assert st.ready is True
    assert st.selected_engine == "speechify"
    assert st.speechify_configured is True
    assert st.voice == "pt_voice"


def test_speechify_rest_payload_and_audio_decode(tmp_path, monkeypatch):
    cfg = _cfg(
        tmp_path,
        tts_speechify_enabled=True,
        tts_speechify_api_key="secret",
        tts_speechify_voice_id="pt_voice",
        tts_speechify_model="simba-3.0",
        tts_speechify_language="pt-BR",
    )
    provider = SpeechifyProvider(cfg)
    seen = {}

    def fake_request(method, path, payload=None, **kwargs):
        seen.update({"method": method, "path": path, "payload": payload})
        return {
            "audio_data": base64.b64encode(b"ID3" + b"x" * 300).decode("ascii"),
            "audio_format": "mp3",
            "billable_characters_count": 4,
        }

    monkeypatch.setattr(provider, "_json_request", fake_request)
    out = tmp_path / "speech.mp3"
    meta = provider.synthesize_mp3("Olá", out)
    assert out.read_bytes().startswith(b"ID3")
    assert seen["method"] == "POST"
    assert seen["path"] == "/v1/audio/speech"
    assert seen["payload"]["model"] == "simba-3.0"
    assert seen["payload"]["language"] == "pt-BR"
    assert seen["payload"]["voice_id"] == "pt_voice"
    assert meta["billable_characters_count"] == 4


def test_retool_admin_accepts_bearer_token():
    server = ThreadingHTTPServer(("127.0.0.1", 0), AdminHandler)
    server.admin_token = "unit-secret"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        req = Request(
            f"http://127.0.0.1:{server.server_port}/healthz",
            headers={"Authorization": "Bearer unit-secret"},
        )
        with urlopen(req, timeout=3) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        assert payload["status"] == "ok"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def test_retool_control_command_allowlist_rejects_arbitrary_commands():
    try:
        run_local_command("rm-everything")
    except RetoolControlError:
        pass
    else:
        raise AssertionError("arbitrary command was not rejected")


def test_openapi_contains_safe_admin_actions():
    root = Path(__file__).resolve().parents[1]
    spec = json.loads((root / "retool" / "CSM_RETOOL_OPENAPI.json").read_text(encoding="utf-8"))
    paths = spec["paths"]
    assert "/api/retool/overview" in paths
    assert "/api/actions/runtime/restart" in paths
    assert "/api/actions/backup" in paths
    assert "/api/daniel-ai/ask" in paths
    assert all("wallet" not in path and "payment" not in path for path in paths)
