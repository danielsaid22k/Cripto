from __future__ import annotations


def test_platform_lines_preserve_lts():
    from csm.platform_lines import platform_lines
    lines = platform_lines()
    assert [item["name"] for item in lines] == ["Core", "Experience", "Intelligence", "Enterprise"]
    core = lines[0]
    assert core["frozen"] is True
    assert core["status"] == "LTS"


def test_admin_web_loopback_rules():
    from csm.admin_web import _is_loopback
    assert _is_loopback("127.0.0.1")
    assert _is_loopback("localhost")
    assert not _is_loopback("0.0.0.0")


def test_enterprise_snapshot(monkeypatch, tmp_path):
    monkeypatch.setenv("CSM_STATE_DIR", str(tmp_path / "state"))
    from csm.enterprise_ops import enterprise_snapshot
    data = enterprise_snapshot()
    assert data["release"] == "8.2.1"
    assert data["lts_base"] == "6.3.0"
    assert "plans" in data
    assert "scanner" in data
    assert "recent_events" in data


def test_audit_log_roundtrip(monkeypatch, tmp_path):
    monkeypatch.setenv("CSM_STATE_DIR", str(tmp_path / "state"))
    # Reload is unnecessary in the normal release, but this verifies API shape.
    from csm.audit_log import record_event, recent_events
    event = record_event("unit_test", category="test", details={"ok": True})
    assert event.event == "unit_test"
    assert any(item.get("event") == "unit_test" for item in recent_events(20))
