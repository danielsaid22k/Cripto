from pathlib import Path


def test_version_660():
    from csm import __version__
    assert __version__.startswith("8.3.1")


def test_profile_preferences_persist(tmp_path):
    from csm.user_profiles import UserProfileStore
    store = UserProfileStore(tmp_path / "profiles.json")
    profile = store.get(123)
    assert profile["risk_profile"] == "moderate"
    assert store.cycle_risk_profile(123)["risk_profile"] == "aggressive"
    assert store.cycle_language(123)["language"] == "en"
    assert store.cycle_notification_frequency(123)["notification_frequency"] == "reduced"


def test_intelligence_center_text(tmp_path):
    from csm.intelligence_center import build_center_text
    user = {"plan": "plus", "expires_at": None}
    text = build_center_text(user=user, stats={"total": 2}, recent=[], renewals=[], profile={
        "risk_profile":"moderate", "detail_mode":"standard", "notification_frequency":"plan",
        "preferred_chains":[], "language":"pt-BR"}, favorites=1, analyses_today=3)
    assert "CENTRO DE INTELIGÊNCIA" in text
    assert "MINHA CONTA" in text
    assert "HISTÓRICO INTELIGENTE" in text


def test_renewal_history(tmp_path):
    from csm.storage import Storage
    storage = Storage(tmp_path / "db.sqlite")
    try:
        storage.upsert_user(1)
        storage.save_payment(payment_id="p1", user_id=1, plan="plus", invoice_url="x", external_reference="e", status="CONFIRMED", billing_type="PIX")
        rows = storage.renewal_history(1)
        assert len(rows) == 1
        assert rows[0]["payment_id"] == "p1"
    finally:
        storage.close()
