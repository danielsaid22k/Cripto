from __future__ import annotations

from types import SimpleNamespace

import csm.scanner as scanner_module


def test_ios_path_forces_mobile_detection(monkeypatch):
    monkeypatch.setattr(scanner_module.sys, "platform", "unknown")
    monkeypatch.setattr(scanner_module.sys, "executable", "/private/var/containers/Bundle/Application/ABC/a-Shell.app/python")
    assert scanner_module._is_mobile_runtime() is True


def test_scanner_uses_sequential_mode_on_mobile(monkeypatch):
    monkeypatch.setattr(scanner_module, "_is_mobile_runtime", lambda: True)
    object.__setattr__(scanner_module.settings, "scan_parallel_enabled", True)
    object.__setattr__(scanner_module.settings, "scan_mobile_delay_ms", 0)

    class Market:
        def fetch(self, chain, address, force=False):
            return {
                "chain": chain, "address": address, "liquidity": 100000,
                "volume24h": 1000000, "marketcap": 1000000, "age_days": 2,
                "change24h": 10, "buys24h": 100, "sells24h": 50,
            }

    scanner = scanner_module.MultichainScanner(market=Market(), http=SimpleNamespace())
    monkeypatch.setattr(scanner, "discover", lambda *a, **k: [("solana", "A")])
    result = scanner.scan(force=True)
    assert result
    assert scanner.last_stats["mode"] == "sequential-mobile"
