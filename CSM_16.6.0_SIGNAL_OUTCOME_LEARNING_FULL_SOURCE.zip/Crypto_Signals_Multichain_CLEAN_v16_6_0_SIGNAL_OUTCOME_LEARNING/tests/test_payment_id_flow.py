from unittest.mock import Mock
from pathlib import Path
import tempfile

from csm.payment_service import PaymentService, valid_cpf, valid_cnpj
from csm.storage import Storage


def test_document_validation():
    assert valid_cpf("52998224725")
    assert not valid_cpf("11111111111")
    assert valid_cnpj("11222333000181")


def test_create_and_confirm_payment(monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        storage = Storage(Path(td) / "test.db")
        storage.upsert_user(123, "user", "Daniel")
        client = Mock()
        client.customers_by_reference.return_value = []
        client.create_customer.return_value = {"id": "cus_1"}
        client.create_payment.return_value = {
            "id": "pay_1", "invoiceUrl": "https://sandbox.asaas.com/i/1", "status": "PENDING"
        }
        client.payment_status.return_value = "CONFIRMED"
        service = PaymentService(storage, client)
        row = service.create_payment(user_id=123, plan="plus", name="Daniel", cpf_cnpj="52998224725", billing_type="PIX")
        assert row["payment_id"] == "pay_1"
        result = service.verify_payment("pay_1")
        assert result["state"] == "activated"
        assert storage.get_user(123)["plan"] == "plus"


def test_reuses_pending_payment():
    with tempfile.TemporaryDirectory() as td:
        storage = Storage(Path(td) / "test.db")
        storage.upsert_user(123, "user", "Daniel")
        storage.save_payment(payment_id="pay_1", user_id=123, plan="plus", invoice_url="https://x", external_reference="csm:123:plus", status="PENDING", billing_type="PIX")
        client = Mock()
        service = PaymentService(storage, client)
        row = service.create_payment(user_id=123, plan="plus", name="Daniel", cpf_cnpj="52998224725", billing_type="PIX")
        assert row["payment_id"] == "pay_1"
        client.create_payment.assert_not_called()


def test_post_is_not_retried_automatically():
    from csm.http_client import SafeHTTP
    from urllib.error import URLError

    http = SafeHTTP(retries=3, backoff=0)
    calls = {"count": 0}

    class BrokenOpener:
        def open(self, *args, **kwargs):
            calls["count"] += 1
            raise URLError("offline")

    http._opener = BrokenOpener()
    try:
        http.post_json("https://example.invalid", data={"a": "b"})
    except Exception:
        pass
    assert calls["count"] == 1
