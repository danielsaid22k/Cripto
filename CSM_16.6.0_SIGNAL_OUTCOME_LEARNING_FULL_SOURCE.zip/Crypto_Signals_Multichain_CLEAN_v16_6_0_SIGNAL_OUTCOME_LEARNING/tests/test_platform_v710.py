from __future__ import annotations

from pathlib import Path


def test_version_and_lts_freeze():
    from csm import __version__
    from csm.platform_ops import LTS_BASE, RELEASE
    assert __version__.startswith("8.3.1")
    assert RELEASE == "8.2.1"
    assert LTS_BASE == "6.3.0"
    assert Path("LTS_FREEZE.json").exists()


def test_platform_dashboard_shape():
    from csm.platform_ops import platform_dashboard
    data = platform_dashboard()
    assert data["release"] == "8.2.1"
    assert data["lts_base"] == "6.3.0"
    assert data["status"] in {"healthy", "attention", "critical"}
    assert "admin" in data and "health" in data and "leader" in data and "alerts" in data


def test_leader_simulation_is_read_only():
    from csm.platform_ops import leader_simulation
    result = leader_simulation()
    assert result["simulation_only"] is True
    assert "Nenhuma alteração" in result["note"]
    assert isinstance(result["steps"], list)


def test_operational_alerts_are_structured():
    from csm.platform_ops import operational_alerts
    alerts = operational_alerts()
    for item in alerts:
        assert item.severity in {"low", "medium", "high", "critical"}
        assert item.code
        assert item.recommended_action


def test_production_readiness_shape():
    from csm.platform_ops import production_readiness
    data = production_readiness()
    assert data["decision"] in {"PROMOVER", "BLOQUEAR"}
    assert data["release"] == "8.2.1"
    assert "quality_gate" in data
    assert "restore_dry_run" in data
