from pathlib import Path


def test_product_report_builds(monkeypatch, tmp_path):
    monkeypatch.setenv("CSM_STATE_DIR", str(tmp_path / "state"))
    from csm.product_ops import build_product_report
    report = build_product_report()
    assert report.version.startswith("8.3.1")
    assert report.scanner_cycles_today >= 0


def test_preferences_and_scanner_metrics(monkeypatch, tmp_path):
    monkeypatch.setenv("CSM_STATE_DIR", str(tmp_path / "state2"))
    from csm.storage import Storage
    storage = Storage(tmp_path / "state2" / "signals.db")
    try:
        prefs = storage.user_preferences(123)
        assert prefs["auto_signals"] is True
        assert storage.toggle_user_preference(123, "auto_signals") is False
        storage.record_scanner_cycle("free", {"candidates": 10, "approved": 3, "sent": 1, "top_score": 91})
        stats = storage.scanner_stats_today()
        assert stats["cycles"] >= 1
        assert stats["discovered"] >= 10
    finally:
        storage.close()
