from __future__ import annotations

from datetime import datetime
from pathlib import Path


def test_version_and_freeze_manifest():
    from csm import __version__
    assert __version__.startswith("8.3.1")
    assert Path("LTS_FREEZE.json").exists()


def test_user_profile_store_atomic(tmp_path):
    from csm.user_profiles import UserProfileStore
    store = UserProfileStore(tmp_path / "profiles.json")
    profile = store.get(123)
    assert profile["preferred_chains"] == []
    profile = store.cycle_chains(123)
    assert profile["preferred_chains"] == ["solana"]
    profile = store.cycle_detail_mode(123)
    assert profile["detail_mode"] == "detailed"
    profile = store.cycle_quiet_hours(123)
    assert profile["quiet_hours"] == "22-07"
    assert store.is_quiet(profile, datetime(2026, 1, 1, 23, 0))
    assert not store.is_quiet(profile, datetime(2026, 1, 1, 12, 0))


def test_project_leader_2_report(tmp_path, monkeypatch):
    from csm.project_leader import ProjectLeader
    leader = ProjectLeader(base_dir=Path.cwd(), state_dir=tmp_path)
    report = leader.audit()
    assert report["version"] == "2.0"
    assert 0 <= report["health_score"] <= 100
    assert isinstance(report["suggestions"], list)


def test_professional_dashboard_shape():
    from csm.professional_ops import admin_dashboard
    data = admin_dashboard()
    assert data["release"] == "8.2.1"
    assert data["lts_base"] == "6.3.0"
    assert "resources" in data
