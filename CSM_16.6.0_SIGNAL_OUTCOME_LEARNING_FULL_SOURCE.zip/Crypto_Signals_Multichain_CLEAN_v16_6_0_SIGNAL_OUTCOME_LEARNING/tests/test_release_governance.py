from __future__ import annotations

import json
import sqlite3
import zipfile
from pathlib import Path


def test_release_version_and_required_docs():
    from csm import __version__

    assert __version__.startswith("8.3.1")
    for name in ("UPGRADE.md", "RECOVERY.md", "RELEASE_PROCESS.md", "CHANGELOG.md", "LTS_FREEZE.json"):
        assert Path(name).is_file(), name


def test_release_policy_metadata():
    from csm.release_ops import release_info

    info = release_info()
    assert info["release"] == "8.2.1"
    assert info["lts_base"] == "6.3.0"
    assert "7.0" in info["policy"]


def test_restore_dry_run_does_not_extract(tmp_path):
    from csm.release_ops import restore_dry_run

    backup = tmp_path / "backup.zip"
    manifest = {
        "format": 2,
        "created_at": "2026-08-05T00:00:00+00:00",
        "version": "7.1.3",
        "includes_secrets": True,
        "database_included": True,
    }
    with zipfile.ZipFile(backup, "w") as archive:
        archive.writestr("backup_manifest.json", json.dumps(manifest))
        archive.writestr("state/config.env", "TELEGRAM_BOT_TOKEN=x\nTELEGRAM_CHAT_ID=1\n")
        archive.writestr("state/signals.db", b"sqlite-placeholder")
        archive.writestr("project/main.py", "print('ok')\n")

    result = restore_dry_run(backup)
    assert result["valid"] is True
    assert result["has_database"] is True
    assert result["has_secrets"] is True
    assert result["would_overwrite_code"] is True
    assert not (tmp_path / "state").exists()


def test_database_gate_accepts_valid_schema(tmp_path):
    from csm.release_ops import _database_gate

    db = tmp_path / "signals.db"
    with sqlite3.connect(db) as conn:
        conn.execute("CREATE TABLE users (user_id INTEGER PRIMARY KEY)")
        conn.execute("PRAGMA user_version=600")
    item = _database_gate(db)
    assert item.passed is True
    assert "schema=600" in item.details


def test_health_dashboard_shape():
    from csm.release_ops import health_dashboard

    data = health_dashboard()
    assert data["release"] == "8.2.1"
    assert data["lts_base"] == "6.3.0"
    assert "database" in data
    assert "integrations" in data
    assert "scanner" in data
    assert "latest_backup" in data


def test_plan_and_scanner_defaults_are_governed():
    from csm.config import settings

    assert settings.plan_monthly_duration_days == 30
    assert settings.plan_annual_duration_days == 365
    assert settings.auto_scan_interval_free == 900
    assert settings.auto_scan_interval_plus == 300
    assert settings.auto_scan_interval_premium == 60


def test_monthly_and_annual_expiry_are_preserved(tmp_path):
    from datetime import datetime, timezone
    from csm.storage import Storage

    storage = Storage(tmp_path / "plans.db")
    try:
        storage.set_plan(10, "plus", 30)
        monthly = storage.get_user(10)
        monthly_days = (datetime.fromisoformat(monthly["expires_at"]) - datetime.now(timezone.utc)).total_seconds() / 86400
        assert 29 <= monthly_days <= 30.1

        storage.set_plan(11, "premium_annual", 365)
        annual = storage.get_user(11)
        annual_days = (datetime.fromisoformat(annual["expires_at"]) - datetime.now(timezone.utc)).total_seconds() / 86400
        assert 364 <= annual_days <= 365.1
    finally:
        storage.close()


def test_database_report_preserves_full_counts(tmp_path):
    from csm.persistence import database_report
    from csm.storage import Storage

    db = tmp_path / "full.db"
    storage = Storage(db)
    try:
        storage.upsert_user(1, "one", "One")
        storage.set_plan(1, "plus", 30)
        storage.save_payment(
            payment_id="pay-test",
            user_id=1,
            plan="plus",
            invoice_url="https://example.invalid",
            external_reference="test",
            status="CONFIRMED",
            billing_type="PIX",
        )
    finally:
        storage.close()
    report = database_report(db)
    assert report["integrity"] == "ok"
    assert report["schema_version"] > 0
    assert report["users"] == 1
    assert report["active_subscribers"] == 1
    assert report["payments"] == 1
