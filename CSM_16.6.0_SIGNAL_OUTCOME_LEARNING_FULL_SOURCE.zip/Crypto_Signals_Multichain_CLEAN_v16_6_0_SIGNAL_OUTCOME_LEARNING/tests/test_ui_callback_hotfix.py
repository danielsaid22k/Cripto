from csm.telegram import Telegram
from csm.preferences_ui import build_preferences_screen


class FakeHTTP:
    def __init__(self): self.calls=[]
    def post_json(self, url, data=None, timeout=None):
        self.calls.append((url, data))
        return {"ok": True, "result": True}


def test_callback_ack_is_independent():
    http=FakeHTTP(); tg=Telegram(http=http)
    assert tg.answer_callback("abc") is True
    assert "answerCallbackQuery" in http.calls[0][0]


def test_edit_or_send_falls_back():
    class FailingHTTP(FakeHTTP):
        def post_json(self, url, data=None, timeout=None):
            self.calls.append((url,data))
            if "editMessageText" in url: raise RuntimeError("not editable")
            return {"ok":True,"result":True}
    http=FailingHTTP(); tg=Telegram(http=http)
    assert tg.edit_or_send(1,2,"x") is True
    assert any("sendMessage" in url for url,_ in http.calls)


def test_preferences_screen_has_all_controls():
    class Profiles:
        def get(self, uid): return {"preferred_chains":[],"quiet_hours":"off","detail_mode":"standard","risk_profile":"moderate","language":"pt-BR","notification_frequency":"plan"}
    class Storage:
        def user_preferences(self, uid): return {"auto_signals":True,"favorite_alerts":True,"expiry_alerts":True}
    class App: pass
    app=App(); app.user_profiles=Profiles(); app.storage=Storage()
    text, keyboard=build_preferences_screen(app,1)
    assert "PREFERÊNCIAS" in text
    callbacks={b["callback_data"] for row in keyboard["inline_keyboard"] for b in row if "callback_data" in b}
    assert {"profile|risk","profile|chains","pref|auto_signals","menu"}.issubset(callbacks)
