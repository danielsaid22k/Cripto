from __future__ import annotations

import json
import time
from pathlib import Path

from csm.storage import Storage
from phantom_v10 import __version__
from phantom_v10.app import PhantomApp
from phantom_v10.release import runtime_audit, ui_audit
from phantom_v10.runtime import RuntimeGuard
from phantom_v10.scanner import ScannerEngine
from phantom_v10.telegram import TelegramClient
from phantom_v10.transport import NetworkBus, StdlibHttpTransport
from phantom_v10.ui import screens as ui


class DummyTelegram:
    def __init__(self):
        self.sent = []
        self.edited = []
        self.acked = []
    def answer_callback(self, cid, text=""):
        self.acked.append(cid)
        return True
    def send(self, chat_id, text, reply_markup=None):
        self.sent.append((chat_id, text, reply_markup))
        return {"message_id": 1}
    def edit_or_send(self, chat_id, message_id, text, reply_markup=None):
        self.edited.append((chat_id, message_id, text, reply_markup))
        return {"message_id": message_id}


class EmptyTransport:
    def __init__(self):
        self.calls = 0
    def get_json(self, url, params=None, timeout=None):
        self.calls += 1
        if "trending_pools" in url or "new_pools" in url:
            return {"data": []}
        return []


class FakeResponse:
    status = 200
    def read(self, _limit=None):
        return b'{"ok":true,"result":{"username":"phantom"}}'


class FakeConnection:
    def __init__(self, *args, **kwargs):
        self.closed = False
        self.requests = []
    def request(self, method, path, body=None, headers=None):
        self.requests.append((method, path, body, headers))
    def getresponse(self):
        return FakeResponse()
    def close(self):
        self.closed = True


def test_v10_version_and_runtime_audit():
    assert __version__ == "16.6.0-retool-admin-speechify"
    audit = runtime_audit()
    assert audit["result"] == "APROVADO"
    assert audit["network_transport"] == "stdlib-http.client"
    assert audit["max_concurrent_network"] == 1
    assert all(not values for values in audit["forbidden"].values())


def test_stdlib_transport_has_no_curl_or_subprocess_and_parses_json():
    bus = NetworkBus()
    transport = StdlibHttpTransport(
        bus=bus,
        label="test",
        connection_factory=lambda host, port, timeout: FakeConnection(),
    )
    result = transport.request_json("POST", "https://api.telegram.org/botx/getMe", data={"a": "b"})
    assert result.status == 200
    assert result.payload["ok"] is True
    assert bus.snapshot()["busy"] is False
    source = Path("phantom_v10/transport.py").read_text(encoding="utf-8")
    assert "import subprocess" not in source
    assert "Popen(" not in source


def test_telegram_client_uses_injected_stdlib_transport():
    bus = NetworkBus()
    transport = StdlibHttpTransport(
        bus=bus,
        label="telegram",
        connection_factory=lambda host, port, timeout: FakeConnection(),
    )
    client = TelegramClient(token="123:abc", transport=transport)
    assert client.get_me()["username"] == "phantom"
    assert bus.snapshot()["total_acquired"] == 1


def test_scanner_is_sequential_and_returns_control_every_step():
    transport = EmptyTransport()
    scanner = ScannerEngine(transport=transport)
    assert scanner.start(limit=10, chains=["solana"])
    result = None
    for _ in range(20):
        before = transport.calls
        result = scanner.step()
        assert transport.calls - before <= 1
        if result is not None:
            break
    assert result == []
    # V16.5.9 provider cooldown/recovery probes can legitimately change the
    # number of discovery sources, but each source remains one cooperative call.
    assert transport.calls == scanner.last_stats["sources_total"]
    assert scanner.active is False


def test_composition_root_shares_one_network_bus(tmp_path):
    storage = Storage(tmp_path / "app.db")
    app = PhantomApp(storage=storage, telegram=DummyTelegram())
    try:
        assert app.telegram_transport.bus is app.network_bus
        assert app.market_transport.bus is app.network_bus
        assert app.scanner_transport.bus is app.network_bus
        assert app.base_transport.bus is app.network_bus
    finally:
        storage.close()


def test_all_reply_buttons_are_local_and_functional(tmp_path):
    from csm.user_profiles import UserProfileStore
    storage = Storage(tmp_path / "buttons.db")
    telegram = DummyTelegram()
    app = PhantomApp(storage=storage, telegram=telegram)
    app.user_profiles = UserProfileStore(tmp_path / "profiles.json")
    storage.upsert_user(321, "u", "U")
    try:
        for label in sorted(ui.REPLY_BUTTONS):
            before = len(telegram.sent)
            app.router.message({"chat": {"id": 321}, "from": {"id": 321, "first_name": "U"}, "text": label})
            assert len(telegram.sent) > before, label
        assert app.scanner.active is False
    finally:
        storage.close()


def test_callback_registry_and_local_screens(tmp_path):
    from csm.user_profiles import UserProfileStore
    storage = Storage(tmp_path / "callbacks.db")
    telegram = DummyTelegram()
    app = PhantomApp(storage=storage, telegram=telegram)
    app.user_profiles = UserProfileStore(tmp_path / "profiles.json")
    storage.upsert_user(42, "u", "U")
    try:
        for data in ("menu", "preferences", "intelligence_center", "dashboard", "favorites", "history|0", "scanner"):
            app.router.callback({"id": "cb-" + data, "data": data, "message": {"chat": {"id": 42}, "message_id": 7}, "from": {"id": 42, "first_name": "U"}})
        assert len(telegram.acked) == 7
        assert len(telegram.edited) == 7
        assert ui_audit()["result"] == "APROVADO"
        assert app.scanner.active is False
    finally:
        storage.close()


def test_runtime_guard_archives_stale_and_clean_stop_leaves_no_active_files(tmp_path, monkeypatch):
    import phantom_v10.runtime as runtime
    monkeypatch.setattr(runtime, "STATE_DIR", tmp_path)
    guard = runtime.RuntimeGuard("bot", stale_after=30)
    guard.runtime_dir.mkdir(parents=True, exist_ok=True)
    old = {"session": "old", "heartbeat_at": time.time() - 120, "state": "running"}
    guard.lock_file.write_text(json.dumps(old))
    guard.session_file.write_text(json.dumps(old))
    event = guard.acquire()
    assert event.recovered is True
    guard.release(state="stopped")
    assert not guard.lock_file.exists()
    assert not guard.session_file.exists()
    assert list(guard.runtime_dir.glob("*.stale.*"))


def test_main_routes_active_bot_to_v10():
    source = Path("main.py").read_text(encoding="utf-8")
    assert "from phantom_v10.app import PhantomApp" in source
    assert "from phantom_v10.runtime import AlreadyRunningError, RuntimeGuard" in source
