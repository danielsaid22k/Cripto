from __future__ import annotations

import ast
from pathlib import Path

import pytest

from csm.storage import Storage
from csm.user_profiles import UserProfileStore
from phantom_v10.app import PhantomApp
from phantom_v10.scanner import ScannerEngine
from phantom_v10.telegram import TelegramClient
from phantom_v10.transport import NetworkBus, StdlibHttpTransport


class DummyTelegram:
    def __init__(self):
        self.sent = []

    def send(self, chat_id, text, reply_markup=None):
        self.sent.append((chat_id, text, reply_markup))
        return {"message_id": 1}

    def close(self):
        return None


class EmptyTransport:
    def get_json(self, url, params=None, timeout=None):
        return {"data": []} if "geckoterminal" in url else []


class InterruptResponse:
    status = 200

    def __init__(self):
        self.closed = False

    def read(self, _limit=None):
        raise KeyboardInterrupt()

    def close(self):
        self.closed = True


class InterruptConnection:
    def __init__(self):
        self.response = InterruptResponse()
        self.closed = False

    def request(self, method, path, body=None, headers=None):
        return None

    def getresponse(self):
        return self.response

    def close(self):
        self.closed = True


class RecordingTelegramTransport:
    def __init__(self):
        self.calls = []

    def post_json(self, url, data=None, timeout=None):
        self.calls.append((url, dict(data or {}), timeout))
        return {"ok": True, "result": []}


def test_transport_closes_response_and_connection_on_keyboard_interrupt():
    bus = NetworkBus()
    conn = InterruptConnection()
    transport = StdlibHttpTransport(
        bus=bus,
        label="interrupt-test",
        connection_factory=lambda host, port, timeout: conn,
    )
    with pytest.raises(KeyboardInterrupt):
        transport.get_json("https://example.com/test")
    assert conn.response.closed is True
    assert conn.closed is True
    assert bus.snapshot()["busy"] is False


def test_scanner_budget_is_partial_completion_not_watchdog_error():
    scanner = ScannerEngine(transport=EmptyTransport(), cycle_budget=10.0, cycle_timeout=30.0)
    assert scanner.start(limit=10, chains=["solana"])
    scanner._cycle_active_seconds = 11.0
    result = scanner.step()
    assert result == []
    assert scanner.active is False
    assert scanner.last_stats["partial"] == 1
    assert scanner.last_stats["aborted"] == 0
    assert scanner.last_stats["errors"] == 0
    assert "orçamento cooperativo" in scanner.last_error


def test_scanner_excludes_ios_background_suspension_from_watchdog():
    scanner = ScannerEngine(transport=EmptyTransport(), cycle_budget=10.0, cycle_timeout=30.0)
    assert scanner.start(limit=10, chains=["solana"])
    scanner._started -= 300.0
    scanner._cycle_clock_last -= 300.0

    result = scanner.step()

    assert result is None
    assert scanner.active is True
    assert scanner.last_stats["aborted"] == 0
    assert scanner.last_stats["timeouts"] == 0
    assert scanner.last_stats["suspensions"] == 1
    assert scanner.last_stats["suspended_seconds"] >= 299.0
    assert scanner.health_snapshot()["cycle_active_seconds"] < 1.0


def test_scanner_watchdog_still_covers_excessive_active_work():
    scanner = ScannerEngine(transport=EmptyTransport(), cycle_budget=10.0, cycle_timeout=30.0)
    assert scanner.start(limit=10, chains=["solana"])
    scanner._cycle_active_seconds = 31.0

    result = scanner.step()

    assert result == []
    assert scanner.active is False
    assert scanner.last_stats["aborted"] == 1
    assert scanner.last_stats["timeouts"] == 1
    assert "tempo ativo" in scanner.last_error


def test_telegram_uses_short_poll_while_scanner_can_run():
    transport = RecordingTelegramTransport()
    client = TelegramClient(token="123:abc", transport=transport)
    assert client.updates(poll_seconds=0) == []
    _, data, timeout = transport.calls[-1]
    assert data["timeout"] == "0"
    assert timeout == 2.0


def test_admin_can_request_safe_shutdown_from_telegram(tmp_path):
    storage = Storage(tmp_path / "safe-stop.db")
    telegram = DummyTelegram()
    app = PhantomApp(storage=storage, telegram=telegram)
    app.user_profiles = UserProfileStore(tmp_path / "profiles.json")
    app.is_admin = lambda user_id: True
    try:
        app.router.message({
            "chat": {"id": 77},
            "from": {"id": 77, "first_name": "Admin"},
            "text": "/encerrar",
        })
        assert app.shutdown_requested is True
        assert app.shutdown_reason == "Telegram /encerrar"
        assert telegram.sent
        assert "Encerramento seguro" in telegram.sent[-1][1]
    finally:
        app.close()


def test_main_has_no_operational_v9_imports():
    tree = ast.parse(Path("main.py").read_text(encoding="utf-8"))
    modules = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            modules.append(node.module or "")
    assert not [name for name in modules if name.startswith("phantom_v9")]


def test_safe_shutdown_bypasses_pending_payment_state(tmp_path):
    storage = Storage(tmp_path / "safe-stop-pending.db")
    telegram = DummyTelegram()
    app = PhantomApp(storage=storage, telegram=telegram)
    app.user_profiles = UserProfileStore(tmp_path / "profiles-pending.json")
    app.is_admin = lambda user_id: True
    app.pending_payment[77] = {"plan": "premium", "billing_type": "PIX", "name": "Admin"}
    try:
        app.router.message({
            "chat": {"id": 77},
            "from": {"id": 77, "first_name": "Admin"},
            "text": "/encerrar",
        })
        assert app.shutdown_requested is True
        assert "Encerramento seguro" in telegram.sent[-1][1]
        assert 77 in app.pending_payment
    finally:
        app.close()


class DoubleInterruptResponse(InterruptResponse):
    def close(self):
        self.closed = True
        raise KeyboardInterrupt()


class DoubleInterruptConnection(InterruptConnection):
    def __init__(self):
        self.response = DoubleInterruptResponse()
        self.closed = False


def test_transport_cleanup_survives_second_interrupt():
    bus = NetworkBus()
    conn = DoubleInterruptConnection()
    transport = StdlibHttpTransport(
        bus=bus,
        label="double-interrupt-test",
        connection_factory=lambda host, port, timeout: conn,
    )
    with pytest.raises(KeyboardInterrupt):
        transport.get_json("https://example.com/test")
    assert conn.response.closed is True
    assert conn.closed is True
    assert bus.snapshot()["busy"] is False
