from __future__ import annotations

from datetime import datetime, timezone

from csm.storage import Storage
from csm.user_profiles import UserProfileStore
from phantom_v10.app import PhantomApp
from phantom_v10.telegram import TelegramClient


class DummyTelegram:
    def __init__(self):
        self.sent = []

    def send(self, chat_id, text, reply_markup=None):
        self.sent.append((chat_id, text, reply_markup))
        return {"message_id": 1}

    def close(self):
        return None


class RecordingTransport:
    def __init__(self):
        self.calls = []

    def post_json(self, url, data=None, timeout=None):
        self.calls.append((url, dict(data or {}), timeout))
        return {"ok": True, "result": []}


def test_stale_shutdown_message_from_previous_process_is_ignored(tmp_path):
    storage = Storage(tmp_path / "signals.db")
    telegram = DummyTelegram()
    app = PhantomApp(storage=storage, telegram=telegram)
    app.user_profiles = UserProfileStore(tmp_path / "profiles.json")
    app.is_admin = lambda user_id: True
    app.started_at = datetime.now(timezone.utc)
    try:
        old_date = int(app.started_at.timestamp()) - 30
        result = app.router.message({
            "chat": {"id": 77},
            "from": {"id": 77, "first_name": "Admin"},
            "date": old_date,
            "text": "/encerrar",
        })
        assert result is None
        assert app.shutdown_requested is False
        assert telegram.sent == []
    finally:
        app.close()


def test_current_shutdown_message_still_stops_bot(tmp_path):
    storage = Storage(tmp_path / "signals.db")
    telegram = DummyTelegram()
    app = PhantomApp(storage=storage, telegram=telegram)
    app.user_profiles = UserProfileStore(tmp_path / "profiles.json")
    app.is_admin = lambda user_id: True
    try:
        now = int(datetime.now(timezone.utc).timestamp())
        app.router.message({
            "chat": {"id": 77},
            "from": {"id": 77, "first_name": "Admin"},
            "date": now,
            "text": "/encerrar",
        })
        assert app.shutdown_requested is True
        assert app.shutdown_reason == "Telegram /encerrar"
        assert telegram.sent
    finally:
        app.close()


def test_telegram_offset_checkpoint_is_atomic_and_bot_scoped(tmp_path):
    storage = Storage(tmp_path / "signals.db")
    app = PhantomApp(storage=storage, telegram=DummyTelegram())
    try:
        assert app._load_telegram_offset(123) is None
        app._save_telegram_offset(456, 123)
        assert app._load_telegram_offset(123) == 456
        assert app._load_telegram_offset(999) is None
        assert app.telegram_offset_file.exists()
        assert not app.telegram_offset_file.with_name(app.telegram_offset_file.name + ".tmp").exists()
    finally:
        app.close()


def test_confirm_offset_sends_nonblocking_getupdates_ack():
    transport = RecordingTransport()
    client = TelegramClient(token="123:abc", transport=transport)
    client.confirm_offset(456)
    _, data, timeout = transport.calls[-1]
    assert data["offset"] == "456"
    assert data["limit"] == "1"
    assert data["timeout"] == "0"
    assert timeout == 2.0

class ReplayTelegram:
    def __init__(self, stale_update=None):
        self.stale_update = stale_update
        self.offsets = []

    def bootstrap(self, attempts=3):
        return {"id": 123, "username": "phantom"}

    def prepare(self):
        return []

    def updates(self, offset=None, poll_seconds=1):
        self.offsets.append(offset)
        if self.stale_update is not None and offset is None:
            update = self.stale_update
            self.stale_update = None
            return [update]
        return []

    def confirm_offset(self, offset):
        return None

    def close(self):
        return None


class StopAfterOneStepScheduler:
    def __init__(self, app):
        self.app = app

    def start(self):
        return None

    def step(self):
        self.app.request_shutdown("test")

    def stop(self):
        return None


def test_run_replays_old_v1001_shutdown_once_but_does_not_stop_and_checkpoints_it(tmp_path):
    storage1 = Storage(tmp_path / "signals.db")
    started = datetime.now(timezone.utc)
    stale = {
        "update_id": 900,
        "message": {
            "chat": {"id": 77},
            "from": {"id": 77, "first_name": "Admin"},
            "date": int(started.timestamp()) - 60,
            "text": "/encerrar",
        },
    }
    telegram1 = ReplayTelegram(stale)
    app1 = PhantomApp(storage=storage1, telegram=telegram1)
    app1.started_at = started
    app1.is_admin = lambda user_id: True
    app1.scheduler = StopAfterOneStepScheduler(app1)
    try:
        app1.run()
        assert app1.shutdown_reason == "test"
        assert app1._load_telegram_offset(123) == 901
    finally:
        app1.close()

    storage2 = Storage(tmp_path / "signals.db")
    telegram2 = ReplayTelegram(stale)
    app2 = PhantomApp(storage=storage2, telegram=telegram2)
    app2.is_admin = lambda user_id: True
    app2.scheduler = StopAfterOneStepScheduler(app2)
    try:
        app2.run()
        assert telegram2.offsets[0] == 901
        assert app2.shutdown_reason == "test"
    finally:
        app2.close()
