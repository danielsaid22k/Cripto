from __future__ import annotations

from csm.storage import Storage
from phantom_v10.app import PhantomApp
from phantom_v10.market import MarketService
from phantom_v10.presentation import market_report, position_alert, token_identity
from phantom_v10.providers import ProviderGateway


def sample_market() -> dict:
    return {
        "source": "GeckoTerminal",
        "chain": "solana",
        "name": "Cupsey",
        "symbol": "CUPSE",
        "address": "6NwarBvDkXhByqVp2Qkq5i9XbtA2B3Bwe8SWGu9vpump",
        "price": 0.0093855,
        "liquidity": 125_000,
        "volume24h": 680_000,
        "volume6h": 240_000,
        "volume1h": 58_000,
        "volume5m": 7_500,
        "marketcap": 1_200_000,
        "fdv": 1_500_000,
        "change24h": 18.4,
        "change6h": 7.2,
        "change1h": 2.1,
        "change5m": 0.8,
        "buys24h": 420,
        "sells24h": 280,
        "buys6h": 150,
        "sells6h": 90,
        "buys1h": 44,
        "sells1h": 24,
        "buys5m": 8,
        "sells5m": 3,
        "buyers24h": 310,
        "sellers24h": 205,
        "age_days": 4.5,
        "dex": "Raydium",
        "pair": "PairAddress123456789",
        "quote_symbol": "SOL",
        "url": "https://www.geckoterminal.com/solana/pools/PairAddress123456789",
        "holders": None,
        "sentiment_positive": 72,
        "sentiment_negative": 28,
        "community_sus_report": 0,
        "last_trade_timestamp": 1_775_000_000,
        "websites": [{"label": "Website", "url": "https://example.com"}],
        "socials": [{"type": "twitter", "url": "https://example.com/x"}],
        "boosts_active": 0,
        "labels": ["CLMM"],
        "cached": False,
    }


def test_gecko_metadata_uses_requested_token_and_token_price():
    item = {
        "id": "solana_PoolAddress",
        "attributes": {
            "address": "PoolAddress",
            "name": "SOL / CUPSE",
            "token_price_usd": "0.0093855",
            "base_token_price_usd": "175.00",
            "quote_token_price_usd": "0.0093855",
            "reserve_in_usd": "125000",
            "volume_usd": {"m5": "7500", "h1": "58000", "h6": "240000", "h24": "680000"},
            "market_cap_usd": "1200000",
            "fdv_usd": "1500000",
            "price_change_percentage": {"m5": "0.8", "h1": "2.1", "h6": "7.2", "h24": "18.4"},
            "transactions": {
                "m5": {"buys": 8, "sells": 3},
                "h1": {"buys": 44, "sells": 24, "buyers": 39, "sellers": 20},
                "h6": {"buys": 150, "sells": 90},
                "h24": {"buys": 420, "sells": 280, "buyers": 310, "sellers": 205},
            },
            "pool_created_at": "2026-08-04T12:00:00Z",
            "sentiment_vote_positive_percentage": 72,
            "sentiment_vote_negative_percentage": 28,
            "community_sus_report": 0,
            "last_trade_timestamp": 1_775_000_000,
        },
        "relationships": {
            "base_token": {"data": {"id": "solana_So11111111111111111111111111111111111111112"}},
            "quote_token": {"data": {"id": "solana_6NwarBvDkXhByqVp2Qkq5i9XbtA2B3Bwe8SWGu9vpump"}},
            "dex": {"data": {"id": "raydium"}},
        },
    }
    included = [
        {
            "id": "solana_So11111111111111111111111111111111111111112",
            "type": "token",
            "attributes": {"address": "So11111111111111111111111111111111111111112", "name": "Wrapped SOL", "symbol": "SOL"},
        },
        {
            "id": "solana_6NwarBvDkXhByqVp2Qkq5i9XbtA2B3Bwe8SWGu9vpump",
            "type": "token",
            "attributes": {
                "address": "6NwarBvDkXhByqVp2Qkq5i9XbtA2B3Bwe8SWGu9vpump",
                "name": "Cupsey",
                "symbol": "CUPSE",
            },
        },
        {"id": "raydium", "type": "dex", "attributes": {"name": "Raydium"}},
    ]

    market = MarketService.normalize_gecko(
        item,
        "solana",
        "6NwarBvDkXhByqVp2Qkq5i9XbtA2B3Bwe8SWGu9vpump",
        included=included,
    )

    assert market["symbol"] == "CUPSE"
    assert market["name"] == "Cupsey"
    assert market["quote_symbol"] == "SOL"
    assert market["price"] == 0.0093855
    assert market["dex"] == "Raydium"
    assert market["buyers24h"] == 310
    assert market["age_days"] is not None
    assert market["url"].startswith("https://www.geckoterminal.com/solana/pools/")


def test_gecko_pool_name_is_safe_fallback_instead_of_question_mark():
    market = MarketService.normalize_gecko(
        {
            "id": "solana_pool",
            "attributes": {
                "name": "CUPSE / SOL",
                "token_price_usd": "0.01",
                "transactions": {},
                "volume_usd": {},
                "price_change_percentage": {},
            },
        },
        "solana",
        "mint",
    )
    assert market["symbol"] == "CUPSE"
    assert token_identity(market)[0] == "CUPSE"


def test_provider_cache_is_isolated_by_network_and_contract():
    gateway = ProviderGateway()
    calls = []

    first = gateway.fetch(
        "GeckoTerminal market",
        lambda: calls.append("A") or {"token": "A"},
        cache_key="gecko:solana:mint-a",
    )
    second = gateway.fetch(
        "GeckoTerminal market",
        lambda: calls.append("B") or {"token": "B"},
        cache_key="gecko:solana:mint-b",
    )
    first_cached = gateway.fetch(
        "GeckoTerminal market",
        lambda: calls.append("A-again") or {"token": "wrong"},
        cache_key="gecko:solana:mint-a",
    )

    assert first == {"token": "A"}
    assert second == {"token": "B"}
    assert first_cached == {"token": "A"}
    assert calls == ["A", "B"]


def test_plan_messages_keep_targets_but_change_depth_and_frequency():
    market = sample_market()
    free, _ = market_report(market, "free")
    plus, _ = market_report(market, "plus_annual")
    premium, _ = market_report(market, "premium")

    assert "a cada 15 minutos" in free
    assert "ACOMPANHAMENTO ESSENCIAL" in free
    assert "Stop loss:" not in free and "Take profit 2:" not in free
    assert "PESQUISA DE MERCADO PREMIUM" not in free
    assert "COMPOSIÇÃO DO SCORE" not in free

    assert "a cada 5 minutos" in plus
    assert "Stop loss" in plus and "Risco/retorno" in plus
    assert "LEITURA DO SINAL" in plus
    assert "PESQUISA DE MERCADO PREMIUM" not in plus

    assert "a cada 1 minuto" in premium
    assert "PESQUISA DE MERCADO PREMIUM" in premium
    assert "COMPOSIÇÃO DO SCORE" in premium
    assert "Pressão compradora" in premium
    assert "QUALIDADE DOS DADOS" in premium
    assert "FDV" in premium
    assert len(premium) < 4096


def test_position_alert_depth_is_distinct_for_free_plus_and_premium():
    market = sample_market()
    position = {
        "symbol": "CUPSE",
        "chain": "solana",
        "address": market["address"],
        "entry_price": market["price"],
        "stop_price": market["price"] * 0.88,
        "target1_price": market["price"] * 1.25,
        "target2_price": market["price"] * 1.50,
    }
    free = position_alert(position, market, "TARGET1", 25.0, market["price"] * 1.30, "free")
    plus = position_alert(position, market, "TARGET1", 25.0, market["price"] * 1.30, "plus")
    premium = position_alert(position, market, "TARGET1", 25.0, market["price"] * 1.30, "premium")

    assert "Preço observado" in free
    assert "Stop inicial:" not in free and "TP1:" not in free and "TP2:" not in free
    assert "Plus:" in free and "Premium:" in free

    assert "Stop inicial:" in plus and "TP1:" in plus and "TP2:" in plus
    assert "Risco/retorno original" in plus
    assert "CONTEXTO PREMIUM NO ALERTA" not in plus

    assert "Stop inicial:" in premium and "TP1:" in premium and "TP2:" in premium
    assert "Máxima acompanhada" in premium
    assert "CONTEXTO PREMIUM NO ALERTA" in premium
    assert "Liquidez:" in premium and "Volume 24h:" in premium and "Market cap:" in premium

    assert len(free) < len(plus) < len(premium)


def test_position_alert_repairs_legacy_unknown_symbol_and_shows_full_levels():
    market = sample_market()
    position = {
        "symbol": "?",
        "chain": "solana",
        "address": market["address"],
        "entry_price": market["price"],
        "stop_price": market["price"] * 0.88,
        "target1_price": market["price"] * 1.25,
        "target2_price": market["price"] * 1.50,
    }
    text = position_alert(position, market, "TARGET2", 74.6, market["price"] * 1.746, "premium")
    assert "CUPSE" in text
    assert "<b>?</b>" not in text
    assert "TAKE PROFIT 2 ATINGIDO" in text
    assert "Entrada:" in text and "Preço atual:" in text
    assert "Stop inicial:" in text and "TP1:" in text and "TP2:" in text
    assert "a cada 1 minuto" in text


class DummyTelegram:
    def close(self):
        return None


def test_history_repairs_legacy_question_mark_and_adds_analysis_button(tmp_path):
    storage = Storage(tmp_path / "signals.db")
    storage.upsert_user(77, "daniel", "Daniel")
    market = sample_market()
    market["symbol"] = "?"
    market["name"] = "CUPSE / SOL"
    storage.save_analysis(77, "solana", market["address"], 93, market)
    app = PhantomApp(storage=storage, telegram=DummyTelegram())
    try:
        text, keyboard = app.history_screen(77)
        assert "CUPSE" in text
        assert "<b>?</b>" not in text
        assert "GeckoTerminal" in text
        assert keyboard["inline_keyboard"][0][0]["callback_data"].startswith("refresh|solana|")
    finally:
        app.close()
