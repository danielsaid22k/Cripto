from __future__ import annotations

from csm.storage import Storage
from csm.user_profiles import UserProfileStore
from phantom_v10.auto_delivery import AutomaticSignalDelivery
from phantom_v10.errors import TelegramAPIError, TransientNetworkError


def item(address: str, score: int, *, symbol: str = "TOK", chain: str = "solana") -> dict:
    return {
        "chain": chain,
        "address": address,
        "symbol": symbol,
        "name": symbol,
        "score": score,
        "opportunity_score": score,
        "price": 0.001,
        "liquidity": 100_000,
        "volume24h": 300_000,
        "marketcap": 500_000,
        "fdv": 600_000,
        "change24h": 12.5,
        "buys24h": 120,
        "sells24h": 80,
        "source": "test",
        "url": "https://example.test/chart",
    }


class DummyTelegram:
    def __init__(self):
        self.sent = []

    def send(self, user_id, text, keyboard=None):
        self.sent.append((int(user_id), text, keyboard))
        return {"message_id": len(self.sent)}


class FailingTelegram:
    def send(self, user_id, text, keyboard=None):
        raise TelegramAPIError("chat inválido", 400)


class RetryTelegram:
    def __init__(self):
        self.calls = 0
        self.sent = []

    def send(self, user_id, text, keyboard=None):
        self.calls += 1
        if self.calls < 3:
            raise TransientNetworkError("temporário")
        self.sent.append((int(user_id), text, keyboard))
        return {"message_id": 1}


def make_delivery(tmp_path, storage, telegram):
    profiles = UserProfileStore(tmp_path / "profiles.json")
    return AutomaticSignalDelivery(
        storage=storage,
        telegram=telegram,
        user_profiles=profiles,
        warning_logger=lambda _text: None,
    )


def test_quota_is_filled_after_duplicates_instead_of_before(tmp_path):
    storage = Storage(tmp_path / "signals.db")
    storage.upsert_user(100, "premium", "Premium")
    storage.set_plan(100, "premium", 30)
    telegram = DummyTelegram()
    delivery = make_delivery(tmp_path, storage, telegram)
    rows = [item("A1", 99), item("A2", 98), item("A3", 97)]
    try:
        storage.mark_alert_delivery(100, "solana", "A1", "entry", 99)
        storage.mark_alert_delivery(100, "solana", "A2", "entry", 98)

        summary = delivery.deliver("premium", rows)

        assert summary["approved"] == 3
        assert summary["duplicates"] == 2
        assert summary["eligible"] == 1
        assert summary["sent"] == 1
        assert len(telegram.sent) == 1
        assert "A3" in telegram.sent[0][1]
        assert "RAIO-X PREMIUM" in telegram.sent[0][1]
        assert storage.alert_delivery_exists(100, "solana", "A3", "entry")
    finally:
        storage.close()


def test_each_plan_has_its_own_recipient_and_delivery_quota(tmp_path):
    storage = Storage(tmp_path / "plans.db")
    storage.upsert_user(1, "free", "Free")
    storage.upsert_user(2, "plus", "Plus")
    storage.upsert_user(3, "premium", "Premium")
    storage.set_plan(2, "plus", 30)
    storage.set_plan(3, "premium", 30)
    telegram = DummyTelegram()
    delivery = make_delivery(tmp_path, storage, telegram)
    rows = [item(f"T{index}", 100 - index, symbol=f"T{index}") for index in range(1, 6)]
    try:
        free = delivery.deliver("free", rows)
        plus = delivery.deliver("plus", rows)
        premium = delivery.deliver("premium", rows)

        assert free["sent"] == 1
        assert plus["sent"] == 2
        assert premium["sent"] == 3
        assert [row[0] for row in telegram.sent] == [1, 2, 2, 3, 3, 3]
        assert "SINAL ESSENCIAL" in telegram.sent[0][1]
        assert "SINAL PLUS" in telegram.sent[1][1]
        assert "RAIO-X PREMIUM" in telegram.sent[3][1]
    finally:
        storage.close()


def test_confirmed_duplicate_is_not_resent_and_reason_is_explicit(tmp_path):
    storage = Storage(tmp_path / "dedupe.db")
    storage.upsert_user(7, "free", "Free")
    telegram = DummyTelegram()
    delivery = make_delivery(tmp_path, storage, telegram)
    rows = [item("DUP", 95)]
    try:
        first = delivery.deliver("free", rows)
        second = delivery.deliver("free", rows)
        assert first["sent"] == 1
        assert second["sent"] == 0
        assert second["duplicates"] == 1
        assert second["reason"] == "aprovados já enviados aos destinatários"
        assert len(telegram.sent) == 1
    finally:
        storage.close()


def test_failed_telegram_send_never_creates_deduplication_marker(tmp_path):
    storage = Storage(tmp_path / "failure.db")
    storage.upsert_user(8, "free", "Free")
    delivery = make_delivery(tmp_path, storage, FailingTelegram())
    try:
        summary = delivery.deliver("free", [item("FAIL", 90)])
        assert summary["sent"] == 0
        assert summary["errors"] == 1
        assert not storage.alert_delivery_exists(8, "solana", "FAIL", "entry")
    finally:
        storage.close()


def test_transient_telegram_failure_retries_then_marks_delivery(tmp_path, monkeypatch):
    import phantom_v10.auto_delivery as module

    monkeypatch.setattr(module.time, "sleep", lambda _seconds: None)
    storage = Storage(tmp_path / "retry.db")
    storage.upsert_user(9, "free", "Free")
    telegram = RetryTelegram()
    delivery = make_delivery(tmp_path, storage, telegram)
    try:
        summary = delivery.deliver("free", [item("RETRY", 91)])
        assert telegram.calls == 3
        assert summary["sent"] == 1
        assert summary["errors"] == 0
        assert storage.alert_delivery_exists(9, "solana", "RETRY", "entry")
    finally:
        storage.close()

class FirstCandidateFailsTelegram:
    def __init__(self):
        self.calls = []
        self.sent = []

    def send(self, user_id, text, keyboard=None):
        self.calls.append(text)
        if "<b>BAD</b>" in text or "<code>BAD1</code>" in text:
            raise TelegramAPIError("mensagem rejeitada", 400)
        self.sent.append((int(user_id), text, keyboard))
        return {"message_id": 1}


def test_failed_candidate_does_not_consume_plan_quota(tmp_path):
    storage = Storage(tmp_path / "fill-after-error.db")
    storage.upsert_user(12, "free", "Free")
    telegram = FirstCandidateFailsTelegram()
    delivery = make_delivery(tmp_path, storage, telegram)
    try:
        summary = delivery.deliver(
            "free",
            [item("BAD1", 99, symbol="BAD"), item("GOOD2", 98, symbol="GOOD")],
        )
        assert summary["errors"] == 1
        assert summary["sent"] == 1
        assert len(telegram.calls) == 2
        assert "GOOD2" in telegram.sent[0][1]
        assert not storage.alert_delivery_exists(12, "solana", "BAD1", "entry")
        assert storage.alert_delivery_exists(12, "solana", "GOOD2", "entry")
    finally:
        storage.close()
