from types import SimpleNamespace
import phantom_v10.discovery as discovery
from phantom_v10.discovery import birdeye_rows, MultiProviderDiscovery


def test_birdeye_data_items_inherit_requested_chain_when_item_omits_chain():
    payload = {
        "success": True,
        "data": {
            "items": [
                {
                    "address": "TokenAddress111",
                    "symbol": "ONE",
                    "name": "Token One",
                    "liquidityAddedAt": 123,
                    "liquidity": 1000,
                },
                {
                    "address": "TokenAddress222",
                    "symbol": "TWO",
                    "name": "Token Two",
                },
            ]
        },
    }
    assert birdeye_rows(payload, "solana") == [
        ("solana", "TokenAddress111"),
        ("solana", "TokenAddress222"),
    ]


def test_birdeye_item_explicit_chain_overrides_requested_chain():
    payload = {"data": {"items": [{"address": "0xabc", "chain": "ethereum"}]}}
    assert birdeye_rows(payload, "solana") == [("ethereum", "0xabc")]


def test_birdeye_source_parser_carries_source_chain(monkeypatch):
    fake = SimpleNamespace(
        multi_provider_enabled=True,
        birdeye_api_key="test-key",
        coingecko_api_key="",
        multi_provider_plus_chain_sources=1,
        multi_provider_premium_chain_sources=1,
        multi_provider_discovery_ttl=30,
        scan_discovery_ttl=30,
    )
    monkeypatch.setattr(discovery, "settings", fake)
    sources = MultiProviderDiscovery().sources("premium", ["solana"])
    src = next(s for s in sources if s.provider == "birdeye")
    rows = src.parser({"success": True, "data": {"items": [{"address": "MintABC"}]}})
    assert rows == [("solana", "MintABC")]
