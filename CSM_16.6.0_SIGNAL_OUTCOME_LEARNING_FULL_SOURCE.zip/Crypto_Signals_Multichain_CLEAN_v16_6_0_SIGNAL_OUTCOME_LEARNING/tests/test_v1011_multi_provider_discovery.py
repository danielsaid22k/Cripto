from __future__ import annotations

from csm.config import settings
from phantom_v10.discovery import MultiProviderDiscovery, birdeye_rows, gecko_rows
from phantom_v10.scanner import ScannerEngine


def test_birdeye_parser_accepts_common_new_listing_shapes():
    payload = {"data": {"items": [
        {"address": "SoL111", "chain": "solana"},
        {"token_address": "0xabc", "network": "ethereum"},
    ]}}
    assert birdeye_rows(payload) == [("solana", "SoL111"), ("ethereum", "0xabc")]


def test_gecko_parser_extracts_base_token_relationship():
    payload = {"data": [{
        "id": "solana_pool",
        "relationships": {"base_token": {"data": {"id": "solana_MINT123"}}},
    }]}
    assert gecko_rows(payload) == [("solana", "MINT123")]


def test_free_sources_remain_core_and_keyless(tmp_path):
    old_data = settings.data_dir
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        layer = MultiProviderDiscovery()
        rows = layer.sources("free", ("solana", "ethereum"))
        providers = {row.provider for row in rows}
        assert providers == {"geckoterminal", "dexscreener"}
        assert all(not row.headers for row in rows)
    finally:
        object.__setattr__(settings, "data_dir", old_data)


def test_plus_and_premium_extra_sources_are_optional_by_key(tmp_path):
    old_b = settings.birdeye_api_key
    old_c = settings.coingecko_api_key
    old_m = settings.multi_provider_enabled
    old_data = settings.data_dir
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        object.__setattr__(settings, "multi_provider_enabled", True)
        object.__setattr__(settings, "birdeye_api_key", "bird-test")
        object.__setattr__(settings, "coingecko_api_key", "cg-test")
        layer = MultiProviderDiscovery()
        plus = layer.sources("plus", ("solana", "ethereum", "bsc"))
        premium = layer.sources("premium", ("solana", "ethereum", "bsc"))
        assert "birdeye" in {row.provider for row in plus}
        assert "coingecko" not in {row.provider for row in plus}
        assert {"birdeye", "coingecko"}.issubset({row.provider for row in premium})
        assert any(row.headers.get("X-API-KEY") == "bird-test" for row in premium)
        assert any(row.headers.get("x-cg-demo-api-key") == "cg-test" for row in premium)
    finally:
        object.__setattr__(settings, "birdeye_api_key", old_b)
        object.__setattr__(settings, "coingecko_api_key", old_c)
        object.__setattr__(settings, "multi_provider_enabled", old_m)
        object.__setattr__(settings, "data_dir", old_data)


def test_scanner_records_discovery_tier_and_sources():
    scanner = ScannerEngine(cycle_timeout=60, cycle_budget=20)
    assert scanner.start(limit=10, chains=("solana",), tier="premium") is True
    snap = scanner.health_snapshot()
    assert snap["discovery_tier"] == "premium"
    assert snap["discovery_sources"]
    scanner.cancel("test")
