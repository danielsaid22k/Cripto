from phantom_v10.scheduler import Scheduler


def test_provider_metrics_line_shows_all_sources_and_unique_counts():
    line = Scheduler._provider_metrics_line({
        "provider_candidates": {
            "dexscreener": 12,
            "geckoterminal": 9,
            "birdeye": 6,
            "coingecko": 4,
        },
        "provider_unique_added": {
            "dexscreener": 8,
            "geckoterminal": 5,
            "birdeye": 4,
            "coingecko": 1,
        },
        "provider_sources_ok": {"dexscreener": 2, "geckoterminal": 2, "birdeye": 1, "coingecko": 1},
        "provider_sources_failed": {},
        "discovered": 18,
        "analyzed": 7,
        "approved": 3,
    })
    assert "DexScreener=12(+8)" in line
    assert "GeckoTerminal=9(+5)" in line
    assert "Birdeye=6(+4)" in line
    assert "CoinGecko=4(+1)" in line
    assert "únicos=18" in line
    assert "analisados=7" in line
    assert "aprovados=3" in line


def test_provider_metrics_line_marks_failed_source_without_exposing_secrets():
    line = Scheduler._provider_metrics_line({
        "provider_candidates": {"birdeye": 0},
        "provider_unique_added": {"birdeye": 0},
        "provider_sources_failed": {"birdeye": 1},
        "discovered": 0,
        "analyzed": 0,
        "approved": 0,
    })
    assert "Birdeye=0(+0) ⚠️1" in line
    assert "API" not in line
