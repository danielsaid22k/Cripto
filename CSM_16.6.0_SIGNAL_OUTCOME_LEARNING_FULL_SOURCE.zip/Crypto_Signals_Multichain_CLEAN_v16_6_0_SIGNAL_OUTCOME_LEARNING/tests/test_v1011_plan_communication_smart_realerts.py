from __future__ import annotations

from csm.experience import scan_explainer
from csm.storage import Storage
from phantom_v10.app import PhantomApp
from phantom_v10.presentation import position_alert
from phantom_v10.ui.screens import plans_text


def _market(score=80, volume=100_000, price=1.1):
    return {
        "chain": "solana",
        "address": "So11111111111111111111111111111111111111112",
        "symbol": "TEST",
        "name": "Test",
        "price": price,
        "liquidity": 100_000,
        "volume24h": volume,
        "marketcap": 1_000_000,
        "fdv": 1_200_000,
        "buys24h": 100,
        "sells24h": 50,
        "score": score,
        "opportunity_score": score,
        "age_days": 2,
        "dex": "raydium",
    }


def _position():
    return {
        "id": 1,
        "user_id": 99,
        "chain": "solana",
        "address": "A",
        "symbol": "TEST",
        "entry_price": 1.0,
        "stop_price": 0.88,
        "target1_price": 1.25,
        "target2_price": 1.5,
        "context_score": 80,
        "context_volume": 100_000,
        "context_peak_price": 1.0,
        "context_risk_rank": 1,
        "context_alerts": 0,
    }


def test_plan_copy_says_interval_is_search_not_signal_promise():
    text = plans_text()
    assert "frequência de <b>busca</b>" in text
    assert "Sem nova oportunidade aprovada = sem novo sinal" in text
    assert "quantidade mínima" in text
    assert "até <b>3</b> novas oportunidades" in text


def test_scan_explainer_distinguishes_tiers():
    free = scan_explainer("free")
    plus = scan_explainer("plus")
    premium = scan_explainer("premium")
    assert "15 minutos" in free and "1 nova oportunidade" in free
    assert "5 minutos" in plus and "até 2 novas oportunidades" in plus
    assert "1 minuto" in premium and "até 3 novas oportunidades" in premium
    assert "Realertas inteligentes" in premium


def test_smart_alert_has_change_reasons_for_paid_plan():
    text = position_alert(
        _position(), _market(), "SMART", 10.0, 1.1, "premium",
        smart_reasons=["score subiu de 80 para 90"],
    )
    assert "ATUALIZAÇÃO INTELIGENTE" in text
    assert "O QUE MUDOU" in text
    assert "score subiu" in text
    assert "não é promessa de um novo sinal" in text


def test_premium_realerts_earlier_than_plus():
    app = PhantomApp.__new__(PhantomApp)
    position = _position()
    market = _market(score=88, volume=160_000, price=1.11)
    premium_reasons, _ = app._smart_realert(position, market, "premium", 1.11)
    plus_reasons, _ = app._smart_realert(position, market, "plus", 1.11)
    assert premium_reasons
    assert plus_reasons == []


def test_storage_migrates_context_columns(tmp_path):
    storage = Storage(path=tmp_path / "signals.db")
    columns = {row[1] for row in storage.conn.execute("PRAGMA table_info(signal_positions)").fetchall()}
    for name in {
        "context_score", "context_volume", "context_peak_price",
        "context_risk_rank", "context_alerts", "last_context_event",
    }:
        assert name in columns
    storage.close()
