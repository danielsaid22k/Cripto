import time
from types import SimpleNamespace

from phantom_v10.discovery import MultiProviderDiscovery
from phantom_v10.scheduler import Scheduler
from phantom_v10.scanner import ScannerEngine


def test_coingecko_404_quarantines_only_provider_chain(monkeypatch):
    discovery = MultiProviderDiscovery()
    discovery.mark_temporarily_unsupported("coingecko", "fantom", ttl_seconds=300)
    assert discovery._is_temporarily_unsupported("coingecko", "fantom") is True
    assert discovery._is_temporarily_unsupported("coingecko", "ethereum") is False


def test_capability_quarantine_expires_and_revalidates(monkeypatch):
    discovery = MultiProviderDiscovery()
    discovery.mark_temporarily_unsupported("coingecko", "fantom", ttl_seconds=300)
    key = ("coingecko", "fantom")
    discovery._unsupported_until[key] = time.monotonic() - 1
    assert discovery._is_temporarily_unsupported("coingecko", "fantom") is False


def test_metrics_show_unsupported_as_skip_not_failure():
    line = Scheduler._provider_metrics_line({
        "provider_candidates": {"coingecko": 20},
        "provider_unique_added": {"coingecko": 20},
        "provider_sources_failed": {},
        "provider_unsupported": {"coingecko": ["fantom: não suportada (revalidação ≤5min)"]},
        "discovered": 20,
        "analyzed": 2,
        "approved": 1,
    })
    assert "CoinGecko=20(+20)" in line
    assert "⏭️[fantom: não suportada (revalidação ≤5min)]" in line
    assert "⚠️" not in line


def test_scanner_404_does_not_increment_operational_errors(monkeypatch):
    scanner = ScannerEngine()
    source = SimpleNamespace(
        name="CoinGecko Onchain novos fantom", provider="coingecko", chain="fantom",
        url="https://example.invalid", params={}, headers={}, cache_ttl=30,
        parser=lambda payload: [],
    )
    scanner.active = True
    scanner.phase = "discover"
    scanner._sources = [source]
    scanner._source_index = 0
    scanner._target = 10
    scanner._candidates = []
    scanner._seen = set()
    scanner._allowed = {"fantom"}
    monkeypatch.setattr(scanner, "_provider_request", lambda *a, **k: None)
    monkeypatch.setattr(scanner.providers, "state", lambda name: SimpleNamespace(last_error="NetworkHTTPError: HTTP 404"))
    scanner._discover_step()
    assert scanner.last_stats["errors"] == 0
    assert scanner.last_stats["sources_failed"] == 0
    assert scanner.last_stats["provider_unsupported"]["coingecko"]
    assert scanner.discovery._is_temporarily_unsupported("coingecko", "fantom")
