from phantom_v10.scheduler import Scheduler
from phantom_v10.scanner import ScannerEngine


def test_compact_provider_error_classifies_common_failures():
    assert ScannerEngine._compact_provider_error("TransientNetworkError: Serviço temporariamente indisponível (HTTP 429).") == "HTTP 429"
    assert ScannerEngine._compact_provider_error("TransientNetworkError: Timeout de rede/TLS.") == "timeout"
    assert ScannerEngine._compact_provider_error("TransientNetworkError: Resposta HTTPS não JSON.") == "JSON inválido"
    assert ScannerEngine._compact_provider_error("NetworkHTTPError: HTTP 403 em https://example.invalid/path?secret=x") == "HTTP 403 (acesso/whitelist)"


def test_metrics_line_shows_provider_chain_and_short_cause():
    line = Scheduler._provider_metrics_line({
        "provider_candidates": {"birdeye": 20, "coingecko": 0},
        "provider_unique_added": {"birdeye": 20, "coingecko": 0},
        "provider_sources_failed": {"birdeye": 1, "coingecko": 2},
        "provider_error_details": {
            "birdeye": ["solana: HTTP 429"],
            "coingecko": ["base: timeout", "ethereum: HTTP 403"],
        },
        "discovered": 20, "analyzed": 1, "approved": 0,
    })
    assert "Birdeye=20(+20) ⚠️1[solana: HTTP 429]" in line
    assert "CoinGecko=0(+0) ⚠️2[base: timeout; ethereum: HTTP 403]" in line
    assert "secret" not in line.lower()
