from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import Mock

from csm.storage import Storage
from csm.persistence import SCHEMA_VERSION, database_report
from phantom_v10.payments import PaymentService
from phantom_v10.scheduler import Scheduler


def test_legacy_schema_auto_migrates_paid_user_and_payment(tmp_path):
    db = tmp_path / "legacy.db"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE users (user_id INTEGER PRIMARY KEY, plan TEXT, expires_at TEXT)")
    conn.execute(
        "INSERT INTO users VALUES (?,?,?)",
        (10, "vip", (datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=10)).isoformat()),
    )
    conn.execute(
        "CREATE TABLE payment_orders (payment_id TEXT PRIMARY KEY, user_id INTEGER, plan TEXT, invoice_url TEXT, external_reference TEXT, status TEXT)"
    )
    conn.execute(
        "INSERT INTO payment_orders VALUES (?,?,?,?,?,?)",
        ("pay_10", 10, "vip", "https://example.test/pay", "csm:10:vip", "AWAITING_PAYMENT"),
    )
    conn.commit()
    conn.close()

    storage = Storage(db)
    try:
        user = storage.get_user(10)
        assert user["plan"] == "plus"
        assert [row["user_id"] for row in storage.signal_users("plus")] == [10]
        assert storage.open_payments(user_id=10)[0]["payment_id"] == "pay_10"
        assert "asaas_customer_id" in storage._table_columns("users")
        assert "billing_type" in storage._table_columns("payment_orders")
        assert "activated_at" in storage._table_columns("payment_orders")
    finally:
        storage.close()

    report = database_report(db)
    assert report["integrity"] == "ok"
    assert report["schema_version"] == SCHEMA_VERSION
    assert report["active_subscribers"] == 1


def test_paid_status_survives_restart_until_local_activation(tmp_path):
    storage = Storage(tmp_path / "paid-recovery.db")
    storage.upsert_user(22, "paid", "Paid")
    storage.save_payment(
        payment_id="pay_recover",
        user_id=22,
        plan="premium",
        invoice_url="https://example.test/pay",
        external_reference="csm:22:premium",
        status="RECEIVED",
        billing_type="PIX",
    )
    client = Mock()
    service = PaymentService(storage, client=client)
    try:
        result = service.verify_payment("pay_recover")
        assert result["state"] == "activated"
        assert result["recovered"] is True
        client.payment_status.assert_not_called()
        user = storage.get_user(22)
        assert user["plan"] == "premium"
        assert storage.get_payment("pay_recover")["activated_at"]
        assert storage.open_payments(user_id=22) == []
    finally:
        storage.close()


def test_payment_activation_is_idempotent_and_does_not_extend_twice(tmp_path):
    storage = Storage(tmp_path / "idempotent.db")
    storage.upsert_user(33, "renew", "Renew")
    storage.save_payment(
        payment_id="pay_once",
        user_id=33,
        plan="plus",
        invoice_url="https://example.test/pay",
        external_reference="csm:33:plus",
        status="CONFIRMED",
        billing_type="PIX",
    )
    try:
        assert storage.activate_payment("pay_once", days=30) is True
        first_expiry = storage.get_user(33)["expires_at"]
        assert storage.activate_payment("pay_once", days=30) is False
        assert storage.get_user(33)["expires_at"] == first_expiry
    finally:
        storage.close()


def test_legacy_merge_does_not_leave_existing_user_free(tmp_path):
    current = tmp_path / "current.db"
    legacy = tmp_path / "old.db"

    storage = Storage(current)
    storage.upsert_user(44, "current", "Current")

    conn = sqlite3.connect(legacy)
    conn.execute(
        """CREATE TABLE users (
            user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
            plan TEXT, expires_at TEXT, blocked INTEGER DEFAULT 0,
            asaas_customer_id TEXT DEFAULT ''
        )"""
    )
    conn.execute(
        "INSERT INTO users VALUES (?,?,?,?,?,?,?)",
        (44, "old", "Old", "vip", (datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=20)).isoformat(), 0, "cus_old"),
    )
    conn.commit()
    conn.close()

    try:
        storage._legacy_candidates = lambda: [legacy]
        storage._merge_legacy_databases()
        user = storage.get_user(44)
        assert user["plan"] == "plus"
        assert user["asaas_customer_id"] == "cus_old"
        assert [row["user_id"] for row in storage.signal_users("plus")] == [44]
    finally:
        storage.close()



def test_active_runtime_confirms_remote_payment_and_moves_user_to_paid_group(tmp_path):
    storage = Storage(tmp_path / "remote-confirm.db")
    storage.upsert_user(66, "buyer", "Buyer")
    storage.save_payment(
        payment_id="pay_remote",
        user_id=66,
        plan="plus_annual",
        invoice_url="https://example.test/pay",
        external_reference="csm:66:plus_annual",
        status="PENDING",
        billing_type="PIX",
    )
    client = Mock()
    client.payment_status.return_value = "CONFIRMED"
    service = PaymentService(storage, client=client)
    try:
        result = service.verify_payment("pay_remote")
        assert result["state"] == "activated"
        assert storage.get_user(66)["plan"] == "plus_annual"
        assert [row["user_id"] for row in storage.signal_users("plus")] == [66]
        assert storage.open_payments(user_id=66) == []
    finally:
        storage.close()

def test_scheduler_auto_reconciles_new_subscription(tmp_path, monkeypatch):
    storage = Storage(tmp_path / "scheduler.db")
    storage.upsert_user(55, "new", "New")
    storage.save_payment(
        payment_id="pay_auto",
        user_id=55,
        plan="premium",
        invoice_url="https://example.test/pay",
        external_reference="csm:55:premium",
        status="PENDING",
        billing_type="PIX",
    )

    class DummyScanner:
        active = False
        last_stats = {}
        last_error = ""
        def start(self):
            return False
        def cancel(self, _reason):
            return None

    class DummyTelegram:
        def __init__(self):
            self.sent = []
        def send(self, user_id, text, reply_markup=None):
            self.sent.append((user_id, text))
            return {"message_id": 1}

    class DummyPayments:
        def verify_payment(self, payment_id):
            assert payment_id == "pay_auto"
            storage.update_payment_status(payment_id, "CONFIRMED")
            storage.activate_payment(payment_id, days=30)
            return {"state": "activated", "user_id": 55, "plan": "premium", "payment_id": payment_id}

    class DummyApp:
        def __init__(self):
            self.storage = storage
            self.scanner = DummyScanner()
            self.payments = DummyPayments()
            self.telegram = DummyTelegram()
            self.warnings = []
        def log_warning(self, text):
            self.warnings.append(text)
        def process_cached_position(self, _position):
            return None

    from types import SimpleNamespace
    import phantom_v10.scheduler as scheduler_module
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            auto_signals_enabled=False,
            signal_monitor_enabled=False,
            payment_auto_check=True,
            payment_check_batch=100,
            payment_check_interval=60,
            signal_monitor_interval=60,
        ),
    )

    app = DummyApp()
    scheduler = Scheduler(app)
    scheduler.next_payment_check = 0
    try:
        scheduler.step()
        assert storage.get_user(55)["plan"] == "premium"
        assert storage.open_payments(user_id=55) == []
        assert app.telegram.sent and app.telegram.sent[0][0] == 55
        assert not app.warnings
    finally:
        storage.close()
