from __future__ import annotations

import hashlib
import json
import zipfile

from csm.admin_web import _redact_request_target
from csm.project_leader import ProjectLeader
from phantom_v10.discovery import MultiProviderDiscovery, gecko_rows
from phantom_v10.errors import NetworkHTTPError
from phantom_v10.providers import ProviderGateway
from phantom_v10.scanner import ScannerEngine


def test_network_http_error_redacts_telegram_and_query_secrets():
    error = NetworkHTTPError(
        401,
        {"ok": False},
        "https://api.telegram.org/bot123456:SUPERSECRET/getMe?token=query-secret&x=1",
    )
    rendered = str(error)
    assert "SUPERSECRET" not in rendered
    assert "query-secret" not in rendered
    assert "***REDACTED***" in rendered
    assert error.url == "https://api.telegram.org/bot***REDACTED***/getMe?token=%2A%2A%2AREDACTED%2A%2A%2A&x=1"


def test_admin_request_target_redacts_query_credentials():
    safe = _redact_request_target("/api/status?token=abc123&mode=full")
    assert "abc123" not in safe
    assert "mode=full" in safe
    assert "REDACTED" in safe


def test_provider_404_is_a_neutral_miss_not_a_circuit_breaker_failure():
    gateway = ProviderGateway(max_backoff=300)
    calls = []

    def missing():
        calls.append(1)
        raise NetworkHTTPError(404, {}, "https://example.invalid/token")

    for _ in range(6):
        assert gateway.fetch("GeckoTerminal market", missing, force=True) is None
    state = gateway.state("GeckoTerminal market")
    assert len(calls) == 6
    assert state.misses == 6
    assert state.failures == 0
    assert state.next_retry == 0
    assert state.status in {"AVAILABLE", "ONLINE"}


def test_core_geckoterminal_discovery_is_global_not_solana_only():
    sources = MultiProviderDiscovery._core_sources()
    gecko = [source for source in sources if source.provider == "geckoterminal"]
    assert len(gecko) == 2
    assert all("/networks/solana/" not in source.url for source in gecko)
    assert any(source.url.endswith("/networks/trending_pools") for source in gecko)
    assert any(source.url.endswith("/networks/new_pools") for source in gecko)


def test_gecko_rows_reads_explicit_network_relationship():
    rows = gecko_rows({
        "data": [{
            "id": "pool_without_network_prefix",
            "attributes": {},
            "relationships": {
                "network": {"data": {"id": "bsc"}},
                "base_token": {"data": {"id": "bsc_0xabc"}},
            },
        }]
    })
    assert rows == [("bsc", "0xabc")]


def test_scanner_candidate_rotation_advances_across_partial_slices():
    scanner = ScannerEngine(cycle_budget=10.0, cycle_timeout=30.0)
    scanner._candidates = [
        ("solana", "a"), ("solana", "b"), ("solana", "c"), ("solana", "d")
    ]
    scanner._candidate_rotation = 2
    scanner._rotation_applied = False
    scanner._apply_candidate_rotation()
    assert [address for _, address in scanner._candidates] == ["c", "d", "a", "b"]
    assert scanner.last_stats["candidate_rotation_start"] == 2
    scanner.last_stats["analyzed"] = 2
    scanner._finish(partial=True, note="slice")
    assert scanner.last_stats["next_candidate_rotation"] == 0


def test_scanner_records_filter_rejection_reason(monkeypatch):
    scanner = ScannerEngine()
    market = {
        "liquidity": 0,
        "volume24h": 999999,
        "marketcap": 1000000,
        "change24h": 1,
        "buys24h": 100,
        "sells24h": 50,
    }
    scanner._accept_market(market)
    assert scanner.last_stats["rejected"] == 1
    assert scanner.last_stats["rejection_reasons"]["liquidity_below_min"] == 1


def test_project_leader_does_not_extract_unlisted_zip_members(tmp_path):
    app_dir = tmp_path / "app"
    state_dir = tmp_path / "state"
    app_dir.mkdir()
    payload = b"safe update"
    manifest = {
        "update_id": "security-test",
        "version": "1",
        "files": [{"path": "safe.txt", "sha256": hashlib.sha256(payload).hexdigest()}],
    }
    bundle = tmp_path / "update.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("update-manifest.json", json.dumps(manifest))
        archive.writestr("payload/safe.txt", payload)
        archive.writestr("../../escaped.txt", b"must never be extracted")

    leader = ProjectLeader(base_dir=app_dir, state_dir=state_dir)
    leader.apply_update_bundle(bundle)

    assert (app_dir / "safe.txt").read_bytes() == payload
    assert not (tmp_path / "escaped.txt").exists()



def test_logs_and_backups_live_in_persistent_state():
    from csm.config import settings
    from csm.backup_manager import _default_backup_dir

    assert settings.logs_dir.parent == settings.data_dir
    assert settings.log_file.parent == settings.logs_dir
    assert _default_backup_dir().parent == settings.data_dir



def test_backup_names_use_product_release_not_legacy_core_version():
    from csm.backup_manager import _safe_name
    assert _safe_name().startswith("CryptoSignals_v16.6.0_backup_")
