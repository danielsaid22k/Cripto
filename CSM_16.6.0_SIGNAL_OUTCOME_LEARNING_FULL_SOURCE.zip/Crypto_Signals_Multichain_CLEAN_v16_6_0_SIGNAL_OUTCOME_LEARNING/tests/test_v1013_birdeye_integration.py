from __future__ import annotations

from csm.config import settings
from phantom_v10.discovery import MultiProviderDiscovery, birdeye_new_listing_params
from phantom_v10.errors import NetworkHTTPError
from phantom_v10.provider_diagnostics import check_birdeye
from phantom_v10.scanner import ScannerEngine
from phantom_v10.transport import HttpResult


class FakeTransport:
    def __init__(self, outcomes):
        self.outcomes = list(outcomes)
        self.calls = []

    def clone(self, **kwargs):
        return self

    def request_json(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


def test_birdeye_params_do_not_send_solana_only_filter_to_evm():
    assert birdeye_new_listing_params("ethereum") == {"limit": 20}
    assert birdeye_new_listing_params("bsc") == {"limit": 20}
    assert birdeye_new_listing_params("base") == {"limit": 20}
    assert birdeye_new_listing_params("solana") == {"limit": 20}


def test_birdeye_check_distinguishes_invalid_key(monkeypatch):
    old = settings.birdeye_api_key
    object.__setattr__(settings, "birdeye_api_key", "x" * 32)
    try:
        fake = FakeTransport([
            NetworkHTTPError(401, {"success": False, "message": "Unauthorized"}, "https://public-api.birdeye.so/defi/networks")
        ])
        report = check_birdeye(transport=fake)
        assert report["key_present"] is True
        assert report["auth_ok"] is False
        assert report["status"] == 401
        assert "inválida" in report["message"]
        assert len(fake.calls) == 1
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)


def test_birdeye_check_validates_auth_then_new_listing(monkeypatch):
    old = settings.birdeye_api_key
    object.__setattr__(settings, "birdeye_api_key", "y" * 32)
    try:
        fake = FakeTransport([
            HttpResult({"success": True, "data": ["solana", "ethereum"]}, 200, 1.0, "https://public-api.birdeye.so/defi/networks"),
            HttpResult({"success": True, "data": {"items": [{"address": "SoL1"}]}}, 200, 1.0, "https://public-api.birdeye.so/defi/v2/tokens/new_listing"),
        ])
        report = check_birdeye(transport=fake)
        assert report["auth_ok"] is True
        assert report["listing_ok"] is True
        assert report["items"] == 1
        assert report["networks"] == ["solana", "ethereum"]
        assert len(fake.calls) == 2
        assert fake.calls[1][2]["params"] == {"limit": 1}
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)


def test_birdeye_auth_pause_skips_paid_source_without_breaking_core(monkeypatch):
    old_key = settings.birdeye_api_key
    old_plus = settings.multi_provider_plus_chain_sources
    object.__setattr__(settings, "birdeye_api_key", "z" * 32)
    object.__setattr__(settings, "multi_provider_plus_chain_sources", 1)
    try:
        discovery = MultiProviderDiscovery()
        before = discovery.sources("plus", ["solana", "ethereum"])
        assert any(src.provider == "birdeye" for src in before)
        assert any(src.provider == "dexscreener" for src in before)
        discovery.pause_provider("birdeye", reason="HTTP 401 (chave ausente/inválida)", ttl_seconds=300)
        after = discovery.sources("plus", ["solana", "ethereum"])
        # V16.5.9 may schedule exactly one diagnostic credential probe when a
        # key fingerprint is new, but no normal Birdeye discovery route runs.
        assert not any(src.provider == "birdeye" and not getattr(src, "probe_only", False) for src in after)
        assert any(src.provider == "dexscreener" for src in after)
        assert "birdeye" in discovery.last_paused_providers
    finally:
        object.__setattr__(settings, "birdeye_api_key", old_key)
        object.__setattr__(settings, "multi_provider_plus_chain_sources", old_plus)


def test_scanner_compacts_auth_errors_with_actionable_reason():
    assert ScannerEngine._compact_provider_error("NetworkHTTPError: HTTP 401 em https://example") == "HTTP 401 (chave ausente/inválida)"
    assert ScannerEngine._compact_provider_error("NetworkHTTPError: HTTP 403 em https://example") == "HTTP 403 (acesso/whitelist)"


def test_provider_gateway_does_not_hide_401_with_stale_cache():
    import time
    from phantom_v10.providers import ProviderGateway

    gateway = ProviderGateway()
    gateway.cache["birdeye:test"] = (time.time() - 40, {"old": True})

    def fail():
        raise NetworkHTTPError(401, {"message": "Unauthorized"}, "https://public-api.birdeye.so/defi/networks")

    result = gateway.fetch(
        "Birdeye novos solana",
        fail,
        cache_key="birdeye:test",
        cache_ttl=30,
        stale_ttl=900,
    )
    assert result is None
    state = gateway.state("Birdeye novos solana")
    assert state.status == "OFFLINE"
    assert state.next_retry > time.time()


def test_scheduler_metrics_show_paused_birdeye_even_without_request_counts():
    from phantom_v10.scheduler import Scheduler
    line = Scheduler._provider_metrics_line({
        "provider_paused": {"birdeye": "HTTP 401 (chave ausente/inválida) • revalidação ≤5min"},
        "discovered": 10,
        "analyzed": 2,
        "approved": 1,
    })
    assert "Birdeye=0(+0)" in line
    assert "HTTP 401" in line
    assert "🔐" in line


def test_birdeye_check_continues_after_coverage_400_when_listing_works():
    old = settings.birdeye_api_key
    object.__setattr__(settings, "birdeye_api_key", "n" * 32)
    try:
        fake = FakeTransport([
            NetworkHTTPError(400, {"success": False, "message": "coverage contract"}, "https://public-api.birdeye.so/defi/networks"),
            HttpResult({"success": True, "data": {"items": []}}, 200, 1.0, "https://public-api.birdeye.so/defi/v2/tokens/new_listing"),
        ])
        report = check_birdeye(transport=fake)
        assert report["auth_status"] == 400
        assert report["auth_ok"] is True
        assert report["listing_ok"] is True
        assert report["listing_status"] == 200
        assert "coverage contract" in report["auth_server_detail"]
        assert len(fake.calls) == 2
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)


def test_birdeye_check_exposes_safe_400_server_detail_without_secret():
    old = settings.birdeye_api_key
    secret = "s" * 32
    object.__setattr__(settings, "birdeye_api_key", secret)
    try:
        fake = FakeTransport([
            NetworkHTTPError(400, {"message": "Bad request", "api_key": secret}, "https://public-api.birdeye.so/defi/networks"),
            NetworkHTTPError(400, {"message": "Unsupported argument", "detail": secret}, "https://public-api.birdeye.so/defi/v2/tokens/new_listing"),
        ])
        report = check_birdeye(transport=fake)
        assert report["listing_ok"] is False
        combined = str(report)
        assert secret not in combined
        assert "Unsupported argument" in combined
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)
