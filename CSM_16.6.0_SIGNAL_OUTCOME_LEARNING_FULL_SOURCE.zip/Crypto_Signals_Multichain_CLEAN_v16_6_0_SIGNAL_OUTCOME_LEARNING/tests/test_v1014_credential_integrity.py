from __future__ import annotations

import json
import zipfile
from pathlib import Path

from csm.credential_audit import (
    audit_birdeye_credentials,
    read_credential_marker,
    recovery_secret_allowed,
    secret_fingerprint,
    update_credential_marker,
)


def _env(path: Path, key: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"BIRDEYE_API_KEY={key}\n", encoding="utf-8")


def test_birdeye_audit_identifies_active_and_historical_without_exposing_value(tmp_path):
    parent = tmp_path / "Documents"
    base = parent / "Crypto_Signals_Multichain_CLEAN_v10_1_4_TEST"
    state = parent / "Crypto_Signals_Multichain_State"
    base.mkdir(parents=True)
    state.mkdir(parents=True)
    active = "A" * 32
    old = "B" * 32
    _env(state / "config.env", active)
    _env(base / ".env", active)
    legacy = parent / "Crypto_Signals_Multichain_CLEAN_v10_1_3_OLD"
    _env(legacy / ".env", old)
    backup_dir = state / "backups"
    backup_dir.mkdir()
    with zipfile.ZipFile(backup_dir / "old.zip", "w") as zf:
        zf.writestr("state/config.env", f"BIRDEYE_API_KEY={old}\n")

    report = audit_birdeye_credentials(base_dir=base, state_dir=state, runtime_value=active)
    assert report["active_source"] == str((state / "config.env").resolve())
    assert report["active_fingerprint"] == secret_fingerprint(active)
    assert report["stale_copies"] >= 2
    assert active not in str(report)
    assert old not in str(report)


def test_birdeye_rotation_marker_blocks_old_backup_key(tmp_path):
    state = tmp_path / "state"
    new = "N" * 32
    old = "O" * 32
    update_credential_marker("BIRDEYE_API_KEY", new, state)
    assert recovery_secret_allowed("BIRDEYE_API_KEY", new, state)[0] is True
    allowed, reason = recovery_secret_allowed("BIRDEYE_API_KEY", old, state)
    assert allowed is False
    assert "fingerprint" in reason


def test_birdeye_clear_marker_blocks_any_automatic_restore(tmp_path):
    state = tmp_path / "state"
    update_credential_marker("BIRDEYE_API_KEY", "", state)
    allowed, reason = recovery_secret_allowed("BIRDEYE_API_KEY", "X" * 32, state)
    assert allowed is False
    assert reason == "credential-explicitly-cleared"


def test_setup_write_env_records_exact_birdeye_generation(tmp_path, monkeypatch):
    import csm.setup_wizard as wizard

    state = tmp_path / "State"
    base = tmp_path / "Release"
    base.mkdir()
    example = base / ".env.example"
    example.write_text(
        "ENABLE_TELEGRAM=true\nTELEGRAM_BOT_TOKEN=\nTELEGRAM_CHAT_ID=\nADMIN_USER_IDS=\n"
        "MULTI_PROVIDER_ENABLED=true\nBIRDEYE_API_KEY=\nCOINGECKO_API_KEY=\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(wizard, "STATE_DIR", state)
    monkeypatch.setattr(wizard, "PERSISTENT_ENV_FILE", state / "config.env")
    monkeypatch.setattr(wizard, "ENV_FILE", base / ".env")
    monkeypatch.setattr(wizard, "EXAMPLE_FILE", example)
    key = "K" * 32
    values = {
        "ENABLE_TELEGRAM": "true",
        "TELEGRAM_BOT_TOKEN": "123456789:" + "A" * 30,
        "TELEGRAM_CHAT_ID": "123456789",
        "ADMIN_USER_IDS": "123456789",
        "MULTI_PROVIDER_ENABLED": "true",
        "BIRDEYE_API_KEY": key,
        "COINGECKO_API_KEY": "",
    }
    wizard.write_env(values)
    persistent = (state / "config.env").read_text(encoding="utf-8")
    local = (base / ".env").read_text(encoding="utf-8")
    assert persistent == local
    assert f"BIRDEYE_API_KEY={key}" in persistent
    marker = read_credential_marker(state)
    entry = marker["credentials"]["BIRDEYE_API_KEY"]
    assert entry["state"] == "set"
    assert entry["fingerprint"] == secret_fingerprint(key)
    assert key not in json.dumps(marker)
