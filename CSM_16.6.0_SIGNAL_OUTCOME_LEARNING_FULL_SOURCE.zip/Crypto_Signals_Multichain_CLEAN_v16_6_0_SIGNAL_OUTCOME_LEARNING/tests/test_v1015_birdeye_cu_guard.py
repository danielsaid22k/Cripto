from __future__ import annotations

import time

from csm.config import settings
from phantom_v10.errors import NetworkHTTPError
from phantom_v10.provider_diagnostics import check_birdeye
from phantom_v10.providers import ProviderGateway
from phantom_v10.scanner import ScannerEngine


class FakeTransport:
    def __init__(self, outcomes):
        self.outcomes = list(outcomes)
        self.calls = []

    def clone(self, **kwargs):
        return self

    def request_json(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


def _quota_error(url: str = "https://public-api.birdeye.so/defi/networks") -> NetworkHTTPError:
    return NetworkHTTPError(
        400,
        {"success": False, "message": "Compute units usage limit exceeded"},
        url,
    )


def test_birdeye_quota_is_not_misclassified_as_invalid_key_and_avoids_second_probe():
    old = settings.birdeye_api_key
    object.__setattr__(settings, "birdeye_api_key", "q" * 32)
    try:
        fake = FakeTransport([_quota_error()])
        report = check_birdeye(check_listing=True, transport=fake)
        assert report["quota_exhausted"] is True
        assert report["credential_ok"] is True
        assert report["failure_kind"] == "quota_exhausted"
        assert report["auth_status"] == 400
        assert report["listing_ok"] is False
        assert report["listing_status"] is None
        assert "Compute Units" in report["message"]
        assert len(fake.calls) == 1
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)


def test_provider_gateway_marks_compute_unit_exhaustion_without_stale_cache():
    gateway = ProviderGateway(max_backoff=300)
    gateway.cache["birdeye:test"] = (time.time() - 40, {"old": True})

    result = gateway.fetch(
        "Birdeye novos solana",
        lambda: (_ for _ in ()).throw(_quota_error()),
        cache_key="birdeye:test",
        cache_ttl=30,
        stale_ttl=900,
    )
    assert result is None
    state = gateway.state("Birdeye novos solana")
    assert state.status == "QUOTA_EXHAUSTED"
    assert "Compute Units usage limit exceeded" in state.last_error
    assert state.next_retry > time.time()


def test_scanner_compacts_compute_unit_quota_before_generic_http_400():
    raw = "NetworkHTTPError: HTTP 400 (Compute Units usage limit exceeded)"
    assert ScannerEngine._compact_provider_error(raw) == "CU esgotada"
