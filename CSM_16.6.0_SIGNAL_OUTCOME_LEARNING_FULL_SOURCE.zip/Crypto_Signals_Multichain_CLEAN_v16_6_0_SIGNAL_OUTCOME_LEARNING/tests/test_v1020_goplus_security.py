from __future__ import annotations

from csm.config import settings
from csm.logging_setup import redact
from phantom_v10.goplus_security import (
    evaluate_evm,
    evaluate_solana,
    extract_result,
    request_spec,
)
from phantom_v10.presentation import signal_card
from phantom_v10.scanner import ScannerEngine


EVM = "0x1111111111111111111111111111111111111111"
SOL = "So11111111111111111111111111111111111111112"


def _market(chain="ethereum", address=EVM):
    return {
        "chain": chain,
        "address": address,
        "symbol": "SAFE",
        "name": "Safe Test",
        "price": 0.001,
        "liquidity": 100000,
        "volume24h": 300000,
        "marketcap": 1000000,
        "fdv": 1000000,
        "change24h": 10,
        "buys24h": 200,
        "sells24h": 100,
        "age_days": 2,
        "source": "test",
    }


def _safe_evm_row():
    return {
        "is_open_source": "1",
        "is_proxy": "0",
        "is_mintable": "0",
        "can_take_back_ownership": "0",
        "owner_change_balance": "0",
        "hidden_owner": "0",
        "selfdestruct": "0",
        "is_honeypot": "0",
        "cannot_buy": "0",
        "cannot_sell_all": "0",
        "transfer_pausable": "0",
        "is_blacklisted": "0",
        "is_whitelisted": "0",
        "slippage_modifiable": "0",
        "personal_slippage_modifiable": "0",
        "anti_whale_modifiable": "0",
        "trading_cooldown": "0",
        "buy_tax": "0.01",
        "sell_tax": "0.02",
        "holders": [
            {"percent": "0.08", "tag": ""},
            {"percent": "0.07", "tag": ""},
        ],
    }


def test_goplus_request_specs_cover_active_networks_and_keep_token_in_header():
    url, params, headers = request_spec("base", EVM, "secret-token")
    assert url.endswith("/token_security/8453")
    assert params == {"contract_addresses": EVM}
    assert headers == {"Authorization": "Bearer secret-token"}
    assert "secret-token" not in url

    url, params, _ = request_spec("solana", SOL, "")
    assert url.endswith("/solana/token_security")
    assert params["contract_addresses"] == SOL


def test_goplus_extract_result_is_case_insensitive_and_single_row_safe():
    payload = {"code": 1, "result": {EVM.upper(): {"is_honeypot": "0"}}}
    assert extract_result(payload, EVM)["is_honeypot"] == "0"
    assert extract_result({"result": {"other": {"x": 1}}}, EVM) == {"x": 1}


def test_goplus_evm_honeypot_is_hard_blocked():
    row = _safe_evm_row()
    row["is_honeypot"] = "1"
    verdict = evaluate_evm(row)
    assert verdict["goplus_blocked"] is True
    assert verdict["goplus_risk_level"] == "CRÍTICO"
    assert "honeypot" in verdict["goplus_block_reason"]


def test_goplus_evm_safe_row_reports_taxes_and_high_score():
    verdict = evaluate_evm(_safe_evm_row())
    assert verdict["goplus_blocked"] is False
    assert verdict["goplus_score"] >= 85
    assert verdict["goplus_buy_tax_pct"] == 1.0
    assert verdict["goplus_sell_tax_pct"] == 2.0
    assert verdict["goplus_top10_holders_pct"] == 15.0


def test_goplus_solana_balance_mutable_is_hard_blocked():
    row = {
        "default_account_state": "1",
        "non_transferable": "0",
        "balance_mutable_authority": {"status": "1"},
        "holders": [],
    }
    verdict = evaluate_solana(row)
    assert verdict["goplus_blocked"] is True
    assert "saldo" in verdict["goplus_block_reason"]


def test_goplus_solana_fee_is_parsed_from_basis_points():
    row = {
        "default_account_state": "1",
        "non_transferable": "0",
        "balance_mutable_authority": {"status": "0"},
        "transfer_fee": {"current_fee_rate": {"fee_rate": "200"}},
        "holders": [],
    }
    verdict = evaluate_solana(row)
    assert verdict["goplus_blocked"] is False
    assert verdict["goplus_sell_tax_pct"] == 2.0



def test_goplus_evm_transfer_tax_above_limit_is_blocked():
    row = _safe_evm_row()
    row["transfer_tax"] = "0.30"
    verdict = evaluate_evm(row, max_sell_tax_pct=25)
    assert verdict["goplus_blocked"] is True
    assert verdict["goplus_transfer_tax_pct"] == 30.0
    assert "transfer tax" in verdict["goplus_block_reason"]


def test_goplus_solana_scheduled_fee_above_limit_is_blocked():
    row = {
        "default_account_state": "1",
        "non_transferable": "0",
        "balance_mutable_authority": {"status": "0"},
        "transfer_fee": {
            "current_fee_rate": {"fee_rate": "100"},
            "scheduled_fee_rate": {"fee_rate": "3000"},
        },
        "holders": [],
    }
    verdict = evaluate_solana(row, max_transfer_fee_pct=25)
    assert verdict["goplus_blocked"] is True
    assert verdict["goplus_sell_tax_pct"] == 1.0
    assert verdict["goplus_scheduled_transfer_fee_pct"] == 30.0
    assert "agendada" in verdict["goplus_block_reason"]

def test_scanner_runs_security_as_separate_cooperative_step(monkeypatch):
    old_enabled = settings.goplus_enabled
    old_min_score = settings.goplus_min_security_score
    object.__setattr__(settings, "goplus_enabled", True)
    object.__setattr__(settings, "goplus_min_security_score", 55)
    try:
        scanner = ScannerEngine(cycle_budget=20, cycle_timeout=30)
        scanner._current_candidate = ("ethereum", EVM)
        scanner._market_stage = "gecko"
        scanner._accept_market(_market())
        assert scanner._market_stage == "goplus"
        assert scanner.results == []

        monkeypatch.setattr(scanner, "_provider_request", lambda *a, **k: {"code": 1, "result": {EVM: _safe_evm_row()}})
        scanner._goplus_step("ethereum", EVM)
        assert len(scanner.results) == 1
        item = scanner.results[0]
        assert item["goplus_checked"] is True
        assert item["goplus_score"] >= 85
        assert item["final_score"] <= item["market_opportunity_score"]
        assert scanner.last_stats["security_verified"] == 1
    finally:
        object.__setattr__(settings, "goplus_enabled", old_enabled)
        object.__setattr__(settings, "goplus_min_security_score", old_min_score)


def test_scanner_blocks_critical_goplus_verdict(monkeypatch):
    old_enabled = settings.goplus_enabled
    object.__setattr__(settings, "goplus_enabled", True)
    try:
        scanner = ScannerEngine(cycle_budget=20, cycle_timeout=30)
        scanner._current_candidate = ("ethereum", EVM)
        scanner._accept_market(_market())
        row = _safe_evm_row()
        row["owner_change_balance"] = "1"
        monkeypatch.setattr(scanner, "_provider_request", lambda *a, **k: {"result": {EVM: row}})
        scanner._goplus_step("ethereum", EVM)
        assert scanner.results == []
        assert scanner.last_stats["security_blocked"] == 1
        assert scanner.last_stats["rejection_reasons"]["goplus_critical_risk"] == 1
    finally:
        object.__setattr__(settings, "goplus_enabled", old_enabled)


def test_premium_signal_card_exposes_security_without_secret():
    old_enabled = settings.goplus_enabled
    object.__setattr__(settings, "goplus_enabled", True)
    try:
        item = _market()
        item.update({
            "score": 85,
            "opportunity_score": 88,
            "final_score": 84,
            "goplus_checked": True,
            "goplus_status": "verified",
            "goplus_score": 72,
            "goplus_risk_level": "MODERADO",
            "goplus_buy_tax_pct": 1.0,
            "goplus_sell_tax_pct": 2.0,
            "goplus_top10_holders_pct": 30.0,
            "goplus_risks": ["função de mint ativa"],
        })
        text = signal_card(item, "premium")
        assert "GoPlus Security" in text
        assert "72/100" in text
        assert "função de mint ativa" in text
        assert "84/100" in text
    finally:
        object.__setattr__(settings, "goplus_enabled", old_enabled)


def test_logging_redacts_goplus_access_token():
    old_token = settings.goplus_access_token
    object.__setattr__(settings, "goplus_access_token", "goplus-super-secret")
    try:
        text = redact("GOPLUS_ACCESS_TOKEN=goplus-super-secret Authorization goplus-super-secret")
        assert "goplus-super-secret" not in text
    finally:
        object.__setattr__(settings, "goplus_access_token", old_token)
