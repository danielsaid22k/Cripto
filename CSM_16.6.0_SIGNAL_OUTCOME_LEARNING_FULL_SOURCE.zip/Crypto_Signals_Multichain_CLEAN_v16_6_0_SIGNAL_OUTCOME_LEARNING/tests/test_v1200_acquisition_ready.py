from __future__ import annotations

import json
import os
import sqlite3
import time
import zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pytest

from csm.acquisition import acquisition_readiness, generate_sale_pack
from csm.branding import load_branding, save_branding
from csm.performance import HistoricalConfidenceModel, PerformanceLedger
from csm.saas import SaaSManager
from csm.storage import Storage
from phantom_v10 import __version__


def sample_signal(**extra):
    base = {
        "chain": "solana",
        "address": "So11111111111111111111111111111111111111112",
        "symbol": "SAMPLE",
        "name": "Sample Token",
        "price": 1.0,
        "score": 88,
        "opportunity_score": 90,
        "final_score": 86,
        "goplus_score": 94,
        "goplus_risk_level": "LOW",
        "goplus_buy_tax_pct": 0.0,
        "goplus_sell_tax_pct": 0.0,
        "liquidity": 250000,
        "volume24h": 800000,
        "marketcap": 2_000_000,
        "change24h": 12.5,
        "buys24h": 120,
        "sells24h": 70,
        "source": "DexScreener",
        "approval_reasons": ["liquidez relevante", "pressão compradora"],
    }
    base.update(extra)
    return base


def test_v12_version():
    assert __version__ == "16.6.0-retool-admin-speechify"


def test_fresh_heartbeat_is_recovered_immediately_when_owner_pid_is_dead(tmp_path, monkeypatch):
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(runtime, "STATE_DIR", tmp_path)
    guard = runtime.RuntimeGuard("bot", stale_after=60)
    payload = {
        "pid": 999999,
        "session": "dead-session",
        "heartbeat_at": time.time(),
        "state": "running",
    }
    guard.lock_file.write_text(json.dumps(payload), encoding="utf-8")
    guard.session_file.write_text(json.dumps(payload), encoding="utf-8")
    monkeypatch.setattr(runtime.RuntimeGuard, "_pid_alive", staticmethod(lambda data: False))

    event = guard.acquire()

    assert event.recovered is True
    assert event.reason == "processo_ausente"
    guard.release()


def test_performance_ledger_is_append_only_and_merges_multi_user_delivery(tmp_path):
    storage = Storage(tmp_path / "perf.db")
    try:
        ledger = PerformanceLedger(storage)
        # Keep the fixture deterministically inside one 5-minute proof bucket.
        # Using wall-clock ``now`` made this test randomly cross a bucket boundary
        # during the last seconds of minutes 4/9/14/... and create a legitimate
        # second event instead of testing the intended multi-plan merge.
        now = datetime.now(timezone.utc).replace(minute=1, second=0, microsecond=0)
        signal_id = ledger.record_signal(sample_signal(), "premium", now=now)
        same_id = ledger.record_signal(sample_signal(), "plus", now=now + timedelta(seconds=10))
        assert signal_id == same_id
        row = storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (signal_id,)).fetchone()
        assert row["delivered_count"] == 2
        assert set(row["plan_groups"].split(",")) == {"premium", "plus"}

        assert ledger.record_observation(signal_id, {"price": 1.30, "liquidity": 260000, "volume24h": 900000, "marketcap": 2200000, "source": "DexScreener"}, captured_at=now + timedelta(minutes=5))
        assert ledger.record_observation(signal_id, {"price": 0.85, "liquidity": 220000, "volume24h": 700000, "marketcap": 1800000, "source": "DexScreener"}, captured_at=now + timedelta(minutes=15))
        report = ledger.report(days=1)
        assert report["signals_total"] == 1
        assert report["signals_observed"] == 1
        assert report["tp1_hit_rate_pct"] == 100.0
        assert report["stop_touch_rate_pct"] == 100.0
        assert report["horizons"]["5m"]["samples"] == 1
        assert report["by_provider"]["DexScreener"]["signals"] == 1
        assert report["by_score_band"]["80-89"]["signals"] == 1
    finally:
        storage.close()


def test_historical_confidence_requires_minimum_evidence(tmp_path):
    storage = Storage(tmp_path / "confidence.db")
    try:
        ledger = PerformanceLedger(storage)
        model = HistoricalConfidenceModel(storage, min_samples=5)
        assert model.estimate(sample_signal()).available is False
        now = datetime.now(timezone.utc) - timedelta(hours=1)
        for idx in range(5):
            item = sample_signal(address=f"SoSample{idx:02d}")
            sid = ledger.record_signal(item, "premium", now=now + timedelta(minutes=idx * 5))
            ledger.record_observation(sid, {"price": 1.30 if idx < 3 else 0.95, "source": "DexScreener"}, captured_at=now + timedelta(minutes=idx * 5 + 20))
        estimate = model.estimate(sample_signal())
        assert estimate.available is True
        assert estimate.samples >= 5
        assert 0 <= estimate.score <= 100
    finally:
        storage.close()


def test_saas_keys_are_hashed_and_rate_limited(tmp_path):
    storage = Storage(tmp_path / "saas.db")
    try:
        manager = SaaSManager(storage)
        manager.create_tenant("Buyer Demo", "buyer-demo")
        created = manager.create_api_key("buyer-demo", rpm=1, daily=5)
        raw = created["api_key"]
        row = storage.conn.execute("SELECT * FROM saas_api_keys").fetchone()
        assert raw not in tuple(str(value) for value in row)
        assert len(row["key_hash"]) == 64
        assert manager.authenticate(raw) is not None
        with pytest.raises(RuntimeError, match="rate_limit_rpm"):
            manager.authenticate(raw)
        assert manager.authenticate("wrong-key", consume=False) is None
    finally:
        storage.close()


def test_branding_is_persisted_without_source_edit(tmp_path, monkeypatch):
    import csm.branding as branding

    target = tmp_path / "branding.json"
    saved = save_branding({"product_name": "White Label Alpha", "logo_emoji": "🚀"}, target)
    assert saved["product_name"] == "White Label Alpha"
    loaded = load_branding(target)
    assert loaded["logo_emoji"] == "🚀"
    assert json.loads(target.read_text())["product_name"] == "White Label Alpha"


def test_sale_pack_excludes_database_and_secrets(tmp_path):
    storage = Storage(tmp_path / "sale.db")
    try:
        ledger = PerformanceLedger(storage)
        ledger.record_signal(sample_signal(), "premium")
        target = generate_sale_pack(storage, tmp_path / "room.zip")
        assert target.exists()
        with zipfile.ZipFile(target) as zf:
            names = zf.namelist()
            assert any(name.endswith("ACQUISITION_READINESS.json") for name in names)
            assert any(name.endswith("PERFORMANCE_REPORT.json") for name in names)
            assert any(name.endswith("DEMO_SYNTHETIC.json") for name in names)
            assert not any(name.endswith(".db") for name in names)
            assert not any(name.endswith("config.env") for name in names)
            demo_name = next(name for name in names if name.endswith("DEMO_SYNTHETIC.json"))
            demo = json.loads(zf.read(demo_name))
            assert demo["synthetic"] is True
    finally:
        storage.close()




def test_strategy_compare_uses_same_observed_ledger(tmp_path):
    storage = Storage(tmp_path / "compare.db")
    try:
        ledger = PerformanceLedger(storage)
        now = datetime.now(timezone.utc) - timedelta(hours=1)
        for idx, score in enumerate((72, 82, 92)):
            sid = ledger.record_signal(sample_signal(address=f"SoCompare{idx}", final_score=score, goplus_score=90), "premium", now=now + timedelta(minutes=idx))
            ledger.record_observation(sid, {"price": 1.20 if idx else 0.90, "source": "DexScreener"}, captured_at=now + timedelta(minutes=idx + 20))
        result = ledger.compare_strategies(
            days=1,
            strategy_a={"min_score": 0, "min_goplus": 0, "max_sell_tax": 100},
            strategy_b={"min_score": 80, "min_goplus": 80, "max_sell_tax": 10},
        )
        assert result["strategy_a"]["signals"] == 3
        assert result["strategy_b"]["signals"] == 2
        assert result["dataset"] == "signal_ledger_observed_only"
    finally:
        storage.close()


def test_admin_dashboard_contains_signals_security_analytics_and_system_sections():
    from csm.admin_web import _page
    html = _page({
        "release": "12", "product_release": "12", "lts_base": "6.3.0", "environment": "test",
        "plans": {}, "scanner": {}, "performance": {"signals_observed": 0, "win_rate_pct": 0, "tp1_hit_rate_pct": 0, "by_chain": {}},
        "ledger_signals": [], "renewals_next_30_days": [], "operational_alerts": [],
    }).decode("utf-8")
    for title in ("Signals • Performance Ledger", "Security • GoPlus snapshots", "Analytics • Resultado por rede", "System • Saúde operacional"):
        assert title in html

def test_readiness_does_not_overclaim_without_observed_performance(tmp_path):
    storage = Storage(tmp_path / "readiness.db")
    try:
        report = acquisition_readiness(storage)
        assert report["performance"]["signals_observed"] == 0
        assert report["rating"] != "ACQUISITION READY"
        assert "EVIDENCE" in report["rating"] or report["score"] < 80
    finally:
        storage.close()

def test_deployment_assets_present():
    for name in ("Dockerfile", "docker-compose.yml", "deployment/csm.service", "deployment/csm-api.service"):
        assert Path(name).exists(), name


def test_v1202_responsive_lease_blocks_a_second_live_runtime(tmp_path, monkeypatch):
    import threading
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(runtime, "STATE_DIR", tmp_path)
    first = runtime.RuntimeGuard("bot", stale_after=60)
    first.acquire()
    stop = threading.Event()

    def responder():
        while not stop.is_set():
            first.service_lease()
            time.sleep(0.01)

    worker = threading.Thread(target=responder, daemon=True)
    worker.start()
    try:
        payload = runtime.RuntimeGuard._read_json(first.lock_file)
        assert payload["lease"]["kind"] == "udp-challenge-v2"
        assert int(payload["lease"]["protocol"]) == 2
        assert int(payload["lease"]["port"]) > 0
        assert runtime.RuntimeGuard._lease_status(payload) is True
        assert runtime.RuntimeGuard._lease_challenge(payload, timeout=0.5) is True

        second = runtime.RuntimeGuard("bot", stale_after=60)
        with pytest.raises(runtime.AlreadyRunningError, match="lease responsiva"):
            second.acquire()
    finally:
        stop.set()
        worker.join(timeout=1)
        first.release(state="stopped")


def test_v1202_leaked_socket_cannot_fake_live_python(tmp_path, monkeypatch):
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(runtime, "STATE_DIR", tmp_path)
    first = runtime.RuntimeGuard("bot", stale_after=60)
    first.acquire()
    old = runtime.RuntimeGuard._read_json(first.lock_file)
    # Simulate the real a-Shell native-crash mode: the host keeps the UDP file
    # descriptor busy, but no Python loop remains to answer a nonce. Keep the
    # heartbeat recent enough for the old 60s guard, but older than the short
    # active-I/O grace window so recovery is immediate.
    old["heartbeat_at"] = time.time() - 19
    first._atomic_write(first.lock_file, old)
    first._atomic_write(first.session_file, old)
    assert runtime.RuntimeGuard._lease_status(old) is True
    assert runtime.RuntimeGuard._lease_challenge(old, timeout=0.05) is False

    second = runtime.RuntimeGuard("bot", stale_after=60)
    event = second.acquire()
    try:
        assert event.recovered is True
        assert event.reason == "lease_sem_resposta"
        current = runtime.RuntimeGuard._read_json(second.lock_file)
        assert current["session"] == second.session
        assert current["liveness_authority"].startswith("udp-challenge-v2")
    finally:
        second.release(state="stopped")
        first.release(state="stopped")


def test_v1202_migrates_stuck_v1201_bind_only_lease_after_short_window(tmp_path, monkeypatch):
    import socket
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(runtime, "STATE_DIR", tmp_path)
    leaked = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    leaked.bind(("127.0.0.1", 0))
    port = leaked.getsockname()[1]
    payload = {
        "pid": 12345,
        "session": "legacy-v1201",
        "heartbeat_at": time.time() - 19,
        "state": "running",
        "lease": {"kind": "udp-loopback", "host": "127.0.0.1", "port": port},
    }
    guard = runtime.RuntimeGuard("bot", stale_after=60)
    guard.lock_file.write_text(json.dumps(payload), encoding="utf-8")
    guard.session_file.write_text(json.dumps(payload), encoding="utf-8")
    monkeypatch.setattr(runtime.RuntimeGuard, "_pid_alive", staticmethod(lambda data: True))
    try:
        event = guard.acquire()
        assert event.recovered is True
        assert event.reason == "lease_legada_sem_resposta"
    finally:
        guard.release(state="stopped")
        leaked.close()


def test_v1202_runtime_status_reports_lease_liveness(tmp_path, monkeypatch):
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(runtime, "STATE_DIR", tmp_path)
    guard = runtime.RuntimeGuard("bot", stale_after=60)
    guard.acquire()
    try:
        status = runtime.runtime_state("bot", stale_after=60)
        assert status["healthy"] is True
        assert status["lease_alive"] is True
        assert int(status["lease_port"]) > 0
        assert status["liveness_authority"].startswith("udp-challenge-v2")
    finally:
        guard.release(state="stopped")


def test_v1202_ashell_ctrl_c_is_cooperative_and_tls_sigint_is_masked():
    app_source = Path("phantom_v10/app.py").read_text(encoding="utf-8")
    runtime_source = Path("phantom_v10/runtime.py").read_text(encoding="utf-8")
    transport_source = Path("phantom_v10/transport.py").read_text(encoding="utf-8")
    assert "signal.signal(signal.SIGINT, _cooperative_sigint)" in app_source
    assert 'request_shutdown("Ctrl+C/SIGINT")' in app_source
    assert "CSM_PING" in runtime_source and "CSM_PONG" in runtime_source
    assert "pthread_sigmask" in transport_source
    assert "SIG_BLOCK" in transport_source and "SIG_SETMASK" in transport_source


def test_v1202_transport_masks_sigint_until_after_tls_cleanup(monkeypatch):
    import phantom_v10.transport as transport_mod

    calls = []
    previous = {"previous-mask"}

    def fake_pthread_sigmask(how, mask):
        calls.append((how, mask))
        return previous

    monkeypatch.setattr(transport_mod.signal, "pthread_sigmask", fake_pthread_sigmask, raising=False)
    bus = transport_mod.NetworkBus()

    class Response:
        status = 200
        def read(self, _limit=None): return b'{"ok":true}'
        def close(self): calls.append(("response-close", None))

    class Connection:
        def request(self, *args, **kwargs): pass
        def getresponse(self): return Response()
        def close(self): calls.append(("connection-close", None))

    t = transport_mod.StdlibHttpTransport(
        bus=bus,
        connection_factory=lambda host, port, timeout: Connection(),
    )
    result = t.request_json("GET", "https://example.test/x")
    assert result.status == 200
    assert calls[0][0] == transport_mod.signal.SIG_BLOCK
    assert ("response-close", None) in calls
    assert ("connection-close", None) in calls
    assert calls[-1][0] == transport_mod.signal.SIG_SETMASK
    assert bus.busy is False
