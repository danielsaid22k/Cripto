from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from csm.acquisition import acquisition_readiness, generate_sale_pack
from csm.performance import PerformanceLedger
from csm.proof import ProofLedger, ZERO_HASH, merkle_root
from csm.storage import Storage
from phantom_v10 import __version__
from phantom_v10.presentation import signal_card


def sample_signal(**extra):
    base = {
        "chain": "solana",
        "address": "So11111111111111111111111111111111111111112",
        "symbol": "PROOF",
        "name": "Proof Sample",
        "price": 1.0,
        "score": 88,
        "opportunity_score": 90,
        "final_score": 86,
        "goplus_score": 94,
        "goplus_risk_level": "LOW",
        "goplus_buy_tax_pct": 0.0,
        "goplus_sell_tax_pct": 0.0,
        "goplus_top10_holders_pct": 20.0,
        "liquidity": 250000,
        "volume24h": 800000,
        "marketcap": 2_000_000,
        "change24h": 12.5,
        "buys24h": 120,
        "sells24h": 70,
        "source": "DexScreener",
        "approval_reasons": ["liquidez relevante", "pressão compradora"],
        "discovery_providers": ["DexScreener", "Birdeye"],
    }
    base.update(extra)
    return base


def test_v13_version_and_schema(tmp_path):
    assert __version__ == "16.6.0-retool-admin-speechify"
    storage = Storage(tmp_path / "v13.db")
    try:
        assert storage.conn.execute("PRAGMA user_version").fetchone()[0] >= 630
        tables = {row[0] for row in storage.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"proof_events", "proof_daily_roots", "proof_anchors"} <= tables
    finally:
        storage.close()


def test_live_proof_is_prepared_before_delivery_and_same_hash_is_persisted(tmp_path):
    storage = Storage(tmp_path / "live.db")
    try:
        ledger = PerformanceLedger(storage)
        now = datetime.now(timezone.utc)
        item = sample_signal()
        preview = ledger.prepare_signal_proof(item, now=now)
        assert preview is not None
        assert preview.commit_mode == "live_commit"
        rendered = signal_card({**item, **preview.public_fields()}, "premium")
        assert preview.proof_id in rendered
        assert preview.event_hash[:20] in rendered
        sid = ledger.record_signal(item, "premium", now=now, proof_preview=preview)
        row = storage.conn.execute("SELECT * FROM proof_events WHERE signal_id=? AND event_type='signal'", (sid,)).fetchone()
        assert row["event_hash"] == preview.event_hash
        assert row["commit_mode"] == "live_commit"
        assert ProofLedger(storage).verify_signal(sid)["ok"] is True
    finally:
        storage.close()


def test_proof_tables_are_append_only(tmp_path):
    storage = Storage(tmp_path / "immutable.db")
    try:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(sample_signal(), "premium")
        event_id = storage.conn.execute("SELECT id FROM proof_events WHERE signal_id=?", (sid,)).fetchone()[0]
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("UPDATE proof_events SET proof_id='tampered' WHERE id=?", (event_id,))
        storage.conn.rollback()
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("DELETE FROM proof_events WHERE id=?", (event_id,))
        storage.conn.rollback()
    finally:
        storage.close()


def test_source_tampering_is_detected(tmp_path):
    storage = Storage(tmp_path / "tamper.db")
    try:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(sample_signal(), "premium")
        assert ProofLedger(storage).verify_signal(sid)["ok"] is True
        storage.conn.execute("UPDATE signal_ledger SET entry_price=9.99 WHERE id=?", (sid,))
        storage.conn.commit()
        result = ProofLedger(storage).verify_signal(sid)
        assert result["ok"] is False
        assert "signal_source_mismatch" in result["errors"]
    finally:
        storage.close()


def test_observations_form_hash_chain_and_daily_root(tmp_path):
    storage = Storage(tmp_path / "chain.db")
    try:
        ledger = PerformanceLedger(storage)
        now = datetime.now(timezone.utc) - timedelta(days=2)
        item = sample_signal(address="SoProofChain")
        preview = ledger.prepare_signal_proof(item, now=now)
        sid = ledger.record_signal(item, "premium", now=now, proof_preview=preview)
        ledger.record_observation(sid, {"price": 1.25, "source": "DexScreener"}, captured_at=now + timedelta(minutes=5))
        ledger.record_observation(sid, {"price": 1.50, "source": "DexScreener"}, captured_at=now + timedelta(minutes=15))
        events = [dict(row) for row in storage.conn.execute("SELECT * FROM proof_events WHERE signal_id=? ORDER BY id", (sid,)).fetchall()]
        assert len(events) == 3
        assert events[0]["previous_hash"] == ZERO_HASH
        assert events[1]["previous_hash"] == events[0]["event_hash"]
        assert events[2]["previous_hash"] == events[1]["event_hash"]
        proof = ProofLedger(storage)
        assert proof.verify_signal(sid)["ok"] is True
        day = events[0]["committed_at"][:10]
        root = proof.seal_root(day)
        expected = merkle_root([row["event_hash"] for row in storage.conn.execute(
            "SELECT event_hash FROM proof_events WHERE substr(committed_at,1,10)=? ORDER BY id", (day,)
        ).fetchall()])
        assert root["root_hash"] == expected
        assert proof.verify_roots()["ok"] is True
    finally:
        storage.close()


def test_legacy_backfill_is_never_claimed_as_live_commit(tmp_path):
    storage = Storage(tmp_path / "legacy.db")
    try:
        # Insert a historical ledger row directly, simulating a V12 record that
        # existed before Proof of Performance was introduced.
        storage.conn.execute(
            """INSERT INTO signal_ledger(event_key,chain,address,symbol,name,entry_price,final_score,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            ("legacy-event", "solana", "Legacy111", "LEG", "Legacy", 1.0, 80,
             (datetime.now(timezone.utc)-timedelta(days=1)).isoformat(),
             (datetime.now(timezone.utc)-timedelta(days=1)).isoformat()),
        )
        storage.conn.commit()
        result = ProofLedger(storage).backfill_legacy(days=30)
        assert result["signals_backfilled"] == 1
        row = storage.conn.execute("SELECT commit_mode FROM proof_events WHERE event_type='signal'").fetchone()
        assert row["commit_mode"] == "legacy_backfill"
        status = ProofLedger(storage).status()
        assert status["live_commits"] == 0
        assert status["legacy_backfills"] == 1
    finally:
        storage.close()


def test_export_bundle_has_dependency_free_verifier_and_no_secrets(tmp_path):
    storage = Storage(tmp_path / "export.db")
    try:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(sample_signal(), "premium")
        ledger.record_observation(sid, {"price": 1.1, "source": "DexScreener"})
        target = ProofLedger(storage).export_bundle(days=30, output=tmp_path / "proof.zip")
        with zipfile.ZipFile(target) as zf:
            names = set(zf.namelist())
            assert "CSM_PROOF_BUNDLE/proofs.json" in names
            assert "CSM_PROOF_BUNDLE/verify_proofs.py" in names
            assert not any(name.endswith(".db") or name.endswith("config.env") for name in names)
            zf.extractall(tmp_path / "unpacked")
        bundle = tmp_path / "unpacked" / "CSM_PROOF_BUNDLE"
        proc = subprocess.run([sys.executable, str(bundle / "verify_proofs.py"), str(bundle / "proofs.json")], capture_output=True, text=True)
        assert proc.returncode == 0, proc.stdout + proc.stderr
        assert "CSM Proof Verification: OK" in proc.stdout
    finally:
        storage.close()


def test_sale_pack_and_readiness_include_v13_proof_evidence(tmp_path):
    storage = Storage(tmp_path / "sale.db")
    try:
        ledger = PerformanceLedger(storage)
        ledger.record_signal(sample_signal(), "premium")
        readiness = acquisition_readiness(storage)
        assert "proof_of_performance" in readiness
        assert "proof_of_performance" in readiness["components"]
        target = generate_sale_pack(storage, tmp_path / "room.zip")
        with zipfile.ZipFile(target) as zf:
            names = set(zf.namelist())
            assert any(name.endswith("PROOF_STATUS.json") for name in names)
            assert any(name.endswith("PROOF_PUBLIC.json") for name in names)
    finally:
        storage.close()


def test_anchor_registration_requires_sealed_root_and_is_immutable(tmp_path):
    storage = Storage(tmp_path / "anchor.db")
    try:
        ledger = PerformanceLedger(storage)
        now = datetime.now(timezone.utc) - timedelta(days=1)
        item = sample_signal(address="Anchor111")
        preview = ledger.prepare_signal_proof(item, now=now)
        ledger.record_signal(item, "premium", now=now, proof_preview=preview)
        proof = ProofLedger(storage)
        day = now.date().isoformat()
        proof.seal_root(day)
        anchor = proof.register_anchor(day, chain="solana", txid="ABCDEF1234567890", url="https://example.invalid/tx")
        assert anchor["root_hash"] == proof.current_root(day)["root_hash"]
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("UPDATE proof_anchors SET txid='changed' WHERE id=?", (anchor["id"],))
        storage.conn.rollback()
    finally:
        storage.close()
