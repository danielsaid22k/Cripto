from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
import sqlite3
import zipfile

import pytest

import csm.onchain as onchain_module
import phantom_v10.onchain_monitor as monitor_module
from csm.acquisition import acquisition_readiness, generate_sale_pack
from csm.config import settings as real_settings
from csm.onchain import OnChainLedger
from csm.performance import PerformanceLedger
from csm.storage import Storage
from phantom_v10.errors import sanitize_url
from phantom_v10.onchain_monitor import OnChainMonitor


def sample_signal(**extra):
    base = {
        "chain": "solana",
        "address": "So11111111111111111111111111111111111111112",
        "symbol": "CHAIN",
        "name": "OnChain Sample",
        "price": 100.0,
        "score": 90,
        "opportunity_score": 91,
        "final_score": 88,
        "goplus_score": 95,
        "goplus_risk_level": "LOW",
        "goplus_buy_tax_pct": 0.0,
        "goplus_sell_tax_pct": 0.0,
        "liquidity": 200000.0,
        "volume24h": 500000.0,
        "marketcap": 2_000_000.0,
        "source": "DexScreener",
        "approval_reasons": ["sample"],
    }
    base.update(extra)
    return base


class FakeTransport:
    def __init__(self, responses):
        self.responses = list(responses)
        self.requests = []

    def clone(self, **kwargs):
        return self

    def request_json(self, method, url, **kwargs):
        self.requests.append({"method": method, "url": url, **kwargs})
        if not self.responses:
            raise AssertionError("unexpected network request")
        return SimpleNamespace(payload=self.responses.pop(0), status=200)


def _settings(**kwargs):
    return replace(
        real_settings,
        onchain_enabled=True,
        onchain_whale_min_usd=10_000.0,
        onchain_snapshot_bucket_seconds=60,
        onchain_solana_top_accounts=3,
        onchain_solana_tx_per_poll=4,
        **kwargs,
    )


def _advance_snapshot_time(monkeypatch, ledger):
    original = ledger.record_snapshot
    current = datetime(2026, 8, 17, 0, 0, tzinfo=timezone.utc)

    def record(signal, metrics, **kwargs):
        nonlocal current
        result = original(signal, metrics, captured_at=current)
        current += timedelta(minutes=2)
        return result

    monkeypatch.setattr(ledger, "record_snapshot", record)


def test_v135_schema_is_additive_and_events_are_append_only(tmp_path):
    storage = Storage(tmp_path / "onchain.db")
    try:
        assert storage.conn.execute("PRAGMA user_version").fetchone()[0] >= 660
        tables = {r[0] for r in storage.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"onchain_snapshots", "onchain_events", "onchain_cursors", "wallet_profiles"} <= tables
        sid = PerformanceLedger(storage).record_signal(sample_signal(), "premium")
        signal = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        ledger = OnChainLedger(storage)
        assert ledger.record_event(signal, event_type="whale_transfer", txid="tx-1", amount_usd=25_000)
        event_id = storage.conn.execute("SELECT id FROM onchain_events").fetchone()[0]
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("UPDATE onchain_events SET severity='CRITICAL' WHERE id=?", (event_id,))
        storage.conn.rollback()
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("DELETE FROM onchain_events WHERE id=?", (event_id,))
        storage.conn.rollback()
    finally:
        storage.close()


def test_mobile_onchain_runtime_contains_no_webhook_thread_or_subprocess_contract():
    source = Path("phantom_v10/onchain_monitor.py").read_text(encoding="utf-8").lower()
    assert "import threading" not in source
    assert "import subprocess" not in source
    assert "import websocket" not in source and "from websocket" not in source
    assert "serve_forever" not in source
    env = Path(".env.example").read_text(encoding="utf-8").upper()
    assert "ONCHAIN_ENABLED" in env
    assert "HELIUS_API_KEY" in env
    assert "ONCHAIN_WEBHOOK" not in env


def test_provider_credentials_are_redacted_from_helius_and_hosted_evm_urls():
    assert "secret-helius" not in sanitize_url("https://mainnet.helius-rpc.com/?api-key=secret-helius")
    assert "secret-alchemy" not in sanitize_url("https://eth-mainnet.g.alchemy.com/v2/secret-alchemy")
    assert "secret-infura" not in sanitize_url("https://mainnet.infura.io/v3/secret-infura")


def test_solana_polling_tracks_holder_concentration_then_whale_transfer(tmp_path, monkeypatch):
    mint = "Mint111111111111111111111111111111111111111"
    top = ["TopTokenAcct1", "TopTokenAcct2", "TopTokenAcct3"]
    supply = {"jsonrpc": "2.0", "id": "supply", "result": {"value": {"uiAmountString": "1000"}}}
    largest = {"jsonrpc": "2.0", "id": "largest", "result": {"value": [
        {"address": top[0], "uiAmountString": "300"},
        {"address": top[1], "uiAmountString": "200"},
        {"address": top[2], "uiAmountString": "100"},
    ]}}
    baseline = [
        {"jsonrpc": "2.0", "id": "acct:0", "result": [{"signature": "sig-base-1"}]},
        {"jsonrpc": "2.0", "id": "acct:1", "result": [{"signature": "sig-base-2"}]},
        {"jsonrpc": "2.0", "id": "acct:2", "result": [{"signature": "sig-base-3"}]},
    ]
    discovered = [
        {"jsonrpc": "2.0", "id": "acct:0", "result": [{"signature": "sig-whale"}, {"signature": "sig-base-1"}]},
        {"jsonrpc": "2.0", "id": "acct:1", "result": [{"signature": "sig-base-2"}]},
        {"jsonrpc": "2.0", "id": "acct:2", "result": [{"signature": "sig-base-3"}]},
    ]
    tx_result = {
        "jsonrpc": "2.0", "id": "tx:0", "result": {
            "slot": 12345, "blockTime": 1770000000,
            "meta": {
                "preTokenBalances": [
                    {"mint": mint, "owner": "WhaleSender", "uiTokenAmount": {"uiAmountString": "400"}},
                    {"mint": mint, "owner": "WhaleReceiver", "uiTokenAmount": {"uiAmountString": "50"}},
                ],
                "postTokenBalances": [
                    {"mint": mint, "owner": "WhaleSender", "uiTokenAmount": {"uiAmountString": "200"}},
                    {"mint": mint, "owner": "WhaleReceiver", "uiTokenAmount": {"uiAmountString": "250"}},
                ],
            },
        },
    }
    responses = [
        [supply, largest],
        [supply, largest, *baseline],
        [supply, largest, *discovered],
        [supply, largest, *discovered, tx_result],
    ]
    fake_settings = _settings(helius_api_key="test-key", helius_secure_rpc_url="")
    monkeypatch.setattr(monitor_module, "settings", fake_settings)
    monkeypatch.setattr(onchain_module, "settings", fake_settings)

    storage = Storage(tmp_path / "solana.db")
    try:
        sid = PerformanceLedger(storage).record_signal(sample_signal(address=mint), "premium")
        signal = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        transport = FakeTransport(responses)
        monitor = OnChainMonitor(storage, transport)
        _advance_snapshot_time(monkeypatch, monitor.ledger)
        for _ in range(4):
            assert monitor.observe_one(signal) is not None
        latest = monitor.ledger.latest_snapshot(sid)
        assert latest["top10_holders_pct"] == pytest.approx(60.0)
        assert latest["whale_transfer_count"] == 1
        assert latest["whale_volume_usd"] == pytest.approx(20_000.0)
        whale = storage.conn.execute("SELECT * FROM onchain_events WHERE event_type='whale_transfer'").fetchone()
        assert whale is not None
        assert whale["wallet_address"] == "WhaleSender"
        assert len(transport.requests) == 4
        assert all(req["method"] == "POST" for req in transport.requests)
        assert max(len(req["json_data"]) for req in transport.requests) <= 10
    finally:
        storage.close()


def test_evm_polling_baselines_then_detects_deployer_outflow_and_whale(tmp_path, monkeypatch):
    token = "0x" + "1" * 40
    deployer = "0x" + "2" * 40
    receiver = "0x" + "3" * 40
    topic_addr = lambda addr: "0x" + "0" * 24 + addr[2:]
    first = [
        {"jsonrpc": "2.0", "id": "block", "result": "0x64"},
        {"jsonrpc": "2.0", "id": "decimals", "result": "0x12"},
    ]
    amount_raw = 200 * 10**18
    second = [
        {"jsonrpc": "2.0", "id": "block", "result": "0x66"},
        {"jsonrpc": "2.0", "id": "logs", "result": [{
            "topics": [monitor_module.TRANSFER_TOPIC, topic_addr(deployer), topic_addr(receiver)],
            "data": hex(amount_raw), "transactionHash": "0xabc", "logIndex": "0x1", "blockNumber": "0x65",
        }]},
    ]
    fake_settings = _settings(evm_rpc_base="https://rpc.example", onchain_evm_rebase_after_seconds=3600)
    monkeypatch.setattr(monitor_module, "settings", fake_settings)
    monkeypatch.setattr(onchain_module, "settings", fake_settings)
    storage = Storage(tmp_path / "evm.db")
    try:
        sid = PerformanceLedger(storage).record_signal(sample_signal(
            chain="base", address=token, goplus_creator_address=deployer, price=100.0
        ), "premium")
        signal = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        transport = FakeTransport([first, second])
        monitor = OnChainMonitor(storage, transport)
        _advance_snapshot_time(monkeypatch, monitor.ledger)
        monitor.observe_one(signal)
        latest = monitor.observe_one(signal)
        assert latest["transfer_count"] == 1
        assert latest["whale_transfer_count"] == 1
        assert latest["risk_level"] in {"MODERATE", "HIGH", "CRITICAL"}
        event = storage.conn.execute("SELECT * FROM onchain_events WHERE event_type='deployer_outflow'").fetchone()
        assert event is not None
        assert event["severity"] == "HIGH"
        assert len(transport.requests) == 2
    finally:
        storage.close()


def test_liquidity_deterioration_reduces_onchain_score_without_touching_final_score(tmp_path):
    storage = Storage(tmp_path / "score.db")
    try:
        perf = PerformanceLedger(storage)
        sid = perf.record_signal(sample_signal(price=1.0, liquidity=200_000), "premium")
        perf.record_observation(sid, {"price": 0.9, "liquidity": 80_000, "source": "DexScreener"})
        signal = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        original_final = signal["final_score"]
        scored = OnChainLedger(storage).score_snapshot(signal, {"source": "test"})
        assert scored["liquidity_change_pct"] == pytest.approx(-60.0)
        assert scored["onchain_score"] <= 55
        after = storage.conn.execute("SELECT final_score FROM signal_ledger WHERE id=?", (sid,)).fetchone()[0]
        assert after == original_final
    finally:
        storage.close()


def test_dashboard_api_and_buyer_data_room_include_onchain_evidence(tmp_path):
    from csm.admin_web import _page

    rendered = _page({
        "release": "13.5", "product_release": "13.5", "lts_base": "6.3.0", "environment": "test",
        "plans": {}, "scanner": {}, "proof": {},
        "performance": {"signals_observed": 0, "win_rate_pct": 0, "tp1_hit_rate_pct": 0, "by_chain": {}},
        "onchain": {"summary": {"signals_monitored": 1, "average_onchain_score": 90}, "latest": []},
        "ledger_signals": [], "renewals_next_30_days": [], "operational_alerts": [],
    }).decode("utf-8")
    assert "On-Chain Intelligence • Pós-sinal" in rendered
    assert "/api/onchain" in rendered

    storage = Storage(tmp_path / "sale.db")
    try:
        sid = PerformanceLedger(storage).record_signal(sample_signal(), "premium")
        signal = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        OnChainLedger(storage).record_snapshot(signal, {"source": "test", "top10_holders_pct": 20})
        readiness = acquisition_readiness(storage)
        assert readiness["components"]["onchain_evidence"] > 0
        assert readiness["onchain_intelligence"]["signals_monitored"] == 1
        target = generate_sale_pack(storage, tmp_path / "room.zip")
        with zipfile.ZipFile(target) as zf:
            names = set(zf.namelist())
            assert any(name.endswith("ONCHAIN_STATUS.json") for name in names)
            assert any(name.endswith("ONCHAIN_REPORT.json") for name in names)
    finally:
        storage.close()
