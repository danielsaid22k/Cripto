from __future__ import annotations

import json
import sqlite3
import zipfile
from pathlib import Path

import pytest

from csm import __product_version__
from csm.acquisition import acquisition_readiness, generate_sale_pack
from csm.performance import PerformanceLedger
from csm.reputation import ReputationEngine
from csm.storage import Storage
from phantom_v10.presentation import market_report


def sample_signal(**overrides):
    item = {
        "chain": "base",
        "address": "0x" + "1" * 40,
        "symbol": "REP",
        "name": "Reputation Test",
        "price": 1.0,
        "score": 88,
        "opportunity_score": 88,
        "final_score": 84,
        "goplus_score": 90,
        "goplus_risk_level": "LOW",
        "goplus_creator_address": "0x" + "2" * 40,
        "liquidity": 100_000,
        "volume24h": 250_000,
        "marketcap": 1_000_000,
        "change24h": 12.0,
        "buys24h": 120,
        "sells24h": 80,
        "source": "test",
        "target1_pct": 25,
        "target2_pct": 50,
        "stop_pct": 12,
    }
    item.update(overrides)
    return item


def test_v14_product_version_and_additive_schema(tmp_path):
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    storage = Storage(tmp_path / "rep.db")
    try:
        assert storage.conn.execute("PRAGMA user_version").fetchone()[0] >= 660
        tables = {r[0] for r in storage.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"wallet_reputation_evidence", "wallet_reputation_state", "wallet_reputation_snapshots"} <= tables
    finally:
        storage.close()


def test_reputation_evidence_is_append_only_and_deduplicated(tmp_path):
    storage = Storage(tmp_path / "rep.db")
    try:
        engine = ReputationEngine(storage)
        address = "0x" + "2" * 40
        assert engine.add_evidence("base", address, evidence_type="deployer_outflow", source="test", source_ref="1", role="deployer", weight=-18, severity="HIGH")
        assert not engine.add_evidence("base", address, evidence_type="deployer_outflow", source="test", source_ref="1", role="deployer", weight=-18, severity="HIGH")
        row_id = storage.conn.execute("SELECT id FROM wallet_reputation_evidence").fetchone()[0]
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("UPDATE wallet_reputation_evidence SET weight=0 WHERE id=?", (row_id,))
        storage.conn.rollback()
        with pytest.raises(sqlite3.DatabaseError, match="append-only"):
            storage.conn.execute("DELETE FROM wallet_reputation_evidence WHERE id=?", (row_id,))
        storage.conn.rollback()
    finally:
        storage.close()


def test_reputation_builds_from_onchain_and_real_signal_outcomes(tmp_path):
    storage = Storage(tmp_path / "rep.db")
    try:
        perf = PerformanceLedger(storage)
        sid = perf.record_signal(sample_signal(), "premium")
        signal = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        # Directly populate append-only on-chain facts to simulate V13.5 history.
        storage.conn.execute(
            """INSERT INTO onchain_events(signal_id,chain,address,event_key,event_type,severity,wallet_address,counterparty,txid,block_ref,amount_token,amount_usd,details_json,occurred_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
            (sid, "base", signal["address"], "ev1", "deployer_outflow", "HIGH", signal["goplus_creator_address"], "", "tx1", "1", 1000, 20000, "{}"),
        )
        storage.conn.execute("UPDATE signal_ledger SET first_stop_at=CURRENT_TIMESTAMP,max_drawdown_pct=-55,observations=2 WHERE id=?", (sid,))
        storage.conn.commit()

        engine = ReputationEngine(storage)
        result = engine.refresh(days=3650, limit=1000, snapshot=True)
        assert result["onchain_evidence_added"] >= 1
        assert result["outcome_evidence_added"] >= 2
        profile = engine.profile("base", signal["goplus_creator_address"])
        assert profile is not None
        assert profile["role"] == "deployer"
        assert profile["evidence_count"] >= 3
        assert profile["reputation_score"] < 50
        assert profile["negative_evidence"] >= 3
        assert profile["linked_signals"] == 1
    finally:
        storage.close()


def test_reputation_never_inflates_or_changes_final_score(tmp_path):
    storage = Storage(tmp_path / "rep.db")
    try:
        engine = ReputationEngine(storage)
        deployer = "0x" + "2" * 40
        # Enough negative evidence to cross confidence threshold.
        for i in range(8):
            assert engine.add_evidence("base", deployer, evidence_type="deployer_outflow", source="test", source_ref=str(i), role="deployer", weight=-8, severity="HIGH")
        engine.materialize("base", deployer)
        item = sample_signal(csm_confidence_score=84)
        original_final = item["final_score"]
        engine.enrich_candidate(item, min_confidence=30, max_penalty=20)
        assert item["final_score"] == original_final
        assert item["csm_confidence_score"] < 84
        assert item["deployer_reputation_penalty"] > 0

        # Strong positive evidence may describe the deployer but must not inflate confidence.
        good = "0x" + "3" * 40
        for i in range(12):
            engine.add_evidence("base", good, evidence_type="signal_tp2", source="test", source_ref=str(i), role="deployer", weight=4, severity="POSITIVE")
        engine.materialize("base", good)
        item2 = sample_signal(goplus_creator_address=good, csm_confidence_score=84)
        engine.enrich_candidate(item2, min_confidence=30, max_penalty=20)
        assert item2["final_score"] == original_final
        assert item2["csm_confidence_score"] == 84
        assert item2["deployer_reputation_penalty"] == 0
    finally:
        storage.close()


def test_premium_message_explains_deployer_reputation_without_claiming_safety():
    item = sample_signal(
        deployer_reputation_score=24,
        deployer_reputation_confidence=71,
        deployer_reputation_rating="CAUTION",
        deployer_reputation_evidence=10,
        deployer_reputation_signals=4,
        deployer_reputation_penalty=8,
        deployer_reputation_factors=[{"type": "deployer_outflow", "weight": -18}],
    )
    text, _ = market_report(item, "premium")
    assert "REPUTAÇÃO DO DEPLOYER" in text
    assert "24/100" in text
    assert "confiança" in text
    assert "não substitui" in text.lower()


def test_acquisition_and_data_room_include_reputation_evidence(tmp_path, monkeypatch):
    # Keep readiness source inventory pointed to the real source tree while DB is isolated.
    storage = Storage(tmp_path / "rep.db")
    try:
        engine = ReputationEngine(storage)
        deployer = "0x" + "2" * 40
        engine.add_evidence("base", deployer, evidence_type="deployer_outflow", source="test", source_ref="risk", role="deployer", weight=-18, severity="HIGH")
        engine.materialize("base", deployer)
        readiness = acquisition_readiness(storage)
        assert "wallet_deployer_reputation" in readiness
        assert "reputation_evidence" in readiness["components"]
        target = generate_sale_pack(storage, tmp_path / "room.zip")
        with zipfile.ZipFile(target) as zf:
            names = set(zf.namelist())
            assert any(name.endswith("WALLET_REPUTATION_STATUS.json") for name in names)
            assert any(name.endswith("WALLET_REPUTATION_REPORT.json") for name in names)
    finally:
        storage.close()


def test_reputation_module_has_no_network_or_background_runtime_contract():
    source = Path("csm/reputation.py").read_text(encoding="utf-8").lower()
    for forbidden in ("requests", "urllib", "http.client", "threading", "subprocess", "websocket"):
        assert f"import {forbidden}" not in source
