from __future__ import annotations

import json
import sqlite3
import zipfile
from pathlib import Path

from csm import __product_version__
from csm.acquisition import acquisition_readiness, generate_sale_pack
from csm.observability import ObservabilityEngine
from csm.storage import Storage


def test_v145_product_version_and_additive_schema(tmp_path):
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    storage = Storage(tmp_path / "ops.db")
    try:
        assert storage.conn.execute("PRAGMA user_version").fetchone()[0] >= 660
        tables = {r[0] for r in storage.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"ops_metrics", "ops_incidents", "ops_state"} <= tables
    finally:
        storage.close()


def test_capture_scanner_cycle_records_low_cardinality_metrics_and_incidents(tmp_path):
    storage = Storage(tmp_path / "ops.db")
    try:
        engine = ObservabilityEngine(storage)
        engine.capture_scanner_cycle(
            {
                "discovered": 100,
                "analyzed": 7,
                "approved": 2,
                "rejected": 5,
                "errors": 0,
                "active_seconds": 12.3,
                "suspensions": 0,
                "aborted": 0,
                "partial": 1,
            },
            delivery_summaries=[("premium", {"sent": 2, "errors": 0})],
            provider_rows=[
                {"name": "DexScreener", "status": "ONLINE", "success_rate": 100, "latency_ms": 120, "failures": 0},
                {"name": "Birdeye", "status": "QUOTA_EXHAUSTED", "success_rate": 40, "latency_ms": 3100, "failures": 3, "last_error": "HTTP 400 compute units quota"},
            ],
            network_snapshot={"busy": False, "age_seconds": 0, "busy_rejections": 0},
        )
        status = engine.status(days=7)
        assert status["metrics"] > 0
        assert status["open_incidents"] == 1
        assert status["raw_open_incidents"] >= status["open_incidents"]
        assert status["health_score"] < 100
        names = {r[0] for r in storage.conn.execute("SELECT DISTINCT metric_name FROM ops_metrics")}
        assert {"discovered", "active_seconds", "latency_ms", "signals_sent"} <= names
    finally:
        storage.close()


def test_incident_recovers_when_provider_recovers(tmp_path):
    storage = Storage(tmp_path / "ops.db")
    try:
        engine = ObservabilityEngine(storage)
        stats = {"discovered": 1, "analyzed": 1, "approved": 1, "rejected": 0, "errors": 0, "active_seconds": 1, "suspensions": 0, "aborted": 0, "partial": 0}
        engine.capture_scanner_cycle(stats, provider_rows=[{"name": "GoPlus security", "status": "OFFLINE", "success_rate": 0, "latency_ms": 4000, "failures": 5, "last_error": "HTTP 503"}])
        assert any(r["status"] == "OPEN" for r in engine.incidents())
        engine.capture_scanner_cycle(stats, provider_rows=[{"name": "GoPlus security", "status": "ONLINE", "success_rate": 100, "latency_ms": 150, "failures": 0, "last_error": ""}])
        rows = engine.incidents()
        health = [r for r in rows if r["incident_key"].endswith(":health")][0]
        latency = [r for r in rows if r["incident_key"].endswith(":latency")][0]
        assert health["status"] == "RESOLVED"
        assert latency["status"] == "RESOLVED"
    finally:
        storage.close()


def test_observability_redacts_urls_and_secret_like_values(tmp_path):
    storage = Storage(tmp_path / "ops.db")
    try:
        engine = ObservabilityEngine(storage)
        engine.record_loop_error("RuntimeError", "token=SUPERSECRET https://example.test/path?api_key=HELLO")
        row = storage.conn.execute("SELECT details_json FROM ops_incidents ORDER BY id DESC LIMIT 1").fetchone()
        text = str(row[0])
        assert "SUPERSECRET" not in text
        assert "HELLO" not in text
        assert "[redacted]" in text.lower() or "[url]" in text.lower()
    finally:
        storage.close()


def test_prometheus_export_is_local_and_sanitized(tmp_path):
    storage = Storage(tmp_path / "ops.db")
    try:
        engine = ObservabilityEngine(storage)
        engine.record_metric("scanner", "approved", 3, unit="count")
        target = engine.export(tmp_path / "metrics.prom", fmt="prometheus")
        text = target.read_text(encoding="utf-8")
        assert "csm_health_score" in text
        assert "csm_scanner_approved_avg" in text
        assert "http://" not in text and "https://" not in text
    finally:
        storage.close()


def test_acquisition_and_data_room_include_observability(tmp_path):
    storage = Storage(tmp_path / "ops.db")
    try:
        engine = ObservabilityEngine(storage)
        for _ in range(25):
            engine.record_metric("runtime", "heartbeat", 1)
        readiness = acquisition_readiness(storage)
        assert "observability_operations" in readiness
        assert "operational_observability" in readiness["components"]
        target = generate_sale_pack(storage, tmp_path / "room.zip")
        with zipfile.ZipFile(target) as zf:
            names = set(zf.namelist())
            assert any(name.endswith("OBSERVABILITY_STATUS.json") for name in names)
            assert any(name.endswith("OBSERVABILITY_REPORT.json") for name in names)
    finally:
        storage.close()



def test_healthy_heartbeat_resolves_stale_loop_incidents_across_components(tmp_path):
    from datetime import datetime, timedelta, timezone
    from unittest.mock import patch

    storage = Storage(tmp_path / "ops.db")
    try:
        engine = ObservabilityEngine(storage)
        old = datetime.now(timezone.utc) - timedelta(minutes=10)
        with patch("csm.observability._utc_now", return_value=old):
            engine.record_loop_error("RuntimeError", "runtime transient", component="runtime")
            engine.record_loop_error("TelegramAPIError", "telegram transient", component="telegram")
            engine.record_loop_error("NetworkError", "network transient", component="network")
        assert len([r for r in engine.incidents(open_only=True) if ":loop:" in r["incident_key"]]) == 3
        engine.heartbeat(scanner_active=False)
        assert not [r for r in engine.incidents(open_only=True) if ":loop:" in r["incident_key"]]
    finally:
        storage.close()

def test_observability_module_has_no_network_background_or_public_webhook_contract():
    source = Path("csm/observability.py").read_text(encoding="utf-8").lower()
    for forbidden in ("requests", "urllib", "http.client", "threading", "subprocess", "websocket"):
        assert f"import {forbidden}" not in source
    assert "serve_forever" not in source
