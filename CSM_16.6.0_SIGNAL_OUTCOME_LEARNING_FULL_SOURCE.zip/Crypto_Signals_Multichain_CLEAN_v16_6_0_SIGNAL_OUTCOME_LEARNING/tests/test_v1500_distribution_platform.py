from __future__ import annotations

import json
from pathlib import Path

from csm import __product_version__
from csm.distribution import DistributionManager
from csm.storage import Storage


class _Result:
    def __init__(self, status=204):
        self.status = status
        self.payload = {}
        self.elapsed_ms = 5.0
        self.url = "https://example.invalid/hook"


class _Transport:
    def __init__(self):
        self.calls = []
        self.headers = {}
    def clone(self, **kwargs):
        child = _Transport()
        child.calls = self.calls
        child.headers = kwargs.get("headers", {})
        return child
    def request_json(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs, dict(self.headers)))
        return _Result(204)


def test_v15_version_schema_and_tables(tmp_path):
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    storage = Storage(tmp_path / "dist.db")
    try:
        assert storage.conn.execute("PRAGMA user_version").fetchone()[0] == 680
        tables = {r[0] for r in storage.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"distribution_destinations", "distribution_jobs", "distribution_attempts"} <= tables
    finally:
        storage.close()


def test_webhook_target_and_secret_are_not_in_sqlite(tmp_path):
    storage = Storage(tmp_path / "dist.db")
    try:
        manager = DistributionManager(storage, _Transport())
        row = manager.add_destination(
            channel="webhook", name="Enterprise", target="https://example.com/csm/hook",
            plans="premium", events="signal.created",
        )
        raw = (tmp_path / "dist.db").read_bytes()
        assert b"https://example.com/csm/hook" not in raw
        assert row["signing_secret"].encode() not in raw
        assert row["target_hint"] == "example.com"
        secret_file = tmp_path / row["config_ref"]
        assert secret_file.is_file()
        cfg = json.loads(secret_file.read_text())
        assert cfg["target"] == "https://example.com/csm/hook"
        assert cfg["signing_secret"] == row["signing_secret"]
    finally:
        storage.close()


def test_signal_queue_is_idempotent_and_plan_scoped(tmp_path):
    storage = Storage(tmp_path / "dist.db")
    try:
        manager = DistributionManager(storage, _Transport())
        manager.add_destination(channel="webhook", name="Premium", target="https://example.com/hook", plans="premium")
        manager.add_destination(channel="discord", name="Plus", target="https://discord.com/api/webhooks/1/token", plans="plus")
        item = {"chain":"solana","address":"ABC","symbol":"ABC","price":1.0,"final_score":88}
        assert manager.enqueue_signal(item, "premium", {"proof_hash":"deadbeef"}) == 1
        assert manager.enqueue_signal(item, "premium", {"proof_hash":"deadbeef"}) == 0
        rows = manager.jobs(limit=10)
        assert len(rows) == 1
        assert rows[0]["channel"] == "webhook"
    finally:
        storage.close()


def test_webhook_delivery_has_hmac_and_idempotency_headers(tmp_path):
    storage = Storage(tmp_path / "dist.db")
    transport = _Transport()
    try:
        manager = DistributionManager(storage, transport)
        manager.add_destination(channel="webhook", name="Hook", target="https://example.com/hook", plans="premium", signing_secret="shared-secret")
        manager.enqueue_signal({"chain":"base","address":"0xabc","symbol":"T","final_score":90}, "premium", {"proof_hash":"proof123"})
        result = manager.run_one()
        assert result["state"] == "SENT"
        assert transport.calls
        method, url, kwargs, headers = transport.calls[0]
        assert method == "POST"
        assert url == "https://example.com/hook"
        assert headers["X-CSM-Signature"].startswith("v1=")
        assert headers["X-CSM-Delivery"].startswith("evt_")
        assert headers["Idempotency-Key"]
        assert kwargs["json_data"]["proof"]["proof_hash"] == "proof123"
    finally:
        storage.close()


def test_failed_delivery_retries_then_dead_letters(tmp_path):
    class FailTransport(_Transport):
        def clone(self, **kwargs):
            child = FailTransport(); child.calls = self.calls; child.headers = kwargs.get("headers", {}); return child
        def request_json(self, method, url, **kwargs):
            self.calls.append((method,url,kwargs,dict(self.headers)))
            return _Result(500)
    storage = Storage(tmp_path / "dist.db")
    try:
        manager = DistributionManager(storage, FailTransport())
        manager.add_destination(channel="webhook", name="Hook", target="https://example.com/hook", plans="premium")
        manager.enqueue_signal({"chain":"base","address":"0xabc","symbol":"T","final_score":90}, "premium", {})
        # force max attempts to 1 locally by monkeypatching frozen settings object via object.__setattr__
        from csm.config import settings
        old = settings.distribution_max_attempts
        object.__setattr__(settings, "distribution_max_attempts", 1)
        try:
            result = manager.run_one()
            assert result["state"] == "DEAD"
            dead = manager.jobs(limit=10, status="DEAD")
            assert len(dead) == 1
            assert manager.retry_job(dead[0]["id"]) is True
        finally:
            object.__setattr__(settings, "distribution_max_attempts", old)
    finally:
        storage.close()


def test_attempt_log_is_append_only(tmp_path):
    storage = Storage(tmp_path / "dist.db")
    try:
        manager = DistributionManager(storage, _Transport())
        manager.add_destination(channel="webhook", name="Hook", target="https://example.com/hook", plans="premium")
        manager.enqueue_signal({"chain":"base","address":"0xabc","symbol":"T","final_score":90}, "premium", {})
        manager.run_one()
        row = storage.conn.execute("SELECT id FROM distribution_attempts LIMIT 1").fetchone()
        assert row
        import sqlite3
        try:
            storage.conn.execute("DELETE FROM distribution_attempts WHERE id=?", (row[0],))
        except sqlite3.DatabaseError:
            pass
        else:
            raise AssertionError("append-only trigger did not block delete")
    finally:
        storage.close()
