from __future__ import annotations

import json
import sqlite3
import threading
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from csm import __product_version__
from csm.customer_portal import portal_page
from csm.distribution import DistributionManager
from csm.entitlements import EntitlementManager
from csm.observability import ObservabilityEngine
from csm.onchain import OnChainLedger
from csm.performance import PerformanceLedger
from csm.proof import ProofLedger
from csm.reputation import ReputationEngine
from csm.saas import SaaSManager
from csm.saas_api import SaaSAPIHandler
from csm.storage import Storage


def test_v16_schema_and_new_tenant_entitlement(tmp_path):
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    storage = Storage(tmp_path / "v16.db")
    try:
        assert storage.conn.execute("PRAGMA user_version").fetchone()[0] == 680
        saas = SaaSManager(storage)
        tenant = saas.create_tenant("Free Customer", "free-customer")
        assert tenant["entitlement_plan"] == "free"
        effective = EntitlementManager(storage).effective("free-customer")
        assert effective["active"] is True
        assert "signals" in effective["features"]
        assert "performance" not in effective["features"]
    finally:
        storage.close()


def test_existing_tenant_default_is_backward_compatible_enterprise(tmp_path):
    storage = Storage(tmp_path / "compat.db")
    try:
        # Omitting V16 entitlement columns mimics a tenant that existed before
        # V16. SQLite applies the migration default, preserving prior API access.
        storage.conn.execute(
            "INSERT INTO saas_tenants(slug,name,brand_name) VALUES(?,?,?)",
            ("legacy-tenant", "Legacy", "Legacy"),
        )
        storage.conn.commit()
        ent = EntitlementManager(storage).effective("legacy-tenant")
        assert ent["plan"] == "enterprise"
        assert "enterprise" in ent["features"]
        assert "distribution" in ent["features"]
    finally:
        storage.close()


def test_entitlement_link_syncs_from_local_user_plan(tmp_path):
    storage = Storage(tmp_path / "sync.db")
    try:
        storage.set_plan(12345, "premium", 30)
        SaaSManager(storage).create_tenant("Customer", "customer", plan="free")
        manager = EntitlementManager(storage)
        manager.link_user("customer", 12345)
        changed = manager.sync_from_users("customer")
        assert len(changed) == 1
        effective = manager.effective("customer")
        assert effective["plan"] == "premium"
        assert effective["linked_user_id"] == 12345
        assert "onchain" in effective["features"]
    finally:
        storage.close()


def test_entitlement_event_history_is_append_only(tmp_path):
    storage = Storage(tmp_path / "append.db")
    try:
        SaaSManager(storage).create_tenant("Customer", "customer")
        manager = EntitlementManager(storage)
        manager.set_entitlement("customer", plan="plus", source="test")
        row = storage.conn.execute("SELECT id FROM entitlement_events LIMIT 1").fetchone()
        assert row
        with pytest.raises(sqlite3.DatabaseError):
            storage.conn.execute("DELETE FROM entitlement_events WHERE id=?", (row[0],))
    finally:
        storage.close()


def test_portal_page_keeps_api_key_out_of_url_and_persistent_storage():
    page = portal_page("CSM Test", __product_version__).decode("utf-8")
    assert "sessionStorage" in page
    assert "localStorage" not in page
    assert "Authorization" in page
    assert "Bearer " in page
    assert "?token=" not in page



def test_linked_entitlement_auto_syncs_when_plan_changes(tmp_path):
    storage = Storage(tmp_path / "auto-sync.db")
    try:
        storage.upsert_user(777, "user", "User")
        SaaSManager(storage).create_tenant("Auto", "auto", plan="free", user_id=777)
        storage.set_plan(777, "plus", 30)
        effective = EntitlementManager(storage).effective("auto")
        assert effective["plan"] == "plus"
        assert "performance" in effective["features"]
    finally:
        storage.close()

def _server(storage: Storage):
    server = ThreadingHTTPServer(("127.0.0.1", 0), SaaSAPIHandler)
    server.storage = storage
    server.saas = SaaSManager(storage)
    server.entitlements = EntitlementManager(storage)
    server.ledger = PerformanceLedger(storage)
    server.proofs = ProofLedger(storage)
    server.onchain = OnChainLedger(storage)
    server.reputation = ReputationEngine(storage)
    server.observability = ObservabilityEngine(storage)
    server.distribution = DistributionManager(storage)
    server.db_lock = threading.RLock()
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    return server, thread


def _get(server, path: str, key: str | None = None):
    headers = {"Authorization": f"Bearer {key}"} if key else {}
    req = Request(f"http://127.0.0.1:{server.server_port}{path}", headers=headers)
    try:
        with urlopen(req, timeout=3) as response:
            return response.status, response.headers.get("Content-Type", ""), response.read()
    except HTTPError as exc:
        return exc.code, exc.headers.get("Content-Type", ""), exc.read()


def test_customer_portal_and_feature_gate_over_real_local_http(tmp_path):
    storage = Storage(tmp_path / "http.db")
    server = None
    try:
        saas = SaaSManager(storage)
        saas.create_tenant("Free Customer", "free-customer", plan="free")
        key = saas.create_api_key("free-customer", rpm=50, daily=500)["api_key"]
        server, thread = _server(storage)

        status, ctype, body = _get(server, "/portal")
        assert status == 200
        assert "text/html" in ctype
        assert b"Customer Portal" in body

        status, _, body = _get(server, "/api/v1/signals?days=30&limit=10", key)
        assert status == 200
        assert json.loads(body)["count"] == 0

        status, _, body = _get(server, "/api/v1/performance?days=30", key)
        assert status == 403
        payload = json.loads(body)
        assert payload["error"] == "feature_not_available"
        assert payload["plan"] == "free"

        status, _, body = _get(server, "/api/v1/portal/overview", key)
        assert status == 200
        overview = json.loads(body)
        assert overview["me"]["entitlement"]["plan"] == "free"
        assert overview["usage"]["daily_limit"] == 500
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        storage.close()



def test_plan_default_api_quotas_and_signal_cap(tmp_path):
    storage = Storage(tmp_path / "caps.db")
    server = None
    try:
        saas = SaaSManager(storage)
        saas.create_tenant("Free", "free", plan="free")
        created = saas.create_api_key("free")
        assert created["rpm_limit"] == 15
        assert created["daily_limit"] == 1000
        ledger = PerformanceLedger(storage)
        for i in range(30):
            ledger.record_signal({
                "chain": "solana", "address": f"addr{i}", "symbol": f"T{i}",
                "name": f"Token{i}", "price": 1.0, "final_score": 80,
                "liquidity": 100000, "volume24h": 200000, "marketcap": 1000000,
                "source": "test",
            }, "free")
        server, thread = _server(storage)
        status, _, body = _get(server, "/api/v1/signals?days=3650&limit=1000", created["api_key"])
        assert status == 200
        payload = json.loads(body)
        assert payload["count"] <= 25
    finally:
        if server is not None:
            server.shutdown(); server.server_close()
        storage.close()

def test_enterprise_overview_is_plan_gated(tmp_path):
    storage = Storage(tmp_path / "enterprise.db")
    server = None
    try:
        saas = SaaSManager(storage)
        saas.create_tenant("Enterprise", "enterprise", plan="enterprise")
        key = saas.create_api_key("enterprise", rpm=50, daily=500)["api_key"]
        server, thread = _server(storage)
        status, _, body = _get(server, "/api/v1/enterprise/overview", key)
        assert status == 200
        payload = json.loads(body)
        assert payload["entitlement"]["plan"] == "enterprise"
        assert "performance" in payload
        assert "observability" in payload
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        storage.close()
