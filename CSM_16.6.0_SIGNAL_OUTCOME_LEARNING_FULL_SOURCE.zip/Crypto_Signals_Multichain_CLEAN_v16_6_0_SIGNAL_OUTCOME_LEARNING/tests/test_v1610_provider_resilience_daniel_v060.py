from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from csm.observability import ObservabilityEngine
from csm.provider_health import aggregate_provider_health
from phantom_v10.discovery import MultiProviderDiscovery
from phantom_v10.providers import ProviderGateway
from daniel_ai import __version__ as daniel_version
from csm import __product_version__


class RateLimitError(RuntimeError):
    status = 429


class QuotaError(RuntimeError):
    status = 400
    payload = {"message": "Compute Units usage limit exceeded"}


def test_release_versions_advance_together():
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    assert daniel_version == "1.3.1"


def test_gateway_429_opens_long_cooldown_and_force_does_not_bypass():
    gateway = ProviderGateway(max_backoff=900, rate_limit_base=300)
    calls = {"n": 0}

    def limited():
        calls["n"] += 1
        raise RateLimitError("HTTP 429 Too Many Requests")

    assert gateway.fetch("GeckoTerminal market", limited, force=True) is None
    state = gateway.state("GeckoTerminal market")
    assert state.status == "COOLDOWN"
    assert state.next_retry > 0
    assert state.rate_limit_events == 1
    assert state.circuit_reason == "rate_limit"

    # An open circuit protects the provider even when callers request fresh
    # market data with force=True; fallback should be used instead.
    assert gateway.fetch("GeckoTerminal market", limited, force=True) is None
    assert calls["n"] == 1
    snap = gateway.snapshot()[0]
    assert snap["retry_in"] >= 250


def test_gateway_success_marks_recovery_grace():
    gateway = ProviderGateway(max_backoff=900, rate_limit_base=300, recovery_grace=600)
    gateway.fetch("GeckoTerminal market", lambda: (_ for _ in ()).throw(RateLimitError("HTTP 429")), force=True)
    state = gateway.state("GeckoTerminal market")
    state.next_retry = 0
    assert gateway.fetch("GeckoTerminal market", lambda: {"ok": True}, force=True) == {"ok": True}
    snap = gateway.snapshot()[0]
    assert snap["status"] == "ONLINE"
    assert snap["recently_recovered"] is True
    assert snap["recovery_in"] > 0


def test_gateway_quota_exhaustion_is_distinct_from_rate_limit():
    gateway = ProviderGateway(max_backoff=900)
    assert gateway.fetch("Birdeye novos solana", lambda: (_ for _ in ()).throw(QuotaError("HTTP 400")), force=True) is None
    state = gateway.state("Birdeye novos solana")
    assert state.status == "QUOTA_EXHAUSTED"
    assert state.quota_exhaustions == 1
    assert state.circuit_reason == "quota"


def test_discovery_provider_pause_keeps_other_sources_available():
    layer = MultiProviderDiscovery()
    layer.pause_provider("geckoterminal", reason="HTTP 429 • cooldown", ttl_seconds=300)
    rows = layer.sources("free", ("solana", "ethereum"))
    assert not any(row.provider == "geckoterminal" and not getattr(row, "probe_only", False) for row in rows)
    assert any(row.provider == "dexscreener" for row in rows)
    assert "geckoterminal" in layer.last_paused_providers


def test_health_cannot_report_100_while_provider_is_in_cooldown():
    report = aggregate_provider_health([
        {
            "name": "GeckoTerminal market",
            "status": "COOLDOWN",
            "success_rate": 99.4,
            "latency_ms": 600,
            "retry_in": 300,
        },
        {
            "name": "DexScreener market",
            "status": "ONLINE",
            "success_rate": 100.0,
            "latency_ms": 180,
        },
    ])
    rows = {row["name"]: row for row in report["providers"]}
    assert rows["GeckoTerminal market"]["health_score"] <= 55
    assert report["counts"]["COOLDOWN"] == 1
    assert report["overall_health"] < 100


def test_observability_emits_recovery_candidate_only_after_alerted_incident_resolves():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    engine = ObservabilityEngine(SimpleNamespace(conn=conn))
    now = datetime.now(timezone.utc)
    engine._incident(
        "provider:geckoterminal-market:limit",
        active=True,
        component="provider",
        severity="HIGH",
        summary="Limite/cota do provider GeckoTerminal market detectado",
        details={"last_error": "HTTP 429"},
        now=now,
    )
    row = conn.execute("SELECT id FROM ops_incidents WHERE incident_key=?", ("provider:geckoterminal-market:limit",)).fetchone()
    engine.mark_notified([int(row[0])])
    # V16.5.8 requires a stable recovery window before sending "recovered".
    notified = now - timedelta(seconds=700)
    resolved = now - timedelta(seconds=650)
    conn.execute("UPDATE ops_incidents SET last_notified_at=? WHERE id=?", (notified.isoformat(), int(row[0])))
    engine._incident(
        "provider:geckoterminal-market:limit",
        active=False,
        component="provider",
        severity="HIGH",
        summary="Limite/cota do provider GeckoTerminal market detectado",
        now=resolved,
    )
    rows = engine.recovery_candidates()
    assert len(rows) == 1
    engine.mark_recovery_notified([int(rows[0]["id"])])
    assert engine.recovery_candidates() == []
    conn.close()
