from __future__ import annotations

import sqlite3
from pathlib import Path

from csm import __product_version__
from csm.scanner_intelligence import (
    ScannerIntelligenceStore,
    compare_approved_rejected,
    ensure_schema,
    recent_decisions,
    scanner_funnel,
)
from csm.storage import Storage
from daniel_ai import __version__ as daniel_version
from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.learning import AutoLearner
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools
from phantom_v10.scanner import ScannerEngine


def cfg(tmp_path: Path, *, web: bool = False, learning: bool = True) -> DanielSettings:
    return DanielSettings(
        enabled=True,
        admin_only=True,
        memory_enabled=True,
        history_limit=50,
        max_question_chars=4000,
        openai_enabled=False,
        openai_api_key="",
        openai_model="",
        web_enabled=web,
        documents_enabled=True,
        documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel",
        db_file=tmp_path / "daniel" / "daniel_ai.db",
        learning_enabled=learning,
        learning_interval_minutes=60,
        learning_max_sources_per_topic=3,
        learning_ttl_hours=168,
        learning_max_items=50,
        learning_web_timeout_seconds=2,
        learned_dir=tmp_path / "daniel" / "learned",
    )


def _market(chain: str, address: str, *, liquidity: float, volume: float = 100000.0) -> dict:
    return {
        "chain": chain,
        "address": address,
        "symbol": address[:6].upper(),
        "name": address,
        "liquidity": liquidity,
        "volume24h": volume,
        "marketcap": 500000.0,
        "change24h": 10.0,
        "buys24h": 80,
        "sells24h": 40,
        "source": "test",
        "age_days": 3.0,
    }


def test_v162_v080_versions_advance_together():
    # Historical capability remains present in later additive releases.
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    assert daniel_version == "1.3.1"


def test_scanner_intelligence_schema_is_additive():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)
    names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    assert "scanner_intelligence_cycles" in names
    assert "scanner_decisions" in names
    conn.close()


def test_scanner_records_rejection_reason_by_chain_without_changing_gate():
    scanner = ScannerEngine(cycle_timeout=40, cycle_budget=20)
    scanner.last_stats = scanner._stats()
    scanner.last_stats["cycle_key"] = "test-cycle"
    scanner._current_candidate = ("solana", "lowliq")
    scanner._accept_market(_market("solana", "lowliq", liquidity=1.0))
    assert scanner.last_stats["rejected"] == 1
    assert scanner.last_stats["rejection_reasons"]["liquidity_below_min"] == 1
    assert scanner.last_stats["chain_stats"]["solana"]["rejected"] == 1
    assert scanner.last_stats["decisions"][0]["decision"] == "REJECTED"
    assert scanner.last_stats["decisions"][0]["reason"] == "liquidity_below_min"


def test_scanner_records_approved_decision_snapshot():
    scanner = ScannerEngine(cycle_timeout=40, cycle_budget=20)
    scanner.last_stats = scanner._stats()
    scanner.last_stats["cycle_key"] = "approved-cycle"
    scanner._current_candidate = ("base", "goodtoken")
    scanner._record_analyzed(_market("base", "goodtoken", liquidity=50000.0))
    scanner.last_stats["analyzed"] = 1
    scanner._finalize_approved_market(_market("base", "goodtoken", liquidity=50000.0))
    assert scanner.last_stats["approved"] == 1
    assert scanner.last_stats["chain_stats"]["base"]["approved"] == 1
    assert scanner.last_stats["decisions"][0]["decision"] == "APPROVED"


def test_capture_cycle_and_funnel_preserve_exact_reasons(tmp_path):
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        store = ScannerIntelligenceStore(storage)
        stats = {
            "cycle_key": "c1",
            "discovery_tier": "premium",
            "discovered": 4,
            "analyzed": 3,
            "approved": 1,
            "rejected": 2,
            "market_unavailable": 1,
            "errors": 0,
            "security_blocked": 0,
            "rejection_reasons": {"liquidity_below_min": 1, "volume_below_min": 1},
            "chain_stats": {},
            "providers_used": ["geckoterminal", "dexscreener"],
            "decisions": [
                {**_market("solana", "a", liquidity=50000), "decision": "APPROVED", "reason": "", "analytic_score": 88, "final_score": 88},
                {**_market("solana", "b", liquidity=1), "decision": "REJECTED", "reason": "liquidity_below_min", "analytic_score": 30},
                {**_market("bsc", "c", liquidity=50000, volume=1), "decision": "REJECTED", "reason": "volume_below_min", "analytic_score": 40},
                {"chain": "bsc", "address": "d", "decision": "UNAVAILABLE", "reason": "market_unavailable"},
            ],
        }
        result = store.capture_cycle(stats)
        assert result["decisions"] == 4
        funnel = scanner_funnel(storage.conn, hours=24)
        assert funnel["analyzed"] == 3
        assert funnel["approved"] == 1
        assert funnel["rejected"] == 2
        assert funnel["rejection_reasons"][0]["count"] == 1
        labels = {r["label"] for r in funnel["rejection_reasons"]}
        assert "liquidez abaixo do mínimo" in labels
        assert "volume 24h abaixo do mínimo" in labels
        solana = next(r for r in funnel["networks"] if r["chain"] == "solana")
        assert solana["approved"] == 1 and solana["rejected"] == 1


def test_compare_and_recent_decisions_are_evidence_only(tmp_path):
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        store = ScannerIntelligenceStore(storage)
        store.capture_cycle({
            "cycle_key": "c2", "discovered": 2, "analyzed": 2, "approved": 1, "rejected": 1,
            "rejection_reasons": {"liquidity_below_min": 1},
            "decisions": [
                {**_market("base", "ok", liquidity=100000, volume=200000), "decision": "APPROVED", "analytic_score": 90, "final_score": 90},
                {**_market("base", "bad", liquidity=100, volume=1000), "decision": "REJECTED", "reason": "liquidity_below_min", "analytic_score": 20},
            ],
        })
        comparison = compare_approved_rejected(storage.conn, 24, "base")
        assert comparison["approved"]["samples"] == 1
        assert comparison["rejected"]["samples"] == 1
        assert comparison["approved"]["avg_liquidity"] > comparison["rejected"]["avg_liquidity"]
        rows = recent_decisions(storage.conn, hours=24, chain="base", decision="REJECTED", limit=5)
        assert rows[0]["reason_label"] == "liquidez abaixo do mínimo"


def test_daniel_reads_chain_rejection_evidence_instead_of_guessing(tmp_path):
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        ScannerIntelligenceStore(storage).capture_cycle({
            "cycle_key": "c3", "discovered": 1, "analyzed": 1, "approved": 0, "rejected": 1,
            "rejection_reasons": {"volume_below_min": 1},
            "decisions": [{**_market("bsc", "quiet", liquidity=50000, volume=1), "decision": "REJECTED", "reason": "volume_below_min", "analytic_score": 35}],
        })
    c = cfg(tmp_path)
    mem = DanielMemory(c.db_file)
    ai = DanielAI(c, tools=DanielTools(c, csm_db=db), memory=mem)
    answer = ai.ask("por que há poucos sinais na BSC nas últimas 24h?", user_id=1)
    assert "Scanner Intelligence" in answer
    assert "volume 24h abaixo do mínimo" in answer
    assert "não altera filtros" in answer.lower() or "nao altera filtros" in answer.lower()
    mem.close()


def test_compare_rejected_with_approved_routes_to_funnel_not_token_compare(tmp_path):
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        ScannerIntelligenceStore(storage).capture_cycle({
            "cycle_key": "c4", "discovered": 2, "analyzed": 2, "approved": 1, "rejected": 1,
            "rejection_reasons": {"liquidity_below_min": 1},
            "decisions": [
                {**_market("solana", "ok", liquidity=100000), "decision": "APPROVED", "analytic_score": 90, "final_score": 90},
                {**_market("solana", "bad", liquidity=1), "decision": "REJECTED", "reason": "liquidity_below_min", "analytic_score": 20},
            ],
        })
    c = cfg(tmp_path)
    mem = DanielMemory(c.db_file)
    ai = DanielAI(c, tools=DanielTools(c, csm_db=db), memory=mem)
    answer = ai.ask("compare os rejeitados com os aprovados nas últimas 24h", user_id=1)
    assert "Aprovados × rejeitados" in answer
    assert "nenhum sinal encontrado" not in answer.lower()
    mem.close()


def test_outcome_learning_uses_local_observed_ledger_and_never_needs_web(tmp_path):
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        for i in range(12):
            positive = i < 8
            storage.conn.execute(
                """INSERT INTO signal_ledger(
                       event_key,chain,address,symbol,entry_price,final_score,liquidity,volume24h,
                       buys24h,sells24h,observations,last_return_pct,max_return_pct,first_tp1_at,first_stop_at
                   ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    f"event-{i}", "solana" if i < 7 else "base", f"addr-{i}", f"T{i}", 1.0,
                    90 if positive else 65, 100000 if positive else 12000, 250000 if positive else 30000,
                    80 if positive else 35, 30 if positive else 50, 2,
                    12.0 if positive else -8.0, 18.0 if positive else 2.0,
                    "2026-08-20 00:00:00" if positive else None,
                    None if positive else "2026-08-20 01:00:00",
                ),
            )
        storage.conn.commit()
        before = storage.conn.execute("SELECT COUNT(*) FROM signal_ledger").fetchone()[0]
        c = cfg(tmp_path, web=False, learning=True)
        mem = DanielMemory(c.db_file)
        learner = AutoLearner(c, memory=mem)
        result = learner.learn_csm_outcomes(storage.conn, days=30, minimum_samples=8)
        after = storage.conn.execute("SELECT COUNT(*) FROM signal_ledger").fetchone()[0]
        assert result["ok"] is True
        assert result["samples"] == 12
        assert before == after == 12
        learned = mem.search_learned("CSM outcome patterns")
        assert learned and learned[0]["origin"] == "csm_outcomes"
        assert "Correlação observacional" in learned[0]["summary"]
        mem.close()
