from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from csm import __product_version__
from csm.performance import PerformanceLedger
from csm.signal_lifecycle import lifecycle_summary, recent_events
from csm.storage import Storage
from daniel_ai import __version__ as daniel_version
from daniel_ai.config import DanielSettings
from daniel_ai.engine import DanielAI
from daniel_ai.learning import AutoLearner
from daniel_ai.memory import DanielMemory
from daniel_ai.tools import DanielTools


def _cfg(tmp_path: Path) -> DanielSettings:
    return DanielSettings(
        enabled=True, admin_only=True, memory_enabled=True, history_limit=50,
        max_question_chars=4000, openai_enabled=False, openai_api_key="", openai_model="",
        web_enabled=False, documents_enabled=True, documents_dir=tmp_path / "docs",
        state_dir=tmp_path / "daniel", db_file=tmp_path / "daniel" / "daniel_ai.db",
        learning_enabled=True, learning_interval_minutes=60, learning_max_sources_per_topic=3,
        learning_ttl_hours=168, learning_max_items=50, learning_web_timeout_seconds=2,
        learned_dir=tmp_path / "daniel" / "learned",
    )


def _signal(symbol: str = "LIFE", chain: str = "solana") -> dict:
    return {
        "chain": chain, "address": f"addr-{symbol.lower()}", "symbol": symbol, "name": symbol,
        "price": 1.0, "final_score": 88, "opportunity_score": 88,
        "liquidity": 100000.0, "volume24h": 200000.0, "marketcap": 1000000.0,
        "change24h": 10.0, "buys24h": 80, "sells24h": 40, "source": "test",
        "approval_reasons": ["test-approved"],
    }


def _market(price: float, *, liquidity: float = 100000.0, volume: float = 200000.0, buys: int = 80, sells: int = 40, change1h: float = 1.0) -> dict:
    return {
        "price": price, "liquidity": liquidity, "volume24h": volume, "marketcap": 1000000.0,
        "buys24h": buys, "sells24h": sells, "change1h": change1h, "volume1h": volume / 24,
        "source": "test",
    }


def test_v163_v090_versions_advance_together():
    assert __product_version__ == "16.6.0-signal-outcome-learning"
    assert daniel_version == "1.3.1"


def test_lifecycle_schema_is_additive(tmp_path):
    with Storage(tmp_path / "signals.db") as storage:
        ledger_cols = {r[1] for r in storage.conn.execute("PRAGMA table_info(signal_ledger)").fetchall()}
        obs_cols = {r[1] for r in storage.conn.execute("PRAGMA table_info(signal_observations)").fetchall()}
        tables = {r[0] for r in storage.conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        assert {"target3_pct", "first_tp3_at", "lifecycle_state", "next_check_at", "deterioration_score"} <= ledger_cols
        assert {"buy_pressure_pct", "liquidity_change_pct", "volume_change_pct", "score_delta"} <= obs_cols
        assert "signal_lifecycle_events" in tables


def test_tp3_records_all_milestones_and_closes_cycle(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal("ROCKET"), "premium", now=now)
        assert sid
        assert ledger.record_observation(sid, _market(2.10), captured_at=now + timedelta(minutes=10)) is True
        row = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        assert row["lifecycle_state"] == "TP3"
        assert row["status"] == "COMPLETE"
        assert row["first_tp1_at"] and row["first_tp2_at"] and row["first_tp3_at"]
        events = {r["event_type"] for r in recent_events(storage.conn, hours=24, limit=10)}
        assert {"TP1", "TP2", "TP3"} <= events
        assert ledger.due_signals(limit=10) == []


def test_stop_closes_cycle_without_rewriting_original_signal(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)
        original = _signal("STOPME")
        sid = ledger.record_signal(original, "plus", now=now)
        before = dict(storage.conn.execute("SELECT final_score,entry_price,liquidity FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        ledger.record_observation(sid, _market(0.85), captured_at=now + timedelta(minutes=10))
        row = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        assert row["lifecycle_state"] == "STOPPED" and row["status"] == "COMPLETE"
        assert row["first_stop_at"]
        assert row["final_score"] == before["final_score"]
        assert row["entry_price"] == before["entry_price"]
        assert row["liquidity"] == before["liquidity"]


def test_deterioration_detects_liquidity_and_buy_pressure_and_keeps_monitoring(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal("WEAK"), "premium", now=now)
        ledger.record_observation(
            sid, _market(1.02, liquidity=50000, volume=60000, buys=20, sells=80, change1h=-15),
            captured_at=now + timedelta(minutes=10),
        )
        row = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        assert row["lifecycle_state"] == "DETERIORATING"
        assert row["status"] == "ACTIVE"
        assert int(row["deterioration_score"] or 0) >= 35
        assert float(row["last_liquidity_change_pct"] or 0) <= -49
        assert row["next_check_at"]
        events = recent_events(storage.conn, hours=24, limit=10)
        assert any(e["event_type"] == "DETERIORATION" for e in events)


def test_lifecycle_summary_and_daniel_explain_deteriorating_signals(tmp_path):
    now = datetime.now(timezone.utc)
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal("DANIEL"), "premium", now=now)
        ledger.record_observation(sid, _market(0.99, liquidity=45000, buys=15, sells=85, change1h=-13), captured_at=now + timedelta(minutes=5))
        summary = lifecycle_summary(storage.conn, hours=24)
        assert summary["states"].get("DETERIORATING") == 1
    c = _cfg(tmp_path)
    mem = DanielMemory(c.db_file)
    ai = DanielAI(c, tools=DanielTools(c, csm_db=db), memory=mem)
    answer = ai.ask("quais sinais estão deteriorando hoje?", user_id=1)
    assert "Signal Lifecycle" in answer
    assert "DANIEL" in answer
    assert "deteriora" in answer.lower()
    mem.close()


def test_outcome_learning_reads_lifecycle_but_never_changes_csm(tmp_path):
    now = datetime.now(timezone.utc)
    db = tmp_path / "signals.db"
    with Storage(db) as storage:
        ledger = PerformanceLedger(storage)
        for i in range(10):
            sig = _signal(f"P{i}", "solana" if i < 6 else "base")
            sid = ledger.record_signal(sig, "premium", now=now - timedelta(hours=i + 1))
            price = 1.30 if i < 7 else 0.85
            ledger.record_observation(sid, _market(price), captured_at=now - timedelta(hours=i) )
        before = storage.conn.execute("SELECT COUNT(*) FROM signal_ledger").fetchone()[0]
        c = _cfg(tmp_path)
        mem = DanielMemory(c.db_file)
        learner = AutoLearner(c, memory=mem)
        result = learner.learn_csm_outcomes(storage.conn, days=30, minimum_samples=8)
        after = storage.conn.execute("SELECT COUNT(*) FROM signal_ledger").fetchone()[0]
        assert result["ok"] is True
        assert before == after == 10
        learned = mem.search_learned("lifecycle outcome patterns")
        assert learned and "Lifecycle:" in learned[0]["summary"]
        mem.close()
