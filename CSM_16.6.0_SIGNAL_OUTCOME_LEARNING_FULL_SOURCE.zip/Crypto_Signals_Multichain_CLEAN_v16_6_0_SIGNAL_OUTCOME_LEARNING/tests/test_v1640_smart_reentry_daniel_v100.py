from __future__ import annotations

from datetime import datetime, timezone, timedelta

from csm.performance import PerformanceLedger
from csm.smart_reentry import SmartReentry, ensure_schema
from csm.storage import Storage
from csm.user_profiles import UserProfileStore
from daniel_ai.engine import DanielAI
from daniel_ai.tools import DanielTools
from phantom_v10.auto_delivery import AutomaticSignalDelivery


def token(address="RE1", *, score=90, liquidity=100_000, volume=300_000, buys=120, sells=80, change1h=2.0):
    return {
        "chain": "solana", "address": address, "symbol": "RE", "name": "Reentry",
        "price": 0.001, "score": score, "opportunity_score": score, "final_score": score,
        "liquidity": liquidity, "volume24h": volume, "marketcap": 500_000, "fdv": 600_000,
        "change5m": 0.5, "change6h": 4.0, "change24h": 12.5,
        "buys5m": 10, "sells5m": 5, "buys1h": 30, "sells1h": 15,
        "volume5m": 10_000, "volume1h": 50_000, "volume6h": 120_000,
        "buys24h": buys, "sells24h": sells, "change1h": change1h, "source": "test",
    }


class Telegram:
    def __init__(self):
        self.sent=[]
    def send(self, user_id, text, keyboard=None):
        self.sent.append((user_id,text,keyboard))
        return {"message_id": len(self.sent)}


def test_plan_cooldowns_are_24_12_6_and_revalidation_is_plan_specific(tmp_path):
    storage=Storage(tmp_path/"signals.db")
    try:
        gate=SmartReentry(storage, PerformanceLedger(storage))
        for uid in (1,2,3):
            storage.mark_alert_delivery(uid,"solana","RE1","entry",90)
            storage.conn.execute("UPDATE alert_deliveries SET created_at=datetime('now','-7 hours') WHERE user_id=?",(uid,))
        storage.conn.commit()
        free=gate.evaluate(user_id=1,plan_group="free",item=token())
        plus=gate.evaluate(user_id=2,plan_group="plus",item=token())
        premium=gate.evaluate(user_id=3,plan_group="premium",item=token())
        assert free.cooldown_hours == 24 and not free.allowed
        assert plus.cooldown_hours == 12 and not plus.allowed
        assert premium.cooldown_hours == 6 and premium.allowed
        assert premium.is_reentry
        assert premium.metrics["current_revalidated"] is True
    finally:
        storage.close()


def test_stopped_or_deteriorated_signal_requires_material_improvement(tmp_path):
    storage=Storage(tmp_path/"strict.db")
    try:
        ledger=PerformanceLedger(storage)
        prior=token(score=90,liquidity=100_000,volume=300_000,buys=120,sells=80,change1h=2)
        signal_id=ledger.record_signal(prior,"premium",now=datetime.now(timezone.utc)-timedelta(hours=8))
        storage.conn.execute("UPDATE signal_ledger SET lifecycle_state='STOPPED',status='CLOSED',last_buy_pressure_pct=60,last_score_delta=0 WHERE id=?",(signal_id,))
        ensure_schema(storage.conn)
        storage.conn.execute(
            """INSERT INTO signal_reentry_history(user_id,chain,address,symbol,name,plan_group,delivery_kind,signal_id,cooldown_hours,score,created_at)
               VALUES(1,'solana','RE1','RE','Reentry','premium','INITIAL',?,6,90,datetime('now','-7 hours'))""",
            (signal_id,),
        )
        storage.conn.commit()
        gate=SmartReentry(storage,ledger)
        blocked=gate.evaluate(user_id=1,plan_group="premium",item=token(score=90,liquidity=100_000,volume=300_000,buys=120,sells=80,change1h=2))
        assert blocked.is_reentry and not blocked.allowed
        assert blocked.prior_lifecycle_state == "STOPPED"
        assert blocked.strict_revalidation is True
        assert "melhora material" in blocked.block_reason

        improved=gate.evaluate(user_id=1,plan_group="premium",item=token(score=94,liquidity=115_000,volume=390_000,buys=150,sells=70,change1h=10))
        assert improved.allowed
        assert improved.improvement_reasons
        assert any("liquidez" in reason or "score" in reason for reason in improved.improvement_reasons)
    finally:
        storage.close()


def test_auto_delivery_records_confirmed_reentry_and_banner(tmp_path):
    storage=Storage(tmp_path/"delivery.db")
    try:
        storage.upsert_user(10,"premium","P")
        storage.set_plan(10,"premium",30)
        telegram=Telegram()
        delivery=AutomaticSignalDelivery(storage=storage,telegram=telegram,user_profiles=UserProfileStore(tmp_path/"profiles.json"))
        first=delivery.deliver("premium",[token()])
        assert first["sent"] == 1
        storage.conn.execute("UPDATE signal_reentry_history SET created_at=datetime('now','-7 hours') WHERE user_id=10")
        storage.conn.execute("UPDATE alert_deliveries SET created_at=datetime('now','-7 hours') WHERE user_id=10")
        storage.conn.commit()
        second=delivery.deliver("premium",[token(score=93,liquidity=120_000,volume=360_000,buys=140,sells=70,change1h=8)])
        assert second["sent"] == 1
        assert second["reentries"] == 1
        assert "REENTRADA INTELIGENTE V16.4" in telegram.sent[-1][1]
        rows=storage.conn.execute("SELECT delivery_kind FROM signal_reentry_history WHERE user_id=10 ORDER BY id").fetchall()
        assert [row[0] for row in rows] == ["INITIAL","REENTRY"]
    finally:
        storage.close()


def test_daniel_operational_copilot_and_reentry_explanation_are_read_only(tmp_path):
    storage=Storage(tmp_path/"daniel.db")
    try:
        ensure_schema(storage.conn)
        storage.conn.execute(
            """INSERT INTO signal_reentry_history(user_id,chain,address,symbol,name,plan_group,delivery_kind,prior_lifecycle_state,cooldown_hours,score,evidence_json,created_at)
               VALUES(1,'solana','RE1','RE','Reentry','premium','REENTRY','STOPPED',6,94,?,CURRENT_TIMESTAMP)""",
            ('{"improvement_reasons":["score +4 pontos","liquidez +15.0%"]}',),
        )
        storage.conn.commit()
    finally:
        storage.close()
    tools=DanielTools(csm_db=tmp_path/"daniel.db")
    ai=DanielAI(tools=tools)
    answer=ai.ask("por que RE foi reenviado?",user_id=1)
    assert "reenviado" in answer.lower()
    assert "score +4" in answer.lower()
    operational=ai.ask("status operacional",user_id=1)
    assert "Operational Copilot" in operational
    assert "Smart Reentry" in operational
    assert "somente leitura" in operational
