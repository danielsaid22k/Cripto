from __future__ import annotations

from csm.config import settings
from phantom_v10.errors import NetworkHTTPError
from phantom_v10.provider_diagnostics import check_birdeye
from phantom_v10.transport import HttpResult


class FakeTransport:
    def __init__(self, outcomes):
        self.outcomes = list(outcomes)
        self.calls = []

    def clone(self, **kwargs):
        return self

    def request_json(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


def test_coverage_429_stops_before_new_listing():
    old = settings.birdeye_api_key
    object.__setattr__(settings, "birdeye_api_key", "r" * 32)

    try:
        fake = FakeTransport([
            NetworkHTTPError(
                429,
                {"message": "Too many requests"},
                "https://public-api.birdeye.so/defi/networks",
            )
        ])

        report = check_birdeye(check_listing=True, transport=fake)

        assert report["rate_limited"] is True
        assert report["failure_kind"] == "rate_limit"
        assert report["auth_status"] == 429
        assert report["listing_ok"] is False
        assert report["listing_status"] is None
        assert len(fake.calls) == 1
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)


def test_new_listing_429_preserves_valid_credentials():
    old = settings.birdeye_api_key
    object.__setattr__(settings, "birdeye_api_key", "s" * 32)

    try:
        fake = FakeTransport([
            HttpResult(
                {"success": True, "data": ["solana", "ethereum"]},
                200,
                1.0,
                "https://public-api.birdeye.so/defi/networks",
            ),
            NetworkHTTPError(
                429,
                {"message": "Too many requests"},
                "https://public-api.birdeye.so/defi/v2/tokens/new_listing",
            ),
        ])

        report = check_birdeye(check_listing=True, transport=fake)

        assert report["auth_ok"] is True
        assert report["credential_ok"] is True
        assert report["rate_limited"] is True
        assert report["failure_kind"] == "rate_limit"
        assert report["listing_ok"] is False
        assert report["listing_status"] == 429
        assert len(fake.calls) == 2
    finally:
        object.__setattr__(settings, "birdeye_api_key", old)
