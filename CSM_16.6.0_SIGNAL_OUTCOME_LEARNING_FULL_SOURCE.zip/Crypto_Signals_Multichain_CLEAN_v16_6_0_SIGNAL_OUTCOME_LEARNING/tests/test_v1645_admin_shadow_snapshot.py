from types import SimpleNamespace

from csm import admin_web


class DummyStorage:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class FakePerformanceLedger:
    shadow_calls = []

    def __init__(self, _storage):
        pass

    def report(self, *, days=30):
        return {
            "signals_observed": 1,
            "win_rate_pct": 50.0,
            "tp1_hit_rate_pct": 25.0,
        }

    def signals(self, *, days=30, limit=50):
        return []

    def signal_quality_shadow_report(self, **kwargs):
        self.__class__.shadow_calls.append(dict(kwargs))
        return {
            "signals_total": 10,
            "shadow_confirmed": 4,
            "shadow_missing": 6,
            "shadow_coverage_pct": 40.0,
            "target_seconds": 300,
            "grace_seconds": 180,
        }


class FakeProof:
    def __init__(self, _storage):
        pass

    def seal_due_roots(self):
        pass

    def status(self):
        return {}


class FakeOnChain:
    def __init__(self, _storage):
        pass

    def report(self, **_kwargs):
        return {}


class FakeReputation:
    def __init__(self, _storage):
        pass

    def refresh(self, **_kwargs):
        pass

    def report(self, **_kwargs):
        return {}


class FakeObservability:
    def __init__(self, _storage):
        pass

    def report(self, **_kwargs):
        return {}


class FakeDistribution:
    def __init__(self, _storage):
        pass

    def status(self, **_kwargs):
        return {}


def test_admin_snapshot_exposes_shadow_quality_without_persisting(monkeypatch):
    FakePerformanceLedger.shadow_calls.clear()

    monkeypatch.setattr(admin_web, "Storage", DummyStorage)
    monkeypatch.setattr(admin_web, "PerformanceLedger", FakePerformanceLedger)
    monkeypatch.setattr(admin_web, "ProofLedger", FakeProof)
    monkeypatch.setattr(admin_web, "OnChainLedger", FakeOnChain)
    monkeypatch.setattr(admin_web, "ReputationEngine", FakeReputation)
    monkeypatch.setattr(admin_web, "ObservabilityEngine", FakeObservability)
    monkeypatch.setattr(admin_web, "DistributionManager", FakeDistribution)

    monkeypatch.setattr(admin_web, "enterprise_snapshot", lambda: {})
    monkeypatch.setattr(admin_web, "load_branding", lambda: {})

    monkeypatch.setattr(
        admin_web,
        "settings",
        SimpleNamespace(
            signal_quality_shadow_target_seconds=300,
            signal_quality_shadow_grace_seconds=180,
        ),
    )

    snapshot = admin_web._admin_snapshot()

    assert "signal_quality_shadow" in snapshot["performance"]

    shadow = snapshot["performance"]["signal_quality_shadow"]
    assert shadow["shadow_coverage_pct"] == 40.0
    assert shadow["shadow_confirmed"] == 4

    assert FakePerformanceLedger.shadow_calls == [
        {
            "days": 30,
            "target_seconds": 300,
            "grace_seconds": 180,
            "persist": False,
        }
    ]
