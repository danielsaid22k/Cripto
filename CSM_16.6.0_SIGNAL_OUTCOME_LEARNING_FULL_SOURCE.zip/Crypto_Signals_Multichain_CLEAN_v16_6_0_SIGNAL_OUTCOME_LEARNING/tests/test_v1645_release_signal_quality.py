import csm
import phantom_v10


def test_v1645_commercial_release_versions():
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"


def test_internal_runtime_compat_version_is_not_commercial_release():
    assert csm.__version__ == "8.3.1-ashell-single-runtime"
