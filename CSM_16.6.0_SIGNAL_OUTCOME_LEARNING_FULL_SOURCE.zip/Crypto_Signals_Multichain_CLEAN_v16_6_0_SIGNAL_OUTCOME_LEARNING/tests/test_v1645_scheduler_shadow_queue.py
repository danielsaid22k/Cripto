from types import SimpleNamespace

import phantom_v10.scheduler as scheduler_module
from phantom_v10.scheduler import Scheduler


class DummyScanner:
    active = False

    def cancel(self, _reason):
        self.active = False


class DummyLedger:
    def __init__(self):
        self.calls = []

    def shadow_due_signals(self, **kwargs):
        self.calls.append(dict(kwargs))
        return [
            {
                "id": 42,
                "chain": "solana",
                "address": "shadow-address",
                "symbol": "SHADOW",
            }
        ]


class DummyMonitor:
    def __init__(self):
        self.ledger = DummyLedger()


class DummyApp:
    def __init__(self):
        self.scanner = DummyScanner()
        self.performance_monitor = DummyMonitor()


def test_scheduler_loads_dedicated_shadow_queue(monkeypatch):
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            performance_monitor_batch=7,
            signal_quality_shadow_target_seconds=300,
            signal_quality_shadow_grace_seconds=180,
        ),
    )

    app = DummyApp()
    scheduler = Scheduler(app)

    assert list(scheduler.shadow_performance_queue) == []

    loaded = scheduler._reload_shadow_performance_queue()

    assert loaded == 1
    assert [row["id"] for row in scheduler.shadow_performance_queue] == [42]

    assert app.performance_monitor.ledger.calls == [
        {
            "limit": 7,
            "target_seconds": 300,
            "grace_seconds": 180,
        }
    ]


def test_scheduler_stop_clears_shadow_queue():
    app = DummyApp()
    scheduler = Scheduler(app)

    scheduler.shadow_performance_queue.append({"id": 42})
    scheduler.stop()

    assert list(scheduler.shadow_performance_queue) == []


class DummyExecutingMonitor(DummyMonitor):
    def __init__(self):
        super().__init__()
        self.observed = []

    def observe_one(self, signal):
        self.observed.append(int(signal["id"]))
        return True


class DummyExecutingApp(DummyApp):
    def __init__(self):
        super().__init__()
        self.performance_monitor = DummyExecutingMonitor()


def test_shadow_step_processes_only_one_signal(monkeypatch):
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            performance_monitor_batch=7,
            signal_quality_shadow_target_seconds=300,
            signal_quality_shadow_grace_seconds=180,
        ),
    )

    app = DummyExecutingApp()
    scheduler = Scheduler(app)

    worked = scheduler._run_shadow_performance_step()

    assert worked is True
    assert app.performance_monitor.observed == [42]
    assert list(scheduler.shadow_performance_queue) == []


def test_shadow_step_returns_false_without_monitor(monkeypatch):
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            performance_monitor_batch=7,
            signal_quality_shadow_target_seconds=300,
            signal_quality_shadow_grace_seconds=180,
        ),
    )

    app = DummyApp()
    app.performance_monitor = None

    scheduler = Scheduler(app)

    assert scheduler._run_shadow_performance_step() is False


class DummyFailedMonitor(DummyMonitor):
    def __init__(self):
        super().__init__()
        self.observed = []

    def observe_one(self, signal):
        self.observed.append(int(signal["id"]))
        return False


class DummyFailedApp(DummyApp):
    def __init__(self):
        super().__init__()
        self.performance_monitor = DummyFailedMonitor()


def test_shadow_attempt_consumes_scheduler_step_even_without_observation(monkeypatch):
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            performance_monitor_batch=7,
            signal_quality_shadow_target_seconds=300,
            signal_quality_shadow_grace_seconds=180,
        ),
    )

    app = DummyFailedApp()
    scheduler = Scheduler(app)

    # Houve uma tentativa de rede, portanto o passo deve ser considerado usado,
    # mesmo que nenhum registro tenha sido produzido.
    assert scheduler._run_shadow_performance_step() is True
    assert app.performance_monitor.observed == [42]


def test_shadow_poll_respects_sixty_second_interval(monkeypatch):
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            performance_monitor_batch=7,
            signal_quality_shadow_enabled=True,
            signal_quality_shadow_poll_interval=60,
            signal_quality_shadow_target_seconds=300,
            signal_quality_shadow_grace_seconds=180,
        ),
    )

    app = DummyExecutingApp()
    scheduler = Scheduler(app)

    # Primeira consulta pode executar.
    assert scheduler._run_shadow_if_due(1000.0) is True
    assert app.performance_monitor.observed == [42]
    assert len(app.performance_monitor.ledger.calls) == 1

    # Com apenas 30s, não deve consultar novamente.
    assert scheduler._run_shadow_if_due(1030.0) is False
    assert len(app.performance_monitor.ledger.calls) == 1

    # Aos 60s, nova consulta é permitida.
    assert scheduler._run_shadow_if_due(1060.0) is True
    assert app.performance_monitor.observed == [42, 42]
    assert len(app.performance_monitor.ledger.calls) == 2


def test_shadow_poll_disabled_does_nothing(monkeypatch):
    monkeypatch.setattr(
        scheduler_module,
        "settings",
        SimpleNamespace(
            signal_quality_shadow_enabled=False,
            signal_quality_shadow_poll_interval=60,
        ),
    )

    app = DummyExecutingApp()
    scheduler = Scheduler(app)

    assert scheduler._run_shadow_if_due(1000.0) is False
    assert app.performance_monitor.observed == []
