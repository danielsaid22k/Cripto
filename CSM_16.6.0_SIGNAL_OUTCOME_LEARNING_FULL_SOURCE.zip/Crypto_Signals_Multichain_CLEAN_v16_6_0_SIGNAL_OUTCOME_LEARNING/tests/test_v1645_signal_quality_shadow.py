from datetime import datetime, timedelta, timezone

from csm.performance import PerformanceLedger
from csm.storage import Storage


def _signal():
    return {
        "chain": "solana",
        "address": "shadow-test-address",
        "symbol": "SHADOW",
        "name": "Shadow Test",
        "price": 1.0,
        "liquidity": 500_000,
        "volume24h": 1_000_000,
        "marketcap": 2_000_000,
        "change24h": 10.0,
        "buys24h": 60,
        "sells24h": 40,
        "source": "DexScreener",
        "market_score": 85,
        "final_score": 85,
    }


def _market(price=1.01):
    return {
        "price": price,
        "liquidity": 510_000,
        "volume24h": 1_050_000,
        "marketcap": 2_020_000,
        "buys24h": 62,
        "sells24h": 38,
        "change1h": 2.0,
        "source": "DexScreener",
        "score": 86,
    }


def test_shadow_confirmation_becomes_due_at_five_minutes(tmp_path):
    now = datetime.now(timezone.utc)

    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal(), "premium", now=now)
        assert sid

        # Baseline imediata continua existindo.
        assert ledger.record_observation(
            sid,
            _market(),
            captured_at=now + timedelta(seconds=5),
        )

        # Não pode pedir confirmação shadow antes dos 5 minutos.
        assert ledger.shadow_due_signals(
            now=now + timedelta(minutes=4, seconds=59),
            limit=10,
        ) == []

        # Aos ~5 minutos o sinal deve virar prioridade shadow.
        due = ledger.shadow_due_signals(
            now=now + timedelta(minutes=5),
            limit=10,
        )
        assert [row["id"] for row in due] == [sid]

        # A confirmação shadow é apenas observacional:
        # não altera score original nem bloqueia o sinal.
        before = dict(
            storage.conn.execute(
                "SELECT final_score,status FROM signal_ledger WHERE id=?",
                (sid,),
            ).fetchone()
        )

        assert ledger.record_observation(
            sid,
            _market(1.02),
            captured_at=now + timedelta(minutes=5),
        )

        after = dict(
            storage.conn.execute(
                "SELECT final_score,status FROM signal_ledger WHERE id=?",
                (sid,),
            ).fetchone()
        )

        assert after["final_score"] == before["final_score"]
        assert after["status"] == before["status"]

        # Depois da captura de 5m não deve ser solicitada de novo.
        assert ledger.shadow_due_signals(
            now=now + timedelta(minutes=5, seconds=30),
            limit=10,
        ) == []


def test_signal_quality_shadow_report_measures_five_minute_coverage(tmp_path):
    now = datetime.now(timezone.utc)

    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)

        first = _signal()
        first["address"] = "shadow-report-1"
        first["symbol"] = "SHADOW1"

        second = _signal()
        second["address"] = "shadow-report-2"
        second["symbol"] = "SHADOW2"

        sid1 = ledger.record_signal(first, "premium", now=now)
        sid2 = ledger.record_signal(second, "premium", now=now)

        assert sid1 and sid2

        # Ambos têm baseline imediata.
        assert ledger.record_observation(
            sid1, _market(1.00),
            captured_at=now + timedelta(seconds=5),
        )
        assert ledger.record_observation(
            sid2, _market(1.00),
            captured_at=now + timedelta(seconds=6),
        )

        # Apenas o primeiro recebe confirmação shadow na janela de 5 minutos.
        assert ledger.record_observation(
            sid1, _market(1.10),
            captured_at=now + timedelta(minutes=5),
        )

        report = ledger.signal_quality_shadow_report(
            days=30,
            target_seconds=300,
            grace_seconds=180,
        )

        assert report["signals_total"] == 2
        assert report["signals_with_baseline"] == 2
        assert report["shadow_confirmed"] == 1
        assert report["shadow_missing"] == 1
        assert report["shadow_coverage_pct"] == 50.0
        assert report["target_seconds"] == 300
        assert report["grace_seconds"] == 180
        assert report["average_shadow_age_seconds"] == 300.0
        assert report["median_shadow_age_seconds"] == 300.0

        # Relatório é evidence-only e deve deixar trilha auditável.
        run = storage.conn.execute(
            """
            SELECT run_type
            FROM performance_runs
            ORDER BY id DESC
            LIMIT 1
            """
        ).fetchone()

        assert run
        assert run["run_type"] == "signal_quality_shadow"


def test_shadow_report_can_be_read_without_persisting_run(tmp_path):
    now = datetime.now(timezone.utc)

    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)

        signal = _signal()
        signal["address"] = "shadow-readonly"
        signal["symbol"] = "READONLY"

        sid = ledger.record_signal(signal, "premium", now=now)
        assert sid

        ledger.record_observation(
            sid,
            _market(),
            captured_at=now + timedelta(seconds=5),
        )

        before = storage.conn.execute(
            "SELECT COUNT(*) FROM performance_runs"
        ).fetchone()[0]

        report = ledger.signal_quality_shadow_report(
            days=30,
            target_seconds=300,
            grace_seconds=180,
            persist=False,
        )

        after = storage.conn.execute(
            "SELECT COUNT(*) FROM performance_runs"
        ).fetchone()[0]

        assert report["signals_total"] == 1
        assert after == before



def test_shadow_report_tracks_outcomes_of_confirmed_cohort(tmp_path):
    now = datetime.now(timezone.utc)

    with Storage(tmp_path / "signals.db") as storage:
        ledger = PerformanceLedger(storage)

        confirmed = _signal()
        confirmed["address"] = "shadow-confirmed-winner"
        confirmed["symbol"] = "CONFIRMED"

        missing = _signal()
        missing["address"] = "shadow-missing-loser"
        missing["symbol"] = "MISSING"

        sid1 = ledger.record_signal(
            confirmed,
            "premium",
            now=now,
        )
        sid2 = ledger.record_signal(
            missing,
            "premium",
            now=now,
        )

        assert sid1 and sid2

        ledger.record_observation(
            sid1,
            _market(1.00),
            captured_at=now + timedelta(seconds=5),
        )
        ledger.record_observation(
            sid2,
            _market(1.00),
            captured_at=now + timedelta(seconds=5),
        )

        ledger.record_observation(
            sid1,
            _market(1.05),
            captured_at=now + timedelta(minutes=5),
        )

        ledger.record_observation(
            sid1,
            _market(1.30),
            captured_at=now + timedelta(minutes=10),
        )

        ledger.record_observation(
            sid2,
            _market(0.80),
            captured_at=now + timedelta(minutes=10),
        )

        report = ledger.signal_quality_shadow_report(
            days=30,
            target_seconds=300,
            grace_seconds=180,
            persist=False,
        )

        outcome = report["confirmed_outcomes"]

        assert outcome["signals"] == 1
        assert outcome["win_rate_pct"] == 100.0
        assert outcome["tp1_hit_rate_pct"] == 100.0
        assert outcome["stop_touch_rate_pct"] == 0.0
        assert outcome["average_last_return_pct"] == 30.0
