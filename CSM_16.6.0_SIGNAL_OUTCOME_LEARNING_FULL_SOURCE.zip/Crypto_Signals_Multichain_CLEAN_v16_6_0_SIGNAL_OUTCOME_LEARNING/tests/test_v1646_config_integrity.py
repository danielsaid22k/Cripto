from csm.config_integrity import ConfigIntegrityGuard


def env(path, **values):
    path.write_text(
        "\n".join(
            f"{k}={v}"
            for k, v in values.items()
        ) + "\n",
        encoding="utf-8",
    )


def test_unchanged_is_ok(tmp_path):
    f = tmp_path / "config.env"

    env(
        f,
        TELEGRAM_BOT_TOKEN="SECRET_A",
        ADMIN_WEB_TOKEN="SECRET_B",
        SCAN_CHAINS="solana,bsc",
    )

    g = ConfigIntegrityGuard(
        f,
        tmp_path / "state",
    )

    g.mark_healthy()

    assert g.report()["status"] == "OK"


def test_secret_is_not_exposed(tmp_path):
    f = tmp_path / "config.env"

    env(
        f,
        TELEGRAM_BOT_TOKEN="SUPER_SECRET_OLD",
        ADMIN_WEB_TOKEN="ADMIN_SECRET",
    )

    g = ConfigIntegrityGuard(
        f,
        tmp_path / "state",
    )

    g.mark_healthy()

    env(
        f,
        TELEGRAM_BOT_TOKEN="SUPER_SECRET_NEW",
        ADMIN_WEB_TOKEN="ADMIN_SECRET",
    )

    raw = str(g.report())

    assert "SUPER_SECRET_OLD" not in raw
    assert "SUPER_SECRET_NEW" not in raw


def test_removed_critical_blocks(tmp_path):
    f = tmp_path / "config.env"

    env(
        f,
        TELEGRAM_BOT_TOKEN="TOKEN",
        ADMIN_WEB_TOKEN="ADMIN",
    )

    g = ConfigIntegrityGuard(
        f,
        tmp_path / "state",
    )

    g.mark_healthy()

    env(
        f,
        TELEGRAM_BOT_TOKEN="",
        ADMIN_WEB_TOKEN="ADMIN",
    )

    result = g.preflight("restart")

    assert result["allowed"] is False
    assert result["critical_missing_count"] >= 1
