from csm.quality_promotion import (
    assess_quality_promotion,
)


def test_good_evidence_is_review_only():
    r = assess_quality_promotion({
        "samples": 100,
        "win_rate_pct": 62,
        "average_return_pct": 4.5,
        "shadow_coverage_pct": 80,
    })

    assert r["eligible_for_review"] is True
    assert r["promotion_enabled"] is False
    assert r["mode"] == "REVIEW_ONLY"


def test_weak_evidence_stays_shadow():
    r = assess_quality_promotion({
        "samples": 20,
        "win_rate_pct": 30,
        "average_return_pct": -2,
        "shadow_coverage_pct": 10,
    })

    assert r["eligible_for_review"] is False
    assert r["promotion_enabled"] is False
    assert r["status"] == "SHADOW_LEARNING"
