import csm
import phantom_v10

from csm.quality_promotion import (
    assess_quality_promotion,
)


def test_v1649_versions():
    assert (
        csm.__product_version__
        == "16.6.0-signal-outcome-learning"
    )

    assert (
        phantom_v10.__version__
        == "16.6.0-retool-admin-speechify"
    )


def test_live_never_automatic():
    report = assess_quality_promotion({
        "samples": 1000,
        "win_rate_pct": 90,
        "average_return_pct": 20,
        "shadow_coverage_pct": 100,
    })

    assert report["eligible_for_review"] is True
    assert report["promotion_enabled"] is False
    assert report["mode"] == "REVIEW_ONLY"
