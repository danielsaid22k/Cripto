from csm.signal_quality_intelligence import (
    analyze_signal_quality,
    probable_loss_reasons,
    shadow_quality_decision,
)


def test_quality_analysis():
    rows = [
        {
            "chain": "solana",
            "provider": "birdeye",
            "score": 84,
            "liquidity_usd": 250000,
            "volume_24h_usd": 180000,
            "buy_pressure_pct": 63,
            "provider_count": 2,
            "return_pct": 12,
        },
        {
            "chain": "bsc",
            "provider": "dexscreener",
            "score": 64,
            "liquidity_usd": 30000,
            "volume_24h_usd": 12000,
            "buy_pressure_pct": 42,
            "provider_count": 1,
            "return_pct": -8,
        },
    ]

    report = analyze_signal_quality(rows)

    assert report["samples"] == 2
    assert report["wins"] == 1
    assert report["losses"] == 1
    assert report["win_rate_pct"] == 50.0
    assert report["mode"] == "SHADOW"
    assert report["promotion_enabled"] is False
    assert report["shadow_approved"] == 1
    assert report["shadow_rejected"] == 1


def test_loss_reasons():
    row = {
        "score": 60,
        "liquidity_usd": 20000,
        "volume_24h_usd": 10000,
        "buy_pressure_pct": 40,
        "provider_count": 1,
    }

    reasons = probable_loss_reasons(row)

    assert "LOW_SCORE" in reasons
    assert "LOW_LIQUIDITY" in reasons
    assert "LOW_VOLUME" in reasons
    assert "WEAK_BUY_PRESSURE" in reasons
    assert "SINGLE_PROVIDER" in reasons


def test_shadow_does_not_promote():
    result = shadow_quality_decision({
        "score": 65,
        "liquidity_usd": 20000,
        "volume_24h_usd": 10000,
        "buy_pressure_pct": 45,
        "provider_count": 1,
    })

    assert result["mode"] == "SHADOW"
    assert result["approved"] is False
    assert result["would_block"] is True
