import csm
import phantom_v10

from csm.shadow_evidence_accelerator import (
    evidence_health,
)
from csm.quality_promotion import (
    assess_quality_promotion,
)


def test_v1650_versions():
    assert (
        csm.__product_version__
        == "16.6.0-signal-outcome-learning"
    )

    assert (
        csm.__version__
        == "8.3.1-ashell-single-runtime"
    )

    assert (
        phantom_v10.__version__
        == "16.6.0-retool-admin-speechify"
    )


def test_shadow_maturity():
    report = evidence_health(
        total=200,
        confirmed=50,
    )

    assert report["status"] == "MATURE"
    assert report["coverage_pct"] == 25.0


def test_live_still_never_automatic():
    promotion = assess_quality_promotion({
        "samples": 1000,
        "win_rate_pct": 90,
        "average_return_pct": 25,
        "shadow_coverage_pct": 100,
    })

    assert (
        promotion["promotion_enabled"]
        is False
    )

    assert (
        promotion["mode"]
        == "REVIEW_ONLY"
    )
