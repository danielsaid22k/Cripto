from csm.shadow_evidence_accelerator import (
    build_recovery_plan,
    classify_shadow_age,
    evidence_health,
)


def test_shadow_age_states():
    assert classify_shadow_age(200) == "WAITING"
    assert classify_shadow_age(300) == "DUE"
    assert classify_shadow_age(470) == "DUE"
    assert classify_shadow_age(500) == "LATE"


def test_recovery_only_uses_valid_window():
    now = 1000

    rows = [
        {
            "signal_id": "A",
            "created_at": 800,
        },
        {
            "signal_id": "B",
            "created_at": 650,
        },
        {
            "signal_id": "C",
            "created_at": 400,
        },
    ]

    report = build_recovery_plan(
        rows,
        now_ts=now,
    )

    assert report["waiting"] == 1
    assert report["due"] == 1
    assert report["late"] == 1

    assert report["recovery_batch_size"] == 1
    assert (
        report["recovery_batch"][0]["signal_id"]
        == "B"
    )


def test_duplicate_signal_not_reprocessed():
    rows = [
        {
            "signal_id": "X",
            "created_at": 650,
        },
        {
            "signal_id": "X",
            "created_at": 650,
        },
    ]

    report = build_recovery_plan(
        rows,
        now_ts=1000,
    )

    assert report["pending_total"] == 1


def test_health_maturity():
    early = evidence_health(
        total=120,
        confirmed=5,
    )

    assert early["status"] == "EARLY"

    mature = evidence_health(
        total=200,
        confirmed=50,
    )

    assert mature["status"] == "MATURE"
    assert mature["coverage_pct"] == 25.0
