import json

from csm.shadow_evidence_overview import (
    attach_shadow_evidence,
)


def test_evidence_is_attached(tmp_path):
    root = tmp_path
    folder = root / "shadow_evidence"
    folder.mkdir()

    (folder / "queue_status.json").write_text(
        json.dumps({
            "queue_size": 12,
            "waiting": 5,
            "due": 4,
            "late": 3,
            "unknown": 0,
            "by_chain": {
                "solana": 7,
                "bsc": 5,
            },
            "by_provider": {
                "birdeye": 6,
                "dexscreener": 6,
            },
        }),
        encoding="utf-8",
    )

    report = attach_shadow_evidence(
        {
            "samples": 121,
            "shadow_confirmed": 5,
            "mode": "SHADOW",
        },
        state_dir=root,
    )

    evidence = report["shadow_evidence"]

    assert evidence["total"] == 121
    assert evidence["confirmed"] == 5
    assert evidence["status"] == "EARLY"

    assert evidence["queue"]["size"] == 12
    assert evidence["queue"]["due"] == 4

    assert evidence["live_impact"] is False


def test_missing_queue_is_safe(tmp_path):
    report = attach_shadow_evidence(
        {
            "samples": 100,
            "shadow_confirmed": 25,
        },
        state_dir=tmp_path,
    )

    assert (
        report["shadow_evidence"]
        ["queue"]["size"]
        == 0
    )

    assert (
        report["shadow_evidence"]
        ["status"]
        == "GROWING"
    )
