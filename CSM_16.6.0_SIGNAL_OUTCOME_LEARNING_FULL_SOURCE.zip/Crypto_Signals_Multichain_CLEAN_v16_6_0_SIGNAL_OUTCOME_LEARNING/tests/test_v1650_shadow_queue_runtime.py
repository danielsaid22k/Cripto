from csm.shadow_evidence_runtime import (
    prioritize_shadow_queue,
    queue_status,
)


def test_due_is_prioritized():
    queue = [
        {
            "signal_id": "waiting",
            "created_at": 900,
        },
        {
            "signal_id": "due",
            "created_at": 650,
        },
        {
            "signal_id": "late",
            "created_at": 300,
        },
    ]

    result = prioritize_shadow_queue(
        queue,
        now_ts=1000,
    )

    assert result[0]["signal_id"] == "due"
    assert result[-1]["signal_id"] == "late"


def test_queue_status_tracks_chain_provider():
    queue = [
        {
            "signal_id": "A",
            "created_at": 650,
            "chain": "solana",
            "provider": "birdeye",
        },
        {
            "signal_id": "B",
            "created_at": 650,
            "chain": "bsc",
            "provider": "dexscreener",
        },
    ]

    report = queue_status(
        queue,
        now_ts=1000,
    )

    assert report["queue_size"] == 2
    assert report["due"] == 2
    assert report["by_chain"]["solana"] == 1
    assert report["by_provider"]["birdeye"] == 1
