from csm.evidence_attribution import (
    analyze_evidence_attribution,
    score_band,
)


def test_score_band():
    assert score_band(95) == "90-100"
    assert score_band(85) == "80-89"
    assert score_band(75) == "70-79"
    assert score_band(65) == "60-69"
    assert score_band(50) == "<60"


def test_only_confirmed_rows_are_used():
    rows = [
        {
            "chain": "solana",
            "provider": "birdeye",
            "score": 85,
            "shadow_confirmed": True,
            "shadow_return_pct": 10,
        },
        {
            "chain": "bsc",
            "provider": "dexscreener",
            "score": 70,
            "shadow_confirmed": False,
        },
    ]

    report = analyze_evidence_attribution(
        rows,
        minimum_samples=1,
    )

    assert report["confirmed_samples"] == 1
    assert report["by_chain"][0]["name"] == "solana"


def test_best_and_worst_require_evidence():
    rows = [
        {
            "chain": "solana",
            "provider": "birdeye",
            "shadow_confirmed": True,
            "shadow_return_pct": 10,
        },
        {
            "chain": "solana",
            "provider": "birdeye",
            "shadow_confirmed": True,
            "shadow_return_pct": 5,
        },
        {
            "chain": "bsc",
            "provider": "dexscreener",
            "shadow_confirmed": True,
            "shadow_return_pct": -5,
        },
        {
            "chain": "bsc",
            "provider": "dexscreener",
            "shadow_confirmed": True,
            "shadow_return_pct": -10,
        },
    ]

    report = analyze_evidence_attribution(
        rows,
        minimum_samples=2,
    )

    assert report["best_chain"]["name"] == "solana"
    assert report["worst_chain"]["name"] == "bsc"
    assert report["best_provider"]["name"] == "birdeye"
    assert report["worst_provider"]["name"] == "dexscreener"
    assert report["live_impact"] is False
