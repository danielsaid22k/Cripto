from csm.evidence_attribution_runtime import (
    attach_evidence_attribution,
    collect_evidence_rows,
)


def test_collects_real_evidence_rows():
    performance = {
        "anything": {
            "rows": [
                {
                    "signal_id": "A",
                    "chain": "solana",
                    "provider": "birdeye",
                    "shadow_confirmed": True,
                    "shadow_return_pct": 10,
                },
                {
                    "signal_id": "B",
                    "chain": "bsc",
                    "provider": "dexscreener",
                    "shadow_confirmed": False,
                    "shadow_return_pct": -5,
                },
            ]
        }
    }

    rows = collect_evidence_rows(performance)

    assert len(rows) == 2


def test_explicit_unconfirmed_is_not_counted():
    performance = {
        "rows": [
            {
                "signal_id": "A",
                "chain": "solana",
                "provider": "birdeye",
                "shadow_confirmed": True,
                "shadow_return_pct": 10,
            },
            {
                "signal_id": "B",
                "chain": "bsc",
                "provider": "dexscreener",
                "shadow_confirmed": False,
                "shadow_return_pct": -20,
            },
        ]
    }

    quality = attach_evidence_attribution(
        {
            "mode": "SHADOW",
            "by_chain": [],
            "by_provider": [],
        },
        performance,
    )

    attr = quality["evidence_attribution"]

    assert attr["confirmed_samples"] == 1
    assert quality["by_chain"][0]["name"] == "solana"
    assert quality["attribution_live_impact"] is False


def test_no_evidence_does_not_fake_rankings():
    quality = attach_evidence_attribution(
        {
            "mode": "SHADOW",
            "by_chain": [],
            "by_provider": [],
        },
        {
            "summary": {
                "signals_total": 100,
            }
        },
    )

    assert quality["by_chain"] == []
    assert quality["by_provider"] == []

    assert (
        quality["evidence_attribution"]
        ["confirmed_samples"]
        == 0
    )
