import csm
import phantom_v10

from csm.evidence_attribution import (
    analyze_evidence_attribution,
)


def test_v1651_versions():
    assert (
        csm.__product_version__
        == "16.6.0-signal-outcome-learning"
    )

    assert (
        csm.__version__
        == "8.3.1-ashell-single-runtime"
    )

    assert (
        phantom_v10.__version__
        == "16.6.0-retool-admin-speechify"
    )


def test_attribution_remains_shadow_only():
    report = analyze_evidence_attribution(
        [
            {
                "chain": "solana",
                "provider": "birdeye",
                "shadow_confirmed": True,
                "shadow_return_pct": 10,
            }
        ],
        minimum_samples=1,
    )

    assert report["mode"] == "SHADOW"
    assert report["live_impact"] is False
