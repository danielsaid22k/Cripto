from csm.config_change_history import (
    classify_origin,
    normalize_audit_event,
)


def test_setup_origin():
    assert (
        classify_origin([
            "python /home/csm-supervisor/setup_config.py"
        ])
        == "SETUP_CENTER"
    )


def test_retool_origin():
    assert (
        classify_origin([
            "python csm/admin_web.py retool"
        ])
        == "ADMIN_RETOOL"
    )


def test_unknown_origin():
    assert classify_origin([]) == "UNKNOWN"


def test_event_never_contains_secret_value():
    event = normalize_audit_event({
        "time": "2026-08-29T20:00:00+00:00",
        "changed": {
            "TELEGRAM_BOT_TOKEN": {
                "before": {
                    "present": True,
                    "fp": "abc123",
                    "length": 45,
                },
                "after": {
                    "present": True,
                    "fp": "def456",
                    "length": 46,
                },
            }
        },
        "process_context": [],
    })

    text = str(event)

    assert "TELEGRAM_BOT_TOKEN" in text
    assert event["origin"] == "UNKNOWN"
    assert event["safety"]
