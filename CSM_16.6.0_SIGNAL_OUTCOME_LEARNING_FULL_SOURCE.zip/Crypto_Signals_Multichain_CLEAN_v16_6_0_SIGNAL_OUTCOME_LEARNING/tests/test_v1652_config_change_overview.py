import json

import csm.config_change_history as history


def test_empty_history_is_stable(
    tmp_path,
    monkeypatch,
):
    path = tmp_path / "history.jsonl"

    monkeypatch.setattr(
        history,
        "HISTORY_FILE",
        path,
    )

    result = history.overview_status()

    assert result["status"] == "STABLE"
    assert result["events"] == 0
    assert (
        result["secret_values_stored"]
        is False
    )
    assert (
        result["automatic_restore"]
        is False
    )


def test_unknown_change_requires_review(
    tmp_path,
    monkeypatch,
):
    path = tmp_path / "history.jsonl"

    event = {
        "event_id": "abc",
        "time": "2026-08-29T20:00:00+00:00",
        "version": "16.5.2",
        "event": "CONFIG_CHANGED",
        "origin": "UNKNOWN",
        "keys": [
            "TELEGRAM_BOT_TOKEN",
        ],
    }

    path.write_text(
        json.dumps(event) + "\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        history,
        "HISTORY_FILE",
        path,
    )

    result = history.overview_status()

    assert result["status"] == "REVIEW"
    assert result["events"] == 1


def test_known_change_is_identified(
    tmp_path,
    monkeypatch,
):
    path = tmp_path / "history.jsonl"

    event = {
        "event_id": "def",
        "time": "2026-08-29T20:00:00+00:00",
        "version": "16.5.2",
        "event": "CONFIG_CHANGED",
        "origin": "SETUP_CENTER",
        "keys": [
            "TELEGRAM_CHAT_ID",
        ],
    }

    path.write_text(
        json.dumps(event) + "\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        history,
        "HISTORY_FILE",
        path,
    )

    result = history.overview_status()

    assert result["status"] == "KNOWN_CHANGE"
