from __future__ import annotations

from pathlib import Path


def test_v1653_release_versions():
    import csm
    import phantom_v10

    assert csm.__version__ == "8.3.1-ashell-single-runtime"
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"


def test_v1653_runtime_resilience_files_present():
    assert Path("csm/runtime_resilience.py").is_file()
    assert Path("install_runtime_resilience_termux.sh").is_file()
    assert Path("CSM_V16_5_3_RUNTIME_RESILIENCE.md").is_file()


def test_v1653_does_not_bump_daniel_ai():
    import daniel_ai

    assert daniel_ai.__version__ == "1.3.1"
