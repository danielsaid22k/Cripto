from __future__ import annotations

from pathlib import Path


def test_retool_runtime_uses_v10_liveness_when_tmux_is_missing(monkeypatch):
    import csm.retool_control as rc
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(rc, "_tmux_has_session", lambda name: False)
    monkeypatch.setattr(rc, "_tmux_pane_pid", lambda name: None)
    monkeypatch.setattr(
        rc,
        "_http_probe",
        lambda url, timeout=0.8: {
            "ok": True,
            "http_status": 200,
            "latency_ms": 4.2,
            "error": None,
        },
    )
    monkeypatch.setattr(
        runtime,
        "runtime_state",
        lambda name="bot", stale_after=60.0: {
            "healthy": True,
            "session": "abc123",
            "state": "running",
            "heartbeat_age_seconds": 1.0,
            "lock_exists": True,
            "session_exists": True,
            "pid_diagnostic_only": 4321,
            "pid_alive": True,
            "lease_alive": True,
        },
    )

    data = rc.runtime_snapshot()

    assert data["runtime_state"] == "running"
    assert data["process_active"] is True
    assert data["bot_healthy"] is True
    assert data["saas_api_healthy"] is True
    assert data["health_score"] == 100
    assert data["liveness_source"] == "v10-lease-session-heartbeat"
    assert data["release"] == "16.6.0-signal-outcome-learning"


def test_retool_runtime_does_not_hide_stale_v10_liveness_with_tmux(monkeypatch):
    import csm.retool_control as rc
    import phantom_v10.runtime as runtime

    monkeypatch.setattr(rc, "_tmux_has_session", lambda name: name == "csm-bot")
    monkeypatch.setattr(rc, "_tmux_pane_pid", lambda name: 9999)
    monkeypatch.setattr(
        rc,
        "_http_probe",
        lambda url, timeout=0.8: {
            "ok": True,
            "http_status": 200,
            "latency_ms": 2.0,
            "error": None,
        },
    )
    monkeypatch.setattr(
        runtime,
        "runtime_state",
        lambda name="bot", stale_after=60.0: {
            "healthy": False,
            "session": "stale",
            "state": "running",
            "heartbeat_age_seconds": 120.0,
            "lock_exists": True,
            "session_exists": True,
            "pid_diagnostic_only": 9999,
            "pid_alive": True,
            "lease_alive": False,
        },
    )

    data = rc.runtime_snapshot()

    assert data["runtime_state"] == "degraded"
    assert data["process_active"] is True
    assert data["bot_healthy"] is False
    assert data["saas_api_healthy"] is True
    assert data["health_score"] == 40
    assert data["runtime_health_reason"] == "bot_liveness_not_healthy"


def test_runtime_resilience_overview_aggregates_expected_components(monkeypatch):
    import csm.runtime_resilience as rr

    healthy = lambda name: rr._component(name, "HEALTHY", expected=True)

    monkeypatch.setattr(
        rr,
        "_supervisor_component",
        lambda: (healthy("supervisor"), {"ok": True, "desired_state": {}}),
    )
    monkeypatch.setattr(
        rr,
        "_runtime_components",
        lambda runtime_override=None, desired_state=None: (healthy("bot"), healthy("saas_api"), {"runtime_state": "running"}),
    )
    monkeypatch.setattr(
        rr,
        "_admin_bridge_component",
        lambda current_admin_bridge=False, expected=True: healthy("admin_bridge"),
    )
    monkeypatch.setattr(
        rr,
        "_ngrok_component",
        lambda payload: rr._component("ngrok", "NOT_CONFIGURED", expected=False),
    )
    monkeypatch.setattr(
        rr,
        "_auditor_component",
        lambda: rr._component("config_auditor", "NOT_CONFIGURED", expected=False),
    )

    data = rr.collect_components(current_admin_bridge=True)

    assert data["state"] == "HEALTHY"
    assert data["health_score"] == 100
    assert data["automatic_recovery_policy"]["config_changes_allowed"] is False
    assert data["automatic_recovery_policy"]["secret_values_logged"] is False


def test_runtime_resilience_restart_storm_budget_blocks_fourth_attempt(tmp_path, monkeypatch):
    import csm.runtime_resilience as rr

    now = 10_000.0
    state = {
        "components": {
            "runtime_core": {
                "last_attempt": now - 100,
                "restart_attempts": [now - 400, now - 300, now - 200],
            }
        }
    }

    allowed, attempts = rr._restart_budget(state, "runtime_core", now)

    assert allowed is False
    assert len(attempts) == rr.MAX_RESTARTS_PER_WINDOW


def test_retool_overview_exposes_runtime_resilience():
    source = Path("csm/admin_web.py").read_text(encoding="utf-8")
    assert '"runtime_resilience": resilience_data' in source
    assert 'resilience_data = runtime_resilience_overview(' in source
    assert "current_admin_bridge=True" in source


def test_retool_overview_normalizes_runtime_card_display_fields():
    source = Path("csm/admin_web.py").read_text(encoding="utf-8")
    assert 'leader_data["audit_release"] = leader_data.get("release")' in source
    assert 'leader_data["release"] = runtime_data.get("release")' in source
    assert 'leader_data["health_score"] = runtime_data.get("health_score")' in source


def test_runtime_resilience_respects_supervisor_desired_stop(monkeypatch):
    import csm.runtime_resilience as rr

    supervisor = rr._component("supervisor", "HEALTHY", expected=True)
    monkeypatch.setattr(
        rr,
        "_supervisor_component",
        lambda: (
            supervisor,
            {
                "ok": True,
                "desired_state": {
                    "bot": "stopped",
                    "api": "stopped",
                    "admin_bridge": "stopped",
                    "ngrok": "stopped",
                },
            },
        ),
    )
    monkeypatch.setattr(
        rr,
        "_admin_bridge_component",
        lambda current_admin_bridge=False, expected=True: rr._component(
            "admin_bridge", "STOPPED", expected=expected
        ),
    )
    monkeypatch.setattr(
        rr,
        "_ngrok_component",
        lambda payload: rr._component("ngrok", "NOT_CONFIGURED", expected=False),
    )
    monkeypatch.setattr(
        rr,
        "_auditor_component",
        lambda: rr._component("config_auditor", "NOT_CONFIGURED", expected=False),
    )

    runtime = {
        "bot_healthy": False,
        "process_active": False,
        "saas_api_healthy": False,
        "saas_api_process_present": False,
        "tmux_api": False,
        "runtime_state": "stopped",
    }
    data = rr.collect_components(runtime_override=runtime)

    assert data["components"]["bot"]["expected"] is False
    assert data["components"]["saas_api"]["expected"] is False
    assert data["components"]["admin_bridge"]["expected"] is False
    assert data["health_score"] == 100
    assert data["state"] == "HEALTHY"


def test_runtime_resilience_suppresses_recovery_during_maintenance(monkeypatch):
    import csm.project_leader as pl
    import csm.runtime_resilience as rr

    unhealthy = {
        "state": "FAILED",
        "health_score": 0,
        "components": {
            "bot": rr._component("bot", "DOWN", expected=True, recovery_supported=True),
            "saas_api": rr._component("saas_api", "DOWN", expected=True, recovery_supported=True),
            "supervisor": rr._component("supervisor", "HEALTHY", expected=True, recovery_supported=True),
            "admin_bridge": rr._component("admin_bridge", "DOWN", expected=True, recovery_supported=True),
            "ngrok": rr._component("ngrok", "NOT_CONFIGURED", expected=False),
            "config_auditor": rr._component("config_auditor", "NOT_CONFIGURED", expected=False),
        },
    }

    monkeypatch.setattr(rr, "collect_components", lambda **kwargs: dict(unhealthy))
    monkeypatch.setattr(rr, "_read_state", lambda: {})
    monkeypatch.setattr(rr, "_write_state", lambda state: None)

    class FakeLeader:
        def maintenance(self):
            return {"active": True, "reason": "update_in_progress"}

    monkeypatch.setattr(pl, "ProjectLeader", FakeLeader)
    monkeypatch.setattr(
        rr,
        "_recover_admin_bridge",
        lambda: (_ for _ in ()).throw(AssertionError("must not recover during maintenance")),
    )
    monkeypatch.setattr(
        rr,
        "_recover_runtime_core",
        lambda: (_ for _ in ()).throw(AssertionError("must not recover during maintenance")),
    )

    data = rr.watch_once(recover=True)

    assert data["recovery_enabled"] is False
    assert any(item.get("result") == "maintenance_active" for item in data["actions"])
