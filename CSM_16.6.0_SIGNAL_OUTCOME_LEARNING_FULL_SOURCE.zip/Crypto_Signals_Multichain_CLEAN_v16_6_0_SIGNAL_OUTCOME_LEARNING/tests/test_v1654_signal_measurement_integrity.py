from datetime import datetime, timedelta, timezone

from csm.performance import PerformanceLedger
from csm.storage import Storage


def _signal(address="v1654"):
    return {
        "chain": "solana", "address": address, "symbol": "MINT", "name": "Measure",
        "price": 1.0, "liquidity": 100000, "volume24h": 500000, "marketcap": 1000000,
        "buys24h": 60, "sells24h": 40, "source": "DexScreener", "final_score": 85,
    }

def _market(price):
    return {
        "price": price, "liquidity": 101000, "volume24h": 510000, "marketcap": 1010000,
        "buys24h": 62, "sells24h": 38, "source": "DexScreener", "score": 86,
    }

def test_baseline_never_counts_as_5m(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "db.sqlite") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal(), "premium", now=now)
        assert ledger.record_observation(sid, _market(1.0), captured_at=now + timedelta(seconds=3))
        report = ledger.report(days=1)
        assert report["horizons"]["5m"]["samples"] == 0
        assert ledger.record_shadow_observation(sid, _market(1.1), captured_at=now + timedelta(seconds=310))
        report = ledger.report(days=1)
        assert report["horizons"]["5m"]["samples"] == 1
        assert report["horizons"]["5m"]["average_return_pct"] == 10.0

def test_complete_signal_remains_shadow_eligible(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "db.sqlite") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal("closed"), "premium", now=now)
        storage.conn.execute("UPDATE signal_ledger SET status='COMPLETE', lifecycle_state='STOPPED' WHERE id=?", (sid,))
        storage.conn.commit()
        due = ledger.shadow_due_signals(now=now + timedelta(seconds=320), target_seconds=300, grace_seconds=180)
        assert [row["id"] for row in due] == [sid]

def test_shadow_capture_does_not_mutate_lifecycle(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "db.sqlite") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal("pure-shadow"), "premium", now=now)
        before = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        assert ledger.record_shadow_observation(sid, _market(0.5), captured_at=now + timedelta(seconds=310))
        after = dict(storage.conn.execute("SELECT * FROM signal_ledger WHERE id=?", (sid,)).fetchone())
        for key in ("status", "lifecycle_state", "first_stop_at", "first_tp1_at", "last_return_pct", "observations"):
            assert after.get(key) == before.get(key)
        obs = storage.conn.execute("SELECT observation_kind,age_seconds FROM signal_observations WHERE signal_id=? ORDER BY id DESC LIMIT 1", (sid,)).fetchone()
        assert obs["observation_kind"] == "shadow"
        assert 300 <= obs["age_seconds"] <= 480

def test_queue_snapshot_reports_recent_late_without_active_bias(tmp_path):
    now = datetime.now(timezone.utc)
    with Storage(tmp_path / "db.sqlite") as storage:
        ledger = PerformanceLedger(storage)
        sid = ledger.record_signal(_signal("late"), "premium", now=now - timedelta(minutes=10))
        storage.conn.execute("UPDATE signal_ledger SET status='COMPLETE', lifecycle_state='STOPPED' WHERE id=?", (sid,))
        storage.conn.commit()
        q = ledger.shadow_queue_snapshot(now=now, hours=24, target_seconds=300, grace_seconds=180)
        assert q["late"] == 1
        assert q["queue_size"] == 1
        assert q["source"] == "ledger_recent"
