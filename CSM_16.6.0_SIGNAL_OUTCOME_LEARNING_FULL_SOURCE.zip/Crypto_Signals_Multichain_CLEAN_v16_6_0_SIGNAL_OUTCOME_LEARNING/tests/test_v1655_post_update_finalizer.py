from __future__ import annotations

import json
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import csm
import phantom_v10
from csm import post_update
from csm.admin_web import AdminHandler


def _isolated(monkeypatch, tmp_path):
    monkeypatch.setattr(post_update, "_root", lambda: tmp_path)
    monkeypatch.setattr(post_update, "_log_file", lambda: tmp_path / "post_update.log")


def test_release_is_v1655():
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"


def test_finalizer_blocks_before_restart_when_validation_fails(monkeypatch, tmp_path):
    _isolated(monkeypatch, tmp_path)
    called = {"runtime": 0, "admin": 0}

    def fake_cli(command, **kwargs):
        return {"ok": command != "db-check", "returncode": 0 if command != "db-check" else 1, "output": command}

    monkeypatch.setattr(post_update, "_run_cli", fake_cli)
    monkeypatch.setattr(post_update, "_runtime_restart_step", lambda: called.__setitem__("runtime", called["runtime"] + 1) or {"ok": True})
    monkeypatch.setattr(post_update, "_admin_bridge_restart_step", lambda: called.__setitem__("admin", called["admin"] + 1) or {"ok": True})

    report = post_update.run()
    assert report["status"] == "BLOCKED"
    assert report["blocked_by"] == "db_check"
    assert called == {"runtime": 0, "admin": 0}


def test_finalizer_runs_restart_only_after_all_validations(monkeypatch, tmp_path):
    _isolated(monkeypatch, tmp_path)
    order = []

    def fake_cli(command, **kwargs):
        order.append(command)
        return {"ok": True, "returncode": 0, "output": command}

    monkeypatch.setattr(post_update, "_migrate_in_place_step", lambda: order.append("migrate-in-place") or {"ok": True, "mode": "in_place_only"})
    monkeypatch.setattr(post_update, "_run_cli", fake_cli)
    monkeypatch.setattr(post_update, "_version_step", lambda: order.append("version") or {"ok": True})
    monkeypatch.setattr(post_update, "_config_integrity_step", lambda: order.append("config") or {"ok": True})
    monkeypatch.setattr(post_update, "_runtime_restart_step", lambda: order.append("runtime") or {"ok": True, "runtime_healthy": True})
    monkeypatch.setattr(post_update, "_admin_bridge_restart_step", lambda: order.append("admin") or {"ok": True})

    report = post_update.run()
    assert report["status"] == "APPROVED"
    assert order == ["migrate-in-place", "db-check", "selftest", "release-check", "version", "config", "runtime", "admin"]


def test_finalizer_can_skip_restarts_for_diagnostics(monkeypatch, tmp_path):
    _isolated(monkeypatch, tmp_path)
    monkeypatch.setattr(post_update, "_run_cli", lambda *a, **k: {"ok": True, "returncode": 0, "output": "ok"})
    monkeypatch.setattr(post_update, "_version_step", lambda: {"ok": True})
    monkeypatch.setattr(post_update, "_config_integrity_step", lambda: {"ok": True})
    report = post_update.run(restart_runtime=False, restart_admin_bridge=False)
    assert report["status"] == "APPROVED"
    assert report["steps"]["runtime_restart"]["skipped"] is True
    assert report["steps"]["admin_bridge_restart"]["skipped"] is True


def test_status_reads_last_report(monkeypatch, tmp_path):
    _isolated(monkeypatch, tmp_path)
    (tmp_path / "last_report.json").write_text(json.dumps({"status": "APPROVED"}), encoding="utf-8")
    data = post_update.status()
    assert data["report"]["status"] == "APPROVED"
    assert data["running"] is False


def test_openapi_contains_finalize_endpoints():
    root = Path(__file__).resolve().parents[1]
    spec = json.loads((root / "retool" / "CSM_RETOOL_OPENAPI.json").read_text(encoding="utf-8"))
    assert spec["info"]["version"] == "16.6.0"
    assert "/api/update/finalize" in spec["paths"]
    assert "/api/update/finalize/status" in spec["paths"]


def test_retool_finalize_status_endpoint(monkeypatch, tmp_path):
    _isolated(monkeypatch, tmp_path)
    (tmp_path / "last_report.json").write_text(json.dumps({"status": "APPROVED"}), encoding="utf-8")
    server = ThreadingHTTPServer(("127.0.0.1", 0), AdminHandler)
    server.admin_token = "unit-secret"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        req = Request(
            f"http://127.0.0.1:{server.server_port}/api/update/finalize/status",
            headers={"Authorization": "Bearer unit-secret"},
        )
        with urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        assert data["ok"] is True
        assert data["report"]["status"] == "APPROVED"
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=3)


def test_retool_finalize_post_accepts_background_job(monkeypatch):
    monkeypatch.setattr(post_update, "launch_background", lambda **kwargs: {"ok": True, "accepted": True, "pid": 123, "status_endpoint": "/api/update/finalize/status"})
    server = ThreadingHTTPServer(("127.0.0.1", 0), AdminHandler)
    server.admin_token = "unit-secret"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        req = Request(
            f"http://127.0.0.1:{server.server_port}/api/update/finalize",
            data=b"{}",
            method="POST",
            headers={"Authorization": "Bearer unit-secret", "Content-Type": "application/json"},
        )
        with urlopen(req, timeout=3) as resp:
            assert resp.status == 202
            data = json.loads(resp.read().decode("utf-8"))
        assert data["accepted"] is True
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=3)
