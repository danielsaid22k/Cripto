from __future__ import annotations

from pathlib import Path

import csm
import phantom_v10
from csm import post_update


def _isolated(monkeypatch, tmp_path):
    monkeypatch.setattr(post_update, "_root", lambda: tmp_path)
    monkeypatch.setattr(post_update, "_log_file", lambda: tmp_path / "post_update.log")


def test_release_is_v1656():
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"


def test_finalizer_uses_in_place_migration_not_legacy_cli(monkeypatch, tmp_path):
    _isolated(monkeypatch, tmp_path)
    calls = []
    monkeypatch.setattr(post_update, "_migrate_in_place_step", lambda: calls.append("in_place") or {"ok": True, "mode": "in_place_only", "auto_restore_previous": False})
    monkeypatch.setattr(post_update, "_run_cli", lambda command, **kwargs: calls.append(command) or {"ok": True, "returncode": 0, "output": command})
    monkeypatch.setattr(post_update, "_version_step", lambda: {"ok": True})
    monkeypatch.setattr(post_update, "_config_integrity_step", lambda: {"ok": True})
    report = post_update.run(restart_runtime=False, restart_admin_bridge=False)
    assert report["status"] == "APPROVED"
    assert calls[0] == "in_place"
    assert "migrate" not in calls
    assert report["steps"]["migrate"]["auto_restore_previous"] is False


def test_runtime_health_wait_retries_until_api_is_ready(monkeypatch):
    snapshots = [
        {"bot_healthy": True, "saas_api_healthy": False, "runtime_health_reason": "saas_api_healthz_not_healthy"},
        {"bot_healthy": True, "saas_api_healthy": False, "runtime_health_reason": "saas_api_healthz_not_healthy"},
        {"bot_healthy": True, "saas_api_healthy": True, "health_score": 100},
    ]
    import csm.retool_control as rc
    monkeypatch.setattr(rc, "runtime_snapshot", lambda: snapshots.pop(0))
    monkeypatch.setattr(post_update.time, "sleep", lambda _x: None)
    result = post_update._wait_for_runtime_health(timeout_seconds=5, interval_seconds=0.2)
    assert result["ok"] is True
    assert result["attempts"] == 3
    assert result["runtime"]["health_score"] == 100


def test_runtime_restart_accepts_supervisor_then_waits(monkeypatch):
    import csm.retool_control as rc
    monkeypatch.setattr(rc, "restart_bot", lambda: {"ok": False, "supervisor": {"ok": True}, "runtime": {"bot_healthy": True, "saas_api_healthy": False}})
    monkeypatch.setattr(post_update, "_wait_for_runtime_health", lambda **kwargs: {"ok": True, "attempts": 2, "wait_seconds": 2.0, "runtime": {"bot_healthy": True, "saas_api_healthy": True, "health_score": 100, "release": "16.6.0-signal-outcome-learning"}})
    result = post_update._runtime_restart_step()
    assert result["ok"] is True
    assert result["runtime_healthy"] is True
    assert result["health_wait"]["attempts"] == 2
