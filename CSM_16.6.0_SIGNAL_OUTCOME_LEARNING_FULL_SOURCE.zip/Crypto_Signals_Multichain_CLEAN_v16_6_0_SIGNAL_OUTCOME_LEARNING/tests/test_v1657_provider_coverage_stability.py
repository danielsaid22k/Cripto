from __future__ import annotations

from csm.config import settings
from csm.logging_setup import redact
from phantom_v10.discovery import MultiProviderDiscovery, dexpaprika_rows
from phantom_v10.market import MarketService
from phantom_v10.providers import ProviderGateway


class CreditsExhausted(RuntimeError):
    status = 402


def test_dexpaprika_parser_reads_chain_and_address():
    rows = dexpaprika_rows({"results": [
        {"chain": "bsc", "address": "0xabc", "liquidity_usd": 50000},
        {"chain": "bsc", "address": "0xabc"},
        {"chain": "base", "address": "0xdef"},
    ]})
    assert rows == [("bsc", "0xabc"), ("base", "0xdef")]


def test_dexpaprika_is_additive_plus_source_and_not_free():
    old_enabled = settings.dexpaprika_enabled
    old_multi = settings.multi_provider_enabled
    old_base = settings.dexpaprika_base_url
    old_count = settings.dexpaprika_chain_sources
    try:
        object.__setattr__(settings, "dexpaprika_enabled", True)
        object.__setattr__(settings, "multi_provider_enabled", True)
        object.__setattr__(settings, "dexpaprika_base_url", "https://api.dexpaprika.com")
        object.__setattr__(settings, "dexpaprika_chain_sources", 1)
        free = MultiProviderDiscovery().sources("free", ("solana", "bsc"))
        assert not any(row.provider == "dexpaprika" for row in free)
        plus = MultiProviderDiscovery().sources("plus", ("solana", "bsc"))
        dp = [row for row in plus if row.provider == "dexpaprika"]
        assert len(dp) == 1
        assert dp[0].url.startswith("https://api.dexpaprika.com/networks/")
        assert dp[0].params["order_by"] == "created_at"
        assert dp[0].url.endswith("/tokens/search")
        assert "detailed" not in dp[0].params
    finally:
        object.__setattr__(settings, "dexpaprika_enabled", old_enabled)
        object.__setattr__(settings, "multi_provider_enabled", old_multi)
        object.__setattr__(settings, "dexpaprika_base_url", old_base)
        object.__setattr__(settings, "dexpaprika_chain_sources", old_count)


def test_dexpaprika_token_normalizer_preserves_existing_market_shape():
    row = MarketService.normalize_dexpaprika({
        "name": "Token X", "symbol": "TKX", "added_at": "2026-08-31T00:00:00Z",
        "summary": {
            "price_usd": 0.01, "fdv": 1000000, "liquidity_usd": 75000,
            "24h": {"volume_usd": 150000, "buys": 80, "sells": 40, "txns": 120},
            "6h": {"volume_usd": 50000, "buys": 30, "sells": 10, "txns": 40},
            "1h": {"volume_usd": 12000, "buys": 8, "sells": 3, "txns": 11},
            "5m": {"volume_usd": 1500, "buys": 3, "sells": 1, "txns": 4},
        },
    }, "bsc", "0xabc")
    assert row["source"] == "DexPaprika"
    assert row["liquidity"] == 75000
    assert row["volume24h"] == 150000
    assert row["buys24h"] == 80 and row["sells24h"] == 40
    assert row["marketcap"] == row["fdv"] == 1000000


def test_provider_gateway_http_402_opens_quota_circuit():
    gateway = ProviderGateway(max_backoff=900)
    assert gateway.fetch(
        "DexPaprika novos bsc",
        lambda: (_ for _ in ()).throw(CreditsExhausted("HTTP 402 Payment Required")),
        force=True,
    ) is None
    state = gateway.state("DexPaprika novos bsc")
    assert state.status == "QUOTA_EXHAUSTED"
    assert state.circuit_reason == "quota"
    assert state.next_retry > 0


def test_birdeye_compute_units_uses_long_cooldown():
    class CUError(RuntimeError):
        status = 400
        payload = {"message": "Compute Units usage limit exceeded"}
    gateway = ProviderGateway(max_backoff=900)
    before = __import__('time').time()
    gateway.fetch("Birdeye novos ethereum", lambda: (_ for _ in ()).throw(CUError("HTTP 400")), force=True)
    state = gateway.state("Birdeye novos ethereum")
    assert state.status == "QUOTA_EXHAUSTED"
    assert state.next_retry - before >= min(21600, settings.birdeye_quota_cooldown_seconds) - 5


def test_dexpaprika_api_key_is_redacted_from_logs():
    old = settings.dexpaprika_api_key
    try:
        object.__setattr__(settings, "dexpaprika_api_key", "api_super_secret_123")
        rendered = redact("DEXPAPRIKA_API_KEY=api_super_secret_123 Authorization api_super_secret_123")
        assert "api_super_secret_123" not in rendered
        assert "REDACTED" in rendered
    finally:
        object.__setattr__(settings, "dexpaprika_api_key", old)
