from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

import csm
import phantom_v10
from csm.config import settings
from csm.current_install import ensure_current_alias
from csm.observability import ObservabilityEngine
from phantom_v10.discovery import MultiProviderDiscovery
from phantom_v10.errors import NetworkHTTPError, TelegramAPIError
from phantom_v10.honeypot_security import evaluate as evaluate_honeypot, request_spec as honeypot_request_spec
from phantom_v10.providers import ProviderGateway, ProviderState
from phantom_v10.scanner import ScannerEngine
from phantom_v10.telegram import TelegramClient


class MemStorage:
    def __init__(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row


class RateLimitTransport:
    def post_json(self, url, data=None, timeout=None):
        raise NetworkHTTPError(429, {"description": "Too Many Requests", "parameters": {"retry_after": 7}}, url)


def test_release_is_v1658():
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"


def test_telegram_preserves_real_429_retry_after():
    client = TelegramClient(token="123456:abcdefghijklmnopqrstuvwxyz", transport=RateLimitTransport())
    try:
        client.call("sendMessage", {"chat_id": "1", "text": "x"})
        assert False, "expected TelegramAPIError"
    except TelegramAPIError as exc:
        assert exc.error_code == 429
        assert exc.retry_after == 7
        assert "Too Many Requests" in exc.description


def test_telegram_classifies_chat_not_found_as_unreachable():
    assert TelegramClient.is_unreachable_error(TelegramAPIError("Bad Request: chat not found", 400))
    assert TelegramClient.is_unreachable_error(TelegramAPIError("Forbidden: bot was blocked by the user", 403))
    assert not TelegramClient.is_unreachable_error(TelegramAPIError("Too Many Requests", 429, retry_after=5))


def test_phantom_app_does_not_auto_create_configured_chat_as_subscriber():
    source = (Path(__file__).parents[1] / "phantom_v10" / "app.py").read_text(encoding="utf-8")
    # TELEGRAM_CHAT_ID can still be an admin/ops destination, but startup must
    # never turn it into a commercial Free subscriber again.
    assert "storage.upsert_user(configured_chat_id)" not in source


def test_active_router_restores_admin_block_commands():
    source = (Path(__file__).parents[1] / "phantom_v10" / "router.py").read_text(encoding="utf-8")
    assert 'command_base in {"/admin_block", "/admin_unblock"}' in source


def test_observability_dedupes_family_limit_and_route_health():
    obs = ObservabilityEngine(MemStorage())
    now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
    obs._incident("provider:birdeye:limit", active=True, component="provider", severity="HIGH", summary="Limite/cota do provider birdeye detectado", details={"last_error": "Compute Units usage limit exceeded"}, now=now)
    obs._incident("provider:birdeye-novos-bsc:health", active=True, component="provider", severity="MEDIUM", summary="Provider Birdeye novos bsc em estado QUOTA_EXHAUSTED", details={"last_error": "Compute Units usage limit exceeded"}, now=now)
    obs.conn.commit()
    status = obs.status()
    assert status["raw_open_incidents"] == 2
    assert status["open_incidents"] == 1
    assert status["deduplicated_incidents"] == 1
    assert status["health_score"] == 80


def test_observability_resolves_stale_provider_incident():
    obs = ObservabilityEngine(MemStorage())
    old = __import__("datetime").datetime.now(__import__("datetime").timezone.utc) - __import__("datetime").timedelta(hours=2)
    obs._incident("provider:dexscreener-performance:health", active=True, component="provider", severity="MEDIUM", summary="Provider DexScreener performance em estado DEGRADED", details={}, now=old)
    obs.conn.commit()
    status = obs.status()
    assert status["open_incidents"] == 0
    row = obs.conn.execute("SELECT status FROM ops_incidents WHERE incident_key=?", ("provider:dexscreener-performance:health",)).fetchone()
    assert row[0] == "RESOLVED"


def test_provider_limit_notification_uses_long_cooldown(monkeypatch):
    obs = ObservabilityEngine(MemStorage())
    now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
    obs._incident("provider:geckoterminal:limit", active=True, component="provider", severity="HIGH", summary="limite", details={"last_error": "HTTP 429"}, now=now)
    obs.conn.execute("UPDATE ops_incidents SET last_notified_at=?", ((now - __import__("datetime").timedelta(hours=1)).isoformat(),))
    obs.conn.commit()
    old = settings.observability_provider_limit_alert_cooldown
    try:
        object.__setattr__(settings, "observability_provider_limit_alert_cooldown", 21600)
        assert obs.notification_candidates(cooldown_seconds=300) == []
    finally:
        object.__setattr__(settings, "observability_provider_limit_alert_cooldown", old)


def test_geckoterminal_429_uses_adaptive_backoff_in_v1659():
    gateway = ProviderGateway(max_backoff=900)
    state = ProviderState(name="GeckoTerminal market", consecutive_rate_limits=1)
    assert gateway._rate_limit_delay(state) == settings.geckoterminal_rate_limit_initial_seconds
    state.consecutive_rate_limits = 2
    assert gateway._rate_limit_delay(state) == settings.geckoterminal_rate_limit_second_seconds


def test_provider_pause_persists_across_restart(tmp_path):
    old_data = settings.data_dir
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        one = MultiProviderDiscovery()
        one.pause_provider("birdeye", reason="quota", ttl_seconds=3600)
        assert (tmp_path / "runtime" / "v10" / "provider_cooldowns.json").exists()
        two = MultiProviderDiscovery()
        assert two._provider_pause("birdeye") == "quota"
    finally:
        object.__setattr__(settings, "data_dir", old_data)


def test_current_alias_creates_safe_fixed_path(monkeypatch, tmp_path):
    home = tmp_path / "home"
    target = tmp_path / "installed"
    home.mkdir(); target.mkdir()
    monkeypatch.setenv("HOME", str(home))
    result = ensure_current_alias(target)
    assert result["ok"] is True
    alias = home / "CSM_CURRENT"
    assert alias.is_symlink()
    assert alias.resolve() == target.resolve()


def test_honeypot_keyless_request_and_normalization():
    spec = honeypot_request_spec("bsc", "0xabc", "https://api.honeypot.is", "")
    assert spec is not None
    url, params, headers = spec
    assert url.endswith("/v2/IsHoneypot")
    assert params["chainID"] == 56
    assert headers == {}
    verdict = evaluate_honeypot("bsc", {
        "summary": {"risk": "low", "riskLevel": 10},
        "honeypotResult": {"isHoneypot": False},
        "simulationResult": {"buyTax": 2, "sellTax": 3, "transferTax": 0},
        "token": {"totalHolders": 1234},
        "pair": {"liquidity": 75000, "createdAtTimestamp": "123"},
        "contractCode": {"openSource": True, "isProxy": False},
    })
    assert verdict["honeypot_available"] is True
    assert verdict["honeypot_detected"] is False
    assert verdict["honeypot_score"] == 90
    assert verdict["honeypot_total_holders"] == 1234


def test_honeypot_advisory_fallback_does_not_change_live_score(monkeypatch):
    old_enabled = settings.honeypot_enabled
    old_enforce = settings.honeypot_enforce_blocks
    try:
        object.__setattr__(settings, "honeypot_enabled", True)
        object.__setattr__(settings, "honeypot_enforce_blocks", False)
        scanner = ScannerEngine()
        scanner._current_candidate = ("bsc", "0xabc")
        scanner._pending_market = {"chain": "bsc", "address": "0xabc", "symbol": "X"}
        scanner._pending_security = {"goplus_score": None, "goplus_status": "unavailable"}
        monkeypatch.setattr(scanner, "_provider_request", lambda *a, **k: {"summary": {"risk": "high", "riskLevel": 70}, "honeypotResult": {"isHoneypot": False}})
        captured = {}
        monkeypatch.setattr(scanner, "_finalize_approved_market", lambda market, security=None: captured.update(security or {}))
        scanner._honeypot_step("bsc", "0xabc")
        assert captured["honeypot_score"] == 30
        assert "security_score" not in captured
        assert captured["goplus_score"] is None
    finally:
        object.__setattr__(settings, "honeypot_enabled", old_enabled)
        object.__setattr__(settings, "honeypot_enforce_blocks", old_enforce)
