from __future__ import annotations

import csm.provider_intelligence as pi


def test_quality_router_utility_with_coverage_rows_is_numeric(monkeypatch):
    monkeypatch.setattr(pi, "load_provider_health", lambda: {
        "providers": [{"name": "DexPaprika novos bsc", "health_score": 94}]
    })
    monkeypatch.setattr(pi, "coverage_status", lambda: {
        "providers": [{"provider": "dexpaprika", "utility_pct": 72.5}]
    })

    router = pi.ProviderQualityRouter()
    utility = router._utility("dexpaprika")
    assert isinstance(utility, float)
    assert utility == 72.5
    scored = router.score("dexpaprika", "bsc", "discovery")
    assert isinstance(scored.score, float)
    assert scored.score > 0


def test_quality_router_does_not_return_none_with_multiple_rows(monkeypatch):
    monkeypatch.setattr(pi, "load_provider_health", lambda: {"providers": []})
    monkeypatch.setattr(pi, "coverage_status", lambda: {
        "providers": [
            {"provider": "dexpaprika", "utility_pct": 20},
            {"provider": "DexPaprika", "utility_pct": 80},
        ]
    })
    router = pi.ProviderQualityRouter()
    assert router._utility("dexpaprika") == 50.0
    assert router.market_order("bsc")
