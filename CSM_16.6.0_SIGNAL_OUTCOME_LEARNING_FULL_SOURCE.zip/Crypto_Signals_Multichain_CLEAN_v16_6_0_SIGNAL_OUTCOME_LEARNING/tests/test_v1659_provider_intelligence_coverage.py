from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone

import csm
import phantom_v10
from csm.config import settings
from csm.observability import ObservabilityEngine
from csm.provider_coverage import capture_cycle, coverage_status, priority_chains
from csm.provider_intelligence import BirdeyeCredentialProbeState, ProviderQualityRouter
from csm.scanner_intelligence import ensure_schema, provider_rejection_diagnostics
from phantom_v10.discovery import MultiProviderDiscovery
from phantom_v10.errors import TransientNetworkError
from phantom_v10.providers import ProviderGateway, ProviderState


class MemStorage:
    def __init__(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row


def test_release_is_v1659():
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"


def test_geckoterminal_adaptive_backoff_schedule_and_retry_after():
    gateway = ProviderGateway(max_backoff=900)
    state = ProviderState(name="GeckoTerminal market")
    expected = [300, 600, 1200, 1800]
    for idx, seconds in enumerate(expected, start=1):
        state.consecutive_rate_limits = idx
        assert gateway._rate_limit_delay(state) == seconds
    state.consecutive_rate_limits = 1
    assert gateway._rate_limit_delay(state, retry_after=420) == 420


def test_gateway_reads_retry_after_metadata():
    gateway = ProviderGateway(max_backoff=900)
    err = TransientNetworkError("Serviço temporariamente indisponível (HTTP 429).", status=429, retry_after=420)
    assert gateway.fetch("GeckoTerminal market", lambda: (_ for _ in ()).throw(err), force=True) is None
    state = gateway.state("GeckoTerminal market")
    assert state.status == "COOLDOWN"
    assert state.last_retry_after == 420
    assert 419 <= int(state.next_retry - __import__('time').time()) <= 420


def test_birdeye_key_change_creates_probe_only_source(monkeypatch, tmp_path):
    old_data, old_key = settings.data_dir, settings.birdeye_api_key
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        object.__setattr__(settings, "birdeye_api_key", "new-test-key")
        layer = MultiProviderDiscovery()
        rows = layer.sources("plus", ("solana", "bsc"))
        probes = [row for row in rows if row.provider == "birdeye" and row.probe_only]
        assert len(probes) == 1
        assert probes[0].probe_kind == "credential"
        assert probes[0].parser({"data": {"items": [{"address": "SHOULD_NOT_SIGNAL"}]}}) == []
        layer.mark_probe_result("birdeye", "credential", ok=True, detail="ok")
        assert not BirdeyeCredentialProbeState().needs_probe()
    finally:
        object.__setattr__(settings, "data_dir", old_data)
        object.__setattr__(settings, "birdeye_api_key", old_key)


def test_recovery_probe_can_exist_while_normal_gecko_is_paused(tmp_path):
    old_data = settings.data_dir
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        layer = MultiProviderDiscovery()
        layer.pause_provider("geckoterminal", reason="HTTP 429", ttl_seconds=600)
        rows = layer.sources("free", ("solana",))
        assert any(row.provider == "geckoterminal" and row.probe_only and row.probe_kind == "recovery" for row in rows)
        assert not any(row.provider == "geckoterminal" and not row.probe_only for row in rows)
    finally:
        object.__setattr__(settings, "data_dir", old_data)


def test_observability_separates_current_health_from_history():
    obs = ObservabilityEngine(MemStorage())
    now = datetime.now(timezone.utc)
    old = now - timedelta(minutes=10)
    obs._incident("provider:birdeye:limit", active=True, component="provider", severity="HIGH", summary="quota", details={"last_error": "Compute Units usage limit exceeded"}, now=old)
    obs.conn.commit()
    status = obs.status()
    assert status["health_score"] == 100
    assert status["current_open_incidents"] == 0
    assert status["historical_open_incidents"] == 1
    assert status["effective_open_incidents"] == 1


def test_provider_coverage_guard_finds_undercovered_chain(tmp_path):
    old_data = settings.data_dir
    old_min = settings.coverage_guard_min_analyzed_per_hour
    old_cycles = settings.opportunity_coverage_min_cycles
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        object.__setattr__(settings, "coverage_guard_min_analyzed_per_hour", 2)
        object.__setattr__(settings, "opportunity_coverage_min_cycles", 1)
        capture_cycle({
            "cycle_key": "x", "discovery_tier": "premium", "chain_stats": {"solana": {"analyzed": 5, "approved": 1, "rejected": 4}},
            "provider_chain_candidates": {"dexpaprika": {"solana": 5}}, "provider_chain_unique_added": {"dexpaprika": {"solana": 3}},
        })
        report = coverage_status(minutes=60)
        assert report["enough_history"] is True
        assert "bsc" in {row["chain"] for row in report["deficits"]}
        assert "bsc" in priority_chains(limit=20)
    finally:
        object.__setattr__(settings, "data_dir", old_data)
        object.__setattr__(settings, "coverage_guard_min_analyzed_per_hour", old_min)
        object.__setattr__(settings, "opportunity_coverage_min_cycles", old_cycles)


def test_quality_router_prioritizes_probe_and_returns_market_failover_order(tmp_path):
    old_data = settings.data_dir
    try:
        object.__setattr__(settings, "data_dir", tmp_path)
        layer = MultiProviderDiscovery()
        layer.pause_provider("geckoterminal", reason="429", ttl_seconds=600)
        rows = layer.sources("free", ("solana",))
        assert rows[0].probe_only is True
        order = ProviderQualityRouter().market_order("bsc")
        assert set(order) >= {"geckoterminal", "dexscreener"}
        assert len(order) == len(set(order))
    finally:
        object.__setattr__(settings, "data_dir", old_data)


def test_scanner_provider_rejection_diagnostics_groups_chain_source_reason():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)
    now = datetime.now(timezone.utc).isoformat()
    rows = [
        ("c1","bsc","a","A","A","REJECTED","liquidity_below_min",40,40,1000,20000,10000,0,1,1,"DexScreener",now),
        ("c1","bsc","b","B","B","REJECTED","liquidity_below_min",45,45,2000,22000,12000,0,1,1,"DexScreener",now),
        ("c1","bsc","c","C","C","APPROVED","",80,80,50000,100000,100000,10,10,2,"DexPaprika",now),
    ]
    conn.executemany("""INSERT INTO scanner_decisions(cycle_key,chain,address,symbol,name,decision,reason,analytic_score,final_score,liquidity,volume24h,marketcap,change24h,buys24h,sells24h,source,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", rows)
    conn.commit()
    report = provider_rejection_diagnostics(conn, hours=24, chain="bsc")
    assert report["items"][0]["count"] == 2
    assert report["items"][0]["source"] == "DexScreener"
    assert any(row["source"] == "DexPaprika" and row["approved"] == 1 for row in report["providers"])


def test_diagnostic_probe_rows_are_excluded_from_provider_health_snapshot(tmp_path):
    from csm.provider_health import aggregate_provider_health
    rows = [
        {"name":"GeckoTerminal recovery probe","status":"OFFLINE","success_rate":0,"diagnostic_only":True},
        {"name":"DexScreener market","status":"ONLINE","success_rate":100,"latency_ms":100},
    ]
    report = aggregate_provider_health(rows)
    assert len(report["providers"]) == 1
    assert report["providers"][0]["name"] == "DexScreener market"


def test_setup_probe_new_birdeye_key_clears_quota_pause_without_delivery(monkeypatch, tmp_path):
    import csm.setup_wizard as setup_wizard
    import phantom_v10.provider_diagnostics as diagnostics

    old_data = settings.data_dir
    old_state_dir = setup_wizard.STATE_DIR
    try:
        object.__setattr__(settings, "data_dir", tmp_path / "data")
        monkeypatch.setattr(setup_wizard, "STATE_DIR", tmp_path)
        layer = MultiProviderDiscovery()
        layer.pause_provider("birdeye", reason="Compute Units usage limit exceeded", ttl_seconds=21600)
        assert layer._provider_pause("birdeye") is not None

        calls = []
        def fake_check_birdeye(*, api_key=None, check_listing=True, **_kwargs):
            calls.append((api_key, check_listing))
            return {
                "listing_ok": True,
                "credential_ok": True,
                "quota_exhausted": False,
                "rate_limited": False,
                "status": 200,
                "message": "autenticação e New Listing OK",
            }

        monkeypatch.setattr(diagnostics, "check_birdeye", fake_check_birdeye)
        setup_wizard._auto_probe_birdeye({"BIRDEYE_API_KEY": "rotated-key", "BIRDEYE_QUOTA_COOLDOWN_SECONDS": "21600"})

        assert calls == [("rotated-key", True)]
        assert BirdeyeCredentialProbeState().status()["last_probe_result"] == "OK"
        assert MultiProviderDiscovery()._provider_pause("birdeye") is None

        # The same key is not probed again on another setup save.
        setup_wizard._auto_probe_birdeye({"BIRDEYE_API_KEY": "rotated-key"})
        assert calls == [("rotated-key", True)]
    finally:
        object.__setattr__(settings, "data_dir", old_data)
        setup_wizard.STATE_DIR = old_state_dir
