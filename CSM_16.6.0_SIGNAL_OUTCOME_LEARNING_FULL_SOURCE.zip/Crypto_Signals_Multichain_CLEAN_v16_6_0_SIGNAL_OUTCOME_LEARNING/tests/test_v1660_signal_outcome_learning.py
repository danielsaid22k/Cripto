from __future__ import annotations

from datetime import datetime, timezone, timedelta
from types import SimpleNamespace

from csm.storage import Storage
from csm.signal_outcome_learning import SignalOutcomeLearning, MODE, VERSION


def _seed(storage: Storage) -> None:
    now = datetime.now(timezone.utc)
    rows = [
        # chain, provider, score, liq, vol, last_ret, max_ret, dd, tp1, tp2, stop, plan
        ("solana", "dexpaprika", 88, 60000, 120000, 18, 35, -7, True, False, False, "premium"),
        ("solana", "dexpaprika", 91, 90000, 240000, 12, 30, -5, True, False, False, "premium"),
        ("bsc", "dexscreener", 78, 40000, 80000, -14, 4, -18, False, False, True, "plus"),
        ("bsc", "dexscreener", 75, 45000, 90000, -9, 6, -15, False, False, True, "plus"),
    ]
    for idx, row in enumerate(rows, 1):
        chain, provider, score, liq, vol, last_ret, max_ret, dd, tp1, tp2, stop, plan = row
        created = now - timedelta(hours=idx + 1)
        storage.conn.execute(
            """INSERT INTO signal_ledger(
                event_key,chain,address,symbol,name,plan_groups,entry_price,final_score,
                liquidity,volume24h,source,providers_json,delivered_count,observations,
                last_price,last_return_pct,max_return_pct,max_drawdown_pct,
                first_tp1_at,first_tp2_at,first_stop_at,status,created_at,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                f"ev-{idx}", chain, f"addr-{idx}", f"TK{idx}", f"Token {idx}", plan, 1.0,
                score, liq, vol, provider, f'["{provider}"]', 1, 1, 1.0 + last_ret / 100.0,
                last_ret, max_ret, dd,
                (created + timedelta(minutes=20)).isoformat() if tp1 else None,
                (created + timedelta(minutes=40)).isoformat() if tp2 else None,
                (created + timedelta(minutes=25)).isoformat() if stop else None,
                "ACTIVE", created.isoformat(), now.isoformat(),
            ),
        )
        storage.conn.execute(
            """INSERT INTO signal_observations(
                signal_id,captured_bucket,captured_at,age_seconds,price,return_pct,
                liquidity,volume24h,marketcap,score,source,observation_kind
            ) VALUES((SELECT id FROM signal_ledger WHERE event_key=?),?,?,?,?,?,?,?,?,?,?,?)""",
            (
                f"ev-{idx}", int(now.timestamp()) // 60 + idx, now.isoformat(),
                3600.0, 1.0 + last_ret / 100.0, last_ret, liq, vol, 100000, score, provider, "live",
            ),
        )
    storage.conn.commit()


def test_learning_is_evidence_only_and_segments(tmp_path):
    with Storage(tmp_path / "signals.db") as storage:
        _seed(storage)
        report = SignalOutcomeLearning(storage).build(days=30)
    assert VERSION == "16.6.0-signal-outcome-learning"
    assert MODE == "EVIDENCE_ONLY"
    assert report["mode"] == "EVIDENCE_ONLY"
    assert report["signals_observed"] == 4
    assert report["safety"]["live_impact"] is False
    assert report["safety"]["auto_apply_available"] is False
    assert report["safety"]["changes_filters"] is False
    dims = {row["dimension"] for row in report["segments"]}
    assert {"chain", "provider", "chain_provider", "score_band", "liquidity_band", "volume_band", "plan"} <= dims


def test_learning_uses_smoothing_and_min_samples(tmp_path, monkeypatch):
    import csm.signal_outcome_learning as sol
    monkeypatch.setattr(sol, "settings", SimpleNamespace(
        signal_outcome_learning_lookback_days=30,
        signal_outcome_learning_min_samples=2,
        signal_outcome_learning_prior_strength=8.0,
        signal_outcome_learning_enabled=True,
        signal_outcome_learning_interval_seconds=1800,
        data_dir=tmp_path,
    ))
    with Storage(tmp_path / "signals.db") as storage:
        _seed(storage)
        report = SignalOutcomeLearning(storage).build(days=30)
        solana = next(row for row in report["segments"] if row["dimension"] == "chain" and row["segment"] == "solana")
        bsc = next(row for row in report["segments"] if row["dimension"] == "chain" and row["segment"] == "bsc")
    assert solana["enough_samples"] is True
    assert bsc["enough_samples"] is True
    assert 0 < solana["smoothed_win_rate_pct"] < 100
    assert 0 < bsc["smoothed_win_rate_pct"] < 100
    assert solana["smoothed_win_rate_pct"] > bsc["smoothed_win_rate_pct"]


def test_learning_run_persists_snapshot_but_never_applies(tmp_path, monkeypatch):
    import csm.signal_outcome_learning as sol
    monkeypatch.setattr(sol, "settings", SimpleNamespace(
        signal_outcome_learning_lookback_days=30,
        signal_outcome_learning_min_samples=2,
        signal_outcome_learning_prior_strength=8.0,
        signal_outcome_learning_enabled=True,
        signal_outcome_learning_interval_seconds=1800,
        data_dir=tmp_path,
    ))
    with Storage(tmp_path / "signals.db") as storage:
        _seed(storage)
        learner = SignalOutcomeLearning(storage)
        report = learner.run(days=30, persist=True)
        latest = learner.latest()
    assert report["safety"]["auto_apply_available"] is False
    assert latest is not None
    assert latest["mode"] == "EVIDENCE_ONLY"
    assert (tmp_path / "reports" / "signal_outcome_learning.json").exists()


def test_release_wiring_is_v1660():
    import csm
    import phantom_v10
    assert csm.__product_version__ == "16.6.0-signal-outcome-learning"
    assert phantom_v10.__version__ == "16.6.0-retool-admin-speechify"
