from pathlib import Path


def test_http_engine_has_no_urllib3_or_requests():
    text = Path('csm/http_client.py').read_text()
    assert 'urllib3' not in text
    assert 'import requests' not in text
    assert 'Connection": "close' in text


def test_scanner_has_no_thread_pool():
    text = Path('csm/scanner.py').read_text()
    assert 'ThreadPoolExecutor' not in text
    assert 'sequential-v8-safe' in text


def test_runtime_guard_uses_os_lock():
    text = Path('csm/runtime_guard.py').read_text()
    assert 'fcntl.flock' in text


def test_lts_preserved():
    import json
    data=json.loads(Path('LTS_FREEZE.json').read_text())
    assert str(data.get('lts_base') or data.get('base_version') or data.get('base')) == '6.3.0'


def test_supervisor_isolates_scanner_failure(monkeypatch):
    from csm.supervisor import ScannerSupervisor
    class Broken:
        def scan(self, *args, **kwargs):
            raise RuntimeError("fonte caiu")
    supervisor = ScannerSupervisor(Broken())
    assert supervisor.scan(force=True) == []
    assert supervisor.state.failures == 1
