from csm.provider_manager import ProviderManager


def test_provider_fallback_cache():
    manager = ProviderManager(cache_ttl=30)
    first = manager.fetch("demo", lambda: {"ok": 1})
    assert first and first.payload == {"ok": 1} and not first.cached
    second = manager.fetch("demo", lambda: (_ for _ in ()).throw(RuntimeError("down")))
    assert second and second.payload == {"ok": 1} and second.cached


def test_provider_circuit_breaker_without_cache():
    manager = ProviderManager(cache_ttl=0)
    assert manager.fetch("demo", lambda: (_ for _ in ()).throw(RuntimeError("down"))) is None
    state = manager.state("demo")
    assert state.status in {"DEGRADED", "OFFLINE"}
    assert state.retry_at > 0
