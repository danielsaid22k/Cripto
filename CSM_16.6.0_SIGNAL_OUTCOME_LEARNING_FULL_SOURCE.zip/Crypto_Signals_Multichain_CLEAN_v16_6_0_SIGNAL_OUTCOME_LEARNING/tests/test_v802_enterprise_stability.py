from csm.provider_manager import ProviderManager


def test_warning_is_state_transition_only():
    manager = ProviderManager(cache_ttl=0, stale_cache_ttl=60)
    manager.fetch("demo", lambda: (_ for _ in ()).throw(RuntimeError("down")))
    state = manager.state("demo")
    assert state.status == "DEGRADED"
    first_retry = state.retry_at
    # Circuit remains open and loader is not called again.
    result = manager.fetch("demo", lambda: (_ for _ in ()).throw(AssertionError("must not run")))
    assert result is None
    assert state.retry_at == first_retry


def test_provider_recovers_and_exposes_metrics():
    manager = ProviderManager(cache_ttl=0)
    manager.fetch("demo", lambda: (_ for _ in ()).throw(RuntimeError("down")))
    state = manager.state("demo")
    state.retry_at = 0
    result = manager.fetch("demo", lambda: {"ok": True})
    assert result and result.payload["ok"] is True
    row = manager.snapshot()[0]
    assert row["status"] == "ONLINE"
    assert row["successes"] == 1
    assert row["total_calls"] == 2
    assert row["success_rate"] == 50.0
    assert row["average_latency_ms"] is not None


def test_stale_cache_is_used_during_outage():
    manager = ProviderManager(cache_ttl=0, stale_cache_ttl=300)
    assert manager.fetch("demo", lambda: [1]).payload == [1]
    state = manager.state("demo")
    state.retry_at = 0
    result = manager.fetch("demo", lambda: (_ for _ in ()).throw(RuntimeError("down")))
    assert result and result.cached and result.payload == [1]
