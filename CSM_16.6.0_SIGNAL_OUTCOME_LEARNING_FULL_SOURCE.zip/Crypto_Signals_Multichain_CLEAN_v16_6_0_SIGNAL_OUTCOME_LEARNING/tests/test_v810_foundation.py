from pathlib import Path


def test_configuration_manager_preserves_lts_source():
    from phantom.config.manager import configuration_manager
    snapshot = configuration_manager.snapshot()
    assert snapshot.annual_duration_days > 0
    assert snapshot.monthly_duration_days > 0
    assert snapshot.persistent_config.endswith("config.env")


def test_architecture_audit_is_read_only(tmp_path: Path):
    from phantom.architecture.dependencies import audit_architecture
    (tmp_path / "csm").mkdir()
    sample = tmp_path / "csm" / "sample.py"
    sample.write_text("import json\n", encoding="utf-8")
    before = sample.read_bytes()
    report = audit_architecture(tmp_path)
    assert len(report.modules) == 1
    assert sample.read_bytes() == before


def test_plugin_registry_rejects_duplicates():
    import pytest
    from phantom.plugins.registry import PluginManifest, PluginRegistry
    registry = PluginRegistry()
    manifest = PluginManifest("demo", "1.0", "demo:load")
    registry.register(manifest)
    with pytest.raises(ValueError):
        registry.register(manifest)


def test_foundation_health_builds():
    from phantom.monitoring.health import build_foundation_health
    report = build_foundation_health()
    assert report.process_id > 0
    assert report.uptime_seconds >= 0
    assert "database" in report.runtime


def test_foundation_release_preserves_lts(monkeypatch):
    from phantom.release.engine import LTS_BASE, run_foundation_release
    report = run_foundation_release(run_tests=False)
    assert report.lts_base == "6.3.0" == LTS_BASE
    assert any(item.name == "Contrato LTS" for item in report.checks)
