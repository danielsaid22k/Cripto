from pathlib import Path


def test_clean_build_artifacts_removes_only_disposable_files(tmp_path: Path):
    from phantom.release.engine import clean_build_artifacts

    (tmp_path / ".pytest_cache").mkdir()
    (tmp_path / "pkg" / "__pycache__").mkdir(parents=True)
    (tmp_path / "pkg" / "__pycache__" / "x.pyc").write_bytes(b"x")
    (tmp_path / ".coverage").write_text("coverage", encoding="utf-8")
    persistent = tmp_path / "config.env"
    persistent.write_text("TOKEN=preserve", encoding="utf-8")
    database = tmp_path / "signals.db"
    database.write_bytes(b"db")

    report = clean_build_artifacts(tmp_path)

    assert report.count >= 3
    assert not (tmp_path / ".pytest_cache").exists()
    assert not (tmp_path / "pkg" / "__pycache__").exists()
    assert not (tmp_path / ".coverage").exists()
    assert persistent.read_text(encoding="utf-8") == "TOKEN=preserve"
    assert database.read_bytes() == b"db"


def test_release_summary_has_required_sections():
    from phantom.release.engine import build_release_summary

    summary = build_release_summary()
    assert summary["lts_base"] == "6.3.0"
    assert "database" in summary
    assert "backup" in summary
    assert "tests" in summary
    assert "foundation_release" in summary
    assert summary["status"] in {"APROVADO", "BLOQUEADO"}
