from csm.provider_health import aggregate_provider_health, provider_health_score
from csm.provider_manager import ProviderManager
from csm.scanner import SOURCES


def test_provider_priorities_are_explicit_and_unique():
    priorities = [source.priority for source in SOURCES]
    assert priorities == sorted(priorities)
    assert len(priorities) == len(set(priorities))
    assert SOURCES[0].name.startswith("GeckoTerminal")


def test_provider_manager_exposes_priority():
    manager = ProviderManager(cache_ttl=0)
    result = manager.fetch("demo", lambda: {"ok": True}, priority=7)
    assert result is not None
    row = manager.snapshot()[0]
    assert row["priority"] == 7
    assert row["status"] == "ONLINE"


def test_health_score_penalizes_degraded_provider():
    online = {"status": "ONLINE", "success_rate": 100, "average_latency_ms": 100}
    degraded = {"status": "DEGRADED", "success_rate": 50, "average_latency_ms": 2000}
    assert provider_health_score(online) > provider_health_score(degraded)


def test_aggregate_provider_health_shape():
    data = aggregate_provider_health([
        {"name": "A", "status": "ONLINE", "success_rate": 100, "average_latency_ms": 100, "priority": 1},
        {"name": "B", "status": "OFFLINE", "success_rate": 0, "average_latency_ms": None, "priority": 2},
    ])
    assert data["counts"]["ONLINE"] == 1
    assert data["counts"]["OFFLINE"] == 1
    assert 0 <= data["overall_health"] <= 100


def test_provider_catalog_keeps_unvalidated_sources_disabled():
    from csm.provider_catalog import provider_catalog
    rows = provider_catalog()
    active = {row["provider"] for row in rows if row["enabled"]}
    reserved = {row["provider"] for row in rows if not row["enabled"]}
    assert {"GeckoTerminal", "DexScreener"} <= active
    assert {"Birdeye", "DEXTools", "CoinGecko"} <= reserved
