from pathlib import Path


def test_legacy_python_worker_modules_are_removed():
    legacy = [
        'csm/market_isolation_v821.py', 'csm/market_worker_v821.py',
        'csm/scanner_isolation_v821.py', 'csm/scanner_supervisor_v821.py',
        'csm/scanner_worker_v821.py', 'csm/scanner_async_v823.py',
        'csm/scanner_worker_v823.py', 'csm/scanner_async_v830.py',
        'csm/runtime_guard_v821.py', 'csm/stability_status_v821.py',
    ]
    assert all(not Path(item).exists() for item in legacy)


def test_v831_runtime_guard_uses_persistent_namespace_and_no_thread():
    src=Path('csm/runtime_guard_v831.py').read_text()
    assert "runtime" in src and "v831" in src
    assert 'fcntl.flock' in src
    assert 'threading.Thread' not in src
