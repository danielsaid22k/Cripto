from __future__ import annotations

import json
import zipfile


def test_v822_release_engine_has_no_pytest_subprocess():
    from pathlib import Path
    text = Path("phantom/release/engine_v822.py").read_text(encoding="utf-8")
    assert "pytest.main" in text
    assert "subprocess.run" not in text


def test_v822_config_recovery_merges_without_overwrite(tmp_path, monkeypatch):
    import phantom.config.recovery_v822 as recovery

    project = tmp_path / "Crypto_Signals_Multichain_CLEAN_v8_2_2"
    state = tmp_path / "Crypto_Signals_Multichain_State"
    previous = tmp_path / "Crypto_Signals_Multichain_CLEAN_v8_2_1" / "backups"
    project.mkdir(parents=True)
    state.mkdir(parents=True)
    previous.mkdir(parents=True)

    current = state / "config.env"
    current.write_text("TELEGRAM_BOT_TOKEN=novo\nTELEGRAM_CHAT_ID=123\n", encoding="utf-8")

    backup = previous / "ultimo_backup.zip"
    with zipfile.ZipFile(backup, "w") as z:
        z.writestr("backup_manifest.json", json.dumps({"includes_secrets": True}))
        z.writestr("state/config.env", "TELEGRAM_BOT_TOKEN=antigo\nTELEGRAM_CHAT_ID=999\nASAAS_API_KEY=secret\nASAAS_ENABLED=true\n")

    monkeypatch.setattr(recovery, "_project_root", lambda: project)
    monkeypatch.setattr(recovery, "_state_dir", lambda: state)
    report = recovery.recover_persistent_config()
    values = recovery._parse_env_text(current.read_text(encoding="utf-8"))
    assert values["TELEGRAM_BOT_TOKEN"] == "novo"
    assert values["TELEGRAM_CHAT_ID"] == "123"
    assert values["ASAAS_API_KEY"] == "secret"
    assert values["ASAAS_ENABLED"] == "true"
    assert "ASAAS_API_KEY" in report.restored_keys


def test_v822_config_recovery_does_not_require_backup(tmp_path, monkeypatch):
    import phantom.config.recovery_v822 as recovery
    project = tmp_path / "Crypto_Signals_Multichain_CLEAN_v8_2_2"
    state = tmp_path / "Crypto_Signals_Multichain_State"
    project.mkdir(); state.mkdir()
    (state / "config.env").write_text("TELEGRAM_BOT_TOKEN=x\n", encoding="utf-8")
    monkeypatch.setattr(recovery, "_project_root", lambda: project)
    monkeypatch.setattr(recovery, "_state_dir", lambda: state)
    report = recovery.recover_persistent_config()
    assert report.action == "nenhum-backup-com-segredos"
