from __future__ import annotations

import time


def test_central_v2_is_local_and_survives_partial_failures():
    from csm.central_v823 import build_central_v2

    class Storage:
        def get_user(self, user_id):
            return {"plan": "premium", "expires_at": None}
        def user_signal_stats(self, user_id):
            raise RuntimeError("stats indisponível")
        def favorite_count(self, user_id):
            return 2
        def count_today(self, user_id):
            return 1
        def recent_signal_results(self, user_id, limit):
            return []

    class Profiles:
        def get(self, user_id):
            return {"risk_profile": "moderate", "detail_mode": "standard", "notification_frequency": "plan", "preferred_chains": [], "language": "pt-BR"}

    class App:
        storage = Storage()
        user_profiles = Profiles()

    text, keyboard = build_central_v2(App(), 1)
    assert "MINHA CENTRAL" in text
    assert "Premium" in text
    assert "Tela local/fail-safe" in text
    assert keyboard["inline_keyboard"]


def test_fast_ack_uses_short_timeout_once():
    from csm.ui_guard_v823 import acknowledge_callback_fast

    calls = []
    class HTTP:
        def post_json(self, url, data, timeout=None):
            calls.append((url, data, timeout))
            return {"ok": True}
    class Telegram:
        http = HTTP()
        base = "https://api.telegram.org/botX"

    assert acknowledge_callback_fast(Telegram(), "abc", timeout=1.5) is True
    assert len(calls) == 1
    assert calls[0][2] == 1.5


def test_active_scanner_is_single_runtime():
    from pathlib import Path
    src = Path("csm/app.py").read_text(encoding="utf-8")
    assert "SingleRuntimeScannerV831" in src
    assert "scanner_async_v823" not in src


def test_release_receipt_fingerprint_changes_with_code(tmp_path, monkeypatch):
    import phantom.release.engine_v823 as engine
    from csm.config import settings

    # O fingerprint real deve ser estável para o mesmo código.
    a = engine._fingerprint()
    b = engine._fingerprint()
    assert a == b
    assert len(a) == 64
