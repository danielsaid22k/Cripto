from pathlib import Path


def test_all_declared_callback_literals_have_route():
    from csm.ui_audit_v830 import audit_ui
    report=audit_ui()
    assert report.callbacks_unmatched == []


def test_all_reply_keyboard_buttons_have_message_handler():
    from csm.ui_audit_v830 import audit_ui
    report=audit_ui()
    assert report.reply_buttons_missing == []


def test_scanner_worker_coordinator_is_replaced_by_single_runtime():
    src=Path('csm/app.py').read_text(encoding='utf-8')
    assert 'SingleRuntimeScannerV831' in src
    assert 'AsyncScannerCoordinatorV830' not in src
    assert not Path('csm/scanner_async_v830.py').exists()


def test_message_minhas_central_uses_local_v2():
    src=Path('csm/app.py').read_text(encoding='utf-8')
    assert 'build_central_v2(self, user_id)' in src


def test_v830_router_validates_registry():
    src=Path('csm/ui_callbacks_v830.py').read_text(encoding='utf-8')
    assert 'matches_callback(data)' in src
