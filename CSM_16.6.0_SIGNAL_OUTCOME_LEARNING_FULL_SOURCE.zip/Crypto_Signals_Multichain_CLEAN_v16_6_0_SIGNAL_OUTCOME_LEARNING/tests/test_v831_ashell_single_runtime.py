from pathlib import Path


def test_v831_version_and_lts():
    from csm import __version__
    import json
    assert __version__.startswith("8.3.1")
    freeze=json.loads(Path("LTS_FREEZE.json").read_text())
    assert freeze["lts_base"] == "6.3.0"


def test_mobile_transport_uses_curl_not_python_worker():
    from csm.curl_http_v831 import CurlJSONV831
    captured={}
    class Done:
        returncode=0
        stdout='{"ok":true}\n__PHANTOM_HTTP_STATUS__:200'
        stderr=''
    def runner(cmd, **kwargs):
        captured['cmd']=cmd
        return Done()
    http=CurlJSONV831(binary='/usr/bin/curl', runner=runner, timeout=2)
    assert http.get_json('https://example.invalid') == {"ok": True}
    command=' '.join(captured['cmd'])
    assert 'curl' in command
    assert 'python' not in command.lower()
    assert '--max-time' in captured['cmd']


def test_scanner_is_cooperative_and_creates_no_python_worker():
    from csm.scanner_single_v831 import SingleRuntimeScannerV831

    class FakeHTTP:
        def get_json(self, url, params=None):
            if 'geckoterminal' in url:
                return {"data":[{"id":"solana_pool","attributes":{"network":"solana"},"relationships":{"base_token":{"data":{"id":"solana_ABC"}}}}]}
            return []

    class FakeMarket:
        def fetch(self, chain, address, force=False):
            return {
                "chain": chain, "address": address, "symbol": "ABC", "name":"ABC",
                "price": 1.0, "liquidity": 150000.0, "volume24h": 600000.0,
                "volume6h": 100000.0, "volume1h": 30000.0, "marketcap": 1000000.0,
                "fdv": 1000000.0, "change24h": 5.0, "change6h": 2.0, "change1h": 1.0,
                "buys24h": 100, "sells24h": 80, "buys6h": 20, "sells6h": 15,
                "buys1h": 10, "sells1h": 8, "age_days": 10.0, "dex":"x", "pair":"p", "url":"", "holders":None,
            }

    scanner=SingleRuntimeScannerV831(http=FakeHTTP(), market=FakeMarket(), mobile=True)
    assert scanner.start(limit=10, chains=['solana'], force=True)
    assert scanner.active
    completion=None
    steps=0
    while completion is None and steps < 20:
        completion=scanner.poll(); steps += 1
    assert completion is not None
    assert completion.ok
    assert completion.stats['mode'] == 'single-python-cooperative-v831'
    assert steps > 1  # prova que foi dividido em etapas cooperativas
    assert completion.results


def test_runtime_guard_has_no_background_thread():
    text=Path('csm/runtime_guard_v831.py').read_text()
    assert 'import threading' not in text
    assert 'threading.Thread' not in text
    assert 'fcntl.flock' in text


def test_app_no_longer_uses_python_scanner_workers():
    text=Path('csm/app.py').read_text()
    assert 'SingleRuntimeScannerV831' in text
    assert 'SingleRuntimeMarketV831' in text
    assert 'AsyncScannerCoordinatorV830' not in text
    assert 'IsolatedScannerClient' not in text
    assert 'IsolatedMarketClient' not in text


def test_mobile_telegram_polling_is_short_and_threadless():
    text=Path('csm/telegram_mobile_v831.py').read_text()
    assert '"timeout": 1' in text
    assert 'threading' not in text
