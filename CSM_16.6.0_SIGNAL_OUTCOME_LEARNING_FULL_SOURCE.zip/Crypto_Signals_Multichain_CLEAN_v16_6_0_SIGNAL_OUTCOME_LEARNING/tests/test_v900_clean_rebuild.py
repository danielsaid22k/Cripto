from __future__ import annotations

import json
import time
from pathlib import Path
from types import SimpleNamespace

from csm.storage import Storage
from phantom_v9 import __version__
from phantom_v9.app import PhantomAppV9
from phantom_v9.network import CurlTransport
from phantom_v9.release import runtime_audit, ui_audit
from phantom_v9.runtime import RuntimeGuard
from phantom_v9.scanner import ScannerEngine
from phantom_v9 import ui


class DummyTelegram:
    def __init__(self): self.sent=[]; self.edited=[]; self.acked=[]
    def answer_callback(self,cid,text=""): self.acked.append(cid); return True
    def send(self,chat_id,text,reply_markup=None): self.sent.append((chat_id,text,reply_markup)); return {"message_id":1}
    def edit_or_send(self,chat_id,message_id,text,reply_markup=None): self.edited.append((chat_id,message_id,text,reply_markup)); return {"message_id":message_id}


class DummyTransport:
    def get_json(self,url,params=None,timeout=None):
        if "trending_pools" in url or "new_pools" in url:
            return {"data":[]}
        if "token-profiles" in url or "token-boosts" in url:
            return []
        return {}


def test_version_and_runtime_contract():
    assert __version__.startswith("9.0.")
    audit=runtime_audit()
    assert audit["result"] == "APROVADO"
    assert audit["single_python"] is True


def test_ui_registry_has_no_dead_routes():
    audit=ui_audit()
    assert audit["result"] == "APROVADO"
    assert audit["missing_callbacks"] == []
    assert audit["missing_reply_handlers"] == []
    for sample in ["menu","dashboard","intelligence_center","preferences","pref|auto_signals","profile|risk","history|0","scanner_force","refresh|solana|abc"]:
        assert ui.callback_supported(sample)


def test_auto_signals_button_is_status_only(tmp_path):
    storage=Storage(tmp_path/"v9.db")
    tg=DummyTelegram()
    app=PhantomAppV9(storage=storage,transport=DummyTransport(),telegram=tg)
    app.scanner.active=False
    msg={"chat":{"id":123},"from":{"id":123,"first_name":"T"},"text":"📡 Sinais automáticos"}
    app.message(msg)
    assert app.scanner.active is False
    assert tg.sent and "SINAIS AUTOMÁTICOS" in tg.sent[-1][1]
    storage.close()


def test_central_and_dashboard_are_local(tmp_path):
    storage=Storage(tmp_path/"v9.db")
    tg=DummyTelegram(); app=PhantomAppV9(storage=storage,transport=DummyTransport(),telegram=tg)
    storage.upsert_user(10,"u","U")
    for data in ("intelligence_center","dashboard","preferences"):
        app.callback({"id":"cb","data":data,"message":{"chat":{"id":10},"message_id":7},"from":{"id":10,"first_name":"U"}})
    assert len(tg.acked)==3
    assert len(tg.edited)==3
    assert not app.scanner.active
    storage.close()


def test_scanner_is_cooperative_one_step_at_a_time():
    sc=ScannerEngine(transport=DummyTransport())
    assert sc.start(limit=10,chains=["solana"])
    assert sc.phase == "discover"
    assert sc.step() is None
    assert sc.active
    # Empty discovery sources eventually finish without threads/processes.
    result=None
    for _ in range(20):
        result=sc.step()
        if result is not None: break
    assert result == []
    assert sc.active is False


def test_runtime_guard_recovers_stale_lock(tmp_path, monkeypatch):
    import phantom_v9.runtime as rt
    monkeypatch.setattr(rt,"STATE_DIR",tmp_path)
    g=RuntimeGuard("bot",stale_after=15)
    g.runtime_dir=tmp_path/"runtime"/"v9"; g.runtime_dir.mkdir(parents=True,exist_ok=True); g.lock_file=g.runtime_dir/".bot.lock.json"; g.session_file=g.runtime_dir/".bot.session.json"
    g.lock_file.write_text(json.dumps({"pid":999999,"heartbeat_at":time.time()-100,"session":"old"}))
    g.acquire()
    assert g.acquired
    g.release()
    assert not g.lock_file.exists()


def test_all_reply_buttons_return_without_network(tmp_path):
    from csm.user_profiles import UserProfileStore
    storage=Storage(tmp_path/"buttons.db"); tg=DummyTelegram(); app=PhantomAppV9(storage=storage,transport=DummyTransport(),telegram=tg)
    app.user_profiles=UserProfileStore(tmp_path/"profiles.json")
    storage.upsert_user(321,"u","U")
    for label in sorted(ui.REPLY_BUTTONS):
        before=len(tg.sent)
        app.message({"chat":{"id":321},"from":{"id":321,"first_name":"U"},"text":label})
        assert len(tg.sent) > before, label
    assert app.scanner.active is False
    storage.close()


def test_callback_contract_samples_are_fail_safe(tmp_path):
    from csm.user_profiles import UserProfileStore
    storage=Storage(tmp_path/"callbacks.db"); tg=DummyTelegram(); app=PhantomAppV9(storage=storage,transport=DummyTransport(),telegram=tg)
    app.user_profiles=UserProfileStore(tmp_path/"profiles.json")
    storage.upsert_user(42,"u","U")
    samples=[
        "menu","plans","preferences","pref|auto_signals","profile|risk","intelligence_center","dashboard","my_plan","favorites","export_user",
        "scanner","scanner_force","scanner_page|0","scanner_detail|0","subscribe|premium","paymethod|premium|PIX","payment_check","history|0",
        "copy|solana|ABC","favorite|solana|ABC","unfavorite|solana|ABC","refresh|solana|ABC",
    ]
    for data in samples:
        app.callback({"id":"cb-"+data,"data":data,"message":{"chat":{"id":42},"message_id":7},"from":{"id":42,"first_name":"U"}})
    assert len(tg.acked)==len(samples)
    assert len(tg.sent)+len(tg.edited) >= len(samples)
    storage.close()
