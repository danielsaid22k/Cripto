from __future__ import annotations

import json
import time
from types import SimpleNamespace

import pytest

from csm.storage import Storage
from phantom_v9 import __version__
from phantom_v9.app_v901 import PhantomAppV901
from phantom_v9.network_v901 import JobResult
from phantom_v9.runtime_v901 import AlreadyRunningError, RuntimeGuardV901
from phantom_v9.scanner_v901 import ScannerEngineV901


class DummyTelegram:
    def __init__(self): self.sent=[]; self.edited=[]; self.acked=[]
    def answer_callback(self,cid,text=""): self.acked.append(cid); return True
    def send(self,chat_id,text,reply_markup=None): self.sent.append((chat_id,text,reply_markup)); return {"message_id":1}
    def edit_or_send(self,chat_id,message_id,text,reply_markup=None): self.edited.append((chat_id,message_id,text,reply_markup)); return {"message_id":message_id}


class DummySyncTransport:
    def get_json(self,*a,**k): return {}
    def post_json(self,*a,**k): return {"ok":True,"result":{}}
    headers={}


class FakeCoopTransport:
    def __init__(self, payloads=None):
        self.payloads=list(payloads or [])
        self.current=None
        self.starts=0
    def health(self):
        return {"available":True,"busy":self.current is not None,"blocked_reason":"","job_id":getattr(self.current,"job_id",None)}
    def start_json(self,method,url,params=None,timeout=None):
        if self.current is not None: return None
        self.starts+=1
        self.current=SimpleNamespace(job_id=f"j{self.starts}",url=url)
        return self.current
    def poll(self,job):
        assert job is self.current
        payload=self.payloads.pop(0) if self.payloads else ({"data":[]} if "gecko" in job.url else [])
        self.current=None
        return JobResult("ok",payload=payload,status=200,elapsed_ms=3.0)


class StuckCoopTransport(FakeCoopTransport):
    def poll(self,job):
        return JobResult("pending",elapsed_ms=1.0)


def _guard_in_tmp(tmp_path, monkeypatch, stale_after=8):
    import phantom_v9.runtime_v901 as rt
    monkeypatch.setattr(rt,"STATE_DIR",tmp_path)
    return rt.RuntimeGuardV901("bot",stale_after=stale_after)


def test_version_is_runtime_recovery():
    assert __version__ == "9.0.3-timezone-metrics-hotfix"


def test_runtime_guard_ignores_pid_and_recovers_expired_session(tmp_path, monkeypatch):
    g=_guard_in_tmp(tmp_path,monkeypatch)
    g.runtime_dir.mkdir(parents=True,exist_ok=True)
    old={"pid":79903,"session":"old-session","heartbeat_at":time.time()-120,"state":"running","scanner_phase":"discover"}
    g.lock_file.write_text(json.dumps(old)); g.session_file.write_text(json.dumps(old))
    event=g.acquire()
    assert event.recovered is True
    assert event.reason == "heartbeat_expirado"
    assert g.lock_file.exists()
    current=json.loads(g.lock_file.read_text())
    assert current["session"] == g.session
    assert current["liveness_authority"] == "session+heartbeat"
    assert list(g.runtime_dir.glob(".bot.lock.json.stale.*"))
    assert list(g.runtime_dir.glob(".bot.session.json.stale.*"))
    g.release()


def test_runtime_guard_blocks_only_recent_matching_session(tmp_path, monkeypatch):
    g=_guard_in_tmp(tmp_path,monkeypatch)
    g.runtime_dir.mkdir(parents=True,exist_ok=True)
    recent={"pid":123,"session":"same","heartbeat_at":time.time(),"state":"running"}
    g.lock_file.write_text(json.dumps(recent)); g.session_file.write_text(json.dumps(recent))
    with pytest.raises(AlreadyRunningError): g.acquire()


def test_runtime_guard_recovers_inconsistent_pair(tmp_path, monkeypatch):
    g=_guard_in_tmp(tmp_path,monkeypatch)
    g.runtime_dir.mkdir(parents=True,exist_ok=True)
    now=time.time()
    g.lock_file.write_text(json.dumps({"pid":1,"session":"a","heartbeat_at":now,"state":"running"}))
    g.session_file.write_text(json.dumps({"pid":1,"session":"b","heartbeat_at":now,"state":"running"}))
    event=g.acquire()
    assert event.recovered and event.reason == "sessao_inconsistente"
    g.release()


def test_scanner_network_is_polled_not_waited():
    transport=FakeCoopTransport(payloads=[{"data":[]},{"data":[]},[],[]])
    sc=ScannerEngineV901(transport=transport,cycle_timeout=30,phase_timeout=10)
    assert sc.start(limit=10,chains=["solana"])
    # Each source requires a start step and a later poll step. No step blocks.
    for _ in range(30):
        result=sc.step()
        if result is not None: break
    assert result == []
    assert sc.last_stats["sources_ok"] == 4
    assert transport.starts == 4
    assert sc.active is False


def test_scanner_watchdog_aborts_state_machine_without_network_wait():
    transport=StuckCoopTransport()
    sc=ScannerEngineV901(transport=transport,cycle_timeout=20,phase_timeout=10)
    sc.start(limit=10,chains=["solana"])
    sc._started=time.monotonic()-100
    result=sc.step()
    assert result == []
    assert sc.active is False
    assert sc.last_stats["aborted"] == 1
    assert "watchdog" in sc.last_error


def test_app_uses_new_scanner_and_auto_signals_stays_local(tmp_path):
    storage=Storage(tmp_path/"app.db")
    tg=DummyTelegram()
    app=PhantomAppV901(storage=storage,transport=DummySyncTransport(),telegram=tg)
    assert isinstance(app.scanner,ScannerEngineV901)
    storage.upsert_user(55,"u","U")
    app.message({"chat":{"id":55},"from":{"id":55,"first_name":"U"},"text":"📡 Sinais automáticos"})
    assert app.scanner.active is False
    assert tg.sent and "SINAIS AUTOMÁTICOS" in tg.sent[-1][1]
    storage.close()


def test_background_position_monitor_does_not_call_sync_market(tmp_path):
    storage=Storage(tmp_path/"position.db")
    tg=DummyTelegram()
    app=PhantomAppV901(storage=storage,transport=DummySyncTransport(),telegram=tg)
    app.market.fetch=lambda *a,**k: (_ for _ in ()).throw(AssertionError("sync market must not run in background"))
    app.next_cycle={"premium":time.monotonic()+999,"plus":time.monotonic()+999,"free":time.monotonic()+999}
    app.position_queue.append({"id":1,"user_id":1,"chain":"solana","address":"abc","symbol":"X","entry_price":1,"peak_price":1,"stop_sent":0,"target1_sent":0,"target2_sent":0,"stop_price":0.5,"target1_price":2,"target2_price":3})
    app._scheduler_step()
    assert not app.position_queue
    storage.close()
