from __future__ import annotations

from types import SimpleNamespace

import pytest

from phantom_v9 import __version__
from phantom_v9.network_v902 import (
    CurlQueueV902,
    NetworkBusyError,
    QueuedCurlTransportV902,
    CooperativeCurlTransportV902,
)
from phantom_v9.telegram_v902 import TelegramClientV902
from phantom_v9.release import runtime_audit


class FakeRunner:
    def __init__(self): self.calls=0
    def __call__(self,*args,**kwargs):
        self.calls+=1
        return SimpleNamespace(stdout='{"ok":true,"result":[]}\n__PHANTOM_STATUS__:200',stderr='',returncode=0)


def test_version_network_queue():
    assert __version__ == "9.0.3-timezone-metrics-hotfix"


def test_global_queue_rejects_second_owner():
    q=CurlQueueV902()
    assert q.acquire("a","scanner") is True
    assert q.acquire("b","sync") is False
    assert q.snapshot()["busy"] is True
    assert q.release("a") is True
    assert q.acquire("b","sync") is True


def test_sync_transport_does_not_launch_when_queue_busy():
    q=CurlQueueV902(); q.acquire("scanner-job","scanner")
    runner=FakeRunner()
    t=QueuedCurlTransportV902(binary="curl",runner=runner,queue=q,label="telegram")
    with pytest.raises(NetworkBusyError):
        t.get_json("https://example.invalid")
    assert runner.calls == 0


def test_telegram_updates_yields_without_curl_when_scanner_busy():
    q=CurlQueueV902(); q.acquire("scanner-job","scanner")
    runner=FakeRunner()
    t=QueuedCurlTransportV902(binary="curl",runner=runner,queue=q,label="telegram")
    tg=TelegramClientV902(token="123:abc",transport=t)
    assert tg.updates() == []
    assert runner.calls == 0


def test_scanner_and_sync_share_same_queue(tmp_path, monkeypatch):
    import phantom_v9.network_v902 as nv
    monkeypatch.setattr(nv,"STATE_DIR",tmp_path)
    q=CurlQueueV902()
    class FakePopen:
        def __init__(self,*a,**k): self.returncode=None
        def poll(self): return None
        def terminate(self): pass
        def kill(self): pass
    monkeypatch.setattr(nv.subprocess,"Popen",FakePopen)
    sc=CooperativeCurlTransportV902(binary="curl",queue=q)
    job=sc.start_json("GET","https://example.invalid",timeout=1)
    assert job is not None and q.busy()
    runner=FakeRunner(); sync=QueuedCurlTransportV902(binary="curl",runner=runner,queue=q,label="telegram")
    with pytest.raises(NetworkBusyError): sync.get_json("https://example.invalid")
    assert runner.calls == 0


def test_release_audit_requires_one_global_queue():
    audit=runtime_audit()
    assert audit["result"] == "APROVADO"
    assert audit["max_concurrent_curl"] == 1
    assert audit["network_transport"] == "one-global-curl-queue"

def test_sync_request_releases_queue_after_completion():
    q=CurlQueueV902(); runner=FakeRunner()
    t=QueuedCurlTransportV902(binary="curl",runner=runner,queue=q,label="telegram")
    payload=t.get_json("https://example.invalid")
    assert payload == {"ok":True,"result":[]}
    assert q.busy() is False
    assert runner.calls == 1
