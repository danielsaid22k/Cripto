from __future__ import annotations

import os
import time
from pathlib import Path


def test_scanner_stats_converts_utc_created_at_to_local_day(tmp_path, monkeypatch):
    # Reproduces the a-Shell/Brazil boundary where local evening is already
    # the next UTC calendar day. created_at is stored as UTC by SQLite.
    old_tz = os.environ.get("TZ")
    monkeypatch.setenv("TZ", "America/Sao_Paulo")
    if hasattr(time, "tzset"):
        time.tzset()
    try:
        from csm.storage import Storage
        db = tmp_path / "signals.db"
        storage = Storage(db)
        try:
            # Use SQLite's own UTC clock so the test exercises the same storage path.
            storage.record_scanner_cycle("premium", {"candidates": 7, "approved": 2, "sent": 1, "top_score": 88})
            stats = storage.scanner_stats_today()
            assert stats["cycles"] == 1
            assert stats["discovered"] == 7
        finally:
            storage.close()
    finally:
        if old_tz is None:
            os.environ.pop("TZ", None)
        else:
            os.environ["TZ"] = old_tz
        if hasattr(time, "tzset"):
            time.tzset()


def test_scanner_stats_query_converts_created_at_to_localtime():
    source = Path("csm/storage.py").read_text(encoding="utf-8")
    assert "date(created_at,'localtime')=date('now','localtime')" in source


def test_runtime_recover_cli_uses_v902_guard():
    source = Path("main.py").read_text(encoding="utf-8")
    assert 'from phantom_v9.runtime_v902 import RuntimeGuardV902, AlreadyRunningError' in source
    assert 'guard=RuntimeGuardV902("bot")' in source
