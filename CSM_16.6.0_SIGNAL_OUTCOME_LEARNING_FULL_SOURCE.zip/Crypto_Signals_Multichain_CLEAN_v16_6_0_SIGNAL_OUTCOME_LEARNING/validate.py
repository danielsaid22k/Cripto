from __future__ import annotations

import compileall
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def clean_generated() -> None:
    for path in ROOT.rglob("__pycache__"):
        shutil.rmtree(path, ignore_errors=True)
    shutil.rmtree(ROOT / ".pytest_cache", ignore_errors=True)
    for path in ROOT.rglob("*.py[co]"):
        path.unlink(missing_ok=True)


def _run(args: list[str], env: dict[str, str]) -> int:
    return subprocess.run(args, cwd=ROOT, env=env, check=False).returncode


def main() -> int:
    clean_generated()
    print("[1/4] Compilando pacote Python completo...", flush=True)
    if not compileall.compile_dir(ROOT, quiet=1, force=True):
        return 1
    clean_generated()

    inherited_pythonpath = os.environ.get("PYTHONPATH", "")
    test_pythonpath = str(ROOT) + (os.pathsep + inherited_pythonpath if inherited_pythonpath else "")

    # Validation never consumes or mutates the operator's persistent database.
    # A clean temporary state also exposes hidden test-order dependencies.
    with tempfile.TemporaryDirectory(prefix="csm_validation_") as tmp:
        env = {**os.environ, "PYTHONPATH": test_pythonpath, "CSM_STATE_DIR": tmp}

        print("[2/4] Executando testes em estado isolado...", flush=True)
        code = _run([sys.executable, "-m", "pytest", "-q"], env)
        if code != 0:
            return code

        print("[3/4] Verificando SQLite e selftest isolados...", flush=True)
        code = _run([sys.executable, "main.py", "selftest"], env)
        if code != 0:
            return code

        print("[4/4] Verificando governança e limpeza da release...", flush=True)
        code = _run([sys.executable, "main.py", "release-check"], env)
        if code == 0:
            print("✅ VALIDAÇÃO CONCLUÍDA EM AMBIENTE LIMPO", flush=True)
        return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        clean_generated()
